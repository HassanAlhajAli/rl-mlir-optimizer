module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x8xf64>) : !llvm.array<1 x vector<8xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x1xf64>) : !llvm.array<8 x vector<1xf64>>
    %22 = llvm.mlir.constant(64 : index) : i64
    %23 = llvm.mlir.constant(256 : index) : i64
    %24 = llvm.mlir.constant(0 : index) : i64
    %25 = llvm.mlir.constant(1 : index) : i64
    %26 = llvm.mlir.constant(8 : index) : i64
    %27 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%24 : i64)
  ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb2
    %29 = llvm.icmp "slt" %28, %23 : i64
    llvm.cond_br %29, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %30 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %31 = llvm.getelementptr %30[%28] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %27, %31 : f64, !llvm.ptr
    %32 = llvm.add %28, %25  : i64
    llvm.br ^bb1(%32 : i64)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%24 : i64)
  ^bb4(%33: i64):  // 2 preds: ^bb3, ^bb11
    %34 = llvm.icmp "slt" %33, %23 : i64
    llvm.cond_br %34, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    %35 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %36 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %37 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %38 = llvm.insertvalue %35, %37[0] : !llvm.struct<(ptr, ptr, i64)> 
    %39 = llvm.insertvalue %36, %38[1] : !llvm.struct<(ptr, ptr, i64)> 
    %40 = llvm.mlir.constant(0 : index) : i64
    %41 = llvm.insertvalue %40, %39[2] : !llvm.struct<(ptr, ptr, i64)> 
    %42 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %45 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %46 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %47 = llvm.mul %33, %22  : i64
    %48 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %49 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %50 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %51 = llvm.insertvalue %48, %50[0] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.insertvalue %49, %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.mlir.constant(0 : index) : i64
    %54 = llvm.insertvalue %53, %52[2] : !llvm.struct<(ptr, ptr, i64)> 
    %55 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %58 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %59 = llvm.insertvalue %48, %58[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %60 = llvm.insertvalue %49, %59[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %61 = llvm.insertvalue %33, %60[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %62 = llvm.mlir.constant(8 : index) : i64
    %63 = llvm.insertvalue %62, %61[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %64 = llvm.mlir.constant(1 : index) : i64
    %65 = llvm.insertvalue %64, %63[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%24 : i64)
  ^bb6(%66: i64):  // 2 preds: ^bb5, ^bb10
    %67 = llvm.icmp "slt" %66, %22 : i64
    llvm.cond_br %67, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %68 = llvm.mlir.constant(1 : index) : i64
    %69 = llvm.alloca %68 x !llvm.array<8 x vector<1xf64>> : (i64) -> !llvm.ptr
    %70 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %71 = llvm.insertvalue %69, %70[0] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.insertvalue %69, %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %73 = llvm.mlir.constant(0 : index) : i64
    %74 = llvm.insertvalue %73, %72[2] : !llvm.struct<(ptr, ptr, i64)> 
    %75 = llvm.add %47, %66  : i64
    %76 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %77 = llvm.insertvalue %35, %76[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.insertvalue %36, %77[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.insertvalue %75, %78[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.mlir.constant(8 : index) : i64
    %81 = llvm.insertvalue %80, %79[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %82 = llvm.mlir.constant(64 : index) : i64
    %83 = llvm.insertvalue %82, %81[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.mlir.constant(1 : index) : i64
    %85 = llvm.insertvalue %84, %83[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.mlir.constant(1 : index) : i64
    %87 = llvm.insertvalue %86, %85[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %91 = llvm.insertvalue %88, %90[0] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.insertvalue %89, %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.mlir.constant(0 : index) : i64
    %94 = llvm.insertvalue %93, %92[2] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %99 = llvm.insertvalue %88, %98[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %89, %99[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %66, %100[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.mlir.constant(1 : index) : i64
    %103 = llvm.insertvalue %102, %101[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %104 = llvm.mlir.constant(1 : index) : i64
    %105 = llvm.insertvalue %104, %103[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %107 = llvm.extractvalue %74[0] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.insertvalue %107, %106[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.extractvalue %74[1] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.insertvalue %109, %108[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.mlir.constant(0 : index) : i64
    %112 = llvm.insertvalue %111, %110[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %113 = llvm.mlir.constant(8 : index) : i64
    %114 = llvm.insertvalue %113, %112[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.mlir.constant(1 : index) : i64
    %116 = llvm.insertvalue %115, %114[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%24 : i64)
  ^bb8(%117: i64):  // 2 preds: ^bb7, ^bb9
    %118 = llvm.icmp "slt" %117, %26 : i64
    llvm.cond_br %118, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %119 = llvm.getelementptr %36[%75] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %120 = llvm.mlir.constant(64 : index) : i64
    %121 = llvm.mul %117, %120  : i64
    %122 = llvm.add %121, %24  : i64
    %123 = llvm.getelementptr %119[%122] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %124 = llvm.load %123 : !llvm.ptr -> f64
    %125 = llvm.mlir.undef : vector<1xf64>
    %126 = llvm.mlir.constant(0 : i32) : i32
    %127 = llvm.insertelement %124, %125[%126 : i32] : vector<1xf64>
    %128 = llvm.shufflevector %127, %125 [0] : vector<1xf64> 
    %129 = llvm.getelementptr %109[%117] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %128, %129 : vector<1xf64>, !llvm.ptr
    %130 = llvm.add %117, %25  : i64
    llvm.br ^bb8(%130 : i64)
  ^bb10:  // pred: ^bb8
    %131 = llvm.load %69 : !llvm.ptr -> !llvm.array<8 x vector<1xf64>>
    %132 = llvm.getelementptr %89[%66] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %133 = llvm.getelementptr %132[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %134 = llvm.load %133 : !llvm.ptr -> f64
    %135 = llvm.mlir.undef : vector<1xf64>
    %136 = llvm.mlir.constant(0 : i32) : i32
    %137 = llvm.insertelement %134, %135[%136 : i32] : vector<1xf64>
    %138 = llvm.shufflevector %137, %135 [0] : vector<1xf64> 
    %139 = llvm.insertvalue %138, %21[0] : !llvm.array<8 x vector<1xf64>> 
    %140 = llvm.insertvalue %138, %139[1] : !llvm.array<8 x vector<1xf64>> 
    %141 = llvm.insertvalue %138, %140[2] : !llvm.array<8 x vector<1xf64>> 
    %142 = llvm.insertvalue %138, %141[3] : !llvm.array<8 x vector<1xf64>> 
    %143 = llvm.insertvalue %138, %142[4] : !llvm.array<8 x vector<1xf64>> 
    %144 = llvm.insertvalue %138, %143[5] : !llvm.array<8 x vector<1xf64>> 
    %145 = llvm.insertvalue %138, %144[6] : !llvm.array<8 x vector<1xf64>> 
    %146 = llvm.insertvalue %138, %145[7] : !llvm.array<8 x vector<1xf64>> 
    %147 = llvm.extractvalue %65[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = llvm.extractvalue %65[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %149 = llvm.getelementptr %147[%148] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %150 = llvm.getelementptr %149[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %151 = llvm.load %150 {alignment = 8 : i64} : !llvm.ptr -> vector<8xf64>
    %152 = llvm.mlir.undef : !llvm.array<8 x vector<1xf64>>
    %153 = llvm.extractvalue %131[0] : !llvm.array<8 x vector<1xf64>> 
    %154 = llvm.fmul %153, %138  : vector<1xf64>
    %155 = llvm.insertvalue %154, %152[0] : !llvm.array<8 x vector<1xf64>> 
    %156 = llvm.extractvalue %131[1] : !llvm.array<8 x vector<1xf64>> 
    %157 = llvm.fmul %156, %138  : vector<1xf64>
    %158 = llvm.insertvalue %157, %155[1] : !llvm.array<8 x vector<1xf64>> 
    %159 = llvm.extractvalue %131[2] : !llvm.array<8 x vector<1xf64>> 
    %160 = llvm.fmul %159, %138  : vector<1xf64>
    %161 = llvm.insertvalue %160, %158[2] : !llvm.array<8 x vector<1xf64>> 
    %162 = llvm.extractvalue %131[3] : !llvm.array<8 x vector<1xf64>> 
    %163 = llvm.fmul %162, %138  : vector<1xf64>
    %164 = llvm.insertvalue %163, %161[3] : !llvm.array<8 x vector<1xf64>> 
    %165 = llvm.extractvalue %131[4] : !llvm.array<8 x vector<1xf64>> 
    %166 = llvm.fmul %165, %138  : vector<1xf64>
    %167 = llvm.insertvalue %166, %164[4] : !llvm.array<8 x vector<1xf64>> 
    %168 = llvm.extractvalue %131[5] : !llvm.array<8 x vector<1xf64>> 
    %169 = llvm.fmul %168, %138  : vector<1xf64>
    %170 = llvm.insertvalue %169, %167[5] : !llvm.array<8 x vector<1xf64>> 
    %171 = llvm.extractvalue %131[6] : !llvm.array<8 x vector<1xf64>> 
    %172 = llvm.fmul %171, %138  : vector<1xf64>
    %173 = llvm.insertvalue %172, %170[6] : !llvm.array<8 x vector<1xf64>> 
    %174 = llvm.extractvalue %131[7] : !llvm.array<8 x vector<1xf64>> 
    %175 = llvm.fmul %174, %138  : vector<1xf64>
    %176 = llvm.insertvalue %175, %173[7] : !llvm.array<8 x vector<1xf64>> 
    %177 = llvm.extractvalue %176[0] : !llvm.array<8 x vector<1xf64>> 
    %178 = llvm.mlir.constant(0 : i64) : i64
    %179 = llvm.extractelement %177[%178 : i64] : vector<1xf64>
    %180 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<8xf64>> 
    %181 = llvm.mlir.constant(0 : i64) : i64
    %182 = llvm.insertelement %179, %180[%181 : i64] : vector<8xf64>
    %183 = llvm.insertvalue %182, %20[0] : !llvm.array<1 x vector<8xf64>> 
    %184 = llvm.extractvalue %176[1] : !llvm.array<8 x vector<1xf64>> 
    %185 = llvm.mlir.constant(0 : i64) : i64
    %186 = llvm.extractelement %184[%185 : i64] : vector<1xf64>
    %187 = llvm.mlir.constant(1 : i64) : i64
    %188 = llvm.insertelement %186, %182[%187 : i64] : vector<8xf64>
    %189 = llvm.insertvalue %188, %183[0] : !llvm.array<1 x vector<8xf64>> 
    %190 = llvm.extractvalue %176[2] : !llvm.array<8 x vector<1xf64>> 
    %191 = llvm.mlir.constant(0 : i64) : i64
    %192 = llvm.extractelement %190[%191 : i64] : vector<1xf64>
    %193 = llvm.mlir.constant(2 : i64) : i64
    %194 = llvm.insertelement %192, %188[%193 : i64] : vector<8xf64>
    %195 = llvm.insertvalue %194, %189[0] : !llvm.array<1 x vector<8xf64>> 
    %196 = llvm.extractvalue %176[3] : !llvm.array<8 x vector<1xf64>> 
    %197 = llvm.mlir.constant(0 : i64) : i64
    %198 = llvm.extractelement %196[%197 : i64] : vector<1xf64>
    %199 = llvm.mlir.constant(3 : i64) : i64
    %200 = llvm.insertelement %198, %194[%199 : i64] : vector<8xf64>
    %201 = llvm.insertvalue %200, %195[0] : !llvm.array<1 x vector<8xf64>> 
    %202 = llvm.extractvalue %176[4] : !llvm.array<8 x vector<1xf64>> 
    %203 = llvm.mlir.constant(0 : i64) : i64
    %204 = llvm.extractelement %202[%203 : i64] : vector<1xf64>
    %205 = llvm.mlir.constant(4 : i64) : i64
    %206 = llvm.insertelement %204, %200[%205 : i64] : vector<8xf64>
    %207 = llvm.insertvalue %206, %201[0] : !llvm.array<1 x vector<8xf64>> 
    %208 = llvm.extractvalue %176[5] : !llvm.array<8 x vector<1xf64>> 
    %209 = llvm.mlir.constant(0 : i64) : i64
    %210 = llvm.extractelement %208[%209 : i64] : vector<1xf64>
    %211 = llvm.mlir.constant(5 : i64) : i64
    %212 = llvm.insertelement %210, %206[%211 : i64] : vector<8xf64>
    %213 = llvm.insertvalue %212, %207[0] : !llvm.array<1 x vector<8xf64>> 
    %214 = llvm.extractvalue %176[6] : !llvm.array<8 x vector<1xf64>> 
    %215 = llvm.mlir.constant(0 : i64) : i64
    %216 = llvm.extractelement %214[%215 : i64] : vector<1xf64>
    %217 = llvm.mlir.constant(6 : i64) : i64
    %218 = llvm.insertelement %216, %212[%217 : i64] : vector<8xf64>
    %219 = llvm.insertvalue %218, %213[0] : !llvm.array<1 x vector<8xf64>> 
    %220 = llvm.extractvalue %176[7] : !llvm.array<8 x vector<1xf64>> 
    %221 = llvm.mlir.constant(0 : i64) : i64
    %222 = llvm.extractelement %220[%221 : i64] : vector<1xf64>
    %223 = llvm.mlir.constant(7 : i64) : i64
    %224 = llvm.insertelement %222, %218[%223 : i64] : vector<8xf64>
    %225 = llvm.insertvalue %224, %219[0] : !llvm.array<1 x vector<8xf64>> 
    %226 = llvm.fadd %224, %151  : vector<8xf64>
    %227 = llvm.extractvalue %65[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %228 = llvm.extractvalue %65[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %229 = llvm.getelementptr %227[%228] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %230 = llvm.getelementptr %229[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %226, %230 {alignment = 8 : i64} : vector<8xf64>, !llvm.ptr
    %231 = llvm.add %66, %25  : i64
    llvm.br ^bb6(%231 : i64)
  ^bb11:  // pred: ^bb6
    %232 = llvm.add %33, %26  : i64
    llvm.br ^bb4(%232 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
