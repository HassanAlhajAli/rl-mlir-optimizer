; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %77
  %17 = phi i64 [ %78, %77 ], [ 0, %.preheader.preheader ]
  %18 = shl nuw nsw i64 %17, 8
  %19 = getelementptr double, ptr %13, i64 %17
  %.promoted = load <16 x double>, ptr %19, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %18
  br label %20

20:                                               ; preds = %.preheader, %20
  %21 = phi i64 [ 0, %.preheader ], [ %76, %20 ]
  %22 = phi <16 x double> [ %.promoted, %.preheader ], [ %75, %20 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %21
  %23 = load double, ptr %gep, align 8
  %24 = getelementptr double, ptr %gep, i64 256
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep, i64 512
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep, i64 768
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep, i64 1024
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep, i64 1280
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep, i64 1536
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep, i64 1792
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep, i64 2048
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep, i64 2304
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %gep, i64 2560
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %gep, i64 2816
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %gep, i64 3072
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %gep, i64 3328
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %gep, i64 3584
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %gep, i64 3840
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %8, i64 %21
  %55 = load double, ptr %54, align 8
  %56 = insertelement <16 x double> poison, double %23, i64 0
  %57 = insertelement <16 x double> %56, double %25, i64 1
  %58 = insertelement <16 x double> %57, double %27, i64 2
  %59 = insertelement <16 x double> %58, double %29, i64 3
  %60 = insertelement <16 x double> %59, double %31, i64 4
  %61 = insertelement <16 x double> %60, double %33, i64 5
  %62 = insertelement <16 x double> %61, double %35, i64 6
  %63 = insertelement <16 x double> %62, double %37, i64 7
  %64 = insertelement <16 x double> %63, double %39, i64 8
  %65 = insertelement <16 x double> %64, double %41, i64 9
  %66 = insertelement <16 x double> %65, double %43, i64 10
  %67 = insertelement <16 x double> %66, double %45, i64 11
  %68 = insertelement <16 x double> %67, double %47, i64 12
  %69 = insertelement <16 x double> %68, double %49, i64 13
  %70 = insertelement <16 x double> %69, double %51, i64 14
  %71 = insertelement <16 x double> %70, double %53, i64 15
  %72 = insertelement <16 x double> poison, double %55, i64 0
  %73 = shufflevector <16 x double> %72, <16 x double> poison, <16 x i32> zeroinitializer
  %74 = fmul <16 x double> %71, %73
  %75 = fadd <16 x double> %22, %74
  store <16 x double> %75, ptr %19, align 8
  %76 = add nuw nsw i64 %21, 1
  %exitcond.not = icmp eq i64 %76, 256
  br i1 %exitcond.not, label %77, label %20

77:                                               ; preds = %20
  %78 = add nuw nsw i64 %17, 16
  %79 = icmp ult i64 %17, 112
  br i1 %79, label %.preheader, label %80

80:                                               ; preds = %77
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28, i8 0, i64 1024, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %64, %3
  %4 = phi i64 [ %65, %64 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 8
  %6 = getelementptr double, ptr %.unpack28, i64 %4
  %.promoted.i = load <16 x double>, ptr %6, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %7

7:                                                ; preds = %7, %.preheader.i
  %8 = phi i64 [ 0, %.preheader.i ], [ %63, %7 ]
  %9 = phi <16 x double> [ %.promoted.i, %.preheader.i ], [ %62, %7 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %8
  %10 = load double, ptr %gep.i, align 8
  %11 = getelementptr double, ptr %gep.i, i64 256
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %gep.i, i64 512
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %gep.i, i64 768
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %gep.i, i64 1024
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i, i64 1280
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i, i64 1536
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i, i64 1792
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %gep.i, i64 2048
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep.i, i64 2304
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep.i, i64 2560
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i, i64 2816
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %gep.i, i64 3072
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %gep.i, i64 3328
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %gep.i, i64 3584
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %gep.i, i64 3840
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %.unpack17, i64 %8
  %42 = load double, ptr %41, align 8
  %43 = insertelement <16 x double> poison, double %10, i64 0
  %44 = insertelement <16 x double> %43, double %12, i64 1
  %45 = insertelement <16 x double> %44, double %14, i64 2
  %46 = insertelement <16 x double> %45, double %16, i64 3
  %47 = insertelement <16 x double> %46, double %18, i64 4
  %48 = insertelement <16 x double> %47, double %20, i64 5
  %49 = insertelement <16 x double> %48, double %22, i64 6
  %50 = insertelement <16 x double> %49, double %24, i64 7
  %51 = insertelement <16 x double> %50, double %26, i64 8
  %52 = insertelement <16 x double> %51, double %28, i64 9
  %53 = insertelement <16 x double> %52, double %30, i64 10
  %54 = insertelement <16 x double> %53, double %32, i64 11
  %55 = insertelement <16 x double> %54, double %34, i64 12
  %56 = insertelement <16 x double> %55, double %36, i64 13
  %57 = insertelement <16 x double> %56, double %38, i64 14
  %58 = insertelement <16 x double> %57, double %40, i64 15
  %59 = insertelement <16 x double> poison, double %42, i64 0
  %60 = shufflevector <16 x double> %59, <16 x double> poison, <16 x i32> zeroinitializer
  %61 = fmul <16 x double> %58, %60
  %62 = fadd <16 x double> %9, %61
  store <16 x double> %62, ptr %6, align 8
  %63 = add nuw nsw i64 %8, 1
  %exitcond.not.i = icmp eq i64 %63, 256
  br i1 %exitcond.not.i, label %64, label %7

64:                                               ; preds = %7
  %65 = add nuw nsw i64 %4, 16
  %66 = icmp ult i64 %4, 112
  br i1 %66, label %.preheader.i, label %kernel.exit

kernel.exit:                                      ; preds = %64
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %10, i8 0, i64 1024, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %71, %1
  %11 = phi i64 [ %72, %71 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 8
  %13 = getelementptr double, ptr %10, i64 %11
  %.promoted.i = load <16 x double>, ptr %13, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %12
  br label %14

14:                                               ; preds = %14, %.preheader.i
  %15 = phi i64 [ 0, %.preheader.i ], [ %70, %14 ]
  %16 = phi <16 x double> [ %.promoted.i, %.preheader.i ], [ %69, %14 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %17 = load double, ptr %gep.i, align 8
  %18 = getelementptr double, ptr %gep.i, i64 256
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 512
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 768
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i, i64 1024
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep.i, i64 1280
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep.i, i64 1536
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep.i, i64 1792
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep.i, i64 2048
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep.i, i64 2304
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep.i, i64 2560
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep.i, i64 2816
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep.i, i64 3072
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %gep.i, i64 3328
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %gep.i, i64 3584
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %gep.i, i64 3840
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %7, i64 %15
  %49 = load double, ptr %48, align 8
  %50 = insertelement <16 x double> poison, double %17, i64 0
  %51 = insertelement <16 x double> %50, double %19, i64 1
  %52 = insertelement <16 x double> %51, double %21, i64 2
  %53 = insertelement <16 x double> %52, double %23, i64 3
  %54 = insertelement <16 x double> %53, double %25, i64 4
  %55 = insertelement <16 x double> %54, double %27, i64 5
  %56 = insertelement <16 x double> %55, double %29, i64 6
  %57 = insertelement <16 x double> %56, double %31, i64 7
  %58 = insertelement <16 x double> %57, double %33, i64 8
  %59 = insertelement <16 x double> %58, double %35, i64 9
  %60 = insertelement <16 x double> %59, double %37, i64 10
  %61 = insertelement <16 x double> %60, double %39, i64 11
  %62 = insertelement <16 x double> %61, double %41, i64 12
  %63 = insertelement <16 x double> %62, double %43, i64 13
  %64 = insertelement <16 x double> %63, double %45, i64 14
  %65 = insertelement <16 x double> %64, double %47, i64 15
  %66 = insertelement <16 x double> poison, double %49, i64 0
  %67 = shufflevector <16 x double> %66, <16 x double> poison, <16 x i32> zeroinitializer
  %68 = fmul <16 x double> %65, %67
  %69 = fadd <16 x double> %16, %68
  store <16 x double> %69, ptr %13, align 8
  %70 = add nuw nsw i64 %15, 1
  %exitcond.not.i = icmp eq i64 %70, 256
  br i1 %exitcond.not.i, label %71, label %14

71:                                               ; preds = %14
  %72 = add nuw nsw i64 %11, 16
  %73 = icmp ult i64 %11, 112
  br i1 %73, label %.preheader.i, label %kernel.exit

kernel.exit:                                      ; preds = %71
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28.i, i8 0, i64 1024, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %70, %1
  %10 = phi i64 [ %71, %70 ], [ 0, %1 ]
  %11 = shl nuw nsw i64 %10, 8
  %12 = getelementptr double, ptr %.unpack28.i, i64 %10
  %.promoted.i.i = load <16 x double>, ptr %12, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %13

13:                                               ; preds = %13, %.preheader.i.i
  %14 = phi i64 [ 0, %.preheader.i.i ], [ %69, %13 ]
  %15 = phi <16 x double> [ %.promoted.i.i, %.preheader.i.i ], [ %68, %13 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %14
  %16 = load double, ptr %gep.i.i, align 8
  %17 = getelementptr double, ptr %gep.i.i, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i.i, i64 512
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i.i, i64 768
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i.i, i64 1024
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %gep.i.i, i64 1280
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep.i.i, i64 1536
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep.i.i, i64 1792
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i.i, i64 2048
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %gep.i.i, i64 2304
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %gep.i.i, i64 2560
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %gep.i.i, i64 2816
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %gep.i.i, i64 3072
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %gep.i.i, i64 3328
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %gep.i.i, i64 3584
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %gep.i.i, i64 3840
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %.unpack17.i, i64 %14
  %48 = load double, ptr %47, align 8
  %49 = insertelement <16 x double> poison, double %16, i64 0
  %50 = insertelement <16 x double> %49, double %18, i64 1
  %51 = insertelement <16 x double> %50, double %20, i64 2
  %52 = insertelement <16 x double> %51, double %22, i64 3
  %53 = insertelement <16 x double> %52, double %24, i64 4
  %54 = insertelement <16 x double> %53, double %26, i64 5
  %55 = insertelement <16 x double> %54, double %28, i64 6
  %56 = insertelement <16 x double> %55, double %30, i64 7
  %57 = insertelement <16 x double> %56, double %32, i64 8
  %58 = insertelement <16 x double> %57, double %34, i64 9
  %59 = insertelement <16 x double> %58, double %36, i64 10
  %60 = insertelement <16 x double> %59, double %38, i64 11
  %61 = insertelement <16 x double> %60, double %40, i64 12
  %62 = insertelement <16 x double> %61, double %42, i64 13
  %63 = insertelement <16 x double> %62, double %44, i64 14
  %64 = insertelement <16 x double> %63, double %46, i64 15
  %65 = insertelement <16 x double> poison, double %48, i64 0
  %66 = shufflevector <16 x double> %65, <16 x double> poison, <16 x i32> zeroinitializer
  %67 = fmul <16 x double> %64, %66
  %68 = fadd <16 x double> %15, %67
  store <16 x double> %68, ptr %12, align 8
  %69 = add nuw nsw i64 %14, 1
  %exitcond.not.i.i = icmp eq i64 %69, 256
  br i1 %exitcond.not.i.i, label %70, label %13

70:                                               ; preds = %13
  %71 = add nuw nsw i64 %10, 16
  %72 = icmp ult i64 %10, 112
  br i1 %72, label %.preheader.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %70
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
