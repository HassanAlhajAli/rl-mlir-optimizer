module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x8xf64>) : !llvm.array<1 x vector<8xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x1xf64>) : !llvm.array<8 x vector<1xf64>>
    %22 = llvm.mlir.constant(256 : index) : i64
    %23 = llvm.mlir.constant(0 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.constant(8 : index) : i64
    %26 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%23 : i64)
  ^bb1(%27: i64):  // 2 preds: ^bb0, ^bb2
    %28 = llvm.icmp "slt" %27, %22 : i64
    llvm.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %30 = llvm.getelementptr %29[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %26, %30 : f64, !llvm.ptr
    %31 = llvm.add %27, %24  : i64
    llvm.br ^bb1(%31 : i64)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%23 : i64)
  ^bb4(%32: i64):  // 2 preds: ^bb3, ^bb11
    %33 = llvm.icmp "slt" %32, %22 : i64
    llvm.cond_br %33, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    %34 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %35 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %36 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %37 = llvm.insertvalue %34, %36[0] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.insertvalue %35, %37[1] : !llvm.struct<(ptr, ptr, i64)> 
    %39 = llvm.mlir.constant(0 : index) : i64
    %40 = llvm.insertvalue %39, %38[2] : !llvm.struct<(ptr, ptr, i64)> 
    %41 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %42 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %45 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %46 = llvm.mul %32, %22  : i64
    %47 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %48 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %49 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %50 = llvm.insertvalue %47, %49[0] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.insertvalue %48, %50[1] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(0 : index) : i64
    %53 = llvm.insertvalue %52, %51[2] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %55 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %58 = llvm.insertvalue %47, %57[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %59 = llvm.insertvalue %48, %58[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %60 = llvm.insertvalue %32, %59[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %61 = llvm.mlir.constant(8 : index) : i64
    %62 = llvm.insertvalue %61, %60[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %63 = llvm.mlir.constant(1 : index) : i64
    %64 = llvm.insertvalue %63, %62[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%23 : i64)
  ^bb6(%65: i64):  // 2 preds: ^bb5, ^bb10
    %66 = llvm.icmp "slt" %65, %22 : i64
    llvm.cond_br %66, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.alloca %67 x !llvm.array<8 x vector<1xf64>> : (i64) -> !llvm.ptr
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %68, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.add %46, %65  : i64
    %75 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %76 = llvm.insertvalue %34, %75[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.insertvalue %35, %76[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.insertvalue %74, %77[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mlir.constant(8 : index) : i64
    %80 = llvm.insertvalue %79, %78[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.mlir.constant(256 : index) : i64
    %82 = llvm.insertvalue %81, %80[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.mlir.constant(1 : index) : i64
    %84 = llvm.insertvalue %83, %82[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.mlir.constant(1 : index) : i64
    %86 = llvm.insertvalue %85, %84[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %90 = llvm.insertvalue %87, %89[0] : !llvm.struct<(ptr, ptr, i64)> 
    %91 = llvm.insertvalue %88, %90[1] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.mlir.constant(0 : index) : i64
    %93 = llvm.insertvalue %92, %91[2] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %98 = llvm.insertvalue %87, %97[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %99 = llvm.insertvalue %88, %98[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %65, %99[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.mlir.constant(1 : index) : i64
    %102 = llvm.insertvalue %101, %100[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.mlir.constant(1 : index) : i64
    %104 = llvm.insertvalue %103, %102[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %105 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %106 = llvm.extractvalue %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %107 = llvm.insertvalue %106, %105[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.extractvalue %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.insertvalue %108, %107[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %110 = llvm.mlir.constant(0 : index) : i64
    %111 = llvm.insertvalue %110, %109[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %112 = llvm.mlir.constant(8 : index) : i64
    %113 = llvm.insertvalue %112, %111[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %114 = llvm.mlir.constant(1 : index) : i64
    %115 = llvm.insertvalue %114, %113[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%23 : i64)
  ^bb8(%116: i64):  // 2 preds: ^bb7, ^bb9
    %117 = llvm.icmp "slt" %116, %25 : i64
    llvm.cond_br %117, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %118 = llvm.getelementptr %35[%74] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %119 = llvm.mlir.constant(256 : index) : i64
    %120 = llvm.mul %116, %119  : i64
    %121 = llvm.add %120, %23  : i64
    %122 = llvm.getelementptr %118[%121] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %123 = llvm.load %122 : !llvm.ptr -> f64
    %124 = llvm.mlir.undef : vector<1xf64>
    %125 = llvm.mlir.constant(0 : i32) : i32
    %126 = llvm.insertelement %123, %124[%125 : i32] : vector<1xf64>
    %127 = llvm.shufflevector %126, %124 [0] : vector<1xf64> 
    %128 = llvm.getelementptr %108[%116] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %127, %128 : vector<1xf64>, !llvm.ptr
    %129 = llvm.add %116, %24  : i64
    llvm.br ^bb8(%129 : i64)
  ^bb10:  // pred: ^bb8
    %130 = llvm.load %68 : !llvm.ptr -> !llvm.array<8 x vector<1xf64>>
    %131 = llvm.getelementptr %88[%65] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %132 = llvm.getelementptr %131[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %133 = llvm.load %132 : !llvm.ptr -> f64
    %134 = llvm.mlir.undef : vector<1xf64>
    %135 = llvm.mlir.constant(0 : i32) : i32
    %136 = llvm.insertelement %133, %134[%135 : i32] : vector<1xf64>
    %137 = llvm.shufflevector %136, %134 [0] : vector<1xf64> 
    %138 = llvm.insertvalue %137, %21[0] : !llvm.array<8 x vector<1xf64>> 
    %139 = llvm.insertvalue %137, %138[1] : !llvm.array<8 x vector<1xf64>> 
    %140 = llvm.insertvalue %137, %139[2] : !llvm.array<8 x vector<1xf64>> 
    %141 = llvm.insertvalue %137, %140[3] : !llvm.array<8 x vector<1xf64>> 
    %142 = llvm.insertvalue %137, %141[4] : !llvm.array<8 x vector<1xf64>> 
    %143 = llvm.insertvalue %137, %142[5] : !llvm.array<8 x vector<1xf64>> 
    %144 = llvm.insertvalue %137, %143[6] : !llvm.array<8 x vector<1xf64>> 
    %145 = llvm.insertvalue %137, %144[7] : !llvm.array<8 x vector<1xf64>> 
    %146 = llvm.extractvalue %64[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %147 = llvm.extractvalue %64[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = llvm.getelementptr %146[%147] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %149 = llvm.getelementptr %148[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %150 = llvm.load %149 {alignment = 8 : i64} : !llvm.ptr -> vector<8xf64>
    %151 = llvm.mlir.undef : !llvm.array<8 x vector<1xf64>>
    %152 = llvm.extractvalue %130[0] : !llvm.array<8 x vector<1xf64>> 
    %153 = llvm.fmul %152, %137  : vector<1xf64>
    %154 = llvm.insertvalue %153, %151[0] : !llvm.array<8 x vector<1xf64>> 
    %155 = llvm.extractvalue %130[1] : !llvm.array<8 x vector<1xf64>> 
    %156 = llvm.fmul %155, %137  : vector<1xf64>
    %157 = llvm.insertvalue %156, %154[1] : !llvm.array<8 x vector<1xf64>> 
    %158 = llvm.extractvalue %130[2] : !llvm.array<8 x vector<1xf64>> 
    %159 = llvm.fmul %158, %137  : vector<1xf64>
    %160 = llvm.insertvalue %159, %157[2] : !llvm.array<8 x vector<1xf64>> 
    %161 = llvm.extractvalue %130[3] : !llvm.array<8 x vector<1xf64>> 
    %162 = llvm.fmul %161, %137  : vector<1xf64>
    %163 = llvm.insertvalue %162, %160[3] : !llvm.array<8 x vector<1xf64>> 
    %164 = llvm.extractvalue %130[4] : !llvm.array<8 x vector<1xf64>> 
    %165 = llvm.fmul %164, %137  : vector<1xf64>
    %166 = llvm.insertvalue %165, %163[4] : !llvm.array<8 x vector<1xf64>> 
    %167 = llvm.extractvalue %130[5] : !llvm.array<8 x vector<1xf64>> 
    %168 = llvm.fmul %167, %137  : vector<1xf64>
    %169 = llvm.insertvalue %168, %166[5] : !llvm.array<8 x vector<1xf64>> 
    %170 = llvm.extractvalue %130[6] : !llvm.array<8 x vector<1xf64>> 
    %171 = llvm.fmul %170, %137  : vector<1xf64>
    %172 = llvm.insertvalue %171, %169[6] : !llvm.array<8 x vector<1xf64>> 
    %173 = llvm.extractvalue %130[7] : !llvm.array<8 x vector<1xf64>> 
    %174 = llvm.fmul %173, %137  : vector<1xf64>
    %175 = llvm.insertvalue %174, %172[7] : !llvm.array<8 x vector<1xf64>> 
    %176 = llvm.extractvalue %175[0] : !llvm.array<8 x vector<1xf64>> 
    %177 = llvm.mlir.constant(0 : i64) : i64
    %178 = llvm.extractelement %176[%177 : i64] : vector<1xf64>
    %179 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<8xf64>> 
    %180 = llvm.mlir.constant(0 : i64) : i64
    %181 = llvm.insertelement %178, %179[%180 : i64] : vector<8xf64>
    %182 = llvm.insertvalue %181, %20[0] : !llvm.array<1 x vector<8xf64>> 
    %183 = llvm.extractvalue %175[1] : !llvm.array<8 x vector<1xf64>> 
    %184 = llvm.mlir.constant(0 : i64) : i64
    %185 = llvm.extractelement %183[%184 : i64] : vector<1xf64>
    %186 = llvm.mlir.constant(1 : i64) : i64
    %187 = llvm.insertelement %185, %181[%186 : i64] : vector<8xf64>
    %188 = llvm.insertvalue %187, %182[0] : !llvm.array<1 x vector<8xf64>> 
    %189 = llvm.extractvalue %175[2] : !llvm.array<8 x vector<1xf64>> 
    %190 = llvm.mlir.constant(0 : i64) : i64
    %191 = llvm.extractelement %189[%190 : i64] : vector<1xf64>
    %192 = llvm.mlir.constant(2 : i64) : i64
    %193 = llvm.insertelement %191, %187[%192 : i64] : vector<8xf64>
    %194 = llvm.insertvalue %193, %188[0] : !llvm.array<1 x vector<8xf64>> 
    %195 = llvm.extractvalue %175[3] : !llvm.array<8 x vector<1xf64>> 
    %196 = llvm.mlir.constant(0 : i64) : i64
    %197 = llvm.extractelement %195[%196 : i64] : vector<1xf64>
    %198 = llvm.mlir.constant(3 : i64) : i64
    %199 = llvm.insertelement %197, %193[%198 : i64] : vector<8xf64>
    %200 = llvm.insertvalue %199, %194[0] : !llvm.array<1 x vector<8xf64>> 
    %201 = llvm.extractvalue %175[4] : !llvm.array<8 x vector<1xf64>> 
    %202 = llvm.mlir.constant(0 : i64) : i64
    %203 = llvm.extractelement %201[%202 : i64] : vector<1xf64>
    %204 = llvm.mlir.constant(4 : i64) : i64
    %205 = llvm.insertelement %203, %199[%204 : i64] : vector<8xf64>
    %206 = llvm.insertvalue %205, %200[0] : !llvm.array<1 x vector<8xf64>> 
    %207 = llvm.extractvalue %175[5] : !llvm.array<8 x vector<1xf64>> 
    %208 = llvm.mlir.constant(0 : i64) : i64
    %209 = llvm.extractelement %207[%208 : i64] : vector<1xf64>
    %210 = llvm.mlir.constant(5 : i64) : i64
    %211 = llvm.insertelement %209, %205[%210 : i64] : vector<8xf64>
    %212 = llvm.insertvalue %211, %206[0] : !llvm.array<1 x vector<8xf64>> 
    %213 = llvm.extractvalue %175[6] : !llvm.array<8 x vector<1xf64>> 
    %214 = llvm.mlir.constant(0 : i64) : i64
    %215 = llvm.extractelement %213[%214 : i64] : vector<1xf64>
    %216 = llvm.mlir.constant(6 : i64) : i64
    %217 = llvm.insertelement %215, %211[%216 : i64] : vector<8xf64>
    %218 = llvm.insertvalue %217, %212[0] : !llvm.array<1 x vector<8xf64>> 
    %219 = llvm.extractvalue %175[7] : !llvm.array<8 x vector<1xf64>> 
    %220 = llvm.mlir.constant(0 : i64) : i64
    %221 = llvm.extractelement %219[%220 : i64] : vector<1xf64>
    %222 = llvm.mlir.constant(7 : i64) : i64
    %223 = llvm.insertelement %221, %217[%222 : i64] : vector<8xf64>
    %224 = llvm.insertvalue %223, %218[0] : !llvm.array<1 x vector<8xf64>> 
    %225 = llvm.fadd %223, %150  : vector<8xf64>
    %226 = llvm.extractvalue %64[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %227 = llvm.extractvalue %64[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %228 = llvm.getelementptr %226[%227] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %229 = llvm.getelementptr %228[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %225, %229 {alignment = 8 : i64} : vector<8xf64>, !llvm.ptr
    %230 = llvm.add %65, %24  : i64
    llvm.br ^bb6(%230 : i64)
  ^bb11:  // pred: ^bb6
    %231 = llvm.add %32, %25  : i64
    llvm.br ^bb4(%231 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
