module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x16xf64>) : !llvm.array<1 x vector<16xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<16x1xf64>) : !llvm.array<16 x vector<1xf64>>
    %22 = llvm.mlir.constant(256 : index) : i64
    %23 = llvm.mlir.constant(0 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.constant(16 : index) : i64
    %26 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%23 : i64)
  ^bb1(%27: i64):  // 2 preds: ^bb0, ^bb2
    %28 = llvm.icmp "slt" %27, %22 : i64
    llvm.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %30 = llvm.getelementptr %29[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %26, %30 : f64, !llvm.ptr
    %31 = llvm.add %27, %24  : i64
    llvm.br ^bb1(%31 : i64)
  ^bb3:  // pred: ^bb1
    llvm.br ^bb4(%23 : i64)
  ^bb4(%32: i64):  // 2 preds: ^bb3, ^bb11
    %33 = llvm.icmp "slt" %32, %22 : i64
    llvm.cond_br %33, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    %34 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %35 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %36 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %37 = llvm.insertvalue %34, %36[0] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.insertvalue %35, %37[1] : !llvm.struct<(ptr, ptr, i64)> 
    %39 = llvm.mlir.constant(0 : index) : i64
    %40 = llvm.insertvalue %39, %38[2] : !llvm.struct<(ptr, ptr, i64)> 
    %41 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %42 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %45 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %46 = llvm.mul %32, %22  : i64
    %47 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %48 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %49 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %50 = llvm.insertvalue %47, %49[0] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.insertvalue %48, %50[1] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(0 : index) : i64
    %53 = llvm.insertvalue %52, %51[2] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %55 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %58 = llvm.insertvalue %47, %57[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %59 = llvm.insertvalue %48, %58[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %60 = llvm.insertvalue %32, %59[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %61 = llvm.mlir.constant(16 : index) : i64
    %62 = llvm.insertvalue %61, %60[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %63 = llvm.mlir.constant(1 : index) : i64
    %64 = llvm.insertvalue %63, %62[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%23 : i64)
  ^bb6(%65: i64):  // 2 preds: ^bb5, ^bb10
    %66 = llvm.icmp "slt" %65, %22 : i64
    llvm.cond_br %66, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.alloca %67 x !llvm.array<16 x vector<1xf64>> : (i64) -> !llvm.ptr
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %68, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.add %46, %65  : i64
    %75 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %76 = llvm.insertvalue %34, %75[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.insertvalue %35, %76[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.insertvalue %74, %77[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mlir.constant(16 : index) : i64
    %80 = llvm.insertvalue %79, %78[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.mlir.constant(256 : index) : i64
    %82 = llvm.insertvalue %81, %80[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.mlir.constant(1 : index) : i64
    %84 = llvm.insertvalue %83, %82[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.mlir.constant(1 : index) : i64
    %86 = llvm.insertvalue %85, %84[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %90 = llvm.insertvalue %87, %89[0] : !llvm.struct<(ptr, ptr, i64)> 
    %91 = llvm.insertvalue %88, %90[1] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.mlir.constant(0 : index) : i64
    %93 = llvm.insertvalue %92, %91[2] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %98 = llvm.insertvalue %87, %97[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %99 = llvm.insertvalue %88, %98[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %65, %99[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.mlir.constant(1 : index) : i64
    %102 = llvm.insertvalue %101, %100[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.mlir.constant(1 : index) : i64
    %104 = llvm.insertvalue %103, %102[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %105 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %106 = llvm.extractvalue %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %107 = llvm.insertvalue %106, %105[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.extractvalue %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.insertvalue %108, %107[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %110 = llvm.mlir.constant(0 : index) : i64
    %111 = llvm.insertvalue %110, %109[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %112 = llvm.mlir.constant(16 : index) : i64
    %113 = llvm.insertvalue %112, %111[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %114 = llvm.mlir.constant(1 : index) : i64
    %115 = llvm.insertvalue %114, %113[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%23 : i64)
  ^bb8(%116: i64):  // 2 preds: ^bb7, ^bb9
    %117 = llvm.icmp "slt" %116, %25 : i64
    llvm.cond_br %117, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %118 = llvm.getelementptr %35[%74] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %119 = llvm.mlir.constant(256 : index) : i64
    %120 = llvm.mul %116, %119  : i64
    %121 = llvm.add %120, %23  : i64
    %122 = llvm.getelementptr %118[%121] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %123 = llvm.load %122 : !llvm.ptr -> f64
    %124 = llvm.mlir.undef : vector<1xf64>
    %125 = llvm.mlir.constant(0 : i32) : i32
    %126 = llvm.insertelement %123, %124[%125 : i32] : vector<1xf64>
    %127 = llvm.shufflevector %126, %124 [0] : vector<1xf64> 
    %128 = llvm.getelementptr %108[%116] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %127, %128 : vector<1xf64>, !llvm.ptr
    %129 = llvm.add %116, %24  : i64
    llvm.br ^bb8(%129 : i64)
  ^bb10:  // pred: ^bb8
    %130 = llvm.load %68 : !llvm.ptr -> !llvm.array<16 x vector<1xf64>>
    %131 = llvm.getelementptr %88[%65] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %132 = llvm.getelementptr %131[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %133 = llvm.load %132 : !llvm.ptr -> f64
    %134 = llvm.mlir.undef : vector<1xf64>
    %135 = llvm.mlir.constant(0 : i32) : i32
    %136 = llvm.insertelement %133, %134[%135 : i32] : vector<1xf64>
    %137 = llvm.shufflevector %136, %134 [0] : vector<1xf64> 
    %138 = llvm.insertvalue %137, %21[0] : !llvm.array<16 x vector<1xf64>> 
    %139 = llvm.insertvalue %137, %138[1] : !llvm.array<16 x vector<1xf64>> 
    %140 = llvm.insertvalue %137, %139[2] : !llvm.array<16 x vector<1xf64>> 
    %141 = llvm.insertvalue %137, %140[3] : !llvm.array<16 x vector<1xf64>> 
    %142 = llvm.insertvalue %137, %141[4] : !llvm.array<16 x vector<1xf64>> 
    %143 = llvm.insertvalue %137, %142[5] : !llvm.array<16 x vector<1xf64>> 
    %144 = llvm.insertvalue %137, %143[6] : !llvm.array<16 x vector<1xf64>> 
    %145 = llvm.insertvalue %137, %144[7] : !llvm.array<16 x vector<1xf64>> 
    %146 = llvm.insertvalue %137, %145[8] : !llvm.array<16 x vector<1xf64>> 
    %147 = llvm.insertvalue %137, %146[9] : !llvm.array<16 x vector<1xf64>> 
    %148 = llvm.insertvalue %137, %147[10] : !llvm.array<16 x vector<1xf64>> 
    %149 = llvm.insertvalue %137, %148[11] : !llvm.array<16 x vector<1xf64>> 
    %150 = llvm.insertvalue %137, %149[12] : !llvm.array<16 x vector<1xf64>> 
    %151 = llvm.insertvalue %137, %150[13] : !llvm.array<16 x vector<1xf64>> 
    %152 = llvm.insertvalue %137, %151[14] : !llvm.array<16 x vector<1xf64>> 
    %153 = llvm.insertvalue %137, %152[15] : !llvm.array<16 x vector<1xf64>> 
    %154 = llvm.extractvalue %64[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %155 = llvm.extractvalue %64[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.getelementptr %154[%155] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %157 = llvm.getelementptr %156[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %158 = llvm.load %157 {alignment = 8 : i64} : !llvm.ptr -> vector<16xf64>
    %159 = llvm.mlir.undef : !llvm.array<16 x vector<1xf64>>
    %160 = llvm.extractvalue %130[0] : !llvm.array<16 x vector<1xf64>> 
    %161 = llvm.fmul %160, %137  : vector<1xf64>
    %162 = llvm.insertvalue %161, %159[0] : !llvm.array<16 x vector<1xf64>> 
    %163 = llvm.extractvalue %130[1] : !llvm.array<16 x vector<1xf64>> 
    %164 = llvm.fmul %163, %137  : vector<1xf64>
    %165 = llvm.insertvalue %164, %162[1] : !llvm.array<16 x vector<1xf64>> 
    %166 = llvm.extractvalue %130[2] : !llvm.array<16 x vector<1xf64>> 
    %167 = llvm.fmul %166, %137  : vector<1xf64>
    %168 = llvm.insertvalue %167, %165[2] : !llvm.array<16 x vector<1xf64>> 
    %169 = llvm.extractvalue %130[3] : !llvm.array<16 x vector<1xf64>> 
    %170 = llvm.fmul %169, %137  : vector<1xf64>
    %171 = llvm.insertvalue %170, %168[3] : !llvm.array<16 x vector<1xf64>> 
    %172 = llvm.extractvalue %130[4] : !llvm.array<16 x vector<1xf64>> 
    %173 = llvm.fmul %172, %137  : vector<1xf64>
    %174 = llvm.insertvalue %173, %171[4] : !llvm.array<16 x vector<1xf64>> 
    %175 = llvm.extractvalue %130[5] : !llvm.array<16 x vector<1xf64>> 
    %176 = llvm.fmul %175, %137  : vector<1xf64>
    %177 = llvm.insertvalue %176, %174[5] : !llvm.array<16 x vector<1xf64>> 
    %178 = llvm.extractvalue %130[6] : !llvm.array<16 x vector<1xf64>> 
    %179 = llvm.fmul %178, %137  : vector<1xf64>
    %180 = llvm.insertvalue %179, %177[6] : !llvm.array<16 x vector<1xf64>> 
    %181 = llvm.extractvalue %130[7] : !llvm.array<16 x vector<1xf64>> 
    %182 = llvm.fmul %181, %137  : vector<1xf64>
    %183 = llvm.insertvalue %182, %180[7] : !llvm.array<16 x vector<1xf64>> 
    %184 = llvm.extractvalue %130[8] : !llvm.array<16 x vector<1xf64>> 
    %185 = llvm.fmul %184, %137  : vector<1xf64>
    %186 = llvm.insertvalue %185, %183[8] : !llvm.array<16 x vector<1xf64>> 
    %187 = llvm.extractvalue %130[9] : !llvm.array<16 x vector<1xf64>> 
    %188 = llvm.fmul %187, %137  : vector<1xf64>
    %189 = llvm.insertvalue %188, %186[9] : !llvm.array<16 x vector<1xf64>> 
    %190 = llvm.extractvalue %130[10] : !llvm.array<16 x vector<1xf64>> 
    %191 = llvm.fmul %190, %137  : vector<1xf64>
    %192 = llvm.insertvalue %191, %189[10] : !llvm.array<16 x vector<1xf64>> 
    %193 = llvm.extractvalue %130[11] : !llvm.array<16 x vector<1xf64>> 
    %194 = llvm.fmul %193, %137  : vector<1xf64>
    %195 = llvm.insertvalue %194, %192[11] : !llvm.array<16 x vector<1xf64>> 
    %196 = llvm.extractvalue %130[12] : !llvm.array<16 x vector<1xf64>> 
    %197 = llvm.fmul %196, %137  : vector<1xf64>
    %198 = llvm.insertvalue %197, %195[12] : !llvm.array<16 x vector<1xf64>> 
    %199 = llvm.extractvalue %130[13] : !llvm.array<16 x vector<1xf64>> 
    %200 = llvm.fmul %199, %137  : vector<1xf64>
    %201 = llvm.insertvalue %200, %198[13] : !llvm.array<16 x vector<1xf64>> 
    %202 = llvm.extractvalue %130[14] : !llvm.array<16 x vector<1xf64>> 
    %203 = llvm.fmul %202, %137  : vector<1xf64>
    %204 = llvm.insertvalue %203, %201[14] : !llvm.array<16 x vector<1xf64>> 
    %205 = llvm.extractvalue %130[15] : !llvm.array<16 x vector<1xf64>> 
    %206 = llvm.fmul %205, %137  : vector<1xf64>
    %207 = llvm.insertvalue %206, %204[15] : !llvm.array<16 x vector<1xf64>> 
    %208 = llvm.extractvalue %207[0] : !llvm.array<16 x vector<1xf64>> 
    %209 = llvm.mlir.constant(0 : i64) : i64
    %210 = llvm.extractelement %208[%209 : i64] : vector<1xf64>
    %211 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<16xf64>> 
    %212 = llvm.mlir.constant(0 : i64) : i64
    %213 = llvm.insertelement %210, %211[%212 : i64] : vector<16xf64>
    %214 = llvm.insertvalue %213, %20[0] : !llvm.array<1 x vector<16xf64>> 
    %215 = llvm.extractvalue %207[1] : !llvm.array<16 x vector<1xf64>> 
    %216 = llvm.mlir.constant(0 : i64) : i64
    %217 = llvm.extractelement %215[%216 : i64] : vector<1xf64>
    %218 = llvm.mlir.constant(1 : i64) : i64
    %219 = llvm.insertelement %217, %213[%218 : i64] : vector<16xf64>
    %220 = llvm.insertvalue %219, %214[0] : !llvm.array<1 x vector<16xf64>> 
    %221 = llvm.extractvalue %207[2] : !llvm.array<16 x vector<1xf64>> 
    %222 = llvm.mlir.constant(0 : i64) : i64
    %223 = llvm.extractelement %221[%222 : i64] : vector<1xf64>
    %224 = llvm.mlir.constant(2 : i64) : i64
    %225 = llvm.insertelement %223, %219[%224 : i64] : vector<16xf64>
    %226 = llvm.insertvalue %225, %220[0] : !llvm.array<1 x vector<16xf64>> 
    %227 = llvm.extractvalue %207[3] : !llvm.array<16 x vector<1xf64>> 
    %228 = llvm.mlir.constant(0 : i64) : i64
    %229 = llvm.extractelement %227[%228 : i64] : vector<1xf64>
    %230 = llvm.mlir.constant(3 : i64) : i64
    %231 = llvm.insertelement %229, %225[%230 : i64] : vector<16xf64>
    %232 = llvm.insertvalue %231, %226[0] : !llvm.array<1 x vector<16xf64>> 
    %233 = llvm.extractvalue %207[4] : !llvm.array<16 x vector<1xf64>> 
    %234 = llvm.mlir.constant(0 : i64) : i64
    %235 = llvm.extractelement %233[%234 : i64] : vector<1xf64>
    %236 = llvm.mlir.constant(4 : i64) : i64
    %237 = llvm.insertelement %235, %231[%236 : i64] : vector<16xf64>
    %238 = llvm.insertvalue %237, %232[0] : !llvm.array<1 x vector<16xf64>> 
    %239 = llvm.extractvalue %207[5] : !llvm.array<16 x vector<1xf64>> 
    %240 = llvm.mlir.constant(0 : i64) : i64
    %241 = llvm.extractelement %239[%240 : i64] : vector<1xf64>
    %242 = llvm.mlir.constant(5 : i64) : i64
    %243 = llvm.insertelement %241, %237[%242 : i64] : vector<16xf64>
    %244 = llvm.insertvalue %243, %238[0] : !llvm.array<1 x vector<16xf64>> 
    %245 = llvm.extractvalue %207[6] : !llvm.array<16 x vector<1xf64>> 
    %246 = llvm.mlir.constant(0 : i64) : i64
    %247 = llvm.extractelement %245[%246 : i64] : vector<1xf64>
    %248 = llvm.mlir.constant(6 : i64) : i64
    %249 = llvm.insertelement %247, %243[%248 : i64] : vector<16xf64>
    %250 = llvm.insertvalue %249, %244[0] : !llvm.array<1 x vector<16xf64>> 
    %251 = llvm.extractvalue %207[7] : !llvm.array<16 x vector<1xf64>> 
    %252 = llvm.mlir.constant(0 : i64) : i64
    %253 = llvm.extractelement %251[%252 : i64] : vector<1xf64>
    %254 = llvm.mlir.constant(7 : i64) : i64
    %255 = llvm.insertelement %253, %249[%254 : i64] : vector<16xf64>
    %256 = llvm.insertvalue %255, %250[0] : !llvm.array<1 x vector<16xf64>> 
    %257 = llvm.extractvalue %207[8] : !llvm.array<16 x vector<1xf64>> 
    %258 = llvm.mlir.constant(0 : i64) : i64
    %259 = llvm.extractelement %257[%258 : i64] : vector<1xf64>
    %260 = llvm.mlir.constant(8 : i64) : i64
    %261 = llvm.insertelement %259, %255[%260 : i64] : vector<16xf64>
    %262 = llvm.insertvalue %261, %256[0] : !llvm.array<1 x vector<16xf64>> 
    %263 = llvm.extractvalue %207[9] : !llvm.array<16 x vector<1xf64>> 
    %264 = llvm.mlir.constant(0 : i64) : i64
    %265 = llvm.extractelement %263[%264 : i64] : vector<1xf64>
    %266 = llvm.mlir.constant(9 : i64) : i64
    %267 = llvm.insertelement %265, %261[%266 : i64] : vector<16xf64>
    %268 = llvm.insertvalue %267, %262[0] : !llvm.array<1 x vector<16xf64>> 
    %269 = llvm.extractvalue %207[10] : !llvm.array<16 x vector<1xf64>> 
    %270 = llvm.mlir.constant(0 : i64) : i64
    %271 = llvm.extractelement %269[%270 : i64] : vector<1xf64>
    %272 = llvm.mlir.constant(10 : i64) : i64
    %273 = llvm.insertelement %271, %267[%272 : i64] : vector<16xf64>
    %274 = llvm.insertvalue %273, %268[0] : !llvm.array<1 x vector<16xf64>> 
    %275 = llvm.extractvalue %207[11] : !llvm.array<16 x vector<1xf64>> 
    %276 = llvm.mlir.constant(0 : i64) : i64
    %277 = llvm.extractelement %275[%276 : i64] : vector<1xf64>
    %278 = llvm.mlir.constant(11 : i64) : i64
    %279 = llvm.insertelement %277, %273[%278 : i64] : vector<16xf64>
    %280 = llvm.insertvalue %279, %274[0] : !llvm.array<1 x vector<16xf64>> 
    %281 = llvm.extractvalue %207[12] : !llvm.array<16 x vector<1xf64>> 
    %282 = llvm.mlir.constant(0 : i64) : i64
    %283 = llvm.extractelement %281[%282 : i64] : vector<1xf64>
    %284 = llvm.mlir.constant(12 : i64) : i64
    %285 = llvm.insertelement %283, %279[%284 : i64] : vector<16xf64>
    %286 = llvm.insertvalue %285, %280[0] : !llvm.array<1 x vector<16xf64>> 
    %287 = llvm.extractvalue %207[13] : !llvm.array<16 x vector<1xf64>> 
    %288 = llvm.mlir.constant(0 : i64) : i64
    %289 = llvm.extractelement %287[%288 : i64] : vector<1xf64>
    %290 = llvm.mlir.constant(13 : i64) : i64
    %291 = llvm.insertelement %289, %285[%290 : i64] : vector<16xf64>
    %292 = llvm.insertvalue %291, %286[0] : !llvm.array<1 x vector<16xf64>> 
    %293 = llvm.extractvalue %207[14] : !llvm.array<16 x vector<1xf64>> 
    %294 = llvm.mlir.constant(0 : i64) : i64
    %295 = llvm.extractelement %293[%294 : i64] : vector<1xf64>
    %296 = llvm.mlir.constant(14 : i64) : i64
    %297 = llvm.insertelement %295, %291[%296 : i64] : vector<16xf64>
    %298 = llvm.insertvalue %297, %292[0] : !llvm.array<1 x vector<16xf64>> 
    %299 = llvm.extractvalue %207[15] : !llvm.array<16 x vector<1xf64>> 
    %300 = llvm.mlir.constant(0 : i64) : i64
    %301 = llvm.extractelement %299[%300 : i64] : vector<1xf64>
    %302 = llvm.mlir.constant(15 : i64) : i64
    %303 = llvm.insertelement %301, %297[%302 : i64] : vector<16xf64>
    %304 = llvm.insertvalue %303, %298[0] : !llvm.array<1 x vector<16xf64>> 
    %305 = llvm.fadd %303, %158  : vector<16xf64>
    %306 = llvm.extractvalue %64[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %307 = llvm.extractvalue %64[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.getelementptr %306[%307] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %309 = llvm.getelementptr %308[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %305, %309 {alignment = 8 : i64} : vector<16xf64>, !llvm.ptr
    %310 = llvm.add %65, %24  : i64
    llvm.br ^bb6(%310 : i64)
  ^bb11:  // pred: ^bb6
    %311 = llvm.add %32, %25  : i64
    llvm.br ^bb4(%311 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
