; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  %.promoted = load <8 x double>, ptr %13, align 8
  br label %17

17:                                               ; preds = %.preheader.preheader, %17
  %18 = phi <8 x double> [ %.promoted, %.preheader.preheader ], [ %45, %17 ]
  %19 = phi i64 [ 0, %.preheader.preheader ], [ %46, %17 ]
  %20 = getelementptr double, ptr %1, i64 %19
  %unmaskedload = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %20, i64 65
  %unmaskedload32 = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %20, i64 130
  %unmaskedload33 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %20, i64 195
  %unmaskedload34 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %20, i64 260
  %unmaskedload35 = load <1 x double>, ptr %24, align 8
  %25 = getelementptr double, ptr %20, i64 325
  %unmaskedload36 = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %20, i64 390
  %unmaskedload37 = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %20, i64 455
  %unmaskedload38 = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %8, i64 %19
  %29 = load double, ptr %28, align 8
  %30 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload32, <2 x i32> <i32 0, i32 1>
  %31 = insertelement <2 x double> poison, double %29, i64 0
  %32 = shufflevector <2 x double> %31, <2 x double> poison, <2 x i32> zeroinitializer
  %33 = fmul <2 x double> %30, %32
  %34 = shufflevector <1 x double> %unmaskedload33, <1 x double> %unmaskedload34, <2 x i32> <i32 0, i32 1>
  %35 = fmul <2 x double> %34, %32
  %36 = shufflevector <2 x double> %33, <2 x double> %35, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %37 = shufflevector <1 x double> %unmaskedload35, <1 x double> %unmaskedload36, <2 x i32> <i32 0, i32 1>
  %38 = fmul <2 x double> %37, %32
  %39 = shufflevector <2 x double> %38, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %40 = shufflevector <8 x double> %36, <8 x double> %39, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %41 = shufflevector <1 x double> %unmaskedload37, <1 x double> %unmaskedload38, <2 x i32> <i32 0, i32 1>
  %42 = fmul <2 x double> %41, %32
  %43 = shufflevector <2 x double> %42, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <8 x double> %40, <8 x double> %43, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %45 = fadd <8 x double> %18, %44
  store <8 x double> %45, ptr %13, align 8
  %46 = add nuw nsw i64 %19, 1
  %exitcond.not = icmp eq i64 %46, 65
  br i1 %exitcond.not, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %47 = getelementptr double, ptr %1, i64 520
  %48 = getelementptr double, ptr %13, i64 8
  %.promoted44 = load <8 x double>, ptr %48, align 8
  br label %49

49:                                               ; preds = %49, %.preheader.1
  %50 = phi <8 x double> [ %.promoted44, %.preheader.1 ], [ %77, %49 ]
  %51 = phi i64 [ 0, %.preheader.1 ], [ %78, %49 ]
  %52 = getelementptr double, ptr %47, i64 %51
  %unmaskedload.1 = load <1 x double>, ptr %52, align 8
  %53 = getelementptr double, ptr %52, i64 65
  %unmaskedload32.1 = load <1 x double>, ptr %53, align 8
  %54 = getelementptr double, ptr %52, i64 130
  %unmaskedload33.1 = load <1 x double>, ptr %54, align 8
  %55 = getelementptr double, ptr %52, i64 195
  %unmaskedload34.1 = load <1 x double>, ptr %55, align 8
  %56 = getelementptr double, ptr %52, i64 260
  %unmaskedload35.1 = load <1 x double>, ptr %56, align 8
  %57 = getelementptr double, ptr %52, i64 325
  %unmaskedload36.1 = load <1 x double>, ptr %57, align 8
  %58 = getelementptr double, ptr %52, i64 390
  %unmaskedload37.1 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %52, i64 455
  %unmaskedload40 = load <1 x double>, ptr %59, align 8
  %60 = getelementptr double, ptr %8, i64 %51
  %61 = load double, ptr %60, align 8
  %62 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload32.1, <2 x i32> <i32 0, i32 1>
  %63 = insertelement <2 x double> poison, double %61, i64 0
  %64 = shufflevector <2 x double> %63, <2 x double> poison, <2 x i32> zeroinitializer
  %65 = fmul <2 x double> %62, %64
  %66 = shufflevector <1 x double> %unmaskedload33.1, <1 x double> %unmaskedload34.1, <2 x i32> <i32 0, i32 1>
  %67 = fmul <2 x double> %66, %64
  %68 = shufflevector <2 x double> %65, <2 x double> %67, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %unmaskedload35.1, <1 x double> %unmaskedload36.1, <2 x i32> <i32 0, i32 1>
  %70 = fmul <2 x double> %69, %64
  %71 = shufflevector <2 x double> %70, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %72 = shufflevector <8 x double> %68, <8 x double> %71, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %73 = shufflevector <1 x double> %unmaskedload37.1, <1 x double> %unmaskedload40, <2 x i32> <i32 0, i32 1>
  %74 = fmul <2 x double> %73, %64
  %75 = shufflevector <2 x double> %74, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %76 = shufflevector <8 x double> %72, <8 x double> %75, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %77 = fadd <8 x double> %50, %76
  store <8 x double> %77, ptr %48, align 8
  %78 = add nuw nsw i64 %51, 1
  %exitcond.not.1 = icmp eq i64 %78, 65
  br i1 %exitcond.not.1, label %.preheader.2, label %49

.preheader.2:                                     ; preds = %49
  %79 = getelementptr double, ptr %1, i64 1040
  %80 = getelementptr double, ptr %13, i64 16
  %.promoted45 = load <8 x double>, ptr %80, align 8
  br label %81

81:                                               ; preds = %81, %.preheader.2
  %82 = phi <8 x double> [ %.promoted45, %.preheader.2 ], [ %109, %81 ]
  %83 = phi i64 [ 0, %.preheader.2 ], [ %110, %81 ]
  %84 = getelementptr double, ptr %79, i64 %83
  %unmaskedload.2 = load <1 x double>, ptr %84, align 8
  %85 = getelementptr double, ptr %84, i64 65
  %unmaskedload32.2 = load <1 x double>, ptr %85, align 8
  %86 = getelementptr double, ptr %84, i64 130
  %unmaskedload33.2 = load <1 x double>, ptr %86, align 8
  %87 = getelementptr double, ptr %84, i64 195
  %unmaskedload34.2 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %84, i64 260
  %unmaskedload35.2 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %84, i64 325
  %unmaskedload36.2 = load <1 x double>, ptr %89, align 8
  %90 = getelementptr double, ptr %84, i64 390
  %unmaskedload37.2 = load <1 x double>, ptr %90, align 8
  %91 = getelementptr double, ptr %84, i64 455
  %unmaskedload42 = load <1 x double>, ptr %91, align 8
  %92 = getelementptr double, ptr %8, i64 %83
  %93 = load double, ptr %92, align 8
  %94 = shufflevector <1 x double> %unmaskedload.2, <1 x double> %unmaskedload32.2, <2 x i32> <i32 0, i32 1>
  %95 = insertelement <2 x double> poison, double %93, i64 0
  %96 = shufflevector <2 x double> %95, <2 x double> poison, <2 x i32> zeroinitializer
  %97 = fmul <2 x double> %94, %96
  %98 = shufflevector <1 x double> %unmaskedload33.2, <1 x double> %unmaskedload34.2, <2 x i32> <i32 0, i32 1>
  %99 = fmul <2 x double> %98, %96
  %100 = shufflevector <2 x double> %97, <2 x double> %99, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %unmaskedload35.2, <1 x double> %unmaskedload36.2, <2 x i32> <i32 0, i32 1>
  %102 = fmul <2 x double> %101, %96
  %103 = shufflevector <2 x double> %102, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <8 x double> %100, <8 x double> %103, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %105 = shufflevector <1 x double> %unmaskedload37.2, <1 x double> %unmaskedload42, <2 x i32> <i32 0, i32 1>
  %106 = fmul <2 x double> %105, %96
  %107 = shufflevector <2 x double> %106, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %108 = shufflevector <8 x double> %104, <8 x double> %107, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %109 = fadd <8 x double> %82, %108
  store <8 x double> %109, ptr %80, align 8
  %110 = add nuw nsw i64 %83, 1
  %exitcond.not.2 = icmp eq i64 %110, 65
  br i1 %exitcond.not.2, label %.preheader.3, label %81

.preheader.3:                                     ; preds = %81
  %111 = getelementptr double, ptr %1, i64 1560
  %112 = getelementptr double, ptr %13, i64 24
  br label %113

113:                                              ; preds = %113, %.preheader.3
  %114 = phi i64 [ 0, %.preheader.3 ], [ %141, %113 ]
  %115 = getelementptr double, ptr %111, i64 %114
  %unmaskedload.3 = load <1 x double>, ptr %115, align 8
  %116 = getelementptr double, ptr %115, i64 65
  %unmaskedload32.3 = load <1 x double>, ptr %116, align 8
  %117 = getelementptr double, ptr %115, i64 130
  %unmaskedload33.3 = load <1 x double>, ptr %117, align 8
  %118 = getelementptr double, ptr %115, i64 195
  %unmaskedload34.3 = load <1 x double>, ptr %118, align 8
  %119 = getelementptr double, ptr %115, i64 260
  %unmaskedload35.3 = load <1 x double>, ptr %119, align 8
  %120 = getelementptr double, ptr %115, i64 325
  %unmaskedload36.3 = load <1 x double>, ptr %120, align 8
  %121 = getelementptr double, ptr %115, i64 390
  %unmaskedload37.3 = load <1 x double>, ptr %121, align 8
  %122 = getelementptr double, ptr %8, i64 %114
  %123 = load double, ptr %122, align 8
  %124 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %112, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %125 = shufflevector <1 x double> %unmaskedload.3, <1 x double> %unmaskedload32.3, <2 x i32> <i32 0, i32 1>
  %126 = insertelement <2 x double> poison, double %123, i64 0
  %127 = shufflevector <2 x double> %126, <2 x double> poison, <2 x i32> zeroinitializer
  %128 = fmul <2 x double> %125, %127
  %129 = shufflevector <1 x double> %unmaskedload33.3, <1 x double> %unmaskedload34.3, <2 x i32> <i32 0, i32 1>
  %130 = fmul <2 x double> %129, %127
  %131 = shufflevector <2 x double> %128, <2 x double> %130, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %132 = shufflevector <1 x double> %unmaskedload35.3, <1 x double> %unmaskedload36.3, <2 x i32> <i32 0, i32 1>
  %133 = fmul <2 x double> %132, %127
  %134 = shufflevector <2 x double> %133, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %135 = shufflevector <8 x double> %131, <8 x double> %134, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %136 = shufflevector <1 x double> %unmaskedload37.3, <1 x double> poison, <2 x i32> <i32 0, i32 poison>
  %137 = fmul <2 x double> %136, %127
  %138 = shufflevector <2 x double> %137, <2 x double> poison, <8 x i32> <i32 0, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %139 = shufflevector <8 x double> %135, <8 x double> %138, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 poison>
  %140 = fadd <8 x double> %124, %139
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %140, ptr %112, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %141 = add nuw nsw i64 %114, 1
  %exitcond.not.3 = icmp eq i64 %141, 65
  br i1 %exitcond.not.3, label %142, label %113

142:                                              ; preds = %113
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
.preheader.i:
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %3

3:                                                ; preds = %3, %.preheader.i
  %4 = phi <8 x double> [ zeroinitializer, %.preheader.i ], [ %31, %3 ]
  %5 = phi i64 [ 0, %.preheader.i ], [ %32, %3 ]
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %unmaskedload.i = load <1 x double>, ptr %6, align 8
  %7 = getelementptr double, ptr %6, i64 65
  %unmaskedload32.i = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %6, i64 130
  %unmaskedload33.i = load <1 x double>, ptr %8, align 8
  %9 = getelementptr double, ptr %6, i64 195
  %unmaskedload34.i = load <1 x double>, ptr %9, align 8
  %10 = getelementptr double, ptr %6, i64 260
  %unmaskedload35.i = load <1 x double>, ptr %10, align 8
  %11 = getelementptr double, ptr %6, i64 325
  %unmaskedload36.i = load <1 x double>, ptr %11, align 8
  %12 = getelementptr double, ptr %6, i64 390
  %unmaskedload37.i = load <1 x double>, ptr %12, align 8
  %13 = getelementptr double, ptr %6, i64 455
  %unmaskedload = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %.unpack17, i64 %5
  %15 = load double, ptr %14, align 8
  %16 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload32.i, <2 x i32> <i32 0, i32 1>
  %17 = insertelement <2 x double> poison, double %15, i64 0
  %18 = shufflevector <2 x double> %17, <2 x double> poison, <2 x i32> zeroinitializer
  %19 = fmul <2 x double> %16, %18
  %20 = shufflevector <1 x double> %unmaskedload33.i, <1 x double> %unmaskedload34.i, <2 x i32> <i32 0, i32 1>
  %21 = fmul <2 x double> %20, %18
  %22 = shufflevector <2 x double> %19, <2 x double> %21, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %23 = shufflevector <1 x double> %unmaskedload35.i, <1 x double> %unmaskedload36.i, <2 x i32> <i32 0, i32 1>
  %24 = fmul <2 x double> %23, %18
  %25 = shufflevector <2 x double> %24, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %26 = shufflevector <8 x double> %22, <8 x double> %25, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %27 = shufflevector <1 x double> %unmaskedload37.i, <1 x double> %unmaskedload, <2 x i32> <i32 0, i32 1>
  %28 = fmul <2 x double> %27, %18
  %29 = shufflevector <2 x double> %28, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %30 = shufflevector <8 x double> %26, <8 x double> %29, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %31 = fadd <8 x double> %4, %30
  store <8 x double> %31, ptr %.unpack28, align 8
  %32 = add nuw nsw i64 %5, 1
  %exitcond.not.i = icmp eq i64 %32, 65
  br i1 %exitcond.not.i, label %.preheader.i.1, label %3

.preheader.i.1:                                   ; preds = %3
  %33 = getelementptr double, ptr %.unpack2, i64 520
  %34 = getelementptr double, ptr %.unpack28, i64 8
  %.promoted = load <8 x double>, ptr %34, align 8
  br label %35

35:                                               ; preds = %35, %.preheader.i.1
  %36 = phi <8 x double> [ %.promoted, %.preheader.i.1 ], [ %63, %35 ]
  %37 = phi i64 [ 0, %.preheader.i.1 ], [ %64, %35 ]
  %38 = getelementptr double, ptr %33, i64 %37
  %unmaskedload.i.1 = load <1 x double>, ptr %38, align 8
  %39 = getelementptr double, ptr %38, i64 65
  %unmaskedload32.i.1 = load <1 x double>, ptr %39, align 8
  %40 = getelementptr double, ptr %38, i64 130
  %unmaskedload33.i.1 = load <1 x double>, ptr %40, align 8
  %41 = getelementptr double, ptr %38, i64 195
  %unmaskedload34.i.1 = load <1 x double>, ptr %41, align 8
  %42 = getelementptr double, ptr %38, i64 260
  %unmaskedload35.i.1 = load <1 x double>, ptr %42, align 8
  %43 = getelementptr double, ptr %38, i64 325
  %unmaskedload36.i.1 = load <1 x double>, ptr %43, align 8
  %44 = getelementptr double, ptr %38, i64 390
  %unmaskedload37.i.1 = load <1 x double>, ptr %44, align 8
  %45 = getelementptr double, ptr %38, i64 455
  %unmaskedload38 = load <1 x double>, ptr %45, align 8
  %46 = getelementptr double, ptr %.unpack17, i64 %37
  %47 = load double, ptr %46, align 8
  %48 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload32.i.1, <2 x i32> <i32 0, i32 1>
  %49 = insertelement <2 x double> poison, double %47, i64 0
  %50 = shufflevector <2 x double> %49, <2 x double> poison, <2 x i32> zeroinitializer
  %51 = fmul <2 x double> %48, %50
  %52 = shufflevector <1 x double> %unmaskedload33.i.1, <1 x double> %unmaskedload34.i.1, <2 x i32> <i32 0, i32 1>
  %53 = fmul <2 x double> %52, %50
  %54 = shufflevector <2 x double> %51, <2 x double> %53, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <1 x double> %unmaskedload35.i.1, <1 x double> %unmaskedload36.i.1, <2 x i32> <i32 0, i32 1>
  %56 = fmul <2 x double> %55, %50
  %57 = shufflevector <2 x double> %56, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %58 = shufflevector <8 x double> %54, <8 x double> %57, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %59 = shufflevector <1 x double> %unmaskedload37.i.1, <1 x double> %unmaskedload38, <2 x i32> <i32 0, i32 1>
  %60 = fmul <2 x double> %59, %50
  %61 = shufflevector <2 x double> %60, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <8 x double> %58, <8 x double> %61, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %63 = fadd <8 x double> %36, %62
  store <8 x double> %63, ptr %34, align 8
  %64 = add nuw nsw i64 %37, 1
  %exitcond.not.i.1 = icmp eq i64 %64, 65
  br i1 %exitcond.not.i.1, label %.preheader.i.2, label %35

.preheader.i.2:                                   ; preds = %35
  %65 = getelementptr double, ptr %.unpack2, i64 1040
  %66 = getelementptr double, ptr %.unpack28, i64 16
  %.promoted42 = load <8 x double>, ptr %66, align 8
  br label %67

67:                                               ; preds = %67, %.preheader.i.2
  %68 = phi <8 x double> [ %.promoted42, %.preheader.i.2 ], [ %95, %67 ]
  %69 = phi i64 [ 0, %.preheader.i.2 ], [ %96, %67 ]
  %70 = getelementptr double, ptr %65, i64 %69
  %unmaskedload.i.2 = load <1 x double>, ptr %70, align 8
  %71 = getelementptr double, ptr %70, i64 65
  %unmaskedload32.i.2 = load <1 x double>, ptr %71, align 8
  %72 = getelementptr double, ptr %70, i64 130
  %unmaskedload33.i.2 = load <1 x double>, ptr %72, align 8
  %73 = getelementptr double, ptr %70, i64 195
  %unmaskedload34.i.2 = load <1 x double>, ptr %73, align 8
  %74 = getelementptr double, ptr %70, i64 260
  %unmaskedload35.i.2 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %70, i64 325
  %unmaskedload36.i.2 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %70, i64 390
  %unmaskedload37.i.2 = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %70, i64 455
  %unmaskedload40 = load <1 x double>, ptr %77, align 8
  %78 = getelementptr double, ptr %.unpack17, i64 %69
  %79 = load double, ptr %78, align 8
  %80 = shufflevector <1 x double> %unmaskedload.i.2, <1 x double> %unmaskedload32.i.2, <2 x i32> <i32 0, i32 1>
  %81 = insertelement <2 x double> poison, double %79, i64 0
  %82 = shufflevector <2 x double> %81, <2 x double> poison, <2 x i32> zeroinitializer
  %83 = fmul <2 x double> %80, %82
  %84 = shufflevector <1 x double> %unmaskedload33.i.2, <1 x double> %unmaskedload34.i.2, <2 x i32> <i32 0, i32 1>
  %85 = fmul <2 x double> %84, %82
  %86 = shufflevector <2 x double> %83, <2 x double> %85, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %unmaskedload35.i.2, <1 x double> %unmaskedload36.i.2, <2 x i32> <i32 0, i32 1>
  %88 = fmul <2 x double> %87, %82
  %89 = shufflevector <2 x double> %88, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %90 = shufflevector <8 x double> %86, <8 x double> %89, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %91 = shufflevector <1 x double> %unmaskedload37.i.2, <1 x double> %unmaskedload40, <2 x i32> <i32 0, i32 1>
  %92 = fmul <2 x double> %91, %82
  %93 = shufflevector <2 x double> %92, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %94 = shufflevector <8 x double> %90, <8 x double> %93, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %95 = fadd <8 x double> %68, %94
  store <8 x double> %95, ptr %66, align 8
  %96 = add nuw nsw i64 %69, 1
  %exitcond.not.i.2 = icmp eq i64 %96, 65
  br i1 %exitcond.not.i.2, label %.preheader.i.3, label %67

.preheader.i.3:                                   ; preds = %67
  %97 = getelementptr double, ptr %.unpack2, i64 1560
  %98 = getelementptr double, ptr %.unpack28, i64 24
  br label %99

99:                                               ; preds = %99, %.preheader.i.3
  %100 = phi i64 [ 0, %.preheader.i.3 ], [ %126, %99 ]
  %101 = getelementptr double, ptr %97, i64 %100
  %unmaskedload.i.3 = load <1 x double>, ptr %101, align 8
  %102 = getelementptr double, ptr %101, i64 65
  %unmaskedload32.i.3 = load <1 x double>, ptr %102, align 8
  %103 = getelementptr double, ptr %101, i64 130
  %unmaskedload33.i.3 = load <1 x double>, ptr %103, align 8
  %104 = getelementptr double, ptr %101, i64 195
  %unmaskedload34.i.3 = load <1 x double>, ptr %104, align 8
  %105 = getelementptr double, ptr %101, i64 260
  %unmaskedload35.i.3 = load <1 x double>, ptr %105, align 8
  %106 = getelementptr double, ptr %101, i64 325
  %unmaskedload36.i.3 = load <1 x double>, ptr %106, align 8
  %107 = getelementptr double, ptr %101, i64 390
  %unmaskedload37.i.3 = load <1 x double>, ptr %107, align 8
  %108 = getelementptr double, ptr %.unpack17, i64 %100
  %109 = load double, ptr %108, align 8
  %110 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %98, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %111 = shufflevector <1 x double> %unmaskedload.i.3, <1 x double> %unmaskedload32.i.3, <2 x i32> <i32 0, i32 1>
  %112 = insertelement <2 x double> poison, double %109, i64 0
  %113 = shufflevector <2 x double> %112, <2 x double> poison, <2 x i32> zeroinitializer
  %114 = fmul <2 x double> %111, %113
  %115 = shufflevector <1 x double> %unmaskedload33.i.3, <1 x double> %unmaskedload34.i.3, <2 x i32> <i32 0, i32 1>
  %116 = fmul <2 x double> %115, %113
  %117 = shufflevector <2 x double> %114, <2 x double> %116, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %118 = shufflevector <1 x double> %unmaskedload35.i.3, <1 x double> %unmaskedload36.i.3, <2 x i32> <i32 0, i32 1>
  %119 = fmul <2 x double> %118, %113
  %120 = shufflevector <2 x double> %119, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %121 = shufflevector <8 x double> %117, <8 x double> %120, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %122 = extractelement <1 x double> %unmaskedload37.i.3, i64 0
  %123 = fmul double %122, %109
  %124 = insertelement <8 x double> %121, double %123, i64 6
  %125 = fadd <8 x double> %110, %124
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %125, ptr %98, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %126 = add nuw nsw i64 %100, 1
  %exitcond.not.i.3 = icmp eq i64 %126, 65
  br i1 %exitcond.not.i.3, label %kernel.exit, label %99

kernel.exit:                                      ; preds = %99
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x double> @llvm.masked.load.v8f64.p0(ptr nocapture, i32 immarg, <8 x i1>, <8 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f64.p0(<8 x double>, ptr nocapture, i32 immarg, <8 x i1>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
.preheader.i:
  %1 = getelementptr ptr, ptr %0, i64 1
  %2 = load ptr, ptr %1, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 13
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %9, i8 0, i64 248, i1 false)
  br label %10

10:                                               ; preds = %10, %.preheader.i
  %11 = phi <8 x double> [ zeroinitializer, %.preheader.i ], [ %38, %10 ]
  %12 = phi i64 [ 0, %.preheader.i ], [ %39, %10 ]
  %13 = getelementptr double, ptr %3, i64 %12
  %unmaskedload.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 65
  %unmaskedload32.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 130
  %unmaskedload33.i = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %13, i64 195
  %unmaskedload34.i = load <1 x double>, ptr %16, align 8
  %17 = getelementptr double, ptr %13, i64 260
  %unmaskedload35.i = load <1 x double>, ptr %17, align 8
  %18 = getelementptr double, ptr %13, i64 325
  %unmaskedload36.i = load <1 x double>, ptr %18, align 8
  %19 = getelementptr double, ptr %13, i64 390
  %unmaskedload37.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %13, i64 455
  %unmaskedload = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %6, i64 %12
  %22 = load double, ptr %21, align 8
  %23 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload32.i, <2 x i32> <i32 0, i32 1>
  %24 = insertelement <2 x double> poison, double %22, i64 0
  %25 = shufflevector <2 x double> %24, <2 x double> poison, <2 x i32> zeroinitializer
  %26 = fmul <2 x double> %23, %25
  %27 = shufflevector <1 x double> %unmaskedload33.i, <1 x double> %unmaskedload34.i, <2 x i32> <i32 0, i32 1>
  %28 = fmul <2 x double> %27, %25
  %29 = shufflevector <2 x double> %26, <2 x double> %28, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %30 = shufflevector <1 x double> %unmaskedload35.i, <1 x double> %unmaskedload36.i, <2 x i32> <i32 0, i32 1>
  %31 = fmul <2 x double> %30, %25
  %32 = shufflevector <2 x double> %31, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %33 = shufflevector <8 x double> %29, <8 x double> %32, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %34 = shufflevector <1 x double> %unmaskedload37.i, <1 x double> %unmaskedload, <2 x i32> <i32 0, i32 1>
  %35 = fmul <2 x double> %34, %25
  %36 = shufflevector <2 x double> %35, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %37 = shufflevector <8 x double> %33, <8 x double> %36, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %38 = fadd <8 x double> %11, %37
  store <8 x double> %38, ptr %9, align 8
  %39 = add nuw nsw i64 %12, 1
  %exitcond.not.i = icmp eq i64 %39, 65
  br i1 %exitcond.not.i, label %.preheader.i.1, label %10

.preheader.i.1:                                   ; preds = %10
  %40 = getelementptr double, ptr %3, i64 520
  %41 = getelementptr double, ptr %9, i64 8
  %.promoted6 = load <8 x double>, ptr %41, align 8
  br label %42

42:                                               ; preds = %42, %.preheader.i.1
  %43 = phi <8 x double> [ %.promoted6, %.preheader.i.1 ], [ %70, %42 ]
  %44 = phi i64 [ 0, %.preheader.i.1 ], [ %71, %42 ]
  %45 = getelementptr double, ptr %40, i64 %44
  %unmaskedload.i.1 = load <1 x double>, ptr %45, align 8
  %46 = getelementptr double, ptr %45, i64 65
  %unmaskedload32.i.1 = load <1 x double>, ptr %46, align 8
  %47 = getelementptr double, ptr %45, i64 130
  %unmaskedload33.i.1 = load <1 x double>, ptr %47, align 8
  %48 = getelementptr double, ptr %45, i64 195
  %unmaskedload34.i.1 = load <1 x double>, ptr %48, align 8
  %49 = getelementptr double, ptr %45, i64 260
  %unmaskedload35.i.1 = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %45, i64 325
  %unmaskedload36.i.1 = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %45, i64 390
  %unmaskedload37.i.1 = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %45, i64 455
  %unmaskedload2 = load <1 x double>, ptr %52, align 8
  %53 = getelementptr double, ptr %6, i64 %44
  %54 = load double, ptr %53, align 8
  %55 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload32.i.1, <2 x i32> <i32 0, i32 1>
  %56 = insertelement <2 x double> poison, double %54, i64 0
  %57 = shufflevector <2 x double> %56, <2 x double> poison, <2 x i32> zeroinitializer
  %58 = fmul <2 x double> %55, %57
  %59 = shufflevector <1 x double> %unmaskedload33.i.1, <1 x double> %unmaskedload34.i.1, <2 x i32> <i32 0, i32 1>
  %60 = fmul <2 x double> %59, %57
  %61 = shufflevector <2 x double> %58, <2 x double> %60, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <1 x double> %unmaskedload35.i.1, <1 x double> %unmaskedload36.i.1, <2 x i32> <i32 0, i32 1>
  %63 = fmul <2 x double> %62, %57
  %64 = shufflevector <2 x double> %63, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %65 = shufflevector <8 x double> %61, <8 x double> %64, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %66 = shufflevector <1 x double> %unmaskedload37.i.1, <1 x double> %unmaskedload2, <2 x i32> <i32 0, i32 1>
  %67 = fmul <2 x double> %66, %57
  %68 = shufflevector <2 x double> %67, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <8 x double> %65, <8 x double> %68, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %70 = fadd <8 x double> %43, %69
  store <8 x double> %70, ptr %41, align 8
  %71 = add nuw nsw i64 %44, 1
  %exitcond.not.i.1 = icmp eq i64 %71, 65
  br i1 %exitcond.not.i.1, label %.preheader.i.2, label %42

.preheader.i.2:                                   ; preds = %42
  %72 = getelementptr double, ptr %3, i64 1040
  %73 = getelementptr double, ptr %9, i64 16
  %.promoted7 = load <8 x double>, ptr %73, align 8
  br label %74

74:                                               ; preds = %74, %.preheader.i.2
  %75 = phi <8 x double> [ %.promoted7, %.preheader.i.2 ], [ %102, %74 ]
  %76 = phi i64 [ 0, %.preheader.i.2 ], [ %103, %74 ]
  %77 = getelementptr double, ptr %72, i64 %76
  %unmaskedload.i.2 = load <1 x double>, ptr %77, align 8
  %78 = getelementptr double, ptr %77, i64 65
  %unmaskedload32.i.2 = load <1 x double>, ptr %78, align 8
  %79 = getelementptr double, ptr %77, i64 130
  %unmaskedload33.i.2 = load <1 x double>, ptr %79, align 8
  %80 = getelementptr double, ptr %77, i64 195
  %unmaskedload34.i.2 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %77, i64 260
  %unmaskedload35.i.2 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %77, i64 325
  %unmaskedload36.i.2 = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %77, i64 390
  %unmaskedload37.i.2 = load <1 x double>, ptr %83, align 8
  %84 = getelementptr double, ptr %77, i64 455
  %unmaskedload4 = load <1 x double>, ptr %84, align 8
  %85 = getelementptr double, ptr %6, i64 %76
  %86 = load double, ptr %85, align 8
  %87 = shufflevector <1 x double> %unmaskedload.i.2, <1 x double> %unmaskedload32.i.2, <2 x i32> <i32 0, i32 1>
  %88 = insertelement <2 x double> poison, double %86, i64 0
  %89 = shufflevector <2 x double> %88, <2 x double> poison, <2 x i32> zeroinitializer
  %90 = fmul <2 x double> %87, %89
  %91 = shufflevector <1 x double> %unmaskedload33.i.2, <1 x double> %unmaskedload34.i.2, <2 x i32> <i32 0, i32 1>
  %92 = fmul <2 x double> %91, %89
  %93 = shufflevector <2 x double> %90, <2 x double> %92, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %94 = shufflevector <1 x double> %unmaskedload35.i.2, <1 x double> %unmaskedload36.i.2, <2 x i32> <i32 0, i32 1>
  %95 = fmul <2 x double> %94, %89
  %96 = shufflevector <2 x double> %95, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %97 = shufflevector <8 x double> %93, <8 x double> %96, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %98 = shufflevector <1 x double> %unmaskedload37.i.2, <1 x double> %unmaskedload4, <2 x i32> <i32 0, i32 1>
  %99 = fmul <2 x double> %98, %89
  %100 = shufflevector <2 x double> %99, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <8 x double> %97, <8 x double> %100, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %102 = fadd <8 x double> %75, %101
  store <8 x double> %102, ptr %73, align 8
  %103 = add nuw nsw i64 %76, 1
  %exitcond.not.i.2 = icmp eq i64 %103, 65
  br i1 %exitcond.not.i.2, label %.preheader.i.3, label %74

.preheader.i.3:                                   ; preds = %74
  %104 = getelementptr double, ptr %3, i64 1560
  %105 = getelementptr double, ptr %9, i64 24
  br label %106

106:                                              ; preds = %106, %.preheader.i.3
  %107 = phi i64 [ 0, %.preheader.i.3 ], [ %133, %106 ]
  %108 = getelementptr double, ptr %104, i64 %107
  %unmaskedload.i.3 = load <1 x double>, ptr %108, align 8
  %109 = getelementptr double, ptr %108, i64 65
  %unmaskedload32.i.3 = load <1 x double>, ptr %109, align 8
  %110 = getelementptr double, ptr %108, i64 130
  %unmaskedload33.i.3 = load <1 x double>, ptr %110, align 8
  %111 = getelementptr double, ptr %108, i64 195
  %unmaskedload34.i.3 = load <1 x double>, ptr %111, align 8
  %112 = getelementptr double, ptr %108, i64 260
  %unmaskedload35.i.3 = load <1 x double>, ptr %112, align 8
  %113 = getelementptr double, ptr %108, i64 325
  %unmaskedload36.i.3 = load <1 x double>, ptr %113, align 8
  %114 = getelementptr double, ptr %108, i64 390
  %unmaskedload37.i.3 = load <1 x double>, ptr %114, align 8
  %115 = getelementptr double, ptr %6, i64 %107
  %116 = load double, ptr %115, align 8
  %117 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %105, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %118 = shufflevector <1 x double> %unmaskedload.i.3, <1 x double> %unmaskedload32.i.3, <2 x i32> <i32 0, i32 1>
  %119 = insertelement <2 x double> poison, double %116, i64 0
  %120 = shufflevector <2 x double> %119, <2 x double> poison, <2 x i32> zeroinitializer
  %121 = fmul <2 x double> %118, %120
  %122 = shufflevector <1 x double> %unmaskedload33.i.3, <1 x double> %unmaskedload34.i.3, <2 x i32> <i32 0, i32 1>
  %123 = fmul <2 x double> %122, %120
  %124 = shufflevector <2 x double> %121, <2 x double> %123, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %125 = shufflevector <1 x double> %unmaskedload35.i.3, <1 x double> %unmaskedload36.i.3, <2 x i32> <i32 0, i32 1>
  %126 = fmul <2 x double> %125, %120
  %127 = shufflevector <2 x double> %126, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %128 = shufflevector <8 x double> %124, <8 x double> %127, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %129 = extractelement <1 x double> %unmaskedload37.i.3, i64 0
  %130 = fmul double %129, %116
  %131 = insertelement <8 x double> %128, double %130, i64 6
  %132 = fadd <8 x double> %117, %131
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %132, ptr %105, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %133 = add nuw nsw i64 %107, 1
  %exitcond.not.i.3 = icmp eq i64 %133, 65
  br i1 %exitcond.not.i.3, label %kernel.exit, label %106

kernel.exit:                                      ; preds = %106
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
