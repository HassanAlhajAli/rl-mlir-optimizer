; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  %.promoted = load <16 x double>, ptr %13, align 8
  br label %17

17:                                               ; preds = %.preheader.preheader, %17
  %18 = phi <16 x double> [ %.promoted, %.preheader.preheader ], [ %69, %17 ]
  %19 = phi i64 [ 0, %.preheader.preheader ], [ %70, %17 ]
  %20 = getelementptr double, ptr %1, i64 %19
  %unmaskedload = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %20, i64 65
  %unmaskedload64 = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %20, i64 130
  %unmaskedload65 = load <1 x double>, ptr %22, align 8
  %23 = shufflevector <1 x double> %unmaskedload65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = getelementptr double, ptr %20, i64 195
  %unmaskedload66 = load <1 x double>, ptr %24, align 8
  %25 = shufflevector <1 x double> %unmaskedload66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %26 = getelementptr double, ptr %20, i64 260
  %unmaskedload67 = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %20, i64 325
  %unmaskedload68 = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %20, i64 390
  %unmaskedload69 = load <1 x double>, ptr %28, align 8
  %29 = shufflevector <1 x double> %unmaskedload69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = getelementptr double, ptr %20, i64 455
  %unmaskedload70 = load <1 x double>, ptr %30, align 8
  %31 = shufflevector <1 x double> %unmaskedload70, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = getelementptr double, ptr %20, i64 520
  %unmaskedload71 = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %20, i64 585
  %unmaskedload72 = load <1 x double>, ptr %33, align 8
  %34 = getelementptr double, ptr %20, i64 650
  %unmaskedload73 = load <1 x double>, ptr %34, align 8
  %35 = shufflevector <1 x double> %unmaskedload73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = getelementptr double, ptr %20, i64 715
  %unmaskedload74 = load <1 x double>, ptr %36, align 8
  %37 = shufflevector <1 x double> %unmaskedload74, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = getelementptr double, ptr %20, i64 780
  %unmaskedload75 = load <1 x double>, ptr %38, align 8
  %39 = getelementptr double, ptr %20, i64 845
  %unmaskedload76 = load <1 x double>, ptr %39, align 8
  %40 = getelementptr double, ptr %20, i64 910
  %unmaskedload77 = load <1 x double>, ptr %40, align 8
  %41 = shufflevector <1 x double> %unmaskedload77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = getelementptr double, ptr %20, i64 975
  %unmaskedload78 = load <1 x double>, ptr %42, align 8
  %43 = shufflevector <1 x double> %unmaskedload78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = getelementptr double, ptr %8, i64 %19
  %45 = load double, ptr %44, align 8
  %46 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %25, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %49 = insertelement <4 x double> poison, double %45, i64 0
  %50 = shufflevector <4 x double> %49, <4 x double> poison, <4 x i32> zeroinitializer
  %51 = fmul <4 x double> %48, %50
  %52 = shufflevector <1 x double> %unmaskedload67, <1 x double> %unmaskedload68, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %54 = shufflevector <4 x double> %53, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %55 = fmul <4 x double> %54, %50
  %56 = shufflevector <4 x double> %51, <4 x double> %55, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %57 = shufflevector <1 x double> %unmaskedload71, <1 x double> %unmaskedload72, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %60 = fmul <4 x double> %59, %50
  %61 = shufflevector <4 x double> %60, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <16 x double> %56, <16 x double> %61, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %63 = shufflevector <1 x double> %unmaskedload75, <1 x double> %unmaskedload76, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %64 = shufflevector <4 x double> %63, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %65 = shufflevector <4 x double> %64, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %66 = fmul <4 x double> %65, %50
  %67 = shufflevector <4 x double> %66, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %68 = shufflevector <16 x double> %62, <16 x double> %67, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %69 = fadd <16 x double> %18, %68
  store <16 x double> %69, ptr %13, align 8
  %70 = add nuw nsw i64 %19, 1
  %exitcond.not = icmp eq i64 %70, 65
  br i1 %exitcond.not, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %71 = getelementptr double, ptr %1, i64 1040
  %72 = getelementptr double, ptr %13, i64 16
  br label %73

73:                                               ; preds = %73, %.preheader.1
  %74 = phi i64 [ 0, %.preheader.1 ], [ %123, %73 ]
  %75 = getelementptr double, ptr %71, i64 %74
  %unmaskedload.1 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %75, i64 65
  %unmaskedload64.1 = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %75, i64 130
  %unmaskedload65.1 = load <1 x double>, ptr %77, align 8
  %78 = shufflevector <1 x double> %unmaskedload65.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = getelementptr double, ptr %75, i64 195
  %unmaskedload66.1 = load <1 x double>, ptr %79, align 8
  %80 = shufflevector <1 x double> %unmaskedload66.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = getelementptr double, ptr %75, i64 260
  %unmaskedload67.1 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %75, i64 325
  %unmaskedload68.1 = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %75, i64 390
  %unmaskedload69.1 = load <1 x double>, ptr %83, align 8
  %84 = shufflevector <1 x double> %unmaskedload69.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = getelementptr double, ptr %75, i64 455
  %unmaskedload70.1 = load <1 x double>, ptr %85, align 8
  %86 = shufflevector <1 x double> %unmaskedload70.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = getelementptr double, ptr %75, i64 520
  %unmaskedload71.1 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %75, i64 585
  %unmaskedload72.1 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %75, i64 650
  %unmaskedload73.1 = load <1 x double>, ptr %89, align 8
  %90 = shufflevector <1 x double> %unmaskedload73.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %91 = getelementptr double, ptr %75, i64 715
  %unmaskedload74.1 = load <1 x double>, ptr %91, align 8
  %92 = shufflevector <1 x double> %unmaskedload74.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = getelementptr double, ptr %75, i64 780
  %unmaskedload75.1 = load <1 x double>, ptr %93, align 8
  %94 = getelementptr double, ptr %75, i64 845
  %unmaskedload76.1 = load <1 x double>, ptr %94, align 8
  %95 = getelementptr double, ptr %75, i64 910
  %unmaskedload77.1 = load <1 x double>, ptr %95, align 8
  %96 = shufflevector <1 x double> %unmaskedload77.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %97 = getelementptr double, ptr %8, i64 %74
  %98 = load double, ptr %97, align 8
  %99 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %72, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %100 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload64.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %103 = insertelement <4 x double> poison, double %98, i64 0
  %104 = shufflevector <4 x double> %103, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = fmul <4 x double> %102, %104
  %106 = shufflevector <1 x double> %unmaskedload67.1, <1 x double> %unmaskedload68.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %109 = fmul <4 x double> %108, %104
  %110 = shufflevector <4 x double> %105, <4 x double> %109, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <1 x double> %unmaskedload71.1, <1 x double> %unmaskedload72.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %112 = shufflevector <4 x double> %111, <4 x double> %90, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %114 = fmul <4 x double> %113, %104
  %115 = shufflevector <4 x double> %114, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %116 = shufflevector <16 x double> %110, <16 x double> %115, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %117 = shufflevector <1 x double> %unmaskedload75.1, <1 x double> %unmaskedload76.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %118 = shufflevector <4 x double> %117, <4 x double> %96, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %119 = fmul <4 x double> %118, %104
  %120 = shufflevector <4 x double> %119, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %121 = shufflevector <16 x double> %116, <16 x double> %120, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 poison>
  %122 = fadd <16 x double> %99, %121
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %122, ptr %72, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %123 = add nuw nsw i64 %74, 1
  %exitcond.not.1 = icmp eq i64 %123, 65
  br i1 %exitcond.not.1, label %124, label %73

124:                                              ; preds = %73
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
.preheader.i:
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %3

3:                                                ; preds = %3, %.preheader.i
  %4 = phi <16 x double> [ zeroinitializer, %.preheader.i ], [ %55, %3 ]
  %5 = phi i64 [ 0, %.preheader.i ], [ %56, %3 ]
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %unmaskedload.i = load <1 x double>, ptr %6, align 8
  %7 = getelementptr double, ptr %6, i64 65
  %unmaskedload64.i = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %6, i64 130
  %unmaskedload65.i = load <1 x double>, ptr %8, align 8
  %9 = shufflevector <1 x double> %unmaskedload65.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %10 = getelementptr double, ptr %6, i64 195
  %unmaskedload66.i = load <1 x double>, ptr %10, align 8
  %11 = shufflevector <1 x double> %unmaskedload66.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %12 = getelementptr double, ptr %6, i64 260
  %unmaskedload67.i = load <1 x double>, ptr %12, align 8
  %13 = getelementptr double, ptr %6, i64 325
  %unmaskedload68.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %6, i64 390
  %unmaskedload69.i = load <1 x double>, ptr %14, align 8
  %15 = shufflevector <1 x double> %unmaskedload69.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %16 = getelementptr double, ptr %6, i64 455
  %unmaskedload70.i = load <1 x double>, ptr %16, align 8
  %17 = shufflevector <1 x double> %unmaskedload70.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %18 = getelementptr double, ptr %6, i64 520
  %unmaskedload71.i = load <1 x double>, ptr %18, align 8
  %19 = getelementptr double, ptr %6, i64 585
  %unmaskedload72.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %6, i64 650
  %unmaskedload73.i = load <1 x double>, ptr %20, align 8
  %21 = shufflevector <1 x double> %unmaskedload73.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %22 = getelementptr double, ptr %6, i64 715
  %unmaskedload74.i = load <1 x double>, ptr %22, align 8
  %23 = shufflevector <1 x double> %unmaskedload74.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = getelementptr double, ptr %6, i64 780
  %unmaskedload75.i = load <1 x double>, ptr %24, align 8
  %25 = getelementptr double, ptr %6, i64 845
  %unmaskedload76.i = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %6, i64 910
  %unmaskedload77.i = load <1 x double>, ptr %26, align 8
  %27 = shufflevector <1 x double> %unmaskedload77.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %28 = getelementptr double, ptr %6, i64 975
  %unmaskedload = load <1 x double>, ptr %28, align 8
  %29 = shufflevector <1 x double> %unmaskedload, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = getelementptr double, ptr %.unpack17, i64 %5
  %31 = load double, ptr %30, align 8
  %32 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload64.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %9, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %11, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = insertelement <4 x double> poison, double %31, i64 0
  %36 = shufflevector <4 x double> %35, <4 x double> poison, <4 x i32> zeroinitializer
  %37 = fmul <4 x double> %34, %36
  %38 = shufflevector <1 x double> %unmaskedload67.i, <1 x double> %unmaskedload68.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %39 = shufflevector <4 x double> %38, <4 x double> %15, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %17, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %41 = fmul <4 x double> %40, %36
  %42 = shufflevector <4 x double> %37, <4 x double> %41, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %43 = shufflevector <1 x double> %unmaskedload71.i, <1 x double> %unmaskedload72.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %21, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %46 = fmul <4 x double> %45, %36
  %47 = shufflevector <4 x double> %46, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %48 = shufflevector <16 x double> %42, <16 x double> %47, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %unmaskedload75.i, <1 x double> %unmaskedload76.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %27, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fmul <4 x double> %51, %36
  %53 = shufflevector <4 x double> %52, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %54 = shufflevector <16 x double> %48, <16 x double> %53, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %55 = fadd <16 x double> %4, %54
  store <16 x double> %55, ptr %.unpack28, align 8
  %56 = add nuw nsw i64 %5, 1
  %exitcond.not.i = icmp eq i64 %56, 65
  br i1 %exitcond.not.i, label %.preheader.i.1, label %3

.preheader.i.1:                                   ; preds = %3
  %57 = getelementptr double, ptr %.unpack2, i64 1040
  %58 = getelementptr double, ptr %.unpack28, i64 16
  br label %59

59:                                               ; preds = %59, %.preheader.i.1
  %60 = phi i64 [ 0, %.preheader.i.1 ], [ %112, %59 ]
  %61 = getelementptr double, ptr %57, i64 %60
  %unmaskedload.i.1 = load <1 x double>, ptr %61, align 8
  %62 = getelementptr double, ptr %61, i64 65
  %unmaskedload64.i.1 = load <1 x double>, ptr %62, align 8
  %63 = getelementptr double, ptr %61, i64 130
  %unmaskedload65.i.1 = load <1 x double>, ptr %63, align 8
  %64 = shufflevector <1 x double> %unmaskedload65.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = getelementptr double, ptr %61, i64 195
  %unmaskedload66.i.1 = load <1 x double>, ptr %65, align 8
  %66 = shufflevector <1 x double> %unmaskedload66.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = getelementptr double, ptr %61, i64 260
  %unmaskedload67.i.1 = load <1 x double>, ptr %67, align 8
  %68 = getelementptr double, ptr %61, i64 325
  %unmaskedload68.i.1 = load <1 x double>, ptr %68, align 8
  %69 = getelementptr double, ptr %61, i64 390
  %unmaskedload69.i.1 = load <1 x double>, ptr %69, align 8
  %70 = shufflevector <1 x double> %unmaskedload69.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %71 = getelementptr double, ptr %61, i64 455
  %unmaskedload70.i.1 = load <1 x double>, ptr %71, align 8
  %72 = shufflevector <1 x double> %unmaskedload70.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = getelementptr double, ptr %61, i64 520
  %unmaskedload71.i.1 = load <1 x double>, ptr %73, align 8
  %74 = getelementptr double, ptr %61, i64 585
  %unmaskedload72.i.1 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %61, i64 650
  %unmaskedload73.i.1 = load <1 x double>, ptr %75, align 8
  %76 = shufflevector <1 x double> %unmaskedload73.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = getelementptr double, ptr %61, i64 715
  %unmaskedload74.i.1 = load <1 x double>, ptr %77, align 8
  %78 = shufflevector <1 x double> %unmaskedload74.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = getelementptr double, ptr %61, i64 780
  %unmaskedload75.i.1 = load <1 x double>, ptr %79, align 8
  %80 = getelementptr double, ptr %61, i64 845
  %unmaskedload76.i.1 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %61, i64 910
  %unmaskedload77.i.1 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %.unpack17, i64 %60
  %83 = load double, ptr %82, align 8
  %84 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %58, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %85 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload64.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %87 = shufflevector <4 x double> %86, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %88 = insertelement <4 x double> poison, double %83, i64 0
  %89 = shufflevector <4 x double> %88, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = fmul <4 x double> %87, %89
  %91 = shufflevector <1 x double> %unmaskedload67.i.1, <1 x double> %unmaskedload68.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %70, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %94 = fmul <4 x double> %93, %89
  %95 = shufflevector <4 x double> %90, <4 x double> %94, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %96 = shufflevector <1 x double> %unmaskedload71.i.1, <1 x double> %unmaskedload72.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %98 = shufflevector <4 x double> %97, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %99 = fmul <4 x double> %98, %89
  %100 = shufflevector <4 x double> %99, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <16 x double> %95, <16 x double> %100, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %102 = shufflevector <1 x double> %unmaskedload75.i.1, <1 x double> %unmaskedload76.i.1, <2 x i32> <i32 0, i32 1>
  %103 = insertelement <2 x double> poison, double %83, i64 0
  %104 = shufflevector <2 x double> %103, <2 x double> poison, <2 x i32> zeroinitializer
  %105 = fmul <2 x double> %102, %104
  %106 = shufflevector <2 x double> %105, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %107 = shufflevector <16 x double> %101, <16 x double> %106, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %108 = extractelement <1 x double> %unmaskedload77.i.1, i64 0
  %109 = fmul double %108, %83
  %110 = insertelement <16 x double> %107, double %109, i64 14
  %111 = fadd <16 x double> %84, %110
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %111, ptr %58, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %112 = add nuw nsw i64 %60, 1
  %exitcond.not.i.1 = icmp eq i64 %112, 65
  br i1 %exitcond.not.i.1, label %kernel.exit, label %59

kernel.exit:                                      ; preds = %59
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <16 x double> @llvm.masked.load.v16f64.p0(ptr nocapture, i32 immarg, <16 x i1>, <16 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v16f64.p0(<16 x double>, ptr nocapture, i32 immarg, <16 x i1>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
.preheader.i:
  %1 = getelementptr ptr, ptr %0, i64 1
  %2 = load ptr, ptr %1, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 13
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %9, i8 0, i64 248, i1 false)
  br label %10

10:                                               ; preds = %10, %.preheader.i
  %11 = phi <16 x double> [ zeroinitializer, %.preheader.i ], [ %62, %10 ]
  %12 = phi i64 [ 0, %.preheader.i ], [ %63, %10 ]
  %13 = getelementptr double, ptr %3, i64 %12
  %unmaskedload.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 65
  %unmaskedload64.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 130
  %unmaskedload65.i = load <1 x double>, ptr %15, align 8
  %16 = shufflevector <1 x double> %unmaskedload65.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %17 = getelementptr double, ptr %13, i64 195
  %unmaskedload66.i = load <1 x double>, ptr %17, align 8
  %18 = shufflevector <1 x double> %unmaskedload66.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %19 = getelementptr double, ptr %13, i64 260
  %unmaskedload67.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %13, i64 325
  %unmaskedload68.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %13, i64 390
  %unmaskedload69.i = load <1 x double>, ptr %21, align 8
  %22 = shufflevector <1 x double> %unmaskedload69.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = getelementptr double, ptr %13, i64 455
  %unmaskedload70.i = load <1 x double>, ptr %23, align 8
  %24 = shufflevector <1 x double> %unmaskedload70.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = getelementptr double, ptr %13, i64 520
  %unmaskedload71.i = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %13, i64 585
  %unmaskedload72.i = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %13, i64 650
  %unmaskedload73.i = load <1 x double>, ptr %27, align 8
  %28 = shufflevector <1 x double> %unmaskedload73.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = getelementptr double, ptr %13, i64 715
  %unmaskedload74.i = load <1 x double>, ptr %29, align 8
  %30 = shufflevector <1 x double> %unmaskedload74.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = getelementptr double, ptr %13, i64 780
  %unmaskedload75.i = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %13, i64 845
  %unmaskedload76.i = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %13, i64 910
  %unmaskedload77.i = load <1 x double>, ptr %33, align 8
  %34 = shufflevector <1 x double> %unmaskedload77.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %35 = getelementptr double, ptr %13, i64 975
  %unmaskedload = load <1 x double>, ptr %35, align 8
  %36 = shufflevector <1 x double> %unmaskedload, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = getelementptr double, ptr %6, i64 %12
  %38 = load double, ptr %37, align 8
  %39 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload64.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %16, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %18, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = insertelement <4 x double> poison, double %38, i64 0
  %43 = shufflevector <4 x double> %42, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = fmul <4 x double> %41, %43
  %45 = shufflevector <1 x double> %unmaskedload67.i, <1 x double> %unmaskedload68.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %48 = fmul <4 x double> %47, %43
  %49 = shufflevector <4 x double> %44, <4 x double> %48, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %unmaskedload71.i, <1 x double> %unmaskedload72.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fmul <4 x double> %52, %43
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <16 x double> %49, <16 x double> %54, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <1 x double> %unmaskedload75.i, <1 x double> %unmaskedload76.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %34, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %59 = fmul <4 x double> %58, %43
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <16 x double> %55, <16 x double> %60, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %62 = fadd <16 x double> %11, %61
  store <16 x double> %62, ptr %9, align 8
  %63 = add nuw nsw i64 %12, 1
  %exitcond.not.i = icmp eq i64 %63, 65
  br i1 %exitcond.not.i, label %.preheader.i.1, label %10

.preheader.i.1:                                   ; preds = %10
  %64 = getelementptr double, ptr %3, i64 1040
  %65 = getelementptr double, ptr %9, i64 16
  br label %66

66:                                               ; preds = %66, %.preheader.i.1
  %67 = phi i64 [ 0, %.preheader.i.1 ], [ %119, %66 ]
  %68 = getelementptr double, ptr %64, i64 %67
  %unmaskedload.i.1 = load <1 x double>, ptr %68, align 8
  %69 = getelementptr double, ptr %68, i64 65
  %unmaskedload64.i.1 = load <1 x double>, ptr %69, align 8
  %70 = getelementptr double, ptr %68, i64 130
  %unmaskedload65.i.1 = load <1 x double>, ptr %70, align 8
  %71 = shufflevector <1 x double> %unmaskedload65.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %72 = getelementptr double, ptr %68, i64 195
  %unmaskedload66.i.1 = load <1 x double>, ptr %72, align 8
  %73 = shufflevector <1 x double> %unmaskedload66.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = getelementptr double, ptr %68, i64 260
  %unmaskedload67.i.1 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %68, i64 325
  %unmaskedload68.i.1 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %68, i64 390
  %unmaskedload69.i.1 = load <1 x double>, ptr %76, align 8
  %77 = shufflevector <1 x double> %unmaskedload69.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %78 = getelementptr double, ptr %68, i64 455
  %unmaskedload70.i.1 = load <1 x double>, ptr %78, align 8
  %79 = shufflevector <1 x double> %unmaskedload70.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = getelementptr double, ptr %68, i64 520
  %unmaskedload71.i.1 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %68, i64 585
  %unmaskedload72.i.1 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %68, i64 650
  %unmaskedload73.i.1 = load <1 x double>, ptr %82, align 8
  %83 = shufflevector <1 x double> %unmaskedload73.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = getelementptr double, ptr %68, i64 715
  %unmaskedload74.i.1 = load <1 x double>, ptr %84, align 8
  %85 = shufflevector <1 x double> %unmaskedload74.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = getelementptr double, ptr %68, i64 780
  %unmaskedload75.i.1 = load <1 x double>, ptr %86, align 8
  %87 = getelementptr double, ptr %68, i64 845
  %unmaskedload76.i.1 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %68, i64 910
  %unmaskedload77.i.1 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %6, i64 %67
  %90 = load double, ptr %89, align 8
  %91 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %65, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %92 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload64.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %71, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = insertelement <4 x double> poison, double %90, i64 0
  %96 = shufflevector <4 x double> %95, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = fmul <4 x double> %94, %96
  %98 = shufflevector <1 x double> %unmaskedload67.i.1, <1 x double> %unmaskedload68.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %99 = shufflevector <4 x double> %98, <4 x double> %77, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %101 = fmul <4 x double> %100, %96
  %102 = shufflevector <4 x double> %97, <4 x double> %101, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %103 = shufflevector <1 x double> %unmaskedload71.i.1, <1 x double> %unmaskedload72.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %106 = fmul <4 x double> %105, %96
  %107 = shufflevector <4 x double> %106, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %108 = shufflevector <16 x double> %102, <16 x double> %107, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %109 = shufflevector <1 x double> %unmaskedload75.i.1, <1 x double> %unmaskedload76.i.1, <2 x i32> <i32 0, i32 1>
  %110 = insertelement <2 x double> poison, double %90, i64 0
  %111 = shufflevector <2 x double> %110, <2 x double> poison, <2 x i32> zeroinitializer
  %112 = fmul <2 x double> %109, %111
  %113 = shufflevector <2 x double> %112, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %114 = shufflevector <16 x double> %108, <16 x double> %113, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %115 = extractelement <1 x double> %unmaskedload77.i.1, i64 0
  %116 = fmul double %115, %90
  %117 = insertelement <16 x double> %114, double %116, i64 14
  %118 = fadd <16 x double> %91, %117
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %118, ptr %65, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %119 = add nuw nsw i64 %67, 1
  %exitcond.not.i.1 = icmp eq i64 %119, 65
  br i1 %exitcond.not.i.1, label %kernel.exit, label %66

kernel.exit:                                      ; preds = %66
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28.i, i8 0, i64 248, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi <16 x double> [ zeroinitializer, %1 ], [ %62, %10 ]
  %12 = phi i64 [ 0, %1 ], [ %63, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %12
  %unmaskedload.i.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 65
  %unmaskedload64.i.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 130
  %unmaskedload65.i.i = load <1 x double>, ptr %15, align 8
  %16 = shufflevector <1 x double> %unmaskedload65.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %17 = getelementptr double, ptr %13, i64 195
  %unmaskedload66.i.i = load <1 x double>, ptr %17, align 8
  %18 = shufflevector <1 x double> %unmaskedload66.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %19 = getelementptr double, ptr %13, i64 260
  %unmaskedload67.i.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %13, i64 325
  %unmaskedload68.i.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %13, i64 390
  %unmaskedload69.i.i = load <1 x double>, ptr %21, align 8
  %22 = shufflevector <1 x double> %unmaskedload69.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = getelementptr double, ptr %13, i64 455
  %unmaskedload70.i.i = load <1 x double>, ptr %23, align 8
  %24 = shufflevector <1 x double> %unmaskedload70.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = getelementptr double, ptr %13, i64 520
  %unmaskedload71.i.i = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %13, i64 585
  %unmaskedload72.i.i = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %13, i64 650
  %unmaskedload73.i.i = load <1 x double>, ptr %27, align 8
  %28 = shufflevector <1 x double> %unmaskedload73.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = getelementptr double, ptr %13, i64 715
  %unmaskedload74.i.i = load <1 x double>, ptr %29, align 8
  %30 = shufflevector <1 x double> %unmaskedload74.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = getelementptr double, ptr %13, i64 780
  %unmaskedload75.i.i = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %13, i64 845
  %unmaskedload76.i.i = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %13, i64 910
  %unmaskedload77.i.i = load <1 x double>, ptr %33, align 8
  %34 = shufflevector <1 x double> %unmaskedload77.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %35 = getelementptr double, ptr %13, i64 975
  %unmaskedload.i = load <1 x double>, ptr %35, align 8
  %36 = shufflevector <1 x double> %unmaskedload.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = getelementptr double, ptr %.unpack17.i, i64 %12
  %38 = load double, ptr %37, align 8
  %39 = shufflevector <1 x double> %unmaskedload.i.i, <1 x double> %unmaskedload64.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %16, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %18, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = insertelement <4 x double> poison, double %38, i64 0
  %43 = shufflevector <4 x double> %42, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = fmul <4 x double> %41, %43
  %45 = shufflevector <1 x double> %unmaskedload67.i.i, <1 x double> %unmaskedload68.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %48 = fmul <4 x double> %47, %43
  %49 = shufflevector <4 x double> %44, <4 x double> %48, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %unmaskedload71.i.i, <1 x double> %unmaskedload72.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fmul <4 x double> %52, %43
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <16 x double> %49, <16 x double> %54, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <1 x double> %unmaskedload75.i.i, <1 x double> %unmaskedload76.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %34, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %59 = fmul <4 x double> %58, %43
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <16 x double> %55, <16 x double> %60, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %62 = fadd <16 x double> %11, %61
  store <16 x double> %62, ptr %.unpack28.i, align 8
  %63 = add nuw nsw i64 %12, 1
  %exitcond.not.i.i = icmp eq i64 %63, 65
  br i1 %exitcond.not.i.i, label %.preheader.i.1.i, label %10

.preheader.i.1.i:                                 ; preds = %10
  %64 = getelementptr double, ptr %.unpack2.i, i64 1040
  %65 = getelementptr double, ptr %.unpack28.i, i64 16
  br label %66

66:                                               ; preds = %66, %.preheader.i.1.i
  %67 = phi i64 [ 0, %.preheader.i.1.i ], [ %119, %66 ]
  %68 = getelementptr double, ptr %64, i64 %67
  %unmaskedload.i.1.i = load <1 x double>, ptr %68, align 8
  %69 = getelementptr double, ptr %68, i64 65
  %unmaskedload64.i.1.i = load <1 x double>, ptr %69, align 8
  %70 = getelementptr double, ptr %68, i64 130
  %unmaskedload65.i.1.i = load <1 x double>, ptr %70, align 8
  %71 = shufflevector <1 x double> %unmaskedload65.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %72 = getelementptr double, ptr %68, i64 195
  %unmaskedload66.i.1.i = load <1 x double>, ptr %72, align 8
  %73 = shufflevector <1 x double> %unmaskedload66.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = getelementptr double, ptr %68, i64 260
  %unmaskedload67.i.1.i = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %68, i64 325
  %unmaskedload68.i.1.i = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %68, i64 390
  %unmaskedload69.i.1.i = load <1 x double>, ptr %76, align 8
  %77 = shufflevector <1 x double> %unmaskedload69.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %78 = getelementptr double, ptr %68, i64 455
  %unmaskedload70.i.1.i = load <1 x double>, ptr %78, align 8
  %79 = shufflevector <1 x double> %unmaskedload70.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = getelementptr double, ptr %68, i64 520
  %unmaskedload71.i.1.i = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %68, i64 585
  %unmaskedload72.i.1.i = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %68, i64 650
  %unmaskedload73.i.1.i = load <1 x double>, ptr %82, align 8
  %83 = shufflevector <1 x double> %unmaskedload73.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = getelementptr double, ptr %68, i64 715
  %unmaskedload74.i.1.i = load <1 x double>, ptr %84, align 8
  %85 = shufflevector <1 x double> %unmaskedload74.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = getelementptr double, ptr %68, i64 780
  %unmaskedload75.i.1.i = load <1 x double>, ptr %86, align 8
  %87 = getelementptr double, ptr %68, i64 845
  %unmaskedload76.i.1.i = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %68, i64 910
  %unmaskedload77.i.1.i = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %.unpack17.i, i64 %67
  %90 = load double, ptr %89, align 8
  %91 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %65, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %92 = shufflevector <1 x double> %unmaskedload.i.1.i, <1 x double> %unmaskedload64.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %71, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = insertelement <4 x double> poison, double %90, i64 0
  %96 = shufflevector <4 x double> %95, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = fmul <4 x double> %94, %96
  %98 = shufflevector <1 x double> %unmaskedload67.i.1.i, <1 x double> %unmaskedload68.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %99 = shufflevector <4 x double> %98, <4 x double> %77, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %101 = fmul <4 x double> %100, %96
  %102 = shufflevector <4 x double> %97, <4 x double> %101, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %103 = shufflevector <1 x double> %unmaskedload71.i.1.i, <1 x double> %unmaskedload72.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %106 = fmul <4 x double> %105, %96
  %107 = shufflevector <4 x double> %106, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %108 = shufflevector <16 x double> %102, <16 x double> %107, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %109 = shufflevector <1 x double> %unmaskedload75.i.1.i, <1 x double> %unmaskedload76.i.1.i, <2 x i32> <i32 0, i32 1>
  %110 = insertelement <2 x double> poison, double %90, i64 0
  %111 = shufflevector <2 x double> %110, <2 x double> poison, <2 x i32> zeroinitializer
  %112 = fmul <2 x double> %109, %111
  %113 = shufflevector <2 x double> %112, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %114 = shufflevector <16 x double> %108, <16 x double> %113, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %115 = extractelement <1 x double> %unmaskedload77.i.1.i, i64 0
  %116 = fmul double %115, %90
  %117 = insertelement <16 x double> %114, double %116, i64 14
  %118 = fadd <16 x double> %91, %117
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %118, ptr %65, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %119 = add nuw nsw i64 %67, 1
  %exitcond.not.i.1.i = icmp eq i64 %119, 65
  br i1 %exitcond.not.i.1.i, label %_mlir_ciface_kernel.exit, label %66

_mlir_ciface_kernel.exit:                         ; preds = %66
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
