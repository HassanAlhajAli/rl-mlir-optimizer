; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %17

17:                                               ; preds = %.preheader.preheader, %17
  %18 = phi i64 [ 0, %.preheader.preheader ], [ %50, %17 ]
  %19 = phi <8 x double> [ zeroinitializer, %.preheader.preheader ], [ %49, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 128
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 256
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 384
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %20, i64 512
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %20, i64 640
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %20, i64 768
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %20, i64 896
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %18
  %37 = load double, ptr %36, align 8
  %38 = insertelement <8 x double> poison, double %21, i64 0
  %39 = insertelement <8 x double> %38, double %23, i64 1
  %40 = insertelement <8 x double> %39, double %25, i64 2
  %41 = insertelement <8 x double> %40, double %27, i64 3
  %42 = insertelement <8 x double> %41, double %29, i64 4
  %43 = insertelement <8 x double> %42, double %31, i64 5
  %44 = insertelement <8 x double> %43, double %33, i64 6
  %45 = insertelement <8 x double> %44, double %35, i64 7
  %46 = insertelement <8 x double> poison, double %37, i64 0
  %47 = shufflevector <8 x double> %46, <8 x double> poison, <8 x i32> zeroinitializer
  %48 = fmul <8 x double> %45, %47
  %49 = fadd <8 x double> %19, %48
  store <8 x double> %49, ptr %13, align 8
  %50 = add nuw nsw i64 %18, 1
  %exitcond.not = icmp eq i64 %50, 128
  br i1 %exitcond.not, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %51 = getelementptr double, ptr %13, i64 8
  br label %52

52:                                               ; preds = %52, %.preheader.1
  %53 = phi i64 [ 0, %.preheader.1 ], [ %86, %52 ]
  %54 = phi <8 x double> [ zeroinitializer, %.preheader.1 ], [ %85, %52 ]
  %55 = getelementptr double, ptr %1, i64 %53
  %56 = getelementptr double, ptr %55, i64 1024
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %55, i64 1152
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %55, i64 1280
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %55, i64 1408
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %55, i64 1536
  %65 = load double, ptr %64, align 8
  %66 = getelementptr double, ptr %55, i64 1664
  %67 = load double, ptr %66, align 8
  %68 = getelementptr double, ptr %55, i64 1792
  %69 = load double, ptr %68, align 8
  %70 = getelementptr double, ptr %55, i64 1920
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %8, i64 %53
  %73 = load double, ptr %72, align 8
  %74 = insertelement <8 x double> poison, double %57, i64 0
  %75 = insertelement <8 x double> %74, double %59, i64 1
  %76 = insertelement <8 x double> %75, double %61, i64 2
  %77 = insertelement <8 x double> %76, double %63, i64 3
  %78 = insertelement <8 x double> %77, double %65, i64 4
  %79 = insertelement <8 x double> %78, double %67, i64 5
  %80 = insertelement <8 x double> %79, double %69, i64 6
  %81 = insertelement <8 x double> %80, double %71, i64 7
  %82 = insertelement <8 x double> poison, double %73, i64 0
  %83 = shufflevector <8 x double> %82, <8 x double> poison, <8 x i32> zeroinitializer
  %84 = fmul <8 x double> %81, %83
  %85 = fadd <8 x double> %54, %84
  store <8 x double> %85, ptr %51, align 8
  %86 = add nuw nsw i64 %53, 1
  %exitcond.1.not = icmp eq i64 %86, 128
  br i1 %exitcond.1.not, label %87, label %52

87:                                               ; preds = %52
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28, i8 0, i64 128, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %37, %4 ]
  %6 = phi <8 x double> [ zeroinitializer, %3 ], [ %36, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %7, i64 128
  %10 = load double, ptr %9, align 8
  %11 = getelementptr double, ptr %7, i64 256
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %7, i64 384
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %7, i64 512
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %7, i64 640
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %7, i64 768
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %7, i64 896
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17, i64 %5
  %24 = load double, ptr %23, align 8
  %25 = insertelement <8 x double> poison, double %8, i64 0
  %26 = insertelement <8 x double> %25, double %10, i64 1
  %27 = insertelement <8 x double> %26, double %12, i64 2
  %28 = insertelement <8 x double> %27, double %14, i64 3
  %29 = insertelement <8 x double> %28, double %16, i64 4
  %30 = insertelement <8 x double> %29, double %18, i64 5
  %31 = insertelement <8 x double> %30, double %20, i64 6
  %32 = insertelement <8 x double> %31, double %22, i64 7
  %33 = insertelement <8 x double> poison, double %24, i64 0
  %34 = shufflevector <8 x double> %33, <8 x double> poison, <8 x i32> zeroinitializer
  %35 = fmul <8 x double> %32, %34
  %36 = fadd <8 x double> %6, %35
  store <8 x double> %36, ptr %.unpack28, align 8
  %37 = add nuw nsw i64 %5, 1
  %exitcond.not.i = icmp eq i64 %37, 128
  br i1 %exitcond.not.i, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %38 = getelementptr double, ptr %.unpack28, i64 8
  br label %39

39:                                               ; preds = %39, %.preheader.1.i
  %40 = phi i64 [ 0, %.preheader.1.i ], [ %73, %39 ]
  %41 = phi <8 x double> [ zeroinitializer, %.preheader.1.i ], [ %72, %39 ]
  %42 = getelementptr double, ptr %.unpack2, i64 %40
  %43 = getelementptr double, ptr %42, i64 1024
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %42, i64 1152
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %42, i64 1280
  %48 = load double, ptr %47, align 8
  %49 = getelementptr double, ptr %42, i64 1408
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %42, i64 1536
  %52 = load double, ptr %51, align 8
  %53 = getelementptr double, ptr %42, i64 1664
  %54 = load double, ptr %53, align 8
  %55 = getelementptr double, ptr %42, i64 1792
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %42, i64 1920
  %58 = load double, ptr %57, align 8
  %59 = getelementptr double, ptr %.unpack17, i64 %40
  %60 = load double, ptr %59, align 8
  %61 = insertelement <8 x double> poison, double %44, i64 0
  %62 = insertelement <8 x double> %61, double %46, i64 1
  %63 = insertelement <8 x double> %62, double %48, i64 2
  %64 = insertelement <8 x double> %63, double %50, i64 3
  %65 = insertelement <8 x double> %64, double %52, i64 4
  %66 = insertelement <8 x double> %65, double %54, i64 5
  %67 = insertelement <8 x double> %66, double %56, i64 6
  %68 = insertelement <8 x double> %67, double %58, i64 7
  %69 = insertelement <8 x double> poison, double %60, i64 0
  %70 = shufflevector <8 x double> %69, <8 x double> poison, <8 x i32> zeroinitializer
  %71 = fmul <8 x double> %68, %70
  %72 = fadd <8 x double> %41, %71
  store <8 x double> %72, ptr %38, align 8
  %73 = add nuw nsw i64 %40, 1
  %exitcond.1.not.i = icmp eq i64 %73, 128
  br i1 %exitcond.1.not.i, label %kernel.exit, label %39

kernel.exit:                                      ; preds = %39
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %10, i8 0, i64 128, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %44, %11 ]
  %13 = phi <8 x double> [ zeroinitializer, %1 ], [ %43, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %14, i64 128
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %14, i64 256
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %14, i64 384
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %14, i64 512
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %14, i64 640
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %14, i64 768
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %14, i64 896
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %7, i64 %12
  %31 = load double, ptr %30, align 8
  %32 = insertelement <8 x double> poison, double %15, i64 0
  %33 = insertelement <8 x double> %32, double %17, i64 1
  %34 = insertelement <8 x double> %33, double %19, i64 2
  %35 = insertelement <8 x double> %34, double %21, i64 3
  %36 = insertelement <8 x double> %35, double %23, i64 4
  %37 = insertelement <8 x double> %36, double %25, i64 5
  %38 = insertelement <8 x double> %37, double %27, i64 6
  %39 = insertelement <8 x double> %38, double %29, i64 7
  %40 = insertelement <8 x double> poison, double %31, i64 0
  %41 = shufflevector <8 x double> %40, <8 x double> poison, <8 x i32> zeroinitializer
  %42 = fmul <8 x double> %39, %41
  %43 = fadd <8 x double> %13, %42
  store <8 x double> %43, ptr %10, align 8
  %44 = add nuw nsw i64 %12, 1
  %exitcond.not.i = icmp eq i64 %44, 128
  br i1 %exitcond.not.i, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %45 = getelementptr double, ptr %10, i64 8
  br label %46

46:                                               ; preds = %46, %.preheader.1.i
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %80, %46 ]
  %48 = phi <8 x double> [ zeroinitializer, %.preheader.1.i ], [ %79, %46 ]
  %49 = getelementptr double, ptr %4, i64 %47
  %50 = getelementptr double, ptr %49, i64 1024
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %49, i64 1152
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %49, i64 1280
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %49, i64 1408
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %49, i64 1536
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %49, i64 1664
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %49, i64 1792
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %49, i64 1920
  %65 = load double, ptr %64, align 8
  %66 = getelementptr double, ptr %7, i64 %47
  %67 = load double, ptr %66, align 8
  %68 = insertelement <8 x double> poison, double %51, i64 0
  %69 = insertelement <8 x double> %68, double %53, i64 1
  %70 = insertelement <8 x double> %69, double %55, i64 2
  %71 = insertelement <8 x double> %70, double %57, i64 3
  %72 = insertelement <8 x double> %71, double %59, i64 4
  %73 = insertelement <8 x double> %72, double %61, i64 5
  %74 = insertelement <8 x double> %73, double %63, i64 6
  %75 = insertelement <8 x double> %74, double %65, i64 7
  %76 = insertelement <8 x double> poison, double %67, i64 0
  %77 = shufflevector <8 x double> %76, <8 x double> poison, <8 x i32> zeroinitializer
  %78 = fmul <8 x double> %75, %77
  %79 = fadd <8 x double> %48, %78
  store <8 x double> %79, ptr %45, align 8
  %80 = add nuw nsw i64 %47, 1
  %exitcond.1.not.i = icmp eq i64 %80, 128
  br i1 %exitcond.1.not.i, label %kernel.exit, label %46

kernel.exit:                                      ; preds = %46
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28.i, i8 0, i64 128, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi i64 [ 0, %1 ], [ %43, %10 ]
  %12 = phi <8 x double> [ zeroinitializer, %1 ], [ %42, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 384
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %13, i64 512
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %13, i64 640
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %13, i64 768
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %13, i64 896
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %.unpack17.i, i64 %11
  %30 = load double, ptr %29, align 8
  %31 = insertelement <8 x double> poison, double %14, i64 0
  %32 = insertelement <8 x double> %31, double %16, i64 1
  %33 = insertelement <8 x double> %32, double %18, i64 2
  %34 = insertelement <8 x double> %33, double %20, i64 3
  %35 = insertelement <8 x double> %34, double %22, i64 4
  %36 = insertelement <8 x double> %35, double %24, i64 5
  %37 = insertelement <8 x double> %36, double %26, i64 6
  %38 = insertelement <8 x double> %37, double %28, i64 7
  %39 = insertelement <8 x double> poison, double %30, i64 0
  %40 = shufflevector <8 x double> %39, <8 x double> poison, <8 x i32> zeroinitializer
  %41 = fmul <8 x double> %38, %40
  %42 = fadd <8 x double> %12, %41
  store <8 x double> %42, ptr %.unpack28.i, align 8
  %43 = add nuw nsw i64 %11, 1
  %exitcond.not.i.i = icmp eq i64 %43, 128
  br i1 %exitcond.not.i.i, label %.preheader.1.i.i, label %10

.preheader.1.i.i:                                 ; preds = %10
  %44 = getelementptr double, ptr %.unpack28.i, i64 8
  br label %45

45:                                               ; preds = %45, %.preheader.1.i.i
  %46 = phi i64 [ 0, %.preheader.1.i.i ], [ %79, %45 ]
  %47 = phi <8 x double> [ zeroinitializer, %.preheader.1.i.i ], [ %78, %45 ]
  %48 = getelementptr double, ptr %.unpack2.i, i64 %46
  %49 = getelementptr double, ptr %48, i64 1024
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %48, i64 1152
  %52 = load double, ptr %51, align 8
  %53 = getelementptr double, ptr %48, i64 1280
  %54 = load double, ptr %53, align 8
  %55 = getelementptr double, ptr %48, i64 1408
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %48, i64 1536
  %58 = load double, ptr %57, align 8
  %59 = getelementptr double, ptr %48, i64 1664
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %48, i64 1792
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %48, i64 1920
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %.unpack17.i, i64 %46
  %66 = load double, ptr %65, align 8
  %67 = insertelement <8 x double> poison, double %50, i64 0
  %68 = insertelement <8 x double> %67, double %52, i64 1
  %69 = insertelement <8 x double> %68, double %54, i64 2
  %70 = insertelement <8 x double> %69, double %56, i64 3
  %71 = insertelement <8 x double> %70, double %58, i64 4
  %72 = insertelement <8 x double> %71, double %60, i64 5
  %73 = insertelement <8 x double> %72, double %62, i64 6
  %74 = insertelement <8 x double> %73, double %64, i64 7
  %75 = insertelement <8 x double> poison, double %66, i64 0
  %76 = shufflevector <8 x double> %75, <8 x double> poison, <8 x i32> zeroinitializer
  %77 = fmul <8 x double> %74, %76
  %78 = fadd <8 x double> %47, %77
  store <8 x double> %78, ptr %44, align 8
  %79 = add nuw nsw i64 %46, 1
  %exitcond.1.not.i.i = icmp eq i64 %79, 128
  br i1 %exitcond.1.not.i.i, label %_mlir_ciface_kernel.exit, label %45

_mlir_ciface_kernel.exit:                         ; preds = %45
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
