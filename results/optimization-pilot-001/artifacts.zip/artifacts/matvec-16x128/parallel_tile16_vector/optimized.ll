; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %17

17:                                               ; preds = %.preheader, %17
  %18 = phi i64 [ 0, %.preheader ], [ %74, %17 ]
  %19 = phi <16 x double> [ zeroinitializer, %.preheader ], [ %73, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 128
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 256
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 384
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %20, i64 512
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %20, i64 640
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %20, i64 768
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %20, i64 896
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %20, i64 1024
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %20, i64 1152
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %20, i64 1280
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %20, i64 1408
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %20, i64 1536
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %20, i64 1664
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %20, i64 1792
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %20, i64 1920
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %8, i64 %18
  %53 = load double, ptr %52, align 8
  %54 = insertelement <16 x double> poison, double %21, i64 0
  %55 = insertelement <16 x double> %54, double %23, i64 1
  %56 = insertelement <16 x double> %55, double %25, i64 2
  %57 = insertelement <16 x double> %56, double %27, i64 3
  %58 = insertelement <16 x double> %57, double %29, i64 4
  %59 = insertelement <16 x double> %58, double %31, i64 5
  %60 = insertelement <16 x double> %59, double %33, i64 6
  %61 = insertelement <16 x double> %60, double %35, i64 7
  %62 = insertelement <16 x double> %61, double %37, i64 8
  %63 = insertelement <16 x double> %62, double %39, i64 9
  %64 = insertelement <16 x double> %63, double %41, i64 10
  %65 = insertelement <16 x double> %64, double %43, i64 11
  %66 = insertelement <16 x double> %65, double %45, i64 12
  %67 = insertelement <16 x double> %66, double %47, i64 13
  %68 = insertelement <16 x double> %67, double %49, i64 14
  %69 = insertelement <16 x double> %68, double %51, i64 15
  %70 = insertelement <16 x double> poison, double %53, i64 0
  %71 = shufflevector <16 x double> %70, <16 x double> poison, <16 x i32> zeroinitializer
  %72 = fmul <16 x double> %69, %71
  %73 = fadd <16 x double> %19, %72
  store <16 x double> %73, ptr %13, align 8
  %74 = add nuw nsw i64 %18, 1
  %exitcond.not = icmp eq i64 %74, 128
  br i1 %exitcond.not, label %75, label %17

75:                                               ; preds = %17
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28, i8 0, i64 128, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %61, %4 ]
  %6 = phi <16 x double> [ zeroinitializer, %3 ], [ %60, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %7, i64 128
  %10 = load double, ptr %9, align 8
  %11 = getelementptr double, ptr %7, i64 256
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %7, i64 384
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %7, i64 512
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %7, i64 640
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %7, i64 768
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %7, i64 896
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %7, i64 1024
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %7, i64 1152
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %7, i64 1280
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %7, i64 1408
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %7, i64 1536
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %7, i64 1664
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %7, i64 1792
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %7, i64 1920
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %.unpack17, i64 %5
  %40 = load double, ptr %39, align 8
  %41 = insertelement <16 x double> poison, double %8, i64 0
  %42 = insertelement <16 x double> %41, double %10, i64 1
  %43 = insertelement <16 x double> %42, double %12, i64 2
  %44 = insertelement <16 x double> %43, double %14, i64 3
  %45 = insertelement <16 x double> %44, double %16, i64 4
  %46 = insertelement <16 x double> %45, double %18, i64 5
  %47 = insertelement <16 x double> %46, double %20, i64 6
  %48 = insertelement <16 x double> %47, double %22, i64 7
  %49 = insertelement <16 x double> %48, double %24, i64 8
  %50 = insertelement <16 x double> %49, double %26, i64 9
  %51 = insertelement <16 x double> %50, double %28, i64 10
  %52 = insertelement <16 x double> %51, double %30, i64 11
  %53 = insertelement <16 x double> %52, double %32, i64 12
  %54 = insertelement <16 x double> %53, double %34, i64 13
  %55 = insertelement <16 x double> %54, double %36, i64 14
  %56 = insertelement <16 x double> %55, double %38, i64 15
  %57 = insertelement <16 x double> poison, double %40, i64 0
  %58 = shufflevector <16 x double> %57, <16 x double> poison, <16 x i32> zeroinitializer
  %59 = fmul <16 x double> %56, %58
  %60 = fadd <16 x double> %6, %59
  store <16 x double> %60, ptr %.unpack28, align 8
  %61 = add nuw nsw i64 %5, 1
  %exitcond.not.i = icmp eq i64 %61, 128
  br i1 %exitcond.not.i, label %kernel.exit, label %4

kernel.exit:                                      ; preds = %4
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %10, i8 0, i64 128, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %68, %11 ]
  %13 = phi <16 x double> [ zeroinitializer, %1 ], [ %67, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %14, i64 128
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %14, i64 256
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %14, i64 384
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %14, i64 512
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %14, i64 640
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %14, i64 768
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %14, i64 896
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %14, i64 1024
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %14, i64 1152
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %14, i64 1280
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %14, i64 1408
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %14, i64 1536
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %14, i64 1664
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %14, i64 1792
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %14, i64 1920
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %7, i64 %12
  %47 = load double, ptr %46, align 8
  %48 = insertelement <16 x double> poison, double %15, i64 0
  %49 = insertelement <16 x double> %48, double %17, i64 1
  %50 = insertelement <16 x double> %49, double %19, i64 2
  %51 = insertelement <16 x double> %50, double %21, i64 3
  %52 = insertelement <16 x double> %51, double %23, i64 4
  %53 = insertelement <16 x double> %52, double %25, i64 5
  %54 = insertelement <16 x double> %53, double %27, i64 6
  %55 = insertelement <16 x double> %54, double %29, i64 7
  %56 = insertelement <16 x double> %55, double %31, i64 8
  %57 = insertelement <16 x double> %56, double %33, i64 9
  %58 = insertelement <16 x double> %57, double %35, i64 10
  %59 = insertelement <16 x double> %58, double %37, i64 11
  %60 = insertelement <16 x double> %59, double %39, i64 12
  %61 = insertelement <16 x double> %60, double %41, i64 13
  %62 = insertelement <16 x double> %61, double %43, i64 14
  %63 = insertelement <16 x double> %62, double %45, i64 15
  %64 = insertelement <16 x double> poison, double %47, i64 0
  %65 = shufflevector <16 x double> %64, <16 x double> poison, <16 x i32> zeroinitializer
  %66 = fmul <16 x double> %63, %65
  %67 = fadd <16 x double> %13, %66
  store <16 x double> %67, ptr %10, align 8
  %68 = add nuw nsw i64 %12, 1
  %exitcond.not.i = icmp eq i64 %68, 128
  br i1 %exitcond.not.i, label %kernel.exit, label %11

kernel.exit:                                      ; preds = %11
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28.i, i8 0, i64 128, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi i64 [ 0, %1 ], [ %67, %10 ]
  %12 = phi <16 x double> [ zeroinitializer, %1 ], [ %66, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 384
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %13, i64 512
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %13, i64 640
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %13, i64 768
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %13, i64 896
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %13, i64 1024
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %13, i64 1152
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %13, i64 1280
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %13, i64 1408
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %13, i64 1536
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %13, i64 1664
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %13, i64 1792
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %13, i64 1920
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %.unpack17.i, i64 %11
  %46 = load double, ptr %45, align 8
  %47 = insertelement <16 x double> poison, double %14, i64 0
  %48 = insertelement <16 x double> %47, double %16, i64 1
  %49 = insertelement <16 x double> %48, double %18, i64 2
  %50 = insertelement <16 x double> %49, double %20, i64 3
  %51 = insertelement <16 x double> %50, double %22, i64 4
  %52 = insertelement <16 x double> %51, double %24, i64 5
  %53 = insertelement <16 x double> %52, double %26, i64 6
  %54 = insertelement <16 x double> %53, double %28, i64 7
  %55 = insertelement <16 x double> %54, double %30, i64 8
  %56 = insertelement <16 x double> %55, double %32, i64 9
  %57 = insertelement <16 x double> %56, double %34, i64 10
  %58 = insertelement <16 x double> %57, double %36, i64 11
  %59 = insertelement <16 x double> %58, double %38, i64 12
  %60 = insertelement <16 x double> %59, double %40, i64 13
  %61 = insertelement <16 x double> %60, double %42, i64 14
  %62 = insertelement <16 x double> %61, double %44, i64 15
  %63 = insertelement <16 x double> poison, double %46, i64 0
  %64 = shufflevector <16 x double> %63, <16 x double> poison, <16 x i32> zeroinitializer
  %65 = fmul <16 x double> %62, %64
  %66 = fadd <16 x double> %12, %65
  store <16 x double> %66, ptr %.unpack28.i, align 8
  %67 = add nuw nsw i64 %11, 1
  %exitcond.not.i.i = icmp eq i64 %67, 128
  br i1 %exitcond.not.i.i, label %_mlir_ciface_kernel.exit, label %10

_mlir_ciface_kernel.exit:                         ; preds = %10
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
