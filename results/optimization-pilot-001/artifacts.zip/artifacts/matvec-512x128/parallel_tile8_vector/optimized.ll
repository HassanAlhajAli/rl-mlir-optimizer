; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %13, i8 0, i64 4096, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %53
  %17 = phi i64 [ %54, %53 ], [ 0, %.preheader.preheader ]
  %18 = shl nuw nsw i64 %17, 7
  %19 = getelementptr double, ptr %13, i64 %17
  %.promoted = load <8 x double>, ptr %19, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %18
  br label %20

20:                                               ; preds = %.preheader, %20
  %21 = phi i64 [ 0, %.preheader ], [ %52, %20 ]
  %22 = phi <8 x double> [ %.promoted, %.preheader ], [ %51, %20 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %21
  %23 = load double, ptr %gep, align 8
  %24 = getelementptr double, ptr %gep, i64 128
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep, i64 256
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep, i64 384
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep, i64 512
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep, i64 640
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep, i64 768
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep, i64 896
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %8, i64 %21
  %39 = load double, ptr %38, align 8
  %40 = insertelement <8 x double> poison, double %23, i64 0
  %41 = insertelement <8 x double> %40, double %25, i64 1
  %42 = insertelement <8 x double> %41, double %27, i64 2
  %43 = insertelement <8 x double> %42, double %29, i64 3
  %44 = insertelement <8 x double> %43, double %31, i64 4
  %45 = insertelement <8 x double> %44, double %33, i64 5
  %46 = insertelement <8 x double> %45, double %35, i64 6
  %47 = insertelement <8 x double> %46, double %37, i64 7
  %48 = insertelement <8 x double> poison, double %39, i64 0
  %49 = shufflevector <8 x double> %48, <8 x double> poison, <8 x i32> zeroinitializer
  %50 = fmul <8 x double> %47, %49
  %51 = fadd <8 x double> %22, %50
  store <8 x double> %51, ptr %19, align 8
  %52 = add nuw nsw i64 %21, 1
  %exitcond.not = icmp eq i64 %52, 128
  br i1 %exitcond.not, label %53, label %20

53:                                               ; preds = %20
  %54 = add nuw nsw i64 %17, 8
  %55 = icmp ult i64 %17, 504
  br i1 %55, label %.preheader, label %56

56:                                               ; preds = %53
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack28, i8 0, i64 4096, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %40, %3
  %4 = phi i64 [ %41, %40 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 7
  %6 = getelementptr double, ptr %.unpack28, i64 %4
  %.promoted.i = load <8 x double>, ptr %6, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %7

7:                                                ; preds = %7, %.preheader.i
  %8 = phi i64 [ 0, %.preheader.i ], [ %39, %7 ]
  %9 = phi <8 x double> [ %.promoted.i, %.preheader.i ], [ %38, %7 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %8
  %10 = load double, ptr %gep.i, align 8
  %11 = getelementptr double, ptr %gep.i, i64 128
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %gep.i, i64 256
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %gep.i, i64 384
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %gep.i, i64 512
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i, i64 640
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i, i64 768
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i, i64 896
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %.unpack17, i64 %8
  %26 = load double, ptr %25, align 8
  %27 = insertelement <8 x double> poison, double %10, i64 0
  %28 = insertelement <8 x double> %27, double %12, i64 1
  %29 = insertelement <8 x double> %28, double %14, i64 2
  %30 = insertelement <8 x double> %29, double %16, i64 3
  %31 = insertelement <8 x double> %30, double %18, i64 4
  %32 = insertelement <8 x double> %31, double %20, i64 5
  %33 = insertelement <8 x double> %32, double %22, i64 6
  %34 = insertelement <8 x double> %33, double %24, i64 7
  %35 = insertelement <8 x double> poison, double %26, i64 0
  %36 = shufflevector <8 x double> %35, <8 x double> poison, <8 x i32> zeroinitializer
  %37 = fmul <8 x double> %34, %36
  %38 = fadd <8 x double> %9, %37
  store <8 x double> %38, ptr %6, align 8
  %39 = add nuw nsw i64 %8, 1
  %exitcond.not.i = icmp eq i64 %39, 128
  br i1 %exitcond.not.i, label %40, label %7

40:                                               ; preds = %7
  %41 = add nuw nsw i64 %4, 8
  %42 = icmp ult i64 %4, 504
  br i1 %42, label %.preheader.i, label %kernel.exit

kernel.exit:                                      ; preds = %40
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %10, i8 0, i64 4096, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %47, %1
  %11 = phi i64 [ %48, %47 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 7
  %13 = getelementptr double, ptr %10, i64 %11
  %.promoted.i = load <8 x double>, ptr %13, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %12
  br label %14

14:                                               ; preds = %14, %.preheader.i
  %15 = phi i64 [ 0, %.preheader.i ], [ %46, %14 ]
  %16 = phi <8 x double> [ %.promoted.i, %.preheader.i ], [ %45, %14 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %17 = load double, ptr %gep.i, align 8
  %18 = getelementptr double, ptr %gep.i, i64 128
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 256
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 384
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i, i64 512
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep.i, i64 640
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep.i, i64 768
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep.i, i64 896
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %7, i64 %15
  %33 = load double, ptr %32, align 8
  %34 = insertelement <8 x double> poison, double %17, i64 0
  %35 = insertelement <8 x double> %34, double %19, i64 1
  %36 = insertelement <8 x double> %35, double %21, i64 2
  %37 = insertelement <8 x double> %36, double %23, i64 3
  %38 = insertelement <8 x double> %37, double %25, i64 4
  %39 = insertelement <8 x double> %38, double %27, i64 5
  %40 = insertelement <8 x double> %39, double %29, i64 6
  %41 = insertelement <8 x double> %40, double %31, i64 7
  %42 = insertelement <8 x double> poison, double %33, i64 0
  %43 = shufflevector <8 x double> %42, <8 x double> poison, <8 x i32> zeroinitializer
  %44 = fmul <8 x double> %41, %43
  %45 = fadd <8 x double> %16, %44
  store <8 x double> %45, ptr %13, align 8
  %46 = add nuw nsw i64 %15, 1
  %exitcond.not.i = icmp eq i64 %46, 128
  br i1 %exitcond.not.i, label %47, label %14

47:                                               ; preds = %14
  %48 = add nuw nsw i64 %11, 8
  %49 = icmp ult i64 %11, 504
  br i1 %49, label %.preheader.i, label %kernel.exit

kernel.exit:                                      ; preds = %47
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack28.i, i8 0, i64 4096, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %46, %1
  %10 = phi i64 [ %47, %46 ], [ 0, %1 ]
  %11 = shl nuw nsw i64 %10, 7
  %12 = getelementptr double, ptr %.unpack28.i, i64 %10
  %.promoted.i.i = load <8 x double>, ptr %12, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %13

13:                                               ; preds = %13, %.preheader.i.i
  %14 = phi i64 [ 0, %.preheader.i.i ], [ %45, %13 ]
  %15 = phi <8 x double> [ %.promoted.i.i, %.preheader.i.i ], [ %44, %13 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %14
  %16 = load double, ptr %gep.i.i, align 8
  %17 = getelementptr double, ptr %gep.i.i, i64 128
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i.i, i64 256
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i.i, i64 384
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i.i, i64 512
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %gep.i.i, i64 640
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep.i.i, i64 768
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep.i.i, i64 896
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %.unpack17.i, i64 %14
  %32 = load double, ptr %31, align 8
  %33 = insertelement <8 x double> poison, double %16, i64 0
  %34 = insertelement <8 x double> %33, double %18, i64 1
  %35 = insertelement <8 x double> %34, double %20, i64 2
  %36 = insertelement <8 x double> %35, double %22, i64 3
  %37 = insertelement <8 x double> %36, double %24, i64 4
  %38 = insertelement <8 x double> %37, double %26, i64 5
  %39 = insertelement <8 x double> %38, double %28, i64 6
  %40 = insertelement <8 x double> %39, double %30, i64 7
  %41 = insertelement <8 x double> poison, double %32, i64 0
  %42 = shufflevector <8 x double> %41, <8 x double> poison, <8 x i32> zeroinitializer
  %43 = fmul <8 x double> %40, %42
  %44 = fadd <8 x double> %15, %43
  store <8 x double> %44, ptr %12, align 8
  %45 = add nuw nsw i64 %14, 1
  %exitcond.not.i.i = icmp eq i64 %45, 128
  br i1 %exitcond.not.i.i, label %46, label %13

46:                                               ; preds = %13
  %47 = add nuw nsw i64 %10, 8
  %48 = icmp ult i64 %10, 504
  br i1 %48, label %.preheader.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %46
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
