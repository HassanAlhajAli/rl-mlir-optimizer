; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(8192) %15, i8 0, i64 8192, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep57 = getelementptr double, ptr %8, i64 8
  %invariant.gep41 = getelementptr double, ptr %8, i64 16
  %invariant.gep27 = getelementptr double, ptr %8, i64 24
  %invariant.gep63 = getelementptr double, ptr %8, i64 12
  %invariant.gep47 = getelementptr double, ptr %8, i64 20
  %invariant.gep32 = getelementptr double, ptr %8, i64 28
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %381
  %21 = phi i64 [ %382, %381 ], [ 0, %.preheader17.preheader ]
  %22 = shl nuw nsw i64 %21, 5
  %23 = getelementptr double, ptr %15, i64 %22
  %invariant.gep77 = getelementptr double, ptr %1, i64 %22
  %invariant.gep79 = getelementptr double, ptr %1, i64 %22
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17, %112
  %24 = phi i64 [ 0, %.preheader17 ], [ %113, %112 ]
  %25 = shl i64 %24, 5
  %26 = getelementptr double, ptr %23, i64 %25
  %.promoted = load <4 x double>, ptr %26, align 8
  %gep78 = getelementptr double, ptr %invariant.gep77, i64 %25
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %27 = phi i64 [ 0, %.preheader16 ], [ %68, %.critedge ]
  %28 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %67, %.critedge ]
  %29 = shl nuw nsw i64 %27, 5
  %gep76 = getelementptr double, ptr %gep78, i64 %27
  %30 = load double, ptr %gep76, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %32 = getelementptr double, ptr %8, i64 %29
  %33 = load <4 x double>, ptr %32, align 8
  %34 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> zeroinitializer
  %35 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 1>
  %36 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 2>
  %37 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 3>
  %38 = fmul <1 x double> %31, %34
  %39 = fmul <1 x double> %31, %35
  %40 = fmul <1 x double> %31, %36
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = fmul <1 x double> %31, %37
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <1 x double> %38, <1 x double> %39, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %47 = fadd <4 x double> %28, %46
  store <4 x double> %47, ptr %26, align 8
  %48 = or disjoint i64 %27, 1
  %49 = shl nuw nsw i64 %48, 5
  %gep76.1 = getelementptr double, ptr %gep78, i64 %48
  %50 = load double, ptr %gep76.1, align 8
  %51 = insertelement <1 x double> poison, double %50, i64 0
  %52 = getelementptr double, ptr %8, i64 %49
  %53 = load <4 x double>, ptr %52, align 8
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> zeroinitializer
  %55 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 1>
  %56 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 2>
  %57 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 3>
  %58 = fmul <1 x double> %51, %54
  %59 = fmul <1 x double> %51, %55
  %60 = fmul <1 x double> %51, %56
  %61 = shufflevector <1 x double> %60, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %62 = fmul <1 x double> %51, %57
  %63 = shufflevector <1 x double> %62, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <1 x double> %58, <1 x double> %59, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %65 = shufflevector <4 x double> %64, <4 x double> %61, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %63, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %67 = fadd <4 x double> %47, %66
  store <4 x double> %67, ptr %26, align 8
  %68 = add nuw nsw i64 %27, 2
  %exitcond.not.1 = icmp eq i64 %68, 32
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %69 = getelementptr double, ptr %26, i64 4
  %.promoted.1 = load <4 x double>, ptr %69, align 8
  %gep80 = getelementptr double, ptr %invariant.gep79, i64 %25
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %70 = phi i64 [ 0, %.preheader.1 ], [ %111, %.critedge.1 ]
  %71 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %110, %.critedge.1 ]
  %72 = shl nuw nsw i64 %70, 5
  %gep72 = getelementptr double, ptr %gep80, i64 %70
  %73 = load double, ptr %gep72, align 8
  %74 = insertelement <1 x double> poison, double %73, i64 0
  %75 = getelementptr double, ptr %invariant.gep.1, i64 %72
  %76 = load <4 x double>, ptr %75, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %74, %77
  %82 = fmul <1 x double> %74, %78
  %83 = fmul <1 x double> %74, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %74, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %71, %89
  store <4 x double> %90, ptr %69, align 8
  %91 = or disjoint i64 %70, 1
  %92 = shl nuw nsw i64 %91, 5
  %gep72.1 = getelementptr double, ptr %gep80, i64 %91
  %93 = load double, ptr %gep72.1, align 8
  %94 = insertelement <1 x double> poison, double %93, i64 0
  %95 = getelementptr double, ptr %invariant.gep.1, i64 %92
  %96 = load <4 x double>, ptr %95, align 8
  %97 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> zeroinitializer
  %98 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 1>
  %99 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 2>
  %100 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 3>
  %101 = fmul <1 x double> %94, %97
  %102 = fmul <1 x double> %94, %98
  %103 = fmul <1 x double> %94, %99
  %104 = shufflevector <1 x double> %103, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %105 = fmul <1 x double> %94, %100
  %106 = shufflevector <1 x double> %105, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %107 = shufflevector <1 x double> %101, <1 x double> %102, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %104, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %109 = shufflevector <4 x double> %108, <4 x double> %106, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %110 = fadd <4 x double> %90, %109
  store <4 x double> %110, ptr %69, align 8
  %111 = add nuw nsw i64 %70, 2
  %exitcond.1.not.1 = icmp eq i64 %111, 32
  br i1 %exitcond.1.not.1, label %112, label %.critedge.1

112:                                              ; preds = %.critedge.1
  %113 = add nuw nsw i64 %24, 1
  %exitcond19.not = icmp eq i64 %113, 8
  br i1 %exitcond19.not, label %114, label %.preheader16

114:                                              ; preds = %112
  %115 = or disjoint i64 %22, 8
  %116 = getelementptr double, ptr %15, i64 %115
  %invariant.gep65 = getelementptr double, ptr %1, i64 %22
  %invariant.gep67 = getelementptr double, ptr %1, i64 %22
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %201, %114
  %117 = phi i64 [ 0, %114 ], [ %202, %201 ]
  %118 = shl i64 %117, 5
  %119 = getelementptr double, ptr %116, i64 %118
  %.promoted.120 = load <4 x double>, ptr %119, align 8
  %gep66 = getelementptr double, ptr %invariant.gep65, i64 %118
  br label %.critedge.124

.critedge.124:                                    ; preds = %.critedge.124, %.preheader16.1
  %120 = phi i64 [ 0, %.preheader16.1 ], [ %159, %.critedge.124 ]
  %121 = phi <4 x double> [ %.promoted.120, %.preheader16.1 ], [ %158, %.critedge.124 ]
  %122 = shl nuw nsw i64 %120, 5
  %gep56 = getelementptr double, ptr %gep66, i64 %120
  %123 = load double, ptr %gep56, align 8
  %124 = insertelement <1 x double> poison, double %123, i64 0
  %gep58 = getelementptr double, ptr %invariant.gep57, i64 %122
  %125 = load <4 x double>, ptr %gep58, align 8
  %126 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> zeroinitializer
  %127 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 1>
  %128 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 2>
  %129 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 3>
  %130 = fmul <1 x double> %124, %126
  %131 = fmul <1 x double> %124, %127
  %132 = fmul <1 x double> %124, %128
  %133 = shufflevector <1 x double> %132, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %134 = fmul <1 x double> %124, %129
  %135 = shufflevector <1 x double> %134, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %136 = shufflevector <1 x double> %130, <1 x double> %131, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %137 = shufflevector <4 x double> %136, <4 x double> %133, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %138 = shufflevector <4 x double> %137, <4 x double> %135, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %139 = fadd <4 x double> %121, %138
  store <4 x double> %139, ptr %119, align 8
  %140 = or disjoint i64 %120, 1
  %141 = shl nuw nsw i64 %140, 5
  %gep56.1 = getelementptr double, ptr %gep66, i64 %140
  %142 = load double, ptr %gep56.1, align 8
  %143 = insertelement <1 x double> poison, double %142, i64 0
  %gep58.1 = getelementptr double, ptr %invariant.gep57, i64 %141
  %144 = load <4 x double>, ptr %gep58.1, align 8
  %145 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> zeroinitializer
  %146 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 1>
  %147 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 2>
  %148 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 3>
  %149 = fmul <1 x double> %143, %145
  %150 = fmul <1 x double> %143, %146
  %151 = fmul <1 x double> %143, %147
  %152 = shufflevector <1 x double> %151, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %153 = fmul <1 x double> %143, %148
  %154 = shufflevector <1 x double> %153, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %155 = shufflevector <1 x double> %149, <1 x double> %150, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %156 = shufflevector <4 x double> %155, <4 x double> %152, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %157 = shufflevector <4 x double> %156, <4 x double> %154, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %158 = fadd <4 x double> %139, %157
  store <4 x double> %158, ptr %119, align 8
  %159 = add nuw nsw i64 %120, 2
  %exitcond.123.not.1 = icmp eq i64 %159, 32
  br i1 %exitcond.123.not.1, label %.preheader.1.1, label %.critedge.124

.preheader.1.1:                                   ; preds = %.critedge.124
  %160 = getelementptr double, ptr %119, i64 4
  %.promoted.1.1 = load <4 x double>, ptr %160, align 8
  %gep68 = getelementptr double, ptr %invariant.gep67, i64 %118
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1, %.preheader.1.1
  %161 = phi i64 [ 0, %.preheader.1.1 ], [ %200, %.critedge.1.1 ]
  %162 = phi <4 x double> [ %.promoted.1.1, %.preheader.1.1 ], [ %199, %.critedge.1.1 ]
  %163 = shl nuw nsw i64 %161, 5
  %gep62 = getelementptr double, ptr %gep68, i64 %161
  %164 = load double, ptr %gep62, align 8
  %165 = insertelement <1 x double> poison, double %164, i64 0
  %gep64 = getelementptr double, ptr %invariant.gep63, i64 %163
  %166 = load <4 x double>, ptr %gep64, align 8
  %167 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> zeroinitializer
  %168 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 1>
  %169 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 2>
  %170 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 3>
  %171 = fmul <1 x double> %165, %167
  %172 = fmul <1 x double> %165, %168
  %173 = fmul <1 x double> %165, %169
  %174 = shufflevector <1 x double> %173, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %175 = fmul <1 x double> %165, %170
  %176 = shufflevector <1 x double> %175, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %177 = shufflevector <1 x double> %171, <1 x double> %172, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %174, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %176, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %180 = fadd <4 x double> %162, %179
  store <4 x double> %180, ptr %160, align 8
  %181 = or disjoint i64 %161, 1
  %182 = shl nuw nsw i64 %181, 5
  %gep62.1 = getelementptr double, ptr %gep68, i64 %181
  %183 = load double, ptr %gep62.1, align 8
  %184 = insertelement <1 x double> poison, double %183, i64 0
  %gep64.1 = getelementptr double, ptr %invariant.gep63, i64 %182
  %185 = load <4 x double>, ptr %gep64.1, align 8
  %186 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> zeroinitializer
  %187 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 1>
  %188 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 2>
  %189 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 3>
  %190 = fmul <1 x double> %184, %186
  %191 = fmul <1 x double> %184, %187
  %192 = fmul <1 x double> %184, %188
  %193 = shufflevector <1 x double> %192, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %194 = fmul <1 x double> %184, %189
  %195 = shufflevector <1 x double> %194, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %196 = shufflevector <1 x double> %190, <1 x double> %191, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %197 = shufflevector <4 x double> %196, <4 x double> %193, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %198 = shufflevector <4 x double> %197, <4 x double> %195, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %199 = fadd <4 x double> %180, %198
  store <4 x double> %199, ptr %160, align 8
  %200 = add nuw nsw i64 %161, 2
  %exitcond.1.1.not.1 = icmp eq i64 %200, 32
  br i1 %exitcond.1.1.not.1, label %201, label %.critedge.1.1

201:                                              ; preds = %.critedge.1.1
  %202 = add nuw nsw i64 %117, 1
  %exitcond19.1.not = icmp eq i64 %202, 8
  br i1 %exitcond19.1.not, label %203, label %.preheader16.1

203:                                              ; preds = %201
  %204 = or disjoint i64 %22, 16
  %205 = getelementptr double, ptr %15, i64 %204
  %invariant.gep49 = getelementptr double, ptr %1, i64 %22
  %invariant.gep51 = getelementptr double, ptr %1, i64 %22
  br label %.preheader16.2

.preheader16.2:                                   ; preds = %290, %203
  %206 = phi i64 [ 0, %203 ], [ %291, %290 ]
  %207 = shl i64 %206, 5
  %208 = getelementptr double, ptr %205, i64 %207
  %.promoted.2 = load <4 x double>, ptr %208, align 8
  %gep50 = getelementptr double, ptr %invariant.gep49, i64 %207
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader16.2
  %209 = phi i64 [ 0, %.preheader16.2 ], [ %248, %.critedge.2 ]
  %210 = phi <4 x double> [ %.promoted.2, %.preheader16.2 ], [ %247, %.critedge.2 ]
  %211 = shl nuw nsw i64 %209, 5
  %gep40 = getelementptr double, ptr %gep50, i64 %209
  %212 = load double, ptr %gep40, align 8
  %213 = insertelement <1 x double> poison, double %212, i64 0
  %gep42 = getelementptr double, ptr %invariant.gep41, i64 %211
  %214 = load <4 x double>, ptr %gep42, align 8
  %215 = shufflevector <4 x double> %214, <4 x double> poison, <1 x i32> zeroinitializer
  %216 = shufflevector <4 x double> %214, <4 x double> poison, <1 x i32> <i32 1>
  %217 = shufflevector <4 x double> %214, <4 x double> poison, <1 x i32> <i32 2>
  %218 = shufflevector <4 x double> %214, <4 x double> poison, <1 x i32> <i32 3>
  %219 = fmul <1 x double> %213, %215
  %220 = fmul <1 x double> %213, %216
  %221 = fmul <1 x double> %213, %217
  %222 = shufflevector <1 x double> %221, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %223 = fmul <1 x double> %213, %218
  %224 = shufflevector <1 x double> %223, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %225 = shufflevector <1 x double> %219, <1 x double> %220, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %226 = shufflevector <4 x double> %225, <4 x double> %222, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %227 = shufflevector <4 x double> %226, <4 x double> %224, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %228 = fadd <4 x double> %210, %227
  store <4 x double> %228, ptr %208, align 8
  %229 = or disjoint i64 %209, 1
  %230 = shl nuw nsw i64 %229, 5
  %gep40.1 = getelementptr double, ptr %gep50, i64 %229
  %231 = load double, ptr %gep40.1, align 8
  %232 = insertelement <1 x double> poison, double %231, i64 0
  %gep42.1 = getelementptr double, ptr %invariant.gep41, i64 %230
  %233 = load <4 x double>, ptr %gep42.1, align 8
  %234 = shufflevector <4 x double> %233, <4 x double> poison, <1 x i32> zeroinitializer
  %235 = shufflevector <4 x double> %233, <4 x double> poison, <1 x i32> <i32 1>
  %236 = shufflevector <4 x double> %233, <4 x double> poison, <1 x i32> <i32 2>
  %237 = shufflevector <4 x double> %233, <4 x double> poison, <1 x i32> <i32 3>
  %238 = fmul <1 x double> %232, %234
  %239 = fmul <1 x double> %232, %235
  %240 = fmul <1 x double> %232, %236
  %241 = shufflevector <1 x double> %240, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %242 = fmul <1 x double> %232, %237
  %243 = shufflevector <1 x double> %242, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %244 = shufflevector <1 x double> %238, <1 x double> %239, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %245 = shufflevector <4 x double> %244, <4 x double> %241, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %246 = shufflevector <4 x double> %245, <4 x double> %243, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %247 = fadd <4 x double> %228, %246
  store <4 x double> %247, ptr %208, align 8
  %248 = add nuw nsw i64 %209, 2
  %exitcond.2.not.1 = icmp eq i64 %248, 32
  br i1 %exitcond.2.not.1, label %.preheader.1.2, label %.critedge.2

.preheader.1.2:                                   ; preds = %.critedge.2
  %249 = getelementptr double, ptr %208, i64 4
  %.promoted.1.2 = load <4 x double>, ptr %249, align 8
  %gep52 = getelementptr double, ptr %invariant.gep51, i64 %207
  br label %.critedge.1.2

.critedge.1.2:                                    ; preds = %.critedge.1.2, %.preheader.1.2
  %250 = phi i64 [ 0, %.preheader.1.2 ], [ %289, %.critedge.1.2 ]
  %251 = phi <4 x double> [ %.promoted.1.2, %.preheader.1.2 ], [ %288, %.critedge.1.2 ]
  %252 = shl nuw nsw i64 %250, 5
  %gep46 = getelementptr double, ptr %gep52, i64 %250
  %253 = load double, ptr %gep46, align 8
  %254 = insertelement <1 x double> poison, double %253, i64 0
  %gep48 = getelementptr double, ptr %invariant.gep47, i64 %252
  %255 = load <4 x double>, ptr %gep48, align 8
  %256 = shufflevector <4 x double> %255, <4 x double> poison, <1 x i32> zeroinitializer
  %257 = shufflevector <4 x double> %255, <4 x double> poison, <1 x i32> <i32 1>
  %258 = shufflevector <4 x double> %255, <4 x double> poison, <1 x i32> <i32 2>
  %259 = shufflevector <4 x double> %255, <4 x double> poison, <1 x i32> <i32 3>
  %260 = fmul <1 x double> %254, %256
  %261 = fmul <1 x double> %254, %257
  %262 = fmul <1 x double> %254, %258
  %263 = shufflevector <1 x double> %262, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %264 = fmul <1 x double> %254, %259
  %265 = shufflevector <1 x double> %264, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %266 = shufflevector <1 x double> %260, <1 x double> %261, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %267 = shufflevector <4 x double> %266, <4 x double> %263, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %268 = shufflevector <4 x double> %267, <4 x double> %265, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %269 = fadd <4 x double> %251, %268
  store <4 x double> %269, ptr %249, align 8
  %270 = or disjoint i64 %250, 1
  %271 = shl nuw nsw i64 %270, 5
  %gep46.1 = getelementptr double, ptr %gep52, i64 %270
  %272 = load double, ptr %gep46.1, align 8
  %273 = insertelement <1 x double> poison, double %272, i64 0
  %gep48.1 = getelementptr double, ptr %invariant.gep47, i64 %271
  %274 = load <4 x double>, ptr %gep48.1, align 8
  %275 = shufflevector <4 x double> %274, <4 x double> poison, <1 x i32> zeroinitializer
  %276 = shufflevector <4 x double> %274, <4 x double> poison, <1 x i32> <i32 1>
  %277 = shufflevector <4 x double> %274, <4 x double> poison, <1 x i32> <i32 2>
  %278 = shufflevector <4 x double> %274, <4 x double> poison, <1 x i32> <i32 3>
  %279 = fmul <1 x double> %273, %275
  %280 = fmul <1 x double> %273, %276
  %281 = fmul <1 x double> %273, %277
  %282 = shufflevector <1 x double> %281, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %283 = fmul <1 x double> %273, %278
  %284 = shufflevector <1 x double> %283, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %285 = shufflevector <1 x double> %279, <1 x double> %280, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %286 = shufflevector <4 x double> %285, <4 x double> %282, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %287 = shufflevector <4 x double> %286, <4 x double> %284, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %288 = fadd <4 x double> %269, %287
  store <4 x double> %288, ptr %249, align 8
  %289 = add nuw nsw i64 %250, 2
  %exitcond.1.2.not.1 = icmp eq i64 %289, 32
  br i1 %exitcond.1.2.not.1, label %290, label %.critedge.1.2

290:                                              ; preds = %.critedge.1.2
  %291 = add nuw nsw i64 %206, 1
  %exitcond19.2.not = icmp eq i64 %291, 8
  br i1 %exitcond19.2.not, label %292, label %.preheader16.2

292:                                              ; preds = %290
  %293 = or disjoint i64 %22, 24
  %294 = getelementptr double, ptr %15, i64 %293
  %invariant.gep34 = getelementptr double, ptr %1, i64 %22
  %invariant.gep = getelementptr double, ptr %1, i64 %22
  br label %.preheader16.3

.preheader16.3:                                   ; preds = %379, %292
  %295 = phi i64 [ 0, %292 ], [ %380, %379 ]
  %296 = shl i64 %295, 5
  %297 = getelementptr double, ptr %294, i64 %296
  %.promoted.3 = load <4 x double>, ptr %297, align 8
  %gep35 = getelementptr double, ptr %invariant.gep34, i64 %296
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader16.3
  %298 = phi i64 [ 0, %.preheader16.3 ], [ %337, %.critedge.3 ]
  %299 = phi <4 x double> [ %.promoted.3, %.preheader16.3 ], [ %336, %.critedge.3 ]
  %300 = shl nuw nsw i64 %298, 5
  %gep26 = getelementptr double, ptr %gep35, i64 %298
  %301 = load double, ptr %gep26, align 8
  %302 = insertelement <1 x double> poison, double %301, i64 0
  %gep = getelementptr double, ptr %invariant.gep27, i64 %300
  %303 = load <4 x double>, ptr %gep, align 8
  %304 = shufflevector <4 x double> %303, <4 x double> poison, <1 x i32> zeroinitializer
  %305 = shufflevector <4 x double> %303, <4 x double> poison, <1 x i32> <i32 1>
  %306 = shufflevector <4 x double> %303, <4 x double> poison, <1 x i32> <i32 2>
  %307 = shufflevector <4 x double> %303, <4 x double> poison, <1 x i32> <i32 3>
  %308 = fmul <1 x double> %302, %304
  %309 = fmul <1 x double> %302, %305
  %310 = fmul <1 x double> %302, %306
  %311 = shufflevector <1 x double> %310, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %312 = fmul <1 x double> %302, %307
  %313 = shufflevector <1 x double> %312, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %314 = shufflevector <1 x double> %308, <1 x double> %309, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %315 = shufflevector <4 x double> %314, <4 x double> %311, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %316 = shufflevector <4 x double> %315, <4 x double> %313, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %317 = fadd <4 x double> %299, %316
  store <4 x double> %317, ptr %297, align 8
  %318 = or disjoint i64 %298, 1
  %319 = shl nuw nsw i64 %318, 5
  %gep26.1 = getelementptr double, ptr %gep35, i64 %318
  %320 = load double, ptr %gep26.1, align 8
  %321 = insertelement <1 x double> poison, double %320, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep27, i64 %319
  %322 = load <4 x double>, ptr %gep.1, align 8
  %323 = shufflevector <4 x double> %322, <4 x double> poison, <1 x i32> zeroinitializer
  %324 = shufflevector <4 x double> %322, <4 x double> poison, <1 x i32> <i32 1>
  %325 = shufflevector <4 x double> %322, <4 x double> poison, <1 x i32> <i32 2>
  %326 = shufflevector <4 x double> %322, <4 x double> poison, <1 x i32> <i32 3>
  %327 = fmul <1 x double> %321, %323
  %328 = fmul <1 x double> %321, %324
  %329 = fmul <1 x double> %321, %325
  %330 = shufflevector <1 x double> %329, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %331 = fmul <1 x double> %321, %326
  %332 = shufflevector <1 x double> %331, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %333 = shufflevector <1 x double> %327, <1 x double> %328, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %334 = shufflevector <4 x double> %333, <4 x double> %330, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %335 = shufflevector <4 x double> %334, <4 x double> %332, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %336 = fadd <4 x double> %317, %335
  store <4 x double> %336, ptr %297, align 8
  %337 = add nuw nsw i64 %298, 2
  %exitcond.3.not.1 = icmp eq i64 %337, 32
  br i1 %exitcond.3.not.1, label %.preheader.1.3, label %.critedge.3

.preheader.1.3:                                   ; preds = %.critedge.3
  %338 = getelementptr double, ptr %297, i64 4
  %.promoted.1.3 = load <4 x double>, ptr %338, align 8
  %gep36 = getelementptr double, ptr %invariant.gep, i64 %296
  br label %.critedge.1.3

.critedge.1.3:                                    ; preds = %.critedge.1.3, %.preheader.1.3
  %339 = phi i64 [ 0, %.preheader.1.3 ], [ %378, %.critedge.1.3 ]
  %340 = phi <4 x double> [ %.promoted.1.3, %.preheader.1.3 ], [ %377, %.critedge.1.3 ]
  %341 = shl nuw nsw i64 %339, 5
  %gep31 = getelementptr double, ptr %gep36, i64 %339
  %342 = load double, ptr %gep31, align 8
  %343 = insertelement <1 x double> poison, double %342, i64 0
  %gep33 = getelementptr double, ptr %invariant.gep32, i64 %341
  %344 = load <4 x double>, ptr %gep33, align 8
  %345 = shufflevector <4 x double> %344, <4 x double> poison, <1 x i32> zeroinitializer
  %346 = shufflevector <4 x double> %344, <4 x double> poison, <1 x i32> <i32 1>
  %347 = shufflevector <4 x double> %344, <4 x double> poison, <1 x i32> <i32 2>
  %348 = shufflevector <4 x double> %344, <4 x double> poison, <1 x i32> <i32 3>
  %349 = fmul <1 x double> %343, %345
  %350 = fmul <1 x double> %343, %346
  %351 = fmul <1 x double> %343, %347
  %352 = shufflevector <1 x double> %351, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %353 = fmul <1 x double> %343, %348
  %354 = shufflevector <1 x double> %353, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %355 = shufflevector <1 x double> %349, <1 x double> %350, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %356 = shufflevector <4 x double> %355, <4 x double> %352, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %357 = shufflevector <4 x double> %356, <4 x double> %354, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %358 = fadd <4 x double> %340, %357
  store <4 x double> %358, ptr %338, align 8
  %359 = or disjoint i64 %339, 1
  %360 = shl nuw nsw i64 %359, 5
  %gep31.1 = getelementptr double, ptr %gep36, i64 %359
  %361 = load double, ptr %gep31.1, align 8
  %362 = insertelement <1 x double> poison, double %361, i64 0
  %gep33.1 = getelementptr double, ptr %invariant.gep32, i64 %360
  %363 = load <4 x double>, ptr %gep33.1, align 8
  %364 = shufflevector <4 x double> %363, <4 x double> poison, <1 x i32> zeroinitializer
  %365 = shufflevector <4 x double> %363, <4 x double> poison, <1 x i32> <i32 1>
  %366 = shufflevector <4 x double> %363, <4 x double> poison, <1 x i32> <i32 2>
  %367 = shufflevector <4 x double> %363, <4 x double> poison, <1 x i32> <i32 3>
  %368 = fmul <1 x double> %362, %364
  %369 = fmul <1 x double> %362, %365
  %370 = fmul <1 x double> %362, %366
  %371 = shufflevector <1 x double> %370, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %372 = fmul <1 x double> %362, %367
  %373 = shufflevector <1 x double> %372, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %374 = shufflevector <1 x double> %368, <1 x double> %369, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %375 = shufflevector <4 x double> %374, <4 x double> %371, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %376 = shufflevector <4 x double> %375, <4 x double> %373, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %377 = fadd <4 x double> %358, %376
  store <4 x double> %377, ptr %338, align 8
  %378 = add nuw nsw i64 %339, 2
  %exitcond.1.3.not.1 = icmp eq i64 %378, 32
  br i1 %exitcond.1.3.not.1, label %379, label %.critedge.1.3

379:                                              ; preds = %.critedge.1.3
  %380 = add nuw nsw i64 %295, 1
  %exitcond19.3.not = icmp eq i64 %380, 8
  br i1 %exitcond19.3.not, label %381, label %.preheader16.3

381:                                              ; preds = %379
  %382 = add nuw nsw i64 %21, 8
  %383 = icmp ult i64 %21, 24
  br i1 %383, label %.preheader17, label %384

384:                                              ; preds = %381
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
