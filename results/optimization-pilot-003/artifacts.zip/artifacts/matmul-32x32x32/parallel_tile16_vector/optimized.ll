; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(8192) %15, i8 0, i64 8192, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  %invariant.gep46 = getelementptr double, ptr %8, i64 16
  %invariant.gep52 = getelementptr double, ptr %8, i64 20
  %invariant.gep58 = getelementptr double, ptr %8, i64 24
  %invariant.gep64 = getelementptr double, ptr %8, i64 28
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %371
  %21 = phi i1 [ false, %371 ], [ true, %.preheader17.preheader ]
  %22 = phi i64 [ 512, %371 ], [ 0, %.preheader17.preheader ]
  %23 = getelementptr double, ptr %15, i64 %22
  %invariant.gep36 = getelementptr double, ptr %1, i64 %22
  %invariant.gep = getelementptr double, ptr %1, i64 %22
  %invariant.gep38 = getelementptr double, ptr %1, i64 %22
  %invariant.gep40 = getelementptr double, ptr %1, i64 %22
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17, %198
  %24 = phi i64 [ 0, %.preheader17 ], [ %199, %198 ]
  %25 = shl i64 %24, 5
  %26 = getelementptr double, ptr %23, i64 %25
  %.promoted = load <4 x double>, ptr %26, align 8
  %gep = getelementptr double, ptr %invariant.gep36, i64 %25
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %27 = phi i64 [ 0, %.preheader16 ], [ %68, %.critedge ]
  %28 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %67, %.critedge ]
  %29 = shl nuw nsw i64 %27, 5
  %gep26 = getelementptr double, ptr %gep, i64 %27
  %30 = load double, ptr %gep26, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %32 = getelementptr double, ptr %8, i64 %29
  %33 = load <4 x double>, ptr %32, align 8
  %34 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> zeroinitializer
  %35 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 1>
  %36 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 2>
  %37 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 3>
  %38 = fmul <1 x double> %31, %34
  %39 = fmul <1 x double> %31, %35
  %40 = fmul <1 x double> %31, %36
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = fmul <1 x double> %31, %37
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <1 x double> %38, <1 x double> %39, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %47 = fadd <4 x double> %28, %46
  store <4 x double> %47, ptr %26, align 8
  %48 = or disjoint i64 %27, 1
  %49 = shl nuw nsw i64 %48, 5
  %gep26.1 = getelementptr double, ptr %gep, i64 %48
  %50 = load double, ptr %gep26.1, align 8
  %51 = insertelement <1 x double> poison, double %50, i64 0
  %52 = getelementptr double, ptr %8, i64 %49
  %53 = load <4 x double>, ptr %52, align 8
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> zeroinitializer
  %55 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 1>
  %56 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 2>
  %57 = shufflevector <4 x double> %53, <4 x double> poison, <1 x i32> <i32 3>
  %58 = fmul <1 x double> %51, %54
  %59 = fmul <1 x double> %51, %55
  %60 = fmul <1 x double> %51, %56
  %61 = shufflevector <1 x double> %60, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %62 = fmul <1 x double> %51, %57
  %63 = shufflevector <1 x double> %62, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <1 x double> %58, <1 x double> %59, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %65 = shufflevector <4 x double> %64, <4 x double> %61, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %63, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %67 = fadd <4 x double> %47, %66
  store <4 x double> %67, ptr %26, align 8
  %68 = add nuw nsw i64 %27, 2
  %exitcond.not.1 = icmp eq i64 %68, 32
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %69 = getelementptr double, ptr %26, i64 4
  %.promoted.1 = load <4 x double>, ptr %69, align 8
  %gep37 = getelementptr double, ptr %invariant.gep, i64 %25
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %70 = phi i64 [ 0, %.preheader.1 ], [ %111, %.critedge.1 ]
  %71 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %110, %.critedge.1 ]
  %72 = shl nuw nsw i64 %70, 5
  %gep29 = getelementptr double, ptr %gep37, i64 %70
  %73 = load double, ptr %gep29, align 8
  %74 = insertelement <1 x double> poison, double %73, i64 0
  %75 = getelementptr double, ptr %invariant.gep.1, i64 %72
  %76 = load <4 x double>, ptr %75, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %74, %77
  %82 = fmul <1 x double> %74, %78
  %83 = fmul <1 x double> %74, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %74, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %71, %89
  store <4 x double> %90, ptr %69, align 8
  %91 = or disjoint i64 %70, 1
  %92 = shl nuw nsw i64 %91, 5
  %gep29.1 = getelementptr double, ptr %gep37, i64 %91
  %93 = load double, ptr %gep29.1, align 8
  %94 = insertelement <1 x double> poison, double %93, i64 0
  %95 = getelementptr double, ptr %invariant.gep.1, i64 %92
  %96 = load <4 x double>, ptr %95, align 8
  %97 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> zeroinitializer
  %98 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 1>
  %99 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 2>
  %100 = shufflevector <4 x double> %96, <4 x double> poison, <1 x i32> <i32 3>
  %101 = fmul <1 x double> %94, %97
  %102 = fmul <1 x double> %94, %98
  %103 = fmul <1 x double> %94, %99
  %104 = shufflevector <1 x double> %103, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %105 = fmul <1 x double> %94, %100
  %106 = shufflevector <1 x double> %105, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %107 = shufflevector <1 x double> %101, <1 x double> %102, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %104, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %109 = shufflevector <4 x double> %108, <4 x double> %106, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %110 = fadd <4 x double> %90, %109
  store <4 x double> %110, ptr %69, align 8
  %111 = add nuw nsw i64 %70, 2
  %exitcond.1.not.1 = icmp eq i64 %111, 32
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %112 = getelementptr double, ptr %26, i64 8
  %.promoted.2 = load <4 x double>, ptr %112, align 8
  %gep39 = getelementptr double, ptr %invariant.gep38, i64 %25
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %113 = phi i64 [ 0, %.preheader.2 ], [ %154, %.critedge.2 ]
  %114 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %153, %.critedge.2 ]
  %115 = shl nuw nsw i64 %113, 5
  %gep32 = getelementptr double, ptr %gep39, i64 %113
  %116 = load double, ptr %gep32, align 8
  %117 = insertelement <1 x double> poison, double %116, i64 0
  %118 = getelementptr double, ptr %invariant.gep.2, i64 %115
  %119 = load <4 x double>, ptr %118, align 8
  %120 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> zeroinitializer
  %121 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 1>
  %122 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 2>
  %123 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 3>
  %124 = fmul <1 x double> %117, %120
  %125 = fmul <1 x double> %117, %121
  %126 = fmul <1 x double> %117, %122
  %127 = shufflevector <1 x double> %126, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %128 = fmul <1 x double> %117, %123
  %129 = shufflevector <1 x double> %128, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %130 = shufflevector <1 x double> %124, <1 x double> %125, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %131 = shufflevector <4 x double> %130, <4 x double> %127, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %132 = shufflevector <4 x double> %131, <4 x double> %129, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %133 = fadd <4 x double> %114, %132
  store <4 x double> %133, ptr %112, align 8
  %134 = or disjoint i64 %113, 1
  %135 = shl nuw nsw i64 %134, 5
  %gep32.1 = getelementptr double, ptr %gep39, i64 %134
  %136 = load double, ptr %gep32.1, align 8
  %137 = insertelement <1 x double> poison, double %136, i64 0
  %138 = getelementptr double, ptr %invariant.gep.2, i64 %135
  %139 = load <4 x double>, ptr %138, align 8
  %140 = shufflevector <4 x double> %139, <4 x double> poison, <1 x i32> zeroinitializer
  %141 = shufflevector <4 x double> %139, <4 x double> poison, <1 x i32> <i32 1>
  %142 = shufflevector <4 x double> %139, <4 x double> poison, <1 x i32> <i32 2>
  %143 = shufflevector <4 x double> %139, <4 x double> poison, <1 x i32> <i32 3>
  %144 = fmul <1 x double> %137, %140
  %145 = fmul <1 x double> %137, %141
  %146 = fmul <1 x double> %137, %142
  %147 = shufflevector <1 x double> %146, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %148 = fmul <1 x double> %137, %143
  %149 = shufflevector <1 x double> %148, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %150 = shufflevector <1 x double> %144, <1 x double> %145, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %151 = shufflevector <4 x double> %150, <4 x double> %147, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %152 = shufflevector <4 x double> %151, <4 x double> %149, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %153 = fadd <4 x double> %133, %152
  store <4 x double> %153, ptr %112, align 8
  %154 = add nuw nsw i64 %113, 2
  %exitcond.2.not.1 = icmp eq i64 %154, 32
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %155 = getelementptr double, ptr %26, i64 12
  %.promoted.3 = load <4 x double>, ptr %155, align 8
  %gep41 = getelementptr double, ptr %invariant.gep40, i64 %25
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %156 = phi i64 [ 0, %.preheader.3 ], [ %197, %.critedge.3 ]
  %157 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %196, %.critedge.3 ]
  %158 = shl nuw nsw i64 %156, 5
  %gep35 = getelementptr double, ptr %gep41, i64 %156
  %159 = load double, ptr %gep35, align 8
  %160 = insertelement <1 x double> poison, double %159, i64 0
  %161 = getelementptr double, ptr %invariant.gep.3, i64 %158
  %162 = load <4 x double>, ptr %161, align 8
  %163 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> zeroinitializer
  %164 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 1>
  %165 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 2>
  %166 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 3>
  %167 = fmul <1 x double> %160, %163
  %168 = fmul <1 x double> %160, %164
  %169 = fmul <1 x double> %160, %165
  %170 = shufflevector <1 x double> %169, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %171 = fmul <1 x double> %160, %166
  %172 = shufflevector <1 x double> %171, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %173 = shufflevector <1 x double> %167, <1 x double> %168, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %174 = shufflevector <4 x double> %173, <4 x double> %170, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %175 = shufflevector <4 x double> %174, <4 x double> %172, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %176 = fadd <4 x double> %157, %175
  store <4 x double> %176, ptr %155, align 8
  %177 = or disjoint i64 %156, 1
  %178 = shl nuw nsw i64 %177, 5
  %gep35.1 = getelementptr double, ptr %gep41, i64 %177
  %179 = load double, ptr %gep35.1, align 8
  %180 = insertelement <1 x double> poison, double %179, i64 0
  %181 = getelementptr double, ptr %invariant.gep.3, i64 %178
  %182 = load <4 x double>, ptr %181, align 8
  %183 = shufflevector <4 x double> %182, <4 x double> poison, <1 x i32> zeroinitializer
  %184 = shufflevector <4 x double> %182, <4 x double> poison, <1 x i32> <i32 1>
  %185 = shufflevector <4 x double> %182, <4 x double> poison, <1 x i32> <i32 2>
  %186 = shufflevector <4 x double> %182, <4 x double> poison, <1 x i32> <i32 3>
  %187 = fmul <1 x double> %180, %183
  %188 = fmul <1 x double> %180, %184
  %189 = fmul <1 x double> %180, %185
  %190 = shufflevector <1 x double> %189, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %191 = fmul <1 x double> %180, %186
  %192 = shufflevector <1 x double> %191, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %193 = shufflevector <1 x double> %187, <1 x double> %188, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %194 = shufflevector <4 x double> %193, <4 x double> %190, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %195 = shufflevector <4 x double> %194, <4 x double> %192, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %196 = fadd <4 x double> %176, %195
  store <4 x double> %196, ptr %155, align 8
  %197 = add nuw nsw i64 %156, 2
  %exitcond.3.not.1 = icmp eq i64 %197, 32
  br i1 %exitcond.3.not.1, label %198, label %.critedge.3

198:                                              ; preds = %.critedge.3
  %199 = add nuw nsw i64 %24, 1
  %exitcond19.not = icmp eq i64 %199, 16
  br i1 %exitcond19.not, label %200, label %.preheader16

200:                                              ; preds = %198
  %201 = or disjoint i64 %22, 16
  %202 = getelementptr double, ptr %15, i64 %201
  %invariant.gep66 = getelementptr double, ptr %1, i64 %22
  %invariant.gep68 = getelementptr double, ptr %1, i64 %22
  %invariant.gep70 = getelementptr double, ptr %1, i64 %22
  %invariant.gep72 = getelementptr double, ptr %1, i64 %22
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %369, %200
  %203 = phi i64 [ 0, %200 ], [ %370, %369 ]
  %204 = shl i64 %203, 5
  %205 = getelementptr double, ptr %202, i64 %204
  %.promoted.120 = load <4 x double>, ptr %205, align 8
  %gep67 = getelementptr double, ptr %invariant.gep66, i64 %204
  br label %.critedge.124

.critedge.124:                                    ; preds = %.critedge.124, %.preheader16.1
  %206 = phi i64 [ 0, %.preheader16.1 ], [ %245, %.critedge.124 ]
  %207 = phi <4 x double> [ %.promoted.120, %.preheader16.1 ], [ %244, %.critedge.124 ]
  %208 = shl nuw nsw i64 %206, 5
  %gep45 = getelementptr double, ptr %gep67, i64 %206
  %209 = load double, ptr %gep45, align 8
  %210 = insertelement <1 x double> poison, double %209, i64 0
  %gep47 = getelementptr double, ptr %invariant.gep46, i64 %208
  %211 = load <4 x double>, ptr %gep47, align 8
  %212 = shufflevector <4 x double> %211, <4 x double> poison, <1 x i32> zeroinitializer
  %213 = shufflevector <4 x double> %211, <4 x double> poison, <1 x i32> <i32 1>
  %214 = shufflevector <4 x double> %211, <4 x double> poison, <1 x i32> <i32 2>
  %215 = shufflevector <4 x double> %211, <4 x double> poison, <1 x i32> <i32 3>
  %216 = fmul <1 x double> %210, %212
  %217 = fmul <1 x double> %210, %213
  %218 = fmul <1 x double> %210, %214
  %219 = shufflevector <1 x double> %218, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %220 = fmul <1 x double> %210, %215
  %221 = shufflevector <1 x double> %220, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %222 = shufflevector <1 x double> %216, <1 x double> %217, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %223 = shufflevector <4 x double> %222, <4 x double> %219, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %224 = shufflevector <4 x double> %223, <4 x double> %221, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %225 = fadd <4 x double> %207, %224
  store <4 x double> %225, ptr %205, align 8
  %226 = or disjoint i64 %206, 1
  %227 = shl nuw nsw i64 %226, 5
  %gep45.1 = getelementptr double, ptr %gep67, i64 %226
  %228 = load double, ptr %gep45.1, align 8
  %229 = insertelement <1 x double> poison, double %228, i64 0
  %gep47.1 = getelementptr double, ptr %invariant.gep46, i64 %227
  %230 = load <4 x double>, ptr %gep47.1, align 8
  %231 = shufflevector <4 x double> %230, <4 x double> poison, <1 x i32> zeroinitializer
  %232 = shufflevector <4 x double> %230, <4 x double> poison, <1 x i32> <i32 1>
  %233 = shufflevector <4 x double> %230, <4 x double> poison, <1 x i32> <i32 2>
  %234 = shufflevector <4 x double> %230, <4 x double> poison, <1 x i32> <i32 3>
  %235 = fmul <1 x double> %229, %231
  %236 = fmul <1 x double> %229, %232
  %237 = fmul <1 x double> %229, %233
  %238 = shufflevector <1 x double> %237, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %239 = fmul <1 x double> %229, %234
  %240 = shufflevector <1 x double> %239, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %241 = shufflevector <1 x double> %235, <1 x double> %236, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %242 = shufflevector <4 x double> %241, <4 x double> %238, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %243 = shufflevector <4 x double> %242, <4 x double> %240, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %244 = fadd <4 x double> %225, %243
  store <4 x double> %244, ptr %205, align 8
  %245 = add nuw nsw i64 %206, 2
  %exitcond.123.not.1 = icmp eq i64 %245, 32
  br i1 %exitcond.123.not.1, label %.preheader.1.1, label %.critedge.124

.preheader.1.1:                                   ; preds = %.critedge.124
  %246 = getelementptr double, ptr %205, i64 4
  %.promoted.1.1 = load <4 x double>, ptr %246, align 8
  %gep69 = getelementptr double, ptr %invariant.gep68, i64 %204
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1, %.preheader.1.1
  %247 = phi i64 [ 0, %.preheader.1.1 ], [ %286, %.critedge.1.1 ]
  %248 = phi <4 x double> [ %.promoted.1.1, %.preheader.1.1 ], [ %285, %.critedge.1.1 ]
  %249 = shl nuw nsw i64 %247, 5
  %gep51 = getelementptr double, ptr %gep69, i64 %247
  %250 = load double, ptr %gep51, align 8
  %251 = insertelement <1 x double> poison, double %250, i64 0
  %gep53 = getelementptr double, ptr %invariant.gep52, i64 %249
  %252 = load <4 x double>, ptr %gep53, align 8
  %253 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> zeroinitializer
  %254 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 1>
  %255 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 2>
  %256 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 3>
  %257 = fmul <1 x double> %251, %253
  %258 = fmul <1 x double> %251, %254
  %259 = fmul <1 x double> %251, %255
  %260 = shufflevector <1 x double> %259, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %261 = fmul <1 x double> %251, %256
  %262 = shufflevector <1 x double> %261, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %263 = shufflevector <1 x double> %257, <1 x double> %258, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %264 = shufflevector <4 x double> %263, <4 x double> %260, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %265 = shufflevector <4 x double> %264, <4 x double> %262, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %266 = fadd <4 x double> %248, %265
  store <4 x double> %266, ptr %246, align 8
  %267 = or disjoint i64 %247, 1
  %268 = shl nuw nsw i64 %267, 5
  %gep51.1 = getelementptr double, ptr %gep69, i64 %267
  %269 = load double, ptr %gep51.1, align 8
  %270 = insertelement <1 x double> poison, double %269, i64 0
  %gep53.1 = getelementptr double, ptr %invariant.gep52, i64 %268
  %271 = load <4 x double>, ptr %gep53.1, align 8
  %272 = shufflevector <4 x double> %271, <4 x double> poison, <1 x i32> zeroinitializer
  %273 = shufflevector <4 x double> %271, <4 x double> poison, <1 x i32> <i32 1>
  %274 = shufflevector <4 x double> %271, <4 x double> poison, <1 x i32> <i32 2>
  %275 = shufflevector <4 x double> %271, <4 x double> poison, <1 x i32> <i32 3>
  %276 = fmul <1 x double> %270, %272
  %277 = fmul <1 x double> %270, %273
  %278 = fmul <1 x double> %270, %274
  %279 = shufflevector <1 x double> %278, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %280 = fmul <1 x double> %270, %275
  %281 = shufflevector <1 x double> %280, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %282 = shufflevector <1 x double> %276, <1 x double> %277, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %283 = shufflevector <4 x double> %282, <4 x double> %279, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %284 = shufflevector <4 x double> %283, <4 x double> %281, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %285 = fadd <4 x double> %266, %284
  store <4 x double> %285, ptr %246, align 8
  %286 = add nuw nsw i64 %247, 2
  %exitcond.1.1.not.1 = icmp eq i64 %286, 32
  br i1 %exitcond.1.1.not.1, label %.preheader.2.1, label %.critedge.1.1

.preheader.2.1:                                   ; preds = %.critedge.1.1
  %287 = getelementptr double, ptr %205, i64 8
  %.promoted.2.1 = load <4 x double>, ptr %287, align 8
  %gep71 = getelementptr double, ptr %invariant.gep70, i64 %204
  br label %.critedge.2.1

.critedge.2.1:                                    ; preds = %.critedge.2.1, %.preheader.2.1
  %288 = phi i64 [ 0, %.preheader.2.1 ], [ %327, %.critedge.2.1 ]
  %289 = phi <4 x double> [ %.promoted.2.1, %.preheader.2.1 ], [ %326, %.critedge.2.1 ]
  %290 = shl nuw nsw i64 %288, 5
  %gep57 = getelementptr double, ptr %gep71, i64 %288
  %291 = load double, ptr %gep57, align 8
  %292 = insertelement <1 x double> poison, double %291, i64 0
  %gep59 = getelementptr double, ptr %invariant.gep58, i64 %290
  %293 = load <4 x double>, ptr %gep59, align 8
  %294 = shufflevector <4 x double> %293, <4 x double> poison, <1 x i32> zeroinitializer
  %295 = shufflevector <4 x double> %293, <4 x double> poison, <1 x i32> <i32 1>
  %296 = shufflevector <4 x double> %293, <4 x double> poison, <1 x i32> <i32 2>
  %297 = shufflevector <4 x double> %293, <4 x double> poison, <1 x i32> <i32 3>
  %298 = fmul <1 x double> %292, %294
  %299 = fmul <1 x double> %292, %295
  %300 = fmul <1 x double> %292, %296
  %301 = shufflevector <1 x double> %300, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %302 = fmul <1 x double> %292, %297
  %303 = shufflevector <1 x double> %302, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %304 = shufflevector <1 x double> %298, <1 x double> %299, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %305 = shufflevector <4 x double> %304, <4 x double> %301, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %306 = shufflevector <4 x double> %305, <4 x double> %303, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %307 = fadd <4 x double> %289, %306
  store <4 x double> %307, ptr %287, align 8
  %308 = or disjoint i64 %288, 1
  %309 = shl nuw nsw i64 %308, 5
  %gep57.1 = getelementptr double, ptr %gep71, i64 %308
  %310 = load double, ptr %gep57.1, align 8
  %311 = insertelement <1 x double> poison, double %310, i64 0
  %gep59.1 = getelementptr double, ptr %invariant.gep58, i64 %309
  %312 = load <4 x double>, ptr %gep59.1, align 8
  %313 = shufflevector <4 x double> %312, <4 x double> poison, <1 x i32> zeroinitializer
  %314 = shufflevector <4 x double> %312, <4 x double> poison, <1 x i32> <i32 1>
  %315 = shufflevector <4 x double> %312, <4 x double> poison, <1 x i32> <i32 2>
  %316 = shufflevector <4 x double> %312, <4 x double> poison, <1 x i32> <i32 3>
  %317 = fmul <1 x double> %311, %313
  %318 = fmul <1 x double> %311, %314
  %319 = fmul <1 x double> %311, %315
  %320 = shufflevector <1 x double> %319, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %321 = fmul <1 x double> %311, %316
  %322 = shufflevector <1 x double> %321, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %323 = shufflevector <1 x double> %317, <1 x double> %318, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %324 = shufflevector <4 x double> %323, <4 x double> %320, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %325 = shufflevector <4 x double> %324, <4 x double> %322, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %326 = fadd <4 x double> %307, %325
  store <4 x double> %326, ptr %287, align 8
  %327 = add nuw nsw i64 %288, 2
  %exitcond.2.1.not.1 = icmp eq i64 %327, 32
  br i1 %exitcond.2.1.not.1, label %.preheader.3.1, label %.critedge.2.1

.preheader.3.1:                                   ; preds = %.critedge.2.1
  %328 = getelementptr double, ptr %205, i64 12
  %.promoted.3.1 = load <4 x double>, ptr %328, align 8
  %gep73 = getelementptr double, ptr %invariant.gep72, i64 %204
  br label %.critedge.3.1

.critedge.3.1:                                    ; preds = %.critedge.3.1, %.preheader.3.1
  %329 = phi i64 [ 0, %.preheader.3.1 ], [ %368, %.critedge.3.1 ]
  %330 = phi <4 x double> [ %.promoted.3.1, %.preheader.3.1 ], [ %367, %.critedge.3.1 ]
  %331 = shl nuw nsw i64 %329, 5
  %gep63 = getelementptr double, ptr %gep73, i64 %329
  %332 = load double, ptr %gep63, align 8
  %333 = insertelement <1 x double> poison, double %332, i64 0
  %gep65 = getelementptr double, ptr %invariant.gep64, i64 %331
  %334 = load <4 x double>, ptr %gep65, align 8
  %335 = shufflevector <4 x double> %334, <4 x double> poison, <1 x i32> zeroinitializer
  %336 = shufflevector <4 x double> %334, <4 x double> poison, <1 x i32> <i32 1>
  %337 = shufflevector <4 x double> %334, <4 x double> poison, <1 x i32> <i32 2>
  %338 = shufflevector <4 x double> %334, <4 x double> poison, <1 x i32> <i32 3>
  %339 = fmul <1 x double> %333, %335
  %340 = fmul <1 x double> %333, %336
  %341 = fmul <1 x double> %333, %337
  %342 = shufflevector <1 x double> %341, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %343 = fmul <1 x double> %333, %338
  %344 = shufflevector <1 x double> %343, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %345 = shufflevector <1 x double> %339, <1 x double> %340, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %346 = shufflevector <4 x double> %345, <4 x double> %342, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %347 = shufflevector <4 x double> %346, <4 x double> %344, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %348 = fadd <4 x double> %330, %347
  store <4 x double> %348, ptr %328, align 8
  %349 = or disjoint i64 %329, 1
  %350 = shl nuw nsw i64 %349, 5
  %gep63.1 = getelementptr double, ptr %gep73, i64 %349
  %351 = load double, ptr %gep63.1, align 8
  %352 = insertelement <1 x double> poison, double %351, i64 0
  %gep65.1 = getelementptr double, ptr %invariant.gep64, i64 %350
  %353 = load <4 x double>, ptr %gep65.1, align 8
  %354 = shufflevector <4 x double> %353, <4 x double> poison, <1 x i32> zeroinitializer
  %355 = shufflevector <4 x double> %353, <4 x double> poison, <1 x i32> <i32 1>
  %356 = shufflevector <4 x double> %353, <4 x double> poison, <1 x i32> <i32 2>
  %357 = shufflevector <4 x double> %353, <4 x double> poison, <1 x i32> <i32 3>
  %358 = fmul <1 x double> %352, %354
  %359 = fmul <1 x double> %352, %355
  %360 = fmul <1 x double> %352, %356
  %361 = shufflevector <1 x double> %360, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %362 = fmul <1 x double> %352, %357
  %363 = shufflevector <1 x double> %362, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %364 = shufflevector <1 x double> %358, <1 x double> %359, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %365 = shufflevector <4 x double> %364, <4 x double> %361, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %366 = shufflevector <4 x double> %365, <4 x double> %363, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %367 = fadd <4 x double> %348, %366
  store <4 x double> %367, ptr %328, align 8
  %368 = add nuw nsw i64 %329, 2
  %exitcond.3.1.not.1 = icmp eq i64 %368, 32
  br i1 %exitcond.3.1.not.1, label %369, label %.critedge.3.1

369:                                              ; preds = %.critedge.3.1
  %370 = add nuw nsw i64 %203, 1
  %exitcond19.1.not = icmp eq i64 %370, 16
  br i1 %exitcond19.1.not, label %371, label %.preheader16.1

371:                                              ; preds = %369
  br i1 %21, label %.preheader17, label %372

372:                                              ; preds = %371
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
