module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %22 = llvm.mlir.constant(32 : index) : i64
    %23 = llvm.mlir.constant(128 : index) : i64
    %24 = llvm.mlir.constant(4 : index) : i64
    %25 = llvm.mlir.constant(1 : index) : i64
    %26 = llvm.mlir.constant(8 : index) : i64
    %27 = llvm.mlir.constant(0 : index) : i64
    %28 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%27 : i64)
  ^bb1(%29: i64):  // 2 preds: ^bb0, ^bb2
    %30 = llvm.icmp "slt" %29, %23 : i64
    llvm.cond_br %30, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %31 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %32 = llvm.getelementptr %31[%29] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %28, %32 : f64, !llvm.ptr
    %33 = llvm.add %29, %25  : i64
    llvm.br ^bb1(%33 : i64)
  ^bb3:  // pred: ^bb1
    %34 = llvm.mlir.constant(1 : index) : i64
    %35 = llvm.alloca %34 x !llvm.array<4 x vector<1xf64>> : (i64) -> !llvm.ptr
    %36 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %37 = llvm.insertvalue %35, %36[0] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.insertvalue %35, %37[1] : !llvm.struct<(ptr, ptr, i64)> 
    %39 = llvm.mlir.constant(0 : index) : i64
    %40 = llvm.insertvalue %39, %38[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%27 : i64)
  ^bb4(%41: i64):  // 2 preds: ^bb3, ^bb14
    %42 = llvm.icmp "slt" %41, %23 : i64
    llvm.cond_br %42, ^bb5, ^bb15
  ^bb5:  // pred: ^bb4
    %43 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %45 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %46 = llvm.insertvalue %43, %45[0] : !llvm.struct<(ptr, ptr, i64)> 
    %47 = llvm.insertvalue %44, %46[1] : !llvm.struct<(ptr, ptr, i64)> 
    %48 = llvm.mlir.constant(0 : index) : i64
    %49 = llvm.insertvalue %48, %47[2] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %51 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %52 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %54 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %55 = llvm.mul %41, %22  : i64
    %56 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %58 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %59 = llvm.insertvalue %56, %58[0] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.insertvalue %57, %59[1] : !llvm.struct<(ptr, ptr, i64)> 
    %61 = llvm.mlir.constant(0 : index) : i64
    %62 = llvm.insertvalue %61, %60[2] : !llvm.struct<(ptr, ptr, i64)> 
    %63 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %64 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %65 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%27 : i64)
  ^bb6(%66: i64):  // 2 preds: ^bb5, ^bb13
    %67 = llvm.icmp "slt" %66, %26 : i64
    llvm.cond_br %67, ^bb7, ^bb14
  ^bb7:  // pred: ^bb6
    llvm.br ^bb8(%27 : i64)
  ^bb8(%68: i64):  // 2 preds: ^bb7, ^bb12
    %69 = llvm.icmp "slt" %68, %22 : i64
    llvm.cond_br %69, ^bb9, ^bb13
  ^bb9:  // pred: ^bb8
    %70 = llvm.mul %66, %22  : i64
    %71 = llvm.add %55, %70  : i64
    %72 = llvm.add %71, %68  : i64
    %73 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %74 = llvm.insertvalue %43, %73[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %75 = llvm.insertvalue %44, %74[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %76 = llvm.insertvalue %72, %75[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.mlir.constant(4 : index) : i64
    %78 = llvm.insertvalue %77, %76[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mlir.constant(32 : index) : i64
    %80 = llvm.insertvalue %79, %78[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.mlir.constant(1 : index) : i64
    %82 = llvm.insertvalue %81, %80[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.mlir.constant(1 : index) : i64
    %84 = llvm.insertvalue %83, %82[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %86 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %87 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %88 = llvm.insertvalue %85, %87[0] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.insertvalue %86, %88[1] : !llvm.struct<(ptr, ptr, i64)> 
    %90 = llvm.mlir.constant(0 : index) : i64
    %91 = llvm.insertvalue %90, %89[2] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %93 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %94 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %96 = llvm.insertvalue %85, %95[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.insertvalue %86, %96[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.insertvalue %68, %97[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %99 = llvm.mlir.constant(1 : index) : i64
    %100 = llvm.insertvalue %99, %98[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.mlir.constant(1 : index) : i64
    %102 = llvm.insertvalue %101, %100[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %103 = llvm.add %41, %66  : i64
    %104 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %105 = llvm.insertvalue %56, %104[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.insertvalue %57, %105[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.insertvalue %103, %106[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.mlir.constant(4 : index) : i64
    %109 = llvm.insertvalue %108, %107[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %110 = llvm.mlir.constant(1 : index) : i64
    %111 = llvm.insertvalue %110, %109[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %112 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %113 = llvm.extractvalue %40[0] : !llvm.struct<(ptr, ptr, i64)> 
    %114 = llvm.insertvalue %113, %112[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.extractvalue %40[1] : !llvm.struct<(ptr, ptr, i64)> 
    %116 = llvm.insertvalue %115, %114[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %117 = llvm.mlir.constant(0 : index) : i64
    %118 = llvm.insertvalue %117, %116[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %119 = llvm.mlir.constant(4 : index) : i64
    %120 = llvm.insertvalue %119, %118[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %121 = llvm.mlir.constant(1 : index) : i64
    %122 = llvm.insertvalue %121, %120[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb10(%27 : i64)
  ^bb10(%123: i64):  // 2 preds: ^bb9, ^bb11
    %124 = llvm.icmp "slt" %123, %24 : i64
    llvm.cond_br %124, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %125 = llvm.getelementptr %44[%72] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %126 = llvm.mlir.constant(32 : index) : i64
    %127 = llvm.mul %123, %126  : i64
    %128 = llvm.add %127, %27  : i64
    %129 = llvm.getelementptr %125[%128] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %130 = llvm.load %129 : !llvm.ptr -> f64
    %131 = llvm.mlir.undef : vector<1xf64>
    %132 = llvm.mlir.constant(0 : i32) : i32
    %133 = llvm.insertelement %130, %131[%132 : i32] : vector<1xf64>
    %134 = llvm.shufflevector %133, %131 [0] : vector<1xf64> 
    %135 = llvm.getelementptr %115[%123] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %134, %135 : vector<1xf64>, !llvm.ptr
    %136 = llvm.add %123, %25  : i64
    llvm.br ^bb10(%136 : i64)
  ^bb12:  // pred: ^bb10
    %137 = llvm.load %35 : !llvm.ptr -> !llvm.array<4 x vector<1xf64>>
    %138 = llvm.getelementptr %86[%68] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %139 = llvm.getelementptr %138[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %140 = llvm.load %139 : !llvm.ptr -> f64
    %141 = llvm.mlir.undef : vector<1xf64>
    %142 = llvm.mlir.constant(0 : i32) : i32
    %143 = llvm.insertelement %140, %141[%142 : i32] : vector<1xf64>
    %144 = llvm.shufflevector %143, %141 [0] : vector<1xf64> 
    %145 = llvm.insertvalue %144, %21[0] : !llvm.array<4 x vector<1xf64>> 
    %146 = llvm.insertvalue %144, %145[1] : !llvm.array<4 x vector<1xf64>> 
    %147 = llvm.insertvalue %144, %146[2] : !llvm.array<4 x vector<1xf64>> 
    %148 = llvm.insertvalue %144, %147[3] : !llvm.array<4 x vector<1xf64>> 
    %149 = llvm.extractvalue %111[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.extractvalue %111[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %151 = llvm.getelementptr %149[%150] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %152 = llvm.getelementptr %151[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %153 = llvm.load %152 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %154 = llvm.mlir.undef : !llvm.array<4 x vector<1xf64>>
    %155 = llvm.extractvalue %137[0] : !llvm.array<4 x vector<1xf64>> 
    %156 = llvm.fmul %155, %144  : vector<1xf64>
    %157 = llvm.insertvalue %156, %154[0] : !llvm.array<4 x vector<1xf64>> 
    %158 = llvm.extractvalue %137[1] : !llvm.array<4 x vector<1xf64>> 
    %159 = llvm.fmul %158, %144  : vector<1xf64>
    %160 = llvm.insertvalue %159, %157[1] : !llvm.array<4 x vector<1xf64>> 
    %161 = llvm.extractvalue %137[2] : !llvm.array<4 x vector<1xf64>> 
    %162 = llvm.fmul %161, %144  : vector<1xf64>
    %163 = llvm.insertvalue %162, %160[2] : !llvm.array<4 x vector<1xf64>> 
    %164 = llvm.extractvalue %137[3] : !llvm.array<4 x vector<1xf64>> 
    %165 = llvm.fmul %164, %144  : vector<1xf64>
    %166 = llvm.insertvalue %165, %163[3] : !llvm.array<4 x vector<1xf64>> 
    %167 = llvm.extractvalue %166[0] : !llvm.array<4 x vector<1xf64>> 
    %168 = llvm.mlir.constant(0 : i64) : i64
    %169 = llvm.extractelement %167[%168 : i64] : vector<1xf64>
    %170 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<4xf64>> 
    %171 = llvm.mlir.constant(0 : i64) : i64
    %172 = llvm.insertelement %169, %170[%171 : i64] : vector<4xf64>
    %173 = llvm.insertvalue %172, %20[0] : !llvm.array<1 x vector<4xf64>> 
    %174 = llvm.extractvalue %166[1] : !llvm.array<4 x vector<1xf64>> 
    %175 = llvm.mlir.constant(0 : i64) : i64
    %176 = llvm.extractelement %174[%175 : i64] : vector<1xf64>
    %177 = llvm.mlir.constant(1 : i64) : i64
    %178 = llvm.insertelement %176, %172[%177 : i64] : vector<4xf64>
    %179 = llvm.insertvalue %178, %173[0] : !llvm.array<1 x vector<4xf64>> 
    %180 = llvm.extractvalue %166[2] : !llvm.array<4 x vector<1xf64>> 
    %181 = llvm.mlir.constant(0 : i64) : i64
    %182 = llvm.extractelement %180[%181 : i64] : vector<1xf64>
    %183 = llvm.mlir.constant(2 : i64) : i64
    %184 = llvm.insertelement %182, %178[%183 : i64] : vector<4xf64>
    %185 = llvm.insertvalue %184, %179[0] : !llvm.array<1 x vector<4xf64>> 
    %186 = llvm.extractvalue %166[3] : !llvm.array<4 x vector<1xf64>> 
    %187 = llvm.mlir.constant(0 : i64) : i64
    %188 = llvm.extractelement %186[%187 : i64] : vector<1xf64>
    %189 = llvm.mlir.constant(3 : i64) : i64
    %190 = llvm.insertelement %188, %184[%189 : i64] : vector<4xf64>
    %191 = llvm.insertvalue %190, %185[0] : !llvm.array<1 x vector<4xf64>> 
    %192 = llvm.fadd %190, %153  : vector<4xf64>
    %193 = llvm.extractvalue %111[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %194 = llvm.extractvalue %111[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.getelementptr %193[%194] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %196 = llvm.getelementptr %195[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %192, %196 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %197 = llvm.add %68, %25  : i64
    llvm.br ^bb8(%197 : i64)
  ^bb13:  // pred: ^bb8
    %198 = llvm.add %66, %24  : i64
    llvm.br ^bb6(%198 : i64)
  ^bb14:  // pred: ^bb6
    %199 = llvm.add %41, %26  : i64
    llvm.br ^bb4(%199 : i64)
  ^bb15:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
