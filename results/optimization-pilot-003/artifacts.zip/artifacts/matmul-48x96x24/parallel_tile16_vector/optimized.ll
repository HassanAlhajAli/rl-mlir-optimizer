; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %15, i8 0, i64 36864, i1 false)
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %208
  %21 = phi i64 [ %209, %208 ], [ 0, %.preheader17.preheader ]
  %22 = mul nuw nsw i64 %21, 96
  %invariant.gep = getelementptr double, ptr %15, i64 %22
  br label %23

23:                                               ; preds = %.preheader17, %205
  %24 = phi i64 [ 0, %.preheader17 ], [ %206, %205 ]
  %25 = getelementptr double, ptr %8, i64 %24
  %gep20 = getelementptr double, ptr %invariant.gep, i64 %24
  %invariant.gep.1 = getelementptr double, ptr %25, i64 4
  %invariant.gep.2 = getelementptr double, ptr %25, i64 8
  %invariant.gep.3 = getelementptr double, ptr %25, i64 12
  br label %.preheader16

.preheader16:                                     ; preds = %23, %203
  %26 = phi i64 [ 0, %23 ], [ %204, %203 ]
  %27 = add nuw nsw i64 %26, %21
  %28 = mul nuw nsw i64 %27, 24
  %29 = mul nuw nsw i64 %26, 96
  %30 = getelementptr double, ptr %1, i64 %28
  %31 = getelementptr double, ptr %gep20, i64 %29
  %.promoted = load <4 x double>, ptr %31, align 8
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %32 = phi i64 [ 0, %.preheader16 ], [ %73, %.critedge ]
  %33 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %72, %.critedge ]
  %34 = mul nuw nsw i64 %32, 96
  %35 = getelementptr double, ptr %30, i64 %32
  %36 = load double, ptr %35, align 8
  %37 = insertelement <1 x double> poison, double %36, i64 0
  %gep = getelementptr double, ptr %25, i64 %34
  %38 = load <4 x double>, ptr %gep, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %37, %39
  %44 = fmul <1 x double> %37, %40
  %45 = fmul <1 x double> %37, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %37, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %33, %51
  store <4 x double> %52, ptr %31, align 8
  %53 = or disjoint i64 %32, 1
  %54 = mul nuw nsw i64 %53, 96
  %55 = getelementptr double, ptr %30, i64 %53
  %56 = load double, ptr %55, align 8
  %57 = insertelement <1 x double> poison, double %56, i64 0
  %gep.121 = getelementptr double, ptr %25, i64 %54
  %58 = load <4 x double>, ptr %gep.121, align 8
  %59 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> zeroinitializer
  %60 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 1>
  %61 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 2>
  %62 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 3>
  %63 = fmul <1 x double> %57, %59
  %64 = fmul <1 x double> %57, %60
  %65 = fmul <1 x double> %57, %61
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = fmul <1 x double> %57, %62
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %63, <1 x double> %64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %72 = fadd <4 x double> %52, %71
  store <4 x double> %72, ptr %31, align 8
  %73 = add nuw nsw i64 %32, 2
  %exitcond.not.1 = icmp eq i64 %73, 24
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %74 = getelementptr double, ptr %31, i64 4
  %.promoted.1 = load <4 x double>, ptr %74, align 8
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %75 = phi i64 [ 0, %.preheader.1 ], [ %116, %.critedge.1 ]
  %76 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %115, %.critedge.1 ]
  %77 = mul nuw nsw i64 %75, 96
  %78 = getelementptr double, ptr %30, i64 %75
  %79 = load double, ptr %78, align 8
  %80 = insertelement <1 x double> poison, double %79, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %77
  %81 = load <4 x double>, ptr %gep.1, align 8
  %82 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %80, %82
  %87 = fmul <1 x double> %80, %83
  %88 = fmul <1 x double> %80, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %80, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %74, align 8
  %96 = or disjoint i64 %75, 1
  %97 = mul nuw nsw i64 %96, 96
  %98 = getelementptr double, ptr %30, i64 %96
  %99 = load double, ptr %98, align 8
  %100 = insertelement <1 x double> poison, double %99, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %97
  %101 = load <4 x double>, ptr %gep.1.1, align 8
  %102 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> zeroinitializer
  %103 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 1>
  %104 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 2>
  %105 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 3>
  %106 = fmul <1 x double> %100, %102
  %107 = fmul <1 x double> %100, %103
  %108 = fmul <1 x double> %100, %104
  %109 = shufflevector <1 x double> %108, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %110 = fmul <1 x double> %100, %105
  %111 = shufflevector <1 x double> %110, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %112 = shufflevector <1 x double> %106, <1 x double> %107, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %109, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %111, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %115 = fadd <4 x double> %95, %114
  store <4 x double> %115, ptr %74, align 8
  %116 = add nuw nsw i64 %75, 2
  %exitcond.1.not.1 = icmp eq i64 %116, 24
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %117 = getelementptr double, ptr %31, i64 8
  %.promoted.2 = load <4 x double>, ptr %117, align 8
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %118 = phi i64 [ 0, %.preheader.2 ], [ %159, %.critedge.2 ]
  %119 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %158, %.critedge.2 ]
  %120 = mul nuw nsw i64 %118, 96
  %121 = getelementptr double, ptr %30, i64 %118
  %122 = load double, ptr %121, align 8
  %123 = insertelement <1 x double> poison, double %122, i64 0
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %120
  %124 = load <4 x double>, ptr %gep.2, align 8
  %125 = shufflevector <4 x double> %124, <4 x double> poison, <1 x i32> zeroinitializer
  %126 = shufflevector <4 x double> %124, <4 x double> poison, <1 x i32> <i32 1>
  %127 = shufflevector <4 x double> %124, <4 x double> poison, <1 x i32> <i32 2>
  %128 = shufflevector <4 x double> %124, <4 x double> poison, <1 x i32> <i32 3>
  %129 = fmul <1 x double> %123, %125
  %130 = fmul <1 x double> %123, %126
  %131 = fmul <1 x double> %123, %127
  %132 = shufflevector <1 x double> %131, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %133 = fmul <1 x double> %123, %128
  %134 = shufflevector <1 x double> %133, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %135 = shufflevector <1 x double> %129, <1 x double> %130, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %136 = shufflevector <4 x double> %135, <4 x double> %132, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %137 = shufflevector <4 x double> %136, <4 x double> %134, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %138 = fadd <4 x double> %119, %137
  store <4 x double> %138, ptr %117, align 8
  %139 = or disjoint i64 %118, 1
  %140 = mul nuw nsw i64 %139, 96
  %141 = getelementptr double, ptr %30, i64 %139
  %142 = load double, ptr %141, align 8
  %143 = insertelement <1 x double> poison, double %142, i64 0
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %140
  %144 = load <4 x double>, ptr %gep.2.1, align 8
  %145 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> zeroinitializer
  %146 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 1>
  %147 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 2>
  %148 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 3>
  %149 = fmul <1 x double> %143, %145
  %150 = fmul <1 x double> %143, %146
  %151 = fmul <1 x double> %143, %147
  %152 = shufflevector <1 x double> %151, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %153 = fmul <1 x double> %143, %148
  %154 = shufflevector <1 x double> %153, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %155 = shufflevector <1 x double> %149, <1 x double> %150, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %156 = shufflevector <4 x double> %155, <4 x double> %152, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %157 = shufflevector <4 x double> %156, <4 x double> %154, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %158 = fadd <4 x double> %138, %157
  store <4 x double> %158, ptr %117, align 8
  %159 = add nuw nsw i64 %118, 2
  %exitcond.2.not.1 = icmp eq i64 %159, 24
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %160 = getelementptr double, ptr %31, i64 12
  %.promoted.3 = load <4 x double>, ptr %160, align 8
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %161 = phi i64 [ 0, %.preheader.3 ], [ %202, %.critedge.3 ]
  %162 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %201, %.critedge.3 ]
  %163 = mul nuw nsw i64 %161, 96
  %164 = getelementptr double, ptr %30, i64 %161
  %165 = load double, ptr %164, align 8
  %166 = insertelement <1 x double> poison, double %165, i64 0
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %163
  %167 = load <4 x double>, ptr %gep.3, align 8
  %168 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> zeroinitializer
  %169 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 1>
  %170 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 2>
  %171 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 3>
  %172 = fmul <1 x double> %166, %168
  %173 = fmul <1 x double> %166, %169
  %174 = fmul <1 x double> %166, %170
  %175 = shufflevector <1 x double> %174, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %176 = fmul <1 x double> %166, %171
  %177 = shufflevector <1 x double> %176, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %178 = shufflevector <1 x double> %172, <1 x double> %173, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %175, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %180 = shufflevector <4 x double> %179, <4 x double> %177, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %181 = fadd <4 x double> %162, %180
  store <4 x double> %181, ptr %160, align 8
  %182 = or disjoint i64 %161, 1
  %183 = mul nuw nsw i64 %182, 96
  %184 = getelementptr double, ptr %30, i64 %182
  %185 = load double, ptr %184, align 8
  %186 = insertelement <1 x double> poison, double %185, i64 0
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %183
  %187 = load <4 x double>, ptr %gep.3.1, align 8
  %188 = shufflevector <4 x double> %187, <4 x double> poison, <1 x i32> zeroinitializer
  %189 = shufflevector <4 x double> %187, <4 x double> poison, <1 x i32> <i32 1>
  %190 = shufflevector <4 x double> %187, <4 x double> poison, <1 x i32> <i32 2>
  %191 = shufflevector <4 x double> %187, <4 x double> poison, <1 x i32> <i32 3>
  %192 = fmul <1 x double> %186, %188
  %193 = fmul <1 x double> %186, %189
  %194 = fmul <1 x double> %186, %190
  %195 = shufflevector <1 x double> %194, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %196 = fmul <1 x double> %186, %191
  %197 = shufflevector <1 x double> %196, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %198 = shufflevector <1 x double> %192, <1 x double> %193, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %199 = shufflevector <4 x double> %198, <4 x double> %195, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %200 = shufflevector <4 x double> %199, <4 x double> %197, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %201 = fadd <4 x double> %181, %200
  store <4 x double> %201, ptr %160, align 8
  %202 = add nuw nsw i64 %161, 2
  %exitcond.3.not.1 = icmp eq i64 %202, 24
  br i1 %exitcond.3.not.1, label %203, label %.critedge.3

203:                                              ; preds = %.critedge.3
  %204 = add nuw nsw i64 %26, 1
  %exitcond19.not = icmp eq i64 %204, 16
  br i1 %exitcond19.not, label %205, label %.preheader16

205:                                              ; preds = %203
  %206 = add nuw nsw i64 %24, 16
  %207 = icmp ult i64 %24, 80
  br i1 %207, label %23, label %208

208:                                              ; preds = %205
  %209 = add nuw nsw i64 %21, 16
  %210 = icmp ult i64 %21, 32
  br i1 %210, label %.preheader17, label %211

211:                                              ; preds = %208
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %.unpack32, i8 0, i64 36864, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %191, %3
  %4 = phi i64 [ %192, %191 ], [ 0, %3 ]
  %5 = mul nuw nsw i64 %4, 96
  %invariant.gep.i = getelementptr double, ptr %.unpack32, i64 %5
  br label %6

6:                                                ; preds = %188, %.preheader17.i
  %7 = phi i64 [ 0, %.preheader17.i ], [ %189, %188 ]
  %8 = getelementptr double, ptr %.unpack17, i64 %7
  %gep20.i = getelementptr double, ptr %invariant.gep.i, i64 %7
  %invariant.gep.1.i = getelementptr double, ptr %8, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %8, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %8, i64 12
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %186, %6
  %9 = phi i64 [ 0, %6 ], [ %187, %186 ]
  %10 = add nuw nsw i64 %9, %4
  %11 = mul nuw nsw i64 %10, 24
  %12 = mul nuw nsw i64 %9, 96
  %13 = getelementptr double, ptr %.unpack2, i64 %11
  %14 = getelementptr double, ptr %gep20.i, i64 %12
  %.promoted.i = load <4 x double>, ptr %14, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %15 = phi i64 [ 0, %.preheader16.i ], [ %56, %.critedge.i ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %55, %.critedge.i ]
  %17 = mul nuw nsw i64 %15, 96
  %18 = getelementptr double, ptr %13, i64 %15
  %19 = load double, ptr %18, align 8
  %20 = insertelement <1 x double> poison, double %19, i64 0
  %gep.i = getelementptr double, ptr %8, i64 %17
  %21 = load <4 x double>, ptr %gep.i, align 8
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> zeroinitializer
  %23 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 1>
  %24 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 2>
  %25 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 3>
  %26 = fmul <1 x double> %20, %22
  %27 = fmul <1 x double> %20, %23
  %28 = fmul <1 x double> %20, %24
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = fmul <1 x double> %20, %25
  %31 = shufflevector <1 x double> %30, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = shufflevector <1 x double> %26, <1 x double> %27, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = fadd <4 x double> %16, %34
  store <4 x double> %35, ptr %14, align 8
  %36 = or disjoint i64 %15, 1
  %37 = mul nuw nsw i64 %36, 96
  %38 = getelementptr double, ptr %13, i64 %36
  %39 = load double, ptr %38, align 8
  %40 = insertelement <1 x double> poison, double %39, i64 0
  %gep.i.1 = getelementptr double, ptr %8, i64 %37
  %41 = load <4 x double>, ptr %gep.i.1, align 8
  %42 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> zeroinitializer
  %43 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 1>
  %44 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 2>
  %45 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 3>
  %46 = fmul <1 x double> %40, %42
  %47 = fmul <1 x double> %40, %43
  %48 = fmul <1 x double> %40, %44
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = fmul <1 x double> %40, %45
  %51 = shufflevector <1 x double> %50, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %52 = shufflevector <1 x double> %46, <1 x double> %47, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %54 = shufflevector <4 x double> %53, <4 x double> %51, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %55 = fadd <4 x double> %35, %54
  store <4 x double> %55, ptr %14, align 8
  %56 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %56, 24
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %57 = getelementptr double, ptr %14, i64 4
  %.promoted.1.i = load <4 x double>, ptr %57, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %58 = phi i64 [ 0, %.preheader.1.i ], [ %99, %.critedge.1.i ]
  %59 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %98, %.critedge.1.i ]
  %60 = mul nuw nsw i64 %58, 96
  %61 = getelementptr double, ptr %13, i64 %58
  %62 = load double, ptr %61, align 8
  %63 = insertelement <1 x double> poison, double %62, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %60
  %64 = load <4 x double>, ptr %gep.1.i, align 8
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> zeroinitializer
  %66 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 1>
  %67 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 2>
  %68 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 3>
  %69 = fmul <1 x double> %63, %65
  %70 = fmul <1 x double> %63, %66
  %71 = fmul <1 x double> %63, %67
  %72 = shufflevector <1 x double> %71, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = fmul <1 x double> %63, %68
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = shufflevector <1 x double> %69, <1 x double> %70, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %76 = shufflevector <4 x double> %75, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %78 = fadd <4 x double> %59, %77
  store <4 x double> %78, ptr %57, align 8
  %79 = or disjoint i64 %58, 1
  %80 = mul nuw nsw i64 %79, 96
  %81 = getelementptr double, ptr %13, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = insertelement <1 x double> poison, double %82, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %80
  %84 = load <4 x double>, ptr %gep.1.i.1, align 8
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> zeroinitializer
  %86 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 1>
  %87 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 2>
  %88 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 3>
  %89 = fmul <1 x double> %83, %85
  %90 = fmul <1 x double> %83, %86
  %91 = fmul <1 x double> %83, %87
  %92 = shufflevector <1 x double> %91, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = fmul <1 x double> %83, %88
  %94 = shufflevector <1 x double> %93, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = shufflevector <1 x double> %89, <1 x double> %90, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %98 = fadd <4 x double> %78, %97
  store <4 x double> %98, ptr %57, align 8
  %99 = add nuw nsw i64 %58, 2
  %exitcond.1.not.i.1 = icmp eq i64 %99, 24
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %100 = getelementptr double, ptr %14, i64 8
  %.promoted.2.i = load <4 x double>, ptr %100, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %101 = phi i64 [ 0, %.preheader.2.i ], [ %142, %.critedge.2.i ]
  %102 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %141, %.critedge.2.i ]
  %103 = mul nuw nsw i64 %101, 96
  %104 = getelementptr double, ptr %13, i64 %101
  %105 = load double, ptr %104, align 8
  %106 = insertelement <1 x double> poison, double %105, i64 0
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %103
  %107 = load <4 x double>, ptr %gep.2.i, align 8
  %108 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> zeroinitializer
  %109 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 1>
  %110 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 2>
  %111 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 3>
  %112 = fmul <1 x double> %106, %108
  %113 = fmul <1 x double> %106, %109
  %114 = fmul <1 x double> %106, %110
  %115 = shufflevector <1 x double> %114, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %116 = fmul <1 x double> %106, %111
  %117 = shufflevector <1 x double> %116, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %118 = shufflevector <1 x double> %112, <1 x double> %113, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %119 = shufflevector <4 x double> %118, <4 x double> %115, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %120 = shufflevector <4 x double> %119, <4 x double> %117, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %121 = fadd <4 x double> %102, %120
  store <4 x double> %121, ptr %100, align 8
  %122 = or disjoint i64 %101, 1
  %123 = mul nuw nsw i64 %122, 96
  %124 = getelementptr double, ptr %13, i64 %122
  %125 = load double, ptr %124, align 8
  %126 = insertelement <1 x double> poison, double %125, i64 0
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %123
  %127 = load <4 x double>, ptr %gep.2.i.1, align 8
  %128 = shufflevector <4 x double> %127, <4 x double> poison, <1 x i32> zeroinitializer
  %129 = shufflevector <4 x double> %127, <4 x double> poison, <1 x i32> <i32 1>
  %130 = shufflevector <4 x double> %127, <4 x double> poison, <1 x i32> <i32 2>
  %131 = shufflevector <4 x double> %127, <4 x double> poison, <1 x i32> <i32 3>
  %132 = fmul <1 x double> %126, %128
  %133 = fmul <1 x double> %126, %129
  %134 = fmul <1 x double> %126, %130
  %135 = shufflevector <1 x double> %134, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %136 = fmul <1 x double> %126, %131
  %137 = shufflevector <1 x double> %136, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %138 = shufflevector <1 x double> %132, <1 x double> %133, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %139 = shufflevector <4 x double> %138, <4 x double> %135, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %140 = shufflevector <4 x double> %139, <4 x double> %137, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %141 = fadd <4 x double> %121, %140
  store <4 x double> %141, ptr %100, align 8
  %142 = add nuw nsw i64 %101, 2
  %exitcond.2.not.i.1 = icmp eq i64 %142, 24
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %143 = getelementptr double, ptr %14, i64 12
  %.promoted.3.i = load <4 x double>, ptr %143, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %144 = phi i64 [ 0, %.preheader.3.i ], [ %185, %.critedge.3.i ]
  %145 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %184, %.critedge.3.i ]
  %146 = mul nuw nsw i64 %144, 96
  %147 = getelementptr double, ptr %13, i64 %144
  %148 = load double, ptr %147, align 8
  %149 = insertelement <1 x double> poison, double %148, i64 0
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %146
  %150 = load <4 x double>, ptr %gep.3.i, align 8
  %151 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> zeroinitializer
  %152 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 1>
  %153 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 2>
  %154 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 3>
  %155 = fmul <1 x double> %149, %151
  %156 = fmul <1 x double> %149, %152
  %157 = fmul <1 x double> %149, %153
  %158 = shufflevector <1 x double> %157, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %159 = fmul <1 x double> %149, %154
  %160 = shufflevector <1 x double> %159, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %161 = shufflevector <1 x double> %155, <1 x double> %156, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %162 = shufflevector <4 x double> %161, <4 x double> %158, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %163 = shufflevector <4 x double> %162, <4 x double> %160, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %164 = fadd <4 x double> %145, %163
  store <4 x double> %164, ptr %143, align 8
  %165 = or disjoint i64 %144, 1
  %166 = mul nuw nsw i64 %165, 96
  %167 = getelementptr double, ptr %13, i64 %165
  %168 = load double, ptr %167, align 8
  %169 = insertelement <1 x double> poison, double %168, i64 0
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %166
  %170 = load <4 x double>, ptr %gep.3.i.1, align 8
  %171 = shufflevector <4 x double> %170, <4 x double> poison, <1 x i32> zeroinitializer
  %172 = shufflevector <4 x double> %170, <4 x double> poison, <1 x i32> <i32 1>
  %173 = shufflevector <4 x double> %170, <4 x double> poison, <1 x i32> <i32 2>
  %174 = shufflevector <4 x double> %170, <4 x double> poison, <1 x i32> <i32 3>
  %175 = fmul <1 x double> %169, %171
  %176 = fmul <1 x double> %169, %172
  %177 = fmul <1 x double> %169, %173
  %178 = shufflevector <1 x double> %177, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %179 = fmul <1 x double> %169, %174
  %180 = shufflevector <1 x double> %179, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %181 = shufflevector <1 x double> %175, <1 x double> %176, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %182 = shufflevector <4 x double> %181, <4 x double> %178, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %183 = shufflevector <4 x double> %182, <4 x double> %180, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %184 = fadd <4 x double> %164, %183
  store <4 x double> %184, ptr %143, align 8
  %185 = add nuw nsw i64 %144, 2
  %exitcond.3.not.i.1 = icmp eq i64 %185, 24
  br i1 %exitcond.3.not.i.1, label %186, label %.critedge.3.i

186:                                              ; preds = %.critedge.3.i
  %187 = add nuw nsw i64 %9, 1
  %exitcond19.not.i = icmp eq i64 %187, 16
  br i1 %exitcond19.not.i, label %188, label %.preheader16.i

188:                                              ; preds = %186
  %189 = add nuw nsw i64 %7, 16
  %190 = icmp ult i64 %7, 80
  br i1 %190, label %6, label %191

191:                                              ; preds = %188
  %192 = add nuw nsw i64 %4, 16
  %193 = icmp ult i64 %4, 32
  br i1 %193, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %191
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %10, i8 0, i64 36864, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %198, %1
  %11 = phi i64 [ %199, %198 ], [ 0, %1 ]
  %12 = mul nuw nsw i64 %11, 96
  %invariant.gep.i = getelementptr double, ptr %10, i64 %12
  br label %13

13:                                               ; preds = %195, %.preheader17.i
  %14 = phi i64 [ 0, %.preheader17.i ], [ %196, %195 ]
  %15 = getelementptr double, ptr %7, i64 %14
  %gep20.i = getelementptr double, ptr %invariant.gep.i, i64 %14
  %invariant.gep.1.i = getelementptr double, ptr %15, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %15, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %15, i64 12
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %193, %13
  %16 = phi i64 [ 0, %13 ], [ %194, %193 ]
  %17 = add nuw nsw i64 %16, %11
  %18 = mul nuw nsw i64 %17, 24
  %19 = mul nuw nsw i64 %16, 96
  %20 = getelementptr double, ptr %4, i64 %18
  %21 = getelementptr double, ptr %gep20.i, i64 %19
  %.promoted.i = load <4 x double>, ptr %21, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %22 = phi i64 [ 0, %.preheader16.i ], [ %63, %.critedge.i ]
  %23 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %62, %.critedge.i ]
  %24 = mul nuw nsw i64 %22, 96
  %25 = getelementptr double, ptr %20, i64 %22
  %26 = load double, ptr %25, align 8
  %27 = insertelement <1 x double> poison, double %26, i64 0
  %gep.i = getelementptr double, ptr %15, i64 %24
  %28 = load <4 x double>, ptr %gep.i, align 8
  %29 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> zeroinitializer
  %30 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 1>
  %31 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 2>
  %32 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 3>
  %33 = fmul <1 x double> %27, %29
  %34 = fmul <1 x double> %27, %30
  %35 = fmul <1 x double> %27, %31
  %36 = shufflevector <1 x double> %35, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = fmul <1 x double> %27, %32
  %38 = shufflevector <1 x double> %37, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = shufflevector <1 x double> %33, <1 x double> %34, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = fadd <4 x double> %23, %41
  store <4 x double> %42, ptr %21, align 8
  %43 = or disjoint i64 %22, 1
  %44 = mul nuw nsw i64 %43, 96
  %45 = getelementptr double, ptr %20, i64 %43
  %46 = load double, ptr %45, align 8
  %47 = insertelement <1 x double> poison, double %46, i64 0
  %gep.i.1 = getelementptr double, ptr %15, i64 %44
  %48 = load <4 x double>, ptr %gep.i.1, align 8
  %49 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> zeroinitializer
  %50 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 1>
  %51 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 2>
  %52 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 3>
  %53 = fmul <1 x double> %47, %49
  %54 = fmul <1 x double> %47, %50
  %55 = fmul <1 x double> %47, %51
  %56 = shufflevector <1 x double> %55, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %57 = fmul <1 x double> %47, %52
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = shufflevector <1 x double> %53, <1 x double> %54, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %60 = shufflevector <4 x double> %59, <4 x double> %56, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %61 = shufflevector <4 x double> %60, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %62 = fadd <4 x double> %42, %61
  store <4 x double> %62, ptr %21, align 8
  %63 = add nuw nsw i64 %22, 2
  %exitcond.not.i.1 = icmp eq i64 %63, 24
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %64 = getelementptr double, ptr %21, i64 4
  %.promoted.1.i = load <4 x double>, ptr %64, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %65 = phi i64 [ 0, %.preheader.1.i ], [ %106, %.critedge.1.i ]
  %66 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %105, %.critedge.1.i ]
  %67 = mul nuw nsw i64 %65, 96
  %68 = getelementptr double, ptr %20, i64 %65
  %69 = load double, ptr %68, align 8
  %70 = insertelement <1 x double> poison, double %69, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %67
  %71 = load <4 x double>, ptr %gep.1.i, align 8
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> zeroinitializer
  %73 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 1>
  %74 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 2>
  %75 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 3>
  %76 = fmul <1 x double> %70, %72
  %77 = fmul <1 x double> %70, %73
  %78 = fmul <1 x double> %70, %74
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = fmul <1 x double> %70, %75
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = shufflevector <1 x double> %76, <1 x double> %77, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %84 = shufflevector <4 x double> %83, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %85 = fadd <4 x double> %66, %84
  store <4 x double> %85, ptr %64, align 8
  %86 = or disjoint i64 %65, 1
  %87 = mul nuw nsw i64 %86, 96
  %88 = getelementptr double, ptr %20, i64 %86
  %89 = load double, ptr %88, align 8
  %90 = insertelement <1 x double> poison, double %89, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %87
  %91 = load <4 x double>, ptr %gep.1.i.1, align 8
  %92 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> zeroinitializer
  %93 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 1>
  %94 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 2>
  %95 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 3>
  %96 = fmul <1 x double> %90, %92
  %97 = fmul <1 x double> %90, %93
  %98 = fmul <1 x double> %90, %94
  %99 = shufflevector <1 x double> %98, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %100 = fmul <1 x double> %90, %95
  %101 = shufflevector <1 x double> %100, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %102 = shufflevector <1 x double> %96, <1 x double> %97, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %99, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %101, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %105 = fadd <4 x double> %85, %104
  store <4 x double> %105, ptr %64, align 8
  %106 = add nuw nsw i64 %65, 2
  %exitcond.1.not.i.1 = icmp eq i64 %106, 24
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %107 = getelementptr double, ptr %21, i64 8
  %.promoted.2.i = load <4 x double>, ptr %107, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %108 = phi i64 [ 0, %.preheader.2.i ], [ %149, %.critedge.2.i ]
  %109 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %148, %.critedge.2.i ]
  %110 = mul nuw nsw i64 %108, 96
  %111 = getelementptr double, ptr %20, i64 %108
  %112 = load double, ptr %111, align 8
  %113 = insertelement <1 x double> poison, double %112, i64 0
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %110
  %114 = load <4 x double>, ptr %gep.2.i, align 8
  %115 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> zeroinitializer
  %116 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 1>
  %117 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 2>
  %118 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 3>
  %119 = fmul <1 x double> %113, %115
  %120 = fmul <1 x double> %113, %116
  %121 = fmul <1 x double> %113, %117
  %122 = shufflevector <1 x double> %121, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %123 = fmul <1 x double> %113, %118
  %124 = shufflevector <1 x double> %123, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %125 = shufflevector <1 x double> %119, <1 x double> %120, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %126 = shufflevector <4 x double> %125, <4 x double> %122, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %127 = shufflevector <4 x double> %126, <4 x double> %124, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %128 = fadd <4 x double> %109, %127
  store <4 x double> %128, ptr %107, align 8
  %129 = or disjoint i64 %108, 1
  %130 = mul nuw nsw i64 %129, 96
  %131 = getelementptr double, ptr %20, i64 %129
  %132 = load double, ptr %131, align 8
  %133 = insertelement <1 x double> poison, double %132, i64 0
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %130
  %134 = load <4 x double>, ptr %gep.2.i.1, align 8
  %135 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> zeroinitializer
  %136 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 1>
  %137 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 2>
  %138 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 3>
  %139 = fmul <1 x double> %133, %135
  %140 = fmul <1 x double> %133, %136
  %141 = fmul <1 x double> %133, %137
  %142 = shufflevector <1 x double> %141, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %143 = fmul <1 x double> %133, %138
  %144 = shufflevector <1 x double> %143, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %145 = shufflevector <1 x double> %139, <1 x double> %140, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %146 = shufflevector <4 x double> %145, <4 x double> %142, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %147 = shufflevector <4 x double> %146, <4 x double> %144, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %148 = fadd <4 x double> %128, %147
  store <4 x double> %148, ptr %107, align 8
  %149 = add nuw nsw i64 %108, 2
  %exitcond.2.not.i.1 = icmp eq i64 %149, 24
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %150 = getelementptr double, ptr %21, i64 12
  %.promoted.3.i = load <4 x double>, ptr %150, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %151 = phi i64 [ 0, %.preheader.3.i ], [ %192, %.critedge.3.i ]
  %152 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %191, %.critedge.3.i ]
  %153 = mul nuw nsw i64 %151, 96
  %154 = getelementptr double, ptr %20, i64 %151
  %155 = load double, ptr %154, align 8
  %156 = insertelement <1 x double> poison, double %155, i64 0
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %153
  %157 = load <4 x double>, ptr %gep.3.i, align 8
  %158 = shufflevector <4 x double> %157, <4 x double> poison, <1 x i32> zeroinitializer
  %159 = shufflevector <4 x double> %157, <4 x double> poison, <1 x i32> <i32 1>
  %160 = shufflevector <4 x double> %157, <4 x double> poison, <1 x i32> <i32 2>
  %161 = shufflevector <4 x double> %157, <4 x double> poison, <1 x i32> <i32 3>
  %162 = fmul <1 x double> %156, %158
  %163 = fmul <1 x double> %156, %159
  %164 = fmul <1 x double> %156, %160
  %165 = shufflevector <1 x double> %164, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %166 = fmul <1 x double> %156, %161
  %167 = shufflevector <1 x double> %166, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %168 = shufflevector <1 x double> %162, <1 x double> %163, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %169 = shufflevector <4 x double> %168, <4 x double> %165, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %170 = shufflevector <4 x double> %169, <4 x double> %167, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %171 = fadd <4 x double> %152, %170
  store <4 x double> %171, ptr %150, align 8
  %172 = or disjoint i64 %151, 1
  %173 = mul nuw nsw i64 %172, 96
  %174 = getelementptr double, ptr %20, i64 %172
  %175 = load double, ptr %174, align 8
  %176 = insertelement <1 x double> poison, double %175, i64 0
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %173
  %177 = load <4 x double>, ptr %gep.3.i.1, align 8
  %178 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> zeroinitializer
  %179 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 1>
  %180 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 2>
  %181 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 3>
  %182 = fmul <1 x double> %176, %178
  %183 = fmul <1 x double> %176, %179
  %184 = fmul <1 x double> %176, %180
  %185 = shufflevector <1 x double> %184, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %186 = fmul <1 x double> %176, %181
  %187 = shufflevector <1 x double> %186, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %188 = shufflevector <1 x double> %182, <1 x double> %183, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %189 = shufflevector <4 x double> %188, <4 x double> %185, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %190 = shufflevector <4 x double> %189, <4 x double> %187, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %191 = fadd <4 x double> %171, %190
  store <4 x double> %191, ptr %150, align 8
  %192 = add nuw nsw i64 %151, 2
  %exitcond.3.not.i.1 = icmp eq i64 %192, 24
  br i1 %exitcond.3.not.i.1, label %193, label %.critedge.3.i

193:                                              ; preds = %.critedge.3.i
  %194 = add nuw nsw i64 %16, 1
  %exitcond19.not.i = icmp eq i64 %194, 16
  br i1 %exitcond19.not.i, label %195, label %.preheader16.i

195:                                              ; preds = %193
  %196 = add nuw nsw i64 %14, 16
  %197 = icmp ult i64 %14, 80
  br i1 %197, label %13, label %198

198:                                              ; preds = %195
  %199 = add nuw nsw i64 %11, 16
  %200 = icmp ult i64 %11, 32
  br i1 %200, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %198
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %.unpack32.i, i8 0, i64 36864, i1 false)
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %197, %1
  %10 = phi i64 [ %198, %197 ], [ 0, %1 ]
  %11 = mul nuw nsw i64 %10, 96
  %invariant.gep.i.i = getelementptr double, ptr %.unpack32.i, i64 %11
  br label %12

12:                                               ; preds = %194, %.preheader17.i.i
  %13 = phi i64 [ 0, %.preheader17.i.i ], [ %195, %194 ]
  %14 = getelementptr double, ptr %.unpack17.i, i64 %13
  %gep20.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %13
  %invariant.gep.1.i.i = getelementptr double, ptr %14, i64 4
  %invariant.gep.2.i.i = getelementptr double, ptr %14, i64 8
  %invariant.gep.3.i.i = getelementptr double, ptr %14, i64 12
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %192, %12
  %15 = phi i64 [ 0, %12 ], [ %193, %192 ]
  %16 = add nuw nsw i64 %15, %10
  %17 = mul nuw nsw i64 %16, 24
  %18 = mul nuw nsw i64 %15, 96
  %19 = getelementptr double, ptr %.unpack2.i, i64 %17
  %20 = getelementptr double, ptr %gep20.i.i, i64 %18
  %.promoted.i.i = load <4 x double>, ptr %20, align 8
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader16.i.i
  %21 = phi i64 [ 0, %.preheader16.i.i ], [ %62, %.critedge.i.i ]
  %22 = phi <4 x double> [ %.promoted.i.i, %.preheader16.i.i ], [ %61, %.critedge.i.i ]
  %23 = mul nuw nsw i64 %21, 96
  %24 = getelementptr double, ptr %19, i64 %21
  %25 = load double, ptr %24, align 8
  %26 = insertelement <1 x double> poison, double %25, i64 0
  %gep.i.i = getelementptr double, ptr %14, i64 %23
  %27 = load <4 x double>, ptr %gep.i.i, align 8
  %28 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> zeroinitializer
  %29 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 1>
  %30 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 2>
  %31 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 3>
  %32 = fmul <1 x double> %26, %28
  %33 = fmul <1 x double> %26, %29
  %34 = fmul <1 x double> %26, %30
  %35 = shufflevector <1 x double> %34, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = fmul <1 x double> %26, %31
  %37 = shufflevector <1 x double> %36, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = shufflevector <1 x double> %32, <1 x double> %33, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %39 = shufflevector <4 x double> %38, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %41 = fadd <4 x double> %22, %40
  store <4 x double> %41, ptr %20, align 8
  %42 = or disjoint i64 %21, 1
  %43 = mul nuw nsw i64 %42, 96
  %44 = getelementptr double, ptr %19, i64 %42
  %45 = load double, ptr %44, align 8
  %46 = insertelement <1 x double> poison, double %45, i64 0
  %gep.i.i.1 = getelementptr double, ptr %14, i64 %43
  %47 = load <4 x double>, ptr %gep.i.i.1, align 8
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> zeroinitializer
  %49 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 1>
  %50 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 2>
  %51 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 3>
  %52 = fmul <1 x double> %46, %48
  %53 = fmul <1 x double> %46, %49
  %54 = fmul <1 x double> %46, %50
  %55 = shufflevector <1 x double> %54, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %56 = fmul <1 x double> %46, %51
  %57 = shufflevector <1 x double> %56, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %58 = shufflevector <1 x double> %52, <1 x double> %53, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %55, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %60 = shufflevector <4 x double> %59, <4 x double> %57, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %61 = fadd <4 x double> %41, %60
  store <4 x double> %61, ptr %20, align 8
  %62 = add nuw nsw i64 %21, 2
  %exitcond.not.i.i.1 = icmp eq i64 %62, 24
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %63 = getelementptr double, ptr %20, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %63, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %64 = phi i64 [ 0, %.preheader.1.i.i ], [ %105, %.critedge.1.i.i ]
  %65 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %104, %.critedge.1.i.i ]
  %66 = mul nuw nsw i64 %64, 96
  %67 = getelementptr double, ptr %19, i64 %64
  %68 = load double, ptr %67, align 8
  %69 = insertelement <1 x double> poison, double %68, i64 0
  %gep.1.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %66
  %70 = load <4 x double>, ptr %gep.1.i.i, align 8
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> zeroinitializer
  %72 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 1>
  %73 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 2>
  %74 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 3>
  %75 = fmul <1 x double> %69, %71
  %76 = fmul <1 x double> %69, %72
  %77 = fmul <1 x double> %69, %73
  %78 = shufflevector <1 x double> %77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = fmul <1 x double> %69, %74
  %80 = shufflevector <1 x double> %79, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = shufflevector <1 x double> %75, <1 x double> %76, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %82 = shufflevector <4 x double> %81, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %84 = fadd <4 x double> %65, %83
  store <4 x double> %84, ptr %63, align 8
  %85 = or disjoint i64 %64, 1
  %86 = mul nuw nsw i64 %85, 96
  %87 = getelementptr double, ptr %19, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = insertelement <1 x double> poison, double %88, i64 0
  %gep.1.i.i.1 = getelementptr double, ptr %invariant.gep.1.i.i, i64 %86
  %90 = load <4 x double>, ptr %gep.1.i.i.1, align 8
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> zeroinitializer
  %92 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 1>
  %93 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 2>
  %94 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 3>
  %95 = fmul <1 x double> %89, %91
  %96 = fmul <1 x double> %89, %92
  %97 = fmul <1 x double> %89, %93
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = fmul <1 x double> %89, %94
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %95, <1 x double> %96, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %104 = fadd <4 x double> %84, %103
  store <4 x double> %104, ptr %63, align 8
  %105 = add nuw nsw i64 %64, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %105, 24
  br i1 %exitcond.1.not.i.i.1, label %.preheader.2.i.i, label %.critedge.1.i.i

.preheader.2.i.i:                                 ; preds = %.critedge.1.i.i
  %106 = getelementptr double, ptr %20, i64 8
  %.promoted.2.i.i = load <4 x double>, ptr %106, align 8
  br label %.critedge.2.i.i

.critedge.2.i.i:                                  ; preds = %.critedge.2.i.i, %.preheader.2.i.i
  %107 = phi i64 [ 0, %.preheader.2.i.i ], [ %148, %.critedge.2.i.i ]
  %108 = phi <4 x double> [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %147, %.critedge.2.i.i ]
  %109 = mul nuw nsw i64 %107, 96
  %110 = getelementptr double, ptr %19, i64 %107
  %111 = load double, ptr %110, align 8
  %112 = insertelement <1 x double> poison, double %111, i64 0
  %gep.2.i.i = getelementptr double, ptr %invariant.gep.2.i.i, i64 %109
  %113 = load <4 x double>, ptr %gep.2.i.i, align 8
  %114 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> zeroinitializer
  %115 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 1>
  %116 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 2>
  %117 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 3>
  %118 = fmul <1 x double> %112, %114
  %119 = fmul <1 x double> %112, %115
  %120 = fmul <1 x double> %112, %116
  %121 = shufflevector <1 x double> %120, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %122 = fmul <1 x double> %112, %117
  %123 = shufflevector <1 x double> %122, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %124 = shufflevector <1 x double> %118, <1 x double> %119, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %125 = shufflevector <4 x double> %124, <4 x double> %121, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %126 = shufflevector <4 x double> %125, <4 x double> %123, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %127 = fadd <4 x double> %108, %126
  store <4 x double> %127, ptr %106, align 8
  %128 = or disjoint i64 %107, 1
  %129 = mul nuw nsw i64 %128, 96
  %130 = getelementptr double, ptr %19, i64 %128
  %131 = load double, ptr %130, align 8
  %132 = insertelement <1 x double> poison, double %131, i64 0
  %gep.2.i.i.1 = getelementptr double, ptr %invariant.gep.2.i.i, i64 %129
  %133 = load <4 x double>, ptr %gep.2.i.i.1, align 8
  %134 = shufflevector <4 x double> %133, <4 x double> poison, <1 x i32> zeroinitializer
  %135 = shufflevector <4 x double> %133, <4 x double> poison, <1 x i32> <i32 1>
  %136 = shufflevector <4 x double> %133, <4 x double> poison, <1 x i32> <i32 2>
  %137 = shufflevector <4 x double> %133, <4 x double> poison, <1 x i32> <i32 3>
  %138 = fmul <1 x double> %132, %134
  %139 = fmul <1 x double> %132, %135
  %140 = fmul <1 x double> %132, %136
  %141 = shufflevector <1 x double> %140, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %142 = fmul <1 x double> %132, %137
  %143 = shufflevector <1 x double> %142, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %144 = shufflevector <1 x double> %138, <1 x double> %139, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %145 = shufflevector <4 x double> %144, <4 x double> %141, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %146 = shufflevector <4 x double> %145, <4 x double> %143, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %147 = fadd <4 x double> %127, %146
  store <4 x double> %147, ptr %106, align 8
  %148 = add nuw nsw i64 %107, 2
  %exitcond.2.not.i.i.1 = icmp eq i64 %148, 24
  br i1 %exitcond.2.not.i.i.1, label %.preheader.3.i.i, label %.critedge.2.i.i

.preheader.3.i.i:                                 ; preds = %.critedge.2.i.i
  %149 = getelementptr double, ptr %20, i64 12
  %.promoted.3.i.i = load <4 x double>, ptr %149, align 8
  br label %.critedge.3.i.i

.critedge.3.i.i:                                  ; preds = %.critedge.3.i.i, %.preheader.3.i.i
  %150 = phi i64 [ 0, %.preheader.3.i.i ], [ %191, %.critedge.3.i.i ]
  %151 = phi <4 x double> [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %190, %.critedge.3.i.i ]
  %152 = mul nuw nsw i64 %150, 96
  %153 = getelementptr double, ptr %19, i64 %150
  %154 = load double, ptr %153, align 8
  %155 = insertelement <1 x double> poison, double %154, i64 0
  %gep.3.i.i = getelementptr double, ptr %invariant.gep.3.i.i, i64 %152
  %156 = load <4 x double>, ptr %gep.3.i.i, align 8
  %157 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> zeroinitializer
  %158 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 1>
  %159 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 2>
  %160 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 3>
  %161 = fmul <1 x double> %155, %157
  %162 = fmul <1 x double> %155, %158
  %163 = fmul <1 x double> %155, %159
  %164 = shufflevector <1 x double> %163, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %165 = fmul <1 x double> %155, %160
  %166 = shufflevector <1 x double> %165, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %167 = shufflevector <1 x double> %161, <1 x double> %162, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %168 = shufflevector <4 x double> %167, <4 x double> %164, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %169 = shufflevector <4 x double> %168, <4 x double> %166, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %170 = fadd <4 x double> %151, %169
  store <4 x double> %170, ptr %149, align 8
  %171 = or disjoint i64 %150, 1
  %172 = mul nuw nsw i64 %171, 96
  %173 = getelementptr double, ptr %19, i64 %171
  %174 = load double, ptr %173, align 8
  %175 = insertelement <1 x double> poison, double %174, i64 0
  %gep.3.i.i.1 = getelementptr double, ptr %invariant.gep.3.i.i, i64 %172
  %176 = load <4 x double>, ptr %gep.3.i.i.1, align 8
  %177 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> zeroinitializer
  %178 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 1>
  %179 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 2>
  %180 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 3>
  %181 = fmul <1 x double> %175, %177
  %182 = fmul <1 x double> %175, %178
  %183 = fmul <1 x double> %175, %179
  %184 = shufflevector <1 x double> %183, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %185 = fmul <1 x double> %175, %180
  %186 = shufflevector <1 x double> %185, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %187 = shufflevector <1 x double> %181, <1 x double> %182, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %188 = shufflevector <4 x double> %187, <4 x double> %184, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %189 = shufflevector <4 x double> %188, <4 x double> %186, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %190 = fadd <4 x double> %170, %189
  store <4 x double> %190, ptr %149, align 8
  %191 = add nuw nsw i64 %150, 2
  %exitcond.3.not.i.i.1 = icmp eq i64 %191, 24
  br i1 %exitcond.3.not.i.i.1, label %192, label %.critedge.3.i.i

192:                                              ; preds = %.critedge.3.i.i
  %193 = add nuw nsw i64 %15, 1
  %exitcond19.not.i.i = icmp eq i64 %193, 16
  br i1 %exitcond19.not.i.i, label %194, label %.preheader16.i.i

194:                                              ; preds = %192
  %195 = add nuw nsw i64 %13, 16
  %196 = icmp ult i64 %13, 80
  br i1 %196, label %12, label %197

197:                                              ; preds = %194
  %198 = add nuw nsw i64 %10, 16
  %199 = icmp ult i64 %10, 32
  br i1 %199, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %197
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
