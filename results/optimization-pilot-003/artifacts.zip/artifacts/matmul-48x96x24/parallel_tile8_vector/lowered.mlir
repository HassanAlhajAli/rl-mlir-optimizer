module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(24 : index) : i64
    %29 = llvm.mlir.constant(96 : index) : i64
    %30 = llvm.mlir.constant(48 : index) : i64
    %31 = llvm.mlir.constant(1 : index) : i64
    %32 = llvm.mlir.constant(4 : index) : i64
    %33 = llvm.mlir.constant(0 : index) : i64
    %34 = llvm.mlir.constant(8 : index) : i64
    %35 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%33 : i64)
  ^bb1(%36: i64):  // 2 preds: ^bb0, ^bb5
    %37 = llvm.icmp "slt" %36, %30 : i64
    llvm.cond_br %37, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%33 : i64)
  ^bb3(%38: i64):  // 2 preds: ^bb2, ^bb4
    %39 = llvm.icmp "slt" %38, %29 : i64
    llvm.cond_br %39, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %40 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %41 = llvm.mlir.constant(96 : index) : i64
    %42 = llvm.mul %36, %41  : i64
    %43 = llvm.add %42, %38  : i64
    %44 = llvm.getelementptr %40[%43] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %35, %44 : f64, !llvm.ptr
    %45 = llvm.add %38, %31  : i64
    llvm.br ^bb3(%45 : i64)
  ^bb5:  // pred: ^bb3
    %46 = llvm.add %36, %31  : i64
    llvm.br ^bb1(%46 : i64)
  ^bb6:  // pred: ^bb1
    %47 = llvm.mlir.constant(1 : index) : i64
    %48 = llvm.alloca %47 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %49 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %50 = llvm.insertvalue %48, %49[0] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.insertvalue %48, %50[1] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(0 : index) : i64
    %53 = llvm.insertvalue %52, %51[2] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.mlir.constant(1 : index) : i64
    %55 = llvm.alloca %54 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %56 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %57 = llvm.insertvalue %55, %56[0] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.insertvalue %55, %57[1] : !llvm.struct<(ptr, ptr, i64)> 
    %59 = llvm.mlir.constant(0 : index) : i64
    %60 = llvm.insertvalue %59, %58[2] : !llvm.struct<(ptr, ptr, i64)> 
    %61 = llvm.mlir.constant(1 : index) : i64
    %62 = llvm.alloca %61 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %63 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %64 = llvm.insertvalue %62, %63[0] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.insertvalue %62, %64[1] : !llvm.struct<(ptr, ptr, i64)> 
    %66 = llvm.mlir.constant(0 : index) : i64
    %67 = llvm.insertvalue %66, %65[2] : !llvm.struct<(ptr, ptr, i64)> 
    %68 = llvm.mlir.constant(1 : index) : i64
    %69 = llvm.alloca %68 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %70 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %71 = llvm.insertvalue %69, %70[0] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.insertvalue %69, %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %73 = llvm.mlir.constant(0 : index) : i64
    %74 = llvm.insertvalue %73, %72[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%33 : i64)
  ^bb7(%75: i64):  // 2 preds: ^bb6, ^bb32
    %76 = llvm.icmp "slt" %75, %30 : i64
    llvm.cond_br %76, ^bb8, ^bb33
  ^bb8:  // pred: ^bb7
    %77 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %80 = llvm.insertvalue %77, %79[0] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.insertvalue %78, %80[1] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.mlir.constant(0 : index) : i64
    %83 = llvm.insertvalue %82, %81[2] : !llvm.struct<(ptr, ptr, i64)> 
    %84 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.mul %75, %28  : i64
    %90 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %92 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %93 = llvm.insertvalue %90, %92[0] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.insertvalue %91, %93[1] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.mlir.constant(0 : index) : i64
    %96 = llvm.insertvalue %95, %94[2] : !llvm.struct<(ptr, ptr, i64)> 
    %97 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %101 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %102 = llvm.mul %75, %29  : i64
    llvm.br ^bb9(%33 : i64)
  ^bb9(%103: i64):  // 2 preds: ^bb8, ^bb31
    %104 = llvm.icmp "slt" %103, %29 : i64
    llvm.cond_br %104, ^bb10, ^bb32
  ^bb10:  // pred: ^bb9
    %105 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %108 = llvm.insertvalue %105, %107[0] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.insertvalue %106, %108[1] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.mlir.constant(0 : index) : i64
    %111 = llvm.insertvalue %110, %109[2] : !llvm.struct<(ptr, ptr, i64)> 
    %112 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.add %102, %103  : i64
    llvm.br ^bb11(%33 : i64)
  ^bb11(%118: i64):  // 2 preds: ^bb10, ^bb30
    %119 = llvm.icmp "slt" %118, %34 : i64
    llvm.cond_br %119, ^bb12, ^bb31
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%33 : i64)
  ^bb13(%120: i64):  // 2 preds: ^bb12, ^bb29
    %121 = llvm.icmp "slt" %120, %34 : i64
    llvm.cond_br %121, ^bb14, ^bb30
  ^bb14:  // pred: ^bb13
    llvm.br ^bb15(%33 : i64)
  ^bb15(%122: i64):  // 2 preds: ^bb14, ^bb28
    %123 = llvm.icmp "slt" %122, %28 : i64
    llvm.cond_br %123, ^bb16, ^bb29
  ^bb16:  // pred: ^bb15
    %124 = llvm.mul %118, %28  : i64
    %125 = llvm.add %89, %124  : i64
    %126 = llvm.add %125, %122  : i64
    %127 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %128 = llvm.insertvalue %77, %127[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %78, %128[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.insertvalue %126, %129[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.mlir.constant(1 : index) : i64
    %132 = llvm.insertvalue %131, %130[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.mlir.constant(24 : index) : i64
    %134 = llvm.insertvalue %133, %132[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %135 = llvm.mlir.constant(1 : index) : i64
    %136 = llvm.insertvalue %135, %134[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %137 = llvm.mlir.constant(1 : index) : i64
    %138 = llvm.insertvalue %137, %136[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.mul %122, %29  : i64
    %140 = llvm.add %103, %139  : i64
    %141 = llvm.add %140, %120  : i64
    %142 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %143 = llvm.insertvalue %105, %142[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.insertvalue %106, %143[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.insertvalue %141, %144[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.mlir.constant(1 : index) : i64
    %147 = llvm.insertvalue %146, %145[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.mlir.constant(96 : index) : i64
    %149 = llvm.insertvalue %148, %147[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.mlir.constant(4 : index) : i64
    %151 = llvm.insertvalue %150, %149[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.mlir.constant(1 : index) : i64
    %153 = llvm.insertvalue %152, %151[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.mul %118, %29  : i64
    %155 = llvm.add %117, %154  : i64
    %156 = llvm.add %155, %120  : i64
    %157 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %158 = llvm.insertvalue %90, %157[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %159 = llvm.insertvalue %91, %158[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %160 = llvm.insertvalue %156, %159[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %161 = llvm.mlir.constant(1 : index) : i64
    %162 = llvm.insertvalue %161, %160[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %163 = llvm.mlir.constant(96 : index) : i64
    %164 = llvm.insertvalue %163, %162[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %165 = llvm.mlir.constant(4 : index) : i64
    %166 = llvm.insertvalue %165, %164[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %167 = llvm.mlir.constant(1 : index) : i64
    %168 = llvm.insertvalue %167, %166[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %169 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %170 = llvm.extractvalue %53[0] : !llvm.struct<(ptr, ptr, i64)> 
    %171 = llvm.insertvalue %170, %169[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %172 = llvm.extractvalue %53[1] : !llvm.struct<(ptr, ptr, i64)> 
    %173 = llvm.insertvalue %172, %171[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %174 = llvm.mlir.constant(0 : index) : i64
    %175 = llvm.insertvalue %174, %173[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.mlir.constant(1 : index) : i64
    %177 = llvm.insertvalue %176, %175[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %178 = llvm.mlir.constant(1 : index) : i64
    %179 = llvm.insertvalue %178, %177[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb17(%33 : i64)
  ^bb17(%180: i64):  // 2 preds: ^bb16, ^bb18
    %181 = llvm.icmp "slt" %180, %31 : i64
    llvm.cond_br %181, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    %182 = llvm.getelementptr %78[%126] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %183 = llvm.mlir.constant(24 : index) : i64
    %184 = llvm.mul %180, %183  : i64
    %185 = llvm.add %184, %33  : i64
    %186 = llvm.getelementptr %182[%185] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %187 = llvm.load %186 : !llvm.ptr -> f64
    %188 = llvm.mlir.undef : vector<1xf64>
    %189 = llvm.mlir.constant(0 : i32) : i32
    %190 = llvm.insertelement %187, %188[%189 : i32] : vector<1xf64>
    %191 = llvm.shufflevector %190, %188 [0] : vector<1xf64> 
    %192 = llvm.getelementptr %172[%180] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %191, %192 : vector<1xf64>, !llvm.ptr
    %193 = llvm.add %180, %31  : i64
    llvm.br ^bb17(%193 : i64)
  ^bb19:  // pred: ^bb17
    %194 = llvm.load %48 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %195 = llvm.extractvalue %194[0] : !llvm.array<1 x vector<1xf64>> 
    %196 = llvm.insertvalue %195, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %197 = llvm.insertvalue %195, %196[1] : !llvm.array<4 x vector<1xf64>> 
    %198 = llvm.insertvalue %195, %197[2] : !llvm.array<4 x vector<1xf64>> 
    %199 = llvm.insertvalue %195, %198[3] : !llvm.array<4 x vector<1xf64>> 
    %200 = llvm.insertvalue %199, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %201 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %202 = llvm.extractvalue %60[0] : !llvm.struct<(ptr, ptr, i64)> 
    %203 = llvm.insertvalue %202, %201[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.extractvalue %60[1] : !llvm.struct<(ptr, ptr, i64)> 
    %205 = llvm.insertvalue %204, %203[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %206 = llvm.mlir.constant(0 : index) : i64
    %207 = llvm.insertvalue %206, %205[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %208 = llvm.mlir.constant(1 : index) : i64
    %209 = llvm.insertvalue %208, %207[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %210 = llvm.mlir.constant(1 : index) : i64
    %211 = llvm.insertvalue %210, %209[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb20(%33 : i64)
  ^bb20(%212: i64):  // 2 preds: ^bb19, ^bb21
    %213 = llvm.icmp "slt" %212, %31 : i64
    llvm.cond_br %213, ^bb21, ^bb22
  ^bb21:  // pred: ^bb20
    %214 = llvm.extractvalue %153[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %215 = llvm.extractvalue %153[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %216 = llvm.getelementptr %214[%215] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %217 = llvm.mlir.constant(96 : index) : i64
    %218 = llvm.mul %212, %217  : i64
    %219 = llvm.add %218, %33  : i64
    %220 = llvm.getelementptr %216[%219] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %221 = llvm.load %220 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %222 = llvm.getelementptr %204[%212] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %221, %222 : vector<4xf64>, !llvm.ptr
    %223 = llvm.add %212, %31  : i64
    llvm.br ^bb20(%223 : i64)
  ^bb22:  // pred: ^bb20
    %224 = llvm.load %55 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %225 = llvm.extractvalue %224[0] : !llvm.array<1 x vector<4xf64>> 
    %226 = llvm.mlir.constant(0 : i64) : i64
    %227 = llvm.extractelement %225[%226 : i64] : vector<4xf64>
    %228 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %229 = llvm.mlir.constant(0 : i64) : i64
    %230 = llvm.insertelement %227, %228[%229 : i64] : vector<1xf64>
    %231 = llvm.insertvalue %230, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %232 = llvm.extractvalue %224[0] : !llvm.array<1 x vector<4xf64>> 
    %233 = llvm.mlir.constant(1 : i64) : i64
    %234 = llvm.extractelement %232[%233 : i64] : vector<4xf64>
    %235 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %236 = llvm.mlir.constant(0 : i64) : i64
    %237 = llvm.insertelement %234, %235[%236 : i64] : vector<1xf64>
    %238 = llvm.insertvalue %237, %231[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %239 = llvm.extractvalue %224[0] : !llvm.array<1 x vector<4xf64>> 
    %240 = llvm.mlir.constant(2 : i64) : i64
    %241 = llvm.extractelement %239[%240 : i64] : vector<4xf64>
    %242 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %243 = llvm.mlir.constant(0 : i64) : i64
    %244 = llvm.insertelement %241, %242[%243 : i64] : vector<1xf64>
    %245 = llvm.insertvalue %244, %238[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %246 = llvm.extractvalue %224[0] : !llvm.array<1 x vector<4xf64>> 
    %247 = llvm.mlir.constant(3 : i64) : i64
    %248 = llvm.extractelement %246[%247 : i64] : vector<4xf64>
    %249 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %250 = llvm.mlir.constant(0 : i64) : i64
    %251 = llvm.insertelement %248, %249[%250 : i64] : vector<1xf64>
    %252 = llvm.insertvalue %251, %245[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %253 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %254 = llvm.extractvalue %67[0] : !llvm.struct<(ptr, ptr, i64)> 
    %255 = llvm.insertvalue %254, %253[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.extractvalue %67[1] : !llvm.struct<(ptr, ptr, i64)> 
    %257 = llvm.insertvalue %256, %255[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %258 = llvm.mlir.constant(0 : index) : i64
    %259 = llvm.insertvalue %258, %257[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %260 = llvm.mlir.constant(1 : index) : i64
    %261 = llvm.insertvalue %260, %259[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %262 = llvm.mlir.constant(1 : index) : i64
    %263 = llvm.insertvalue %262, %261[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb23(%33 : i64)
  ^bb23(%264: i64):  // 2 preds: ^bb22, ^bb24
    %265 = llvm.icmp "slt" %264, %31 : i64
    llvm.cond_br %265, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %266 = llvm.extractvalue %168[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %267 = llvm.extractvalue %168[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %268 = llvm.getelementptr %266[%267] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %269 = llvm.mlir.constant(96 : index) : i64
    %270 = llvm.mul %264, %269  : i64
    %271 = llvm.add %270, %33  : i64
    %272 = llvm.getelementptr %268[%271] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %273 = llvm.load %272 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %274 = llvm.getelementptr %256[%264] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %273, %274 : vector<4xf64>, !llvm.ptr
    %275 = llvm.add %264, %31  : i64
    llvm.br ^bb23(%275 : i64)
  ^bb25:  // pred: ^bb23
    %276 = llvm.load %62 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %277 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %278 = llvm.extractvalue %200[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %279 = llvm.fmul %278, %230  : vector<1xf64>
    %280 = llvm.insertvalue %279, %277[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %281 = llvm.extractvalue %200[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %282 = llvm.fmul %281, %237  : vector<1xf64>
    %283 = llvm.insertvalue %282, %280[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %284 = llvm.extractvalue %200[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %285 = llvm.fmul %284, %244  : vector<1xf64>
    %286 = llvm.insertvalue %285, %283[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %287 = llvm.extractvalue %200[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %288 = llvm.fmul %287, %251  : vector<1xf64>
    %289 = llvm.insertvalue %288, %286[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %290 = llvm.extractvalue %289[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %291 = llvm.mlir.constant(0 : i64) : i64
    %292 = llvm.extractelement %290[%291 : i64] : vector<1xf64>
    %293 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %294 = llvm.mlir.constant(0 : i64) : i64
    %295 = llvm.insertelement %292, %293[%294 : i64] : vector<4xf64>
    %296 = llvm.insertvalue %295, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %297 = llvm.extractvalue %289[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %298 = llvm.mlir.constant(0 : i64) : i64
    %299 = llvm.extractelement %297[%298 : i64] : vector<1xf64>
    %300 = llvm.mlir.constant(1 : i64) : i64
    %301 = llvm.insertelement %299, %295[%300 : i64] : vector<4xf64>
    %302 = llvm.insertvalue %301, %296[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %303 = llvm.extractvalue %289[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %304 = llvm.mlir.constant(0 : i64) : i64
    %305 = llvm.extractelement %303[%304 : i64] : vector<1xf64>
    %306 = llvm.mlir.constant(2 : i64) : i64
    %307 = llvm.insertelement %305, %301[%306 : i64] : vector<4xf64>
    %308 = llvm.insertvalue %307, %302[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %309 = llvm.extractvalue %289[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %310 = llvm.mlir.constant(0 : i64) : i64
    %311 = llvm.extractelement %309[%310 : i64] : vector<1xf64>
    %312 = llvm.mlir.constant(3 : i64) : i64
    %313 = llvm.insertelement %311, %307[%312 : i64] : vector<4xf64>
    %314 = llvm.insertvalue %313, %308[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %315 = llvm.extractvalue %276[0] : !llvm.array<1 x vector<4xf64>> 
    %316 = llvm.fadd %313, %315  : vector<4xf64>
    %317 = llvm.insertvalue %316, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %317, %69 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %318 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %319 = llvm.extractvalue %74[0] : !llvm.struct<(ptr, ptr, i64)> 
    %320 = llvm.insertvalue %319, %318[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.extractvalue %74[1] : !llvm.struct<(ptr, ptr, i64)> 
    %322 = llvm.insertvalue %321, %320[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %323 = llvm.mlir.constant(0 : index) : i64
    %324 = llvm.insertvalue %323, %322[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %325 = llvm.mlir.constant(1 : index) : i64
    %326 = llvm.insertvalue %325, %324[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %327 = llvm.mlir.constant(1 : index) : i64
    %328 = llvm.insertvalue %327, %326[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb26(%33 : i64)
  ^bb26(%329: i64):  // 2 preds: ^bb25, ^bb27
    %330 = llvm.icmp "slt" %329, %31 : i64
    llvm.cond_br %330, ^bb27, ^bb28
  ^bb27:  // pred: ^bb26
    %331 = llvm.getelementptr %321[%329] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %332 = llvm.load %331 : !llvm.ptr -> vector<4xf64>
    %333 = llvm.extractvalue %168[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %334 = llvm.extractvalue %168[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %335 = llvm.getelementptr %333[%334] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %336 = llvm.mlir.constant(96 : index) : i64
    %337 = llvm.mul %329, %336  : i64
    %338 = llvm.add %337, %33  : i64
    %339 = llvm.getelementptr %335[%338] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %332, %339 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %340 = llvm.add %329, %31  : i64
    llvm.br ^bb26(%340 : i64)
  ^bb28:  // pred: ^bb26
    %341 = llvm.add %122, %31  : i64
    llvm.br ^bb15(%341 : i64)
  ^bb29:  // pred: ^bb15
    %342 = llvm.add %120, %32  : i64
    llvm.br ^bb13(%342 : i64)
  ^bb30:  // pred: ^bb13
    %343 = llvm.add %118, %31  : i64
    llvm.br ^bb11(%343 : i64)
  ^bb31:  // pred: ^bb11
    %344 = llvm.add %103, %34  : i64
    llvm.br ^bb9(%344 : i64)
  ^bb32:  // pred: ^bb9
    %345 = llvm.add %75, %34  : i64
    llvm.br ^bb7(%345 : i64)
  ^bb33:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
