; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %15, i8 0, i64 36864, i1 false)
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %122
  %21 = phi i64 [ %123, %122 ], [ 0, %.preheader17.preheader ]
  %22 = mul nuw nsw i64 %21, 96
  %invariant.gep = getelementptr double, ptr %15, i64 %22
  br label %23

23:                                               ; preds = %.preheader17, %119
  %24 = phi i64 [ 0, %.preheader17 ], [ %120, %119 ]
  %25 = getelementptr double, ptr %8, i64 %24
  %gep20 = getelementptr double, ptr %invariant.gep, i64 %24
  %invariant.gep.1 = getelementptr double, ptr %25, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %23, %117
  %26 = phi i64 [ 0, %23 ], [ %118, %117 ]
  %27 = add nuw nsw i64 %26, %21
  %28 = mul nuw nsw i64 %27, 24
  %29 = mul nuw nsw i64 %26, 96
  %30 = getelementptr double, ptr %1, i64 %28
  %31 = getelementptr double, ptr %gep20, i64 %29
  %.promoted = load <4 x double>, ptr %31, align 8
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %32 = phi i64 [ 0, %.preheader16 ], [ %73, %.critedge ]
  %33 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %72, %.critedge ]
  %34 = mul nuw nsw i64 %32, 96
  %35 = getelementptr double, ptr %30, i64 %32
  %36 = load double, ptr %35, align 8
  %37 = insertelement <1 x double> poison, double %36, i64 0
  %gep = getelementptr double, ptr %25, i64 %34
  %38 = load <4 x double>, ptr %gep, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %37, %39
  %44 = fmul <1 x double> %37, %40
  %45 = fmul <1 x double> %37, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %37, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %33, %51
  store <4 x double> %52, ptr %31, align 8
  %53 = or disjoint i64 %32, 1
  %54 = mul nuw nsw i64 %53, 96
  %55 = getelementptr double, ptr %30, i64 %53
  %56 = load double, ptr %55, align 8
  %57 = insertelement <1 x double> poison, double %56, i64 0
  %gep.121 = getelementptr double, ptr %25, i64 %54
  %58 = load <4 x double>, ptr %gep.121, align 8
  %59 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> zeroinitializer
  %60 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 1>
  %61 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 2>
  %62 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 3>
  %63 = fmul <1 x double> %57, %59
  %64 = fmul <1 x double> %57, %60
  %65 = fmul <1 x double> %57, %61
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = fmul <1 x double> %57, %62
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %63, <1 x double> %64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %72 = fadd <4 x double> %52, %71
  store <4 x double> %72, ptr %31, align 8
  %73 = add nuw nsw i64 %32, 2
  %exitcond.not.1 = icmp eq i64 %73, 24
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %74 = getelementptr double, ptr %31, i64 4
  %.promoted.1 = load <4 x double>, ptr %74, align 8
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %75 = phi i64 [ 0, %.preheader.1 ], [ %116, %.critedge.1 ]
  %76 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %115, %.critedge.1 ]
  %77 = mul nuw nsw i64 %75, 96
  %78 = getelementptr double, ptr %30, i64 %75
  %79 = load double, ptr %78, align 8
  %80 = insertelement <1 x double> poison, double %79, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %77
  %81 = load <4 x double>, ptr %gep.1, align 8
  %82 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %80, %82
  %87 = fmul <1 x double> %80, %83
  %88 = fmul <1 x double> %80, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %80, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %74, align 8
  %96 = or disjoint i64 %75, 1
  %97 = mul nuw nsw i64 %96, 96
  %98 = getelementptr double, ptr %30, i64 %96
  %99 = load double, ptr %98, align 8
  %100 = insertelement <1 x double> poison, double %99, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %97
  %101 = load <4 x double>, ptr %gep.1.1, align 8
  %102 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> zeroinitializer
  %103 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 1>
  %104 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 2>
  %105 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 3>
  %106 = fmul <1 x double> %100, %102
  %107 = fmul <1 x double> %100, %103
  %108 = fmul <1 x double> %100, %104
  %109 = shufflevector <1 x double> %108, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %110 = fmul <1 x double> %100, %105
  %111 = shufflevector <1 x double> %110, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %112 = shufflevector <1 x double> %106, <1 x double> %107, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %109, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %111, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %115 = fadd <4 x double> %95, %114
  store <4 x double> %115, ptr %74, align 8
  %116 = add nuw nsw i64 %75, 2
  %exitcond.1.not.1 = icmp eq i64 %116, 24
  br i1 %exitcond.1.not.1, label %117, label %.critedge.1

117:                                              ; preds = %.critedge.1
  %118 = add nuw nsw i64 %26, 1
  %exitcond19.not = icmp eq i64 %118, 8
  br i1 %exitcond19.not, label %119, label %.preheader16

119:                                              ; preds = %117
  %120 = add nuw nsw i64 %24, 8
  %121 = icmp ult i64 %24, 88
  br i1 %121, label %23, label %122

122:                                              ; preds = %119
  %123 = add nuw nsw i64 %21, 8
  %124 = icmp ult i64 %21, 40
  br i1 %124, label %.preheader17, label %125

125:                                              ; preds = %122
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %.unpack32, i8 0, i64 36864, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %105, %3
  %4 = phi i64 [ %106, %105 ], [ 0, %3 ]
  %5 = mul nuw nsw i64 %4, 96
  %invariant.gep.i = getelementptr double, ptr %.unpack32, i64 %5
  br label %6

6:                                                ; preds = %102, %.preheader17.i
  %7 = phi i64 [ 0, %.preheader17.i ], [ %103, %102 ]
  %8 = getelementptr double, ptr %.unpack17, i64 %7
  %gep20.i = getelementptr double, ptr %invariant.gep.i, i64 %7
  %invariant.gep.1.i = getelementptr double, ptr %8, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %100, %6
  %9 = phi i64 [ 0, %6 ], [ %101, %100 ]
  %10 = add nuw nsw i64 %9, %4
  %11 = mul nuw nsw i64 %10, 24
  %12 = mul nuw nsw i64 %9, 96
  %13 = getelementptr double, ptr %.unpack2, i64 %11
  %14 = getelementptr double, ptr %gep20.i, i64 %12
  %.promoted.i = load <4 x double>, ptr %14, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %15 = phi i64 [ 0, %.preheader16.i ], [ %56, %.critedge.i ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %55, %.critedge.i ]
  %17 = mul nuw nsw i64 %15, 96
  %18 = getelementptr double, ptr %13, i64 %15
  %19 = load double, ptr %18, align 8
  %20 = insertelement <1 x double> poison, double %19, i64 0
  %gep.i = getelementptr double, ptr %8, i64 %17
  %21 = load <4 x double>, ptr %gep.i, align 8
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> zeroinitializer
  %23 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 1>
  %24 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 2>
  %25 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 3>
  %26 = fmul <1 x double> %20, %22
  %27 = fmul <1 x double> %20, %23
  %28 = fmul <1 x double> %20, %24
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = fmul <1 x double> %20, %25
  %31 = shufflevector <1 x double> %30, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = shufflevector <1 x double> %26, <1 x double> %27, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = fadd <4 x double> %16, %34
  store <4 x double> %35, ptr %14, align 8
  %36 = or disjoint i64 %15, 1
  %37 = mul nuw nsw i64 %36, 96
  %38 = getelementptr double, ptr %13, i64 %36
  %39 = load double, ptr %38, align 8
  %40 = insertelement <1 x double> poison, double %39, i64 0
  %gep.i.1 = getelementptr double, ptr %8, i64 %37
  %41 = load <4 x double>, ptr %gep.i.1, align 8
  %42 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> zeroinitializer
  %43 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 1>
  %44 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 2>
  %45 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 3>
  %46 = fmul <1 x double> %40, %42
  %47 = fmul <1 x double> %40, %43
  %48 = fmul <1 x double> %40, %44
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = fmul <1 x double> %40, %45
  %51 = shufflevector <1 x double> %50, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %52 = shufflevector <1 x double> %46, <1 x double> %47, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %54 = shufflevector <4 x double> %53, <4 x double> %51, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %55 = fadd <4 x double> %35, %54
  store <4 x double> %55, ptr %14, align 8
  %56 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %56, 24
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %57 = getelementptr double, ptr %14, i64 4
  %.promoted.1.i = load <4 x double>, ptr %57, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %58 = phi i64 [ 0, %.preheader.1.i ], [ %99, %.critedge.1.i ]
  %59 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %98, %.critedge.1.i ]
  %60 = mul nuw nsw i64 %58, 96
  %61 = getelementptr double, ptr %13, i64 %58
  %62 = load double, ptr %61, align 8
  %63 = insertelement <1 x double> poison, double %62, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %60
  %64 = load <4 x double>, ptr %gep.1.i, align 8
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> zeroinitializer
  %66 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 1>
  %67 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 2>
  %68 = shufflevector <4 x double> %64, <4 x double> poison, <1 x i32> <i32 3>
  %69 = fmul <1 x double> %63, %65
  %70 = fmul <1 x double> %63, %66
  %71 = fmul <1 x double> %63, %67
  %72 = shufflevector <1 x double> %71, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = fmul <1 x double> %63, %68
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = shufflevector <1 x double> %69, <1 x double> %70, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %76 = shufflevector <4 x double> %75, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %78 = fadd <4 x double> %59, %77
  store <4 x double> %78, ptr %57, align 8
  %79 = or disjoint i64 %58, 1
  %80 = mul nuw nsw i64 %79, 96
  %81 = getelementptr double, ptr %13, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = insertelement <1 x double> poison, double %82, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %80
  %84 = load <4 x double>, ptr %gep.1.i.1, align 8
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> zeroinitializer
  %86 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 1>
  %87 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 2>
  %88 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 3>
  %89 = fmul <1 x double> %83, %85
  %90 = fmul <1 x double> %83, %86
  %91 = fmul <1 x double> %83, %87
  %92 = shufflevector <1 x double> %91, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = fmul <1 x double> %83, %88
  %94 = shufflevector <1 x double> %93, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = shufflevector <1 x double> %89, <1 x double> %90, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %98 = fadd <4 x double> %78, %97
  store <4 x double> %98, ptr %57, align 8
  %99 = add nuw nsw i64 %58, 2
  %exitcond.1.not.i.1 = icmp eq i64 %99, 24
  br i1 %exitcond.1.not.i.1, label %100, label %.critedge.1.i

100:                                              ; preds = %.critedge.1.i
  %101 = add nuw nsw i64 %9, 1
  %exitcond19.not.i = icmp eq i64 %101, 8
  br i1 %exitcond19.not.i, label %102, label %.preheader16.i

102:                                              ; preds = %100
  %103 = add nuw nsw i64 %7, 8
  %104 = icmp ult i64 %7, 88
  br i1 %104, label %6, label %105

105:                                              ; preds = %102
  %106 = add nuw nsw i64 %4, 8
  %107 = icmp ult i64 %4, 40
  br i1 %107, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %105
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %10, i8 0, i64 36864, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %112, %1
  %11 = phi i64 [ %113, %112 ], [ 0, %1 ]
  %12 = mul nuw nsw i64 %11, 96
  %invariant.gep.i = getelementptr double, ptr %10, i64 %12
  br label %13

13:                                               ; preds = %109, %.preheader17.i
  %14 = phi i64 [ 0, %.preheader17.i ], [ %110, %109 ]
  %15 = getelementptr double, ptr %7, i64 %14
  %gep20.i = getelementptr double, ptr %invariant.gep.i, i64 %14
  %invariant.gep.1.i = getelementptr double, ptr %15, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %107, %13
  %16 = phi i64 [ 0, %13 ], [ %108, %107 ]
  %17 = add nuw nsw i64 %16, %11
  %18 = mul nuw nsw i64 %17, 24
  %19 = mul nuw nsw i64 %16, 96
  %20 = getelementptr double, ptr %4, i64 %18
  %21 = getelementptr double, ptr %gep20.i, i64 %19
  %.promoted.i = load <4 x double>, ptr %21, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %22 = phi i64 [ 0, %.preheader16.i ], [ %63, %.critedge.i ]
  %23 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %62, %.critedge.i ]
  %24 = mul nuw nsw i64 %22, 96
  %25 = getelementptr double, ptr %20, i64 %22
  %26 = load double, ptr %25, align 8
  %27 = insertelement <1 x double> poison, double %26, i64 0
  %gep.i = getelementptr double, ptr %15, i64 %24
  %28 = load <4 x double>, ptr %gep.i, align 8
  %29 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> zeroinitializer
  %30 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 1>
  %31 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 2>
  %32 = shufflevector <4 x double> %28, <4 x double> poison, <1 x i32> <i32 3>
  %33 = fmul <1 x double> %27, %29
  %34 = fmul <1 x double> %27, %30
  %35 = fmul <1 x double> %27, %31
  %36 = shufflevector <1 x double> %35, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = fmul <1 x double> %27, %32
  %38 = shufflevector <1 x double> %37, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = shufflevector <1 x double> %33, <1 x double> %34, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = fadd <4 x double> %23, %41
  store <4 x double> %42, ptr %21, align 8
  %43 = or disjoint i64 %22, 1
  %44 = mul nuw nsw i64 %43, 96
  %45 = getelementptr double, ptr %20, i64 %43
  %46 = load double, ptr %45, align 8
  %47 = insertelement <1 x double> poison, double %46, i64 0
  %gep.i.1 = getelementptr double, ptr %15, i64 %44
  %48 = load <4 x double>, ptr %gep.i.1, align 8
  %49 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> zeroinitializer
  %50 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 1>
  %51 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 2>
  %52 = shufflevector <4 x double> %48, <4 x double> poison, <1 x i32> <i32 3>
  %53 = fmul <1 x double> %47, %49
  %54 = fmul <1 x double> %47, %50
  %55 = fmul <1 x double> %47, %51
  %56 = shufflevector <1 x double> %55, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %57 = fmul <1 x double> %47, %52
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = shufflevector <1 x double> %53, <1 x double> %54, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %60 = shufflevector <4 x double> %59, <4 x double> %56, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %61 = shufflevector <4 x double> %60, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %62 = fadd <4 x double> %42, %61
  store <4 x double> %62, ptr %21, align 8
  %63 = add nuw nsw i64 %22, 2
  %exitcond.not.i.1 = icmp eq i64 %63, 24
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %64 = getelementptr double, ptr %21, i64 4
  %.promoted.1.i = load <4 x double>, ptr %64, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %65 = phi i64 [ 0, %.preheader.1.i ], [ %106, %.critedge.1.i ]
  %66 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %105, %.critedge.1.i ]
  %67 = mul nuw nsw i64 %65, 96
  %68 = getelementptr double, ptr %20, i64 %65
  %69 = load double, ptr %68, align 8
  %70 = insertelement <1 x double> poison, double %69, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %67
  %71 = load <4 x double>, ptr %gep.1.i, align 8
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> zeroinitializer
  %73 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 1>
  %74 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 2>
  %75 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 3>
  %76 = fmul <1 x double> %70, %72
  %77 = fmul <1 x double> %70, %73
  %78 = fmul <1 x double> %70, %74
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = fmul <1 x double> %70, %75
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = shufflevector <1 x double> %76, <1 x double> %77, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %84 = shufflevector <4 x double> %83, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %85 = fadd <4 x double> %66, %84
  store <4 x double> %85, ptr %64, align 8
  %86 = or disjoint i64 %65, 1
  %87 = mul nuw nsw i64 %86, 96
  %88 = getelementptr double, ptr %20, i64 %86
  %89 = load double, ptr %88, align 8
  %90 = insertelement <1 x double> poison, double %89, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %87
  %91 = load <4 x double>, ptr %gep.1.i.1, align 8
  %92 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> zeroinitializer
  %93 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 1>
  %94 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 2>
  %95 = shufflevector <4 x double> %91, <4 x double> poison, <1 x i32> <i32 3>
  %96 = fmul <1 x double> %90, %92
  %97 = fmul <1 x double> %90, %93
  %98 = fmul <1 x double> %90, %94
  %99 = shufflevector <1 x double> %98, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %100 = fmul <1 x double> %90, %95
  %101 = shufflevector <1 x double> %100, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %102 = shufflevector <1 x double> %96, <1 x double> %97, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %99, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %101, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %105 = fadd <4 x double> %85, %104
  store <4 x double> %105, ptr %64, align 8
  %106 = add nuw nsw i64 %65, 2
  %exitcond.1.not.i.1 = icmp eq i64 %106, 24
  br i1 %exitcond.1.not.i.1, label %107, label %.critedge.1.i

107:                                              ; preds = %.critedge.1.i
  %108 = add nuw nsw i64 %16, 1
  %exitcond19.not.i = icmp eq i64 %108, 8
  br i1 %exitcond19.not.i, label %109, label %.preheader16.i

109:                                              ; preds = %107
  %110 = add nuw nsw i64 %14, 8
  %111 = icmp ult i64 %14, 88
  br i1 %111, label %13, label %112

112:                                              ; preds = %109
  %113 = add nuw nsw i64 %11, 8
  %114 = icmp ult i64 %11, 40
  br i1 %114, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %112
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %.unpack32.i, i8 0, i64 36864, i1 false)
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %111, %1
  %10 = phi i64 [ %112, %111 ], [ 0, %1 ]
  %11 = mul nuw nsw i64 %10, 96
  %invariant.gep.i.i = getelementptr double, ptr %.unpack32.i, i64 %11
  br label %12

12:                                               ; preds = %108, %.preheader17.i.i
  %13 = phi i64 [ 0, %.preheader17.i.i ], [ %109, %108 ]
  %14 = getelementptr double, ptr %.unpack17.i, i64 %13
  %gep20.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %13
  %invariant.gep.1.i.i = getelementptr double, ptr %14, i64 4
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %106, %12
  %15 = phi i64 [ 0, %12 ], [ %107, %106 ]
  %16 = add nuw nsw i64 %15, %10
  %17 = mul nuw nsw i64 %16, 24
  %18 = mul nuw nsw i64 %15, 96
  %19 = getelementptr double, ptr %.unpack2.i, i64 %17
  %20 = getelementptr double, ptr %gep20.i.i, i64 %18
  %.promoted.i.i = load <4 x double>, ptr %20, align 8
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader16.i.i
  %21 = phi i64 [ 0, %.preheader16.i.i ], [ %62, %.critedge.i.i ]
  %22 = phi <4 x double> [ %.promoted.i.i, %.preheader16.i.i ], [ %61, %.critedge.i.i ]
  %23 = mul nuw nsw i64 %21, 96
  %24 = getelementptr double, ptr %19, i64 %21
  %25 = load double, ptr %24, align 8
  %26 = insertelement <1 x double> poison, double %25, i64 0
  %gep.i.i = getelementptr double, ptr %14, i64 %23
  %27 = load <4 x double>, ptr %gep.i.i, align 8
  %28 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> zeroinitializer
  %29 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 1>
  %30 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 2>
  %31 = shufflevector <4 x double> %27, <4 x double> poison, <1 x i32> <i32 3>
  %32 = fmul <1 x double> %26, %28
  %33 = fmul <1 x double> %26, %29
  %34 = fmul <1 x double> %26, %30
  %35 = shufflevector <1 x double> %34, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = fmul <1 x double> %26, %31
  %37 = shufflevector <1 x double> %36, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = shufflevector <1 x double> %32, <1 x double> %33, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %39 = shufflevector <4 x double> %38, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %41 = fadd <4 x double> %22, %40
  store <4 x double> %41, ptr %20, align 8
  %42 = or disjoint i64 %21, 1
  %43 = mul nuw nsw i64 %42, 96
  %44 = getelementptr double, ptr %19, i64 %42
  %45 = load double, ptr %44, align 8
  %46 = insertelement <1 x double> poison, double %45, i64 0
  %gep.i.i.1 = getelementptr double, ptr %14, i64 %43
  %47 = load <4 x double>, ptr %gep.i.i.1, align 8
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> zeroinitializer
  %49 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 1>
  %50 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 2>
  %51 = shufflevector <4 x double> %47, <4 x double> poison, <1 x i32> <i32 3>
  %52 = fmul <1 x double> %46, %48
  %53 = fmul <1 x double> %46, %49
  %54 = fmul <1 x double> %46, %50
  %55 = shufflevector <1 x double> %54, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %56 = fmul <1 x double> %46, %51
  %57 = shufflevector <1 x double> %56, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %58 = shufflevector <1 x double> %52, <1 x double> %53, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %55, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %60 = shufflevector <4 x double> %59, <4 x double> %57, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %61 = fadd <4 x double> %41, %60
  store <4 x double> %61, ptr %20, align 8
  %62 = add nuw nsw i64 %21, 2
  %exitcond.not.i.i.1 = icmp eq i64 %62, 24
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %63 = getelementptr double, ptr %20, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %63, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %64 = phi i64 [ 0, %.preheader.1.i.i ], [ %105, %.critedge.1.i.i ]
  %65 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %104, %.critedge.1.i.i ]
  %66 = mul nuw nsw i64 %64, 96
  %67 = getelementptr double, ptr %19, i64 %64
  %68 = load double, ptr %67, align 8
  %69 = insertelement <1 x double> poison, double %68, i64 0
  %gep.1.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %66
  %70 = load <4 x double>, ptr %gep.1.i.i, align 8
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> zeroinitializer
  %72 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 1>
  %73 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 2>
  %74 = shufflevector <4 x double> %70, <4 x double> poison, <1 x i32> <i32 3>
  %75 = fmul <1 x double> %69, %71
  %76 = fmul <1 x double> %69, %72
  %77 = fmul <1 x double> %69, %73
  %78 = shufflevector <1 x double> %77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = fmul <1 x double> %69, %74
  %80 = shufflevector <1 x double> %79, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = shufflevector <1 x double> %75, <1 x double> %76, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %82 = shufflevector <4 x double> %81, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %84 = fadd <4 x double> %65, %83
  store <4 x double> %84, ptr %63, align 8
  %85 = or disjoint i64 %64, 1
  %86 = mul nuw nsw i64 %85, 96
  %87 = getelementptr double, ptr %19, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = insertelement <1 x double> poison, double %88, i64 0
  %gep.1.i.i.1 = getelementptr double, ptr %invariant.gep.1.i.i, i64 %86
  %90 = load <4 x double>, ptr %gep.1.i.i.1, align 8
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> zeroinitializer
  %92 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 1>
  %93 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 2>
  %94 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 3>
  %95 = fmul <1 x double> %89, %91
  %96 = fmul <1 x double> %89, %92
  %97 = fmul <1 x double> %89, %93
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = fmul <1 x double> %89, %94
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %95, <1 x double> %96, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %104 = fadd <4 x double> %84, %103
  store <4 x double> %104, ptr %63, align 8
  %105 = add nuw nsw i64 %64, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %105, 24
  br i1 %exitcond.1.not.i.i.1, label %106, label %.critedge.1.i.i

106:                                              ; preds = %.critedge.1.i.i
  %107 = add nuw nsw i64 %15, 1
  %exitcond19.not.i.i = icmp eq i64 %107, 8
  br i1 %exitcond19.not.i.i, label %108, label %.preheader16.i.i

108:                                              ; preds = %106
  %109 = add nuw nsw i64 %13, 8
  %110 = icmp ult i64 %13, 88
  br i1 %110, label %12, label %111

111:                                              ; preds = %108
  %112 = add nuw nsw i64 %10, 8
  %113 = icmp ult i64 %10, 40
  br i1 %113, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %111
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
