; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %15, i8 0, i64 16120, i1 false)
  br label %.preheader16.us.preheader

.preheader16.us.preheader:                        ; preds = %.split20.us, %.preheader17.preheader
  %21 = phi i64 [ 0, %.preheader17.preheader ], [ %155, %.split20.us ]
  %22 = sub nuw nsw i64 65, %21
  %23 = tail call i64 @llvm.smin.i64(i64 %22, i64 16)
  %24 = getelementptr double, ptr %8, i64 %21
  %25 = getelementptr double, ptr %15, i64 %21
  %26 = tail call i64 @llvm.smin.i64(i64 %22, i64 4)
  %27 = trunc i64 %26 to i32
  %28 = insertelement <4 x i32> poison, i32 %27, i64 0
  %29 = shufflevector <4 x i32> %28, <4 x i32> poison, <4 x i32> zeroinitializer
  %30 = icmp sgt <4 x i32> %29, <i32 0, i32 1, i32 2, i32 3>
  %31 = icmp ugt i64 %23, 4
  %32 = tail call i64 @llvm.smin.i64(i64 %22, i64 8)
  %33 = trunc i64 %32 to i32
  %34 = add i32 %33, -4
  %35 = insertelement <4 x i32> poison, i32 %34, i64 0
  %36 = shufflevector <4 x i32> %35, <4 x i32> poison, <4 x i32> zeroinitializer
  %37 = icmp sgt <4 x i32> %36, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.123 = getelementptr double, ptr %24, i64 4
  %38 = icmp ugt i64 %23, 8
  %39 = tail call i64 @llvm.smin.i64(i64 %22, i64 12)
  %40 = trunc i64 %39 to i32
  %41 = add i32 %40, -8
  %42 = insertelement <4 x i32> poison, i32 %41, i64 0
  %43 = shufflevector <4 x i32> %42, <4 x i32> poison, <4 x i32> zeroinitializer
  %44 = icmp sgt <4 x i32> %43, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.2 = getelementptr double, ptr %24, i64 8
  %45 = icmp ugt i64 %23, 12
  %46 = trunc i64 %23 to i32
  %47 = add i32 %46, -12
  %48 = insertelement <4 x i32> poison, i32 %47, i64 0
  %49 = shufflevector <4 x i32> %48, <4 x i32> poison, <4 x i32> zeroinitializer
  %50 = icmp sgt <4 x i32> %49, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.3 = getelementptr double, ptr %24, i64 12
  br label %.preheader16.us

.preheader16.us:                                  ; preds = %.preheader16.us.preheader, %._crit_edge.us
  %51 = phi i64 [ %154, %._crit_edge.us ], [ 0, %.preheader16.us.preheader ]
  %52 = mul nuw nsw i64 %51, 17
  %53 = mul nuw nsw i64 %51, 65
  %54 = getelementptr double, ptr %1, i64 %52
  %55 = getelementptr double, ptr %25, i64 %53
  br label %.critedge.us

56:                                               ; preds = %.critedge.us
  br i1 %31, label %.preheader.us.124, label %._crit_edge.us

.preheader.us.124:                                ; preds = %56
  %57 = getelementptr double, ptr %55, i64 4
  br label %.critedge.us.126

.critedge.us.126:                                 ; preds = %.critedge.us.126, %.preheader.us.124
  %58 = phi i64 [ 0, %.preheader.us.124 ], [ %80, %.critedge.us.126 ]
  %59 = mul nuw nsw i64 %58, 65
  %60 = getelementptr double, ptr %54, i64 %58
  %61 = load double, ptr %60, align 8
  %62 = insertelement <1 x double> poison, double %61, i64 0
  %gep.us.125 = getelementptr double, ptr %invariant.gep.us.123, i64 %59
  %63 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.125, i32 8, <4 x i1> %37, <4 x double> zeroinitializer)
  %64 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> zeroinitializer
  %65 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 1>
  %66 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 2>
  %67 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 3>
  %68 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %57, i32 8, <4 x i1> %37, <4 x double> zeroinitializer)
  %69 = fmul <1 x double> %62, %64
  %70 = fmul <1 x double> %62, %65
  %71 = fmul <1 x double> %62, %66
  %72 = shufflevector <1 x double> %71, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = fmul <1 x double> %62, %67
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = shufflevector <1 x double> %69, <1 x double> %70, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %76 = shufflevector <4 x double> %75, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %78 = select <4 x i1> %37, <4 x double> %68, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %79 = fadd <4 x double> %78, %77
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %79, ptr %57, i32 8, <4 x i1> %37)
  %80 = add nuw nsw i64 %58, 1
  %exitcond.not.1 = icmp eq i64 %80, 17
  br i1 %exitcond.not.1, label %81, label %.critedge.us.126

81:                                               ; preds = %.critedge.us.126
  br i1 %38, label %.preheader.us.2, label %._crit_edge.us

.preheader.us.2:                                  ; preds = %81
  %82 = getelementptr double, ptr %55, i64 8
  br label %.critedge.us.2

.critedge.us.2:                                   ; preds = %.critedge.us.2, %.preheader.us.2
  %83 = phi i64 [ 0, %.preheader.us.2 ], [ %105, %.critedge.us.2 ]
  %84 = mul nuw nsw i64 %83, 65
  %85 = getelementptr double, ptr %54, i64 %83
  %86 = load double, ptr %85, align 8
  %87 = insertelement <1 x double> poison, double %86, i64 0
  %gep.us.2 = getelementptr double, ptr %invariant.gep.us.2, i64 %84
  %88 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.2, i32 8, <4 x i1> %44, <4 x double> zeroinitializer)
  %89 = shufflevector <4 x double> %88, <4 x double> poison, <1 x i32> zeroinitializer
  %90 = shufflevector <4 x double> %88, <4 x double> poison, <1 x i32> <i32 1>
  %91 = shufflevector <4 x double> %88, <4 x double> poison, <1 x i32> <i32 2>
  %92 = shufflevector <4 x double> %88, <4 x double> poison, <1 x i32> <i32 3>
  %93 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %82, i32 8, <4 x i1> %44, <4 x double> zeroinitializer)
  %94 = fmul <1 x double> %87, %89
  %95 = fmul <1 x double> %87, %90
  %96 = fmul <1 x double> %87, %91
  %97 = shufflevector <1 x double> %96, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %98 = fmul <1 x double> %87, %92
  %99 = shufflevector <1 x double> %98, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %100 = shufflevector <1 x double> %94, <1 x double> %95, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %97, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %99, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %103 = select <4 x i1> %44, <4 x double> %93, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %104 = fadd <4 x double> %103, %102
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %104, ptr %82, i32 8, <4 x i1> %44)
  %105 = add nuw nsw i64 %83, 1
  %exitcond.not.2 = icmp eq i64 %105, 17
  br i1 %exitcond.not.2, label %106, label %.critedge.us.2

106:                                              ; preds = %.critedge.us.2
  br i1 %45, label %.preheader.us.3, label %._crit_edge.us

.preheader.us.3:                                  ; preds = %106
  %107 = getelementptr double, ptr %55, i64 12
  br label %.critedge.us.3

.critedge.us.3:                                   ; preds = %.critedge.us.3, %.preheader.us.3
  %108 = phi i64 [ 0, %.preheader.us.3 ], [ %130, %.critedge.us.3 ]
  %109 = mul nuw nsw i64 %108, 65
  %110 = getelementptr double, ptr %54, i64 %108
  %111 = load double, ptr %110, align 8
  %112 = insertelement <1 x double> poison, double %111, i64 0
  %gep.us.3 = getelementptr double, ptr %invariant.gep.us.3, i64 %109
  %113 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.3, i32 8, <4 x i1> %50, <4 x double> zeroinitializer)
  %114 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> zeroinitializer
  %115 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 1>
  %116 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 2>
  %117 = shufflevector <4 x double> %113, <4 x double> poison, <1 x i32> <i32 3>
  %118 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %107, i32 8, <4 x i1> %50, <4 x double> zeroinitializer)
  %119 = fmul <1 x double> %112, %114
  %120 = fmul <1 x double> %112, %115
  %121 = fmul <1 x double> %112, %116
  %122 = shufflevector <1 x double> %121, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %123 = fmul <1 x double> %112, %117
  %124 = shufflevector <1 x double> %123, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %125 = shufflevector <1 x double> %119, <1 x double> %120, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %126 = shufflevector <4 x double> %125, <4 x double> %122, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %127 = shufflevector <4 x double> %126, <4 x double> %124, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %128 = select <4 x i1> %50, <4 x double> %118, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %129 = fadd <4 x double> %128, %127
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %129, ptr %107, i32 8, <4 x i1> %50)
  %130 = add nuw nsw i64 %108, 1
  %exitcond.not.3 = icmp eq i64 %130, 17
  br i1 %exitcond.not.3, label %._crit_edge.us, label %.critedge.us.3

.critedge.us:                                     ; preds = %.preheader16.us, %.critedge.us
  %131 = phi i64 [ 0, %.preheader16.us ], [ %153, %.critedge.us ]
  %132 = mul nuw nsw i64 %131, 65
  %133 = getelementptr double, ptr %54, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = insertelement <1 x double> poison, double %134, i64 0
  %gep.us = getelementptr double, ptr %24, i64 %132
  %136 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us, i32 8, <4 x i1> %30, <4 x double> zeroinitializer)
  %137 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> zeroinitializer
  %138 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 1>
  %139 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 2>
  %140 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 3>
  %141 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %55, i32 8, <4 x i1> %30, <4 x double> zeroinitializer)
  %142 = fmul <1 x double> %135, %137
  %143 = fmul <1 x double> %135, %138
  %144 = fmul <1 x double> %135, %139
  %145 = shufflevector <1 x double> %144, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %146 = fmul <1 x double> %135, %140
  %147 = shufflevector <1 x double> %146, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %148 = shufflevector <1 x double> %142, <1 x double> %143, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %149 = shufflevector <4 x double> %148, <4 x double> %145, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %150 = shufflevector <4 x double> %149, <4 x double> %147, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %151 = select <4 x i1> %30, <4 x double> %141, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %152 = fadd <4 x double> %151, %150
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %152, ptr %55, i32 8, <4 x i1> %30)
  %153 = add nuw nsw i64 %131, 1
  %exitcond.not = icmp eq i64 %153, 17
  br i1 %exitcond.not, label %56, label %.critedge.us

._crit_edge.us:                                   ; preds = %.critedge.us.3, %106, %81, %56
  %154 = add nuw nsw i64 %51, 1
  %exitcond22.not = icmp eq i64 %154, 16
  br i1 %exitcond22.not, label %.split20.us, label %.preheader16.us

.split20.us:                                      ; preds = %._crit_edge.us
  %155 = add nuw nsw i64 %21, 16
  %156 = icmp ult i64 %21, 49
  br i1 %156, label %.preheader16.us.preheader, label %.preheader17.1

.preheader17.1:                                   ; preds = %.split20.us
  %157 = getelementptr double, ptr %15, i64 1040
  %invariant.gep = getelementptr double, ptr %1, i64 272
  br label %.preheader16.us.preheader.1

.preheader16.us.preheader.1:                      ; preds = %.preheader17.1, %.split20.us.1
  %158 = phi i64 [ 0, %.preheader17.1 ], [ %291, %.split20.us.1 ]
  %159 = sub nuw nsw i64 65, %158
  %160 = tail call i64 @llvm.smin.i64(i64 %159, i64 16)
  %161 = getelementptr double, ptr %8, i64 %158
  %162 = getelementptr double, ptr %157, i64 %158
  %163 = tail call i64 @llvm.smin.i64(i64 %159, i64 4)
  %164 = trunc i64 %163 to i32
  %165 = insertelement <4 x i32> poison, i32 %164, i64 0
  %166 = shufflevector <4 x i32> %165, <4 x i32> poison, <4 x i32> zeroinitializer
  %167 = icmp sgt <4 x i32> %166, <i32 0, i32 1, i32 2, i32 3>
  %168 = icmp ugt i64 %160, 4
  %169 = tail call i64 @llvm.smin.i64(i64 %159, i64 8)
  %170 = trunc i64 %169 to i32
  %171 = add i32 %170, -4
  %172 = insertelement <4 x i32> poison, i32 %171, i64 0
  %173 = shufflevector <4 x i32> %172, <4 x i32> poison, <4 x i32> zeroinitializer
  %174 = icmp sgt <4 x i32> %173, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.1.1 = getelementptr double, ptr %161, i64 4
  %175 = icmp ugt i64 %160, 8
  %176 = tail call i64 @llvm.smin.i64(i64 %159, i64 12)
  %177 = trunc i64 %176 to i32
  %178 = add i32 %177, -8
  %179 = insertelement <4 x i32> poison, i32 %178, i64 0
  %180 = shufflevector <4 x i32> %179, <4 x i32> poison, <4 x i32> zeroinitializer
  %181 = icmp sgt <4 x i32> %180, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.1.2 = getelementptr double, ptr %161, i64 8
  %182 = icmp ugt i64 %160, 12
  %183 = trunc i64 %160 to i32
  %184 = add i32 %183, -12
  %185 = insertelement <4 x i32> poison, i32 %184, i64 0
  %186 = shufflevector <4 x i32> %185, <4 x i32> poison, <4 x i32> zeroinitializer
  %187 = icmp sgt <4 x i32> %186, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.1.3 = getelementptr double, ptr %161, i64 12
  br label %.preheader16.us.1

.preheader16.us.1:                                ; preds = %._crit_edge.us.1, %.preheader16.us.preheader.1
  %188 = phi i64 [ %290, %._crit_edge.us.1 ], [ 0, %.preheader16.us.preheader.1 ]
  %189 = mul nuw i64 %188, 17
  %190 = mul nuw nsw i64 %188, 65
  %gep = getelementptr double, ptr %invariant.gep, i64 %189
  %191 = getelementptr double, ptr %162, i64 %190
  br label %.critedge.us.1

.critedge.us.1:                                   ; preds = %.critedge.us.1, %.preheader16.us.1
  %192 = phi i64 [ 0, %.preheader16.us.1 ], [ %214, %.critedge.us.1 ]
  %193 = mul nuw nsw i64 %192, 65
  %194 = getelementptr double, ptr %gep, i64 %192
  %195 = load double, ptr %194, align 8
  %196 = insertelement <1 x double> poison, double %195, i64 0
  %gep.us.1 = getelementptr double, ptr %161, i64 %193
  %197 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1, i32 8, <4 x i1> %167, <4 x double> zeroinitializer)
  %198 = shufflevector <4 x double> %197, <4 x double> poison, <1 x i32> zeroinitializer
  %199 = shufflevector <4 x double> %197, <4 x double> poison, <1 x i32> <i32 1>
  %200 = shufflevector <4 x double> %197, <4 x double> poison, <1 x i32> <i32 2>
  %201 = shufflevector <4 x double> %197, <4 x double> poison, <1 x i32> <i32 3>
  %202 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %191, i32 8, <4 x i1> %167, <4 x double> zeroinitializer)
  %203 = fmul <1 x double> %196, %198
  %204 = fmul <1 x double> %196, %199
  %205 = fmul <1 x double> %196, %200
  %206 = shufflevector <1 x double> %205, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %207 = fmul <1 x double> %196, %201
  %208 = shufflevector <1 x double> %207, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %209 = shufflevector <1 x double> %203, <1 x double> %204, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %210 = shufflevector <4 x double> %209, <4 x double> %206, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %211 = shufflevector <4 x double> %210, <4 x double> %208, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %212 = select <4 x i1> %167, <4 x double> %202, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %213 = fadd <4 x double> %212, %211
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %213, ptr %191, i32 8, <4 x i1> %167)
  %214 = add nuw nsw i64 %192, 1
  %exitcond.1.not = icmp eq i64 %214, 17
  br i1 %exitcond.1.not, label %215, label %.critedge.us.1

215:                                              ; preds = %.critedge.us.1
  br i1 %168, label %.preheader.us.1.1, label %._crit_edge.us.1

.preheader.us.1.1:                                ; preds = %215
  %216 = getelementptr double, ptr %191, i64 4
  br label %.critedge.us.1.1

.critedge.us.1.1:                                 ; preds = %.critedge.us.1.1, %.preheader.us.1.1
  %217 = phi i64 [ 0, %.preheader.us.1.1 ], [ %239, %.critedge.us.1.1 ]
  %218 = mul nuw nsw i64 %217, 65
  %219 = getelementptr double, ptr %gep, i64 %217
  %220 = load double, ptr %219, align 8
  %221 = insertelement <1 x double> poison, double %220, i64 0
  %gep.us.1.1 = getelementptr double, ptr %invariant.gep.us.1.1, i64 %218
  %222 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.1, i32 8, <4 x i1> %174, <4 x double> zeroinitializer)
  %223 = shufflevector <4 x double> %222, <4 x double> poison, <1 x i32> zeroinitializer
  %224 = shufflevector <4 x double> %222, <4 x double> poison, <1 x i32> <i32 1>
  %225 = shufflevector <4 x double> %222, <4 x double> poison, <1 x i32> <i32 2>
  %226 = shufflevector <4 x double> %222, <4 x double> poison, <1 x i32> <i32 3>
  %227 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %216, i32 8, <4 x i1> %174, <4 x double> zeroinitializer)
  %228 = fmul <1 x double> %221, %223
  %229 = fmul <1 x double> %221, %224
  %230 = fmul <1 x double> %221, %225
  %231 = shufflevector <1 x double> %230, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %232 = fmul <1 x double> %221, %226
  %233 = shufflevector <1 x double> %232, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %234 = shufflevector <1 x double> %228, <1 x double> %229, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %235 = shufflevector <4 x double> %234, <4 x double> %231, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %236 = shufflevector <4 x double> %235, <4 x double> %233, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %237 = select <4 x i1> %174, <4 x double> %227, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %238 = fadd <4 x double> %237, %236
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %238, ptr %216, i32 8, <4 x i1> %174)
  %239 = add nuw nsw i64 %217, 1
  %exitcond.1.not.1 = icmp eq i64 %239, 17
  br i1 %exitcond.1.not.1, label %240, label %.critedge.us.1.1

240:                                              ; preds = %.critedge.us.1.1
  br i1 %175, label %.preheader.us.1.2, label %._crit_edge.us.1

.preheader.us.1.2:                                ; preds = %240
  %241 = getelementptr double, ptr %191, i64 8
  br label %.critedge.us.1.2

.critedge.us.1.2:                                 ; preds = %.critedge.us.1.2, %.preheader.us.1.2
  %242 = phi i64 [ 0, %.preheader.us.1.2 ], [ %264, %.critedge.us.1.2 ]
  %243 = mul nuw nsw i64 %242, 65
  %244 = getelementptr double, ptr %gep, i64 %242
  %245 = load double, ptr %244, align 8
  %246 = insertelement <1 x double> poison, double %245, i64 0
  %gep.us.1.2 = getelementptr double, ptr %invariant.gep.us.1.2, i64 %243
  %247 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.2, i32 8, <4 x i1> %181, <4 x double> zeroinitializer)
  %248 = shufflevector <4 x double> %247, <4 x double> poison, <1 x i32> zeroinitializer
  %249 = shufflevector <4 x double> %247, <4 x double> poison, <1 x i32> <i32 1>
  %250 = shufflevector <4 x double> %247, <4 x double> poison, <1 x i32> <i32 2>
  %251 = shufflevector <4 x double> %247, <4 x double> poison, <1 x i32> <i32 3>
  %252 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %241, i32 8, <4 x i1> %181, <4 x double> zeroinitializer)
  %253 = fmul <1 x double> %246, %248
  %254 = fmul <1 x double> %246, %249
  %255 = fmul <1 x double> %246, %250
  %256 = shufflevector <1 x double> %255, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %257 = fmul <1 x double> %246, %251
  %258 = shufflevector <1 x double> %257, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %259 = shufflevector <1 x double> %253, <1 x double> %254, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %260 = shufflevector <4 x double> %259, <4 x double> %256, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %261 = shufflevector <4 x double> %260, <4 x double> %258, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %262 = select <4 x i1> %181, <4 x double> %252, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %263 = fadd <4 x double> %262, %261
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %263, ptr %241, i32 8, <4 x i1> %181)
  %264 = add nuw nsw i64 %242, 1
  %exitcond.1.not.2 = icmp eq i64 %264, 17
  br i1 %exitcond.1.not.2, label %265, label %.critedge.us.1.2

265:                                              ; preds = %.critedge.us.1.2
  br i1 %182, label %.preheader.us.1.3, label %._crit_edge.us.1

.preheader.us.1.3:                                ; preds = %265
  %266 = getelementptr double, ptr %191, i64 12
  br label %.critedge.us.1.3

.critedge.us.1.3:                                 ; preds = %.critedge.us.1.3, %.preheader.us.1.3
  %267 = phi i64 [ 0, %.preheader.us.1.3 ], [ %289, %.critedge.us.1.3 ]
  %268 = mul nuw nsw i64 %267, 65
  %269 = getelementptr double, ptr %gep, i64 %267
  %270 = load double, ptr %269, align 8
  %271 = insertelement <1 x double> poison, double %270, i64 0
  %gep.us.1.3 = getelementptr double, ptr %invariant.gep.us.1.3, i64 %268
  %272 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.3, i32 8, <4 x i1> %187, <4 x double> zeroinitializer)
  %273 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> zeroinitializer
  %274 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 1>
  %275 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 2>
  %276 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 3>
  %277 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %266, i32 8, <4 x i1> %187, <4 x double> zeroinitializer)
  %278 = fmul <1 x double> %271, %273
  %279 = fmul <1 x double> %271, %274
  %280 = fmul <1 x double> %271, %275
  %281 = shufflevector <1 x double> %280, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %282 = fmul <1 x double> %271, %276
  %283 = shufflevector <1 x double> %282, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %284 = shufflevector <1 x double> %278, <1 x double> %279, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %285 = shufflevector <4 x double> %284, <4 x double> %281, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %286 = shufflevector <4 x double> %285, <4 x double> %283, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %287 = select <4 x i1> %187, <4 x double> %277, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %288 = fadd <4 x double> %287, %286
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %288, ptr %266, i32 8, <4 x i1> %187)
  %289 = add nuw nsw i64 %267, 1
  %exitcond.1.not.3 = icmp eq i64 %289, 17
  br i1 %exitcond.1.not.3, label %._crit_edge.us.1, label %.critedge.us.1.3

._crit_edge.us.1:                                 ; preds = %.critedge.us.1.3, %265, %240, %215
  %290 = add nuw nsw i64 %188, 1
  %exitcond22.1.not = icmp eq i64 %290, 15
  br i1 %exitcond22.1.not, label %.split20.us.1, label %.preheader16.us.1

.split20.us.1:                                    ; preds = %._crit_edge.us.1
  %291 = add nuw nsw i64 %158, 16
  %292 = icmp ult i64 %158, 49
  br i1 %292, label %.preheader16.us.preheader.1, label %293

293:                                              ; preds = %.split20.us.1
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
.preheader16.us.preheader.i:
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %.unpack32, i8 0, i64 16120, i1 false)
  %invariant.gep.us.i.1 = getelementptr double, ptr %.unpack17, i64 4
  %invariant.gep.us.i.2 = getelementptr double, ptr %.unpack17, i64 8
  %invariant.gep.us.i.3 = getelementptr double, ptr %.unpack17, i64 12
  br label %.preheader16.us.i

.preheader16.us.i:                                ; preds = %._crit_edge.us.i, %.preheader16.us.preheader.i
  %3 = phi i64 [ %131, %._crit_edge.us.i ], [ 0, %.preheader16.us.preheader.i ]
  %4 = mul nuw nsw i64 %3, 17
  %5 = mul nuw nsw i64 %3, 65
  %6 = getelementptr double, ptr %.unpack2, i64 %4
  %7 = getelementptr double, ptr %.unpack32, i64 %5
  %.promoted150 = load <4 x double>, ptr %7, align 8
  br label %.critedge.us.i

.preheader.us.i.145:                              ; preds = %.critedge.us.i
  %8 = getelementptr double, ptr %7, i64 4
  %.promoted149 = load <4 x double>, ptr %8, align 8
  br label %.critedge.us.i.148

.critedge.us.i.148:                               ; preds = %.critedge.us.i.148.1, %.preheader.us.i.145
  %9 = phi <4 x double> [ %.promoted149, %.preheader.us.i.145 ], [ %47, %.critedge.us.i.148.1 ]
  %10 = phi i64 [ 0, %.preheader.us.i.145 ], [ %48, %.critedge.us.i.148.1 ]
  %11 = mul nuw nsw i64 %10, 65
  %12 = getelementptr double, ptr %6, i64 %10
  %13 = load double, ptr %12, align 8
  %14 = insertelement <1 x double> poison, double %13, i64 0
  %gep.us.i.146 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %11
  %unmaskedload70 = load <4 x double>, ptr %gep.us.i.146, align 8
  %15 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> zeroinitializer
  %16 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 1>
  %17 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 2>
  %18 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 3>
  %19 = fmul <1 x double> %14, %15
  %20 = fmul <1 x double> %14, %16
  %21 = fmul <1 x double> %14, %17
  %22 = shufflevector <1 x double> %21, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = fmul <1 x double> %14, %18
  %24 = shufflevector <1 x double> %23, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = shufflevector <1 x double> %19, <1 x double> %20, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %26 = shufflevector <4 x double> %25, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %27 = shufflevector <4 x double> %26, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %28 = fadd <4 x double> %9, %27
  store <4 x double> %28, ptr %8, align 8
  %29 = or disjoint i64 %10, 1
  %exitcond.not.i.147 = icmp eq i64 %29, 17
  br i1 %exitcond.not.i.147, label %.preheader.us.i.249, label %.critedge.us.i.148.1

.critedge.us.i.148.1:                             ; preds = %.critedge.us.i.148
  %30 = mul nuw nsw i64 %29, 65
  %31 = getelementptr double, ptr %6, i64 %29
  %32 = load double, ptr %31, align 8
  %33 = insertelement <1 x double> poison, double %32, i64 0
  %gep.us.i.146.1 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %30
  %unmaskedload70.1 = load <4 x double>, ptr %gep.us.i.146.1, align 8
  %34 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> zeroinitializer
  %35 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 1>
  %36 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 2>
  %37 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 3>
  %38 = fmul <1 x double> %33, %34
  %39 = fmul <1 x double> %33, %35
  %40 = fmul <1 x double> %33, %36
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = fmul <1 x double> %33, %37
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <1 x double> %38, <1 x double> %39, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %47 = fadd <4 x double> %28, %46
  store <4 x double> %47, ptr %8, align 8
  %48 = add nuw nsw i64 %10, 2
  br label %.critedge.us.i.148

.preheader.us.i.249:                              ; preds = %.critedge.us.i.148
  %49 = getelementptr double, ptr %7, i64 8
  %.promoted148 = load <4 x double>, ptr %49, align 8
  br label %.critedge.us.i.252

.critedge.us.i.252:                               ; preds = %.critedge.us.i.252.1, %.preheader.us.i.249
  %50 = phi <4 x double> [ %.promoted148, %.preheader.us.i.249 ], [ %88, %.critedge.us.i.252.1 ]
  %51 = phi i64 [ 0, %.preheader.us.i.249 ], [ %89, %.critedge.us.i.252.1 ]
  %52 = mul nuw nsw i64 %51, 65
  %53 = getelementptr double, ptr %6, i64 %51
  %54 = load double, ptr %53, align 8
  %55 = insertelement <1 x double> poison, double %54, i64 0
  %gep.us.i.250 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %52
  %unmaskedload72 = load <4 x double>, ptr %gep.us.i.250, align 8
  %56 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> zeroinitializer
  %57 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 1>
  %58 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 2>
  %59 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 3>
  %60 = fmul <1 x double> %55, %56
  %61 = fmul <1 x double> %55, %57
  %62 = fmul <1 x double> %55, %58
  %63 = shufflevector <1 x double> %62, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %64 = fmul <1 x double> %55, %59
  %65 = shufflevector <1 x double> %64, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %66 = shufflevector <1 x double> %60, <1 x double> %61, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %63, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %68 = shufflevector <4 x double> %67, <4 x double> %65, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %69 = fadd <4 x double> %50, %68
  store <4 x double> %69, ptr %49, align 8
  %70 = or disjoint i64 %51, 1
  %exitcond.not.i.251 = icmp eq i64 %70, 17
  br i1 %exitcond.not.i.251, label %.preheader.us.i.353, label %.critedge.us.i.252.1

.critedge.us.i.252.1:                             ; preds = %.critedge.us.i.252
  %71 = mul nuw nsw i64 %70, 65
  %72 = getelementptr double, ptr %6, i64 %70
  %73 = load double, ptr %72, align 8
  %74 = insertelement <1 x double> poison, double %73, i64 0
  %gep.us.i.250.1 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %71
  %unmaskedload72.1 = load <4 x double>, ptr %gep.us.i.250.1, align 8
  %75 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> zeroinitializer
  %76 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 1>
  %77 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 2>
  %78 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 3>
  %79 = fmul <1 x double> %74, %75
  %80 = fmul <1 x double> %74, %76
  %81 = fmul <1 x double> %74, %77
  %82 = shufflevector <1 x double> %81, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %83 = fmul <1 x double> %74, %78
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = shufflevector <1 x double> %79, <1 x double> %80, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %82, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %87 = shufflevector <4 x double> %86, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %88 = fadd <4 x double> %69, %87
  store <4 x double> %88, ptr %49, align 8
  %89 = add nuw nsw i64 %51, 2
  br label %.critedge.us.i.252

.preheader.us.i.353:                              ; preds = %.critedge.us.i.252
  %90 = getelementptr double, ptr %7, i64 12
  %.promoted147 = load <4 x double>, ptr %90, align 8
  br label %.critedge.us.i.356

.critedge.us.i.356:                               ; preds = %.critedge.us.i.356.1, %.preheader.us.i.353
  %91 = phi <4 x double> [ %.promoted147, %.preheader.us.i.353 ], [ %129, %.critedge.us.i.356.1 ]
  %92 = phi i64 [ 0, %.preheader.us.i.353 ], [ %130, %.critedge.us.i.356.1 ]
  %93 = mul nuw nsw i64 %92, 65
  %94 = getelementptr double, ptr %6, i64 %92
  %95 = load double, ptr %94, align 8
  %96 = insertelement <1 x double> poison, double %95, i64 0
  %gep.us.i.354 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %93
  %unmaskedload74 = load <4 x double>, ptr %gep.us.i.354, align 8
  %97 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> zeroinitializer
  %98 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 1>
  %99 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 2>
  %100 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 3>
  %101 = fmul <1 x double> %96, %97
  %102 = fmul <1 x double> %96, %98
  %103 = fmul <1 x double> %96, %99
  %104 = shufflevector <1 x double> %103, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %105 = fmul <1 x double> %96, %100
  %106 = shufflevector <1 x double> %105, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %107 = shufflevector <1 x double> %101, <1 x double> %102, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %104, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %109 = shufflevector <4 x double> %108, <4 x double> %106, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %110 = fadd <4 x double> %91, %109
  store <4 x double> %110, ptr %90, align 8
  %111 = or disjoint i64 %92, 1
  %exitcond.not.i.355 = icmp eq i64 %111, 17
  br i1 %exitcond.not.i.355, label %._crit_edge.us.i, label %.critedge.us.i.356.1

.critedge.us.i.356.1:                             ; preds = %.critedge.us.i.356
  %112 = mul nuw nsw i64 %111, 65
  %113 = getelementptr double, ptr %6, i64 %111
  %114 = load double, ptr %113, align 8
  %115 = insertelement <1 x double> poison, double %114, i64 0
  %gep.us.i.354.1 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %112
  %unmaskedload74.1 = load <4 x double>, ptr %gep.us.i.354.1, align 8
  %116 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> zeroinitializer
  %117 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 1>
  %118 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 2>
  %119 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 3>
  %120 = fmul <1 x double> %115, %116
  %121 = fmul <1 x double> %115, %117
  %122 = fmul <1 x double> %115, %118
  %123 = shufflevector <1 x double> %122, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %124 = fmul <1 x double> %115, %119
  %125 = shufflevector <1 x double> %124, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %126 = shufflevector <1 x double> %120, <1 x double> %121, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %127 = shufflevector <4 x double> %126, <4 x double> %123, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %128 = shufflevector <4 x double> %127, <4 x double> %125, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %129 = fadd <4 x double> %110, %128
  store <4 x double> %129, ptr %90, align 8
  %130 = add nuw nsw i64 %92, 2
  br label %.critedge.us.i.356

._crit_edge.us.i:                                 ; preds = %.critedge.us.i.356
  %131 = add nuw nsw i64 %3, 1
  %exitcond22.not.i = icmp eq i64 %131, 16
  br i1 %exitcond22.not.i, label %.split20.us.i, label %.preheader16.us.i

.critedge.us.i:                                   ; preds = %.critedge.us.i.1165, %.preheader16.us.i
  %132 = phi <4 x double> [ %.promoted150, %.preheader16.us.i ], [ %170, %.critedge.us.i.1165 ]
  %133 = phi i64 [ 0, %.preheader16.us.i ], [ %171, %.critedge.us.i.1165 ]
  %134 = mul nuw nsw i64 %133, 65
  %135 = getelementptr double, ptr %6, i64 %133
  %136 = load double, ptr %135, align 8
  %137 = insertelement <1 x double> poison, double %136, i64 0
  %gep.us.i = getelementptr double, ptr %.unpack17, i64 %134
  %unmaskedload = load <4 x double>, ptr %gep.us.i, align 8
  %138 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %139 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %140 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %141 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %142 = fmul <1 x double> %137, %138
  %143 = fmul <1 x double> %137, %139
  %144 = fmul <1 x double> %137, %140
  %145 = shufflevector <1 x double> %144, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %146 = fmul <1 x double> %137, %141
  %147 = shufflevector <1 x double> %146, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %148 = shufflevector <1 x double> %142, <1 x double> %143, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %149 = shufflevector <4 x double> %148, <4 x double> %145, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %150 = shufflevector <4 x double> %149, <4 x double> %147, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %151 = fadd <4 x double> %132, %150
  store <4 x double> %151, ptr %7, align 8
  %152 = or disjoint i64 %133, 1
  %exitcond.not.i = icmp eq i64 %152, 17
  br i1 %exitcond.not.i, label %.preheader.us.i.145, label %.critedge.us.i.1165

.critedge.us.i.1165:                              ; preds = %.critedge.us.i
  %153 = mul nuw nsw i64 %152, 65
  %154 = getelementptr double, ptr %6, i64 %152
  %155 = load double, ptr %154, align 8
  %156 = insertelement <1 x double> poison, double %155, i64 0
  %gep.us.i.1163 = getelementptr double, ptr %.unpack17, i64 %153
  %unmaskedload.1 = load <4 x double>, ptr %gep.us.i.1163, align 8
  %157 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> zeroinitializer
  %158 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 1>
  %159 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 2>
  %160 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 3>
  %161 = fmul <1 x double> %156, %157
  %162 = fmul <1 x double> %156, %158
  %163 = fmul <1 x double> %156, %159
  %164 = shufflevector <1 x double> %163, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %165 = fmul <1 x double> %156, %160
  %166 = shufflevector <1 x double> %165, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %167 = shufflevector <1 x double> %161, <1 x double> %162, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %168 = shufflevector <4 x double> %167, <4 x double> %164, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %169 = shufflevector <4 x double> %168, <4 x double> %166, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %170 = fadd <4 x double> %151, %169
  store <4 x double> %170, ptr %7, align 8
  %171 = add nuw nsw i64 %133, 2
  br label %.critedge.us.i

.split20.us.i:                                    ; preds = %._crit_edge.us.i
  %172 = getelementptr double, ptr %.unpack17, i64 16
  %173 = getelementptr double, ptr %.unpack32, i64 16
  %invariant.gep.us.i.1.1 = getelementptr double, ptr %.unpack17, i64 20
  %invariant.gep.us.i.1.2 = getelementptr double, ptr %.unpack17, i64 24
  %invariant.gep.us.i.1.3 = getelementptr double, ptr %.unpack17, i64 28
  br label %.preheader16.us.i.1

.preheader16.us.i.1:                              ; preds = %._crit_edge.us.i.1, %.split20.us.i
  %174 = phi i64 [ %342, %._crit_edge.us.i.1 ], [ 0, %.split20.us.i ]
  %175 = mul nuw nsw i64 %174, 17
  %176 = mul nuw nsw i64 %174, 65
  %177 = getelementptr double, ptr %.unpack2, i64 %175
  %178 = getelementptr double, ptr %173, i64 %176
  %.promoted154 = load <4 x double>, ptr %178, align 8
  br label %.critedge.us.i.1

.critedge.us.i.1:                                 ; preds = %.critedge.us.i.1.1168, %.preheader16.us.i.1
  %179 = phi <4 x double> [ %.promoted154, %.preheader16.us.i.1 ], [ %217, %.critedge.us.i.1.1168 ]
  %180 = phi i64 [ 0, %.preheader16.us.i.1 ], [ %218, %.critedge.us.i.1.1168 ]
  %181 = mul nuw nsw i64 %180, 65
  %182 = getelementptr double, ptr %177, i64 %180
  %183 = load double, ptr %182, align 8
  %184 = insertelement <1 x double> poison, double %183, i64 0
  %gep.us.i.1 = getelementptr double, ptr %172, i64 %181
  %unmaskedload76 = load <4 x double>, ptr %gep.us.i.1, align 8
  %185 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> zeroinitializer
  %186 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 1>
  %187 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 2>
  %188 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 3>
  %189 = fmul <1 x double> %184, %185
  %190 = fmul <1 x double> %184, %186
  %191 = fmul <1 x double> %184, %187
  %192 = shufflevector <1 x double> %191, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %193 = fmul <1 x double> %184, %188
  %194 = shufflevector <1 x double> %193, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %195 = shufflevector <1 x double> %189, <1 x double> %190, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %196 = shufflevector <4 x double> %195, <4 x double> %192, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %197 = shufflevector <4 x double> %196, <4 x double> %194, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %198 = fadd <4 x double> %179, %197
  store <4 x double> %198, ptr %178, align 8
  %199 = or disjoint i64 %180, 1
  %exitcond.not.i.1 = icmp eq i64 %199, 17
  br i1 %exitcond.not.i.1, label %.preheader.us.i.1.1, label %.critedge.us.i.1.1168

.critedge.us.i.1.1168:                            ; preds = %.critedge.us.i.1
  %200 = mul nuw nsw i64 %199, 65
  %201 = getelementptr double, ptr %177, i64 %199
  %202 = load double, ptr %201, align 8
  %203 = insertelement <1 x double> poison, double %202, i64 0
  %gep.us.i.1.1166 = getelementptr double, ptr %172, i64 %200
  %unmaskedload76.1 = load <4 x double>, ptr %gep.us.i.1.1166, align 8
  %204 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> zeroinitializer
  %205 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 1>
  %206 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 2>
  %207 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 3>
  %208 = fmul <1 x double> %203, %204
  %209 = fmul <1 x double> %203, %205
  %210 = fmul <1 x double> %203, %206
  %211 = shufflevector <1 x double> %210, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %212 = fmul <1 x double> %203, %207
  %213 = shufflevector <1 x double> %212, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %214 = shufflevector <1 x double> %208, <1 x double> %209, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %215 = shufflevector <4 x double> %214, <4 x double> %211, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %216 = shufflevector <4 x double> %215, <4 x double> %213, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %217 = fadd <4 x double> %198, %216
  store <4 x double> %217, ptr %178, align 8
  %218 = add nuw nsw i64 %180, 2
  br label %.critedge.us.i.1

.preheader.us.i.1.1:                              ; preds = %.critedge.us.i.1
  %219 = getelementptr double, ptr %178, i64 4
  %.promoted153 = load <4 x double>, ptr %219, align 8
  br label %.critedge.us.i.1.1

.critedge.us.i.1.1:                               ; preds = %.critedge.us.i.1.1.1, %.preheader.us.i.1.1
  %220 = phi <4 x double> [ %.promoted153, %.preheader.us.i.1.1 ], [ %258, %.critedge.us.i.1.1.1 ]
  %221 = phi i64 [ 0, %.preheader.us.i.1.1 ], [ %259, %.critedge.us.i.1.1.1 ]
  %222 = mul nuw nsw i64 %221, 65
  %223 = getelementptr double, ptr %177, i64 %221
  %224 = load double, ptr %223, align 8
  %225 = insertelement <1 x double> poison, double %224, i64 0
  %gep.us.i.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %222
  %unmaskedload78 = load <4 x double>, ptr %gep.us.i.1.1, align 8
  %226 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> zeroinitializer
  %227 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 1>
  %228 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 2>
  %229 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 3>
  %230 = fmul <1 x double> %225, %226
  %231 = fmul <1 x double> %225, %227
  %232 = fmul <1 x double> %225, %228
  %233 = shufflevector <1 x double> %232, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %234 = fmul <1 x double> %225, %229
  %235 = shufflevector <1 x double> %234, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %236 = shufflevector <1 x double> %230, <1 x double> %231, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %237 = shufflevector <4 x double> %236, <4 x double> %233, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %238 = shufflevector <4 x double> %237, <4 x double> %235, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %239 = fadd <4 x double> %220, %238
  store <4 x double> %239, ptr %219, align 8
  %240 = or disjoint i64 %221, 1
  %exitcond.not.i.1.1 = icmp eq i64 %240, 17
  br i1 %exitcond.not.i.1.1, label %.preheader.us.i.1.2, label %.critedge.us.i.1.1.1

.critedge.us.i.1.1.1:                             ; preds = %.critedge.us.i.1.1
  %241 = mul nuw nsw i64 %240, 65
  %242 = getelementptr double, ptr %177, i64 %240
  %243 = load double, ptr %242, align 8
  %244 = insertelement <1 x double> poison, double %243, i64 0
  %gep.us.i.1.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %241
  %unmaskedload78.1 = load <4 x double>, ptr %gep.us.i.1.1.1, align 8
  %245 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> zeroinitializer
  %246 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 1>
  %247 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 2>
  %248 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 3>
  %249 = fmul <1 x double> %244, %245
  %250 = fmul <1 x double> %244, %246
  %251 = fmul <1 x double> %244, %247
  %252 = shufflevector <1 x double> %251, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %253 = fmul <1 x double> %244, %248
  %254 = shufflevector <1 x double> %253, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %255 = shufflevector <1 x double> %249, <1 x double> %250, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %256 = shufflevector <4 x double> %255, <4 x double> %252, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %257 = shufflevector <4 x double> %256, <4 x double> %254, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %258 = fadd <4 x double> %239, %257
  store <4 x double> %258, ptr %219, align 8
  %259 = add nuw nsw i64 %221, 2
  br label %.critedge.us.i.1.1

.preheader.us.i.1.2:                              ; preds = %.critedge.us.i.1.1
  %260 = getelementptr double, ptr %178, i64 8
  %.promoted152 = load <4 x double>, ptr %260, align 8
  br label %.critedge.us.i.1.2

.critedge.us.i.1.2:                               ; preds = %.critedge.us.i.1.2.1, %.preheader.us.i.1.2
  %261 = phi <4 x double> [ %.promoted152, %.preheader.us.i.1.2 ], [ %299, %.critedge.us.i.1.2.1 ]
  %262 = phi i64 [ 0, %.preheader.us.i.1.2 ], [ %300, %.critedge.us.i.1.2.1 ]
  %263 = mul nuw nsw i64 %262, 65
  %264 = getelementptr double, ptr %177, i64 %262
  %265 = load double, ptr %264, align 8
  %266 = insertelement <1 x double> poison, double %265, i64 0
  %gep.us.i.1.2 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %263
  %unmaskedload80 = load <4 x double>, ptr %gep.us.i.1.2, align 8
  %267 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> zeroinitializer
  %268 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 1>
  %269 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 2>
  %270 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 3>
  %271 = fmul <1 x double> %266, %267
  %272 = fmul <1 x double> %266, %268
  %273 = fmul <1 x double> %266, %269
  %274 = shufflevector <1 x double> %273, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %275 = fmul <1 x double> %266, %270
  %276 = shufflevector <1 x double> %275, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %277 = shufflevector <1 x double> %271, <1 x double> %272, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %278 = shufflevector <4 x double> %277, <4 x double> %274, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %279 = shufflevector <4 x double> %278, <4 x double> %276, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %280 = fadd <4 x double> %261, %279
  store <4 x double> %280, ptr %260, align 8
  %281 = or disjoint i64 %262, 1
  %exitcond.not.i.1.2 = icmp eq i64 %281, 17
  br i1 %exitcond.not.i.1.2, label %.preheader.us.i.1.3, label %.critedge.us.i.1.2.1

.critedge.us.i.1.2.1:                             ; preds = %.critedge.us.i.1.2
  %282 = mul nuw nsw i64 %281, 65
  %283 = getelementptr double, ptr %177, i64 %281
  %284 = load double, ptr %283, align 8
  %285 = insertelement <1 x double> poison, double %284, i64 0
  %gep.us.i.1.2.1 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %282
  %unmaskedload80.1 = load <4 x double>, ptr %gep.us.i.1.2.1, align 8
  %286 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> zeroinitializer
  %287 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 1>
  %288 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 2>
  %289 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 3>
  %290 = fmul <1 x double> %285, %286
  %291 = fmul <1 x double> %285, %287
  %292 = fmul <1 x double> %285, %288
  %293 = shufflevector <1 x double> %292, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %294 = fmul <1 x double> %285, %289
  %295 = shufflevector <1 x double> %294, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %296 = shufflevector <1 x double> %290, <1 x double> %291, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %297 = shufflevector <4 x double> %296, <4 x double> %293, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %298 = shufflevector <4 x double> %297, <4 x double> %295, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %299 = fadd <4 x double> %280, %298
  store <4 x double> %299, ptr %260, align 8
  %300 = add nuw nsw i64 %262, 2
  br label %.critedge.us.i.1.2

.preheader.us.i.1.3:                              ; preds = %.critedge.us.i.1.2
  %301 = getelementptr double, ptr %178, i64 12
  %.promoted151 = load <4 x double>, ptr %301, align 8
  br label %.critedge.us.i.1.3

.critedge.us.i.1.3:                               ; preds = %.critedge.us.i.1.3.1, %.preheader.us.i.1.3
  %302 = phi <4 x double> [ %.promoted151, %.preheader.us.i.1.3 ], [ %340, %.critedge.us.i.1.3.1 ]
  %303 = phi i64 [ 0, %.preheader.us.i.1.3 ], [ %341, %.critedge.us.i.1.3.1 ]
  %304 = mul nuw nsw i64 %303, 65
  %305 = getelementptr double, ptr %177, i64 %303
  %306 = load double, ptr %305, align 8
  %307 = insertelement <1 x double> poison, double %306, i64 0
  %gep.us.i.1.3 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %304
  %unmaskedload82 = load <4 x double>, ptr %gep.us.i.1.3, align 8
  %308 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> zeroinitializer
  %309 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 1>
  %310 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 2>
  %311 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 3>
  %312 = fmul <1 x double> %307, %308
  %313 = fmul <1 x double> %307, %309
  %314 = fmul <1 x double> %307, %310
  %315 = shufflevector <1 x double> %314, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %316 = fmul <1 x double> %307, %311
  %317 = shufflevector <1 x double> %316, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %318 = shufflevector <1 x double> %312, <1 x double> %313, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %319 = shufflevector <4 x double> %318, <4 x double> %315, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %320 = shufflevector <4 x double> %319, <4 x double> %317, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %321 = fadd <4 x double> %302, %320
  store <4 x double> %321, ptr %301, align 8
  %322 = or disjoint i64 %303, 1
  %exitcond.not.i.1.3 = icmp eq i64 %322, 17
  br i1 %exitcond.not.i.1.3, label %._crit_edge.us.i.1, label %.critedge.us.i.1.3.1

.critedge.us.i.1.3.1:                             ; preds = %.critedge.us.i.1.3
  %323 = mul nuw nsw i64 %322, 65
  %324 = getelementptr double, ptr %177, i64 %322
  %325 = load double, ptr %324, align 8
  %326 = insertelement <1 x double> poison, double %325, i64 0
  %gep.us.i.1.3.1 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %323
  %unmaskedload82.1 = load <4 x double>, ptr %gep.us.i.1.3.1, align 8
  %327 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> zeroinitializer
  %328 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 1>
  %329 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 2>
  %330 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 3>
  %331 = fmul <1 x double> %326, %327
  %332 = fmul <1 x double> %326, %328
  %333 = fmul <1 x double> %326, %329
  %334 = shufflevector <1 x double> %333, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %335 = fmul <1 x double> %326, %330
  %336 = shufflevector <1 x double> %335, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %337 = shufflevector <1 x double> %331, <1 x double> %332, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %338 = shufflevector <4 x double> %337, <4 x double> %334, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %339 = shufflevector <4 x double> %338, <4 x double> %336, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %340 = fadd <4 x double> %321, %339
  store <4 x double> %340, ptr %301, align 8
  %341 = add nuw nsw i64 %303, 2
  br label %.critedge.us.i.1.3

._crit_edge.us.i.1:                               ; preds = %.critedge.us.i.1.3
  %342 = add nuw nsw i64 %174, 1
  %exitcond22.not.i.1 = icmp eq i64 %342, 16
  br i1 %exitcond22.not.i.1, label %.split20.us.i.1, label %.preheader16.us.i.1

.split20.us.i.1:                                  ; preds = %._crit_edge.us.i.1
  %343 = getelementptr double, ptr %.unpack17, i64 32
  %344 = getelementptr double, ptr %.unpack32, i64 32
  %invariant.gep.us.i.2.1 = getelementptr double, ptr %.unpack17, i64 36
  %invariant.gep.us.i.2.2 = getelementptr double, ptr %.unpack17, i64 40
  %invariant.gep.us.i.2.3 = getelementptr double, ptr %.unpack17, i64 44
  br label %.preheader16.us.i.2

.preheader16.us.i.2:                              ; preds = %._crit_edge.us.i.2, %.split20.us.i.1
  %345 = phi i64 [ %513, %._crit_edge.us.i.2 ], [ 0, %.split20.us.i.1 ]
  %346 = mul nuw nsw i64 %345, 17
  %347 = mul nuw nsw i64 %345, 65
  %348 = getelementptr double, ptr %.unpack2, i64 %346
  %349 = getelementptr double, ptr %344, i64 %347
  %.promoted158 = load <4 x double>, ptr %349, align 8
  br label %.critedge.us.i.2

.critedge.us.i.2:                                 ; preds = %.critedge.us.i.2.1171, %.preheader16.us.i.2
  %350 = phi <4 x double> [ %.promoted158, %.preheader16.us.i.2 ], [ %388, %.critedge.us.i.2.1171 ]
  %351 = phi i64 [ 0, %.preheader16.us.i.2 ], [ %389, %.critedge.us.i.2.1171 ]
  %352 = mul nuw nsw i64 %351, 65
  %353 = getelementptr double, ptr %348, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = insertelement <1 x double> poison, double %354, i64 0
  %gep.us.i.2 = getelementptr double, ptr %343, i64 %352
  %unmaskedload84 = load <4 x double>, ptr %gep.us.i.2, align 8
  %356 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> zeroinitializer
  %357 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 1>
  %358 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 2>
  %359 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 3>
  %360 = fmul <1 x double> %355, %356
  %361 = fmul <1 x double> %355, %357
  %362 = fmul <1 x double> %355, %358
  %363 = shufflevector <1 x double> %362, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %364 = fmul <1 x double> %355, %359
  %365 = shufflevector <1 x double> %364, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %366 = shufflevector <1 x double> %360, <1 x double> %361, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %367 = shufflevector <4 x double> %366, <4 x double> %363, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %368 = shufflevector <4 x double> %367, <4 x double> %365, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %369 = fadd <4 x double> %350, %368
  store <4 x double> %369, ptr %349, align 8
  %370 = or disjoint i64 %351, 1
  %exitcond.not.i.2 = icmp eq i64 %370, 17
  br i1 %exitcond.not.i.2, label %.preheader.us.i.2.1, label %.critedge.us.i.2.1171

.critedge.us.i.2.1171:                            ; preds = %.critedge.us.i.2
  %371 = mul nuw nsw i64 %370, 65
  %372 = getelementptr double, ptr %348, i64 %370
  %373 = load double, ptr %372, align 8
  %374 = insertelement <1 x double> poison, double %373, i64 0
  %gep.us.i.2.1169 = getelementptr double, ptr %343, i64 %371
  %unmaskedload84.1 = load <4 x double>, ptr %gep.us.i.2.1169, align 8
  %375 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> zeroinitializer
  %376 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 1>
  %377 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 2>
  %378 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 3>
  %379 = fmul <1 x double> %374, %375
  %380 = fmul <1 x double> %374, %376
  %381 = fmul <1 x double> %374, %377
  %382 = shufflevector <1 x double> %381, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %383 = fmul <1 x double> %374, %378
  %384 = shufflevector <1 x double> %383, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %385 = shufflevector <1 x double> %379, <1 x double> %380, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %386 = shufflevector <4 x double> %385, <4 x double> %382, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %387 = shufflevector <4 x double> %386, <4 x double> %384, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %388 = fadd <4 x double> %369, %387
  store <4 x double> %388, ptr %349, align 8
  %389 = add nuw nsw i64 %351, 2
  br label %.critedge.us.i.2

.preheader.us.i.2.1:                              ; preds = %.critedge.us.i.2
  %390 = getelementptr double, ptr %349, i64 4
  %.promoted157 = load <4 x double>, ptr %390, align 8
  br label %.critedge.us.i.2.1

.critedge.us.i.2.1:                               ; preds = %.critedge.us.i.2.1.1, %.preheader.us.i.2.1
  %391 = phi <4 x double> [ %.promoted157, %.preheader.us.i.2.1 ], [ %429, %.critedge.us.i.2.1.1 ]
  %392 = phi i64 [ 0, %.preheader.us.i.2.1 ], [ %430, %.critedge.us.i.2.1.1 ]
  %393 = mul nuw nsw i64 %392, 65
  %394 = getelementptr double, ptr %348, i64 %392
  %395 = load double, ptr %394, align 8
  %396 = insertelement <1 x double> poison, double %395, i64 0
  %gep.us.i.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %393
  %unmaskedload86 = load <4 x double>, ptr %gep.us.i.2.1, align 8
  %397 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> zeroinitializer
  %398 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 1>
  %399 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 2>
  %400 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 3>
  %401 = fmul <1 x double> %396, %397
  %402 = fmul <1 x double> %396, %398
  %403 = fmul <1 x double> %396, %399
  %404 = shufflevector <1 x double> %403, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %405 = fmul <1 x double> %396, %400
  %406 = shufflevector <1 x double> %405, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %407 = shufflevector <1 x double> %401, <1 x double> %402, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %408 = shufflevector <4 x double> %407, <4 x double> %404, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %409 = shufflevector <4 x double> %408, <4 x double> %406, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %410 = fadd <4 x double> %391, %409
  store <4 x double> %410, ptr %390, align 8
  %411 = or disjoint i64 %392, 1
  %exitcond.not.i.2.1 = icmp eq i64 %411, 17
  br i1 %exitcond.not.i.2.1, label %.preheader.us.i.2.2, label %.critedge.us.i.2.1.1

.critedge.us.i.2.1.1:                             ; preds = %.critedge.us.i.2.1
  %412 = mul nuw nsw i64 %411, 65
  %413 = getelementptr double, ptr %348, i64 %411
  %414 = load double, ptr %413, align 8
  %415 = insertelement <1 x double> poison, double %414, i64 0
  %gep.us.i.2.1.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %412
  %unmaskedload86.1 = load <4 x double>, ptr %gep.us.i.2.1.1, align 8
  %416 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> zeroinitializer
  %417 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 1>
  %418 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 2>
  %419 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 3>
  %420 = fmul <1 x double> %415, %416
  %421 = fmul <1 x double> %415, %417
  %422 = fmul <1 x double> %415, %418
  %423 = shufflevector <1 x double> %422, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %424 = fmul <1 x double> %415, %419
  %425 = shufflevector <1 x double> %424, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %426 = shufflevector <1 x double> %420, <1 x double> %421, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %427 = shufflevector <4 x double> %426, <4 x double> %423, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %428 = shufflevector <4 x double> %427, <4 x double> %425, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %429 = fadd <4 x double> %410, %428
  store <4 x double> %429, ptr %390, align 8
  %430 = add nuw nsw i64 %392, 2
  br label %.critedge.us.i.2.1

.preheader.us.i.2.2:                              ; preds = %.critedge.us.i.2.1
  %431 = getelementptr double, ptr %349, i64 8
  %.promoted156 = load <4 x double>, ptr %431, align 8
  br label %.critedge.us.i.2.2

.critedge.us.i.2.2:                               ; preds = %.critedge.us.i.2.2.1, %.preheader.us.i.2.2
  %432 = phi <4 x double> [ %.promoted156, %.preheader.us.i.2.2 ], [ %470, %.critedge.us.i.2.2.1 ]
  %433 = phi i64 [ 0, %.preheader.us.i.2.2 ], [ %471, %.critedge.us.i.2.2.1 ]
  %434 = mul nuw nsw i64 %433, 65
  %435 = getelementptr double, ptr %348, i64 %433
  %436 = load double, ptr %435, align 8
  %437 = insertelement <1 x double> poison, double %436, i64 0
  %gep.us.i.2.2 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %434
  %unmaskedload88 = load <4 x double>, ptr %gep.us.i.2.2, align 8
  %438 = shufflevector <4 x double> %unmaskedload88, <4 x double> poison, <1 x i32> zeroinitializer
  %439 = shufflevector <4 x double> %unmaskedload88, <4 x double> poison, <1 x i32> <i32 1>
  %440 = shufflevector <4 x double> %unmaskedload88, <4 x double> poison, <1 x i32> <i32 2>
  %441 = shufflevector <4 x double> %unmaskedload88, <4 x double> poison, <1 x i32> <i32 3>
  %442 = fmul <1 x double> %437, %438
  %443 = fmul <1 x double> %437, %439
  %444 = fmul <1 x double> %437, %440
  %445 = shufflevector <1 x double> %444, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %446 = fmul <1 x double> %437, %441
  %447 = shufflevector <1 x double> %446, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %448 = shufflevector <1 x double> %442, <1 x double> %443, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %449 = shufflevector <4 x double> %448, <4 x double> %445, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %450 = shufflevector <4 x double> %449, <4 x double> %447, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %451 = fadd <4 x double> %432, %450
  store <4 x double> %451, ptr %431, align 8
  %452 = or disjoint i64 %433, 1
  %exitcond.not.i.2.2 = icmp eq i64 %452, 17
  br i1 %exitcond.not.i.2.2, label %.preheader.us.i.2.3, label %.critedge.us.i.2.2.1

.critedge.us.i.2.2.1:                             ; preds = %.critedge.us.i.2.2
  %453 = mul nuw nsw i64 %452, 65
  %454 = getelementptr double, ptr %348, i64 %452
  %455 = load double, ptr %454, align 8
  %456 = insertelement <1 x double> poison, double %455, i64 0
  %gep.us.i.2.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %453
  %unmaskedload88.1 = load <4 x double>, ptr %gep.us.i.2.2.1, align 8
  %457 = shufflevector <4 x double> %unmaskedload88.1, <4 x double> poison, <1 x i32> zeroinitializer
  %458 = shufflevector <4 x double> %unmaskedload88.1, <4 x double> poison, <1 x i32> <i32 1>
  %459 = shufflevector <4 x double> %unmaskedload88.1, <4 x double> poison, <1 x i32> <i32 2>
  %460 = shufflevector <4 x double> %unmaskedload88.1, <4 x double> poison, <1 x i32> <i32 3>
  %461 = fmul <1 x double> %456, %457
  %462 = fmul <1 x double> %456, %458
  %463 = fmul <1 x double> %456, %459
  %464 = shufflevector <1 x double> %463, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %465 = fmul <1 x double> %456, %460
  %466 = shufflevector <1 x double> %465, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %467 = shufflevector <1 x double> %461, <1 x double> %462, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %468 = shufflevector <4 x double> %467, <4 x double> %464, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %469 = shufflevector <4 x double> %468, <4 x double> %466, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %470 = fadd <4 x double> %451, %469
  store <4 x double> %470, ptr %431, align 8
  %471 = add nuw nsw i64 %433, 2
  br label %.critedge.us.i.2.2

.preheader.us.i.2.3:                              ; preds = %.critedge.us.i.2.2
  %472 = getelementptr double, ptr %349, i64 12
  %.promoted155 = load <4 x double>, ptr %472, align 8
  br label %.critedge.us.i.2.3

.critedge.us.i.2.3:                               ; preds = %.critedge.us.i.2.3.1, %.preheader.us.i.2.3
  %473 = phi <4 x double> [ %.promoted155, %.preheader.us.i.2.3 ], [ %511, %.critedge.us.i.2.3.1 ]
  %474 = phi i64 [ 0, %.preheader.us.i.2.3 ], [ %512, %.critedge.us.i.2.3.1 ]
  %475 = mul nuw nsw i64 %474, 65
  %476 = getelementptr double, ptr %348, i64 %474
  %477 = load double, ptr %476, align 8
  %478 = insertelement <1 x double> poison, double %477, i64 0
  %gep.us.i.2.3 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %475
  %unmaskedload90 = load <4 x double>, ptr %gep.us.i.2.3, align 8
  %479 = shufflevector <4 x double> %unmaskedload90, <4 x double> poison, <1 x i32> zeroinitializer
  %480 = shufflevector <4 x double> %unmaskedload90, <4 x double> poison, <1 x i32> <i32 1>
  %481 = shufflevector <4 x double> %unmaskedload90, <4 x double> poison, <1 x i32> <i32 2>
  %482 = shufflevector <4 x double> %unmaskedload90, <4 x double> poison, <1 x i32> <i32 3>
  %483 = fmul <1 x double> %478, %479
  %484 = fmul <1 x double> %478, %480
  %485 = fmul <1 x double> %478, %481
  %486 = shufflevector <1 x double> %485, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %487 = fmul <1 x double> %478, %482
  %488 = shufflevector <1 x double> %487, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %489 = shufflevector <1 x double> %483, <1 x double> %484, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %490 = shufflevector <4 x double> %489, <4 x double> %486, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %491 = shufflevector <4 x double> %490, <4 x double> %488, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %492 = fadd <4 x double> %473, %491
  store <4 x double> %492, ptr %472, align 8
  %493 = or disjoint i64 %474, 1
  %exitcond.not.i.2.3 = icmp eq i64 %493, 17
  br i1 %exitcond.not.i.2.3, label %._crit_edge.us.i.2, label %.critedge.us.i.2.3.1

.critedge.us.i.2.3.1:                             ; preds = %.critedge.us.i.2.3
  %494 = mul nuw nsw i64 %493, 65
  %495 = getelementptr double, ptr %348, i64 %493
  %496 = load double, ptr %495, align 8
  %497 = insertelement <1 x double> poison, double %496, i64 0
  %gep.us.i.2.3.1 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %494
  %unmaskedload90.1 = load <4 x double>, ptr %gep.us.i.2.3.1, align 8
  %498 = shufflevector <4 x double> %unmaskedload90.1, <4 x double> poison, <1 x i32> zeroinitializer
  %499 = shufflevector <4 x double> %unmaskedload90.1, <4 x double> poison, <1 x i32> <i32 1>
  %500 = shufflevector <4 x double> %unmaskedload90.1, <4 x double> poison, <1 x i32> <i32 2>
  %501 = shufflevector <4 x double> %unmaskedload90.1, <4 x double> poison, <1 x i32> <i32 3>
  %502 = fmul <1 x double> %497, %498
  %503 = fmul <1 x double> %497, %499
  %504 = fmul <1 x double> %497, %500
  %505 = shufflevector <1 x double> %504, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %506 = fmul <1 x double> %497, %501
  %507 = shufflevector <1 x double> %506, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %508 = shufflevector <1 x double> %502, <1 x double> %503, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %509 = shufflevector <4 x double> %508, <4 x double> %505, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %510 = shufflevector <4 x double> %509, <4 x double> %507, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %511 = fadd <4 x double> %492, %510
  store <4 x double> %511, ptr %472, align 8
  %512 = add nuw nsw i64 %474, 2
  br label %.critedge.us.i.2.3

._crit_edge.us.i.2:                               ; preds = %.critedge.us.i.2.3
  %513 = add nuw nsw i64 %345, 1
  %exitcond22.not.i.2 = icmp eq i64 %513, 16
  br i1 %exitcond22.not.i.2, label %.split20.us.i.2, label %.preheader16.us.i.2

.split20.us.i.2:                                  ; preds = %._crit_edge.us.i.2
  %514 = getelementptr double, ptr %.unpack17, i64 48
  %515 = getelementptr double, ptr %.unpack32, i64 48
  %invariant.gep.us.i.3.1 = getelementptr double, ptr %.unpack17, i64 52
  %invariant.gep.us.i.3.2 = getelementptr double, ptr %.unpack17, i64 56
  %invariant.gep.us.i.3.3 = getelementptr double, ptr %.unpack17, i64 60
  br label %.preheader16.us.i.3

.preheader16.us.i.3:                              ; preds = %._crit_edge.us.i.3, %.split20.us.i.2
  %516 = phi i64 [ %684, %._crit_edge.us.i.3 ], [ 0, %.split20.us.i.2 ]
  %517 = mul nuw nsw i64 %516, 17
  %518 = mul nuw nsw i64 %516, 65
  %519 = getelementptr double, ptr %.unpack2, i64 %517
  %520 = getelementptr double, ptr %515, i64 %518
  %.promoted162 = load <4 x double>, ptr %520, align 8
  br label %.critedge.us.i.3

.critedge.us.i.3:                                 ; preds = %.critedge.us.i.3.1174, %.preheader16.us.i.3
  %521 = phi <4 x double> [ %.promoted162, %.preheader16.us.i.3 ], [ %559, %.critedge.us.i.3.1174 ]
  %522 = phi i64 [ 0, %.preheader16.us.i.3 ], [ %560, %.critedge.us.i.3.1174 ]
  %523 = mul nuw nsw i64 %522, 65
  %524 = getelementptr double, ptr %519, i64 %522
  %525 = load double, ptr %524, align 8
  %526 = insertelement <1 x double> poison, double %525, i64 0
  %gep.us.i.3 = getelementptr double, ptr %514, i64 %523
  %unmaskedload92 = load <4 x double>, ptr %gep.us.i.3, align 8
  %527 = shufflevector <4 x double> %unmaskedload92, <4 x double> poison, <1 x i32> zeroinitializer
  %528 = shufflevector <4 x double> %unmaskedload92, <4 x double> poison, <1 x i32> <i32 1>
  %529 = shufflevector <4 x double> %unmaskedload92, <4 x double> poison, <1 x i32> <i32 2>
  %530 = shufflevector <4 x double> %unmaskedload92, <4 x double> poison, <1 x i32> <i32 3>
  %531 = fmul <1 x double> %526, %527
  %532 = fmul <1 x double> %526, %528
  %533 = fmul <1 x double> %526, %529
  %534 = shufflevector <1 x double> %533, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %535 = fmul <1 x double> %526, %530
  %536 = shufflevector <1 x double> %535, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %537 = shufflevector <1 x double> %531, <1 x double> %532, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %538 = shufflevector <4 x double> %537, <4 x double> %534, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %539 = shufflevector <4 x double> %538, <4 x double> %536, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %540 = fadd <4 x double> %521, %539
  store <4 x double> %540, ptr %520, align 8
  %541 = or disjoint i64 %522, 1
  %exitcond.not.i.3 = icmp eq i64 %541, 17
  br i1 %exitcond.not.i.3, label %.preheader.us.i.3.1, label %.critedge.us.i.3.1174

.critedge.us.i.3.1174:                            ; preds = %.critedge.us.i.3
  %542 = mul nuw nsw i64 %541, 65
  %543 = getelementptr double, ptr %519, i64 %541
  %544 = load double, ptr %543, align 8
  %545 = insertelement <1 x double> poison, double %544, i64 0
  %gep.us.i.3.1172 = getelementptr double, ptr %514, i64 %542
  %unmaskedload92.1 = load <4 x double>, ptr %gep.us.i.3.1172, align 8
  %546 = shufflevector <4 x double> %unmaskedload92.1, <4 x double> poison, <1 x i32> zeroinitializer
  %547 = shufflevector <4 x double> %unmaskedload92.1, <4 x double> poison, <1 x i32> <i32 1>
  %548 = shufflevector <4 x double> %unmaskedload92.1, <4 x double> poison, <1 x i32> <i32 2>
  %549 = shufflevector <4 x double> %unmaskedload92.1, <4 x double> poison, <1 x i32> <i32 3>
  %550 = fmul <1 x double> %545, %546
  %551 = fmul <1 x double> %545, %547
  %552 = fmul <1 x double> %545, %548
  %553 = shufflevector <1 x double> %552, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %554 = fmul <1 x double> %545, %549
  %555 = shufflevector <1 x double> %554, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %556 = shufflevector <1 x double> %550, <1 x double> %551, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %557 = shufflevector <4 x double> %556, <4 x double> %553, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %558 = shufflevector <4 x double> %557, <4 x double> %555, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %559 = fadd <4 x double> %540, %558
  store <4 x double> %559, ptr %520, align 8
  %560 = add nuw nsw i64 %522, 2
  br label %.critedge.us.i.3

.preheader.us.i.3.1:                              ; preds = %.critedge.us.i.3
  %561 = getelementptr double, ptr %520, i64 4
  %.promoted161 = load <4 x double>, ptr %561, align 8
  br label %.critedge.us.i.3.1

.critedge.us.i.3.1:                               ; preds = %.critedge.us.i.3.1.1, %.preheader.us.i.3.1
  %562 = phi <4 x double> [ %.promoted161, %.preheader.us.i.3.1 ], [ %600, %.critedge.us.i.3.1.1 ]
  %563 = phi i64 [ 0, %.preheader.us.i.3.1 ], [ %601, %.critedge.us.i.3.1.1 ]
  %564 = mul nuw nsw i64 %563, 65
  %565 = getelementptr double, ptr %519, i64 %563
  %566 = load double, ptr %565, align 8
  %567 = insertelement <1 x double> poison, double %566, i64 0
  %gep.us.i.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %564
  %unmaskedload94 = load <4 x double>, ptr %gep.us.i.3.1, align 8
  %568 = shufflevector <4 x double> %unmaskedload94, <4 x double> poison, <1 x i32> zeroinitializer
  %569 = shufflevector <4 x double> %unmaskedload94, <4 x double> poison, <1 x i32> <i32 1>
  %570 = shufflevector <4 x double> %unmaskedload94, <4 x double> poison, <1 x i32> <i32 2>
  %571 = shufflevector <4 x double> %unmaskedload94, <4 x double> poison, <1 x i32> <i32 3>
  %572 = fmul <1 x double> %567, %568
  %573 = fmul <1 x double> %567, %569
  %574 = fmul <1 x double> %567, %570
  %575 = shufflevector <1 x double> %574, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %576 = fmul <1 x double> %567, %571
  %577 = shufflevector <1 x double> %576, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %578 = shufflevector <1 x double> %572, <1 x double> %573, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %579 = shufflevector <4 x double> %578, <4 x double> %575, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %580 = shufflevector <4 x double> %579, <4 x double> %577, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %581 = fadd <4 x double> %562, %580
  store <4 x double> %581, ptr %561, align 8
  %582 = or disjoint i64 %563, 1
  %exitcond.not.i.3.1 = icmp eq i64 %582, 17
  br i1 %exitcond.not.i.3.1, label %.preheader.us.i.3.2, label %.critedge.us.i.3.1.1

.critedge.us.i.3.1.1:                             ; preds = %.critedge.us.i.3.1
  %583 = mul nuw nsw i64 %582, 65
  %584 = getelementptr double, ptr %519, i64 %582
  %585 = load double, ptr %584, align 8
  %586 = insertelement <1 x double> poison, double %585, i64 0
  %gep.us.i.3.1.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %583
  %unmaskedload94.1 = load <4 x double>, ptr %gep.us.i.3.1.1, align 8
  %587 = shufflevector <4 x double> %unmaskedload94.1, <4 x double> poison, <1 x i32> zeroinitializer
  %588 = shufflevector <4 x double> %unmaskedload94.1, <4 x double> poison, <1 x i32> <i32 1>
  %589 = shufflevector <4 x double> %unmaskedload94.1, <4 x double> poison, <1 x i32> <i32 2>
  %590 = shufflevector <4 x double> %unmaskedload94.1, <4 x double> poison, <1 x i32> <i32 3>
  %591 = fmul <1 x double> %586, %587
  %592 = fmul <1 x double> %586, %588
  %593 = fmul <1 x double> %586, %589
  %594 = shufflevector <1 x double> %593, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %595 = fmul <1 x double> %586, %590
  %596 = shufflevector <1 x double> %595, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %597 = shufflevector <1 x double> %591, <1 x double> %592, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %598 = shufflevector <4 x double> %597, <4 x double> %594, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %599 = shufflevector <4 x double> %598, <4 x double> %596, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %600 = fadd <4 x double> %581, %599
  store <4 x double> %600, ptr %561, align 8
  %601 = add nuw nsw i64 %563, 2
  br label %.critedge.us.i.3.1

.preheader.us.i.3.2:                              ; preds = %.critedge.us.i.3.1
  %602 = getelementptr double, ptr %520, i64 8
  %.promoted160 = load <4 x double>, ptr %602, align 8
  br label %.critedge.us.i.3.2

.critedge.us.i.3.2:                               ; preds = %.critedge.us.i.3.2.1, %.preheader.us.i.3.2
  %603 = phi <4 x double> [ %.promoted160, %.preheader.us.i.3.2 ], [ %641, %.critedge.us.i.3.2.1 ]
  %604 = phi i64 [ 0, %.preheader.us.i.3.2 ], [ %642, %.critedge.us.i.3.2.1 ]
  %605 = mul nuw nsw i64 %604, 65
  %606 = getelementptr double, ptr %519, i64 %604
  %607 = load double, ptr %606, align 8
  %608 = insertelement <1 x double> poison, double %607, i64 0
  %gep.us.i.3.2 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %605
  %unmaskedload96 = load <4 x double>, ptr %gep.us.i.3.2, align 8
  %609 = shufflevector <4 x double> %unmaskedload96, <4 x double> poison, <1 x i32> zeroinitializer
  %610 = shufflevector <4 x double> %unmaskedload96, <4 x double> poison, <1 x i32> <i32 1>
  %611 = shufflevector <4 x double> %unmaskedload96, <4 x double> poison, <1 x i32> <i32 2>
  %612 = shufflevector <4 x double> %unmaskedload96, <4 x double> poison, <1 x i32> <i32 3>
  %613 = fmul <1 x double> %608, %609
  %614 = fmul <1 x double> %608, %610
  %615 = fmul <1 x double> %608, %611
  %616 = shufflevector <1 x double> %615, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %617 = fmul <1 x double> %608, %612
  %618 = shufflevector <1 x double> %617, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %619 = shufflevector <1 x double> %613, <1 x double> %614, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %620 = shufflevector <4 x double> %619, <4 x double> %616, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %621 = shufflevector <4 x double> %620, <4 x double> %618, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %622 = fadd <4 x double> %603, %621
  store <4 x double> %622, ptr %602, align 8
  %623 = or disjoint i64 %604, 1
  %exitcond.not.i.3.2 = icmp eq i64 %623, 17
  br i1 %exitcond.not.i.3.2, label %.preheader.us.i.3.3, label %.critedge.us.i.3.2.1

.critedge.us.i.3.2.1:                             ; preds = %.critedge.us.i.3.2
  %624 = mul nuw nsw i64 %623, 65
  %625 = getelementptr double, ptr %519, i64 %623
  %626 = load double, ptr %625, align 8
  %627 = insertelement <1 x double> poison, double %626, i64 0
  %gep.us.i.3.2.1 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %624
  %unmaskedload96.1 = load <4 x double>, ptr %gep.us.i.3.2.1, align 8
  %628 = shufflevector <4 x double> %unmaskedload96.1, <4 x double> poison, <1 x i32> zeroinitializer
  %629 = shufflevector <4 x double> %unmaskedload96.1, <4 x double> poison, <1 x i32> <i32 1>
  %630 = shufflevector <4 x double> %unmaskedload96.1, <4 x double> poison, <1 x i32> <i32 2>
  %631 = shufflevector <4 x double> %unmaskedload96.1, <4 x double> poison, <1 x i32> <i32 3>
  %632 = fmul <1 x double> %627, %628
  %633 = fmul <1 x double> %627, %629
  %634 = fmul <1 x double> %627, %630
  %635 = shufflevector <1 x double> %634, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %636 = fmul <1 x double> %627, %631
  %637 = shufflevector <1 x double> %636, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %638 = shufflevector <1 x double> %632, <1 x double> %633, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %639 = shufflevector <4 x double> %638, <4 x double> %635, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %640 = shufflevector <4 x double> %639, <4 x double> %637, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %641 = fadd <4 x double> %622, %640
  store <4 x double> %641, ptr %602, align 8
  %642 = add nuw nsw i64 %604, 2
  br label %.critedge.us.i.3.2

.preheader.us.i.3.3:                              ; preds = %.critedge.us.i.3.2
  %643 = getelementptr double, ptr %520, i64 12
  %.promoted159 = load <4 x double>, ptr %643, align 8
  br label %.critedge.us.i.3.3

.critedge.us.i.3.3:                               ; preds = %.critedge.us.i.3.3.1, %.preheader.us.i.3.3
  %644 = phi <4 x double> [ %.promoted159, %.preheader.us.i.3.3 ], [ %682, %.critedge.us.i.3.3.1 ]
  %645 = phi i64 [ 0, %.preheader.us.i.3.3 ], [ %683, %.critedge.us.i.3.3.1 ]
  %646 = mul nuw nsw i64 %645, 65
  %647 = getelementptr double, ptr %519, i64 %645
  %648 = load double, ptr %647, align 8
  %649 = insertelement <1 x double> poison, double %648, i64 0
  %gep.us.i.3.3 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %646
  %unmaskedload98 = load <4 x double>, ptr %gep.us.i.3.3, align 8
  %650 = shufflevector <4 x double> %unmaskedload98, <4 x double> poison, <1 x i32> zeroinitializer
  %651 = shufflevector <4 x double> %unmaskedload98, <4 x double> poison, <1 x i32> <i32 1>
  %652 = shufflevector <4 x double> %unmaskedload98, <4 x double> poison, <1 x i32> <i32 2>
  %653 = shufflevector <4 x double> %unmaskedload98, <4 x double> poison, <1 x i32> <i32 3>
  %654 = fmul <1 x double> %649, %650
  %655 = fmul <1 x double> %649, %651
  %656 = fmul <1 x double> %649, %652
  %657 = shufflevector <1 x double> %656, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %658 = fmul <1 x double> %649, %653
  %659 = shufflevector <1 x double> %658, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %660 = shufflevector <1 x double> %654, <1 x double> %655, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %661 = shufflevector <4 x double> %660, <4 x double> %657, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %662 = shufflevector <4 x double> %661, <4 x double> %659, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %663 = fadd <4 x double> %644, %662
  store <4 x double> %663, ptr %643, align 8
  %664 = or disjoint i64 %645, 1
  %exitcond.not.i.3.3 = icmp eq i64 %664, 17
  br i1 %exitcond.not.i.3.3, label %._crit_edge.us.i.3, label %.critedge.us.i.3.3.1

.critedge.us.i.3.3.1:                             ; preds = %.critedge.us.i.3.3
  %665 = mul nuw nsw i64 %664, 65
  %666 = getelementptr double, ptr %519, i64 %664
  %667 = load double, ptr %666, align 8
  %668 = insertelement <1 x double> poison, double %667, i64 0
  %gep.us.i.3.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %665
  %unmaskedload98.1 = load <4 x double>, ptr %gep.us.i.3.3.1, align 8
  %669 = shufflevector <4 x double> %unmaskedload98.1, <4 x double> poison, <1 x i32> zeroinitializer
  %670 = shufflevector <4 x double> %unmaskedload98.1, <4 x double> poison, <1 x i32> <i32 1>
  %671 = shufflevector <4 x double> %unmaskedload98.1, <4 x double> poison, <1 x i32> <i32 2>
  %672 = shufflevector <4 x double> %unmaskedload98.1, <4 x double> poison, <1 x i32> <i32 3>
  %673 = fmul <1 x double> %668, %669
  %674 = fmul <1 x double> %668, %670
  %675 = fmul <1 x double> %668, %671
  %676 = shufflevector <1 x double> %675, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %677 = fmul <1 x double> %668, %672
  %678 = shufflevector <1 x double> %677, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %679 = shufflevector <1 x double> %673, <1 x double> %674, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %680 = shufflevector <4 x double> %679, <4 x double> %676, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %681 = shufflevector <4 x double> %680, <4 x double> %678, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %682 = fadd <4 x double> %663, %681
  store <4 x double> %682, ptr %643, align 8
  %683 = add nuw nsw i64 %645, 2
  br label %.critedge.us.i.3.3

._crit_edge.us.i.3:                               ; preds = %.critedge.us.i.3.3
  %684 = add nuw nsw i64 %516, 1
  %exitcond22.not.i.3 = icmp eq i64 %684, 16
  br i1 %exitcond22.not.i.3, label %.split20.us.i.3, label %.preheader16.us.i.3

.split20.us.i.3:                                  ; preds = %._crit_edge.us.i.3
  %685 = getelementptr double, ptr %.unpack17, i64 64
  %686 = getelementptr double, ptr %.unpack32, i64 64
  %gep.us.i.4.1 = getelementptr double, ptr %.unpack17, i64 129
  %gep.us.i.4.2 = getelementptr double, ptr %.unpack17, i64 194
  %gep.us.i.4.3 = getelementptr double, ptr %.unpack17, i64 259
  %gep.us.i.4.4 = getelementptr double, ptr %.unpack17, i64 324
  %gep.us.i.4.5 = getelementptr double, ptr %.unpack17, i64 389
  %gep.us.i.4.6 = getelementptr double, ptr %.unpack17, i64 454
  %gep.us.i.4.7 = getelementptr double, ptr %.unpack17, i64 519
  %gep.us.i.4.8 = getelementptr double, ptr %.unpack17, i64 584
  %gep.us.i.4.9 = getelementptr double, ptr %.unpack17, i64 649
  %gep.us.i.4.10 = getelementptr double, ptr %.unpack17, i64 714
  %gep.us.i.4.11 = getelementptr double, ptr %.unpack17, i64 779
  %gep.us.i.4.12 = getelementptr double, ptr %.unpack17, i64 844
  %gep.us.i.4.13 = getelementptr double, ptr %.unpack17, i64 909
  %gep.us.i.4.14 = getelementptr double, ptr %.unpack17, i64 974
  %gep.us.i.4.15 = getelementptr double, ptr %.unpack17, i64 1039
  %gep.us.i.4.16 = getelementptr double, ptr %.unpack17, i64 1104
  br label %.preheader16.us.i.4

.preheader16.us.i.4:                              ; preds = %.preheader16.us.i.4, %.split20.us.i.3
  %687 = phi i64 [ %844, %.preheader16.us.i.4 ], [ 0, %.split20.us.i.3 ]
  %688 = mul nuw nsw i64 %687, 65
  %689 = getelementptr double, ptr %686, i64 %688
  %690 = mul nuw nsw i64 %687, 17
  %691 = getelementptr double, ptr %.unpack2, i64 %690
  %692 = load double, ptr %691, align 8
  %693 = insertelement <1 x double> poison, double %692, i64 0
  %694 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %685, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %695 = shufflevector <4 x double> %694, <4 x double> poison, <1 x i32> zeroinitializer
  %696 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %697 = fmul <1 x double> %693, %695
  %698 = shufflevector <1 x double> %697, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %699 = fadd <4 x double> %696, %698
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %699, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %700 = getelementptr double, ptr %691, i64 1
  %701 = load double, ptr %700, align 8
  %702 = insertelement <1 x double> poison, double %701, i64 0
  %703 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.1, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %704 = shufflevector <4 x double> %703, <4 x double> poison, <1 x i32> zeroinitializer
  %705 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %706 = fmul <1 x double> %702, %704
  %707 = shufflevector <1 x double> %706, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %708 = fadd <4 x double> %705, %707
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %708, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %709 = getelementptr double, ptr %691, i64 2
  %710 = load double, ptr %709, align 8
  %711 = insertelement <1 x double> poison, double %710, i64 0
  %712 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.2, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %713 = shufflevector <4 x double> %712, <4 x double> poison, <1 x i32> zeroinitializer
  %714 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %715 = fmul <1 x double> %711, %713
  %716 = shufflevector <1 x double> %715, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %717 = fadd <4 x double> %714, %716
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %717, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %718 = getelementptr double, ptr %691, i64 3
  %719 = load double, ptr %718, align 8
  %720 = insertelement <1 x double> poison, double %719, i64 0
  %721 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.3, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %722 = shufflevector <4 x double> %721, <4 x double> poison, <1 x i32> zeroinitializer
  %723 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %724 = fmul <1 x double> %720, %722
  %725 = shufflevector <1 x double> %724, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %726 = fadd <4 x double> %723, %725
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %726, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %727 = getelementptr double, ptr %691, i64 4
  %728 = load double, ptr %727, align 8
  %729 = insertelement <1 x double> poison, double %728, i64 0
  %730 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.4, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %731 = shufflevector <4 x double> %730, <4 x double> poison, <1 x i32> zeroinitializer
  %732 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %733 = fmul <1 x double> %729, %731
  %734 = shufflevector <1 x double> %733, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %735 = fadd <4 x double> %732, %734
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %735, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %736 = getelementptr double, ptr %691, i64 5
  %737 = load double, ptr %736, align 8
  %738 = insertelement <1 x double> poison, double %737, i64 0
  %739 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.5, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %740 = shufflevector <4 x double> %739, <4 x double> poison, <1 x i32> zeroinitializer
  %741 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %742 = fmul <1 x double> %738, %740
  %743 = shufflevector <1 x double> %742, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %744 = fadd <4 x double> %741, %743
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %744, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %745 = getelementptr double, ptr %691, i64 6
  %746 = load double, ptr %745, align 8
  %747 = insertelement <1 x double> poison, double %746, i64 0
  %748 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.6, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %749 = shufflevector <4 x double> %748, <4 x double> poison, <1 x i32> zeroinitializer
  %750 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %751 = fmul <1 x double> %747, %749
  %752 = shufflevector <1 x double> %751, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %753 = fadd <4 x double> %750, %752
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %753, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %754 = getelementptr double, ptr %691, i64 7
  %755 = load double, ptr %754, align 8
  %756 = insertelement <1 x double> poison, double %755, i64 0
  %757 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.7, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %758 = shufflevector <4 x double> %757, <4 x double> poison, <1 x i32> zeroinitializer
  %759 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %760 = fmul <1 x double> %756, %758
  %761 = shufflevector <1 x double> %760, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %762 = fadd <4 x double> %759, %761
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %762, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %763 = getelementptr double, ptr %691, i64 8
  %764 = load double, ptr %763, align 8
  %765 = insertelement <1 x double> poison, double %764, i64 0
  %766 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.8, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %767 = shufflevector <4 x double> %766, <4 x double> poison, <1 x i32> zeroinitializer
  %768 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %769 = fmul <1 x double> %765, %767
  %770 = shufflevector <1 x double> %769, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %771 = fadd <4 x double> %768, %770
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %771, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %772 = getelementptr double, ptr %691, i64 9
  %773 = load double, ptr %772, align 8
  %774 = insertelement <1 x double> poison, double %773, i64 0
  %775 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.9, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %776 = shufflevector <4 x double> %775, <4 x double> poison, <1 x i32> zeroinitializer
  %777 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %778 = fmul <1 x double> %774, %776
  %779 = shufflevector <1 x double> %778, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %780 = fadd <4 x double> %777, %779
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %780, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %781 = getelementptr double, ptr %691, i64 10
  %782 = load double, ptr %781, align 8
  %783 = insertelement <1 x double> poison, double %782, i64 0
  %784 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.10, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %785 = shufflevector <4 x double> %784, <4 x double> poison, <1 x i32> zeroinitializer
  %786 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %787 = fmul <1 x double> %783, %785
  %788 = shufflevector <1 x double> %787, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %789 = fadd <4 x double> %786, %788
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %789, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %790 = getelementptr double, ptr %691, i64 11
  %791 = load double, ptr %790, align 8
  %792 = insertelement <1 x double> poison, double %791, i64 0
  %793 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.11, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %794 = shufflevector <4 x double> %793, <4 x double> poison, <1 x i32> zeroinitializer
  %795 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %796 = fmul <1 x double> %792, %794
  %797 = shufflevector <1 x double> %796, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %798 = fadd <4 x double> %795, %797
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %798, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %799 = getelementptr double, ptr %691, i64 12
  %800 = load double, ptr %799, align 8
  %801 = insertelement <1 x double> poison, double %800, i64 0
  %802 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.12, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %803 = shufflevector <4 x double> %802, <4 x double> poison, <1 x i32> zeroinitializer
  %804 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %805 = fmul <1 x double> %801, %803
  %806 = shufflevector <1 x double> %805, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %807 = fadd <4 x double> %804, %806
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %807, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %808 = getelementptr double, ptr %691, i64 13
  %809 = load double, ptr %808, align 8
  %810 = insertelement <1 x double> poison, double %809, i64 0
  %811 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.13, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %812 = shufflevector <4 x double> %811, <4 x double> poison, <1 x i32> zeroinitializer
  %813 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %814 = fmul <1 x double> %810, %812
  %815 = shufflevector <1 x double> %814, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %816 = fadd <4 x double> %813, %815
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %816, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %817 = getelementptr double, ptr %691, i64 14
  %818 = load double, ptr %817, align 8
  %819 = insertelement <1 x double> poison, double %818, i64 0
  %820 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.14, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %821 = shufflevector <4 x double> %820, <4 x double> poison, <1 x i32> zeroinitializer
  %822 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %823 = fmul <1 x double> %819, %821
  %824 = shufflevector <1 x double> %823, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %825 = fadd <4 x double> %822, %824
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %825, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %826 = getelementptr double, ptr %691, i64 15
  %827 = load double, ptr %826, align 8
  %828 = insertelement <1 x double> poison, double %827, i64 0
  %829 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.15, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %830 = shufflevector <4 x double> %829, <4 x double> poison, <1 x i32> zeroinitializer
  %831 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %832 = fmul <1 x double> %828, %830
  %833 = shufflevector <1 x double> %832, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %834 = fadd <4 x double> %831, %833
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %834, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %835 = getelementptr double, ptr %691, i64 16
  %836 = load double, ptr %835, align 8
  %837 = insertelement <1 x double> poison, double %836, i64 0
  %838 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.16, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %839 = shufflevector <4 x double> %838, <4 x double> poison, <1 x i32> zeroinitializer
  %840 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %841 = fmul <1 x double> %837, %839
  %842 = shufflevector <1 x double> %841, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %843 = fadd <4 x double> %840, %842
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %843, ptr %689, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %844 = add nuw nsw i64 %687, 1
  %exitcond22.not.i.4 = icmp eq i64 %844, 16
  br i1 %exitcond22.not.i.4, label %.split20.us.i.4, label %.preheader16.us.i.4

.split20.us.i.4:                                  ; preds = %.preheader16.us.i.4
  %845 = getelementptr double, ptr %.unpack32, i64 1040
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 272
  br label %.preheader16.us.1.i

.preheader16.us.1.i:                              ; preds = %._crit_edge.us.1.i, %.split20.us.i.4
  %846 = phi i64 [ %1013, %._crit_edge.us.1.i ], [ 0, %.split20.us.i.4 ]
  %847 = mul nuw nsw i64 %846, 17
  %848 = mul nuw nsw i64 %846, 65
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %847
  %849 = getelementptr double, ptr %845, i64 %848
  %.promoted134 = load <4 x double>, ptr %849, align 8
  br label %.critedge.us.1.i

.critedge.us.1.i:                                 ; preds = %.critedge.us.1.i.1177, %.preheader16.us.1.i
  %850 = phi <4 x double> [ %.promoted134, %.preheader16.us.1.i ], [ %888, %.critedge.us.1.i.1177 ]
  %851 = phi i64 [ 0, %.preheader16.us.1.i ], [ %889, %.critedge.us.1.i.1177 ]
  %852 = mul nuw nsw i64 %851, 65
  %853 = getelementptr double, ptr %gep.i, i64 %851
  %854 = load double, ptr %853, align 8
  %855 = insertelement <1 x double> poison, double %854, i64 0
  %gep.us.1.i = getelementptr double, ptr %.unpack17, i64 %852
  %unmaskedload100 = load <4 x double>, ptr %gep.us.1.i, align 8
  %856 = shufflevector <4 x double> %unmaskedload100, <4 x double> poison, <1 x i32> zeroinitializer
  %857 = shufflevector <4 x double> %unmaskedload100, <4 x double> poison, <1 x i32> <i32 1>
  %858 = shufflevector <4 x double> %unmaskedload100, <4 x double> poison, <1 x i32> <i32 2>
  %859 = shufflevector <4 x double> %unmaskedload100, <4 x double> poison, <1 x i32> <i32 3>
  %860 = fmul <1 x double> %855, %856
  %861 = fmul <1 x double> %855, %857
  %862 = fmul <1 x double> %855, %858
  %863 = shufflevector <1 x double> %862, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %864 = fmul <1 x double> %855, %859
  %865 = shufflevector <1 x double> %864, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %866 = shufflevector <1 x double> %860, <1 x double> %861, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %867 = shufflevector <4 x double> %866, <4 x double> %863, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %868 = shufflevector <4 x double> %867, <4 x double> %865, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %869 = fadd <4 x double> %850, %868
  store <4 x double> %869, ptr %849, align 8
  %870 = or disjoint i64 %851, 1
  %exitcond.1.not.i = icmp eq i64 %870, 17
  br i1 %exitcond.1.not.i, label %.preheader.us.1.i.157, label %.critedge.us.1.i.1177

.critedge.us.1.i.1177:                            ; preds = %.critedge.us.1.i
  %871 = mul nuw nsw i64 %870, 65
  %872 = getelementptr double, ptr %gep.i, i64 %870
  %873 = load double, ptr %872, align 8
  %874 = insertelement <1 x double> poison, double %873, i64 0
  %gep.us.1.i.1175 = getelementptr double, ptr %.unpack17, i64 %871
  %unmaskedload100.1 = load <4 x double>, ptr %gep.us.1.i.1175, align 8
  %875 = shufflevector <4 x double> %unmaskedload100.1, <4 x double> poison, <1 x i32> zeroinitializer
  %876 = shufflevector <4 x double> %unmaskedload100.1, <4 x double> poison, <1 x i32> <i32 1>
  %877 = shufflevector <4 x double> %unmaskedload100.1, <4 x double> poison, <1 x i32> <i32 2>
  %878 = shufflevector <4 x double> %unmaskedload100.1, <4 x double> poison, <1 x i32> <i32 3>
  %879 = fmul <1 x double> %874, %875
  %880 = fmul <1 x double> %874, %876
  %881 = fmul <1 x double> %874, %877
  %882 = shufflevector <1 x double> %881, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %883 = fmul <1 x double> %874, %878
  %884 = shufflevector <1 x double> %883, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %885 = shufflevector <1 x double> %879, <1 x double> %880, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %886 = shufflevector <4 x double> %885, <4 x double> %882, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %887 = shufflevector <4 x double> %886, <4 x double> %884, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %888 = fadd <4 x double> %869, %887
  store <4 x double> %888, ptr %849, align 8
  %889 = add nuw nsw i64 %851, 2
  br label %.critedge.us.1.i

.preheader.us.1.i.157:                            ; preds = %.critedge.us.1.i
  %890 = getelementptr double, ptr %849, i64 4
  %.promoted133 = load <4 x double>, ptr %890, align 8
  br label %.critedge.us.1.i.160

.critedge.us.1.i.160:                             ; preds = %.critedge.us.1.i.160.1, %.preheader.us.1.i.157
  %891 = phi <4 x double> [ %.promoted133, %.preheader.us.1.i.157 ], [ %929, %.critedge.us.1.i.160.1 ]
  %892 = phi i64 [ 0, %.preheader.us.1.i.157 ], [ %930, %.critedge.us.1.i.160.1 ]
  %893 = mul nuw nsw i64 %892, 65
  %894 = getelementptr double, ptr %gep.i, i64 %892
  %895 = load double, ptr %894, align 8
  %896 = insertelement <1 x double> poison, double %895, i64 0
  %gep.us.1.i.158 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %893
  %unmaskedload102 = load <4 x double>, ptr %gep.us.1.i.158, align 8
  %897 = shufflevector <4 x double> %unmaskedload102, <4 x double> poison, <1 x i32> zeroinitializer
  %898 = shufflevector <4 x double> %unmaskedload102, <4 x double> poison, <1 x i32> <i32 1>
  %899 = shufflevector <4 x double> %unmaskedload102, <4 x double> poison, <1 x i32> <i32 2>
  %900 = shufflevector <4 x double> %unmaskedload102, <4 x double> poison, <1 x i32> <i32 3>
  %901 = fmul <1 x double> %896, %897
  %902 = fmul <1 x double> %896, %898
  %903 = fmul <1 x double> %896, %899
  %904 = shufflevector <1 x double> %903, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %905 = fmul <1 x double> %896, %900
  %906 = shufflevector <1 x double> %905, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %907 = shufflevector <1 x double> %901, <1 x double> %902, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %908 = shufflevector <4 x double> %907, <4 x double> %904, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %909 = shufflevector <4 x double> %908, <4 x double> %906, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %910 = fadd <4 x double> %891, %909
  store <4 x double> %910, ptr %890, align 8
  %911 = or disjoint i64 %892, 1
  %exitcond.1.not.i.159 = icmp eq i64 %911, 17
  br i1 %exitcond.1.not.i.159, label %.preheader.us.1.i.261, label %.critedge.us.1.i.160.1

.critedge.us.1.i.160.1:                           ; preds = %.critedge.us.1.i.160
  %912 = mul nuw nsw i64 %911, 65
  %913 = getelementptr double, ptr %gep.i, i64 %911
  %914 = load double, ptr %913, align 8
  %915 = insertelement <1 x double> poison, double %914, i64 0
  %gep.us.1.i.158.1 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %912
  %unmaskedload102.1 = load <4 x double>, ptr %gep.us.1.i.158.1, align 8
  %916 = shufflevector <4 x double> %unmaskedload102.1, <4 x double> poison, <1 x i32> zeroinitializer
  %917 = shufflevector <4 x double> %unmaskedload102.1, <4 x double> poison, <1 x i32> <i32 1>
  %918 = shufflevector <4 x double> %unmaskedload102.1, <4 x double> poison, <1 x i32> <i32 2>
  %919 = shufflevector <4 x double> %unmaskedload102.1, <4 x double> poison, <1 x i32> <i32 3>
  %920 = fmul <1 x double> %915, %916
  %921 = fmul <1 x double> %915, %917
  %922 = fmul <1 x double> %915, %918
  %923 = shufflevector <1 x double> %922, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %924 = fmul <1 x double> %915, %919
  %925 = shufflevector <1 x double> %924, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %926 = shufflevector <1 x double> %920, <1 x double> %921, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %927 = shufflevector <4 x double> %926, <4 x double> %923, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %928 = shufflevector <4 x double> %927, <4 x double> %925, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %929 = fadd <4 x double> %910, %928
  store <4 x double> %929, ptr %890, align 8
  %930 = add nuw nsw i64 %892, 2
  br label %.critedge.us.1.i.160

.preheader.us.1.i.261:                            ; preds = %.critedge.us.1.i.160
  %931 = getelementptr double, ptr %849, i64 8
  %.promoted132 = load <4 x double>, ptr %931, align 8
  br label %.critedge.us.1.i.264

.critedge.us.1.i.264:                             ; preds = %.critedge.us.1.i.264.1, %.preheader.us.1.i.261
  %932 = phi <4 x double> [ %.promoted132, %.preheader.us.1.i.261 ], [ %970, %.critedge.us.1.i.264.1 ]
  %933 = phi i64 [ 0, %.preheader.us.1.i.261 ], [ %971, %.critedge.us.1.i.264.1 ]
  %934 = mul nuw nsw i64 %933, 65
  %935 = getelementptr double, ptr %gep.i, i64 %933
  %936 = load double, ptr %935, align 8
  %937 = insertelement <1 x double> poison, double %936, i64 0
  %gep.us.1.i.262 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %934
  %unmaskedload104 = load <4 x double>, ptr %gep.us.1.i.262, align 8
  %938 = shufflevector <4 x double> %unmaskedload104, <4 x double> poison, <1 x i32> zeroinitializer
  %939 = shufflevector <4 x double> %unmaskedload104, <4 x double> poison, <1 x i32> <i32 1>
  %940 = shufflevector <4 x double> %unmaskedload104, <4 x double> poison, <1 x i32> <i32 2>
  %941 = shufflevector <4 x double> %unmaskedload104, <4 x double> poison, <1 x i32> <i32 3>
  %942 = fmul <1 x double> %937, %938
  %943 = fmul <1 x double> %937, %939
  %944 = fmul <1 x double> %937, %940
  %945 = shufflevector <1 x double> %944, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %946 = fmul <1 x double> %937, %941
  %947 = shufflevector <1 x double> %946, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %948 = shufflevector <1 x double> %942, <1 x double> %943, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %949 = shufflevector <4 x double> %948, <4 x double> %945, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %950 = shufflevector <4 x double> %949, <4 x double> %947, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %951 = fadd <4 x double> %932, %950
  store <4 x double> %951, ptr %931, align 8
  %952 = or disjoint i64 %933, 1
  %exitcond.1.not.i.263 = icmp eq i64 %952, 17
  br i1 %exitcond.1.not.i.263, label %.preheader.us.1.i.365, label %.critedge.us.1.i.264.1

.critedge.us.1.i.264.1:                           ; preds = %.critedge.us.1.i.264
  %953 = mul nuw nsw i64 %952, 65
  %954 = getelementptr double, ptr %gep.i, i64 %952
  %955 = load double, ptr %954, align 8
  %956 = insertelement <1 x double> poison, double %955, i64 0
  %gep.us.1.i.262.1 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %953
  %unmaskedload104.1 = load <4 x double>, ptr %gep.us.1.i.262.1, align 8
  %957 = shufflevector <4 x double> %unmaskedload104.1, <4 x double> poison, <1 x i32> zeroinitializer
  %958 = shufflevector <4 x double> %unmaskedload104.1, <4 x double> poison, <1 x i32> <i32 1>
  %959 = shufflevector <4 x double> %unmaskedload104.1, <4 x double> poison, <1 x i32> <i32 2>
  %960 = shufflevector <4 x double> %unmaskedload104.1, <4 x double> poison, <1 x i32> <i32 3>
  %961 = fmul <1 x double> %956, %957
  %962 = fmul <1 x double> %956, %958
  %963 = fmul <1 x double> %956, %959
  %964 = shufflevector <1 x double> %963, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %965 = fmul <1 x double> %956, %960
  %966 = shufflevector <1 x double> %965, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %967 = shufflevector <1 x double> %961, <1 x double> %962, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %968 = shufflevector <4 x double> %967, <4 x double> %964, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %969 = shufflevector <4 x double> %968, <4 x double> %966, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %970 = fadd <4 x double> %951, %969
  store <4 x double> %970, ptr %931, align 8
  %971 = add nuw nsw i64 %933, 2
  br label %.critedge.us.1.i.264

.preheader.us.1.i.365:                            ; preds = %.critedge.us.1.i.264
  %972 = getelementptr double, ptr %849, i64 12
  %.promoted = load <4 x double>, ptr %972, align 8
  br label %.critedge.us.1.i.368

.critedge.us.1.i.368:                             ; preds = %.critedge.us.1.i.368.1, %.preheader.us.1.i.365
  %973 = phi <4 x double> [ %.promoted, %.preheader.us.1.i.365 ], [ %1011, %.critedge.us.1.i.368.1 ]
  %974 = phi i64 [ 0, %.preheader.us.1.i.365 ], [ %1012, %.critedge.us.1.i.368.1 ]
  %975 = mul nuw nsw i64 %974, 65
  %976 = getelementptr double, ptr %gep.i, i64 %974
  %977 = load double, ptr %976, align 8
  %978 = insertelement <1 x double> poison, double %977, i64 0
  %gep.us.1.i.366 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %975
  %unmaskedload106 = load <4 x double>, ptr %gep.us.1.i.366, align 8
  %979 = shufflevector <4 x double> %unmaskedload106, <4 x double> poison, <1 x i32> zeroinitializer
  %980 = shufflevector <4 x double> %unmaskedload106, <4 x double> poison, <1 x i32> <i32 1>
  %981 = shufflevector <4 x double> %unmaskedload106, <4 x double> poison, <1 x i32> <i32 2>
  %982 = shufflevector <4 x double> %unmaskedload106, <4 x double> poison, <1 x i32> <i32 3>
  %983 = fmul <1 x double> %978, %979
  %984 = fmul <1 x double> %978, %980
  %985 = fmul <1 x double> %978, %981
  %986 = shufflevector <1 x double> %985, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %987 = fmul <1 x double> %978, %982
  %988 = shufflevector <1 x double> %987, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %989 = shufflevector <1 x double> %983, <1 x double> %984, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %990 = shufflevector <4 x double> %989, <4 x double> %986, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %991 = shufflevector <4 x double> %990, <4 x double> %988, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %992 = fadd <4 x double> %973, %991
  store <4 x double> %992, ptr %972, align 8
  %993 = or disjoint i64 %974, 1
  %exitcond.1.not.i.367 = icmp eq i64 %993, 17
  br i1 %exitcond.1.not.i.367, label %._crit_edge.us.1.i, label %.critedge.us.1.i.368.1

.critedge.us.1.i.368.1:                           ; preds = %.critedge.us.1.i.368
  %994 = mul nuw nsw i64 %993, 65
  %995 = getelementptr double, ptr %gep.i, i64 %993
  %996 = load double, ptr %995, align 8
  %997 = insertelement <1 x double> poison, double %996, i64 0
  %gep.us.1.i.366.1 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %994
  %unmaskedload106.1 = load <4 x double>, ptr %gep.us.1.i.366.1, align 8
  %998 = shufflevector <4 x double> %unmaskedload106.1, <4 x double> poison, <1 x i32> zeroinitializer
  %999 = shufflevector <4 x double> %unmaskedload106.1, <4 x double> poison, <1 x i32> <i32 1>
  %1000 = shufflevector <4 x double> %unmaskedload106.1, <4 x double> poison, <1 x i32> <i32 2>
  %1001 = shufflevector <4 x double> %unmaskedload106.1, <4 x double> poison, <1 x i32> <i32 3>
  %1002 = fmul <1 x double> %997, %998
  %1003 = fmul <1 x double> %997, %999
  %1004 = fmul <1 x double> %997, %1000
  %1005 = shufflevector <1 x double> %1004, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1006 = fmul <1 x double> %997, %1001
  %1007 = shufflevector <1 x double> %1006, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1008 = shufflevector <1 x double> %1002, <1 x double> %1003, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1009 = shufflevector <4 x double> %1008, <4 x double> %1005, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1010 = shufflevector <4 x double> %1009, <4 x double> %1007, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1011 = fadd <4 x double> %992, %1010
  store <4 x double> %1011, ptr %972, align 8
  %1012 = add nuw nsw i64 %974, 2
  br label %.critedge.us.1.i.368

._crit_edge.us.1.i:                               ; preds = %.critedge.us.1.i.368
  %1013 = add nuw nsw i64 %846, 1
  %exitcond22.1.not.i = icmp eq i64 %1013, 15
  br i1 %exitcond22.1.not.i, label %.split20.us.1.i, label %.preheader16.us.1.i

.split20.us.1.i:                                  ; preds = %._crit_edge.us.1.i
  %1014 = getelementptr double, ptr %.unpack32, i64 1056
  br label %.preheader16.us.1.i.1

.preheader16.us.1.i.1:                            ; preds = %._crit_edge.us.1.i.1, %.split20.us.1.i
  %1015 = phi i64 [ %1182, %._crit_edge.us.1.i.1 ], [ 0, %.split20.us.1.i ]
  %1016 = mul nuw nsw i64 %1015, 17
  %1017 = mul nuw nsw i64 %1015, 65
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %1016
  %1018 = getelementptr double, ptr %1014, i64 %1017
  %.promoted138 = load <4 x double>, ptr %1018, align 8
  br label %.critedge.us.1.i.1

.critedge.us.1.i.1:                               ; preds = %.critedge.us.1.i.1.1180, %.preheader16.us.1.i.1
  %1019 = phi <4 x double> [ %.promoted138, %.preheader16.us.1.i.1 ], [ %1057, %.critedge.us.1.i.1.1180 ]
  %1020 = phi i64 [ 0, %.preheader16.us.1.i.1 ], [ %1058, %.critedge.us.1.i.1.1180 ]
  %1021 = mul nuw nsw i64 %1020, 65
  %1022 = getelementptr double, ptr %gep.i.1, i64 %1020
  %1023 = load double, ptr %1022, align 8
  %1024 = insertelement <1 x double> poison, double %1023, i64 0
  %gep.us.1.i.1 = getelementptr double, ptr %172, i64 %1021
  %unmaskedload108 = load <4 x double>, ptr %gep.us.1.i.1, align 8
  %1025 = shufflevector <4 x double> %unmaskedload108, <4 x double> poison, <1 x i32> zeroinitializer
  %1026 = shufflevector <4 x double> %unmaskedload108, <4 x double> poison, <1 x i32> <i32 1>
  %1027 = shufflevector <4 x double> %unmaskedload108, <4 x double> poison, <1 x i32> <i32 2>
  %1028 = shufflevector <4 x double> %unmaskedload108, <4 x double> poison, <1 x i32> <i32 3>
  %1029 = fmul <1 x double> %1024, %1025
  %1030 = fmul <1 x double> %1024, %1026
  %1031 = fmul <1 x double> %1024, %1027
  %1032 = shufflevector <1 x double> %1031, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1033 = fmul <1 x double> %1024, %1028
  %1034 = shufflevector <1 x double> %1033, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1035 = shufflevector <1 x double> %1029, <1 x double> %1030, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1036 = shufflevector <4 x double> %1035, <4 x double> %1032, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1037 = shufflevector <4 x double> %1036, <4 x double> %1034, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1038 = fadd <4 x double> %1019, %1037
  store <4 x double> %1038, ptr %1018, align 8
  %1039 = or disjoint i64 %1020, 1
  %exitcond.1.not.i.1 = icmp eq i64 %1039, 17
  br i1 %exitcond.1.not.i.1, label %.preheader.us.1.i.1.1, label %.critedge.us.1.i.1.1180

.critedge.us.1.i.1.1180:                          ; preds = %.critedge.us.1.i.1
  %1040 = mul nuw nsw i64 %1039, 65
  %1041 = getelementptr double, ptr %gep.i.1, i64 %1039
  %1042 = load double, ptr %1041, align 8
  %1043 = insertelement <1 x double> poison, double %1042, i64 0
  %gep.us.1.i.1.1178 = getelementptr double, ptr %172, i64 %1040
  %unmaskedload108.1 = load <4 x double>, ptr %gep.us.1.i.1.1178, align 8
  %1044 = shufflevector <4 x double> %unmaskedload108.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1045 = shufflevector <4 x double> %unmaskedload108.1, <4 x double> poison, <1 x i32> <i32 1>
  %1046 = shufflevector <4 x double> %unmaskedload108.1, <4 x double> poison, <1 x i32> <i32 2>
  %1047 = shufflevector <4 x double> %unmaskedload108.1, <4 x double> poison, <1 x i32> <i32 3>
  %1048 = fmul <1 x double> %1043, %1044
  %1049 = fmul <1 x double> %1043, %1045
  %1050 = fmul <1 x double> %1043, %1046
  %1051 = shufflevector <1 x double> %1050, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1052 = fmul <1 x double> %1043, %1047
  %1053 = shufflevector <1 x double> %1052, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1054 = shufflevector <1 x double> %1048, <1 x double> %1049, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1055 = shufflevector <4 x double> %1054, <4 x double> %1051, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1056 = shufflevector <4 x double> %1055, <4 x double> %1053, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1057 = fadd <4 x double> %1038, %1056
  store <4 x double> %1057, ptr %1018, align 8
  %1058 = add nuw nsw i64 %1020, 2
  br label %.critedge.us.1.i.1

.preheader.us.1.i.1.1:                            ; preds = %.critedge.us.1.i.1
  %1059 = getelementptr double, ptr %1018, i64 4
  %.promoted137 = load <4 x double>, ptr %1059, align 8
  br label %.critedge.us.1.i.1.1

.critedge.us.1.i.1.1:                             ; preds = %.critedge.us.1.i.1.1.1, %.preheader.us.1.i.1.1
  %1060 = phi <4 x double> [ %.promoted137, %.preheader.us.1.i.1.1 ], [ %1098, %.critedge.us.1.i.1.1.1 ]
  %1061 = phi i64 [ 0, %.preheader.us.1.i.1.1 ], [ %1099, %.critedge.us.1.i.1.1.1 ]
  %1062 = mul nuw nsw i64 %1061, 65
  %1063 = getelementptr double, ptr %gep.i.1, i64 %1061
  %1064 = load double, ptr %1063, align 8
  %1065 = insertelement <1 x double> poison, double %1064, i64 0
  %gep.us.1.i.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %1062
  %unmaskedload110 = load <4 x double>, ptr %gep.us.1.i.1.1, align 8
  %1066 = shufflevector <4 x double> %unmaskedload110, <4 x double> poison, <1 x i32> zeroinitializer
  %1067 = shufflevector <4 x double> %unmaskedload110, <4 x double> poison, <1 x i32> <i32 1>
  %1068 = shufflevector <4 x double> %unmaskedload110, <4 x double> poison, <1 x i32> <i32 2>
  %1069 = shufflevector <4 x double> %unmaskedload110, <4 x double> poison, <1 x i32> <i32 3>
  %1070 = fmul <1 x double> %1065, %1066
  %1071 = fmul <1 x double> %1065, %1067
  %1072 = fmul <1 x double> %1065, %1068
  %1073 = shufflevector <1 x double> %1072, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1074 = fmul <1 x double> %1065, %1069
  %1075 = shufflevector <1 x double> %1074, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1076 = shufflevector <1 x double> %1070, <1 x double> %1071, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1077 = shufflevector <4 x double> %1076, <4 x double> %1073, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1078 = shufflevector <4 x double> %1077, <4 x double> %1075, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1079 = fadd <4 x double> %1060, %1078
  store <4 x double> %1079, ptr %1059, align 8
  %1080 = or disjoint i64 %1061, 1
  %exitcond.1.not.i.1.1 = icmp eq i64 %1080, 17
  br i1 %exitcond.1.not.i.1.1, label %.preheader.us.1.i.1.2, label %.critedge.us.1.i.1.1.1

.critedge.us.1.i.1.1.1:                           ; preds = %.critedge.us.1.i.1.1
  %1081 = mul nuw nsw i64 %1080, 65
  %1082 = getelementptr double, ptr %gep.i.1, i64 %1080
  %1083 = load double, ptr %1082, align 8
  %1084 = insertelement <1 x double> poison, double %1083, i64 0
  %gep.us.1.i.1.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %1081
  %unmaskedload110.1 = load <4 x double>, ptr %gep.us.1.i.1.1.1, align 8
  %1085 = shufflevector <4 x double> %unmaskedload110.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1086 = shufflevector <4 x double> %unmaskedload110.1, <4 x double> poison, <1 x i32> <i32 1>
  %1087 = shufflevector <4 x double> %unmaskedload110.1, <4 x double> poison, <1 x i32> <i32 2>
  %1088 = shufflevector <4 x double> %unmaskedload110.1, <4 x double> poison, <1 x i32> <i32 3>
  %1089 = fmul <1 x double> %1084, %1085
  %1090 = fmul <1 x double> %1084, %1086
  %1091 = fmul <1 x double> %1084, %1087
  %1092 = shufflevector <1 x double> %1091, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1093 = fmul <1 x double> %1084, %1088
  %1094 = shufflevector <1 x double> %1093, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1095 = shufflevector <1 x double> %1089, <1 x double> %1090, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1096 = shufflevector <4 x double> %1095, <4 x double> %1092, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1097 = shufflevector <4 x double> %1096, <4 x double> %1094, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1098 = fadd <4 x double> %1079, %1097
  store <4 x double> %1098, ptr %1059, align 8
  %1099 = add nuw nsw i64 %1061, 2
  br label %.critedge.us.1.i.1.1

.preheader.us.1.i.1.2:                            ; preds = %.critedge.us.1.i.1.1
  %1100 = getelementptr double, ptr %1018, i64 8
  %.promoted136 = load <4 x double>, ptr %1100, align 8
  br label %.critedge.us.1.i.1.2

.critedge.us.1.i.1.2:                             ; preds = %.critedge.us.1.i.1.2.1, %.preheader.us.1.i.1.2
  %1101 = phi <4 x double> [ %.promoted136, %.preheader.us.1.i.1.2 ], [ %1139, %.critedge.us.1.i.1.2.1 ]
  %1102 = phi i64 [ 0, %.preheader.us.1.i.1.2 ], [ %1140, %.critedge.us.1.i.1.2.1 ]
  %1103 = mul nuw nsw i64 %1102, 65
  %1104 = getelementptr double, ptr %gep.i.1, i64 %1102
  %1105 = load double, ptr %1104, align 8
  %1106 = insertelement <1 x double> poison, double %1105, i64 0
  %gep.us.1.i.1.2 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %1103
  %unmaskedload112 = load <4 x double>, ptr %gep.us.1.i.1.2, align 8
  %1107 = shufflevector <4 x double> %unmaskedload112, <4 x double> poison, <1 x i32> zeroinitializer
  %1108 = shufflevector <4 x double> %unmaskedload112, <4 x double> poison, <1 x i32> <i32 1>
  %1109 = shufflevector <4 x double> %unmaskedload112, <4 x double> poison, <1 x i32> <i32 2>
  %1110 = shufflevector <4 x double> %unmaskedload112, <4 x double> poison, <1 x i32> <i32 3>
  %1111 = fmul <1 x double> %1106, %1107
  %1112 = fmul <1 x double> %1106, %1108
  %1113 = fmul <1 x double> %1106, %1109
  %1114 = shufflevector <1 x double> %1113, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1115 = fmul <1 x double> %1106, %1110
  %1116 = shufflevector <1 x double> %1115, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1117 = shufflevector <1 x double> %1111, <1 x double> %1112, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1118 = shufflevector <4 x double> %1117, <4 x double> %1114, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1119 = shufflevector <4 x double> %1118, <4 x double> %1116, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1120 = fadd <4 x double> %1101, %1119
  store <4 x double> %1120, ptr %1100, align 8
  %1121 = or disjoint i64 %1102, 1
  %exitcond.1.not.i.1.2 = icmp eq i64 %1121, 17
  br i1 %exitcond.1.not.i.1.2, label %.preheader.us.1.i.1.3, label %.critedge.us.1.i.1.2.1

.critedge.us.1.i.1.2.1:                           ; preds = %.critedge.us.1.i.1.2
  %1122 = mul nuw nsw i64 %1121, 65
  %1123 = getelementptr double, ptr %gep.i.1, i64 %1121
  %1124 = load double, ptr %1123, align 8
  %1125 = insertelement <1 x double> poison, double %1124, i64 0
  %gep.us.1.i.1.2.1 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %1122
  %unmaskedload112.1 = load <4 x double>, ptr %gep.us.1.i.1.2.1, align 8
  %1126 = shufflevector <4 x double> %unmaskedload112.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1127 = shufflevector <4 x double> %unmaskedload112.1, <4 x double> poison, <1 x i32> <i32 1>
  %1128 = shufflevector <4 x double> %unmaskedload112.1, <4 x double> poison, <1 x i32> <i32 2>
  %1129 = shufflevector <4 x double> %unmaskedload112.1, <4 x double> poison, <1 x i32> <i32 3>
  %1130 = fmul <1 x double> %1125, %1126
  %1131 = fmul <1 x double> %1125, %1127
  %1132 = fmul <1 x double> %1125, %1128
  %1133 = shufflevector <1 x double> %1132, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1134 = fmul <1 x double> %1125, %1129
  %1135 = shufflevector <1 x double> %1134, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1136 = shufflevector <1 x double> %1130, <1 x double> %1131, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1137 = shufflevector <4 x double> %1136, <4 x double> %1133, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1138 = shufflevector <4 x double> %1137, <4 x double> %1135, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1139 = fadd <4 x double> %1120, %1138
  store <4 x double> %1139, ptr %1100, align 8
  %1140 = add nuw nsw i64 %1102, 2
  br label %.critedge.us.1.i.1.2

.preheader.us.1.i.1.3:                            ; preds = %.critedge.us.1.i.1.2
  %1141 = getelementptr double, ptr %1018, i64 12
  %.promoted135 = load <4 x double>, ptr %1141, align 8
  br label %.critedge.us.1.i.1.3

.critedge.us.1.i.1.3:                             ; preds = %.critedge.us.1.i.1.3.1, %.preheader.us.1.i.1.3
  %1142 = phi <4 x double> [ %.promoted135, %.preheader.us.1.i.1.3 ], [ %1180, %.critedge.us.1.i.1.3.1 ]
  %1143 = phi i64 [ 0, %.preheader.us.1.i.1.3 ], [ %1181, %.critedge.us.1.i.1.3.1 ]
  %1144 = mul nuw nsw i64 %1143, 65
  %1145 = getelementptr double, ptr %gep.i.1, i64 %1143
  %1146 = load double, ptr %1145, align 8
  %1147 = insertelement <1 x double> poison, double %1146, i64 0
  %gep.us.1.i.1.3 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %1144
  %unmaskedload114 = load <4 x double>, ptr %gep.us.1.i.1.3, align 8
  %1148 = shufflevector <4 x double> %unmaskedload114, <4 x double> poison, <1 x i32> zeroinitializer
  %1149 = shufflevector <4 x double> %unmaskedload114, <4 x double> poison, <1 x i32> <i32 1>
  %1150 = shufflevector <4 x double> %unmaskedload114, <4 x double> poison, <1 x i32> <i32 2>
  %1151 = shufflevector <4 x double> %unmaskedload114, <4 x double> poison, <1 x i32> <i32 3>
  %1152 = fmul <1 x double> %1147, %1148
  %1153 = fmul <1 x double> %1147, %1149
  %1154 = fmul <1 x double> %1147, %1150
  %1155 = shufflevector <1 x double> %1154, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1156 = fmul <1 x double> %1147, %1151
  %1157 = shufflevector <1 x double> %1156, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1158 = shufflevector <1 x double> %1152, <1 x double> %1153, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1159 = shufflevector <4 x double> %1158, <4 x double> %1155, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1160 = shufflevector <4 x double> %1159, <4 x double> %1157, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1161 = fadd <4 x double> %1142, %1160
  store <4 x double> %1161, ptr %1141, align 8
  %1162 = or disjoint i64 %1143, 1
  %exitcond.1.not.i.1.3 = icmp eq i64 %1162, 17
  br i1 %exitcond.1.not.i.1.3, label %._crit_edge.us.1.i.1, label %.critedge.us.1.i.1.3.1

.critedge.us.1.i.1.3.1:                           ; preds = %.critedge.us.1.i.1.3
  %1163 = mul nuw nsw i64 %1162, 65
  %1164 = getelementptr double, ptr %gep.i.1, i64 %1162
  %1165 = load double, ptr %1164, align 8
  %1166 = insertelement <1 x double> poison, double %1165, i64 0
  %gep.us.1.i.1.3.1 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %1163
  %unmaskedload114.1 = load <4 x double>, ptr %gep.us.1.i.1.3.1, align 8
  %1167 = shufflevector <4 x double> %unmaskedload114.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1168 = shufflevector <4 x double> %unmaskedload114.1, <4 x double> poison, <1 x i32> <i32 1>
  %1169 = shufflevector <4 x double> %unmaskedload114.1, <4 x double> poison, <1 x i32> <i32 2>
  %1170 = shufflevector <4 x double> %unmaskedload114.1, <4 x double> poison, <1 x i32> <i32 3>
  %1171 = fmul <1 x double> %1166, %1167
  %1172 = fmul <1 x double> %1166, %1168
  %1173 = fmul <1 x double> %1166, %1169
  %1174 = shufflevector <1 x double> %1173, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1175 = fmul <1 x double> %1166, %1170
  %1176 = shufflevector <1 x double> %1175, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1177 = shufflevector <1 x double> %1171, <1 x double> %1172, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1178 = shufflevector <4 x double> %1177, <4 x double> %1174, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1179 = shufflevector <4 x double> %1178, <4 x double> %1176, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1180 = fadd <4 x double> %1161, %1179
  store <4 x double> %1180, ptr %1141, align 8
  %1181 = add nuw nsw i64 %1143, 2
  br label %.critedge.us.1.i.1.3

._crit_edge.us.1.i.1:                             ; preds = %.critedge.us.1.i.1.3
  %1182 = add nuw nsw i64 %1015, 1
  %exitcond22.1.not.i.1 = icmp eq i64 %1182, 15
  br i1 %exitcond22.1.not.i.1, label %.split20.us.1.i.1, label %.preheader16.us.1.i.1

.split20.us.1.i.1:                                ; preds = %._crit_edge.us.1.i.1
  %1183 = getelementptr double, ptr %.unpack32, i64 1072
  br label %.preheader16.us.1.i.2

.preheader16.us.1.i.2:                            ; preds = %._crit_edge.us.1.i.2, %.split20.us.1.i.1
  %1184 = phi i64 [ %1351, %._crit_edge.us.1.i.2 ], [ 0, %.split20.us.1.i.1 ]
  %1185 = mul nuw nsw i64 %1184, 17
  %1186 = mul nuw nsw i64 %1184, 65
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %1185
  %1187 = getelementptr double, ptr %1183, i64 %1186
  %.promoted142 = load <4 x double>, ptr %1187, align 8
  br label %.critedge.us.1.i.2

.critedge.us.1.i.2:                               ; preds = %.critedge.us.1.i.2.1183, %.preheader16.us.1.i.2
  %1188 = phi <4 x double> [ %.promoted142, %.preheader16.us.1.i.2 ], [ %1226, %.critedge.us.1.i.2.1183 ]
  %1189 = phi i64 [ 0, %.preheader16.us.1.i.2 ], [ %1227, %.critedge.us.1.i.2.1183 ]
  %1190 = mul nuw nsw i64 %1189, 65
  %1191 = getelementptr double, ptr %gep.i.2, i64 %1189
  %1192 = load double, ptr %1191, align 8
  %1193 = insertelement <1 x double> poison, double %1192, i64 0
  %gep.us.1.i.2 = getelementptr double, ptr %343, i64 %1190
  %unmaskedload116 = load <4 x double>, ptr %gep.us.1.i.2, align 8
  %1194 = shufflevector <4 x double> %unmaskedload116, <4 x double> poison, <1 x i32> zeroinitializer
  %1195 = shufflevector <4 x double> %unmaskedload116, <4 x double> poison, <1 x i32> <i32 1>
  %1196 = shufflevector <4 x double> %unmaskedload116, <4 x double> poison, <1 x i32> <i32 2>
  %1197 = shufflevector <4 x double> %unmaskedload116, <4 x double> poison, <1 x i32> <i32 3>
  %1198 = fmul <1 x double> %1193, %1194
  %1199 = fmul <1 x double> %1193, %1195
  %1200 = fmul <1 x double> %1193, %1196
  %1201 = shufflevector <1 x double> %1200, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1202 = fmul <1 x double> %1193, %1197
  %1203 = shufflevector <1 x double> %1202, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1204 = shufflevector <1 x double> %1198, <1 x double> %1199, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1205 = shufflevector <4 x double> %1204, <4 x double> %1201, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1206 = shufflevector <4 x double> %1205, <4 x double> %1203, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1207 = fadd <4 x double> %1188, %1206
  store <4 x double> %1207, ptr %1187, align 8
  %1208 = or disjoint i64 %1189, 1
  %exitcond.1.not.i.2 = icmp eq i64 %1208, 17
  br i1 %exitcond.1.not.i.2, label %.preheader.us.1.i.2.1, label %.critedge.us.1.i.2.1183

.critedge.us.1.i.2.1183:                          ; preds = %.critedge.us.1.i.2
  %1209 = mul nuw nsw i64 %1208, 65
  %1210 = getelementptr double, ptr %gep.i.2, i64 %1208
  %1211 = load double, ptr %1210, align 8
  %1212 = insertelement <1 x double> poison, double %1211, i64 0
  %gep.us.1.i.2.1181 = getelementptr double, ptr %343, i64 %1209
  %unmaskedload116.1 = load <4 x double>, ptr %gep.us.1.i.2.1181, align 8
  %1213 = shufflevector <4 x double> %unmaskedload116.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1214 = shufflevector <4 x double> %unmaskedload116.1, <4 x double> poison, <1 x i32> <i32 1>
  %1215 = shufflevector <4 x double> %unmaskedload116.1, <4 x double> poison, <1 x i32> <i32 2>
  %1216 = shufflevector <4 x double> %unmaskedload116.1, <4 x double> poison, <1 x i32> <i32 3>
  %1217 = fmul <1 x double> %1212, %1213
  %1218 = fmul <1 x double> %1212, %1214
  %1219 = fmul <1 x double> %1212, %1215
  %1220 = shufflevector <1 x double> %1219, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1221 = fmul <1 x double> %1212, %1216
  %1222 = shufflevector <1 x double> %1221, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1223 = shufflevector <1 x double> %1217, <1 x double> %1218, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1224 = shufflevector <4 x double> %1223, <4 x double> %1220, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1225 = shufflevector <4 x double> %1224, <4 x double> %1222, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1226 = fadd <4 x double> %1207, %1225
  store <4 x double> %1226, ptr %1187, align 8
  %1227 = add nuw nsw i64 %1189, 2
  br label %.critedge.us.1.i.2

.preheader.us.1.i.2.1:                            ; preds = %.critedge.us.1.i.2
  %1228 = getelementptr double, ptr %1187, i64 4
  %.promoted141 = load <4 x double>, ptr %1228, align 8
  br label %.critedge.us.1.i.2.1

.critedge.us.1.i.2.1:                             ; preds = %.critedge.us.1.i.2.1.1, %.preheader.us.1.i.2.1
  %1229 = phi <4 x double> [ %.promoted141, %.preheader.us.1.i.2.1 ], [ %1267, %.critedge.us.1.i.2.1.1 ]
  %1230 = phi i64 [ 0, %.preheader.us.1.i.2.1 ], [ %1268, %.critedge.us.1.i.2.1.1 ]
  %1231 = mul nuw nsw i64 %1230, 65
  %1232 = getelementptr double, ptr %gep.i.2, i64 %1230
  %1233 = load double, ptr %1232, align 8
  %1234 = insertelement <1 x double> poison, double %1233, i64 0
  %gep.us.1.i.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %1231
  %unmaskedload118 = load <4 x double>, ptr %gep.us.1.i.2.1, align 8
  %1235 = shufflevector <4 x double> %unmaskedload118, <4 x double> poison, <1 x i32> zeroinitializer
  %1236 = shufflevector <4 x double> %unmaskedload118, <4 x double> poison, <1 x i32> <i32 1>
  %1237 = shufflevector <4 x double> %unmaskedload118, <4 x double> poison, <1 x i32> <i32 2>
  %1238 = shufflevector <4 x double> %unmaskedload118, <4 x double> poison, <1 x i32> <i32 3>
  %1239 = fmul <1 x double> %1234, %1235
  %1240 = fmul <1 x double> %1234, %1236
  %1241 = fmul <1 x double> %1234, %1237
  %1242 = shufflevector <1 x double> %1241, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1243 = fmul <1 x double> %1234, %1238
  %1244 = shufflevector <1 x double> %1243, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1245 = shufflevector <1 x double> %1239, <1 x double> %1240, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1246 = shufflevector <4 x double> %1245, <4 x double> %1242, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1247 = shufflevector <4 x double> %1246, <4 x double> %1244, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1248 = fadd <4 x double> %1229, %1247
  store <4 x double> %1248, ptr %1228, align 8
  %1249 = or disjoint i64 %1230, 1
  %exitcond.1.not.i.2.1 = icmp eq i64 %1249, 17
  br i1 %exitcond.1.not.i.2.1, label %.preheader.us.1.i.2.2, label %.critedge.us.1.i.2.1.1

.critedge.us.1.i.2.1.1:                           ; preds = %.critedge.us.1.i.2.1
  %1250 = mul nuw nsw i64 %1249, 65
  %1251 = getelementptr double, ptr %gep.i.2, i64 %1249
  %1252 = load double, ptr %1251, align 8
  %1253 = insertelement <1 x double> poison, double %1252, i64 0
  %gep.us.1.i.2.1.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %1250
  %unmaskedload118.1 = load <4 x double>, ptr %gep.us.1.i.2.1.1, align 8
  %1254 = shufflevector <4 x double> %unmaskedload118.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1255 = shufflevector <4 x double> %unmaskedload118.1, <4 x double> poison, <1 x i32> <i32 1>
  %1256 = shufflevector <4 x double> %unmaskedload118.1, <4 x double> poison, <1 x i32> <i32 2>
  %1257 = shufflevector <4 x double> %unmaskedload118.1, <4 x double> poison, <1 x i32> <i32 3>
  %1258 = fmul <1 x double> %1253, %1254
  %1259 = fmul <1 x double> %1253, %1255
  %1260 = fmul <1 x double> %1253, %1256
  %1261 = shufflevector <1 x double> %1260, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1262 = fmul <1 x double> %1253, %1257
  %1263 = shufflevector <1 x double> %1262, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1264 = shufflevector <1 x double> %1258, <1 x double> %1259, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1265 = shufflevector <4 x double> %1264, <4 x double> %1261, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1266 = shufflevector <4 x double> %1265, <4 x double> %1263, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1267 = fadd <4 x double> %1248, %1266
  store <4 x double> %1267, ptr %1228, align 8
  %1268 = add nuw nsw i64 %1230, 2
  br label %.critedge.us.1.i.2.1

.preheader.us.1.i.2.2:                            ; preds = %.critedge.us.1.i.2.1
  %1269 = getelementptr double, ptr %1187, i64 8
  %.promoted140 = load <4 x double>, ptr %1269, align 8
  br label %.critedge.us.1.i.2.2

.critedge.us.1.i.2.2:                             ; preds = %.critedge.us.1.i.2.2.1, %.preheader.us.1.i.2.2
  %1270 = phi <4 x double> [ %.promoted140, %.preheader.us.1.i.2.2 ], [ %1308, %.critedge.us.1.i.2.2.1 ]
  %1271 = phi i64 [ 0, %.preheader.us.1.i.2.2 ], [ %1309, %.critedge.us.1.i.2.2.1 ]
  %1272 = mul nuw nsw i64 %1271, 65
  %1273 = getelementptr double, ptr %gep.i.2, i64 %1271
  %1274 = load double, ptr %1273, align 8
  %1275 = insertelement <1 x double> poison, double %1274, i64 0
  %gep.us.1.i.2.2 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %1272
  %unmaskedload120 = load <4 x double>, ptr %gep.us.1.i.2.2, align 8
  %1276 = shufflevector <4 x double> %unmaskedload120, <4 x double> poison, <1 x i32> zeroinitializer
  %1277 = shufflevector <4 x double> %unmaskedload120, <4 x double> poison, <1 x i32> <i32 1>
  %1278 = shufflevector <4 x double> %unmaskedload120, <4 x double> poison, <1 x i32> <i32 2>
  %1279 = shufflevector <4 x double> %unmaskedload120, <4 x double> poison, <1 x i32> <i32 3>
  %1280 = fmul <1 x double> %1275, %1276
  %1281 = fmul <1 x double> %1275, %1277
  %1282 = fmul <1 x double> %1275, %1278
  %1283 = shufflevector <1 x double> %1282, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1284 = fmul <1 x double> %1275, %1279
  %1285 = shufflevector <1 x double> %1284, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1286 = shufflevector <1 x double> %1280, <1 x double> %1281, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1287 = shufflevector <4 x double> %1286, <4 x double> %1283, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1288 = shufflevector <4 x double> %1287, <4 x double> %1285, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1289 = fadd <4 x double> %1270, %1288
  store <4 x double> %1289, ptr %1269, align 8
  %1290 = or disjoint i64 %1271, 1
  %exitcond.1.not.i.2.2 = icmp eq i64 %1290, 17
  br i1 %exitcond.1.not.i.2.2, label %.preheader.us.1.i.2.3, label %.critedge.us.1.i.2.2.1

.critedge.us.1.i.2.2.1:                           ; preds = %.critedge.us.1.i.2.2
  %1291 = mul nuw nsw i64 %1290, 65
  %1292 = getelementptr double, ptr %gep.i.2, i64 %1290
  %1293 = load double, ptr %1292, align 8
  %1294 = insertelement <1 x double> poison, double %1293, i64 0
  %gep.us.1.i.2.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %1291
  %unmaskedload120.1 = load <4 x double>, ptr %gep.us.1.i.2.2.1, align 8
  %1295 = shufflevector <4 x double> %unmaskedload120.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1296 = shufflevector <4 x double> %unmaskedload120.1, <4 x double> poison, <1 x i32> <i32 1>
  %1297 = shufflevector <4 x double> %unmaskedload120.1, <4 x double> poison, <1 x i32> <i32 2>
  %1298 = shufflevector <4 x double> %unmaskedload120.1, <4 x double> poison, <1 x i32> <i32 3>
  %1299 = fmul <1 x double> %1294, %1295
  %1300 = fmul <1 x double> %1294, %1296
  %1301 = fmul <1 x double> %1294, %1297
  %1302 = shufflevector <1 x double> %1301, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1303 = fmul <1 x double> %1294, %1298
  %1304 = shufflevector <1 x double> %1303, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1305 = shufflevector <1 x double> %1299, <1 x double> %1300, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1306 = shufflevector <4 x double> %1305, <4 x double> %1302, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1307 = shufflevector <4 x double> %1306, <4 x double> %1304, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1308 = fadd <4 x double> %1289, %1307
  store <4 x double> %1308, ptr %1269, align 8
  %1309 = add nuw nsw i64 %1271, 2
  br label %.critedge.us.1.i.2.2

.preheader.us.1.i.2.3:                            ; preds = %.critedge.us.1.i.2.2
  %1310 = getelementptr double, ptr %1187, i64 12
  %.promoted139 = load <4 x double>, ptr %1310, align 8
  br label %.critedge.us.1.i.2.3

.critedge.us.1.i.2.3:                             ; preds = %.critedge.us.1.i.2.3.1, %.preheader.us.1.i.2.3
  %1311 = phi <4 x double> [ %.promoted139, %.preheader.us.1.i.2.3 ], [ %1349, %.critedge.us.1.i.2.3.1 ]
  %1312 = phi i64 [ 0, %.preheader.us.1.i.2.3 ], [ %1350, %.critedge.us.1.i.2.3.1 ]
  %1313 = mul nuw nsw i64 %1312, 65
  %1314 = getelementptr double, ptr %gep.i.2, i64 %1312
  %1315 = load double, ptr %1314, align 8
  %1316 = insertelement <1 x double> poison, double %1315, i64 0
  %gep.us.1.i.2.3 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %1313
  %unmaskedload122 = load <4 x double>, ptr %gep.us.1.i.2.3, align 8
  %1317 = shufflevector <4 x double> %unmaskedload122, <4 x double> poison, <1 x i32> zeroinitializer
  %1318 = shufflevector <4 x double> %unmaskedload122, <4 x double> poison, <1 x i32> <i32 1>
  %1319 = shufflevector <4 x double> %unmaskedload122, <4 x double> poison, <1 x i32> <i32 2>
  %1320 = shufflevector <4 x double> %unmaskedload122, <4 x double> poison, <1 x i32> <i32 3>
  %1321 = fmul <1 x double> %1316, %1317
  %1322 = fmul <1 x double> %1316, %1318
  %1323 = fmul <1 x double> %1316, %1319
  %1324 = shufflevector <1 x double> %1323, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1325 = fmul <1 x double> %1316, %1320
  %1326 = shufflevector <1 x double> %1325, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1327 = shufflevector <1 x double> %1321, <1 x double> %1322, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1328 = shufflevector <4 x double> %1327, <4 x double> %1324, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1329 = shufflevector <4 x double> %1328, <4 x double> %1326, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1330 = fadd <4 x double> %1311, %1329
  store <4 x double> %1330, ptr %1310, align 8
  %1331 = or disjoint i64 %1312, 1
  %exitcond.1.not.i.2.3 = icmp eq i64 %1331, 17
  br i1 %exitcond.1.not.i.2.3, label %._crit_edge.us.1.i.2, label %.critedge.us.1.i.2.3.1

.critedge.us.1.i.2.3.1:                           ; preds = %.critedge.us.1.i.2.3
  %1332 = mul nuw nsw i64 %1331, 65
  %1333 = getelementptr double, ptr %gep.i.2, i64 %1331
  %1334 = load double, ptr %1333, align 8
  %1335 = insertelement <1 x double> poison, double %1334, i64 0
  %gep.us.1.i.2.3.1 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %1332
  %unmaskedload122.1 = load <4 x double>, ptr %gep.us.1.i.2.3.1, align 8
  %1336 = shufflevector <4 x double> %unmaskedload122.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1337 = shufflevector <4 x double> %unmaskedload122.1, <4 x double> poison, <1 x i32> <i32 1>
  %1338 = shufflevector <4 x double> %unmaskedload122.1, <4 x double> poison, <1 x i32> <i32 2>
  %1339 = shufflevector <4 x double> %unmaskedload122.1, <4 x double> poison, <1 x i32> <i32 3>
  %1340 = fmul <1 x double> %1335, %1336
  %1341 = fmul <1 x double> %1335, %1337
  %1342 = fmul <1 x double> %1335, %1338
  %1343 = shufflevector <1 x double> %1342, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1344 = fmul <1 x double> %1335, %1339
  %1345 = shufflevector <1 x double> %1344, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1346 = shufflevector <1 x double> %1340, <1 x double> %1341, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1347 = shufflevector <4 x double> %1346, <4 x double> %1343, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1348 = shufflevector <4 x double> %1347, <4 x double> %1345, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1349 = fadd <4 x double> %1330, %1348
  store <4 x double> %1349, ptr %1310, align 8
  %1350 = add nuw nsw i64 %1312, 2
  br label %.critedge.us.1.i.2.3

._crit_edge.us.1.i.2:                             ; preds = %.critedge.us.1.i.2.3
  %1351 = add nuw nsw i64 %1184, 1
  %exitcond22.1.not.i.2 = icmp eq i64 %1351, 15
  br i1 %exitcond22.1.not.i.2, label %.split20.us.1.i.2, label %.preheader16.us.1.i.2

.split20.us.1.i.2:                                ; preds = %._crit_edge.us.1.i.2
  %1352 = getelementptr double, ptr %.unpack32, i64 1088
  br label %.preheader16.us.1.i.3

.preheader16.us.1.i.3:                            ; preds = %._crit_edge.us.1.i.3, %.split20.us.1.i.2
  %1353 = phi i64 [ %1520, %._crit_edge.us.1.i.3 ], [ 0, %.split20.us.1.i.2 ]
  %1354 = mul nuw nsw i64 %1353, 17
  %1355 = mul nuw nsw i64 %1353, 65
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %1354
  %1356 = getelementptr double, ptr %1352, i64 %1355
  %.promoted146 = load <4 x double>, ptr %1356, align 8
  br label %.critedge.us.1.i.3

.critedge.us.1.i.3:                               ; preds = %.critedge.us.1.i.3.1186, %.preheader16.us.1.i.3
  %1357 = phi <4 x double> [ %.promoted146, %.preheader16.us.1.i.3 ], [ %1395, %.critedge.us.1.i.3.1186 ]
  %1358 = phi i64 [ 0, %.preheader16.us.1.i.3 ], [ %1396, %.critedge.us.1.i.3.1186 ]
  %1359 = mul nuw nsw i64 %1358, 65
  %1360 = getelementptr double, ptr %gep.i.3, i64 %1358
  %1361 = load double, ptr %1360, align 8
  %1362 = insertelement <1 x double> poison, double %1361, i64 0
  %gep.us.1.i.3 = getelementptr double, ptr %514, i64 %1359
  %unmaskedload124 = load <4 x double>, ptr %gep.us.1.i.3, align 8
  %1363 = shufflevector <4 x double> %unmaskedload124, <4 x double> poison, <1 x i32> zeroinitializer
  %1364 = shufflevector <4 x double> %unmaskedload124, <4 x double> poison, <1 x i32> <i32 1>
  %1365 = shufflevector <4 x double> %unmaskedload124, <4 x double> poison, <1 x i32> <i32 2>
  %1366 = shufflevector <4 x double> %unmaskedload124, <4 x double> poison, <1 x i32> <i32 3>
  %1367 = fmul <1 x double> %1362, %1363
  %1368 = fmul <1 x double> %1362, %1364
  %1369 = fmul <1 x double> %1362, %1365
  %1370 = shufflevector <1 x double> %1369, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1371 = fmul <1 x double> %1362, %1366
  %1372 = shufflevector <1 x double> %1371, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1373 = shufflevector <1 x double> %1367, <1 x double> %1368, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1374 = shufflevector <4 x double> %1373, <4 x double> %1370, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1375 = shufflevector <4 x double> %1374, <4 x double> %1372, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1376 = fadd <4 x double> %1357, %1375
  store <4 x double> %1376, ptr %1356, align 8
  %1377 = or disjoint i64 %1358, 1
  %exitcond.1.not.i.3 = icmp eq i64 %1377, 17
  br i1 %exitcond.1.not.i.3, label %.preheader.us.1.i.3.1, label %.critedge.us.1.i.3.1186

.critedge.us.1.i.3.1186:                          ; preds = %.critedge.us.1.i.3
  %1378 = mul nuw nsw i64 %1377, 65
  %1379 = getelementptr double, ptr %gep.i.3, i64 %1377
  %1380 = load double, ptr %1379, align 8
  %1381 = insertelement <1 x double> poison, double %1380, i64 0
  %gep.us.1.i.3.1184 = getelementptr double, ptr %514, i64 %1378
  %unmaskedload124.1 = load <4 x double>, ptr %gep.us.1.i.3.1184, align 8
  %1382 = shufflevector <4 x double> %unmaskedload124.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1383 = shufflevector <4 x double> %unmaskedload124.1, <4 x double> poison, <1 x i32> <i32 1>
  %1384 = shufflevector <4 x double> %unmaskedload124.1, <4 x double> poison, <1 x i32> <i32 2>
  %1385 = shufflevector <4 x double> %unmaskedload124.1, <4 x double> poison, <1 x i32> <i32 3>
  %1386 = fmul <1 x double> %1381, %1382
  %1387 = fmul <1 x double> %1381, %1383
  %1388 = fmul <1 x double> %1381, %1384
  %1389 = shufflevector <1 x double> %1388, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1390 = fmul <1 x double> %1381, %1385
  %1391 = shufflevector <1 x double> %1390, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1392 = shufflevector <1 x double> %1386, <1 x double> %1387, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1393 = shufflevector <4 x double> %1392, <4 x double> %1389, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1394 = shufflevector <4 x double> %1393, <4 x double> %1391, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1395 = fadd <4 x double> %1376, %1394
  store <4 x double> %1395, ptr %1356, align 8
  %1396 = add nuw nsw i64 %1358, 2
  br label %.critedge.us.1.i.3

.preheader.us.1.i.3.1:                            ; preds = %.critedge.us.1.i.3
  %1397 = getelementptr double, ptr %1356, i64 4
  %.promoted145 = load <4 x double>, ptr %1397, align 8
  br label %.critedge.us.1.i.3.1

.critedge.us.1.i.3.1:                             ; preds = %.critedge.us.1.i.3.1.1, %.preheader.us.1.i.3.1
  %1398 = phi <4 x double> [ %.promoted145, %.preheader.us.1.i.3.1 ], [ %1436, %.critedge.us.1.i.3.1.1 ]
  %1399 = phi i64 [ 0, %.preheader.us.1.i.3.1 ], [ %1437, %.critedge.us.1.i.3.1.1 ]
  %1400 = mul nuw nsw i64 %1399, 65
  %1401 = getelementptr double, ptr %gep.i.3, i64 %1399
  %1402 = load double, ptr %1401, align 8
  %1403 = insertelement <1 x double> poison, double %1402, i64 0
  %gep.us.1.i.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %1400
  %unmaskedload126 = load <4 x double>, ptr %gep.us.1.i.3.1, align 8
  %1404 = shufflevector <4 x double> %unmaskedload126, <4 x double> poison, <1 x i32> zeroinitializer
  %1405 = shufflevector <4 x double> %unmaskedload126, <4 x double> poison, <1 x i32> <i32 1>
  %1406 = shufflevector <4 x double> %unmaskedload126, <4 x double> poison, <1 x i32> <i32 2>
  %1407 = shufflevector <4 x double> %unmaskedload126, <4 x double> poison, <1 x i32> <i32 3>
  %1408 = fmul <1 x double> %1403, %1404
  %1409 = fmul <1 x double> %1403, %1405
  %1410 = fmul <1 x double> %1403, %1406
  %1411 = shufflevector <1 x double> %1410, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1412 = fmul <1 x double> %1403, %1407
  %1413 = shufflevector <1 x double> %1412, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1414 = shufflevector <1 x double> %1408, <1 x double> %1409, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1415 = shufflevector <4 x double> %1414, <4 x double> %1411, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1416 = shufflevector <4 x double> %1415, <4 x double> %1413, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1417 = fadd <4 x double> %1398, %1416
  store <4 x double> %1417, ptr %1397, align 8
  %1418 = or disjoint i64 %1399, 1
  %exitcond.1.not.i.3.1 = icmp eq i64 %1418, 17
  br i1 %exitcond.1.not.i.3.1, label %.preheader.us.1.i.3.2, label %.critedge.us.1.i.3.1.1

.critedge.us.1.i.3.1.1:                           ; preds = %.critedge.us.1.i.3.1
  %1419 = mul nuw nsw i64 %1418, 65
  %1420 = getelementptr double, ptr %gep.i.3, i64 %1418
  %1421 = load double, ptr %1420, align 8
  %1422 = insertelement <1 x double> poison, double %1421, i64 0
  %gep.us.1.i.3.1.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %1419
  %unmaskedload126.1 = load <4 x double>, ptr %gep.us.1.i.3.1.1, align 8
  %1423 = shufflevector <4 x double> %unmaskedload126.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1424 = shufflevector <4 x double> %unmaskedload126.1, <4 x double> poison, <1 x i32> <i32 1>
  %1425 = shufflevector <4 x double> %unmaskedload126.1, <4 x double> poison, <1 x i32> <i32 2>
  %1426 = shufflevector <4 x double> %unmaskedload126.1, <4 x double> poison, <1 x i32> <i32 3>
  %1427 = fmul <1 x double> %1422, %1423
  %1428 = fmul <1 x double> %1422, %1424
  %1429 = fmul <1 x double> %1422, %1425
  %1430 = shufflevector <1 x double> %1429, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1431 = fmul <1 x double> %1422, %1426
  %1432 = shufflevector <1 x double> %1431, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1433 = shufflevector <1 x double> %1427, <1 x double> %1428, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1434 = shufflevector <4 x double> %1433, <4 x double> %1430, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1435 = shufflevector <4 x double> %1434, <4 x double> %1432, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1436 = fadd <4 x double> %1417, %1435
  store <4 x double> %1436, ptr %1397, align 8
  %1437 = add nuw nsw i64 %1399, 2
  br label %.critedge.us.1.i.3.1

.preheader.us.1.i.3.2:                            ; preds = %.critedge.us.1.i.3.1
  %1438 = getelementptr double, ptr %1356, i64 8
  %.promoted144 = load <4 x double>, ptr %1438, align 8
  br label %.critedge.us.1.i.3.2

.critedge.us.1.i.3.2:                             ; preds = %.critedge.us.1.i.3.2.1, %.preheader.us.1.i.3.2
  %1439 = phi <4 x double> [ %.promoted144, %.preheader.us.1.i.3.2 ], [ %1477, %.critedge.us.1.i.3.2.1 ]
  %1440 = phi i64 [ 0, %.preheader.us.1.i.3.2 ], [ %1478, %.critedge.us.1.i.3.2.1 ]
  %1441 = mul nuw nsw i64 %1440, 65
  %1442 = getelementptr double, ptr %gep.i.3, i64 %1440
  %1443 = load double, ptr %1442, align 8
  %1444 = insertelement <1 x double> poison, double %1443, i64 0
  %gep.us.1.i.3.2 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %1441
  %unmaskedload128 = load <4 x double>, ptr %gep.us.1.i.3.2, align 8
  %1445 = shufflevector <4 x double> %unmaskedload128, <4 x double> poison, <1 x i32> zeroinitializer
  %1446 = shufflevector <4 x double> %unmaskedload128, <4 x double> poison, <1 x i32> <i32 1>
  %1447 = shufflevector <4 x double> %unmaskedload128, <4 x double> poison, <1 x i32> <i32 2>
  %1448 = shufflevector <4 x double> %unmaskedload128, <4 x double> poison, <1 x i32> <i32 3>
  %1449 = fmul <1 x double> %1444, %1445
  %1450 = fmul <1 x double> %1444, %1446
  %1451 = fmul <1 x double> %1444, %1447
  %1452 = shufflevector <1 x double> %1451, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1453 = fmul <1 x double> %1444, %1448
  %1454 = shufflevector <1 x double> %1453, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1455 = shufflevector <1 x double> %1449, <1 x double> %1450, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1456 = shufflevector <4 x double> %1455, <4 x double> %1452, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1457 = shufflevector <4 x double> %1456, <4 x double> %1454, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1458 = fadd <4 x double> %1439, %1457
  store <4 x double> %1458, ptr %1438, align 8
  %1459 = or disjoint i64 %1440, 1
  %exitcond.1.not.i.3.2 = icmp eq i64 %1459, 17
  br i1 %exitcond.1.not.i.3.2, label %.preheader.us.1.i.3.3, label %.critedge.us.1.i.3.2.1

.critedge.us.1.i.3.2.1:                           ; preds = %.critedge.us.1.i.3.2
  %1460 = mul nuw nsw i64 %1459, 65
  %1461 = getelementptr double, ptr %gep.i.3, i64 %1459
  %1462 = load double, ptr %1461, align 8
  %1463 = insertelement <1 x double> poison, double %1462, i64 0
  %gep.us.1.i.3.2.1 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %1460
  %unmaskedload128.1 = load <4 x double>, ptr %gep.us.1.i.3.2.1, align 8
  %1464 = shufflevector <4 x double> %unmaskedload128.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1465 = shufflevector <4 x double> %unmaskedload128.1, <4 x double> poison, <1 x i32> <i32 1>
  %1466 = shufflevector <4 x double> %unmaskedload128.1, <4 x double> poison, <1 x i32> <i32 2>
  %1467 = shufflevector <4 x double> %unmaskedload128.1, <4 x double> poison, <1 x i32> <i32 3>
  %1468 = fmul <1 x double> %1463, %1464
  %1469 = fmul <1 x double> %1463, %1465
  %1470 = fmul <1 x double> %1463, %1466
  %1471 = shufflevector <1 x double> %1470, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1472 = fmul <1 x double> %1463, %1467
  %1473 = shufflevector <1 x double> %1472, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1474 = shufflevector <1 x double> %1468, <1 x double> %1469, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1475 = shufflevector <4 x double> %1474, <4 x double> %1471, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1476 = shufflevector <4 x double> %1475, <4 x double> %1473, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1477 = fadd <4 x double> %1458, %1476
  store <4 x double> %1477, ptr %1438, align 8
  %1478 = add nuw nsw i64 %1440, 2
  br label %.critedge.us.1.i.3.2

.preheader.us.1.i.3.3:                            ; preds = %.critedge.us.1.i.3.2
  %1479 = getelementptr double, ptr %1356, i64 12
  %.promoted143 = load <4 x double>, ptr %1479, align 8
  br label %.critedge.us.1.i.3.3

.critedge.us.1.i.3.3:                             ; preds = %.critedge.us.1.i.3.3.1, %.preheader.us.1.i.3.3
  %1480 = phi <4 x double> [ %.promoted143, %.preheader.us.1.i.3.3 ], [ %1518, %.critedge.us.1.i.3.3.1 ]
  %1481 = phi i64 [ 0, %.preheader.us.1.i.3.3 ], [ %1519, %.critedge.us.1.i.3.3.1 ]
  %1482 = mul nuw nsw i64 %1481, 65
  %1483 = getelementptr double, ptr %gep.i.3, i64 %1481
  %1484 = load double, ptr %1483, align 8
  %1485 = insertelement <1 x double> poison, double %1484, i64 0
  %gep.us.1.i.3.3 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %1482
  %unmaskedload130 = load <4 x double>, ptr %gep.us.1.i.3.3, align 8
  %1486 = shufflevector <4 x double> %unmaskedload130, <4 x double> poison, <1 x i32> zeroinitializer
  %1487 = shufflevector <4 x double> %unmaskedload130, <4 x double> poison, <1 x i32> <i32 1>
  %1488 = shufflevector <4 x double> %unmaskedload130, <4 x double> poison, <1 x i32> <i32 2>
  %1489 = shufflevector <4 x double> %unmaskedload130, <4 x double> poison, <1 x i32> <i32 3>
  %1490 = fmul <1 x double> %1485, %1486
  %1491 = fmul <1 x double> %1485, %1487
  %1492 = fmul <1 x double> %1485, %1488
  %1493 = shufflevector <1 x double> %1492, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1494 = fmul <1 x double> %1485, %1489
  %1495 = shufflevector <1 x double> %1494, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1496 = shufflevector <1 x double> %1490, <1 x double> %1491, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1497 = shufflevector <4 x double> %1496, <4 x double> %1493, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1498 = shufflevector <4 x double> %1497, <4 x double> %1495, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1499 = fadd <4 x double> %1480, %1498
  store <4 x double> %1499, ptr %1479, align 8
  %1500 = or disjoint i64 %1481, 1
  %exitcond.1.not.i.3.3 = icmp eq i64 %1500, 17
  br i1 %exitcond.1.not.i.3.3, label %._crit_edge.us.1.i.3, label %.critedge.us.1.i.3.3.1

.critedge.us.1.i.3.3.1:                           ; preds = %.critedge.us.1.i.3.3
  %1501 = mul nuw nsw i64 %1500, 65
  %1502 = getelementptr double, ptr %gep.i.3, i64 %1500
  %1503 = load double, ptr %1502, align 8
  %1504 = insertelement <1 x double> poison, double %1503, i64 0
  %gep.us.1.i.3.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %1501
  %unmaskedload130.1 = load <4 x double>, ptr %gep.us.1.i.3.3.1, align 8
  %1505 = shufflevector <4 x double> %unmaskedload130.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1506 = shufflevector <4 x double> %unmaskedload130.1, <4 x double> poison, <1 x i32> <i32 1>
  %1507 = shufflevector <4 x double> %unmaskedload130.1, <4 x double> poison, <1 x i32> <i32 2>
  %1508 = shufflevector <4 x double> %unmaskedload130.1, <4 x double> poison, <1 x i32> <i32 3>
  %1509 = fmul <1 x double> %1504, %1505
  %1510 = fmul <1 x double> %1504, %1506
  %1511 = fmul <1 x double> %1504, %1507
  %1512 = shufflevector <1 x double> %1511, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1513 = fmul <1 x double> %1504, %1508
  %1514 = shufflevector <1 x double> %1513, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1515 = shufflevector <1 x double> %1509, <1 x double> %1510, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1516 = shufflevector <4 x double> %1515, <4 x double> %1512, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1517 = shufflevector <4 x double> %1516, <4 x double> %1514, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1518 = fadd <4 x double> %1499, %1517
  store <4 x double> %1518, ptr %1479, align 8
  %1519 = add nuw nsw i64 %1481, 2
  br label %.critedge.us.1.i.3.3

._crit_edge.us.1.i.3:                             ; preds = %.critedge.us.1.i.3.3
  %1520 = add nuw nsw i64 %1353, 1
  %exitcond22.1.not.i.3 = icmp eq i64 %1520, 15
  br i1 %exitcond22.1.not.i.3, label %.split20.us.1.i.3, label %.preheader16.us.1.i.3

.split20.us.1.i.3:                                ; preds = %._crit_edge.us.1.i.3
  %1521 = getelementptr double, ptr %.unpack32, i64 1104
  %gep.us.1.i.4.1 = getelementptr double, ptr %.unpack17, i64 129
  %gep.us.1.i.4.2 = getelementptr double, ptr %.unpack17, i64 194
  %gep.us.1.i.4.3 = getelementptr double, ptr %.unpack17, i64 259
  %gep.us.1.i.4.4 = getelementptr double, ptr %.unpack17, i64 324
  %gep.us.1.i.4.5 = getelementptr double, ptr %.unpack17, i64 389
  %gep.us.1.i.4.6 = getelementptr double, ptr %.unpack17, i64 454
  %gep.us.1.i.4.7 = getelementptr double, ptr %.unpack17, i64 519
  %gep.us.1.i.4.8 = getelementptr double, ptr %.unpack17, i64 584
  %gep.us.1.i.4.9 = getelementptr double, ptr %.unpack17, i64 649
  %gep.us.1.i.4.10 = getelementptr double, ptr %.unpack17, i64 714
  %gep.us.1.i.4.11 = getelementptr double, ptr %.unpack17, i64 779
  %gep.us.1.i.4.12 = getelementptr double, ptr %.unpack17, i64 844
  %gep.us.1.i.4.13 = getelementptr double, ptr %.unpack17, i64 909
  %gep.us.1.i.4.14 = getelementptr double, ptr %.unpack17, i64 974
  %gep.us.1.i.4.15 = getelementptr double, ptr %.unpack17, i64 1039
  %gep.us.1.i.4.16 = getelementptr double, ptr %.unpack17, i64 1104
  br label %.preheader16.us.1.i.4

.preheader16.us.1.i.4:                            ; preds = %.preheader16.us.1.i.4, %.split20.us.1.i.3
  %1522 = phi i64 [ %1678, %.preheader16.us.1.i.4 ], [ 0, %.split20.us.1.i.3 ]
  %1523 = mul nuw nsw i64 %1522, 65
  %1524 = getelementptr double, ptr %1521, i64 %1523
  %1525 = mul nuw nsw i64 %1522, 17
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %1525
  %1526 = load double, ptr %gep.i.4, align 8
  %1527 = insertelement <1 x double> poison, double %1526, i64 0
  %1528 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %685, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1529 = shufflevector <4 x double> %1528, <4 x double> poison, <1 x i32> zeroinitializer
  %1530 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1531 = fmul <1 x double> %1527, %1529
  %1532 = shufflevector <1 x double> %1531, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1533 = fadd <4 x double> %1530, %1532
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1533, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1534 = getelementptr double, ptr %gep.i.4, i64 1
  %1535 = load double, ptr %1534, align 8
  %1536 = insertelement <1 x double> poison, double %1535, i64 0
  %1537 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.1, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1538 = shufflevector <4 x double> %1537, <4 x double> poison, <1 x i32> zeroinitializer
  %1539 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1540 = fmul <1 x double> %1536, %1538
  %1541 = shufflevector <1 x double> %1540, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1542 = fadd <4 x double> %1539, %1541
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1542, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1543 = getelementptr double, ptr %gep.i.4, i64 2
  %1544 = load double, ptr %1543, align 8
  %1545 = insertelement <1 x double> poison, double %1544, i64 0
  %1546 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.2, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1547 = shufflevector <4 x double> %1546, <4 x double> poison, <1 x i32> zeroinitializer
  %1548 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1549 = fmul <1 x double> %1545, %1547
  %1550 = shufflevector <1 x double> %1549, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1551 = fadd <4 x double> %1548, %1550
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1551, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1552 = getelementptr double, ptr %gep.i.4, i64 3
  %1553 = load double, ptr %1552, align 8
  %1554 = insertelement <1 x double> poison, double %1553, i64 0
  %1555 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.3, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1556 = shufflevector <4 x double> %1555, <4 x double> poison, <1 x i32> zeroinitializer
  %1557 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1558 = fmul <1 x double> %1554, %1556
  %1559 = shufflevector <1 x double> %1558, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1560 = fadd <4 x double> %1557, %1559
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1560, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1561 = getelementptr double, ptr %gep.i.4, i64 4
  %1562 = load double, ptr %1561, align 8
  %1563 = insertelement <1 x double> poison, double %1562, i64 0
  %1564 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.4, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1565 = shufflevector <4 x double> %1564, <4 x double> poison, <1 x i32> zeroinitializer
  %1566 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1567 = fmul <1 x double> %1563, %1565
  %1568 = shufflevector <1 x double> %1567, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1569 = fadd <4 x double> %1566, %1568
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1569, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1570 = getelementptr double, ptr %gep.i.4, i64 5
  %1571 = load double, ptr %1570, align 8
  %1572 = insertelement <1 x double> poison, double %1571, i64 0
  %1573 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.5, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1574 = shufflevector <4 x double> %1573, <4 x double> poison, <1 x i32> zeroinitializer
  %1575 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1576 = fmul <1 x double> %1572, %1574
  %1577 = shufflevector <1 x double> %1576, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1578 = fadd <4 x double> %1575, %1577
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1578, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1579 = getelementptr double, ptr %gep.i.4, i64 6
  %1580 = load double, ptr %1579, align 8
  %1581 = insertelement <1 x double> poison, double %1580, i64 0
  %1582 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.6, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1583 = shufflevector <4 x double> %1582, <4 x double> poison, <1 x i32> zeroinitializer
  %1584 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1585 = fmul <1 x double> %1581, %1583
  %1586 = shufflevector <1 x double> %1585, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1587 = fadd <4 x double> %1584, %1586
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1587, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1588 = getelementptr double, ptr %gep.i.4, i64 7
  %1589 = load double, ptr %1588, align 8
  %1590 = insertelement <1 x double> poison, double %1589, i64 0
  %1591 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.7, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1592 = shufflevector <4 x double> %1591, <4 x double> poison, <1 x i32> zeroinitializer
  %1593 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1594 = fmul <1 x double> %1590, %1592
  %1595 = shufflevector <1 x double> %1594, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1596 = fadd <4 x double> %1593, %1595
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1596, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1597 = getelementptr double, ptr %gep.i.4, i64 8
  %1598 = load double, ptr %1597, align 8
  %1599 = insertelement <1 x double> poison, double %1598, i64 0
  %1600 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.8, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1601 = shufflevector <4 x double> %1600, <4 x double> poison, <1 x i32> zeroinitializer
  %1602 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1603 = fmul <1 x double> %1599, %1601
  %1604 = shufflevector <1 x double> %1603, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1605 = fadd <4 x double> %1602, %1604
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1605, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1606 = getelementptr double, ptr %gep.i.4, i64 9
  %1607 = load double, ptr %1606, align 8
  %1608 = insertelement <1 x double> poison, double %1607, i64 0
  %1609 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.9, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1610 = shufflevector <4 x double> %1609, <4 x double> poison, <1 x i32> zeroinitializer
  %1611 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1612 = fmul <1 x double> %1608, %1610
  %1613 = shufflevector <1 x double> %1612, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1614 = fadd <4 x double> %1611, %1613
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1614, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1615 = getelementptr double, ptr %gep.i.4, i64 10
  %1616 = load double, ptr %1615, align 8
  %1617 = insertelement <1 x double> poison, double %1616, i64 0
  %1618 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.10, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1619 = shufflevector <4 x double> %1618, <4 x double> poison, <1 x i32> zeroinitializer
  %1620 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1621 = fmul <1 x double> %1617, %1619
  %1622 = shufflevector <1 x double> %1621, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1623 = fadd <4 x double> %1620, %1622
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1623, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1624 = getelementptr double, ptr %gep.i.4, i64 11
  %1625 = load double, ptr %1624, align 8
  %1626 = insertelement <1 x double> poison, double %1625, i64 0
  %1627 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.11, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1628 = shufflevector <4 x double> %1627, <4 x double> poison, <1 x i32> zeroinitializer
  %1629 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1630 = fmul <1 x double> %1626, %1628
  %1631 = shufflevector <1 x double> %1630, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1632 = fadd <4 x double> %1629, %1631
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1632, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1633 = getelementptr double, ptr %gep.i.4, i64 12
  %1634 = load double, ptr %1633, align 8
  %1635 = insertelement <1 x double> poison, double %1634, i64 0
  %1636 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.12, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1637 = shufflevector <4 x double> %1636, <4 x double> poison, <1 x i32> zeroinitializer
  %1638 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1639 = fmul <1 x double> %1635, %1637
  %1640 = shufflevector <1 x double> %1639, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1641 = fadd <4 x double> %1638, %1640
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1641, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1642 = getelementptr double, ptr %gep.i.4, i64 13
  %1643 = load double, ptr %1642, align 8
  %1644 = insertelement <1 x double> poison, double %1643, i64 0
  %1645 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.13, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1646 = shufflevector <4 x double> %1645, <4 x double> poison, <1 x i32> zeroinitializer
  %1647 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1648 = fmul <1 x double> %1644, %1646
  %1649 = shufflevector <1 x double> %1648, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1650 = fadd <4 x double> %1647, %1649
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1650, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1651 = getelementptr double, ptr %gep.i.4, i64 14
  %1652 = load double, ptr %1651, align 8
  %1653 = insertelement <1 x double> poison, double %1652, i64 0
  %1654 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.14, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1655 = shufflevector <4 x double> %1654, <4 x double> poison, <1 x i32> zeroinitializer
  %1656 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1657 = fmul <1 x double> %1653, %1655
  %1658 = shufflevector <1 x double> %1657, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1659 = fadd <4 x double> %1656, %1658
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1659, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1660 = getelementptr double, ptr %gep.i.4, i64 15
  %1661 = load double, ptr %1660, align 8
  %1662 = insertelement <1 x double> poison, double %1661, i64 0
  %1663 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.15, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1664 = shufflevector <4 x double> %1663, <4 x double> poison, <1 x i32> zeroinitializer
  %1665 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1666 = fmul <1 x double> %1662, %1664
  %1667 = shufflevector <1 x double> %1666, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1668 = fadd <4 x double> %1665, %1667
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1668, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1669 = getelementptr double, ptr %gep.i.4, i64 16
  %1670 = load double, ptr %1669, align 8
  %1671 = insertelement <1 x double> poison, double %1670, i64 0
  %1672 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.16, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1673 = shufflevector <4 x double> %1672, <4 x double> poison, <1 x i32> zeroinitializer
  %1674 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1675 = fmul <1 x double> %1671, %1673
  %1676 = shufflevector <1 x double> %1675, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1677 = fadd <4 x double> %1674, %1676
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1677, ptr %1524, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1678 = add nuw nsw i64 %1522, 1
  %exitcond22.1.not.i.4 = icmp eq i64 %1678, 15
  br i1 %exitcond22.1.not.i.4, label %.split20.us.1.i.4, label %.preheader16.us.1.i.4

.split20.us.1.i.4:                                ; preds = %.preheader16.us.1.i.4
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
.preheader16.us.preheader.i:
  %1 = getelementptr ptr, ptr %0, i64 1
  %2 = load ptr, ptr %1, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 15
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %9, i8 0, i64 16120, i1 false)
  %invariant.gep.us.i.1 = getelementptr double, ptr %6, i64 4
  %invariant.gep.us.i.2 = getelementptr double, ptr %6, i64 8
  %invariant.gep.us.i.3 = getelementptr double, ptr %6, i64 12
  br label %.preheader16.us.i

.preheader16.us.i:                                ; preds = %._crit_edge.us.i, %.preheader16.us.preheader.i
  %10 = phi i64 [ %138, %._crit_edge.us.i ], [ 0, %.preheader16.us.preheader.i ]
  %11 = mul nuw nsw i64 %10, 17
  %12 = mul nuw nsw i64 %10, 65
  %13 = getelementptr double, ptr %3, i64 %11
  %14 = getelementptr double, ptr %9, i64 %12
  %.promoted106 = load <4 x double>, ptr %14, align 8
  br label %.critedge.us.i

.preheader.us.i.11:                               ; preds = %.critedge.us.i
  %15 = getelementptr double, ptr %14, i64 4
  %.promoted105 = load <4 x double>, ptr %15, align 8
  br label %.critedge.us.i.14

.critedge.us.i.14:                                ; preds = %.critedge.us.i.14.1, %.preheader.us.i.11
  %16 = phi <4 x double> [ %.promoted105, %.preheader.us.i.11 ], [ %54, %.critedge.us.i.14.1 ]
  %17 = phi i64 [ 0, %.preheader.us.i.11 ], [ %55, %.critedge.us.i.14.1 ]
  %18 = mul nuw nsw i64 %17, 65
  %19 = getelementptr double, ptr %13, i64 %17
  %20 = load double, ptr %19, align 8
  %21 = insertelement <1 x double> poison, double %20, i64 0
  %gep.us.i.12 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %18
  %unmaskedload26 = load <4 x double>, ptr %gep.us.i.12, align 8
  %22 = shufflevector <4 x double> %unmaskedload26, <4 x double> poison, <1 x i32> zeroinitializer
  %23 = shufflevector <4 x double> %unmaskedload26, <4 x double> poison, <1 x i32> <i32 1>
  %24 = shufflevector <4 x double> %unmaskedload26, <4 x double> poison, <1 x i32> <i32 2>
  %25 = shufflevector <4 x double> %unmaskedload26, <4 x double> poison, <1 x i32> <i32 3>
  %26 = fmul <1 x double> %21, %22
  %27 = fmul <1 x double> %21, %23
  %28 = fmul <1 x double> %21, %24
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = fmul <1 x double> %21, %25
  %31 = shufflevector <1 x double> %30, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = shufflevector <1 x double> %26, <1 x double> %27, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = fadd <4 x double> %16, %34
  store <4 x double> %35, ptr %15, align 8
  %36 = or disjoint i64 %17, 1
  %exitcond.not.i.13 = icmp eq i64 %36, 17
  br i1 %exitcond.not.i.13, label %.preheader.us.i.25, label %.critedge.us.i.14.1

.critedge.us.i.14.1:                              ; preds = %.critedge.us.i.14
  %37 = mul nuw nsw i64 %36, 65
  %38 = getelementptr double, ptr %13, i64 %36
  %39 = load double, ptr %38, align 8
  %40 = insertelement <1 x double> poison, double %39, i64 0
  %gep.us.i.12.1 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %37
  %unmaskedload26.1 = load <4 x double>, ptr %gep.us.i.12.1, align 8
  %41 = shufflevector <4 x double> %unmaskedload26.1, <4 x double> poison, <1 x i32> zeroinitializer
  %42 = shufflevector <4 x double> %unmaskedload26.1, <4 x double> poison, <1 x i32> <i32 1>
  %43 = shufflevector <4 x double> %unmaskedload26.1, <4 x double> poison, <1 x i32> <i32 2>
  %44 = shufflevector <4 x double> %unmaskedload26.1, <4 x double> poison, <1 x i32> <i32 3>
  %45 = fmul <1 x double> %40, %41
  %46 = fmul <1 x double> %40, %42
  %47 = fmul <1 x double> %40, %43
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = fmul <1 x double> %40, %44
  %50 = shufflevector <1 x double> %49, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %51 = shufflevector <1 x double> %45, <1 x double> %46, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %50, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %54 = fadd <4 x double> %35, %53
  store <4 x double> %54, ptr %15, align 8
  %55 = add nuw nsw i64 %17, 2
  br label %.critedge.us.i.14

.preheader.us.i.25:                               ; preds = %.critedge.us.i.14
  %56 = getelementptr double, ptr %14, i64 8
  %.promoted104 = load <4 x double>, ptr %56, align 8
  br label %.critedge.us.i.28

.critedge.us.i.28:                                ; preds = %.critedge.us.i.28.1, %.preheader.us.i.25
  %57 = phi <4 x double> [ %.promoted104, %.preheader.us.i.25 ], [ %95, %.critedge.us.i.28.1 ]
  %58 = phi i64 [ 0, %.preheader.us.i.25 ], [ %96, %.critedge.us.i.28.1 ]
  %59 = mul nuw nsw i64 %58, 65
  %60 = getelementptr double, ptr %13, i64 %58
  %61 = load double, ptr %60, align 8
  %62 = insertelement <1 x double> poison, double %61, i64 0
  %gep.us.i.26 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %59
  %unmaskedload28 = load <4 x double>, ptr %gep.us.i.26, align 8
  %63 = shufflevector <4 x double> %unmaskedload28, <4 x double> poison, <1 x i32> zeroinitializer
  %64 = shufflevector <4 x double> %unmaskedload28, <4 x double> poison, <1 x i32> <i32 1>
  %65 = shufflevector <4 x double> %unmaskedload28, <4 x double> poison, <1 x i32> <i32 2>
  %66 = shufflevector <4 x double> %unmaskedload28, <4 x double> poison, <1 x i32> <i32 3>
  %67 = fmul <1 x double> %62, %63
  %68 = fmul <1 x double> %62, %64
  %69 = fmul <1 x double> %62, %65
  %70 = shufflevector <1 x double> %69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %71 = fmul <1 x double> %62, %66
  %72 = shufflevector <1 x double> %71, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = shufflevector <1 x double> %67, <1 x double> %68, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %74 = shufflevector <4 x double> %73, <4 x double> %70, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %75 = shufflevector <4 x double> %74, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %76 = fadd <4 x double> %57, %75
  store <4 x double> %76, ptr %56, align 8
  %77 = or disjoint i64 %58, 1
  %exitcond.not.i.27 = icmp eq i64 %77, 17
  br i1 %exitcond.not.i.27, label %.preheader.us.i.39, label %.critedge.us.i.28.1

.critedge.us.i.28.1:                              ; preds = %.critedge.us.i.28
  %78 = mul nuw nsw i64 %77, 65
  %79 = getelementptr double, ptr %13, i64 %77
  %80 = load double, ptr %79, align 8
  %81 = insertelement <1 x double> poison, double %80, i64 0
  %gep.us.i.26.1 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %78
  %unmaskedload28.1 = load <4 x double>, ptr %gep.us.i.26.1, align 8
  %82 = shufflevector <4 x double> %unmaskedload28.1, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %unmaskedload28.1, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %unmaskedload28.1, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %unmaskedload28.1, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %81, %82
  %87 = fmul <1 x double> %81, %83
  %88 = fmul <1 x double> %81, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %81, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %56, align 8
  %96 = add nuw nsw i64 %58, 2
  br label %.critedge.us.i.28

.preheader.us.i.39:                               ; preds = %.critedge.us.i.28
  %97 = getelementptr double, ptr %14, i64 12
  %.promoted103 = load <4 x double>, ptr %97, align 8
  br label %.critedge.us.i.312

.critedge.us.i.312:                               ; preds = %.critedge.us.i.312.1, %.preheader.us.i.39
  %98 = phi <4 x double> [ %.promoted103, %.preheader.us.i.39 ], [ %136, %.critedge.us.i.312.1 ]
  %99 = phi i64 [ 0, %.preheader.us.i.39 ], [ %137, %.critedge.us.i.312.1 ]
  %100 = mul nuw nsw i64 %99, 65
  %101 = getelementptr double, ptr %13, i64 %99
  %102 = load double, ptr %101, align 8
  %103 = insertelement <1 x double> poison, double %102, i64 0
  %gep.us.i.310 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %100
  %unmaskedload30 = load <4 x double>, ptr %gep.us.i.310, align 8
  %104 = shufflevector <4 x double> %unmaskedload30, <4 x double> poison, <1 x i32> zeroinitializer
  %105 = shufflevector <4 x double> %unmaskedload30, <4 x double> poison, <1 x i32> <i32 1>
  %106 = shufflevector <4 x double> %unmaskedload30, <4 x double> poison, <1 x i32> <i32 2>
  %107 = shufflevector <4 x double> %unmaskedload30, <4 x double> poison, <1 x i32> <i32 3>
  %108 = fmul <1 x double> %103, %104
  %109 = fmul <1 x double> %103, %105
  %110 = fmul <1 x double> %103, %106
  %111 = shufflevector <1 x double> %110, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %112 = fmul <1 x double> %103, %107
  %113 = shufflevector <1 x double> %112, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %114 = shufflevector <1 x double> %108, <1 x double> %109, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %115 = shufflevector <4 x double> %114, <4 x double> %111, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %116 = shufflevector <4 x double> %115, <4 x double> %113, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %117 = fadd <4 x double> %98, %116
  store <4 x double> %117, ptr %97, align 8
  %118 = or disjoint i64 %99, 1
  %exitcond.not.i.311 = icmp eq i64 %118, 17
  br i1 %exitcond.not.i.311, label %._crit_edge.us.i, label %.critedge.us.i.312.1

.critedge.us.i.312.1:                             ; preds = %.critedge.us.i.312
  %119 = mul nuw nsw i64 %118, 65
  %120 = getelementptr double, ptr %13, i64 %118
  %121 = load double, ptr %120, align 8
  %122 = insertelement <1 x double> poison, double %121, i64 0
  %gep.us.i.310.1 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %119
  %unmaskedload30.1 = load <4 x double>, ptr %gep.us.i.310.1, align 8
  %123 = shufflevector <4 x double> %unmaskedload30.1, <4 x double> poison, <1 x i32> zeroinitializer
  %124 = shufflevector <4 x double> %unmaskedload30.1, <4 x double> poison, <1 x i32> <i32 1>
  %125 = shufflevector <4 x double> %unmaskedload30.1, <4 x double> poison, <1 x i32> <i32 2>
  %126 = shufflevector <4 x double> %unmaskedload30.1, <4 x double> poison, <1 x i32> <i32 3>
  %127 = fmul <1 x double> %122, %123
  %128 = fmul <1 x double> %122, %124
  %129 = fmul <1 x double> %122, %125
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = fmul <1 x double> %122, %126
  %132 = shufflevector <1 x double> %131, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %133 = shufflevector <1 x double> %127, <1 x double> %128, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %135 = shufflevector <4 x double> %134, <4 x double> %132, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %136 = fadd <4 x double> %117, %135
  store <4 x double> %136, ptr %97, align 8
  %137 = add nuw nsw i64 %99, 2
  br label %.critedge.us.i.312

._crit_edge.us.i:                                 ; preds = %.critedge.us.i.312
  %138 = add nuw nsw i64 %10, 1
  %exitcond22.not.i = icmp eq i64 %138, 16
  br i1 %exitcond22.not.i, label %.split20.us.i, label %.preheader16.us.i

.critedge.us.i:                                   ; preds = %.critedge.us.i.1121, %.preheader16.us.i
  %139 = phi <4 x double> [ %.promoted106, %.preheader16.us.i ], [ %177, %.critedge.us.i.1121 ]
  %140 = phi i64 [ 0, %.preheader16.us.i ], [ %178, %.critedge.us.i.1121 ]
  %141 = mul nuw nsw i64 %140, 65
  %142 = getelementptr double, ptr %13, i64 %140
  %143 = load double, ptr %142, align 8
  %144 = insertelement <1 x double> poison, double %143, i64 0
  %gep.us.i = getelementptr double, ptr %6, i64 %141
  %unmaskedload = load <4 x double>, ptr %gep.us.i, align 8
  %145 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %146 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %147 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %148 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %149 = fmul <1 x double> %144, %145
  %150 = fmul <1 x double> %144, %146
  %151 = fmul <1 x double> %144, %147
  %152 = shufflevector <1 x double> %151, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %153 = fmul <1 x double> %144, %148
  %154 = shufflevector <1 x double> %153, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %155 = shufflevector <1 x double> %149, <1 x double> %150, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %156 = shufflevector <4 x double> %155, <4 x double> %152, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %157 = shufflevector <4 x double> %156, <4 x double> %154, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %158 = fadd <4 x double> %139, %157
  store <4 x double> %158, ptr %14, align 8
  %159 = or disjoint i64 %140, 1
  %exitcond.not.i = icmp eq i64 %159, 17
  br i1 %exitcond.not.i, label %.preheader.us.i.11, label %.critedge.us.i.1121

.critedge.us.i.1121:                              ; preds = %.critedge.us.i
  %160 = mul nuw nsw i64 %159, 65
  %161 = getelementptr double, ptr %13, i64 %159
  %162 = load double, ptr %161, align 8
  %163 = insertelement <1 x double> poison, double %162, i64 0
  %gep.us.i.1119 = getelementptr double, ptr %6, i64 %160
  %unmaskedload.1 = load <4 x double>, ptr %gep.us.i.1119, align 8
  %164 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> zeroinitializer
  %165 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 1>
  %166 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 2>
  %167 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 3>
  %168 = fmul <1 x double> %163, %164
  %169 = fmul <1 x double> %163, %165
  %170 = fmul <1 x double> %163, %166
  %171 = shufflevector <1 x double> %170, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %172 = fmul <1 x double> %163, %167
  %173 = shufflevector <1 x double> %172, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %174 = shufflevector <1 x double> %168, <1 x double> %169, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %175 = shufflevector <4 x double> %174, <4 x double> %171, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %176 = shufflevector <4 x double> %175, <4 x double> %173, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %177 = fadd <4 x double> %158, %176
  store <4 x double> %177, ptr %14, align 8
  %178 = add nuw nsw i64 %140, 2
  br label %.critedge.us.i

.split20.us.i:                                    ; preds = %._crit_edge.us.i
  %179 = getelementptr double, ptr %6, i64 16
  %180 = getelementptr double, ptr %9, i64 16
  %invariant.gep.us.i.1.1 = getelementptr double, ptr %6, i64 20
  %invariant.gep.us.i.1.2 = getelementptr double, ptr %6, i64 24
  %invariant.gep.us.i.1.3 = getelementptr double, ptr %6, i64 28
  br label %.preheader16.us.i.1

.preheader16.us.i.1:                              ; preds = %._crit_edge.us.i.1, %.split20.us.i
  %181 = phi i64 [ %349, %._crit_edge.us.i.1 ], [ 0, %.split20.us.i ]
  %182 = mul nuw nsw i64 %181, 17
  %183 = mul nuw nsw i64 %181, 65
  %184 = getelementptr double, ptr %3, i64 %182
  %185 = getelementptr double, ptr %180, i64 %183
  %.promoted110 = load <4 x double>, ptr %185, align 8
  br label %.critedge.us.i.1

.critedge.us.i.1:                                 ; preds = %.critedge.us.i.1.1124, %.preheader16.us.i.1
  %186 = phi <4 x double> [ %.promoted110, %.preheader16.us.i.1 ], [ %224, %.critedge.us.i.1.1124 ]
  %187 = phi i64 [ 0, %.preheader16.us.i.1 ], [ %225, %.critedge.us.i.1.1124 ]
  %188 = mul nuw nsw i64 %187, 65
  %189 = getelementptr double, ptr %184, i64 %187
  %190 = load double, ptr %189, align 8
  %191 = insertelement <1 x double> poison, double %190, i64 0
  %gep.us.i.1 = getelementptr double, ptr %179, i64 %188
  %unmaskedload32 = load <4 x double>, ptr %gep.us.i.1, align 8
  %192 = shufflevector <4 x double> %unmaskedload32, <4 x double> poison, <1 x i32> zeroinitializer
  %193 = shufflevector <4 x double> %unmaskedload32, <4 x double> poison, <1 x i32> <i32 1>
  %194 = shufflevector <4 x double> %unmaskedload32, <4 x double> poison, <1 x i32> <i32 2>
  %195 = shufflevector <4 x double> %unmaskedload32, <4 x double> poison, <1 x i32> <i32 3>
  %196 = fmul <1 x double> %191, %192
  %197 = fmul <1 x double> %191, %193
  %198 = fmul <1 x double> %191, %194
  %199 = shufflevector <1 x double> %198, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %200 = fmul <1 x double> %191, %195
  %201 = shufflevector <1 x double> %200, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %202 = shufflevector <1 x double> %196, <1 x double> %197, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %203 = shufflevector <4 x double> %202, <4 x double> %199, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %204 = shufflevector <4 x double> %203, <4 x double> %201, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %205 = fadd <4 x double> %186, %204
  store <4 x double> %205, ptr %185, align 8
  %206 = or disjoint i64 %187, 1
  %exitcond.not.i.1 = icmp eq i64 %206, 17
  br i1 %exitcond.not.i.1, label %.preheader.us.i.1.1, label %.critedge.us.i.1.1124

.critedge.us.i.1.1124:                            ; preds = %.critedge.us.i.1
  %207 = mul nuw nsw i64 %206, 65
  %208 = getelementptr double, ptr %184, i64 %206
  %209 = load double, ptr %208, align 8
  %210 = insertelement <1 x double> poison, double %209, i64 0
  %gep.us.i.1.1122 = getelementptr double, ptr %179, i64 %207
  %unmaskedload32.1 = load <4 x double>, ptr %gep.us.i.1.1122, align 8
  %211 = shufflevector <4 x double> %unmaskedload32.1, <4 x double> poison, <1 x i32> zeroinitializer
  %212 = shufflevector <4 x double> %unmaskedload32.1, <4 x double> poison, <1 x i32> <i32 1>
  %213 = shufflevector <4 x double> %unmaskedload32.1, <4 x double> poison, <1 x i32> <i32 2>
  %214 = shufflevector <4 x double> %unmaskedload32.1, <4 x double> poison, <1 x i32> <i32 3>
  %215 = fmul <1 x double> %210, %211
  %216 = fmul <1 x double> %210, %212
  %217 = fmul <1 x double> %210, %213
  %218 = shufflevector <1 x double> %217, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %219 = fmul <1 x double> %210, %214
  %220 = shufflevector <1 x double> %219, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %221 = shufflevector <1 x double> %215, <1 x double> %216, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %222 = shufflevector <4 x double> %221, <4 x double> %218, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %223 = shufflevector <4 x double> %222, <4 x double> %220, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %224 = fadd <4 x double> %205, %223
  store <4 x double> %224, ptr %185, align 8
  %225 = add nuw nsw i64 %187, 2
  br label %.critedge.us.i.1

.preheader.us.i.1.1:                              ; preds = %.critedge.us.i.1
  %226 = getelementptr double, ptr %185, i64 4
  %.promoted109 = load <4 x double>, ptr %226, align 8
  br label %.critedge.us.i.1.1

.critedge.us.i.1.1:                               ; preds = %.critedge.us.i.1.1.1, %.preheader.us.i.1.1
  %227 = phi <4 x double> [ %.promoted109, %.preheader.us.i.1.1 ], [ %265, %.critedge.us.i.1.1.1 ]
  %228 = phi i64 [ 0, %.preheader.us.i.1.1 ], [ %266, %.critedge.us.i.1.1.1 ]
  %229 = mul nuw nsw i64 %228, 65
  %230 = getelementptr double, ptr %184, i64 %228
  %231 = load double, ptr %230, align 8
  %232 = insertelement <1 x double> poison, double %231, i64 0
  %gep.us.i.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %229
  %unmaskedload34 = load <4 x double>, ptr %gep.us.i.1.1, align 8
  %233 = shufflevector <4 x double> %unmaskedload34, <4 x double> poison, <1 x i32> zeroinitializer
  %234 = shufflevector <4 x double> %unmaskedload34, <4 x double> poison, <1 x i32> <i32 1>
  %235 = shufflevector <4 x double> %unmaskedload34, <4 x double> poison, <1 x i32> <i32 2>
  %236 = shufflevector <4 x double> %unmaskedload34, <4 x double> poison, <1 x i32> <i32 3>
  %237 = fmul <1 x double> %232, %233
  %238 = fmul <1 x double> %232, %234
  %239 = fmul <1 x double> %232, %235
  %240 = shufflevector <1 x double> %239, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %241 = fmul <1 x double> %232, %236
  %242 = shufflevector <1 x double> %241, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %243 = shufflevector <1 x double> %237, <1 x double> %238, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %244 = shufflevector <4 x double> %243, <4 x double> %240, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %245 = shufflevector <4 x double> %244, <4 x double> %242, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %246 = fadd <4 x double> %227, %245
  store <4 x double> %246, ptr %226, align 8
  %247 = or disjoint i64 %228, 1
  %exitcond.not.i.1.1 = icmp eq i64 %247, 17
  br i1 %exitcond.not.i.1.1, label %.preheader.us.i.1.2, label %.critedge.us.i.1.1.1

.critedge.us.i.1.1.1:                             ; preds = %.critedge.us.i.1.1
  %248 = mul nuw nsw i64 %247, 65
  %249 = getelementptr double, ptr %184, i64 %247
  %250 = load double, ptr %249, align 8
  %251 = insertelement <1 x double> poison, double %250, i64 0
  %gep.us.i.1.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %248
  %unmaskedload34.1 = load <4 x double>, ptr %gep.us.i.1.1.1, align 8
  %252 = shufflevector <4 x double> %unmaskedload34.1, <4 x double> poison, <1 x i32> zeroinitializer
  %253 = shufflevector <4 x double> %unmaskedload34.1, <4 x double> poison, <1 x i32> <i32 1>
  %254 = shufflevector <4 x double> %unmaskedload34.1, <4 x double> poison, <1 x i32> <i32 2>
  %255 = shufflevector <4 x double> %unmaskedload34.1, <4 x double> poison, <1 x i32> <i32 3>
  %256 = fmul <1 x double> %251, %252
  %257 = fmul <1 x double> %251, %253
  %258 = fmul <1 x double> %251, %254
  %259 = shufflevector <1 x double> %258, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %260 = fmul <1 x double> %251, %255
  %261 = shufflevector <1 x double> %260, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %262 = shufflevector <1 x double> %256, <1 x double> %257, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %263 = shufflevector <4 x double> %262, <4 x double> %259, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %264 = shufflevector <4 x double> %263, <4 x double> %261, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %265 = fadd <4 x double> %246, %264
  store <4 x double> %265, ptr %226, align 8
  %266 = add nuw nsw i64 %228, 2
  br label %.critedge.us.i.1.1

.preheader.us.i.1.2:                              ; preds = %.critedge.us.i.1.1
  %267 = getelementptr double, ptr %185, i64 8
  %.promoted108 = load <4 x double>, ptr %267, align 8
  br label %.critedge.us.i.1.2

.critedge.us.i.1.2:                               ; preds = %.critedge.us.i.1.2.1, %.preheader.us.i.1.2
  %268 = phi <4 x double> [ %.promoted108, %.preheader.us.i.1.2 ], [ %306, %.critedge.us.i.1.2.1 ]
  %269 = phi i64 [ 0, %.preheader.us.i.1.2 ], [ %307, %.critedge.us.i.1.2.1 ]
  %270 = mul nuw nsw i64 %269, 65
  %271 = getelementptr double, ptr %184, i64 %269
  %272 = load double, ptr %271, align 8
  %273 = insertelement <1 x double> poison, double %272, i64 0
  %gep.us.i.1.2 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %270
  %unmaskedload36 = load <4 x double>, ptr %gep.us.i.1.2, align 8
  %274 = shufflevector <4 x double> %unmaskedload36, <4 x double> poison, <1 x i32> zeroinitializer
  %275 = shufflevector <4 x double> %unmaskedload36, <4 x double> poison, <1 x i32> <i32 1>
  %276 = shufflevector <4 x double> %unmaskedload36, <4 x double> poison, <1 x i32> <i32 2>
  %277 = shufflevector <4 x double> %unmaskedload36, <4 x double> poison, <1 x i32> <i32 3>
  %278 = fmul <1 x double> %273, %274
  %279 = fmul <1 x double> %273, %275
  %280 = fmul <1 x double> %273, %276
  %281 = shufflevector <1 x double> %280, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %282 = fmul <1 x double> %273, %277
  %283 = shufflevector <1 x double> %282, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %284 = shufflevector <1 x double> %278, <1 x double> %279, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %285 = shufflevector <4 x double> %284, <4 x double> %281, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %286 = shufflevector <4 x double> %285, <4 x double> %283, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %287 = fadd <4 x double> %268, %286
  store <4 x double> %287, ptr %267, align 8
  %288 = or disjoint i64 %269, 1
  %exitcond.not.i.1.2 = icmp eq i64 %288, 17
  br i1 %exitcond.not.i.1.2, label %.preheader.us.i.1.3, label %.critedge.us.i.1.2.1

.critedge.us.i.1.2.1:                             ; preds = %.critedge.us.i.1.2
  %289 = mul nuw nsw i64 %288, 65
  %290 = getelementptr double, ptr %184, i64 %288
  %291 = load double, ptr %290, align 8
  %292 = insertelement <1 x double> poison, double %291, i64 0
  %gep.us.i.1.2.1 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %289
  %unmaskedload36.1 = load <4 x double>, ptr %gep.us.i.1.2.1, align 8
  %293 = shufflevector <4 x double> %unmaskedload36.1, <4 x double> poison, <1 x i32> zeroinitializer
  %294 = shufflevector <4 x double> %unmaskedload36.1, <4 x double> poison, <1 x i32> <i32 1>
  %295 = shufflevector <4 x double> %unmaskedload36.1, <4 x double> poison, <1 x i32> <i32 2>
  %296 = shufflevector <4 x double> %unmaskedload36.1, <4 x double> poison, <1 x i32> <i32 3>
  %297 = fmul <1 x double> %292, %293
  %298 = fmul <1 x double> %292, %294
  %299 = fmul <1 x double> %292, %295
  %300 = shufflevector <1 x double> %299, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %301 = fmul <1 x double> %292, %296
  %302 = shufflevector <1 x double> %301, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %303 = shufflevector <1 x double> %297, <1 x double> %298, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %304 = shufflevector <4 x double> %303, <4 x double> %300, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %305 = shufflevector <4 x double> %304, <4 x double> %302, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %306 = fadd <4 x double> %287, %305
  store <4 x double> %306, ptr %267, align 8
  %307 = add nuw nsw i64 %269, 2
  br label %.critedge.us.i.1.2

.preheader.us.i.1.3:                              ; preds = %.critedge.us.i.1.2
  %308 = getelementptr double, ptr %185, i64 12
  %.promoted107 = load <4 x double>, ptr %308, align 8
  br label %.critedge.us.i.1.3

.critedge.us.i.1.3:                               ; preds = %.critedge.us.i.1.3.1, %.preheader.us.i.1.3
  %309 = phi <4 x double> [ %.promoted107, %.preheader.us.i.1.3 ], [ %347, %.critedge.us.i.1.3.1 ]
  %310 = phi i64 [ 0, %.preheader.us.i.1.3 ], [ %348, %.critedge.us.i.1.3.1 ]
  %311 = mul nuw nsw i64 %310, 65
  %312 = getelementptr double, ptr %184, i64 %310
  %313 = load double, ptr %312, align 8
  %314 = insertelement <1 x double> poison, double %313, i64 0
  %gep.us.i.1.3 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %311
  %unmaskedload38 = load <4 x double>, ptr %gep.us.i.1.3, align 8
  %315 = shufflevector <4 x double> %unmaskedload38, <4 x double> poison, <1 x i32> zeroinitializer
  %316 = shufflevector <4 x double> %unmaskedload38, <4 x double> poison, <1 x i32> <i32 1>
  %317 = shufflevector <4 x double> %unmaskedload38, <4 x double> poison, <1 x i32> <i32 2>
  %318 = shufflevector <4 x double> %unmaskedload38, <4 x double> poison, <1 x i32> <i32 3>
  %319 = fmul <1 x double> %314, %315
  %320 = fmul <1 x double> %314, %316
  %321 = fmul <1 x double> %314, %317
  %322 = shufflevector <1 x double> %321, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %323 = fmul <1 x double> %314, %318
  %324 = shufflevector <1 x double> %323, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %325 = shufflevector <1 x double> %319, <1 x double> %320, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %326 = shufflevector <4 x double> %325, <4 x double> %322, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %327 = shufflevector <4 x double> %326, <4 x double> %324, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %328 = fadd <4 x double> %309, %327
  store <4 x double> %328, ptr %308, align 8
  %329 = or disjoint i64 %310, 1
  %exitcond.not.i.1.3 = icmp eq i64 %329, 17
  br i1 %exitcond.not.i.1.3, label %._crit_edge.us.i.1, label %.critedge.us.i.1.3.1

.critedge.us.i.1.3.1:                             ; preds = %.critedge.us.i.1.3
  %330 = mul nuw nsw i64 %329, 65
  %331 = getelementptr double, ptr %184, i64 %329
  %332 = load double, ptr %331, align 8
  %333 = insertelement <1 x double> poison, double %332, i64 0
  %gep.us.i.1.3.1 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %330
  %unmaskedload38.1 = load <4 x double>, ptr %gep.us.i.1.3.1, align 8
  %334 = shufflevector <4 x double> %unmaskedload38.1, <4 x double> poison, <1 x i32> zeroinitializer
  %335 = shufflevector <4 x double> %unmaskedload38.1, <4 x double> poison, <1 x i32> <i32 1>
  %336 = shufflevector <4 x double> %unmaskedload38.1, <4 x double> poison, <1 x i32> <i32 2>
  %337 = shufflevector <4 x double> %unmaskedload38.1, <4 x double> poison, <1 x i32> <i32 3>
  %338 = fmul <1 x double> %333, %334
  %339 = fmul <1 x double> %333, %335
  %340 = fmul <1 x double> %333, %336
  %341 = shufflevector <1 x double> %340, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %342 = fmul <1 x double> %333, %337
  %343 = shufflevector <1 x double> %342, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %344 = shufflevector <1 x double> %338, <1 x double> %339, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %345 = shufflevector <4 x double> %344, <4 x double> %341, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %346 = shufflevector <4 x double> %345, <4 x double> %343, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %347 = fadd <4 x double> %328, %346
  store <4 x double> %347, ptr %308, align 8
  %348 = add nuw nsw i64 %310, 2
  br label %.critedge.us.i.1.3

._crit_edge.us.i.1:                               ; preds = %.critedge.us.i.1.3
  %349 = add nuw nsw i64 %181, 1
  %exitcond22.not.i.1 = icmp eq i64 %349, 16
  br i1 %exitcond22.not.i.1, label %.split20.us.i.1, label %.preheader16.us.i.1

.split20.us.i.1:                                  ; preds = %._crit_edge.us.i.1
  %350 = getelementptr double, ptr %6, i64 32
  %351 = getelementptr double, ptr %9, i64 32
  %invariant.gep.us.i.2.1 = getelementptr double, ptr %6, i64 36
  %invariant.gep.us.i.2.2 = getelementptr double, ptr %6, i64 40
  %invariant.gep.us.i.2.3 = getelementptr double, ptr %6, i64 44
  br label %.preheader16.us.i.2

.preheader16.us.i.2:                              ; preds = %._crit_edge.us.i.2, %.split20.us.i.1
  %352 = phi i64 [ %520, %._crit_edge.us.i.2 ], [ 0, %.split20.us.i.1 ]
  %353 = mul nuw nsw i64 %352, 17
  %354 = mul nuw nsw i64 %352, 65
  %355 = getelementptr double, ptr %3, i64 %353
  %356 = getelementptr double, ptr %351, i64 %354
  %.promoted114 = load <4 x double>, ptr %356, align 8
  br label %.critedge.us.i.2

.critedge.us.i.2:                                 ; preds = %.critedge.us.i.2.1127, %.preheader16.us.i.2
  %357 = phi <4 x double> [ %.promoted114, %.preheader16.us.i.2 ], [ %395, %.critedge.us.i.2.1127 ]
  %358 = phi i64 [ 0, %.preheader16.us.i.2 ], [ %396, %.critedge.us.i.2.1127 ]
  %359 = mul nuw nsw i64 %358, 65
  %360 = getelementptr double, ptr %355, i64 %358
  %361 = load double, ptr %360, align 8
  %362 = insertelement <1 x double> poison, double %361, i64 0
  %gep.us.i.2 = getelementptr double, ptr %350, i64 %359
  %unmaskedload40 = load <4 x double>, ptr %gep.us.i.2, align 8
  %363 = shufflevector <4 x double> %unmaskedload40, <4 x double> poison, <1 x i32> zeroinitializer
  %364 = shufflevector <4 x double> %unmaskedload40, <4 x double> poison, <1 x i32> <i32 1>
  %365 = shufflevector <4 x double> %unmaskedload40, <4 x double> poison, <1 x i32> <i32 2>
  %366 = shufflevector <4 x double> %unmaskedload40, <4 x double> poison, <1 x i32> <i32 3>
  %367 = fmul <1 x double> %362, %363
  %368 = fmul <1 x double> %362, %364
  %369 = fmul <1 x double> %362, %365
  %370 = shufflevector <1 x double> %369, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %371 = fmul <1 x double> %362, %366
  %372 = shufflevector <1 x double> %371, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %373 = shufflevector <1 x double> %367, <1 x double> %368, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %374 = shufflevector <4 x double> %373, <4 x double> %370, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %375 = shufflevector <4 x double> %374, <4 x double> %372, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %376 = fadd <4 x double> %357, %375
  store <4 x double> %376, ptr %356, align 8
  %377 = or disjoint i64 %358, 1
  %exitcond.not.i.2 = icmp eq i64 %377, 17
  br i1 %exitcond.not.i.2, label %.preheader.us.i.2.1, label %.critedge.us.i.2.1127

.critedge.us.i.2.1127:                            ; preds = %.critedge.us.i.2
  %378 = mul nuw nsw i64 %377, 65
  %379 = getelementptr double, ptr %355, i64 %377
  %380 = load double, ptr %379, align 8
  %381 = insertelement <1 x double> poison, double %380, i64 0
  %gep.us.i.2.1125 = getelementptr double, ptr %350, i64 %378
  %unmaskedload40.1 = load <4 x double>, ptr %gep.us.i.2.1125, align 8
  %382 = shufflevector <4 x double> %unmaskedload40.1, <4 x double> poison, <1 x i32> zeroinitializer
  %383 = shufflevector <4 x double> %unmaskedload40.1, <4 x double> poison, <1 x i32> <i32 1>
  %384 = shufflevector <4 x double> %unmaskedload40.1, <4 x double> poison, <1 x i32> <i32 2>
  %385 = shufflevector <4 x double> %unmaskedload40.1, <4 x double> poison, <1 x i32> <i32 3>
  %386 = fmul <1 x double> %381, %382
  %387 = fmul <1 x double> %381, %383
  %388 = fmul <1 x double> %381, %384
  %389 = shufflevector <1 x double> %388, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %390 = fmul <1 x double> %381, %385
  %391 = shufflevector <1 x double> %390, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %392 = shufflevector <1 x double> %386, <1 x double> %387, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %393 = shufflevector <4 x double> %392, <4 x double> %389, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %394 = shufflevector <4 x double> %393, <4 x double> %391, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %395 = fadd <4 x double> %376, %394
  store <4 x double> %395, ptr %356, align 8
  %396 = add nuw nsw i64 %358, 2
  br label %.critedge.us.i.2

.preheader.us.i.2.1:                              ; preds = %.critedge.us.i.2
  %397 = getelementptr double, ptr %356, i64 4
  %.promoted113 = load <4 x double>, ptr %397, align 8
  br label %.critedge.us.i.2.1

.critedge.us.i.2.1:                               ; preds = %.critedge.us.i.2.1.1, %.preheader.us.i.2.1
  %398 = phi <4 x double> [ %.promoted113, %.preheader.us.i.2.1 ], [ %436, %.critedge.us.i.2.1.1 ]
  %399 = phi i64 [ 0, %.preheader.us.i.2.1 ], [ %437, %.critedge.us.i.2.1.1 ]
  %400 = mul nuw nsw i64 %399, 65
  %401 = getelementptr double, ptr %355, i64 %399
  %402 = load double, ptr %401, align 8
  %403 = insertelement <1 x double> poison, double %402, i64 0
  %gep.us.i.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %400
  %unmaskedload42 = load <4 x double>, ptr %gep.us.i.2.1, align 8
  %404 = shufflevector <4 x double> %unmaskedload42, <4 x double> poison, <1 x i32> zeroinitializer
  %405 = shufflevector <4 x double> %unmaskedload42, <4 x double> poison, <1 x i32> <i32 1>
  %406 = shufflevector <4 x double> %unmaskedload42, <4 x double> poison, <1 x i32> <i32 2>
  %407 = shufflevector <4 x double> %unmaskedload42, <4 x double> poison, <1 x i32> <i32 3>
  %408 = fmul <1 x double> %403, %404
  %409 = fmul <1 x double> %403, %405
  %410 = fmul <1 x double> %403, %406
  %411 = shufflevector <1 x double> %410, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %412 = fmul <1 x double> %403, %407
  %413 = shufflevector <1 x double> %412, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %414 = shufflevector <1 x double> %408, <1 x double> %409, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %415 = shufflevector <4 x double> %414, <4 x double> %411, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %416 = shufflevector <4 x double> %415, <4 x double> %413, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %417 = fadd <4 x double> %398, %416
  store <4 x double> %417, ptr %397, align 8
  %418 = or disjoint i64 %399, 1
  %exitcond.not.i.2.1 = icmp eq i64 %418, 17
  br i1 %exitcond.not.i.2.1, label %.preheader.us.i.2.2, label %.critedge.us.i.2.1.1

.critedge.us.i.2.1.1:                             ; preds = %.critedge.us.i.2.1
  %419 = mul nuw nsw i64 %418, 65
  %420 = getelementptr double, ptr %355, i64 %418
  %421 = load double, ptr %420, align 8
  %422 = insertelement <1 x double> poison, double %421, i64 0
  %gep.us.i.2.1.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %419
  %unmaskedload42.1 = load <4 x double>, ptr %gep.us.i.2.1.1, align 8
  %423 = shufflevector <4 x double> %unmaskedload42.1, <4 x double> poison, <1 x i32> zeroinitializer
  %424 = shufflevector <4 x double> %unmaskedload42.1, <4 x double> poison, <1 x i32> <i32 1>
  %425 = shufflevector <4 x double> %unmaskedload42.1, <4 x double> poison, <1 x i32> <i32 2>
  %426 = shufflevector <4 x double> %unmaskedload42.1, <4 x double> poison, <1 x i32> <i32 3>
  %427 = fmul <1 x double> %422, %423
  %428 = fmul <1 x double> %422, %424
  %429 = fmul <1 x double> %422, %425
  %430 = shufflevector <1 x double> %429, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %431 = fmul <1 x double> %422, %426
  %432 = shufflevector <1 x double> %431, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %433 = shufflevector <1 x double> %427, <1 x double> %428, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %434 = shufflevector <4 x double> %433, <4 x double> %430, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %435 = shufflevector <4 x double> %434, <4 x double> %432, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %436 = fadd <4 x double> %417, %435
  store <4 x double> %436, ptr %397, align 8
  %437 = add nuw nsw i64 %399, 2
  br label %.critedge.us.i.2.1

.preheader.us.i.2.2:                              ; preds = %.critedge.us.i.2.1
  %438 = getelementptr double, ptr %356, i64 8
  %.promoted112 = load <4 x double>, ptr %438, align 8
  br label %.critedge.us.i.2.2

.critedge.us.i.2.2:                               ; preds = %.critedge.us.i.2.2.1, %.preheader.us.i.2.2
  %439 = phi <4 x double> [ %.promoted112, %.preheader.us.i.2.2 ], [ %477, %.critedge.us.i.2.2.1 ]
  %440 = phi i64 [ 0, %.preheader.us.i.2.2 ], [ %478, %.critedge.us.i.2.2.1 ]
  %441 = mul nuw nsw i64 %440, 65
  %442 = getelementptr double, ptr %355, i64 %440
  %443 = load double, ptr %442, align 8
  %444 = insertelement <1 x double> poison, double %443, i64 0
  %gep.us.i.2.2 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %441
  %unmaskedload44 = load <4 x double>, ptr %gep.us.i.2.2, align 8
  %445 = shufflevector <4 x double> %unmaskedload44, <4 x double> poison, <1 x i32> zeroinitializer
  %446 = shufflevector <4 x double> %unmaskedload44, <4 x double> poison, <1 x i32> <i32 1>
  %447 = shufflevector <4 x double> %unmaskedload44, <4 x double> poison, <1 x i32> <i32 2>
  %448 = shufflevector <4 x double> %unmaskedload44, <4 x double> poison, <1 x i32> <i32 3>
  %449 = fmul <1 x double> %444, %445
  %450 = fmul <1 x double> %444, %446
  %451 = fmul <1 x double> %444, %447
  %452 = shufflevector <1 x double> %451, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %453 = fmul <1 x double> %444, %448
  %454 = shufflevector <1 x double> %453, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %455 = shufflevector <1 x double> %449, <1 x double> %450, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %456 = shufflevector <4 x double> %455, <4 x double> %452, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %457 = shufflevector <4 x double> %456, <4 x double> %454, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %458 = fadd <4 x double> %439, %457
  store <4 x double> %458, ptr %438, align 8
  %459 = or disjoint i64 %440, 1
  %exitcond.not.i.2.2 = icmp eq i64 %459, 17
  br i1 %exitcond.not.i.2.2, label %.preheader.us.i.2.3, label %.critedge.us.i.2.2.1

.critedge.us.i.2.2.1:                             ; preds = %.critedge.us.i.2.2
  %460 = mul nuw nsw i64 %459, 65
  %461 = getelementptr double, ptr %355, i64 %459
  %462 = load double, ptr %461, align 8
  %463 = insertelement <1 x double> poison, double %462, i64 0
  %gep.us.i.2.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %460
  %unmaskedload44.1 = load <4 x double>, ptr %gep.us.i.2.2.1, align 8
  %464 = shufflevector <4 x double> %unmaskedload44.1, <4 x double> poison, <1 x i32> zeroinitializer
  %465 = shufflevector <4 x double> %unmaskedload44.1, <4 x double> poison, <1 x i32> <i32 1>
  %466 = shufflevector <4 x double> %unmaskedload44.1, <4 x double> poison, <1 x i32> <i32 2>
  %467 = shufflevector <4 x double> %unmaskedload44.1, <4 x double> poison, <1 x i32> <i32 3>
  %468 = fmul <1 x double> %463, %464
  %469 = fmul <1 x double> %463, %465
  %470 = fmul <1 x double> %463, %466
  %471 = shufflevector <1 x double> %470, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %472 = fmul <1 x double> %463, %467
  %473 = shufflevector <1 x double> %472, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %474 = shufflevector <1 x double> %468, <1 x double> %469, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %475 = shufflevector <4 x double> %474, <4 x double> %471, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %476 = shufflevector <4 x double> %475, <4 x double> %473, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %477 = fadd <4 x double> %458, %476
  store <4 x double> %477, ptr %438, align 8
  %478 = add nuw nsw i64 %440, 2
  br label %.critedge.us.i.2.2

.preheader.us.i.2.3:                              ; preds = %.critedge.us.i.2.2
  %479 = getelementptr double, ptr %356, i64 12
  %.promoted111 = load <4 x double>, ptr %479, align 8
  br label %.critedge.us.i.2.3

.critedge.us.i.2.3:                               ; preds = %.critedge.us.i.2.3.1, %.preheader.us.i.2.3
  %480 = phi <4 x double> [ %.promoted111, %.preheader.us.i.2.3 ], [ %518, %.critedge.us.i.2.3.1 ]
  %481 = phi i64 [ 0, %.preheader.us.i.2.3 ], [ %519, %.critedge.us.i.2.3.1 ]
  %482 = mul nuw nsw i64 %481, 65
  %483 = getelementptr double, ptr %355, i64 %481
  %484 = load double, ptr %483, align 8
  %485 = insertelement <1 x double> poison, double %484, i64 0
  %gep.us.i.2.3 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %482
  %unmaskedload46 = load <4 x double>, ptr %gep.us.i.2.3, align 8
  %486 = shufflevector <4 x double> %unmaskedload46, <4 x double> poison, <1 x i32> zeroinitializer
  %487 = shufflevector <4 x double> %unmaskedload46, <4 x double> poison, <1 x i32> <i32 1>
  %488 = shufflevector <4 x double> %unmaskedload46, <4 x double> poison, <1 x i32> <i32 2>
  %489 = shufflevector <4 x double> %unmaskedload46, <4 x double> poison, <1 x i32> <i32 3>
  %490 = fmul <1 x double> %485, %486
  %491 = fmul <1 x double> %485, %487
  %492 = fmul <1 x double> %485, %488
  %493 = shufflevector <1 x double> %492, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %494 = fmul <1 x double> %485, %489
  %495 = shufflevector <1 x double> %494, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %496 = shufflevector <1 x double> %490, <1 x double> %491, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %497 = shufflevector <4 x double> %496, <4 x double> %493, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %498 = shufflevector <4 x double> %497, <4 x double> %495, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %499 = fadd <4 x double> %480, %498
  store <4 x double> %499, ptr %479, align 8
  %500 = or disjoint i64 %481, 1
  %exitcond.not.i.2.3 = icmp eq i64 %500, 17
  br i1 %exitcond.not.i.2.3, label %._crit_edge.us.i.2, label %.critedge.us.i.2.3.1

.critedge.us.i.2.3.1:                             ; preds = %.critedge.us.i.2.3
  %501 = mul nuw nsw i64 %500, 65
  %502 = getelementptr double, ptr %355, i64 %500
  %503 = load double, ptr %502, align 8
  %504 = insertelement <1 x double> poison, double %503, i64 0
  %gep.us.i.2.3.1 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %501
  %unmaskedload46.1 = load <4 x double>, ptr %gep.us.i.2.3.1, align 8
  %505 = shufflevector <4 x double> %unmaskedload46.1, <4 x double> poison, <1 x i32> zeroinitializer
  %506 = shufflevector <4 x double> %unmaskedload46.1, <4 x double> poison, <1 x i32> <i32 1>
  %507 = shufflevector <4 x double> %unmaskedload46.1, <4 x double> poison, <1 x i32> <i32 2>
  %508 = shufflevector <4 x double> %unmaskedload46.1, <4 x double> poison, <1 x i32> <i32 3>
  %509 = fmul <1 x double> %504, %505
  %510 = fmul <1 x double> %504, %506
  %511 = fmul <1 x double> %504, %507
  %512 = shufflevector <1 x double> %511, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %513 = fmul <1 x double> %504, %508
  %514 = shufflevector <1 x double> %513, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %515 = shufflevector <1 x double> %509, <1 x double> %510, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %516 = shufflevector <4 x double> %515, <4 x double> %512, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %517 = shufflevector <4 x double> %516, <4 x double> %514, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %518 = fadd <4 x double> %499, %517
  store <4 x double> %518, ptr %479, align 8
  %519 = add nuw nsw i64 %481, 2
  br label %.critedge.us.i.2.3

._crit_edge.us.i.2:                               ; preds = %.critedge.us.i.2.3
  %520 = add nuw nsw i64 %352, 1
  %exitcond22.not.i.2 = icmp eq i64 %520, 16
  br i1 %exitcond22.not.i.2, label %.split20.us.i.2, label %.preheader16.us.i.2

.split20.us.i.2:                                  ; preds = %._crit_edge.us.i.2
  %521 = getelementptr double, ptr %6, i64 48
  %522 = getelementptr double, ptr %9, i64 48
  %invariant.gep.us.i.3.1 = getelementptr double, ptr %6, i64 52
  %invariant.gep.us.i.3.2 = getelementptr double, ptr %6, i64 56
  %invariant.gep.us.i.3.3 = getelementptr double, ptr %6, i64 60
  br label %.preheader16.us.i.3

.preheader16.us.i.3:                              ; preds = %._crit_edge.us.i.3, %.split20.us.i.2
  %523 = phi i64 [ %691, %._crit_edge.us.i.3 ], [ 0, %.split20.us.i.2 ]
  %524 = mul nuw nsw i64 %523, 17
  %525 = mul nuw nsw i64 %523, 65
  %526 = getelementptr double, ptr %3, i64 %524
  %527 = getelementptr double, ptr %522, i64 %525
  %.promoted118 = load <4 x double>, ptr %527, align 8
  br label %.critedge.us.i.3

.critedge.us.i.3:                                 ; preds = %.critedge.us.i.3.1130, %.preheader16.us.i.3
  %528 = phi <4 x double> [ %.promoted118, %.preheader16.us.i.3 ], [ %566, %.critedge.us.i.3.1130 ]
  %529 = phi i64 [ 0, %.preheader16.us.i.3 ], [ %567, %.critedge.us.i.3.1130 ]
  %530 = mul nuw nsw i64 %529, 65
  %531 = getelementptr double, ptr %526, i64 %529
  %532 = load double, ptr %531, align 8
  %533 = insertelement <1 x double> poison, double %532, i64 0
  %gep.us.i.3 = getelementptr double, ptr %521, i64 %530
  %unmaskedload48 = load <4 x double>, ptr %gep.us.i.3, align 8
  %534 = shufflevector <4 x double> %unmaskedload48, <4 x double> poison, <1 x i32> zeroinitializer
  %535 = shufflevector <4 x double> %unmaskedload48, <4 x double> poison, <1 x i32> <i32 1>
  %536 = shufflevector <4 x double> %unmaskedload48, <4 x double> poison, <1 x i32> <i32 2>
  %537 = shufflevector <4 x double> %unmaskedload48, <4 x double> poison, <1 x i32> <i32 3>
  %538 = fmul <1 x double> %533, %534
  %539 = fmul <1 x double> %533, %535
  %540 = fmul <1 x double> %533, %536
  %541 = shufflevector <1 x double> %540, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %542 = fmul <1 x double> %533, %537
  %543 = shufflevector <1 x double> %542, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %544 = shufflevector <1 x double> %538, <1 x double> %539, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %545 = shufflevector <4 x double> %544, <4 x double> %541, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %546 = shufflevector <4 x double> %545, <4 x double> %543, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %547 = fadd <4 x double> %528, %546
  store <4 x double> %547, ptr %527, align 8
  %548 = or disjoint i64 %529, 1
  %exitcond.not.i.3 = icmp eq i64 %548, 17
  br i1 %exitcond.not.i.3, label %.preheader.us.i.3.1, label %.critedge.us.i.3.1130

.critedge.us.i.3.1130:                            ; preds = %.critedge.us.i.3
  %549 = mul nuw nsw i64 %548, 65
  %550 = getelementptr double, ptr %526, i64 %548
  %551 = load double, ptr %550, align 8
  %552 = insertelement <1 x double> poison, double %551, i64 0
  %gep.us.i.3.1128 = getelementptr double, ptr %521, i64 %549
  %unmaskedload48.1 = load <4 x double>, ptr %gep.us.i.3.1128, align 8
  %553 = shufflevector <4 x double> %unmaskedload48.1, <4 x double> poison, <1 x i32> zeroinitializer
  %554 = shufflevector <4 x double> %unmaskedload48.1, <4 x double> poison, <1 x i32> <i32 1>
  %555 = shufflevector <4 x double> %unmaskedload48.1, <4 x double> poison, <1 x i32> <i32 2>
  %556 = shufflevector <4 x double> %unmaskedload48.1, <4 x double> poison, <1 x i32> <i32 3>
  %557 = fmul <1 x double> %552, %553
  %558 = fmul <1 x double> %552, %554
  %559 = fmul <1 x double> %552, %555
  %560 = shufflevector <1 x double> %559, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %561 = fmul <1 x double> %552, %556
  %562 = shufflevector <1 x double> %561, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %563 = shufflevector <1 x double> %557, <1 x double> %558, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %564 = shufflevector <4 x double> %563, <4 x double> %560, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %565 = shufflevector <4 x double> %564, <4 x double> %562, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %566 = fadd <4 x double> %547, %565
  store <4 x double> %566, ptr %527, align 8
  %567 = add nuw nsw i64 %529, 2
  br label %.critedge.us.i.3

.preheader.us.i.3.1:                              ; preds = %.critedge.us.i.3
  %568 = getelementptr double, ptr %527, i64 4
  %.promoted117 = load <4 x double>, ptr %568, align 8
  br label %.critedge.us.i.3.1

.critedge.us.i.3.1:                               ; preds = %.critedge.us.i.3.1.1, %.preheader.us.i.3.1
  %569 = phi <4 x double> [ %.promoted117, %.preheader.us.i.3.1 ], [ %607, %.critedge.us.i.3.1.1 ]
  %570 = phi i64 [ 0, %.preheader.us.i.3.1 ], [ %608, %.critedge.us.i.3.1.1 ]
  %571 = mul nuw nsw i64 %570, 65
  %572 = getelementptr double, ptr %526, i64 %570
  %573 = load double, ptr %572, align 8
  %574 = insertelement <1 x double> poison, double %573, i64 0
  %gep.us.i.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %571
  %unmaskedload50 = load <4 x double>, ptr %gep.us.i.3.1, align 8
  %575 = shufflevector <4 x double> %unmaskedload50, <4 x double> poison, <1 x i32> zeroinitializer
  %576 = shufflevector <4 x double> %unmaskedload50, <4 x double> poison, <1 x i32> <i32 1>
  %577 = shufflevector <4 x double> %unmaskedload50, <4 x double> poison, <1 x i32> <i32 2>
  %578 = shufflevector <4 x double> %unmaskedload50, <4 x double> poison, <1 x i32> <i32 3>
  %579 = fmul <1 x double> %574, %575
  %580 = fmul <1 x double> %574, %576
  %581 = fmul <1 x double> %574, %577
  %582 = shufflevector <1 x double> %581, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %583 = fmul <1 x double> %574, %578
  %584 = shufflevector <1 x double> %583, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %585 = shufflevector <1 x double> %579, <1 x double> %580, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %586 = shufflevector <4 x double> %585, <4 x double> %582, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %587 = shufflevector <4 x double> %586, <4 x double> %584, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %588 = fadd <4 x double> %569, %587
  store <4 x double> %588, ptr %568, align 8
  %589 = or disjoint i64 %570, 1
  %exitcond.not.i.3.1 = icmp eq i64 %589, 17
  br i1 %exitcond.not.i.3.1, label %.preheader.us.i.3.2, label %.critedge.us.i.3.1.1

.critedge.us.i.3.1.1:                             ; preds = %.critedge.us.i.3.1
  %590 = mul nuw nsw i64 %589, 65
  %591 = getelementptr double, ptr %526, i64 %589
  %592 = load double, ptr %591, align 8
  %593 = insertelement <1 x double> poison, double %592, i64 0
  %gep.us.i.3.1.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %590
  %unmaskedload50.1 = load <4 x double>, ptr %gep.us.i.3.1.1, align 8
  %594 = shufflevector <4 x double> %unmaskedload50.1, <4 x double> poison, <1 x i32> zeroinitializer
  %595 = shufflevector <4 x double> %unmaskedload50.1, <4 x double> poison, <1 x i32> <i32 1>
  %596 = shufflevector <4 x double> %unmaskedload50.1, <4 x double> poison, <1 x i32> <i32 2>
  %597 = shufflevector <4 x double> %unmaskedload50.1, <4 x double> poison, <1 x i32> <i32 3>
  %598 = fmul <1 x double> %593, %594
  %599 = fmul <1 x double> %593, %595
  %600 = fmul <1 x double> %593, %596
  %601 = shufflevector <1 x double> %600, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %602 = fmul <1 x double> %593, %597
  %603 = shufflevector <1 x double> %602, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %604 = shufflevector <1 x double> %598, <1 x double> %599, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %605 = shufflevector <4 x double> %604, <4 x double> %601, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %606 = shufflevector <4 x double> %605, <4 x double> %603, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %607 = fadd <4 x double> %588, %606
  store <4 x double> %607, ptr %568, align 8
  %608 = add nuw nsw i64 %570, 2
  br label %.critedge.us.i.3.1

.preheader.us.i.3.2:                              ; preds = %.critedge.us.i.3.1
  %609 = getelementptr double, ptr %527, i64 8
  %.promoted116 = load <4 x double>, ptr %609, align 8
  br label %.critedge.us.i.3.2

.critedge.us.i.3.2:                               ; preds = %.critedge.us.i.3.2.1, %.preheader.us.i.3.2
  %610 = phi <4 x double> [ %.promoted116, %.preheader.us.i.3.2 ], [ %648, %.critedge.us.i.3.2.1 ]
  %611 = phi i64 [ 0, %.preheader.us.i.3.2 ], [ %649, %.critedge.us.i.3.2.1 ]
  %612 = mul nuw nsw i64 %611, 65
  %613 = getelementptr double, ptr %526, i64 %611
  %614 = load double, ptr %613, align 8
  %615 = insertelement <1 x double> poison, double %614, i64 0
  %gep.us.i.3.2 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %612
  %unmaskedload52 = load <4 x double>, ptr %gep.us.i.3.2, align 8
  %616 = shufflevector <4 x double> %unmaskedload52, <4 x double> poison, <1 x i32> zeroinitializer
  %617 = shufflevector <4 x double> %unmaskedload52, <4 x double> poison, <1 x i32> <i32 1>
  %618 = shufflevector <4 x double> %unmaskedload52, <4 x double> poison, <1 x i32> <i32 2>
  %619 = shufflevector <4 x double> %unmaskedload52, <4 x double> poison, <1 x i32> <i32 3>
  %620 = fmul <1 x double> %615, %616
  %621 = fmul <1 x double> %615, %617
  %622 = fmul <1 x double> %615, %618
  %623 = shufflevector <1 x double> %622, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %624 = fmul <1 x double> %615, %619
  %625 = shufflevector <1 x double> %624, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %626 = shufflevector <1 x double> %620, <1 x double> %621, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %627 = shufflevector <4 x double> %626, <4 x double> %623, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %628 = shufflevector <4 x double> %627, <4 x double> %625, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %629 = fadd <4 x double> %610, %628
  store <4 x double> %629, ptr %609, align 8
  %630 = or disjoint i64 %611, 1
  %exitcond.not.i.3.2 = icmp eq i64 %630, 17
  br i1 %exitcond.not.i.3.2, label %.preheader.us.i.3.3, label %.critedge.us.i.3.2.1

.critedge.us.i.3.2.1:                             ; preds = %.critedge.us.i.3.2
  %631 = mul nuw nsw i64 %630, 65
  %632 = getelementptr double, ptr %526, i64 %630
  %633 = load double, ptr %632, align 8
  %634 = insertelement <1 x double> poison, double %633, i64 0
  %gep.us.i.3.2.1 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %631
  %unmaskedload52.1 = load <4 x double>, ptr %gep.us.i.3.2.1, align 8
  %635 = shufflevector <4 x double> %unmaskedload52.1, <4 x double> poison, <1 x i32> zeroinitializer
  %636 = shufflevector <4 x double> %unmaskedload52.1, <4 x double> poison, <1 x i32> <i32 1>
  %637 = shufflevector <4 x double> %unmaskedload52.1, <4 x double> poison, <1 x i32> <i32 2>
  %638 = shufflevector <4 x double> %unmaskedload52.1, <4 x double> poison, <1 x i32> <i32 3>
  %639 = fmul <1 x double> %634, %635
  %640 = fmul <1 x double> %634, %636
  %641 = fmul <1 x double> %634, %637
  %642 = shufflevector <1 x double> %641, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %643 = fmul <1 x double> %634, %638
  %644 = shufflevector <1 x double> %643, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %645 = shufflevector <1 x double> %639, <1 x double> %640, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %646 = shufflevector <4 x double> %645, <4 x double> %642, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %647 = shufflevector <4 x double> %646, <4 x double> %644, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %648 = fadd <4 x double> %629, %647
  store <4 x double> %648, ptr %609, align 8
  %649 = add nuw nsw i64 %611, 2
  br label %.critedge.us.i.3.2

.preheader.us.i.3.3:                              ; preds = %.critedge.us.i.3.2
  %650 = getelementptr double, ptr %527, i64 12
  %.promoted115 = load <4 x double>, ptr %650, align 8
  br label %.critedge.us.i.3.3

.critedge.us.i.3.3:                               ; preds = %.critedge.us.i.3.3.1, %.preheader.us.i.3.3
  %651 = phi <4 x double> [ %.promoted115, %.preheader.us.i.3.3 ], [ %689, %.critedge.us.i.3.3.1 ]
  %652 = phi i64 [ 0, %.preheader.us.i.3.3 ], [ %690, %.critedge.us.i.3.3.1 ]
  %653 = mul nuw nsw i64 %652, 65
  %654 = getelementptr double, ptr %526, i64 %652
  %655 = load double, ptr %654, align 8
  %656 = insertelement <1 x double> poison, double %655, i64 0
  %gep.us.i.3.3 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %653
  %unmaskedload54 = load <4 x double>, ptr %gep.us.i.3.3, align 8
  %657 = shufflevector <4 x double> %unmaskedload54, <4 x double> poison, <1 x i32> zeroinitializer
  %658 = shufflevector <4 x double> %unmaskedload54, <4 x double> poison, <1 x i32> <i32 1>
  %659 = shufflevector <4 x double> %unmaskedload54, <4 x double> poison, <1 x i32> <i32 2>
  %660 = shufflevector <4 x double> %unmaskedload54, <4 x double> poison, <1 x i32> <i32 3>
  %661 = fmul <1 x double> %656, %657
  %662 = fmul <1 x double> %656, %658
  %663 = fmul <1 x double> %656, %659
  %664 = shufflevector <1 x double> %663, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %665 = fmul <1 x double> %656, %660
  %666 = shufflevector <1 x double> %665, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %667 = shufflevector <1 x double> %661, <1 x double> %662, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %668 = shufflevector <4 x double> %667, <4 x double> %664, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %669 = shufflevector <4 x double> %668, <4 x double> %666, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %670 = fadd <4 x double> %651, %669
  store <4 x double> %670, ptr %650, align 8
  %671 = or disjoint i64 %652, 1
  %exitcond.not.i.3.3 = icmp eq i64 %671, 17
  br i1 %exitcond.not.i.3.3, label %._crit_edge.us.i.3, label %.critedge.us.i.3.3.1

.critedge.us.i.3.3.1:                             ; preds = %.critedge.us.i.3.3
  %672 = mul nuw nsw i64 %671, 65
  %673 = getelementptr double, ptr %526, i64 %671
  %674 = load double, ptr %673, align 8
  %675 = insertelement <1 x double> poison, double %674, i64 0
  %gep.us.i.3.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %672
  %unmaskedload54.1 = load <4 x double>, ptr %gep.us.i.3.3.1, align 8
  %676 = shufflevector <4 x double> %unmaskedload54.1, <4 x double> poison, <1 x i32> zeroinitializer
  %677 = shufflevector <4 x double> %unmaskedload54.1, <4 x double> poison, <1 x i32> <i32 1>
  %678 = shufflevector <4 x double> %unmaskedload54.1, <4 x double> poison, <1 x i32> <i32 2>
  %679 = shufflevector <4 x double> %unmaskedload54.1, <4 x double> poison, <1 x i32> <i32 3>
  %680 = fmul <1 x double> %675, %676
  %681 = fmul <1 x double> %675, %677
  %682 = fmul <1 x double> %675, %678
  %683 = shufflevector <1 x double> %682, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %684 = fmul <1 x double> %675, %679
  %685 = shufflevector <1 x double> %684, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %686 = shufflevector <1 x double> %680, <1 x double> %681, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %687 = shufflevector <4 x double> %686, <4 x double> %683, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %688 = shufflevector <4 x double> %687, <4 x double> %685, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %689 = fadd <4 x double> %670, %688
  store <4 x double> %689, ptr %650, align 8
  %690 = add nuw nsw i64 %652, 2
  br label %.critedge.us.i.3.3

._crit_edge.us.i.3:                               ; preds = %.critedge.us.i.3.3
  %691 = add nuw nsw i64 %523, 1
  %exitcond22.not.i.3 = icmp eq i64 %691, 16
  br i1 %exitcond22.not.i.3, label %.split20.us.i.3, label %.preheader16.us.i.3

.split20.us.i.3:                                  ; preds = %._crit_edge.us.i.3
  %692 = getelementptr double, ptr %6, i64 64
  %693 = getelementptr double, ptr %9, i64 64
  %gep.us.i.4.1 = getelementptr double, ptr %6, i64 129
  %gep.us.i.4.2 = getelementptr double, ptr %6, i64 194
  %gep.us.i.4.3 = getelementptr double, ptr %6, i64 259
  %gep.us.i.4.4 = getelementptr double, ptr %6, i64 324
  %gep.us.i.4.5 = getelementptr double, ptr %6, i64 389
  %gep.us.i.4.6 = getelementptr double, ptr %6, i64 454
  %gep.us.i.4.7 = getelementptr double, ptr %6, i64 519
  %gep.us.i.4.8 = getelementptr double, ptr %6, i64 584
  %gep.us.i.4.9 = getelementptr double, ptr %6, i64 649
  %gep.us.i.4.10 = getelementptr double, ptr %6, i64 714
  %gep.us.i.4.11 = getelementptr double, ptr %6, i64 779
  %gep.us.i.4.12 = getelementptr double, ptr %6, i64 844
  %gep.us.i.4.13 = getelementptr double, ptr %6, i64 909
  %gep.us.i.4.14 = getelementptr double, ptr %6, i64 974
  %gep.us.i.4.15 = getelementptr double, ptr %6, i64 1039
  %gep.us.i.4.16 = getelementptr double, ptr %6, i64 1104
  br label %.preheader16.us.i.4

.preheader16.us.i.4:                              ; preds = %.preheader16.us.i.4, %.split20.us.i.3
  %694 = phi i64 [ %851, %.preheader16.us.i.4 ], [ 0, %.split20.us.i.3 ]
  %695 = mul nuw nsw i64 %694, 65
  %696 = getelementptr double, ptr %693, i64 %695
  %697 = mul nuw nsw i64 %694, 17
  %698 = getelementptr double, ptr %3, i64 %697
  %699 = load double, ptr %698, align 8
  %700 = insertelement <1 x double> poison, double %699, i64 0
  %701 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %692, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %702 = shufflevector <4 x double> %701, <4 x double> poison, <1 x i32> zeroinitializer
  %703 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %704 = fmul <1 x double> %700, %702
  %705 = shufflevector <1 x double> %704, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %706 = fadd <4 x double> %703, %705
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %706, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %707 = getelementptr double, ptr %698, i64 1
  %708 = load double, ptr %707, align 8
  %709 = insertelement <1 x double> poison, double %708, i64 0
  %710 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.1, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %711 = shufflevector <4 x double> %710, <4 x double> poison, <1 x i32> zeroinitializer
  %712 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %713 = fmul <1 x double> %709, %711
  %714 = shufflevector <1 x double> %713, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %715 = fadd <4 x double> %712, %714
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %715, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %716 = getelementptr double, ptr %698, i64 2
  %717 = load double, ptr %716, align 8
  %718 = insertelement <1 x double> poison, double %717, i64 0
  %719 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.2, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %720 = shufflevector <4 x double> %719, <4 x double> poison, <1 x i32> zeroinitializer
  %721 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %722 = fmul <1 x double> %718, %720
  %723 = shufflevector <1 x double> %722, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %724 = fadd <4 x double> %721, %723
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %724, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %725 = getelementptr double, ptr %698, i64 3
  %726 = load double, ptr %725, align 8
  %727 = insertelement <1 x double> poison, double %726, i64 0
  %728 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.3, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %729 = shufflevector <4 x double> %728, <4 x double> poison, <1 x i32> zeroinitializer
  %730 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %731 = fmul <1 x double> %727, %729
  %732 = shufflevector <1 x double> %731, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %733 = fadd <4 x double> %730, %732
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %733, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %734 = getelementptr double, ptr %698, i64 4
  %735 = load double, ptr %734, align 8
  %736 = insertelement <1 x double> poison, double %735, i64 0
  %737 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.4, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %738 = shufflevector <4 x double> %737, <4 x double> poison, <1 x i32> zeroinitializer
  %739 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %740 = fmul <1 x double> %736, %738
  %741 = shufflevector <1 x double> %740, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %742 = fadd <4 x double> %739, %741
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %742, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %743 = getelementptr double, ptr %698, i64 5
  %744 = load double, ptr %743, align 8
  %745 = insertelement <1 x double> poison, double %744, i64 0
  %746 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.5, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %747 = shufflevector <4 x double> %746, <4 x double> poison, <1 x i32> zeroinitializer
  %748 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %749 = fmul <1 x double> %745, %747
  %750 = shufflevector <1 x double> %749, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %751 = fadd <4 x double> %748, %750
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %751, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %752 = getelementptr double, ptr %698, i64 6
  %753 = load double, ptr %752, align 8
  %754 = insertelement <1 x double> poison, double %753, i64 0
  %755 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.6, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %756 = shufflevector <4 x double> %755, <4 x double> poison, <1 x i32> zeroinitializer
  %757 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %758 = fmul <1 x double> %754, %756
  %759 = shufflevector <1 x double> %758, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %760 = fadd <4 x double> %757, %759
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %760, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %761 = getelementptr double, ptr %698, i64 7
  %762 = load double, ptr %761, align 8
  %763 = insertelement <1 x double> poison, double %762, i64 0
  %764 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.7, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %765 = shufflevector <4 x double> %764, <4 x double> poison, <1 x i32> zeroinitializer
  %766 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %767 = fmul <1 x double> %763, %765
  %768 = shufflevector <1 x double> %767, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %769 = fadd <4 x double> %766, %768
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %769, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %770 = getelementptr double, ptr %698, i64 8
  %771 = load double, ptr %770, align 8
  %772 = insertelement <1 x double> poison, double %771, i64 0
  %773 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.8, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %774 = shufflevector <4 x double> %773, <4 x double> poison, <1 x i32> zeroinitializer
  %775 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %776 = fmul <1 x double> %772, %774
  %777 = shufflevector <1 x double> %776, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %778 = fadd <4 x double> %775, %777
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %778, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %779 = getelementptr double, ptr %698, i64 9
  %780 = load double, ptr %779, align 8
  %781 = insertelement <1 x double> poison, double %780, i64 0
  %782 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.9, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %783 = shufflevector <4 x double> %782, <4 x double> poison, <1 x i32> zeroinitializer
  %784 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %785 = fmul <1 x double> %781, %783
  %786 = shufflevector <1 x double> %785, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %787 = fadd <4 x double> %784, %786
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %787, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %788 = getelementptr double, ptr %698, i64 10
  %789 = load double, ptr %788, align 8
  %790 = insertelement <1 x double> poison, double %789, i64 0
  %791 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.10, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %792 = shufflevector <4 x double> %791, <4 x double> poison, <1 x i32> zeroinitializer
  %793 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %794 = fmul <1 x double> %790, %792
  %795 = shufflevector <1 x double> %794, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %796 = fadd <4 x double> %793, %795
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %796, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %797 = getelementptr double, ptr %698, i64 11
  %798 = load double, ptr %797, align 8
  %799 = insertelement <1 x double> poison, double %798, i64 0
  %800 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.11, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %801 = shufflevector <4 x double> %800, <4 x double> poison, <1 x i32> zeroinitializer
  %802 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %803 = fmul <1 x double> %799, %801
  %804 = shufflevector <1 x double> %803, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %805 = fadd <4 x double> %802, %804
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %805, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %806 = getelementptr double, ptr %698, i64 12
  %807 = load double, ptr %806, align 8
  %808 = insertelement <1 x double> poison, double %807, i64 0
  %809 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.12, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %810 = shufflevector <4 x double> %809, <4 x double> poison, <1 x i32> zeroinitializer
  %811 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %812 = fmul <1 x double> %808, %810
  %813 = shufflevector <1 x double> %812, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %814 = fadd <4 x double> %811, %813
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %814, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %815 = getelementptr double, ptr %698, i64 13
  %816 = load double, ptr %815, align 8
  %817 = insertelement <1 x double> poison, double %816, i64 0
  %818 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.13, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %819 = shufflevector <4 x double> %818, <4 x double> poison, <1 x i32> zeroinitializer
  %820 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %821 = fmul <1 x double> %817, %819
  %822 = shufflevector <1 x double> %821, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %823 = fadd <4 x double> %820, %822
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %823, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %824 = getelementptr double, ptr %698, i64 14
  %825 = load double, ptr %824, align 8
  %826 = insertelement <1 x double> poison, double %825, i64 0
  %827 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.14, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %828 = shufflevector <4 x double> %827, <4 x double> poison, <1 x i32> zeroinitializer
  %829 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %830 = fmul <1 x double> %826, %828
  %831 = shufflevector <1 x double> %830, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %832 = fadd <4 x double> %829, %831
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %832, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %833 = getelementptr double, ptr %698, i64 15
  %834 = load double, ptr %833, align 8
  %835 = insertelement <1 x double> poison, double %834, i64 0
  %836 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.15, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %837 = shufflevector <4 x double> %836, <4 x double> poison, <1 x i32> zeroinitializer
  %838 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %839 = fmul <1 x double> %835, %837
  %840 = shufflevector <1 x double> %839, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %841 = fadd <4 x double> %838, %840
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %841, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %842 = getelementptr double, ptr %698, i64 16
  %843 = load double, ptr %842, align 8
  %844 = insertelement <1 x double> poison, double %843, i64 0
  %845 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.i.4.16, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %846 = shufflevector <4 x double> %845, <4 x double> poison, <1 x i32> zeroinitializer
  %847 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %848 = fmul <1 x double> %844, %846
  %849 = shufflevector <1 x double> %848, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %850 = fadd <4 x double> %847, %849
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %850, ptr %696, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %851 = add nuw nsw i64 %694, 1
  %exitcond22.not.i.4 = icmp eq i64 %851, 16
  br i1 %exitcond22.not.i.4, label %.split20.us.i.4, label %.preheader16.us.i.4

.split20.us.i.4:                                  ; preds = %.preheader16.us.i.4
  %852 = getelementptr double, ptr %9, i64 1040
  %invariant.gep.i = getelementptr double, ptr %3, i64 272
  br label %.preheader16.us.1.i

.preheader16.us.1.i:                              ; preds = %._crit_edge.us.1.i, %.split20.us.i.4
  %853 = phi i64 [ %1020, %._crit_edge.us.1.i ], [ 0, %.split20.us.i.4 ]
  %854 = mul nuw nsw i64 %853, 17
  %855 = mul nuw nsw i64 %853, 65
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %854
  %856 = getelementptr double, ptr %852, i64 %855
  %.promoted90 = load <4 x double>, ptr %856, align 8
  br label %.critedge.us.1.i

.critedge.us.1.i:                                 ; preds = %.critedge.us.1.i.1133, %.preheader16.us.1.i
  %857 = phi <4 x double> [ %.promoted90, %.preheader16.us.1.i ], [ %895, %.critedge.us.1.i.1133 ]
  %858 = phi i64 [ 0, %.preheader16.us.1.i ], [ %896, %.critedge.us.1.i.1133 ]
  %859 = mul nuw nsw i64 %858, 65
  %860 = getelementptr double, ptr %gep.i, i64 %858
  %861 = load double, ptr %860, align 8
  %862 = insertelement <1 x double> poison, double %861, i64 0
  %gep.us.1.i = getelementptr double, ptr %6, i64 %859
  %unmaskedload56 = load <4 x double>, ptr %gep.us.1.i, align 8
  %863 = shufflevector <4 x double> %unmaskedload56, <4 x double> poison, <1 x i32> zeroinitializer
  %864 = shufflevector <4 x double> %unmaskedload56, <4 x double> poison, <1 x i32> <i32 1>
  %865 = shufflevector <4 x double> %unmaskedload56, <4 x double> poison, <1 x i32> <i32 2>
  %866 = shufflevector <4 x double> %unmaskedload56, <4 x double> poison, <1 x i32> <i32 3>
  %867 = fmul <1 x double> %862, %863
  %868 = fmul <1 x double> %862, %864
  %869 = fmul <1 x double> %862, %865
  %870 = shufflevector <1 x double> %869, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %871 = fmul <1 x double> %862, %866
  %872 = shufflevector <1 x double> %871, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %873 = shufflevector <1 x double> %867, <1 x double> %868, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %874 = shufflevector <4 x double> %873, <4 x double> %870, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %875 = shufflevector <4 x double> %874, <4 x double> %872, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %876 = fadd <4 x double> %857, %875
  store <4 x double> %876, ptr %856, align 8
  %877 = or disjoint i64 %858, 1
  %exitcond.1.not.i = icmp eq i64 %877, 17
  br i1 %exitcond.1.not.i, label %.preheader.us.1.i.113, label %.critedge.us.1.i.1133

.critedge.us.1.i.1133:                            ; preds = %.critedge.us.1.i
  %878 = mul nuw nsw i64 %877, 65
  %879 = getelementptr double, ptr %gep.i, i64 %877
  %880 = load double, ptr %879, align 8
  %881 = insertelement <1 x double> poison, double %880, i64 0
  %gep.us.1.i.1131 = getelementptr double, ptr %6, i64 %878
  %unmaskedload56.1 = load <4 x double>, ptr %gep.us.1.i.1131, align 8
  %882 = shufflevector <4 x double> %unmaskedload56.1, <4 x double> poison, <1 x i32> zeroinitializer
  %883 = shufflevector <4 x double> %unmaskedload56.1, <4 x double> poison, <1 x i32> <i32 1>
  %884 = shufflevector <4 x double> %unmaskedload56.1, <4 x double> poison, <1 x i32> <i32 2>
  %885 = shufflevector <4 x double> %unmaskedload56.1, <4 x double> poison, <1 x i32> <i32 3>
  %886 = fmul <1 x double> %881, %882
  %887 = fmul <1 x double> %881, %883
  %888 = fmul <1 x double> %881, %884
  %889 = shufflevector <1 x double> %888, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %890 = fmul <1 x double> %881, %885
  %891 = shufflevector <1 x double> %890, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %892 = shufflevector <1 x double> %886, <1 x double> %887, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %893 = shufflevector <4 x double> %892, <4 x double> %889, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %894 = shufflevector <4 x double> %893, <4 x double> %891, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %895 = fadd <4 x double> %876, %894
  store <4 x double> %895, ptr %856, align 8
  %896 = add nuw nsw i64 %858, 2
  br label %.critedge.us.1.i

.preheader.us.1.i.113:                            ; preds = %.critedge.us.1.i
  %897 = getelementptr double, ptr %856, i64 4
  %.promoted89 = load <4 x double>, ptr %897, align 8
  br label %.critedge.us.1.i.116

.critedge.us.1.i.116:                             ; preds = %.critedge.us.1.i.116.1, %.preheader.us.1.i.113
  %898 = phi <4 x double> [ %.promoted89, %.preheader.us.1.i.113 ], [ %936, %.critedge.us.1.i.116.1 ]
  %899 = phi i64 [ 0, %.preheader.us.1.i.113 ], [ %937, %.critedge.us.1.i.116.1 ]
  %900 = mul nuw nsw i64 %899, 65
  %901 = getelementptr double, ptr %gep.i, i64 %899
  %902 = load double, ptr %901, align 8
  %903 = insertelement <1 x double> poison, double %902, i64 0
  %gep.us.1.i.114 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %900
  %unmaskedload58 = load <4 x double>, ptr %gep.us.1.i.114, align 8
  %904 = shufflevector <4 x double> %unmaskedload58, <4 x double> poison, <1 x i32> zeroinitializer
  %905 = shufflevector <4 x double> %unmaskedload58, <4 x double> poison, <1 x i32> <i32 1>
  %906 = shufflevector <4 x double> %unmaskedload58, <4 x double> poison, <1 x i32> <i32 2>
  %907 = shufflevector <4 x double> %unmaskedload58, <4 x double> poison, <1 x i32> <i32 3>
  %908 = fmul <1 x double> %903, %904
  %909 = fmul <1 x double> %903, %905
  %910 = fmul <1 x double> %903, %906
  %911 = shufflevector <1 x double> %910, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %912 = fmul <1 x double> %903, %907
  %913 = shufflevector <1 x double> %912, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %914 = shufflevector <1 x double> %908, <1 x double> %909, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %915 = shufflevector <4 x double> %914, <4 x double> %911, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %916 = shufflevector <4 x double> %915, <4 x double> %913, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %917 = fadd <4 x double> %898, %916
  store <4 x double> %917, ptr %897, align 8
  %918 = or disjoint i64 %899, 1
  %exitcond.1.not.i.115 = icmp eq i64 %918, 17
  br i1 %exitcond.1.not.i.115, label %.preheader.us.1.i.217, label %.critedge.us.1.i.116.1

.critedge.us.1.i.116.1:                           ; preds = %.critedge.us.1.i.116
  %919 = mul nuw nsw i64 %918, 65
  %920 = getelementptr double, ptr %gep.i, i64 %918
  %921 = load double, ptr %920, align 8
  %922 = insertelement <1 x double> poison, double %921, i64 0
  %gep.us.1.i.114.1 = getelementptr double, ptr %invariant.gep.us.i.1, i64 %919
  %unmaskedload58.1 = load <4 x double>, ptr %gep.us.1.i.114.1, align 8
  %923 = shufflevector <4 x double> %unmaskedload58.1, <4 x double> poison, <1 x i32> zeroinitializer
  %924 = shufflevector <4 x double> %unmaskedload58.1, <4 x double> poison, <1 x i32> <i32 1>
  %925 = shufflevector <4 x double> %unmaskedload58.1, <4 x double> poison, <1 x i32> <i32 2>
  %926 = shufflevector <4 x double> %unmaskedload58.1, <4 x double> poison, <1 x i32> <i32 3>
  %927 = fmul <1 x double> %922, %923
  %928 = fmul <1 x double> %922, %924
  %929 = fmul <1 x double> %922, %925
  %930 = shufflevector <1 x double> %929, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %931 = fmul <1 x double> %922, %926
  %932 = shufflevector <1 x double> %931, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %933 = shufflevector <1 x double> %927, <1 x double> %928, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %934 = shufflevector <4 x double> %933, <4 x double> %930, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %935 = shufflevector <4 x double> %934, <4 x double> %932, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %936 = fadd <4 x double> %917, %935
  store <4 x double> %936, ptr %897, align 8
  %937 = add nuw nsw i64 %899, 2
  br label %.critedge.us.1.i.116

.preheader.us.1.i.217:                            ; preds = %.critedge.us.1.i.116
  %938 = getelementptr double, ptr %856, i64 8
  %.promoted88 = load <4 x double>, ptr %938, align 8
  br label %.critedge.us.1.i.220

.critedge.us.1.i.220:                             ; preds = %.critedge.us.1.i.220.1, %.preheader.us.1.i.217
  %939 = phi <4 x double> [ %.promoted88, %.preheader.us.1.i.217 ], [ %977, %.critedge.us.1.i.220.1 ]
  %940 = phi i64 [ 0, %.preheader.us.1.i.217 ], [ %978, %.critedge.us.1.i.220.1 ]
  %941 = mul nuw nsw i64 %940, 65
  %942 = getelementptr double, ptr %gep.i, i64 %940
  %943 = load double, ptr %942, align 8
  %944 = insertelement <1 x double> poison, double %943, i64 0
  %gep.us.1.i.218 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %941
  %unmaskedload60 = load <4 x double>, ptr %gep.us.1.i.218, align 8
  %945 = shufflevector <4 x double> %unmaskedload60, <4 x double> poison, <1 x i32> zeroinitializer
  %946 = shufflevector <4 x double> %unmaskedload60, <4 x double> poison, <1 x i32> <i32 1>
  %947 = shufflevector <4 x double> %unmaskedload60, <4 x double> poison, <1 x i32> <i32 2>
  %948 = shufflevector <4 x double> %unmaskedload60, <4 x double> poison, <1 x i32> <i32 3>
  %949 = fmul <1 x double> %944, %945
  %950 = fmul <1 x double> %944, %946
  %951 = fmul <1 x double> %944, %947
  %952 = shufflevector <1 x double> %951, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %953 = fmul <1 x double> %944, %948
  %954 = shufflevector <1 x double> %953, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %955 = shufflevector <1 x double> %949, <1 x double> %950, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %956 = shufflevector <4 x double> %955, <4 x double> %952, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %957 = shufflevector <4 x double> %956, <4 x double> %954, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %958 = fadd <4 x double> %939, %957
  store <4 x double> %958, ptr %938, align 8
  %959 = or disjoint i64 %940, 1
  %exitcond.1.not.i.219 = icmp eq i64 %959, 17
  br i1 %exitcond.1.not.i.219, label %.preheader.us.1.i.321, label %.critedge.us.1.i.220.1

.critedge.us.1.i.220.1:                           ; preds = %.critedge.us.1.i.220
  %960 = mul nuw nsw i64 %959, 65
  %961 = getelementptr double, ptr %gep.i, i64 %959
  %962 = load double, ptr %961, align 8
  %963 = insertelement <1 x double> poison, double %962, i64 0
  %gep.us.1.i.218.1 = getelementptr double, ptr %invariant.gep.us.i.2, i64 %960
  %unmaskedload60.1 = load <4 x double>, ptr %gep.us.1.i.218.1, align 8
  %964 = shufflevector <4 x double> %unmaskedload60.1, <4 x double> poison, <1 x i32> zeroinitializer
  %965 = shufflevector <4 x double> %unmaskedload60.1, <4 x double> poison, <1 x i32> <i32 1>
  %966 = shufflevector <4 x double> %unmaskedload60.1, <4 x double> poison, <1 x i32> <i32 2>
  %967 = shufflevector <4 x double> %unmaskedload60.1, <4 x double> poison, <1 x i32> <i32 3>
  %968 = fmul <1 x double> %963, %964
  %969 = fmul <1 x double> %963, %965
  %970 = fmul <1 x double> %963, %966
  %971 = shufflevector <1 x double> %970, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %972 = fmul <1 x double> %963, %967
  %973 = shufflevector <1 x double> %972, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %974 = shufflevector <1 x double> %968, <1 x double> %969, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %975 = shufflevector <4 x double> %974, <4 x double> %971, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %976 = shufflevector <4 x double> %975, <4 x double> %973, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %977 = fadd <4 x double> %958, %976
  store <4 x double> %977, ptr %938, align 8
  %978 = add nuw nsw i64 %940, 2
  br label %.critedge.us.1.i.220

.preheader.us.1.i.321:                            ; preds = %.critedge.us.1.i.220
  %979 = getelementptr double, ptr %856, i64 12
  %.promoted = load <4 x double>, ptr %979, align 8
  br label %.critedge.us.1.i.324

.critedge.us.1.i.324:                             ; preds = %.critedge.us.1.i.324.1, %.preheader.us.1.i.321
  %980 = phi <4 x double> [ %.promoted, %.preheader.us.1.i.321 ], [ %1018, %.critedge.us.1.i.324.1 ]
  %981 = phi i64 [ 0, %.preheader.us.1.i.321 ], [ %1019, %.critedge.us.1.i.324.1 ]
  %982 = mul nuw nsw i64 %981, 65
  %983 = getelementptr double, ptr %gep.i, i64 %981
  %984 = load double, ptr %983, align 8
  %985 = insertelement <1 x double> poison, double %984, i64 0
  %gep.us.1.i.322 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %982
  %unmaskedload62 = load <4 x double>, ptr %gep.us.1.i.322, align 8
  %986 = shufflevector <4 x double> %unmaskedload62, <4 x double> poison, <1 x i32> zeroinitializer
  %987 = shufflevector <4 x double> %unmaskedload62, <4 x double> poison, <1 x i32> <i32 1>
  %988 = shufflevector <4 x double> %unmaskedload62, <4 x double> poison, <1 x i32> <i32 2>
  %989 = shufflevector <4 x double> %unmaskedload62, <4 x double> poison, <1 x i32> <i32 3>
  %990 = fmul <1 x double> %985, %986
  %991 = fmul <1 x double> %985, %987
  %992 = fmul <1 x double> %985, %988
  %993 = shufflevector <1 x double> %992, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %994 = fmul <1 x double> %985, %989
  %995 = shufflevector <1 x double> %994, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %996 = shufflevector <1 x double> %990, <1 x double> %991, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %997 = shufflevector <4 x double> %996, <4 x double> %993, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %998 = shufflevector <4 x double> %997, <4 x double> %995, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %999 = fadd <4 x double> %980, %998
  store <4 x double> %999, ptr %979, align 8
  %1000 = or disjoint i64 %981, 1
  %exitcond.1.not.i.323 = icmp eq i64 %1000, 17
  br i1 %exitcond.1.not.i.323, label %._crit_edge.us.1.i, label %.critedge.us.1.i.324.1

.critedge.us.1.i.324.1:                           ; preds = %.critedge.us.1.i.324
  %1001 = mul nuw nsw i64 %1000, 65
  %1002 = getelementptr double, ptr %gep.i, i64 %1000
  %1003 = load double, ptr %1002, align 8
  %1004 = insertelement <1 x double> poison, double %1003, i64 0
  %gep.us.1.i.322.1 = getelementptr double, ptr %invariant.gep.us.i.3, i64 %1001
  %unmaskedload62.1 = load <4 x double>, ptr %gep.us.1.i.322.1, align 8
  %1005 = shufflevector <4 x double> %unmaskedload62.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1006 = shufflevector <4 x double> %unmaskedload62.1, <4 x double> poison, <1 x i32> <i32 1>
  %1007 = shufflevector <4 x double> %unmaskedload62.1, <4 x double> poison, <1 x i32> <i32 2>
  %1008 = shufflevector <4 x double> %unmaskedload62.1, <4 x double> poison, <1 x i32> <i32 3>
  %1009 = fmul <1 x double> %1004, %1005
  %1010 = fmul <1 x double> %1004, %1006
  %1011 = fmul <1 x double> %1004, %1007
  %1012 = shufflevector <1 x double> %1011, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1013 = fmul <1 x double> %1004, %1008
  %1014 = shufflevector <1 x double> %1013, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1015 = shufflevector <1 x double> %1009, <1 x double> %1010, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1016 = shufflevector <4 x double> %1015, <4 x double> %1012, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1017 = shufflevector <4 x double> %1016, <4 x double> %1014, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1018 = fadd <4 x double> %999, %1017
  store <4 x double> %1018, ptr %979, align 8
  %1019 = add nuw nsw i64 %981, 2
  br label %.critedge.us.1.i.324

._crit_edge.us.1.i:                               ; preds = %.critedge.us.1.i.324
  %1020 = add nuw nsw i64 %853, 1
  %exitcond22.1.not.i = icmp eq i64 %1020, 15
  br i1 %exitcond22.1.not.i, label %.split20.us.1.i, label %.preheader16.us.1.i

.split20.us.1.i:                                  ; preds = %._crit_edge.us.1.i
  %1021 = getelementptr double, ptr %9, i64 1056
  br label %.preheader16.us.1.i.1

.preheader16.us.1.i.1:                            ; preds = %._crit_edge.us.1.i.1, %.split20.us.1.i
  %1022 = phi i64 [ %1189, %._crit_edge.us.1.i.1 ], [ 0, %.split20.us.1.i ]
  %1023 = mul nuw nsw i64 %1022, 17
  %1024 = mul nuw nsw i64 %1022, 65
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %1023
  %1025 = getelementptr double, ptr %1021, i64 %1024
  %.promoted94 = load <4 x double>, ptr %1025, align 8
  br label %.critedge.us.1.i.1

.critedge.us.1.i.1:                               ; preds = %.critedge.us.1.i.1.1136, %.preheader16.us.1.i.1
  %1026 = phi <4 x double> [ %.promoted94, %.preheader16.us.1.i.1 ], [ %1064, %.critedge.us.1.i.1.1136 ]
  %1027 = phi i64 [ 0, %.preheader16.us.1.i.1 ], [ %1065, %.critedge.us.1.i.1.1136 ]
  %1028 = mul nuw nsw i64 %1027, 65
  %1029 = getelementptr double, ptr %gep.i.1, i64 %1027
  %1030 = load double, ptr %1029, align 8
  %1031 = insertelement <1 x double> poison, double %1030, i64 0
  %gep.us.1.i.1 = getelementptr double, ptr %179, i64 %1028
  %unmaskedload64 = load <4 x double>, ptr %gep.us.1.i.1, align 8
  %1032 = shufflevector <4 x double> %unmaskedload64, <4 x double> poison, <1 x i32> zeroinitializer
  %1033 = shufflevector <4 x double> %unmaskedload64, <4 x double> poison, <1 x i32> <i32 1>
  %1034 = shufflevector <4 x double> %unmaskedload64, <4 x double> poison, <1 x i32> <i32 2>
  %1035 = shufflevector <4 x double> %unmaskedload64, <4 x double> poison, <1 x i32> <i32 3>
  %1036 = fmul <1 x double> %1031, %1032
  %1037 = fmul <1 x double> %1031, %1033
  %1038 = fmul <1 x double> %1031, %1034
  %1039 = shufflevector <1 x double> %1038, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1040 = fmul <1 x double> %1031, %1035
  %1041 = shufflevector <1 x double> %1040, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1042 = shufflevector <1 x double> %1036, <1 x double> %1037, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1043 = shufflevector <4 x double> %1042, <4 x double> %1039, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1044 = shufflevector <4 x double> %1043, <4 x double> %1041, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1045 = fadd <4 x double> %1026, %1044
  store <4 x double> %1045, ptr %1025, align 8
  %1046 = or disjoint i64 %1027, 1
  %exitcond.1.not.i.1 = icmp eq i64 %1046, 17
  br i1 %exitcond.1.not.i.1, label %.preheader.us.1.i.1.1, label %.critedge.us.1.i.1.1136

.critedge.us.1.i.1.1136:                          ; preds = %.critedge.us.1.i.1
  %1047 = mul nuw nsw i64 %1046, 65
  %1048 = getelementptr double, ptr %gep.i.1, i64 %1046
  %1049 = load double, ptr %1048, align 8
  %1050 = insertelement <1 x double> poison, double %1049, i64 0
  %gep.us.1.i.1.1134 = getelementptr double, ptr %179, i64 %1047
  %unmaskedload64.1 = load <4 x double>, ptr %gep.us.1.i.1.1134, align 8
  %1051 = shufflevector <4 x double> %unmaskedload64.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1052 = shufflevector <4 x double> %unmaskedload64.1, <4 x double> poison, <1 x i32> <i32 1>
  %1053 = shufflevector <4 x double> %unmaskedload64.1, <4 x double> poison, <1 x i32> <i32 2>
  %1054 = shufflevector <4 x double> %unmaskedload64.1, <4 x double> poison, <1 x i32> <i32 3>
  %1055 = fmul <1 x double> %1050, %1051
  %1056 = fmul <1 x double> %1050, %1052
  %1057 = fmul <1 x double> %1050, %1053
  %1058 = shufflevector <1 x double> %1057, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1059 = fmul <1 x double> %1050, %1054
  %1060 = shufflevector <1 x double> %1059, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1061 = shufflevector <1 x double> %1055, <1 x double> %1056, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1062 = shufflevector <4 x double> %1061, <4 x double> %1058, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1063 = shufflevector <4 x double> %1062, <4 x double> %1060, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1064 = fadd <4 x double> %1045, %1063
  store <4 x double> %1064, ptr %1025, align 8
  %1065 = add nuw nsw i64 %1027, 2
  br label %.critedge.us.1.i.1

.preheader.us.1.i.1.1:                            ; preds = %.critedge.us.1.i.1
  %1066 = getelementptr double, ptr %1025, i64 4
  %.promoted93 = load <4 x double>, ptr %1066, align 8
  br label %.critedge.us.1.i.1.1

.critedge.us.1.i.1.1:                             ; preds = %.critedge.us.1.i.1.1.1, %.preheader.us.1.i.1.1
  %1067 = phi <4 x double> [ %.promoted93, %.preheader.us.1.i.1.1 ], [ %1105, %.critedge.us.1.i.1.1.1 ]
  %1068 = phi i64 [ 0, %.preheader.us.1.i.1.1 ], [ %1106, %.critedge.us.1.i.1.1.1 ]
  %1069 = mul nuw nsw i64 %1068, 65
  %1070 = getelementptr double, ptr %gep.i.1, i64 %1068
  %1071 = load double, ptr %1070, align 8
  %1072 = insertelement <1 x double> poison, double %1071, i64 0
  %gep.us.1.i.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %1069
  %unmaskedload66 = load <4 x double>, ptr %gep.us.1.i.1.1, align 8
  %1073 = shufflevector <4 x double> %unmaskedload66, <4 x double> poison, <1 x i32> zeroinitializer
  %1074 = shufflevector <4 x double> %unmaskedload66, <4 x double> poison, <1 x i32> <i32 1>
  %1075 = shufflevector <4 x double> %unmaskedload66, <4 x double> poison, <1 x i32> <i32 2>
  %1076 = shufflevector <4 x double> %unmaskedload66, <4 x double> poison, <1 x i32> <i32 3>
  %1077 = fmul <1 x double> %1072, %1073
  %1078 = fmul <1 x double> %1072, %1074
  %1079 = fmul <1 x double> %1072, %1075
  %1080 = shufflevector <1 x double> %1079, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1081 = fmul <1 x double> %1072, %1076
  %1082 = shufflevector <1 x double> %1081, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1083 = shufflevector <1 x double> %1077, <1 x double> %1078, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1084 = shufflevector <4 x double> %1083, <4 x double> %1080, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1085 = shufflevector <4 x double> %1084, <4 x double> %1082, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1086 = fadd <4 x double> %1067, %1085
  store <4 x double> %1086, ptr %1066, align 8
  %1087 = or disjoint i64 %1068, 1
  %exitcond.1.not.i.1.1 = icmp eq i64 %1087, 17
  br i1 %exitcond.1.not.i.1.1, label %.preheader.us.1.i.1.2, label %.critedge.us.1.i.1.1.1

.critedge.us.1.i.1.1.1:                           ; preds = %.critedge.us.1.i.1.1
  %1088 = mul nuw nsw i64 %1087, 65
  %1089 = getelementptr double, ptr %gep.i.1, i64 %1087
  %1090 = load double, ptr %1089, align 8
  %1091 = insertelement <1 x double> poison, double %1090, i64 0
  %gep.us.1.i.1.1.1 = getelementptr double, ptr %invariant.gep.us.i.1.1, i64 %1088
  %unmaskedload66.1 = load <4 x double>, ptr %gep.us.1.i.1.1.1, align 8
  %1092 = shufflevector <4 x double> %unmaskedload66.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1093 = shufflevector <4 x double> %unmaskedload66.1, <4 x double> poison, <1 x i32> <i32 1>
  %1094 = shufflevector <4 x double> %unmaskedload66.1, <4 x double> poison, <1 x i32> <i32 2>
  %1095 = shufflevector <4 x double> %unmaskedload66.1, <4 x double> poison, <1 x i32> <i32 3>
  %1096 = fmul <1 x double> %1091, %1092
  %1097 = fmul <1 x double> %1091, %1093
  %1098 = fmul <1 x double> %1091, %1094
  %1099 = shufflevector <1 x double> %1098, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1100 = fmul <1 x double> %1091, %1095
  %1101 = shufflevector <1 x double> %1100, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1102 = shufflevector <1 x double> %1096, <1 x double> %1097, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1103 = shufflevector <4 x double> %1102, <4 x double> %1099, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1104 = shufflevector <4 x double> %1103, <4 x double> %1101, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1105 = fadd <4 x double> %1086, %1104
  store <4 x double> %1105, ptr %1066, align 8
  %1106 = add nuw nsw i64 %1068, 2
  br label %.critedge.us.1.i.1.1

.preheader.us.1.i.1.2:                            ; preds = %.critedge.us.1.i.1.1
  %1107 = getelementptr double, ptr %1025, i64 8
  %.promoted92 = load <4 x double>, ptr %1107, align 8
  br label %.critedge.us.1.i.1.2

.critedge.us.1.i.1.2:                             ; preds = %.critedge.us.1.i.1.2.1, %.preheader.us.1.i.1.2
  %1108 = phi <4 x double> [ %.promoted92, %.preheader.us.1.i.1.2 ], [ %1146, %.critedge.us.1.i.1.2.1 ]
  %1109 = phi i64 [ 0, %.preheader.us.1.i.1.2 ], [ %1147, %.critedge.us.1.i.1.2.1 ]
  %1110 = mul nuw nsw i64 %1109, 65
  %1111 = getelementptr double, ptr %gep.i.1, i64 %1109
  %1112 = load double, ptr %1111, align 8
  %1113 = insertelement <1 x double> poison, double %1112, i64 0
  %gep.us.1.i.1.2 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %1110
  %unmaskedload68 = load <4 x double>, ptr %gep.us.1.i.1.2, align 8
  %1114 = shufflevector <4 x double> %unmaskedload68, <4 x double> poison, <1 x i32> zeroinitializer
  %1115 = shufflevector <4 x double> %unmaskedload68, <4 x double> poison, <1 x i32> <i32 1>
  %1116 = shufflevector <4 x double> %unmaskedload68, <4 x double> poison, <1 x i32> <i32 2>
  %1117 = shufflevector <4 x double> %unmaskedload68, <4 x double> poison, <1 x i32> <i32 3>
  %1118 = fmul <1 x double> %1113, %1114
  %1119 = fmul <1 x double> %1113, %1115
  %1120 = fmul <1 x double> %1113, %1116
  %1121 = shufflevector <1 x double> %1120, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1122 = fmul <1 x double> %1113, %1117
  %1123 = shufflevector <1 x double> %1122, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1124 = shufflevector <1 x double> %1118, <1 x double> %1119, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1125 = shufflevector <4 x double> %1124, <4 x double> %1121, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1126 = shufflevector <4 x double> %1125, <4 x double> %1123, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1127 = fadd <4 x double> %1108, %1126
  store <4 x double> %1127, ptr %1107, align 8
  %1128 = or disjoint i64 %1109, 1
  %exitcond.1.not.i.1.2 = icmp eq i64 %1128, 17
  br i1 %exitcond.1.not.i.1.2, label %.preheader.us.1.i.1.3, label %.critedge.us.1.i.1.2.1

.critedge.us.1.i.1.2.1:                           ; preds = %.critedge.us.1.i.1.2
  %1129 = mul nuw nsw i64 %1128, 65
  %1130 = getelementptr double, ptr %gep.i.1, i64 %1128
  %1131 = load double, ptr %1130, align 8
  %1132 = insertelement <1 x double> poison, double %1131, i64 0
  %gep.us.1.i.1.2.1 = getelementptr double, ptr %invariant.gep.us.i.1.2, i64 %1129
  %unmaskedload68.1 = load <4 x double>, ptr %gep.us.1.i.1.2.1, align 8
  %1133 = shufflevector <4 x double> %unmaskedload68.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1134 = shufflevector <4 x double> %unmaskedload68.1, <4 x double> poison, <1 x i32> <i32 1>
  %1135 = shufflevector <4 x double> %unmaskedload68.1, <4 x double> poison, <1 x i32> <i32 2>
  %1136 = shufflevector <4 x double> %unmaskedload68.1, <4 x double> poison, <1 x i32> <i32 3>
  %1137 = fmul <1 x double> %1132, %1133
  %1138 = fmul <1 x double> %1132, %1134
  %1139 = fmul <1 x double> %1132, %1135
  %1140 = shufflevector <1 x double> %1139, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1141 = fmul <1 x double> %1132, %1136
  %1142 = shufflevector <1 x double> %1141, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1143 = shufflevector <1 x double> %1137, <1 x double> %1138, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1144 = shufflevector <4 x double> %1143, <4 x double> %1140, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1145 = shufflevector <4 x double> %1144, <4 x double> %1142, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1146 = fadd <4 x double> %1127, %1145
  store <4 x double> %1146, ptr %1107, align 8
  %1147 = add nuw nsw i64 %1109, 2
  br label %.critedge.us.1.i.1.2

.preheader.us.1.i.1.3:                            ; preds = %.critedge.us.1.i.1.2
  %1148 = getelementptr double, ptr %1025, i64 12
  %.promoted91 = load <4 x double>, ptr %1148, align 8
  br label %.critedge.us.1.i.1.3

.critedge.us.1.i.1.3:                             ; preds = %.critedge.us.1.i.1.3.1, %.preheader.us.1.i.1.3
  %1149 = phi <4 x double> [ %.promoted91, %.preheader.us.1.i.1.3 ], [ %1187, %.critedge.us.1.i.1.3.1 ]
  %1150 = phi i64 [ 0, %.preheader.us.1.i.1.3 ], [ %1188, %.critedge.us.1.i.1.3.1 ]
  %1151 = mul nuw nsw i64 %1150, 65
  %1152 = getelementptr double, ptr %gep.i.1, i64 %1150
  %1153 = load double, ptr %1152, align 8
  %1154 = insertelement <1 x double> poison, double %1153, i64 0
  %gep.us.1.i.1.3 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %1151
  %unmaskedload70 = load <4 x double>, ptr %gep.us.1.i.1.3, align 8
  %1155 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> zeroinitializer
  %1156 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 1>
  %1157 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 2>
  %1158 = shufflevector <4 x double> %unmaskedload70, <4 x double> poison, <1 x i32> <i32 3>
  %1159 = fmul <1 x double> %1154, %1155
  %1160 = fmul <1 x double> %1154, %1156
  %1161 = fmul <1 x double> %1154, %1157
  %1162 = shufflevector <1 x double> %1161, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1163 = fmul <1 x double> %1154, %1158
  %1164 = shufflevector <1 x double> %1163, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1165 = shufflevector <1 x double> %1159, <1 x double> %1160, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1166 = shufflevector <4 x double> %1165, <4 x double> %1162, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1167 = shufflevector <4 x double> %1166, <4 x double> %1164, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1168 = fadd <4 x double> %1149, %1167
  store <4 x double> %1168, ptr %1148, align 8
  %1169 = or disjoint i64 %1150, 1
  %exitcond.1.not.i.1.3 = icmp eq i64 %1169, 17
  br i1 %exitcond.1.not.i.1.3, label %._crit_edge.us.1.i.1, label %.critedge.us.1.i.1.3.1

.critedge.us.1.i.1.3.1:                           ; preds = %.critedge.us.1.i.1.3
  %1170 = mul nuw nsw i64 %1169, 65
  %1171 = getelementptr double, ptr %gep.i.1, i64 %1169
  %1172 = load double, ptr %1171, align 8
  %1173 = insertelement <1 x double> poison, double %1172, i64 0
  %gep.us.1.i.1.3.1 = getelementptr double, ptr %invariant.gep.us.i.1.3, i64 %1170
  %unmaskedload70.1 = load <4 x double>, ptr %gep.us.1.i.1.3.1, align 8
  %1174 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1175 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 1>
  %1176 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 2>
  %1177 = shufflevector <4 x double> %unmaskedload70.1, <4 x double> poison, <1 x i32> <i32 3>
  %1178 = fmul <1 x double> %1173, %1174
  %1179 = fmul <1 x double> %1173, %1175
  %1180 = fmul <1 x double> %1173, %1176
  %1181 = shufflevector <1 x double> %1180, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1182 = fmul <1 x double> %1173, %1177
  %1183 = shufflevector <1 x double> %1182, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1184 = shufflevector <1 x double> %1178, <1 x double> %1179, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1185 = shufflevector <4 x double> %1184, <4 x double> %1181, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1186 = shufflevector <4 x double> %1185, <4 x double> %1183, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1187 = fadd <4 x double> %1168, %1186
  store <4 x double> %1187, ptr %1148, align 8
  %1188 = add nuw nsw i64 %1150, 2
  br label %.critedge.us.1.i.1.3

._crit_edge.us.1.i.1:                             ; preds = %.critedge.us.1.i.1.3
  %1189 = add nuw nsw i64 %1022, 1
  %exitcond22.1.not.i.1 = icmp eq i64 %1189, 15
  br i1 %exitcond22.1.not.i.1, label %.split20.us.1.i.1, label %.preheader16.us.1.i.1

.split20.us.1.i.1:                                ; preds = %._crit_edge.us.1.i.1
  %1190 = getelementptr double, ptr %9, i64 1072
  br label %.preheader16.us.1.i.2

.preheader16.us.1.i.2:                            ; preds = %._crit_edge.us.1.i.2, %.split20.us.1.i.1
  %1191 = phi i64 [ %1358, %._crit_edge.us.1.i.2 ], [ 0, %.split20.us.1.i.1 ]
  %1192 = mul nuw nsw i64 %1191, 17
  %1193 = mul nuw nsw i64 %1191, 65
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %1192
  %1194 = getelementptr double, ptr %1190, i64 %1193
  %.promoted98 = load <4 x double>, ptr %1194, align 8
  br label %.critedge.us.1.i.2

.critedge.us.1.i.2:                               ; preds = %.critedge.us.1.i.2.1139, %.preheader16.us.1.i.2
  %1195 = phi <4 x double> [ %.promoted98, %.preheader16.us.1.i.2 ], [ %1233, %.critedge.us.1.i.2.1139 ]
  %1196 = phi i64 [ 0, %.preheader16.us.1.i.2 ], [ %1234, %.critedge.us.1.i.2.1139 ]
  %1197 = mul nuw nsw i64 %1196, 65
  %1198 = getelementptr double, ptr %gep.i.2, i64 %1196
  %1199 = load double, ptr %1198, align 8
  %1200 = insertelement <1 x double> poison, double %1199, i64 0
  %gep.us.1.i.2 = getelementptr double, ptr %350, i64 %1197
  %unmaskedload72 = load <4 x double>, ptr %gep.us.1.i.2, align 8
  %1201 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> zeroinitializer
  %1202 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 1>
  %1203 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 2>
  %1204 = shufflevector <4 x double> %unmaskedload72, <4 x double> poison, <1 x i32> <i32 3>
  %1205 = fmul <1 x double> %1200, %1201
  %1206 = fmul <1 x double> %1200, %1202
  %1207 = fmul <1 x double> %1200, %1203
  %1208 = shufflevector <1 x double> %1207, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1209 = fmul <1 x double> %1200, %1204
  %1210 = shufflevector <1 x double> %1209, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1211 = shufflevector <1 x double> %1205, <1 x double> %1206, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1212 = shufflevector <4 x double> %1211, <4 x double> %1208, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1213 = shufflevector <4 x double> %1212, <4 x double> %1210, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1214 = fadd <4 x double> %1195, %1213
  store <4 x double> %1214, ptr %1194, align 8
  %1215 = or disjoint i64 %1196, 1
  %exitcond.1.not.i.2 = icmp eq i64 %1215, 17
  br i1 %exitcond.1.not.i.2, label %.preheader.us.1.i.2.1, label %.critedge.us.1.i.2.1139

.critedge.us.1.i.2.1139:                          ; preds = %.critedge.us.1.i.2
  %1216 = mul nuw nsw i64 %1215, 65
  %1217 = getelementptr double, ptr %gep.i.2, i64 %1215
  %1218 = load double, ptr %1217, align 8
  %1219 = insertelement <1 x double> poison, double %1218, i64 0
  %gep.us.1.i.2.1137 = getelementptr double, ptr %350, i64 %1216
  %unmaskedload72.1 = load <4 x double>, ptr %gep.us.1.i.2.1137, align 8
  %1220 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1221 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 1>
  %1222 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 2>
  %1223 = shufflevector <4 x double> %unmaskedload72.1, <4 x double> poison, <1 x i32> <i32 3>
  %1224 = fmul <1 x double> %1219, %1220
  %1225 = fmul <1 x double> %1219, %1221
  %1226 = fmul <1 x double> %1219, %1222
  %1227 = shufflevector <1 x double> %1226, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1228 = fmul <1 x double> %1219, %1223
  %1229 = shufflevector <1 x double> %1228, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1230 = shufflevector <1 x double> %1224, <1 x double> %1225, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1231 = shufflevector <4 x double> %1230, <4 x double> %1227, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1232 = shufflevector <4 x double> %1231, <4 x double> %1229, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1233 = fadd <4 x double> %1214, %1232
  store <4 x double> %1233, ptr %1194, align 8
  %1234 = add nuw nsw i64 %1196, 2
  br label %.critedge.us.1.i.2

.preheader.us.1.i.2.1:                            ; preds = %.critedge.us.1.i.2
  %1235 = getelementptr double, ptr %1194, i64 4
  %.promoted97 = load <4 x double>, ptr %1235, align 8
  br label %.critedge.us.1.i.2.1

.critedge.us.1.i.2.1:                             ; preds = %.critedge.us.1.i.2.1.1, %.preheader.us.1.i.2.1
  %1236 = phi <4 x double> [ %.promoted97, %.preheader.us.1.i.2.1 ], [ %1274, %.critedge.us.1.i.2.1.1 ]
  %1237 = phi i64 [ 0, %.preheader.us.1.i.2.1 ], [ %1275, %.critedge.us.1.i.2.1.1 ]
  %1238 = mul nuw nsw i64 %1237, 65
  %1239 = getelementptr double, ptr %gep.i.2, i64 %1237
  %1240 = load double, ptr %1239, align 8
  %1241 = insertelement <1 x double> poison, double %1240, i64 0
  %gep.us.1.i.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %1238
  %unmaskedload74 = load <4 x double>, ptr %gep.us.1.i.2.1, align 8
  %1242 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> zeroinitializer
  %1243 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 1>
  %1244 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 2>
  %1245 = shufflevector <4 x double> %unmaskedload74, <4 x double> poison, <1 x i32> <i32 3>
  %1246 = fmul <1 x double> %1241, %1242
  %1247 = fmul <1 x double> %1241, %1243
  %1248 = fmul <1 x double> %1241, %1244
  %1249 = shufflevector <1 x double> %1248, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1250 = fmul <1 x double> %1241, %1245
  %1251 = shufflevector <1 x double> %1250, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1252 = shufflevector <1 x double> %1246, <1 x double> %1247, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1253 = shufflevector <4 x double> %1252, <4 x double> %1249, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1254 = shufflevector <4 x double> %1253, <4 x double> %1251, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1255 = fadd <4 x double> %1236, %1254
  store <4 x double> %1255, ptr %1235, align 8
  %1256 = or disjoint i64 %1237, 1
  %exitcond.1.not.i.2.1 = icmp eq i64 %1256, 17
  br i1 %exitcond.1.not.i.2.1, label %.preheader.us.1.i.2.2, label %.critedge.us.1.i.2.1.1

.critedge.us.1.i.2.1.1:                           ; preds = %.critedge.us.1.i.2.1
  %1257 = mul nuw nsw i64 %1256, 65
  %1258 = getelementptr double, ptr %gep.i.2, i64 %1256
  %1259 = load double, ptr %1258, align 8
  %1260 = insertelement <1 x double> poison, double %1259, i64 0
  %gep.us.1.i.2.1.1 = getelementptr double, ptr %invariant.gep.us.i.2.1, i64 %1257
  %unmaskedload74.1 = load <4 x double>, ptr %gep.us.1.i.2.1.1, align 8
  %1261 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1262 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 1>
  %1263 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 2>
  %1264 = shufflevector <4 x double> %unmaskedload74.1, <4 x double> poison, <1 x i32> <i32 3>
  %1265 = fmul <1 x double> %1260, %1261
  %1266 = fmul <1 x double> %1260, %1262
  %1267 = fmul <1 x double> %1260, %1263
  %1268 = shufflevector <1 x double> %1267, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1269 = fmul <1 x double> %1260, %1264
  %1270 = shufflevector <1 x double> %1269, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1271 = shufflevector <1 x double> %1265, <1 x double> %1266, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1272 = shufflevector <4 x double> %1271, <4 x double> %1268, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1273 = shufflevector <4 x double> %1272, <4 x double> %1270, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1274 = fadd <4 x double> %1255, %1273
  store <4 x double> %1274, ptr %1235, align 8
  %1275 = add nuw nsw i64 %1237, 2
  br label %.critedge.us.1.i.2.1

.preheader.us.1.i.2.2:                            ; preds = %.critedge.us.1.i.2.1
  %1276 = getelementptr double, ptr %1194, i64 8
  %.promoted96 = load <4 x double>, ptr %1276, align 8
  br label %.critedge.us.1.i.2.2

.critedge.us.1.i.2.2:                             ; preds = %.critedge.us.1.i.2.2.1, %.preheader.us.1.i.2.2
  %1277 = phi <4 x double> [ %.promoted96, %.preheader.us.1.i.2.2 ], [ %1315, %.critedge.us.1.i.2.2.1 ]
  %1278 = phi i64 [ 0, %.preheader.us.1.i.2.2 ], [ %1316, %.critedge.us.1.i.2.2.1 ]
  %1279 = mul nuw nsw i64 %1278, 65
  %1280 = getelementptr double, ptr %gep.i.2, i64 %1278
  %1281 = load double, ptr %1280, align 8
  %1282 = insertelement <1 x double> poison, double %1281, i64 0
  %gep.us.1.i.2.2 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %1279
  %unmaskedload76 = load <4 x double>, ptr %gep.us.1.i.2.2, align 8
  %1283 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> zeroinitializer
  %1284 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 1>
  %1285 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 2>
  %1286 = shufflevector <4 x double> %unmaskedload76, <4 x double> poison, <1 x i32> <i32 3>
  %1287 = fmul <1 x double> %1282, %1283
  %1288 = fmul <1 x double> %1282, %1284
  %1289 = fmul <1 x double> %1282, %1285
  %1290 = shufflevector <1 x double> %1289, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1291 = fmul <1 x double> %1282, %1286
  %1292 = shufflevector <1 x double> %1291, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1293 = shufflevector <1 x double> %1287, <1 x double> %1288, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1294 = shufflevector <4 x double> %1293, <4 x double> %1290, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1295 = shufflevector <4 x double> %1294, <4 x double> %1292, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1296 = fadd <4 x double> %1277, %1295
  store <4 x double> %1296, ptr %1276, align 8
  %1297 = or disjoint i64 %1278, 1
  %exitcond.1.not.i.2.2 = icmp eq i64 %1297, 17
  br i1 %exitcond.1.not.i.2.2, label %.preheader.us.1.i.2.3, label %.critedge.us.1.i.2.2.1

.critedge.us.1.i.2.2.1:                           ; preds = %.critedge.us.1.i.2.2
  %1298 = mul nuw nsw i64 %1297, 65
  %1299 = getelementptr double, ptr %gep.i.2, i64 %1297
  %1300 = load double, ptr %1299, align 8
  %1301 = insertelement <1 x double> poison, double %1300, i64 0
  %gep.us.1.i.2.2.1 = getelementptr double, ptr %invariant.gep.us.i.2.2, i64 %1298
  %unmaskedload76.1 = load <4 x double>, ptr %gep.us.1.i.2.2.1, align 8
  %1302 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1303 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 1>
  %1304 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 2>
  %1305 = shufflevector <4 x double> %unmaskedload76.1, <4 x double> poison, <1 x i32> <i32 3>
  %1306 = fmul <1 x double> %1301, %1302
  %1307 = fmul <1 x double> %1301, %1303
  %1308 = fmul <1 x double> %1301, %1304
  %1309 = shufflevector <1 x double> %1308, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1310 = fmul <1 x double> %1301, %1305
  %1311 = shufflevector <1 x double> %1310, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1312 = shufflevector <1 x double> %1306, <1 x double> %1307, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1313 = shufflevector <4 x double> %1312, <4 x double> %1309, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1314 = shufflevector <4 x double> %1313, <4 x double> %1311, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1315 = fadd <4 x double> %1296, %1314
  store <4 x double> %1315, ptr %1276, align 8
  %1316 = add nuw nsw i64 %1278, 2
  br label %.critedge.us.1.i.2.2

.preheader.us.1.i.2.3:                            ; preds = %.critedge.us.1.i.2.2
  %1317 = getelementptr double, ptr %1194, i64 12
  %.promoted95 = load <4 x double>, ptr %1317, align 8
  br label %.critedge.us.1.i.2.3

.critedge.us.1.i.2.3:                             ; preds = %.critedge.us.1.i.2.3.1, %.preheader.us.1.i.2.3
  %1318 = phi <4 x double> [ %.promoted95, %.preheader.us.1.i.2.3 ], [ %1356, %.critedge.us.1.i.2.3.1 ]
  %1319 = phi i64 [ 0, %.preheader.us.1.i.2.3 ], [ %1357, %.critedge.us.1.i.2.3.1 ]
  %1320 = mul nuw nsw i64 %1319, 65
  %1321 = getelementptr double, ptr %gep.i.2, i64 %1319
  %1322 = load double, ptr %1321, align 8
  %1323 = insertelement <1 x double> poison, double %1322, i64 0
  %gep.us.1.i.2.3 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %1320
  %unmaskedload78 = load <4 x double>, ptr %gep.us.1.i.2.3, align 8
  %1324 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> zeroinitializer
  %1325 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 1>
  %1326 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 2>
  %1327 = shufflevector <4 x double> %unmaskedload78, <4 x double> poison, <1 x i32> <i32 3>
  %1328 = fmul <1 x double> %1323, %1324
  %1329 = fmul <1 x double> %1323, %1325
  %1330 = fmul <1 x double> %1323, %1326
  %1331 = shufflevector <1 x double> %1330, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1332 = fmul <1 x double> %1323, %1327
  %1333 = shufflevector <1 x double> %1332, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1334 = shufflevector <1 x double> %1328, <1 x double> %1329, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1335 = shufflevector <4 x double> %1334, <4 x double> %1331, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1336 = shufflevector <4 x double> %1335, <4 x double> %1333, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1337 = fadd <4 x double> %1318, %1336
  store <4 x double> %1337, ptr %1317, align 8
  %1338 = or disjoint i64 %1319, 1
  %exitcond.1.not.i.2.3 = icmp eq i64 %1338, 17
  br i1 %exitcond.1.not.i.2.3, label %._crit_edge.us.1.i.2, label %.critedge.us.1.i.2.3.1

.critedge.us.1.i.2.3.1:                           ; preds = %.critedge.us.1.i.2.3
  %1339 = mul nuw nsw i64 %1338, 65
  %1340 = getelementptr double, ptr %gep.i.2, i64 %1338
  %1341 = load double, ptr %1340, align 8
  %1342 = insertelement <1 x double> poison, double %1341, i64 0
  %gep.us.1.i.2.3.1 = getelementptr double, ptr %invariant.gep.us.i.2.3, i64 %1339
  %unmaskedload78.1 = load <4 x double>, ptr %gep.us.1.i.2.3.1, align 8
  %1343 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1344 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 1>
  %1345 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 2>
  %1346 = shufflevector <4 x double> %unmaskedload78.1, <4 x double> poison, <1 x i32> <i32 3>
  %1347 = fmul <1 x double> %1342, %1343
  %1348 = fmul <1 x double> %1342, %1344
  %1349 = fmul <1 x double> %1342, %1345
  %1350 = shufflevector <1 x double> %1349, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1351 = fmul <1 x double> %1342, %1346
  %1352 = shufflevector <1 x double> %1351, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1353 = shufflevector <1 x double> %1347, <1 x double> %1348, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1354 = shufflevector <4 x double> %1353, <4 x double> %1350, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1355 = shufflevector <4 x double> %1354, <4 x double> %1352, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1356 = fadd <4 x double> %1337, %1355
  store <4 x double> %1356, ptr %1317, align 8
  %1357 = add nuw nsw i64 %1319, 2
  br label %.critedge.us.1.i.2.3

._crit_edge.us.1.i.2:                             ; preds = %.critedge.us.1.i.2.3
  %1358 = add nuw nsw i64 %1191, 1
  %exitcond22.1.not.i.2 = icmp eq i64 %1358, 15
  br i1 %exitcond22.1.not.i.2, label %.split20.us.1.i.2, label %.preheader16.us.1.i.2

.split20.us.1.i.2:                                ; preds = %._crit_edge.us.1.i.2
  %1359 = getelementptr double, ptr %9, i64 1088
  br label %.preheader16.us.1.i.3

.preheader16.us.1.i.3:                            ; preds = %._crit_edge.us.1.i.3, %.split20.us.1.i.2
  %1360 = phi i64 [ %1527, %._crit_edge.us.1.i.3 ], [ 0, %.split20.us.1.i.2 ]
  %1361 = mul nuw nsw i64 %1360, 17
  %1362 = mul nuw nsw i64 %1360, 65
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %1361
  %1363 = getelementptr double, ptr %1359, i64 %1362
  %.promoted102 = load <4 x double>, ptr %1363, align 8
  br label %.critedge.us.1.i.3

.critedge.us.1.i.3:                               ; preds = %.critedge.us.1.i.3.1142, %.preheader16.us.1.i.3
  %1364 = phi <4 x double> [ %.promoted102, %.preheader16.us.1.i.3 ], [ %1402, %.critedge.us.1.i.3.1142 ]
  %1365 = phi i64 [ 0, %.preheader16.us.1.i.3 ], [ %1403, %.critedge.us.1.i.3.1142 ]
  %1366 = mul nuw nsw i64 %1365, 65
  %1367 = getelementptr double, ptr %gep.i.3, i64 %1365
  %1368 = load double, ptr %1367, align 8
  %1369 = insertelement <1 x double> poison, double %1368, i64 0
  %gep.us.1.i.3 = getelementptr double, ptr %521, i64 %1366
  %unmaskedload80 = load <4 x double>, ptr %gep.us.1.i.3, align 8
  %1370 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> zeroinitializer
  %1371 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 1>
  %1372 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 2>
  %1373 = shufflevector <4 x double> %unmaskedload80, <4 x double> poison, <1 x i32> <i32 3>
  %1374 = fmul <1 x double> %1369, %1370
  %1375 = fmul <1 x double> %1369, %1371
  %1376 = fmul <1 x double> %1369, %1372
  %1377 = shufflevector <1 x double> %1376, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1378 = fmul <1 x double> %1369, %1373
  %1379 = shufflevector <1 x double> %1378, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1380 = shufflevector <1 x double> %1374, <1 x double> %1375, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1381 = shufflevector <4 x double> %1380, <4 x double> %1377, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1382 = shufflevector <4 x double> %1381, <4 x double> %1379, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1383 = fadd <4 x double> %1364, %1382
  store <4 x double> %1383, ptr %1363, align 8
  %1384 = or disjoint i64 %1365, 1
  %exitcond.1.not.i.3 = icmp eq i64 %1384, 17
  br i1 %exitcond.1.not.i.3, label %.preheader.us.1.i.3.1, label %.critedge.us.1.i.3.1142

.critedge.us.1.i.3.1142:                          ; preds = %.critedge.us.1.i.3
  %1385 = mul nuw nsw i64 %1384, 65
  %1386 = getelementptr double, ptr %gep.i.3, i64 %1384
  %1387 = load double, ptr %1386, align 8
  %1388 = insertelement <1 x double> poison, double %1387, i64 0
  %gep.us.1.i.3.1140 = getelementptr double, ptr %521, i64 %1385
  %unmaskedload80.1 = load <4 x double>, ptr %gep.us.1.i.3.1140, align 8
  %1389 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1390 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 1>
  %1391 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 2>
  %1392 = shufflevector <4 x double> %unmaskedload80.1, <4 x double> poison, <1 x i32> <i32 3>
  %1393 = fmul <1 x double> %1388, %1389
  %1394 = fmul <1 x double> %1388, %1390
  %1395 = fmul <1 x double> %1388, %1391
  %1396 = shufflevector <1 x double> %1395, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1397 = fmul <1 x double> %1388, %1392
  %1398 = shufflevector <1 x double> %1397, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1399 = shufflevector <1 x double> %1393, <1 x double> %1394, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1400 = shufflevector <4 x double> %1399, <4 x double> %1396, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1401 = shufflevector <4 x double> %1400, <4 x double> %1398, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1402 = fadd <4 x double> %1383, %1401
  store <4 x double> %1402, ptr %1363, align 8
  %1403 = add nuw nsw i64 %1365, 2
  br label %.critedge.us.1.i.3

.preheader.us.1.i.3.1:                            ; preds = %.critedge.us.1.i.3
  %1404 = getelementptr double, ptr %1363, i64 4
  %.promoted101 = load <4 x double>, ptr %1404, align 8
  br label %.critedge.us.1.i.3.1

.critedge.us.1.i.3.1:                             ; preds = %.critedge.us.1.i.3.1.1, %.preheader.us.1.i.3.1
  %1405 = phi <4 x double> [ %.promoted101, %.preheader.us.1.i.3.1 ], [ %1443, %.critedge.us.1.i.3.1.1 ]
  %1406 = phi i64 [ 0, %.preheader.us.1.i.3.1 ], [ %1444, %.critedge.us.1.i.3.1.1 ]
  %1407 = mul nuw nsw i64 %1406, 65
  %1408 = getelementptr double, ptr %gep.i.3, i64 %1406
  %1409 = load double, ptr %1408, align 8
  %1410 = insertelement <1 x double> poison, double %1409, i64 0
  %gep.us.1.i.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %1407
  %unmaskedload82 = load <4 x double>, ptr %gep.us.1.i.3.1, align 8
  %1411 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> zeroinitializer
  %1412 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 1>
  %1413 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 2>
  %1414 = shufflevector <4 x double> %unmaskedload82, <4 x double> poison, <1 x i32> <i32 3>
  %1415 = fmul <1 x double> %1410, %1411
  %1416 = fmul <1 x double> %1410, %1412
  %1417 = fmul <1 x double> %1410, %1413
  %1418 = shufflevector <1 x double> %1417, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1419 = fmul <1 x double> %1410, %1414
  %1420 = shufflevector <1 x double> %1419, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1421 = shufflevector <1 x double> %1415, <1 x double> %1416, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1422 = shufflevector <4 x double> %1421, <4 x double> %1418, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1423 = shufflevector <4 x double> %1422, <4 x double> %1420, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1424 = fadd <4 x double> %1405, %1423
  store <4 x double> %1424, ptr %1404, align 8
  %1425 = or disjoint i64 %1406, 1
  %exitcond.1.not.i.3.1 = icmp eq i64 %1425, 17
  br i1 %exitcond.1.not.i.3.1, label %.preheader.us.1.i.3.2, label %.critedge.us.1.i.3.1.1

.critedge.us.1.i.3.1.1:                           ; preds = %.critedge.us.1.i.3.1
  %1426 = mul nuw nsw i64 %1425, 65
  %1427 = getelementptr double, ptr %gep.i.3, i64 %1425
  %1428 = load double, ptr %1427, align 8
  %1429 = insertelement <1 x double> poison, double %1428, i64 0
  %gep.us.1.i.3.1.1 = getelementptr double, ptr %invariant.gep.us.i.3.1, i64 %1426
  %unmaskedload82.1 = load <4 x double>, ptr %gep.us.1.i.3.1.1, align 8
  %1430 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1431 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 1>
  %1432 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 2>
  %1433 = shufflevector <4 x double> %unmaskedload82.1, <4 x double> poison, <1 x i32> <i32 3>
  %1434 = fmul <1 x double> %1429, %1430
  %1435 = fmul <1 x double> %1429, %1431
  %1436 = fmul <1 x double> %1429, %1432
  %1437 = shufflevector <1 x double> %1436, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1438 = fmul <1 x double> %1429, %1433
  %1439 = shufflevector <1 x double> %1438, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1440 = shufflevector <1 x double> %1434, <1 x double> %1435, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1441 = shufflevector <4 x double> %1440, <4 x double> %1437, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1442 = shufflevector <4 x double> %1441, <4 x double> %1439, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1443 = fadd <4 x double> %1424, %1442
  store <4 x double> %1443, ptr %1404, align 8
  %1444 = add nuw nsw i64 %1406, 2
  br label %.critedge.us.1.i.3.1

.preheader.us.1.i.3.2:                            ; preds = %.critedge.us.1.i.3.1
  %1445 = getelementptr double, ptr %1363, i64 8
  %.promoted100 = load <4 x double>, ptr %1445, align 8
  br label %.critedge.us.1.i.3.2

.critedge.us.1.i.3.2:                             ; preds = %.critedge.us.1.i.3.2.1, %.preheader.us.1.i.3.2
  %1446 = phi <4 x double> [ %.promoted100, %.preheader.us.1.i.3.2 ], [ %1484, %.critedge.us.1.i.3.2.1 ]
  %1447 = phi i64 [ 0, %.preheader.us.1.i.3.2 ], [ %1485, %.critedge.us.1.i.3.2.1 ]
  %1448 = mul nuw nsw i64 %1447, 65
  %1449 = getelementptr double, ptr %gep.i.3, i64 %1447
  %1450 = load double, ptr %1449, align 8
  %1451 = insertelement <1 x double> poison, double %1450, i64 0
  %gep.us.1.i.3.2 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %1448
  %unmaskedload84 = load <4 x double>, ptr %gep.us.1.i.3.2, align 8
  %1452 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> zeroinitializer
  %1453 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 1>
  %1454 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 2>
  %1455 = shufflevector <4 x double> %unmaskedload84, <4 x double> poison, <1 x i32> <i32 3>
  %1456 = fmul <1 x double> %1451, %1452
  %1457 = fmul <1 x double> %1451, %1453
  %1458 = fmul <1 x double> %1451, %1454
  %1459 = shufflevector <1 x double> %1458, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1460 = fmul <1 x double> %1451, %1455
  %1461 = shufflevector <1 x double> %1460, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1462 = shufflevector <1 x double> %1456, <1 x double> %1457, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1463 = shufflevector <4 x double> %1462, <4 x double> %1459, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1464 = shufflevector <4 x double> %1463, <4 x double> %1461, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1465 = fadd <4 x double> %1446, %1464
  store <4 x double> %1465, ptr %1445, align 8
  %1466 = or disjoint i64 %1447, 1
  %exitcond.1.not.i.3.2 = icmp eq i64 %1466, 17
  br i1 %exitcond.1.not.i.3.2, label %.preheader.us.1.i.3.3, label %.critedge.us.1.i.3.2.1

.critedge.us.1.i.3.2.1:                           ; preds = %.critedge.us.1.i.3.2
  %1467 = mul nuw nsw i64 %1466, 65
  %1468 = getelementptr double, ptr %gep.i.3, i64 %1466
  %1469 = load double, ptr %1468, align 8
  %1470 = insertelement <1 x double> poison, double %1469, i64 0
  %gep.us.1.i.3.2.1 = getelementptr double, ptr %invariant.gep.us.i.3.2, i64 %1467
  %unmaskedload84.1 = load <4 x double>, ptr %gep.us.1.i.3.2.1, align 8
  %1471 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1472 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 1>
  %1473 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 2>
  %1474 = shufflevector <4 x double> %unmaskedload84.1, <4 x double> poison, <1 x i32> <i32 3>
  %1475 = fmul <1 x double> %1470, %1471
  %1476 = fmul <1 x double> %1470, %1472
  %1477 = fmul <1 x double> %1470, %1473
  %1478 = shufflevector <1 x double> %1477, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1479 = fmul <1 x double> %1470, %1474
  %1480 = shufflevector <1 x double> %1479, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1481 = shufflevector <1 x double> %1475, <1 x double> %1476, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1482 = shufflevector <4 x double> %1481, <4 x double> %1478, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1483 = shufflevector <4 x double> %1482, <4 x double> %1480, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1484 = fadd <4 x double> %1465, %1483
  store <4 x double> %1484, ptr %1445, align 8
  %1485 = add nuw nsw i64 %1447, 2
  br label %.critedge.us.1.i.3.2

.preheader.us.1.i.3.3:                            ; preds = %.critedge.us.1.i.3.2
  %1486 = getelementptr double, ptr %1363, i64 12
  %.promoted99 = load <4 x double>, ptr %1486, align 8
  br label %.critedge.us.1.i.3.3

.critedge.us.1.i.3.3:                             ; preds = %.critedge.us.1.i.3.3.1, %.preheader.us.1.i.3.3
  %1487 = phi <4 x double> [ %.promoted99, %.preheader.us.1.i.3.3 ], [ %1525, %.critedge.us.1.i.3.3.1 ]
  %1488 = phi i64 [ 0, %.preheader.us.1.i.3.3 ], [ %1526, %.critedge.us.1.i.3.3.1 ]
  %1489 = mul nuw nsw i64 %1488, 65
  %1490 = getelementptr double, ptr %gep.i.3, i64 %1488
  %1491 = load double, ptr %1490, align 8
  %1492 = insertelement <1 x double> poison, double %1491, i64 0
  %gep.us.1.i.3.3 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %1489
  %unmaskedload86 = load <4 x double>, ptr %gep.us.1.i.3.3, align 8
  %1493 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> zeroinitializer
  %1494 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 1>
  %1495 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 2>
  %1496 = shufflevector <4 x double> %unmaskedload86, <4 x double> poison, <1 x i32> <i32 3>
  %1497 = fmul <1 x double> %1492, %1493
  %1498 = fmul <1 x double> %1492, %1494
  %1499 = fmul <1 x double> %1492, %1495
  %1500 = shufflevector <1 x double> %1499, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1501 = fmul <1 x double> %1492, %1496
  %1502 = shufflevector <1 x double> %1501, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1503 = shufflevector <1 x double> %1497, <1 x double> %1498, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1504 = shufflevector <4 x double> %1503, <4 x double> %1500, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1505 = shufflevector <4 x double> %1504, <4 x double> %1502, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1506 = fadd <4 x double> %1487, %1505
  store <4 x double> %1506, ptr %1486, align 8
  %1507 = or disjoint i64 %1488, 1
  %exitcond.1.not.i.3.3 = icmp eq i64 %1507, 17
  br i1 %exitcond.1.not.i.3.3, label %._crit_edge.us.1.i.3, label %.critedge.us.1.i.3.3.1

.critedge.us.1.i.3.3.1:                           ; preds = %.critedge.us.1.i.3.3
  %1508 = mul nuw nsw i64 %1507, 65
  %1509 = getelementptr double, ptr %gep.i.3, i64 %1507
  %1510 = load double, ptr %1509, align 8
  %1511 = insertelement <1 x double> poison, double %1510, i64 0
  %gep.us.1.i.3.3.1 = getelementptr double, ptr %invariant.gep.us.i.3.3, i64 %1508
  %unmaskedload86.1 = load <4 x double>, ptr %gep.us.1.i.3.3.1, align 8
  %1512 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> zeroinitializer
  %1513 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 1>
  %1514 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 2>
  %1515 = shufflevector <4 x double> %unmaskedload86.1, <4 x double> poison, <1 x i32> <i32 3>
  %1516 = fmul <1 x double> %1511, %1512
  %1517 = fmul <1 x double> %1511, %1513
  %1518 = fmul <1 x double> %1511, %1514
  %1519 = shufflevector <1 x double> %1518, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1520 = fmul <1 x double> %1511, %1515
  %1521 = shufflevector <1 x double> %1520, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1522 = shufflevector <1 x double> %1516, <1 x double> %1517, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %1523 = shufflevector <4 x double> %1522, <4 x double> %1519, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %1524 = shufflevector <4 x double> %1523, <4 x double> %1521, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %1525 = fadd <4 x double> %1506, %1524
  store <4 x double> %1525, ptr %1486, align 8
  %1526 = add nuw nsw i64 %1488, 2
  br label %.critedge.us.1.i.3.3

._crit_edge.us.1.i.3:                             ; preds = %.critedge.us.1.i.3.3
  %1527 = add nuw nsw i64 %1360, 1
  %exitcond22.1.not.i.3 = icmp eq i64 %1527, 15
  br i1 %exitcond22.1.not.i.3, label %.split20.us.1.i.3, label %.preheader16.us.1.i.3

.split20.us.1.i.3:                                ; preds = %._crit_edge.us.1.i.3
  %1528 = getelementptr double, ptr %9, i64 1104
  %gep.us.1.i.4.1 = getelementptr double, ptr %6, i64 129
  %gep.us.1.i.4.2 = getelementptr double, ptr %6, i64 194
  %gep.us.1.i.4.3 = getelementptr double, ptr %6, i64 259
  %gep.us.1.i.4.4 = getelementptr double, ptr %6, i64 324
  %gep.us.1.i.4.5 = getelementptr double, ptr %6, i64 389
  %gep.us.1.i.4.6 = getelementptr double, ptr %6, i64 454
  %gep.us.1.i.4.7 = getelementptr double, ptr %6, i64 519
  %gep.us.1.i.4.8 = getelementptr double, ptr %6, i64 584
  %gep.us.1.i.4.9 = getelementptr double, ptr %6, i64 649
  %gep.us.1.i.4.10 = getelementptr double, ptr %6, i64 714
  %gep.us.1.i.4.11 = getelementptr double, ptr %6, i64 779
  %gep.us.1.i.4.12 = getelementptr double, ptr %6, i64 844
  %gep.us.1.i.4.13 = getelementptr double, ptr %6, i64 909
  %gep.us.1.i.4.14 = getelementptr double, ptr %6, i64 974
  %gep.us.1.i.4.15 = getelementptr double, ptr %6, i64 1039
  %gep.us.1.i.4.16 = getelementptr double, ptr %6, i64 1104
  br label %.preheader16.us.1.i.4

.preheader16.us.1.i.4:                            ; preds = %.preheader16.us.1.i.4, %.split20.us.1.i.3
  %1529 = phi i64 [ %1685, %.preheader16.us.1.i.4 ], [ 0, %.split20.us.1.i.3 ]
  %1530 = mul nuw nsw i64 %1529, 65
  %1531 = getelementptr double, ptr %1528, i64 %1530
  %1532 = mul nuw nsw i64 %1529, 17
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %1532
  %1533 = load double, ptr %gep.i.4, align 8
  %1534 = insertelement <1 x double> poison, double %1533, i64 0
  %1535 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %692, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1536 = shufflevector <4 x double> %1535, <4 x double> poison, <1 x i32> zeroinitializer
  %1537 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1538 = fmul <1 x double> %1534, %1536
  %1539 = shufflevector <1 x double> %1538, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1540 = fadd <4 x double> %1537, %1539
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1540, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1541 = getelementptr double, ptr %gep.i.4, i64 1
  %1542 = load double, ptr %1541, align 8
  %1543 = insertelement <1 x double> poison, double %1542, i64 0
  %1544 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.1, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1545 = shufflevector <4 x double> %1544, <4 x double> poison, <1 x i32> zeroinitializer
  %1546 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1547 = fmul <1 x double> %1543, %1545
  %1548 = shufflevector <1 x double> %1547, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1549 = fadd <4 x double> %1546, %1548
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1549, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1550 = getelementptr double, ptr %gep.i.4, i64 2
  %1551 = load double, ptr %1550, align 8
  %1552 = insertelement <1 x double> poison, double %1551, i64 0
  %1553 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.2, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1554 = shufflevector <4 x double> %1553, <4 x double> poison, <1 x i32> zeroinitializer
  %1555 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1556 = fmul <1 x double> %1552, %1554
  %1557 = shufflevector <1 x double> %1556, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1558 = fadd <4 x double> %1555, %1557
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1558, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1559 = getelementptr double, ptr %gep.i.4, i64 3
  %1560 = load double, ptr %1559, align 8
  %1561 = insertelement <1 x double> poison, double %1560, i64 0
  %1562 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.3, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1563 = shufflevector <4 x double> %1562, <4 x double> poison, <1 x i32> zeroinitializer
  %1564 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1565 = fmul <1 x double> %1561, %1563
  %1566 = shufflevector <1 x double> %1565, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1567 = fadd <4 x double> %1564, %1566
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1567, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1568 = getelementptr double, ptr %gep.i.4, i64 4
  %1569 = load double, ptr %1568, align 8
  %1570 = insertelement <1 x double> poison, double %1569, i64 0
  %1571 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.4, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1572 = shufflevector <4 x double> %1571, <4 x double> poison, <1 x i32> zeroinitializer
  %1573 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1574 = fmul <1 x double> %1570, %1572
  %1575 = shufflevector <1 x double> %1574, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1576 = fadd <4 x double> %1573, %1575
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1576, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1577 = getelementptr double, ptr %gep.i.4, i64 5
  %1578 = load double, ptr %1577, align 8
  %1579 = insertelement <1 x double> poison, double %1578, i64 0
  %1580 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.5, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1581 = shufflevector <4 x double> %1580, <4 x double> poison, <1 x i32> zeroinitializer
  %1582 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1583 = fmul <1 x double> %1579, %1581
  %1584 = shufflevector <1 x double> %1583, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1585 = fadd <4 x double> %1582, %1584
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1585, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1586 = getelementptr double, ptr %gep.i.4, i64 6
  %1587 = load double, ptr %1586, align 8
  %1588 = insertelement <1 x double> poison, double %1587, i64 0
  %1589 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.6, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1590 = shufflevector <4 x double> %1589, <4 x double> poison, <1 x i32> zeroinitializer
  %1591 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1592 = fmul <1 x double> %1588, %1590
  %1593 = shufflevector <1 x double> %1592, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1594 = fadd <4 x double> %1591, %1593
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1594, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1595 = getelementptr double, ptr %gep.i.4, i64 7
  %1596 = load double, ptr %1595, align 8
  %1597 = insertelement <1 x double> poison, double %1596, i64 0
  %1598 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.7, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1599 = shufflevector <4 x double> %1598, <4 x double> poison, <1 x i32> zeroinitializer
  %1600 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1601 = fmul <1 x double> %1597, %1599
  %1602 = shufflevector <1 x double> %1601, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1603 = fadd <4 x double> %1600, %1602
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1603, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1604 = getelementptr double, ptr %gep.i.4, i64 8
  %1605 = load double, ptr %1604, align 8
  %1606 = insertelement <1 x double> poison, double %1605, i64 0
  %1607 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.8, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1608 = shufflevector <4 x double> %1607, <4 x double> poison, <1 x i32> zeroinitializer
  %1609 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1610 = fmul <1 x double> %1606, %1608
  %1611 = shufflevector <1 x double> %1610, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1612 = fadd <4 x double> %1609, %1611
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1612, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1613 = getelementptr double, ptr %gep.i.4, i64 9
  %1614 = load double, ptr %1613, align 8
  %1615 = insertelement <1 x double> poison, double %1614, i64 0
  %1616 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.9, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1617 = shufflevector <4 x double> %1616, <4 x double> poison, <1 x i32> zeroinitializer
  %1618 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1619 = fmul <1 x double> %1615, %1617
  %1620 = shufflevector <1 x double> %1619, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1621 = fadd <4 x double> %1618, %1620
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1621, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1622 = getelementptr double, ptr %gep.i.4, i64 10
  %1623 = load double, ptr %1622, align 8
  %1624 = insertelement <1 x double> poison, double %1623, i64 0
  %1625 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.10, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1626 = shufflevector <4 x double> %1625, <4 x double> poison, <1 x i32> zeroinitializer
  %1627 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1628 = fmul <1 x double> %1624, %1626
  %1629 = shufflevector <1 x double> %1628, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1630 = fadd <4 x double> %1627, %1629
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1630, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1631 = getelementptr double, ptr %gep.i.4, i64 11
  %1632 = load double, ptr %1631, align 8
  %1633 = insertelement <1 x double> poison, double %1632, i64 0
  %1634 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.11, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1635 = shufflevector <4 x double> %1634, <4 x double> poison, <1 x i32> zeroinitializer
  %1636 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1637 = fmul <1 x double> %1633, %1635
  %1638 = shufflevector <1 x double> %1637, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1639 = fadd <4 x double> %1636, %1638
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1639, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1640 = getelementptr double, ptr %gep.i.4, i64 12
  %1641 = load double, ptr %1640, align 8
  %1642 = insertelement <1 x double> poison, double %1641, i64 0
  %1643 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.12, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1644 = shufflevector <4 x double> %1643, <4 x double> poison, <1 x i32> zeroinitializer
  %1645 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1646 = fmul <1 x double> %1642, %1644
  %1647 = shufflevector <1 x double> %1646, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1648 = fadd <4 x double> %1645, %1647
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1648, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1649 = getelementptr double, ptr %gep.i.4, i64 13
  %1650 = load double, ptr %1649, align 8
  %1651 = insertelement <1 x double> poison, double %1650, i64 0
  %1652 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.13, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1653 = shufflevector <4 x double> %1652, <4 x double> poison, <1 x i32> zeroinitializer
  %1654 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1655 = fmul <1 x double> %1651, %1653
  %1656 = shufflevector <1 x double> %1655, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1657 = fadd <4 x double> %1654, %1656
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1657, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1658 = getelementptr double, ptr %gep.i.4, i64 14
  %1659 = load double, ptr %1658, align 8
  %1660 = insertelement <1 x double> poison, double %1659, i64 0
  %1661 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.14, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1662 = shufflevector <4 x double> %1661, <4 x double> poison, <1 x i32> zeroinitializer
  %1663 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1664 = fmul <1 x double> %1660, %1662
  %1665 = shufflevector <1 x double> %1664, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1666 = fadd <4 x double> %1663, %1665
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1666, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1667 = getelementptr double, ptr %gep.i.4, i64 15
  %1668 = load double, ptr %1667, align 8
  %1669 = insertelement <1 x double> poison, double %1668, i64 0
  %1670 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.15, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1671 = shufflevector <4 x double> %1670, <4 x double> poison, <1 x i32> zeroinitializer
  %1672 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1673 = fmul <1 x double> %1669, %1671
  %1674 = shufflevector <1 x double> %1673, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1675 = fadd <4 x double> %1672, %1674
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1675, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1676 = getelementptr double, ptr %gep.i.4, i64 16
  %1677 = load double, ptr %1676, align 8
  %1678 = insertelement <1 x double> poison, double %1677, i64 0
  %1679 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.i.4.16, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1680 = shufflevector <4 x double> %1679, <4 x double> poison, <1 x i32> zeroinitializer
  %1681 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>, <4 x double> poison)
  %1682 = fmul <1 x double> %1678, %1680
  %1683 = shufflevector <1 x double> %1682, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %1684 = fadd <4 x double> %1681, %1683
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %1684, ptr %1531, i32 8, <4 x i1> <i1 true, i1 false, i1 false, i1 false>)
  %1685 = add nuw nsw i64 %1529, 1
  %exitcond22.1.not.i.4 = icmp eq i64 %1685, 15
  br i1 %exitcond22.1.not.i.4, label %.split20.us.1.i.4, label %.preheader16.us.1.i.4

.split20.us.1.i.4:                                ; preds = %.preheader16.us.1.i.4
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
