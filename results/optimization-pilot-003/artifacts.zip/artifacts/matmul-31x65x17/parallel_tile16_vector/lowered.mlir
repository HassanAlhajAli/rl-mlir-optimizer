module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<false> : vector<4xi1>) : vector<4xi1>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<4xf64>) : vector<4xf64>
    %27 = llvm.mlir.constant(dense<false> : vector<1x4xi1>) : !llvm.array<1 x vector<4xi1>>
    %28 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %29 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %30 = llvm.mlir.constant(-1 : index) : i64
    %31 = llvm.mlir.constant(17 : index) : i64
    %32 = llvm.mlir.constant(65 : index) : i64
    %33 = llvm.mlir.constant(31 : index) : i64
    %34 = llvm.mlir.constant(1 : index) : i64
    %35 = llvm.mlir.constant(4 : index) : i64
    %36 = llvm.mlir.constant(0 : index) : i64
    %37 = llvm.mlir.constant(16 : index) : i64
    %38 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%36 : i64)
  ^bb1(%39: i64):  // 2 preds: ^bb0, ^bb5
    %40 = llvm.icmp "slt" %39, %33 : i64
    llvm.cond_br %40, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%36 : i64)
  ^bb3(%41: i64):  // 2 preds: ^bb2, ^bb4
    %42 = llvm.icmp "slt" %41, %32 : i64
    llvm.cond_br %42, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %43 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.mlir.constant(65 : index) : i64
    %45 = llvm.mul %39, %44  : i64
    %46 = llvm.add %45, %41  : i64
    %47 = llvm.getelementptr %43[%46] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %38, %47 : f64, !llvm.ptr
    %48 = llvm.add %41, %34  : i64
    llvm.br ^bb3(%48 : i64)
  ^bb5:  // pred: ^bb3
    %49 = llvm.add %39, %34  : i64
    llvm.br ^bb1(%49 : i64)
  ^bb6:  // pred: ^bb1
    %50 = llvm.mlir.constant(1 : index) : i64
    %51 = llvm.alloca %50 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %52 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %53 = llvm.insertvalue %51, %52[0] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.insertvalue %51, %53[1] : !llvm.struct<(ptr, ptr, i64)> 
    %55 = llvm.mlir.constant(0 : index) : i64
    %56 = llvm.insertvalue %55, %54[2] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.mlir.constant(1 : index) : i64
    %58 = llvm.alloca %57 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %59 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %60 = llvm.insertvalue %58, %59[0] : !llvm.struct<(ptr, ptr, i64)> 
    %61 = llvm.insertvalue %58, %60[1] : !llvm.struct<(ptr, ptr, i64)> 
    %62 = llvm.mlir.constant(0 : index) : i64
    %63 = llvm.insertvalue %62, %61[2] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.mlir.constant(1 : index) : i64
    %65 = llvm.alloca %64 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %66 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %67 = llvm.insertvalue %65, %66[0] : !llvm.struct<(ptr, ptr, i64)> 
    %68 = llvm.insertvalue %65, %67[1] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.mlir.constant(0 : index) : i64
    %70 = llvm.insertvalue %69, %68[2] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.mlir.constant(1 : index) : i64
    %72 = llvm.alloca %71 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %73 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %74 = llvm.insertvalue %72, %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %75 = llvm.insertvalue %72, %74[1] : !llvm.struct<(ptr, ptr, i64)> 
    %76 = llvm.mlir.constant(0 : index) : i64
    %77 = llvm.insertvalue %76, %75[2] : !llvm.struct<(ptr, ptr, i64)> 
    %78 = llvm.mlir.constant(1 : index) : i64
    %79 = llvm.alloca %78 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %80 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %81 = llvm.insertvalue %79, %80[0] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.insertvalue %79, %81[1] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.mlir.constant(0 : index) : i64
    %84 = llvm.insertvalue %83, %82[2] : !llvm.struct<(ptr, ptr, i64)> 
    %85 = llvm.mlir.constant(1 : index) : i64
    %86 = llvm.alloca %85 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %87 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %88 = llvm.insertvalue %86, %87[0] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.insertvalue %86, %88[1] : !llvm.struct<(ptr, ptr, i64)> 
    %90 = llvm.mlir.constant(0 : index) : i64
    %91 = llvm.insertvalue %90, %89[2] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.mlir.constant(1 : index) : i64
    %93 = llvm.alloca %92 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %94 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %95 = llvm.insertvalue %93, %94[0] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.insertvalue %93, %95[1] : !llvm.struct<(ptr, ptr, i64)> 
    %97 = llvm.mlir.constant(0 : index) : i64
    %98 = llvm.insertvalue %97, %96[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%36 : i64)
  ^bb7(%99: i64):  // 2 preds: ^bb6, ^bb32
    %100 = llvm.icmp "slt" %99, %33 : i64
    llvm.cond_br %100, ^bb8, ^bb33
  ^bb8:  // pred: ^bb7
    %101 = llvm.mul %99, %30  : i64
    %102 = llvm.add %101, %33  : i64
    %103 = llvm.icmp "slt" %102, %37 : i64
    %104 = llvm.select %103, %102, %37 : i1, i64
    %105 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %108 = llvm.insertvalue %105, %107[0] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.insertvalue %106, %108[1] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.mlir.constant(0 : index) : i64
    %111 = llvm.insertvalue %110, %109[2] : !llvm.struct<(ptr, ptr, i64)> 
    %112 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.mul %99, %31  : i64
    %118 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %119 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %120 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %121 = llvm.insertvalue %118, %120[0] : !llvm.struct<(ptr, ptr, i64)> 
    %122 = llvm.insertvalue %119, %121[1] : !llvm.struct<(ptr, ptr, i64)> 
    %123 = llvm.mlir.constant(0 : index) : i64
    %124 = llvm.insertvalue %123, %122[2] : !llvm.struct<(ptr, ptr, i64)> 
    %125 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %126 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %127 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.mul %99, %32  : i64
    llvm.br ^bb9(%36 : i64)
  ^bb9(%131: i64):  // 2 preds: ^bb8, ^bb31
    %132 = llvm.icmp "slt" %131, %32 : i64
    llvm.cond_br %132, ^bb10, ^bb32
  ^bb10:  // pred: ^bb9
    %133 = llvm.mul %131, %30  : i64
    %134 = llvm.add %133, %32  : i64
    %135 = llvm.icmp "slt" %134, %37 : i64
    %136 = llvm.select %135, %134, %37 : i1, i64
    %137 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %140 = llvm.insertvalue %137, %139[0] : !llvm.struct<(ptr, ptr, i64)> 
    %141 = llvm.insertvalue %138, %140[1] : !llvm.struct<(ptr, ptr, i64)> 
    %142 = llvm.mlir.constant(0 : index) : i64
    %143 = llvm.insertvalue %142, %141[2] : !llvm.struct<(ptr, ptr, i64)> 
    %144 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %149 = llvm.add %130, %131  : i64
    llvm.br ^bb11(%36 : i64)
  ^bb11(%150: i64):  // 2 preds: ^bb10, ^bb30
    %151 = llvm.icmp "slt" %150, %104 : i64
    llvm.cond_br %151, ^bb12, ^bb31
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%36 : i64)
  ^bb13(%152: i64):  // 2 preds: ^bb12, ^bb29
    %153 = llvm.icmp "slt" %152, %136 : i64
    llvm.cond_br %153, ^bb14, ^bb30
  ^bb14:  // pred: ^bb13
    llvm.br ^bb15(%36 : i64)
  ^bb15(%154: i64):  // 2 preds: ^bb14, ^bb28
    %155 = llvm.icmp "slt" %154, %31 : i64
    llvm.cond_br %155, ^bb16, ^bb29
  ^bb16:  // pred: ^bb15
    %156 = llvm.mul %152, %30  : i64
    %157 = llvm.add %136, %156  : i64
    %158 = llvm.icmp "sgt" %157, %35 : i64
    %159 = llvm.select %158, %35, %157 : i1, i64
    %160 = llvm.mul %152, %30  : i64
    %161 = llvm.add %136, %160  : i64
    %162 = llvm.icmp "sgt" %161, %35 : i64
    %163 = llvm.select %162, %35, %161 : i1, i64
    %164 = llvm.mul %150, %31  : i64
    %165 = llvm.add %117, %164  : i64
    %166 = llvm.add %165, %154  : i64
    %167 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %168 = llvm.insertvalue %105, %167[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %169 = llvm.insertvalue %106, %168[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %170 = llvm.insertvalue %166, %169[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %171 = llvm.mlir.constant(1 : index) : i64
    %172 = llvm.insertvalue %171, %170[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %173 = llvm.mlir.constant(17 : index) : i64
    %174 = llvm.insertvalue %173, %172[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %175 = llvm.mlir.constant(1 : index) : i64
    %176 = llvm.insertvalue %175, %174[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %177 = llvm.mlir.constant(1 : index) : i64
    %178 = llvm.insertvalue %177, %176[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %179 = llvm.mul %154, %32  : i64
    %180 = llvm.add %131, %179  : i64
    %181 = llvm.add %180, %152  : i64
    %182 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %183 = llvm.insertvalue %137, %182[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %184 = llvm.insertvalue %138, %183[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %185 = llvm.insertvalue %181, %184[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %186 = llvm.mlir.constant(1 : index) : i64
    %187 = llvm.insertvalue %186, %185[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %188 = llvm.mlir.constant(65 : index) : i64
    %189 = llvm.insertvalue %188, %187[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %190 = llvm.insertvalue %159, %189[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %191 = llvm.mlir.constant(1 : index) : i64
    %192 = llvm.insertvalue %191, %190[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %193 = llvm.mul %150, %32  : i64
    %194 = llvm.add %149, %193  : i64
    %195 = llvm.add %194, %152  : i64
    %196 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %197 = llvm.insertvalue %118, %196[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %198 = llvm.insertvalue %119, %197[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %199 = llvm.insertvalue %195, %198[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %200 = llvm.mlir.constant(1 : index) : i64
    %201 = llvm.insertvalue %200, %199[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %202 = llvm.mlir.constant(65 : index) : i64
    %203 = llvm.insertvalue %202, %201[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %204 = llvm.insertvalue %163, %203[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %205 = llvm.mlir.constant(1 : index) : i64
    %206 = llvm.insertvalue %205, %204[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %207 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %208 = llvm.extractvalue %56[0] : !llvm.struct<(ptr, ptr, i64)> 
    %209 = llvm.insertvalue %208, %207[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %210 = llvm.extractvalue %56[1] : !llvm.struct<(ptr, ptr, i64)> 
    %211 = llvm.insertvalue %210, %209[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %212 = llvm.mlir.constant(0 : index) : i64
    %213 = llvm.insertvalue %212, %211[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %214 = llvm.mlir.constant(1 : index) : i64
    %215 = llvm.insertvalue %214, %213[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %216 = llvm.mlir.constant(1 : index) : i64
    %217 = llvm.insertvalue %216, %215[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb17(%36 : i64)
  ^bb17(%218: i64):  // 2 preds: ^bb16, ^bb18
    %219 = llvm.icmp "slt" %218, %34 : i64
    llvm.cond_br %219, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    %220 = llvm.getelementptr %106[%166] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %221 = llvm.mlir.constant(17 : index) : i64
    %222 = llvm.mul %218, %221  : i64
    %223 = llvm.add %222, %36  : i64
    %224 = llvm.getelementptr %220[%223] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %225 = llvm.load %224 : !llvm.ptr -> f64
    %226 = llvm.mlir.undef : vector<1xf64>
    %227 = llvm.mlir.constant(0 : i32) : i32
    %228 = llvm.insertelement %225, %226[%227 : i32] : vector<1xf64>
    %229 = llvm.shufflevector %228, %226 [0] : vector<1xf64> 
    %230 = llvm.getelementptr %210[%218] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %229, %230 : vector<1xf64>, !llvm.ptr
    %231 = llvm.add %218, %34  : i64
    llvm.br ^bb17(%231 : i64)
  ^bb19:  // pred: ^bb17
    %232 = llvm.load %51 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %233 = llvm.extractvalue %232[0] : !llvm.array<1 x vector<1xf64>> 
    %234 = llvm.insertvalue %233, %29[0] : !llvm.array<4 x vector<1xf64>> 
    %235 = llvm.insertvalue %233, %234[1] : !llvm.array<4 x vector<1xf64>> 
    %236 = llvm.insertvalue %233, %235[2] : !llvm.array<4 x vector<1xf64>> 
    %237 = llvm.insertvalue %233, %236[3] : !llvm.array<4 x vector<1xf64>> 
    %238 = llvm.insertvalue %237, %28[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %239 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %240 = llvm.trunc %159 : i64 to i32
    %241 = llvm.mlir.undef : vector<4xi32>
    %242 = llvm.mlir.constant(0 : i32) : i32
    %243 = llvm.insertelement %240, %241[%242 : i32] : vector<4xi32>
    %244 = llvm.shufflevector %243, %241 [0, 0, 0, 0] : vector<4xi32> 
    %245 = llvm.icmp "sgt" %244, %239 : vector<4xi32>
    %246 = llvm.insertvalue %245, %27[0] : !llvm.array<1 x vector<4xi1>> 
    llvm.store %246, %65 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    %247 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %248 = llvm.extractvalue %63[0] : !llvm.struct<(ptr, ptr, i64)> 
    %249 = llvm.insertvalue %248, %247[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %250 = llvm.extractvalue %63[1] : !llvm.struct<(ptr, ptr, i64)> 
    %251 = llvm.insertvalue %250, %249[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %252 = llvm.mlir.constant(0 : index) : i64
    %253 = llvm.insertvalue %252, %251[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %254 = llvm.mlir.constant(1 : index) : i64
    %255 = llvm.insertvalue %254, %253[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.mlir.constant(1 : index) : i64
    %257 = llvm.insertvalue %256, %255[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %258 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %259 = llvm.extractvalue %70[0] : !llvm.struct<(ptr, ptr, i64)> 
    %260 = llvm.insertvalue %259, %258[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %261 = llvm.extractvalue %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %262 = llvm.insertvalue %261, %260[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %263 = llvm.mlir.constant(0 : index) : i64
    %264 = llvm.insertvalue %263, %262[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %265 = llvm.mlir.constant(1 : index) : i64
    %266 = llvm.insertvalue %265, %264[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %267 = llvm.mlir.constant(1 : index) : i64
    %268 = llvm.insertvalue %267, %266[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb20(%36 : i64)
  ^bb20(%269: i64):  // 2 preds: ^bb19, ^bb21
    %270 = llvm.icmp "slt" %269, %34 : i64
    llvm.cond_br %270, ^bb21, ^bb22
  ^bb21:  // pred: ^bb20
    %271 = llvm.getelementptr %261[%269] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %272 = llvm.load %271 : !llvm.ptr -> vector<4xi1>
    %273 = llvm.extractvalue %192[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %274 = llvm.extractvalue %192[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %275 = llvm.getelementptr %273[%274] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %276 = llvm.mlir.constant(65 : index) : i64
    %277 = llvm.mul %269, %276  : i64
    %278 = llvm.add %277, %36  : i64
    %279 = llvm.getelementptr %275[%278] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %280 = llvm.intr.masked.load %279, %272, %26 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %281 = llvm.getelementptr %250[%269] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %280, %281 : vector<4xf64>, !llvm.ptr
    %282 = llvm.add %269, %34  : i64
    llvm.br ^bb20(%282 : i64)
  ^bb22:  // pred: ^bb20
    %283 = llvm.load %58 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %284 = llvm.extractvalue %283[0] : !llvm.array<1 x vector<4xf64>> 
    %285 = llvm.mlir.constant(0 : i64) : i64
    %286 = llvm.extractelement %284[%285 : i64] : vector<4xf64>
    %287 = llvm.extractvalue %28[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %288 = llvm.mlir.constant(0 : i64) : i64
    %289 = llvm.insertelement %286, %287[%288 : i64] : vector<1xf64>
    %290 = llvm.insertvalue %289, %28[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %291 = llvm.extractvalue %283[0] : !llvm.array<1 x vector<4xf64>> 
    %292 = llvm.mlir.constant(1 : i64) : i64
    %293 = llvm.extractelement %291[%292 : i64] : vector<4xf64>
    %294 = llvm.extractvalue %28[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %295 = llvm.mlir.constant(0 : i64) : i64
    %296 = llvm.insertelement %293, %294[%295 : i64] : vector<1xf64>
    %297 = llvm.insertvalue %296, %290[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %298 = llvm.extractvalue %283[0] : !llvm.array<1 x vector<4xf64>> 
    %299 = llvm.mlir.constant(2 : i64) : i64
    %300 = llvm.extractelement %298[%299 : i64] : vector<4xf64>
    %301 = llvm.extractvalue %28[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %302 = llvm.mlir.constant(0 : i64) : i64
    %303 = llvm.insertelement %300, %301[%302 : i64] : vector<1xf64>
    %304 = llvm.insertvalue %303, %297[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %305 = llvm.extractvalue %283[0] : !llvm.array<1 x vector<4xf64>> 
    %306 = llvm.mlir.constant(3 : i64) : i64
    %307 = llvm.extractelement %305[%306 : i64] : vector<4xf64>
    %308 = llvm.extractvalue %28[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %309 = llvm.mlir.constant(0 : i64) : i64
    %310 = llvm.insertelement %307, %308[%309 : i64] : vector<1xf64>
    %311 = llvm.insertvalue %310, %304[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %312 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %313 = llvm.trunc %159 : i64 to i32
    %314 = llvm.mlir.undef : vector<4xi32>
    %315 = llvm.mlir.constant(0 : i32) : i32
    %316 = llvm.insertelement %313, %314[%315 : i32] : vector<4xi32>
    %317 = llvm.shufflevector %316, %314 [0, 0, 0, 0] : vector<4xi32> 
    %318 = llvm.icmp "sgt" %317, %312 : vector<4xi32>
    %319 = llvm.insertvalue %318, %27[0] : !llvm.array<1 x vector<4xi1>> 
    llvm.store %319, %79 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    %320 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %321 = llvm.extractvalue %77[0] : !llvm.struct<(ptr, ptr, i64)> 
    %322 = llvm.insertvalue %321, %320[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %323 = llvm.extractvalue %77[1] : !llvm.struct<(ptr, ptr, i64)> 
    %324 = llvm.insertvalue %323, %322[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %325 = llvm.mlir.constant(0 : index) : i64
    %326 = llvm.insertvalue %325, %324[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %327 = llvm.mlir.constant(1 : index) : i64
    %328 = llvm.insertvalue %327, %326[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %329 = llvm.mlir.constant(1 : index) : i64
    %330 = llvm.insertvalue %329, %328[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %331 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %332 = llvm.extractvalue %84[0] : !llvm.struct<(ptr, ptr, i64)> 
    %333 = llvm.insertvalue %332, %331[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %334 = llvm.extractvalue %84[1] : !llvm.struct<(ptr, ptr, i64)> 
    %335 = llvm.insertvalue %334, %333[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %336 = llvm.mlir.constant(0 : index) : i64
    %337 = llvm.insertvalue %336, %335[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %338 = llvm.mlir.constant(1 : index) : i64
    %339 = llvm.insertvalue %338, %337[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %340 = llvm.mlir.constant(1 : index) : i64
    %341 = llvm.insertvalue %340, %339[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb23(%36 : i64)
  ^bb23(%342: i64):  // 2 preds: ^bb22, ^bb24
    %343 = llvm.icmp "slt" %342, %34 : i64
    llvm.cond_br %343, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %344 = llvm.getelementptr %334[%342] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %345 = llvm.load %344 : !llvm.ptr -> vector<4xi1>
    %346 = llvm.extractvalue %206[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %347 = llvm.extractvalue %206[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %348 = llvm.getelementptr %346[%347] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %349 = llvm.mlir.constant(65 : index) : i64
    %350 = llvm.mul %342, %349  : i64
    %351 = llvm.add %350, %36  : i64
    %352 = llvm.getelementptr %348[%351] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %353 = llvm.intr.masked.load %352, %345, %26 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %354 = llvm.getelementptr %323[%342] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %353, %354 : vector<4xf64>, !llvm.ptr
    %355 = llvm.add %342, %34  : i64
    llvm.br ^bb23(%355 : i64)
  ^bb25:  // pred: ^bb23
    %356 = llvm.load %72 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %357 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %358 = llvm.extractvalue %238[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %359 = llvm.fmul %358, %289  : vector<1xf64>
    %360 = llvm.insertvalue %359, %357[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %361 = llvm.extractvalue %238[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %362 = llvm.fmul %361, %296  : vector<1xf64>
    %363 = llvm.insertvalue %362, %360[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %364 = llvm.extractvalue %238[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %365 = llvm.fmul %364, %303  : vector<1xf64>
    %366 = llvm.insertvalue %365, %363[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %367 = llvm.extractvalue %238[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %368 = llvm.fmul %367, %310  : vector<1xf64>
    %369 = llvm.insertvalue %368, %366[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %370 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %371 = llvm.trunc %159 : i64 to i32
    %372 = llvm.mlir.undef : vector<4xi32>
    %373 = llvm.mlir.constant(0 : i32) : i32
    %374 = llvm.insertelement %371, %372[%373 : i32] : vector<4xi32>
    %375 = llvm.shufflevector %374, %372 [0, 0, 0, 0] : vector<4xi32> 
    %376 = llvm.icmp "sgt" %375, %370 : vector<4xi32>
    %377 = llvm.extractvalue %356[0] : !llvm.array<1 x vector<4xf64>> 
    %378 = llvm.mlir.constant(0 : i64) : i64
    %379 = llvm.extractelement %376[%378 : i64] : vector<4xi1>
    %380 = llvm.mlir.constant(0 : i64) : i64
    %381 = llvm.insertelement %379, %25[%380 : i64] : vector<4xi1>
    %382 = llvm.mlir.constant(1 : i64) : i64
    %383 = llvm.extractelement %376[%382 : i64] : vector<4xi1>
    %384 = llvm.mlir.constant(1 : i64) : i64
    %385 = llvm.insertelement %383, %381[%384 : i64] : vector<4xi1>
    %386 = llvm.mlir.constant(2 : i64) : i64
    %387 = llvm.extractelement %376[%386 : i64] : vector<4xi1>
    %388 = llvm.mlir.constant(2 : i64) : i64
    %389 = llvm.insertelement %387, %385[%388 : i64] : vector<4xi1>
    %390 = llvm.mlir.constant(3 : i64) : i64
    %391 = llvm.extractelement %376[%390 : i64] : vector<4xi1>
    %392 = llvm.mlir.constant(3 : i64) : i64
    %393 = llvm.insertelement %391, %389[%392 : i64] : vector<4xi1>
    %394 = llvm.extractvalue %369[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %395 = llvm.mlir.constant(0 : i64) : i64
    %396 = llvm.extractelement %394[%395 : i64] : vector<1xf64>
    %397 = llvm.mlir.constant(0 : i64) : i64
    %398 = llvm.insertelement %396, %26[%397 : i64] : vector<4xf64>
    %399 = llvm.extractvalue %369[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %400 = llvm.mlir.constant(0 : i64) : i64
    %401 = llvm.extractelement %399[%400 : i64] : vector<1xf64>
    %402 = llvm.mlir.constant(1 : i64) : i64
    %403 = llvm.insertelement %401, %398[%402 : i64] : vector<4xf64>
    %404 = llvm.extractvalue %369[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %405 = llvm.mlir.constant(0 : i64) : i64
    %406 = llvm.extractelement %404[%405 : i64] : vector<1xf64>
    %407 = llvm.mlir.constant(2 : i64) : i64
    %408 = llvm.insertelement %406, %403[%407 : i64] : vector<4xf64>
    %409 = llvm.extractvalue %369[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %410 = llvm.mlir.constant(0 : i64) : i64
    %411 = llvm.extractelement %409[%410 : i64] : vector<1xf64>
    %412 = llvm.mlir.constant(3 : i64) : i64
    %413 = llvm.insertelement %411, %408[%412 : i64] : vector<4xf64>
    %414 = llvm.fadd %377, %413  : vector<4xf64>
    %415 = llvm.select %393, %414, %413 : vector<4xi1>, vector<4xf64>
    %416 = llvm.insertvalue %415, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %319, %93 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    llvm.store %416, %86 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %417 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %418 = llvm.extractvalue %91[0] : !llvm.struct<(ptr, ptr, i64)> 
    %419 = llvm.insertvalue %418, %417[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %420 = llvm.extractvalue %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %421 = llvm.insertvalue %420, %419[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %422 = llvm.mlir.constant(0 : index) : i64
    %423 = llvm.insertvalue %422, %421[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %424 = llvm.mlir.constant(1 : index) : i64
    %425 = llvm.insertvalue %424, %423[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %426 = llvm.mlir.constant(1 : index) : i64
    %427 = llvm.insertvalue %426, %425[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %428 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %429 = llvm.extractvalue %98[0] : !llvm.struct<(ptr, ptr, i64)> 
    %430 = llvm.insertvalue %429, %428[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %431 = llvm.extractvalue %98[1] : !llvm.struct<(ptr, ptr, i64)> 
    %432 = llvm.insertvalue %431, %430[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %433 = llvm.mlir.constant(0 : index) : i64
    %434 = llvm.insertvalue %433, %432[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %435 = llvm.mlir.constant(1 : index) : i64
    %436 = llvm.insertvalue %435, %434[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %437 = llvm.mlir.constant(1 : index) : i64
    %438 = llvm.insertvalue %437, %436[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb26(%36 : i64)
  ^bb26(%439: i64):  // 2 preds: ^bb25, ^bb27
    %440 = llvm.icmp "slt" %439, %34 : i64
    llvm.cond_br %440, ^bb27, ^bb28
  ^bb27:  // pred: ^bb26
    %441 = llvm.getelementptr %420[%439] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %442 = llvm.load %441 : !llvm.ptr -> vector<4xf64>
    %443 = llvm.getelementptr %431[%439] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %444 = llvm.load %443 : !llvm.ptr -> vector<4xi1>
    %445 = llvm.extractvalue %206[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %446 = llvm.extractvalue %206[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %447 = llvm.getelementptr %445[%446] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %448 = llvm.mlir.constant(65 : index) : i64
    %449 = llvm.mul %439, %448  : i64
    %450 = llvm.add %449, %36  : i64
    %451 = llvm.getelementptr %447[%450] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.intr.masked.store %442, %451, %444 {alignment = 8 : i32} : vector<4xf64>, vector<4xi1> into !llvm.ptr
    %452 = llvm.add %439, %34  : i64
    llvm.br ^bb26(%452 : i64)
  ^bb28:  // pred: ^bb26
    %453 = llvm.add %154, %34  : i64
    llvm.br ^bb15(%453 : i64)
  ^bb29:  // pred: ^bb15
    %454 = llvm.add %152, %35  : i64
    llvm.br ^bb13(%454 : i64)
  ^bb30:  // pred: ^bb13
    %455 = llvm.add %150, %34  : i64
    llvm.br ^bb11(%455 : i64)
  ^bb31:  // pred: ^bb11
    %456 = llvm.add %131, %37  : i64
    llvm.br ^bb9(%456 : i64)
  ^bb32:  // pred: ^bb9
    %457 = llvm.add %99, %37  : i64
    llvm.br ^bb7(%457 : i64)
  ^bb33:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
