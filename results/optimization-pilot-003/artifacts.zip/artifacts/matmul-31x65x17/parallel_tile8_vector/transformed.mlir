#map = affine_map<(d0) -> (-d0 + 31, 8)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0) -> (-d0 + 65, 8)>
#map3 = affine_map<(d0, d1) -> (d0 - d1, 4)>
#map4 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map5 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<31x17xf64>, %arg1: memref<17x65xf64>, %arg2: memref<31x65xf64>) attributes {llvm.emit_c_interface} {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c1_0 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c0_1 = arith.constant 0 : index
    %c8_2 = arith.constant 8 : index
    %c0_3 = arith.constant 0 : index
    %c0_4 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<31x65xf64>)
    %c0_5 = arith.constant 0 : index
    %c31 = arith.constant 31 : index
    %c8_6 = arith.constant 8 : index
    scf.for %arg3 = %c0_5 to %c31 step %c8_6 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 17] [1, 1] : memref<31x17xf64> to memref<?x17xf64, strided<[17, 1], offset: ?>>
      %subview_7 = memref.subview %arg2[%arg3, 0] [%1, 65] [1, 1] : memref<31x65xf64> to memref<?x65xf64, strided<[65, 1], offset: ?>>
      %c0_8 = arith.constant 0 : index
      %c0_9 = arith.constant 0 : index
      %c0_10 = arith.constant 0 : index
      %c65 = arith.constant 65 : index
      %c8_11 = arith.constant 8 : index
      scf.for %arg4 = %c0_10 to %c65 step %c8_11 {
        %2 = affine.apply #map1(%0)
        %3 = affine.apply #map1(%0)
        %4 = affine.min #map2(%arg4)
        %c0_12 = arith.constant 0 : index
        %5 = affine.apply #map1(%0)
        %6 = affine.min #map2(%arg4)
        %subview_13 = memref.subview %arg1[0, %arg4] [17, %4] [1, 1] : memref<17x65xf64> to memref<17x?xf64, strided<[65, 1], offset: ?>>
        %subview_14 = memref.subview %subview_7[0, %arg4] [%1, %6] [1, 1] : memref<?x65xf64, strided<[65, 1], offset: ?>> to memref<?x?xf64, strided<[65, 1], offset: ?>>
        %c0_15 = arith.constant 0 : index
        %c1_16 = arith.constant 1 : index
        %c0_17 = arith.constant 0 : index
        %c1_18 = arith.constant 1 : index
        %c0_19 = arith.constant 0 : index
        %c1_20 = arith.constant 1 : index
        %c0_21 = arith.constant 0 : index
        %c4_22 = arith.constant 4 : index
        %c0_23 = arith.constant 0 : index
        %c17 = arith.constant 17 : index
        %c1_24 = arith.constant 1 : index
        scf.for %arg5 = %c0_19 to %0 step %c1_20 {
          scf.for %arg6 = %c0_21 to %4 step %c4_22 {
            scf.for %arg7 = %c0_23 to %c17 step %c1_24 {
              %7 = affine.apply #map1(%0)
              %8 = affine.apply #map1(%4)
              %9 = affine.apply #map1(%4)
              %10 = affine.min #map3(%4, %arg6)
              %11 = affine.apply #map1(%0)
              %12 = affine.apply #map1(%4)
              %13 = affine.apply #map1(%4)
              %14 = affine.min #map3(%4, %arg6)
              %subview_25 = memref.subview %subview[%arg5, %arg7] [1, 1] [1, 1] : memref<?x17xf64, strided<[17, 1], offset: ?>> to memref<1x1xf64, strided<[17, 1], offset: ?>>
              %subview_26 = memref.subview %subview_13[%arg7, %arg6] [1, %10] [1, 1] : memref<17x?xf64, strided<[65, 1], offset: ?>> to memref<1x?xf64, strided<[65, 1], offset: ?>>
              %subview_27 = memref.subview %subview_14[%arg5, %arg6] [1, %14] [1, 1] : memref<?x?xf64, strided<[65, 1], offset: ?>> to memref<1x?xf64, strided<[65, 1], offset: ?>>
              %c1_28 = arith.constant 1 : index
              %c1_29 = arith.constant 1 : index
              %dim = memref.dim %subview_26, %c1_29 : memref<1x?xf64, strided<[65, 1], offset: ?>>
              %c1_30 = arith.constant 1 : index
              %c0_31 = arith.constant 0 : index
              %cst_32 = arith.constant 0.000000e+00 : f64
              %15 = vector.transfer_read %subview_25[%c0_31, %c0_31], %cst_32 {permutation_map = #map4} : memref<1x1xf64, strided<[17, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_33 = arith.constant 0.000000e+00 : f64
              %16 = vector.create_mask %c1_30, %dim : vector<1x4xi1>
              %17 = vector.mask %16 { vector.transfer_read %subview_26[%c0_31, %c0_31], %cst_33 {in_bounds = [true, true, true], permutation_map = #map5} : memref<1x?xf64, strided<[65, 1], offset: ?>>, vector<1x4x1xf64> } : vector<1x4xi1> -> vector<1x4x1xf64>
              %cst_34 = arith.constant 0.000000e+00 : f64
              %18 = vector.create_mask %c1_28, %dim : vector<1x4xi1>
              %19 = vector.mask %18 { vector.transfer_read %subview_27[%c0_31, %c0_31], %cst_34 {in_bounds = [true, true]} : memref<1x?xf64, strided<[65, 1], offset: ?>>, vector<1x4xf64> } : vector<1x4xi1> -> vector<1x4xf64>
              %20 = arith.mulf %15, %17 : vector<1x4x1xf64>
              %21 = vector.create_mask %c1_28, %dim, %c1_30 : vector<1x4x1xi1>
              %22 = vector.mask %21 { vector.multi_reduction <add>, %20, %19 [2] : vector<1x4x1xf64> to vector<1x4xf64> } : vector<1x4x1xi1> -> vector<1x4xf64>
              %c0_35 = arith.constant 0 : index
              vector.mask %18 { vector.transfer_write %22, %subview_27[%c0_35, %c0_35] {in_bounds = [true, true]} : vector<1x4xf64>, memref<1x?xf64, strided<[65, 1], offset: ?>> } : vector<1x4xi1>
            }
          }
        }
      }
    }
    return
  }
}
