; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %15, i8 0, i64 16120, i1 false)
  br label %.preheader16.us.preheader

.preheader16.us.preheader:                        ; preds = %.split20.us, %.preheader17.preheader
  %21 = phi i64 [ 0, %.preheader17.preheader ], [ %91, %.split20.us ]
  %22 = sub nuw nsw i64 65, %21
  %23 = tail call i64 @llvm.smin.i64(i64 %22, i64 8)
  %24 = getelementptr double, ptr %8, i64 %21
  %25 = getelementptr double, ptr %15, i64 %21
  %26 = tail call i64 @llvm.smin.i64(i64 %22, i64 4)
  %27 = trunc i64 %26 to i32
  %28 = insertelement <4 x i32> poison, i32 %27, i64 0
  %29 = shufflevector <4 x i32> %28, <4 x i32> poison, <4 x i32> zeroinitializer
  %30 = icmp sgt <4 x i32> %29, <i32 0, i32 1, i32 2, i32 3>
  %31 = icmp ugt i64 %23, 4
  %32 = trunc i64 %23 to i32
  %33 = add i32 %32, -4
  %34 = insertelement <4 x i32> poison, i32 %33, i64 0
  %35 = shufflevector <4 x i32> %34, <4 x i32> poison, <4 x i32> zeroinitializer
  %36 = icmp sgt <4 x i32> %35, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.127 = getelementptr double, ptr %24, i64 4
  br label %.preheader16.us

.preheader16.us:                                  ; preds = %.preheader16.us.preheader, %._crit_edge.us
  %37 = phi i64 [ %90, %._crit_edge.us ], [ 0, %.preheader16.us.preheader ]
  %38 = mul nuw nsw i64 %37, 17
  %39 = mul nuw nsw i64 %37, 65
  %40 = getelementptr double, ptr %1, i64 %38
  %41 = getelementptr double, ptr %25, i64 %39
  br label %.critedge.us

42:                                               ; preds = %.critedge.us
  br i1 %31, label %.preheader.us.128, label %._crit_edge.us

.preheader.us.128:                                ; preds = %42
  %43 = getelementptr double, ptr %41, i64 4
  br label %.critedge.us.130

.critedge.us.130:                                 ; preds = %.critedge.us.130, %.preheader.us.128
  %44 = phi i64 [ 0, %.preheader.us.128 ], [ %66, %.critedge.us.130 ]
  %45 = mul nuw nsw i64 %44, 65
  %46 = getelementptr double, ptr %40, i64 %44
  %47 = load double, ptr %46, align 8
  %48 = insertelement <1 x double> poison, double %47, i64 0
  %gep.us.129 = getelementptr double, ptr %invariant.gep.us.127, i64 %45
  %49 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.129, i32 8, <4 x i1> %36, <4 x double> zeroinitializer)
  %50 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> zeroinitializer
  %51 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 1>
  %52 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 2>
  %53 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 3>
  %54 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %43, i32 8, <4 x i1> %36, <4 x double> zeroinitializer)
  %55 = fmul <1 x double> %48, %50
  %56 = fmul <1 x double> %48, %51
  %57 = fmul <1 x double> %48, %52
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = fmul <1 x double> %48, %53
  %60 = shufflevector <1 x double> %59, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <1 x double> %55, <1 x double> %56, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %64 = select <4 x i1> %36, <4 x double> %54, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %65 = fadd <4 x double> %64, %63
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %65, ptr %43, i32 8, <4 x i1> %36)
  %66 = add nuw nsw i64 %44, 1
  %exitcond.not.1 = icmp eq i64 %66, 17
  br i1 %exitcond.not.1, label %._crit_edge.us, label %.critedge.us.130

.critedge.us:                                     ; preds = %.preheader16.us, %.critedge.us
  %67 = phi i64 [ 0, %.preheader16.us ], [ %89, %.critedge.us ]
  %68 = mul nuw nsw i64 %67, 65
  %69 = getelementptr double, ptr %40, i64 %67
  %70 = load double, ptr %69, align 8
  %71 = insertelement <1 x double> poison, double %70, i64 0
  %gep.us = getelementptr double, ptr %24, i64 %68
  %72 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us, i32 8, <4 x i1> %30, <4 x double> zeroinitializer)
  %73 = shufflevector <4 x double> %72, <4 x double> poison, <1 x i32> zeroinitializer
  %74 = shufflevector <4 x double> %72, <4 x double> poison, <1 x i32> <i32 1>
  %75 = shufflevector <4 x double> %72, <4 x double> poison, <1 x i32> <i32 2>
  %76 = shufflevector <4 x double> %72, <4 x double> poison, <1 x i32> <i32 3>
  %77 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %41, i32 8, <4 x i1> %30, <4 x double> zeroinitializer)
  %78 = fmul <1 x double> %71, %73
  %79 = fmul <1 x double> %71, %74
  %80 = fmul <1 x double> %71, %75
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = fmul <1 x double> %71, %76
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = shufflevector <1 x double> %78, <1 x double> %79, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %85 = shufflevector <4 x double> %84, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %87 = select <4 x i1> %30, <4 x double> %77, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %88 = fadd <4 x double> %87, %86
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %88, ptr %41, i32 8, <4 x i1> %30)
  %89 = add nuw nsw i64 %67, 1
  %exitcond.not = icmp eq i64 %89, 17
  br i1 %exitcond.not, label %42, label %.critedge.us

._crit_edge.us:                                   ; preds = %.critedge.us.130, %42
  %90 = add nuw nsw i64 %37, 1
  %exitcond22.not = icmp eq i64 %90, 8
  br i1 %exitcond22.not, label %.split20.us, label %.preheader16.us

.split20.us:                                      ; preds = %._crit_edge.us
  %91 = add nuw nsw i64 %21, 8
  %92 = icmp ult i64 %21, 57
  br i1 %92, label %.preheader16.us.preheader, label %.preheader17.1

.preheader17.1:                                   ; preds = %.split20.us
  %93 = getelementptr double, ptr %15, i64 520
  %invariant.gep = getelementptr double, ptr %1, i64 136
  br label %.preheader16.us.preheader.1

.preheader16.us.preheader.1:                      ; preds = %.preheader17.1, %.split20.us.1
  %94 = phi i64 [ 0, %.preheader17.1 ], [ %163, %.split20.us.1 ]
  %95 = sub nuw nsw i64 65, %94
  %96 = tail call i64 @llvm.smin.i64(i64 %95, i64 8)
  %97 = getelementptr double, ptr %8, i64 %94
  %98 = getelementptr double, ptr %93, i64 %94
  %99 = tail call i64 @llvm.smin.i64(i64 %95, i64 4)
  %100 = trunc i64 %99 to i32
  %101 = insertelement <4 x i32> poison, i32 %100, i64 0
  %102 = shufflevector <4 x i32> %101, <4 x i32> poison, <4 x i32> zeroinitializer
  %103 = icmp sgt <4 x i32> %102, <i32 0, i32 1, i32 2, i32 3>
  %104 = icmp ugt i64 %96, 4
  %105 = trunc i64 %96 to i32
  %106 = add i32 %105, -4
  %107 = insertelement <4 x i32> poison, i32 %106, i64 0
  %108 = shufflevector <4 x i32> %107, <4 x i32> poison, <4 x i32> zeroinitializer
  %109 = icmp sgt <4 x i32> %108, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.1.1 = getelementptr double, ptr %97, i64 4
  br label %.preheader16.us.1

.preheader16.us.1:                                ; preds = %._crit_edge.us.1, %.preheader16.us.preheader.1
  %110 = phi i64 [ %162, %._crit_edge.us.1 ], [ 0, %.preheader16.us.preheader.1 ]
  %111 = mul nuw i64 %110, 17
  %112 = mul nuw nsw i64 %110, 65
  %gep = getelementptr double, ptr %invariant.gep, i64 %111
  %113 = getelementptr double, ptr %98, i64 %112
  br label %.critedge.us.1

.critedge.us.1:                                   ; preds = %.critedge.us.1, %.preheader16.us.1
  %114 = phi i64 [ 0, %.preheader16.us.1 ], [ %136, %.critedge.us.1 ]
  %115 = mul nuw nsw i64 %114, 65
  %116 = getelementptr double, ptr %gep, i64 %114
  %117 = load double, ptr %116, align 8
  %118 = insertelement <1 x double> poison, double %117, i64 0
  %gep.us.1 = getelementptr double, ptr %97, i64 %115
  %119 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1, i32 8, <4 x i1> %103, <4 x double> zeroinitializer)
  %120 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> zeroinitializer
  %121 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 1>
  %122 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 2>
  %123 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 3>
  %124 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %113, i32 8, <4 x i1> %103, <4 x double> zeroinitializer)
  %125 = fmul <1 x double> %118, %120
  %126 = fmul <1 x double> %118, %121
  %127 = fmul <1 x double> %118, %122
  %128 = shufflevector <1 x double> %127, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %129 = fmul <1 x double> %118, %123
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = shufflevector <1 x double> %125, <1 x double> %126, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %132 = shufflevector <4 x double> %131, <4 x double> %128, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %134 = select <4 x i1> %103, <4 x double> %124, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %135 = fadd <4 x double> %134, %133
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %135, ptr %113, i32 8, <4 x i1> %103)
  %136 = add nuw nsw i64 %114, 1
  %exitcond.1.not = icmp eq i64 %136, 17
  br i1 %exitcond.1.not, label %137, label %.critedge.us.1

137:                                              ; preds = %.critedge.us.1
  br i1 %104, label %.preheader.us.1.1, label %._crit_edge.us.1

.preheader.us.1.1:                                ; preds = %137
  %138 = getelementptr double, ptr %113, i64 4
  br label %.critedge.us.1.1

.critedge.us.1.1:                                 ; preds = %.critedge.us.1.1, %.preheader.us.1.1
  %139 = phi i64 [ 0, %.preheader.us.1.1 ], [ %161, %.critedge.us.1.1 ]
  %140 = mul nuw nsw i64 %139, 65
  %141 = getelementptr double, ptr %gep, i64 %139
  %142 = load double, ptr %141, align 8
  %143 = insertelement <1 x double> poison, double %142, i64 0
  %gep.us.1.1 = getelementptr double, ptr %invariant.gep.us.1.1, i64 %140
  %144 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.1.1, i32 8, <4 x i1> %109, <4 x double> zeroinitializer)
  %145 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> zeroinitializer
  %146 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 1>
  %147 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 2>
  %148 = shufflevector <4 x double> %144, <4 x double> poison, <1 x i32> <i32 3>
  %149 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %138, i32 8, <4 x i1> %109, <4 x double> zeroinitializer)
  %150 = fmul <1 x double> %143, %145
  %151 = fmul <1 x double> %143, %146
  %152 = fmul <1 x double> %143, %147
  %153 = shufflevector <1 x double> %152, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %154 = fmul <1 x double> %143, %148
  %155 = shufflevector <1 x double> %154, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %156 = shufflevector <1 x double> %150, <1 x double> %151, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %157 = shufflevector <4 x double> %156, <4 x double> %153, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %158 = shufflevector <4 x double> %157, <4 x double> %155, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %159 = select <4 x i1> %109, <4 x double> %149, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %160 = fadd <4 x double> %159, %158
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %160, ptr %138, i32 8, <4 x i1> %109)
  %161 = add nuw nsw i64 %139, 1
  %exitcond.1.not.1 = icmp eq i64 %161, 17
  br i1 %exitcond.1.not.1, label %._crit_edge.us.1, label %.critedge.us.1.1

._crit_edge.us.1:                                 ; preds = %.critedge.us.1.1, %137
  %162 = add nuw nsw i64 %110, 1
  %exitcond22.1.not = icmp eq i64 %162, 8
  br i1 %exitcond22.1.not, label %.split20.us.1, label %.preheader16.us.1

.split20.us.1:                                    ; preds = %._crit_edge.us.1
  %163 = add nuw nsw i64 %94, 8
  %164 = icmp ult i64 %94, 57
  br i1 %164, label %.preheader16.us.preheader.1, label %.preheader17.2

.preheader17.2:                                   ; preds = %.split20.us.1
  %165 = getelementptr double, ptr %15, i64 1040
  %invariant.gep23 = getelementptr double, ptr %1, i64 272
  br label %.preheader16.us.preheader.2

.preheader16.us.preheader.2:                      ; preds = %.preheader17.2, %.split20.us.2
  %166 = phi i64 [ 0, %.preheader17.2 ], [ %235, %.split20.us.2 ]
  %167 = sub nuw nsw i64 65, %166
  %168 = tail call i64 @llvm.smin.i64(i64 %167, i64 8)
  %169 = getelementptr double, ptr %8, i64 %166
  %170 = getelementptr double, ptr %165, i64 %166
  %171 = tail call i64 @llvm.smin.i64(i64 %167, i64 4)
  %172 = trunc i64 %171 to i32
  %173 = insertelement <4 x i32> poison, i32 %172, i64 0
  %174 = shufflevector <4 x i32> %173, <4 x i32> poison, <4 x i32> zeroinitializer
  %175 = icmp sgt <4 x i32> %174, <i32 0, i32 1, i32 2, i32 3>
  %176 = icmp ugt i64 %168, 4
  %177 = trunc i64 %168 to i32
  %178 = add i32 %177, -4
  %179 = insertelement <4 x i32> poison, i32 %178, i64 0
  %180 = shufflevector <4 x i32> %179, <4 x i32> poison, <4 x i32> zeroinitializer
  %181 = icmp sgt <4 x i32> %180, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.2.1 = getelementptr double, ptr %169, i64 4
  br label %.preheader16.us.2

.preheader16.us.2:                                ; preds = %._crit_edge.us.2, %.preheader16.us.preheader.2
  %182 = phi i64 [ %234, %._crit_edge.us.2 ], [ 0, %.preheader16.us.preheader.2 ]
  %183 = mul nuw i64 %182, 17
  %184 = mul nuw nsw i64 %182, 65
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %183
  %185 = getelementptr double, ptr %170, i64 %184
  br label %.critedge.us.2

.critedge.us.2:                                   ; preds = %.critedge.us.2, %.preheader16.us.2
  %186 = phi i64 [ 0, %.preheader16.us.2 ], [ %208, %.critedge.us.2 ]
  %187 = mul nuw nsw i64 %186, 65
  %188 = getelementptr double, ptr %gep24, i64 %186
  %189 = load double, ptr %188, align 8
  %190 = insertelement <1 x double> poison, double %189, i64 0
  %gep.us.2 = getelementptr double, ptr %169, i64 %187
  %191 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.2, i32 8, <4 x i1> %175, <4 x double> zeroinitializer)
  %192 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> zeroinitializer
  %193 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 1>
  %194 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 2>
  %195 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 3>
  %196 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %185, i32 8, <4 x i1> %175, <4 x double> zeroinitializer)
  %197 = fmul <1 x double> %190, %192
  %198 = fmul <1 x double> %190, %193
  %199 = fmul <1 x double> %190, %194
  %200 = shufflevector <1 x double> %199, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %201 = fmul <1 x double> %190, %195
  %202 = shufflevector <1 x double> %201, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %203 = shufflevector <1 x double> %197, <1 x double> %198, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %204 = shufflevector <4 x double> %203, <4 x double> %200, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %205 = shufflevector <4 x double> %204, <4 x double> %202, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %206 = select <4 x i1> %175, <4 x double> %196, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %207 = fadd <4 x double> %206, %205
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %207, ptr %185, i32 8, <4 x i1> %175)
  %208 = add nuw nsw i64 %186, 1
  %exitcond.2.not = icmp eq i64 %208, 17
  br i1 %exitcond.2.not, label %209, label %.critedge.us.2

209:                                              ; preds = %.critedge.us.2
  br i1 %176, label %.preheader.us.2.1, label %._crit_edge.us.2

.preheader.us.2.1:                                ; preds = %209
  %210 = getelementptr double, ptr %185, i64 4
  br label %.critedge.us.2.1

.critedge.us.2.1:                                 ; preds = %.critedge.us.2.1, %.preheader.us.2.1
  %211 = phi i64 [ 0, %.preheader.us.2.1 ], [ %233, %.critedge.us.2.1 ]
  %212 = mul nuw nsw i64 %211, 65
  %213 = getelementptr double, ptr %gep24, i64 %211
  %214 = load double, ptr %213, align 8
  %215 = insertelement <1 x double> poison, double %214, i64 0
  %gep.us.2.1 = getelementptr double, ptr %invariant.gep.us.2.1, i64 %212
  %216 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.2.1, i32 8, <4 x i1> %181, <4 x double> zeroinitializer)
  %217 = shufflevector <4 x double> %216, <4 x double> poison, <1 x i32> zeroinitializer
  %218 = shufflevector <4 x double> %216, <4 x double> poison, <1 x i32> <i32 1>
  %219 = shufflevector <4 x double> %216, <4 x double> poison, <1 x i32> <i32 2>
  %220 = shufflevector <4 x double> %216, <4 x double> poison, <1 x i32> <i32 3>
  %221 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %210, i32 8, <4 x i1> %181, <4 x double> zeroinitializer)
  %222 = fmul <1 x double> %215, %217
  %223 = fmul <1 x double> %215, %218
  %224 = fmul <1 x double> %215, %219
  %225 = shufflevector <1 x double> %224, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %226 = fmul <1 x double> %215, %220
  %227 = shufflevector <1 x double> %226, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %228 = shufflevector <1 x double> %222, <1 x double> %223, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %229 = shufflevector <4 x double> %228, <4 x double> %225, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %230 = shufflevector <4 x double> %229, <4 x double> %227, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %231 = select <4 x i1> %181, <4 x double> %221, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %232 = fadd <4 x double> %231, %230
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %232, ptr %210, i32 8, <4 x i1> %181)
  %233 = add nuw nsw i64 %211, 1
  %exitcond.2.not.1 = icmp eq i64 %233, 17
  br i1 %exitcond.2.not.1, label %._crit_edge.us.2, label %.critedge.us.2.1

._crit_edge.us.2:                                 ; preds = %.critedge.us.2.1, %209
  %234 = add nuw nsw i64 %182, 1
  %exitcond22.2.not = icmp eq i64 %234, 8
  br i1 %exitcond22.2.not, label %.split20.us.2, label %.preheader16.us.2

.split20.us.2:                                    ; preds = %._crit_edge.us.2
  %235 = add nuw nsw i64 %166, 8
  %236 = icmp ult i64 %166, 57
  br i1 %236, label %.preheader16.us.preheader.2, label %.preheader17.3

.preheader17.3:                                   ; preds = %.split20.us.2
  %237 = getelementptr double, ptr %15, i64 1560
  %invariant.gep25 = getelementptr double, ptr %1, i64 408
  br label %.preheader16.us.preheader.3

.preheader16.us.preheader.3:                      ; preds = %.preheader17.3, %.split20.us.3
  %238 = phi i64 [ 0, %.preheader17.3 ], [ %307, %.split20.us.3 ]
  %239 = sub nuw nsw i64 65, %238
  %240 = tail call i64 @llvm.smin.i64(i64 %239, i64 8)
  %241 = getelementptr double, ptr %8, i64 %238
  %242 = getelementptr double, ptr %237, i64 %238
  %243 = tail call i64 @llvm.smin.i64(i64 %239, i64 4)
  %244 = trunc i64 %243 to i32
  %245 = insertelement <4 x i32> poison, i32 %244, i64 0
  %246 = shufflevector <4 x i32> %245, <4 x i32> poison, <4 x i32> zeroinitializer
  %247 = icmp sgt <4 x i32> %246, <i32 0, i32 1, i32 2, i32 3>
  %248 = icmp ugt i64 %240, 4
  %249 = trunc i64 %240 to i32
  %250 = add i32 %249, -4
  %251 = insertelement <4 x i32> poison, i32 %250, i64 0
  %252 = shufflevector <4 x i32> %251, <4 x i32> poison, <4 x i32> zeroinitializer
  %253 = icmp sgt <4 x i32> %252, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.us.3.1 = getelementptr double, ptr %241, i64 4
  br label %.preheader16.us.3

.preheader16.us.3:                                ; preds = %._crit_edge.us.3, %.preheader16.us.preheader.3
  %254 = phi i64 [ %306, %._crit_edge.us.3 ], [ 0, %.preheader16.us.preheader.3 ]
  %255 = mul nuw i64 %254, 17
  %256 = mul nuw nsw i64 %254, 65
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %255
  %257 = getelementptr double, ptr %242, i64 %256
  br label %.critedge.us.3

.critedge.us.3:                                   ; preds = %.critedge.us.3, %.preheader16.us.3
  %258 = phi i64 [ 0, %.preheader16.us.3 ], [ %280, %.critedge.us.3 ]
  %259 = mul nuw nsw i64 %258, 65
  %260 = getelementptr double, ptr %gep26, i64 %258
  %261 = load double, ptr %260, align 8
  %262 = insertelement <1 x double> poison, double %261, i64 0
  %gep.us.3 = getelementptr double, ptr %241, i64 %259
  %263 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.3, i32 8, <4 x i1> %247, <4 x double> zeroinitializer)
  %264 = shufflevector <4 x double> %263, <4 x double> poison, <1 x i32> zeroinitializer
  %265 = shufflevector <4 x double> %263, <4 x double> poison, <1 x i32> <i32 1>
  %266 = shufflevector <4 x double> %263, <4 x double> poison, <1 x i32> <i32 2>
  %267 = shufflevector <4 x double> %263, <4 x double> poison, <1 x i32> <i32 3>
  %268 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %257, i32 8, <4 x i1> %247, <4 x double> zeroinitializer)
  %269 = fmul <1 x double> %262, %264
  %270 = fmul <1 x double> %262, %265
  %271 = fmul <1 x double> %262, %266
  %272 = shufflevector <1 x double> %271, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %273 = fmul <1 x double> %262, %267
  %274 = shufflevector <1 x double> %273, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %275 = shufflevector <1 x double> %269, <1 x double> %270, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %276 = shufflevector <4 x double> %275, <4 x double> %272, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %277 = shufflevector <4 x double> %276, <4 x double> %274, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %278 = select <4 x i1> %247, <4 x double> %268, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %279 = fadd <4 x double> %278, %277
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %279, ptr %257, i32 8, <4 x i1> %247)
  %280 = add nuw nsw i64 %258, 1
  %exitcond.3.not = icmp eq i64 %280, 17
  br i1 %exitcond.3.not, label %281, label %.critedge.us.3

281:                                              ; preds = %.critedge.us.3
  br i1 %248, label %.preheader.us.3.1, label %._crit_edge.us.3

.preheader.us.3.1:                                ; preds = %281
  %282 = getelementptr double, ptr %257, i64 4
  br label %.critedge.us.3.1

.critedge.us.3.1:                                 ; preds = %.critedge.us.3.1, %.preheader.us.3.1
  %283 = phi i64 [ 0, %.preheader.us.3.1 ], [ %305, %.critedge.us.3.1 ]
  %284 = mul nuw nsw i64 %283, 65
  %285 = getelementptr double, ptr %gep26, i64 %283
  %286 = load double, ptr %285, align 8
  %287 = insertelement <1 x double> poison, double %286, i64 0
  %gep.us.3.1 = getelementptr double, ptr %invariant.gep.us.3.1, i64 %284
  %288 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.us.3.1, i32 8, <4 x i1> %253, <4 x double> zeroinitializer)
  %289 = shufflevector <4 x double> %288, <4 x double> poison, <1 x i32> zeroinitializer
  %290 = shufflevector <4 x double> %288, <4 x double> poison, <1 x i32> <i32 1>
  %291 = shufflevector <4 x double> %288, <4 x double> poison, <1 x i32> <i32 2>
  %292 = shufflevector <4 x double> %288, <4 x double> poison, <1 x i32> <i32 3>
  %293 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %282, i32 8, <4 x i1> %253, <4 x double> zeroinitializer)
  %294 = fmul <1 x double> %287, %289
  %295 = fmul <1 x double> %287, %290
  %296 = fmul <1 x double> %287, %291
  %297 = shufflevector <1 x double> %296, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %298 = fmul <1 x double> %287, %292
  %299 = shufflevector <1 x double> %298, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %300 = shufflevector <1 x double> %294, <1 x double> %295, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %301 = shufflevector <4 x double> %300, <4 x double> %297, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %302 = shufflevector <4 x double> %301, <4 x double> %299, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %303 = select <4 x i1> %253, <4 x double> %293, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %304 = fadd <4 x double> %303, %302
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %304, ptr %282, i32 8, <4 x i1> %253)
  %305 = add nuw nsw i64 %283, 1
  %exitcond.3.not.1 = icmp eq i64 %305, 17
  br i1 %exitcond.3.not.1, label %._crit_edge.us.3, label %.critedge.us.3.1

._crit_edge.us.3:                                 ; preds = %.critedge.us.3.1, %281
  %306 = add nuw nsw i64 %254, 1
  %exitcond22.3.not = icmp eq i64 %306, 7
  br i1 %exitcond22.3.not, label %.split20.us.3, label %.preheader16.us.3

.split20.us.3:                                    ; preds = %._crit_edge.us.3
  %307 = add nuw nsw i64 %238, 8
  %308 = icmp ult i64 %238, 57
  br i1 %308, label %.preheader16.us.preheader.3, label %309

309:                                              ; preds = %.split20.us.3
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
