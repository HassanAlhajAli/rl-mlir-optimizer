; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %198
  %21 = phi i64 [ %199, %198 ], [ 0, %.preheader17.preheader ]
  %22 = shl nuw nsw i64 %21, 6
  %invariant.gep43 = getelementptr double, ptr %1, i64 %22
  %invariant.gep44 = getelementptr double, ptr %1, i64 %22
  %invariant.gep46 = getelementptr double, ptr %1, i64 %22
  %invariant.gep48 = getelementptr double, ptr %1, i64 %22
  br label %23

23:                                               ; preds = %.preheader17, %195
  %24 = phi i64 [ 0, %.preheader17 ], [ %196, %195 ]
  %25 = or disjoint i64 %24, %22
  %26 = getelementptr double, ptr %15, i64 %25
  %invariant.gep41 = getelementptr double, ptr %8, i64 %24
  %invariant.gep35 = getelementptr double, ptr %invariant.gep.1, i64 %24
  %invariant.gep29 = getelementptr double, ptr %invariant.gep.2, i64 %24
  %invariant.gep23 = getelementptr double, ptr %invariant.gep.3, i64 %24
  br label %.preheader16

.preheader16:                                     ; preds = %23, %193
  %27 = phi i64 [ 0, %23 ], [ %194, %193 ]
  %28 = shl i64 %27, 6
  %29 = getelementptr double, ptr %26, i64 %28
  %.promoted = load <4 x double>, ptr %29, align 8
  %gep = getelementptr double, ptr %invariant.gep43, i64 %28
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %30 = phi i64 [ 0, %.preheader16 ], [ %69, %.critedge ]
  %31 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %68, %.critedge ]
  %32 = shl nuw nsw i64 %30, 6
  %gep40 = getelementptr double, ptr %gep, i64 %30
  %33 = load double, ptr %gep40, align 8
  %34 = insertelement <1 x double> poison, double %33, i64 0
  %gep42 = getelementptr double, ptr %invariant.gep41, i64 %32
  %35 = load <4 x double>, ptr %gep42, align 8
  %36 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> zeroinitializer
  %37 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 1>
  %38 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 2>
  %39 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 3>
  %40 = fmul <1 x double> %34, %36
  %41 = fmul <1 x double> %34, %37
  %42 = fmul <1 x double> %34, %38
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = fmul <1 x double> %34, %39
  %45 = shufflevector <1 x double> %44, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %46 = shufflevector <1 x double> %40, <1 x double> %41, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %45, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %49 = fadd <4 x double> %31, %48
  store <4 x double> %49, ptr %29, align 8
  %50 = or disjoint i64 %30, 1
  %51 = shl nuw nsw i64 %50, 6
  %gep40.1 = getelementptr double, ptr %gep, i64 %50
  %52 = load double, ptr %gep40.1, align 8
  %53 = insertelement <1 x double> poison, double %52, i64 0
  %gep42.1 = getelementptr double, ptr %invariant.gep41, i64 %51
  %54 = load <4 x double>, ptr %gep42.1, align 8
  %55 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> zeroinitializer
  %56 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 1>
  %57 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 2>
  %58 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 3>
  %59 = fmul <1 x double> %53, %55
  %60 = fmul <1 x double> %53, %56
  %61 = fmul <1 x double> %53, %57
  %62 = shufflevector <1 x double> %61, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %63 = fmul <1 x double> %53, %58
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = shufflevector <1 x double> %59, <1 x double> %60, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %62, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %68 = fadd <4 x double> %49, %67
  store <4 x double> %68, ptr %29, align 8
  %69 = add nuw nsw i64 %30, 2
  %exitcond.not.1 = icmp eq i64 %69, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %70 = getelementptr double, ptr %29, i64 4
  %.promoted.1 = load <4 x double>, ptr %70, align 8
  %gep45 = getelementptr double, ptr %invariant.gep44, i64 %28
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %71 = phi i64 [ 0, %.preheader.1 ], [ %110, %.critedge.1 ]
  %72 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %109, %.critedge.1 ]
  %73 = shl nuw nsw i64 %71, 6
  %gep34 = getelementptr double, ptr %gep45, i64 %71
  %74 = load double, ptr %gep34, align 8
  %75 = insertelement <1 x double> poison, double %74, i64 0
  %gep36 = getelementptr double, ptr %invariant.gep35, i64 %73
  %76 = load <4 x double>, ptr %gep36, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %75, %77
  %82 = fmul <1 x double> %75, %78
  %83 = fmul <1 x double> %75, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %75, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %72, %89
  store <4 x double> %90, ptr %70, align 8
  %91 = or disjoint i64 %71, 1
  %92 = shl nuw nsw i64 %91, 6
  %gep34.1 = getelementptr double, ptr %gep45, i64 %91
  %93 = load double, ptr %gep34.1, align 8
  %94 = insertelement <1 x double> poison, double %93, i64 0
  %gep36.1 = getelementptr double, ptr %invariant.gep35, i64 %92
  %95 = load <4 x double>, ptr %gep36.1, align 8
  %96 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> zeroinitializer
  %97 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 1>
  %98 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 2>
  %99 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 3>
  %100 = fmul <1 x double> %94, %96
  %101 = fmul <1 x double> %94, %97
  %102 = fmul <1 x double> %94, %98
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = fmul <1 x double> %94, %99
  %105 = shufflevector <1 x double> %104, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %106 = shufflevector <1 x double> %100, <1 x double> %101, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %105, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %109 = fadd <4 x double> %90, %108
  store <4 x double> %109, ptr %70, align 8
  %110 = add nuw nsw i64 %71, 2
  %exitcond.1.not.1 = icmp eq i64 %110, 64
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %111 = getelementptr double, ptr %29, i64 8
  %.promoted.2 = load <4 x double>, ptr %111, align 8
  %gep47 = getelementptr double, ptr %invariant.gep46, i64 %28
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %112 = phi i64 [ 0, %.preheader.2 ], [ %151, %.critedge.2 ]
  %113 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %150, %.critedge.2 ]
  %114 = shl nuw nsw i64 %112, 6
  %gep28 = getelementptr double, ptr %gep47, i64 %112
  %115 = load double, ptr %gep28, align 8
  %116 = insertelement <1 x double> poison, double %115, i64 0
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %114
  %117 = load <4 x double>, ptr %gep30, align 8
  %118 = shufflevector <4 x double> %117, <4 x double> poison, <1 x i32> zeroinitializer
  %119 = shufflevector <4 x double> %117, <4 x double> poison, <1 x i32> <i32 1>
  %120 = shufflevector <4 x double> %117, <4 x double> poison, <1 x i32> <i32 2>
  %121 = shufflevector <4 x double> %117, <4 x double> poison, <1 x i32> <i32 3>
  %122 = fmul <1 x double> %116, %118
  %123 = fmul <1 x double> %116, %119
  %124 = fmul <1 x double> %116, %120
  %125 = shufflevector <1 x double> %124, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %126 = fmul <1 x double> %116, %121
  %127 = shufflevector <1 x double> %126, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %128 = shufflevector <1 x double> %122, <1 x double> %123, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %129 = shufflevector <4 x double> %128, <4 x double> %125, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %130 = shufflevector <4 x double> %129, <4 x double> %127, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %131 = fadd <4 x double> %113, %130
  store <4 x double> %131, ptr %111, align 8
  %132 = or disjoint i64 %112, 1
  %133 = shl nuw nsw i64 %132, 6
  %gep28.1 = getelementptr double, ptr %gep47, i64 %132
  %134 = load double, ptr %gep28.1, align 8
  %135 = insertelement <1 x double> poison, double %134, i64 0
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %133
  %136 = load <4 x double>, ptr %gep30.1, align 8
  %137 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> zeroinitializer
  %138 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 1>
  %139 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 2>
  %140 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 3>
  %141 = fmul <1 x double> %135, %137
  %142 = fmul <1 x double> %135, %138
  %143 = fmul <1 x double> %135, %139
  %144 = shufflevector <1 x double> %143, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %145 = fmul <1 x double> %135, %140
  %146 = shufflevector <1 x double> %145, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %147 = shufflevector <1 x double> %141, <1 x double> %142, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %148 = shufflevector <4 x double> %147, <4 x double> %144, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %149 = shufflevector <4 x double> %148, <4 x double> %146, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %150 = fadd <4 x double> %131, %149
  store <4 x double> %150, ptr %111, align 8
  %151 = add nuw nsw i64 %112, 2
  %exitcond.2.not.1 = icmp eq i64 %151, 64
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %152 = getelementptr double, ptr %29, i64 12
  %.promoted.3 = load <4 x double>, ptr %152, align 8
  %gep49 = getelementptr double, ptr %invariant.gep48, i64 %28
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %153 = phi i64 [ 0, %.preheader.3 ], [ %192, %.critedge.3 ]
  %154 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %191, %.critedge.3 ]
  %155 = shl nuw nsw i64 %153, 6
  %gep22 = getelementptr double, ptr %gep49, i64 %153
  %156 = load double, ptr %gep22, align 8
  %157 = insertelement <1 x double> poison, double %156, i64 0
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %155
  %158 = load <4 x double>, ptr %gep24, align 8
  %159 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> zeroinitializer
  %160 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 1>
  %161 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 2>
  %162 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 3>
  %163 = fmul <1 x double> %157, %159
  %164 = fmul <1 x double> %157, %160
  %165 = fmul <1 x double> %157, %161
  %166 = shufflevector <1 x double> %165, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %167 = fmul <1 x double> %157, %162
  %168 = shufflevector <1 x double> %167, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %169 = shufflevector <1 x double> %163, <1 x double> %164, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %170 = shufflevector <4 x double> %169, <4 x double> %166, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %171 = shufflevector <4 x double> %170, <4 x double> %168, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %172 = fadd <4 x double> %154, %171
  store <4 x double> %172, ptr %152, align 8
  %173 = or disjoint i64 %153, 1
  %174 = shl nuw nsw i64 %173, 6
  %gep22.1 = getelementptr double, ptr %gep49, i64 %173
  %175 = load double, ptr %gep22.1, align 8
  %176 = insertelement <1 x double> poison, double %175, i64 0
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %174
  %177 = load <4 x double>, ptr %gep24.1, align 8
  %178 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> zeroinitializer
  %179 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 1>
  %180 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 2>
  %181 = shufflevector <4 x double> %177, <4 x double> poison, <1 x i32> <i32 3>
  %182 = fmul <1 x double> %176, %178
  %183 = fmul <1 x double> %176, %179
  %184 = fmul <1 x double> %176, %180
  %185 = shufflevector <1 x double> %184, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %186 = fmul <1 x double> %176, %181
  %187 = shufflevector <1 x double> %186, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %188 = shufflevector <1 x double> %182, <1 x double> %183, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %189 = shufflevector <4 x double> %188, <4 x double> %185, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %190 = shufflevector <4 x double> %189, <4 x double> %187, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %191 = fadd <4 x double> %172, %190
  store <4 x double> %191, ptr %152, align 8
  %192 = add nuw nsw i64 %153, 2
  %exitcond.3.not.1 = icmp eq i64 %192, 64
  br i1 %exitcond.3.not.1, label %193, label %.critedge.3

193:                                              ; preds = %.critedge.3
  %194 = add nuw nsw i64 %27, 1
  %exitcond19.not = icmp eq i64 %194, 16
  br i1 %exitcond19.not, label %195, label %.preheader16

195:                                              ; preds = %193
  %196 = add nuw nsw i64 %24, 16
  %197 = icmp ult i64 %24, 48
  br i1 %197, label %23, label %198

198:                                              ; preds = %195
  %199 = add nuw nsw i64 %21, 16
  %200 = icmp ult i64 %21, 48
  br i1 %200, label %.preheader17, label %201

201:                                              ; preds = %198
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 12
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %181, %3
  %4 = phi i64 [ %182, %181 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 6
  %invariant.gep43.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %6

6:                                                ; preds = %178, %.preheader17.i
  %7 = phi i64 [ 0, %.preheader17.i ], [ %179, %178 ]
  %8 = or disjoint i64 %7, %5
  %9 = getelementptr double, ptr %.unpack32, i64 %8
  %invariant.gep41.i = getelementptr double, ptr %.unpack17, i64 %7
  %invariant.gep35.i = getelementptr double, ptr %invariant.gep.1.i, i64 %7
  %invariant.gep29.i = getelementptr double, ptr %invariant.gep.2.i, i64 %7
  %invariant.gep23.i = getelementptr double, ptr %invariant.gep.3.i, i64 %7
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %176, %6
  %10 = phi i64 [ 0, %6 ], [ %177, %176 ]
  %11 = shl i64 %10, 6
  %12 = getelementptr double, ptr %9, i64 %11
  %.promoted.i = load <4 x double>, ptr %12, align 8
  %gep.i = getelementptr double, ptr %invariant.gep43.i, i64 %11
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %13 = phi i64 [ 0, %.preheader16.i ], [ %52, %.critedge.i ]
  %14 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %51, %.critedge.i ]
  %15 = shl nuw nsw i64 %13, 6
  %gep40.i = getelementptr double, ptr %gep.i, i64 %13
  %16 = load double, ptr %gep40.i, align 8
  %17 = insertelement <1 x double> poison, double %16, i64 0
  %gep42.i = getelementptr double, ptr %invariant.gep41.i, i64 %15
  %18 = load <4 x double>, ptr %gep42.i, align 8
  %19 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> zeroinitializer
  %20 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 1>
  %21 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 2>
  %22 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 3>
  %23 = fmul <1 x double> %17, %19
  %24 = fmul <1 x double> %17, %20
  %25 = fmul <1 x double> %17, %21
  %26 = shufflevector <1 x double> %25, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %27 = fmul <1 x double> %17, %22
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = shufflevector <1 x double> %23, <1 x double> %24, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %30 = shufflevector <4 x double> %29, <4 x double> %26, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %31 = shufflevector <4 x double> %30, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %32 = fadd <4 x double> %14, %31
  store <4 x double> %32, ptr %12, align 8
  %33 = or disjoint i64 %13, 1
  %34 = shl nuw nsw i64 %33, 6
  %gep40.i.1 = getelementptr double, ptr %gep.i, i64 %33
  %35 = load double, ptr %gep40.i.1, align 8
  %36 = insertelement <1 x double> poison, double %35, i64 0
  %gep42.i.1 = getelementptr double, ptr %invariant.gep41.i, i64 %34
  %37 = load <4 x double>, ptr %gep42.i.1, align 8
  %38 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> zeroinitializer
  %39 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 1>
  %40 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 2>
  %41 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 3>
  %42 = fmul <1 x double> %36, %38
  %43 = fmul <1 x double> %36, %39
  %44 = fmul <1 x double> %36, %40
  %45 = shufflevector <1 x double> %44, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %46 = fmul <1 x double> %36, %41
  %47 = shufflevector <1 x double> %46, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %48 = shufflevector <1 x double> %42, <1 x double> %43, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %45, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %47, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %51 = fadd <4 x double> %32, %50
  store <4 x double> %51, ptr %12, align 8
  %52 = add nuw nsw i64 %13, 2
  %exitcond.not.i.1 = icmp eq i64 %52, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %53 = getelementptr double, ptr %12, i64 4
  %.promoted.1.i = load <4 x double>, ptr %53, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %93, %.critedge.1.i ]
  %55 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %92, %.critedge.1.i ]
  %56 = shl nuw nsw i64 %54, 6
  %gep34.i = getelementptr double, ptr %gep.i, i64 %54
  %57 = load double, ptr %gep34.i, align 8
  %58 = insertelement <1 x double> poison, double %57, i64 0
  %gep36.i = getelementptr double, ptr %invariant.gep35.i, i64 %56
  %59 = load <4 x double>, ptr %gep36.i, align 8
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> zeroinitializer
  %61 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 1>
  %62 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 2>
  %63 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 3>
  %64 = fmul <1 x double> %58, %60
  %65 = fmul <1 x double> %58, %61
  %66 = fmul <1 x double> %58, %62
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = fmul <1 x double> %58, %63
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = shufflevector <1 x double> %64, <1 x double> %65, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %73 = fadd <4 x double> %55, %72
  store <4 x double> %73, ptr %53, align 8
  %74 = or disjoint i64 %54, 1
  %75 = shl nuw nsw i64 %74, 6
  %gep34.i.1 = getelementptr double, ptr %gep.i, i64 %74
  %76 = load double, ptr %gep34.i.1, align 8
  %77 = insertelement <1 x double> poison, double %76, i64 0
  %gep36.i.1 = getelementptr double, ptr %invariant.gep35.i, i64 %75
  %78 = load <4 x double>, ptr %gep36.i.1, align 8
  %79 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> zeroinitializer
  %80 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 1>
  %81 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 2>
  %82 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 3>
  %83 = fmul <1 x double> %77, %79
  %84 = fmul <1 x double> %77, %80
  %85 = fmul <1 x double> %77, %81
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = fmul <1 x double> %77, %82
  %88 = shufflevector <1 x double> %87, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %89 = shufflevector <1 x double> %83, <1 x double> %84, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %90 = shufflevector <4 x double> %89, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %91 = shufflevector <4 x double> %90, <4 x double> %88, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %92 = fadd <4 x double> %73, %91
  store <4 x double> %92, ptr %53, align 8
  %93 = add nuw nsw i64 %54, 2
  %exitcond.1.not.i.1 = icmp eq i64 %93, 64
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %94 = getelementptr double, ptr %12, i64 8
  %.promoted.2.i = load <4 x double>, ptr %94, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %95 = phi i64 [ 0, %.preheader.2.i ], [ %134, %.critedge.2.i ]
  %96 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %133, %.critedge.2.i ]
  %97 = shl nuw nsw i64 %95, 6
  %gep28.i = getelementptr double, ptr %gep.i, i64 %95
  %98 = load double, ptr %gep28.i, align 8
  %99 = insertelement <1 x double> poison, double %98, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %97
  %100 = load <4 x double>, ptr %gep30.i, align 8
  %101 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> zeroinitializer
  %102 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 1>
  %103 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 2>
  %104 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 3>
  %105 = fmul <1 x double> %99, %101
  %106 = fmul <1 x double> %99, %102
  %107 = fmul <1 x double> %99, %103
  %108 = shufflevector <1 x double> %107, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %109 = fmul <1 x double> %99, %104
  %110 = shufflevector <1 x double> %109, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <1 x double> %105, <1 x double> %106, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %112 = shufflevector <4 x double> %111, <4 x double> %108, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %110, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %114 = fadd <4 x double> %96, %113
  store <4 x double> %114, ptr %94, align 8
  %115 = or disjoint i64 %95, 1
  %116 = shl nuw nsw i64 %115, 6
  %gep28.i.1 = getelementptr double, ptr %gep.i, i64 %115
  %117 = load double, ptr %gep28.i.1, align 8
  %118 = insertelement <1 x double> poison, double %117, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %116
  %119 = load <4 x double>, ptr %gep30.i.1, align 8
  %120 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> zeroinitializer
  %121 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 1>
  %122 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 2>
  %123 = shufflevector <4 x double> %119, <4 x double> poison, <1 x i32> <i32 3>
  %124 = fmul <1 x double> %118, %120
  %125 = fmul <1 x double> %118, %121
  %126 = fmul <1 x double> %118, %122
  %127 = shufflevector <1 x double> %126, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %128 = fmul <1 x double> %118, %123
  %129 = shufflevector <1 x double> %128, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %130 = shufflevector <1 x double> %124, <1 x double> %125, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %131 = shufflevector <4 x double> %130, <4 x double> %127, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %132 = shufflevector <4 x double> %131, <4 x double> %129, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %133 = fadd <4 x double> %114, %132
  store <4 x double> %133, ptr %94, align 8
  %134 = add nuw nsw i64 %95, 2
  %exitcond.2.not.i.1 = icmp eq i64 %134, 64
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %135 = getelementptr double, ptr %12, i64 12
  %.promoted.3.i = load <4 x double>, ptr %135, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %136 = phi i64 [ 0, %.preheader.3.i ], [ %175, %.critedge.3.i ]
  %137 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %174, %.critedge.3.i ]
  %138 = shl nuw nsw i64 %136, 6
  %gep22.i = getelementptr double, ptr %gep.i, i64 %136
  %139 = load double, ptr %gep22.i, align 8
  %140 = insertelement <1 x double> poison, double %139, i64 0
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %138
  %141 = load <4 x double>, ptr %gep24.i, align 8
  %142 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> zeroinitializer
  %143 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 1>
  %144 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 2>
  %145 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 3>
  %146 = fmul <1 x double> %140, %142
  %147 = fmul <1 x double> %140, %143
  %148 = fmul <1 x double> %140, %144
  %149 = shufflevector <1 x double> %148, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %150 = fmul <1 x double> %140, %145
  %151 = shufflevector <1 x double> %150, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %152 = shufflevector <1 x double> %146, <1 x double> %147, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %149, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %151, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %155 = fadd <4 x double> %137, %154
  store <4 x double> %155, ptr %135, align 8
  %156 = or disjoint i64 %136, 1
  %157 = shl nuw nsw i64 %156, 6
  %gep22.i.1 = getelementptr double, ptr %gep.i, i64 %156
  %158 = load double, ptr %gep22.i.1, align 8
  %159 = insertelement <1 x double> poison, double %158, i64 0
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %157
  %160 = load <4 x double>, ptr %gep24.i.1, align 8
  %161 = shufflevector <4 x double> %160, <4 x double> poison, <1 x i32> zeroinitializer
  %162 = shufflevector <4 x double> %160, <4 x double> poison, <1 x i32> <i32 1>
  %163 = shufflevector <4 x double> %160, <4 x double> poison, <1 x i32> <i32 2>
  %164 = shufflevector <4 x double> %160, <4 x double> poison, <1 x i32> <i32 3>
  %165 = fmul <1 x double> %159, %161
  %166 = fmul <1 x double> %159, %162
  %167 = fmul <1 x double> %159, %163
  %168 = shufflevector <1 x double> %167, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %169 = fmul <1 x double> %159, %164
  %170 = shufflevector <1 x double> %169, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %171 = shufflevector <1 x double> %165, <1 x double> %166, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %172 = shufflevector <4 x double> %171, <4 x double> %168, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %173 = shufflevector <4 x double> %172, <4 x double> %170, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %174 = fadd <4 x double> %155, %173
  store <4 x double> %174, ptr %135, align 8
  %175 = add nuw nsw i64 %136, 2
  %exitcond.3.not.i.1 = icmp eq i64 %175, 64
  br i1 %exitcond.3.not.i.1, label %176, label %.critedge.3.i

176:                                              ; preds = %.critedge.3.i
  %177 = add nuw nsw i64 %10, 1
  %exitcond19.not.i = icmp eq i64 %177, 16
  br i1 %exitcond19.not.i, label %178, label %.preheader16.i

178:                                              ; preds = %176
  %179 = add nuw nsw i64 %7, 16
  %180 = icmp ult i64 %7, 48
  br i1 %180, label %6, label %181

181:                                              ; preds = %178
  %182 = add nuw nsw i64 %4, 16
  %183 = icmp ult i64 %4, 48
  br i1 %183, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %181
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 12
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %188, %1
  %11 = phi i64 [ %189, %188 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 6
  %invariant.gep43.i = getelementptr double, ptr %4, i64 %12
  br label %13

13:                                               ; preds = %185, %.preheader17.i
  %14 = phi i64 [ 0, %.preheader17.i ], [ %186, %185 ]
  %15 = or disjoint i64 %14, %12
  %16 = getelementptr double, ptr %10, i64 %15
  %invariant.gep41.i = getelementptr double, ptr %7, i64 %14
  %invariant.gep35.i = getelementptr double, ptr %invariant.gep.1.i, i64 %14
  %invariant.gep29.i = getelementptr double, ptr %invariant.gep.2.i, i64 %14
  %invariant.gep23.i = getelementptr double, ptr %invariant.gep.3.i, i64 %14
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %183, %13
  %17 = phi i64 [ 0, %13 ], [ %184, %183 ]
  %18 = shl i64 %17, 6
  %19 = getelementptr double, ptr %16, i64 %18
  %.promoted.i = load <4 x double>, ptr %19, align 8
  %gep.i = getelementptr double, ptr %invariant.gep43.i, i64 %18
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %20 = phi i64 [ 0, %.preheader16.i ], [ %59, %.critedge.i ]
  %21 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %58, %.critedge.i ]
  %22 = shl nuw nsw i64 %20, 6
  %gep40.i = getelementptr double, ptr %gep.i, i64 %20
  %23 = load double, ptr %gep40.i, align 8
  %24 = insertelement <1 x double> poison, double %23, i64 0
  %gep42.i = getelementptr double, ptr %invariant.gep41.i, i64 %22
  %25 = load <4 x double>, ptr %gep42.i, align 8
  %26 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> zeroinitializer
  %27 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 1>
  %28 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 2>
  %29 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 3>
  %30 = fmul <1 x double> %24, %26
  %31 = fmul <1 x double> %24, %27
  %32 = fmul <1 x double> %24, %28
  %33 = shufflevector <1 x double> %32, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %34 = fmul <1 x double> %24, %29
  %35 = shufflevector <1 x double> %34, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = shufflevector <1 x double> %30, <1 x double> %31, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %37 = shufflevector <4 x double> %36, <4 x double> %33, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %38 = shufflevector <4 x double> %37, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %39 = fadd <4 x double> %21, %38
  store <4 x double> %39, ptr %19, align 8
  %40 = or disjoint i64 %20, 1
  %41 = shl nuw nsw i64 %40, 6
  %gep40.i.1 = getelementptr double, ptr %gep.i, i64 %40
  %42 = load double, ptr %gep40.i.1, align 8
  %43 = insertelement <1 x double> poison, double %42, i64 0
  %gep42.i.1 = getelementptr double, ptr %invariant.gep41.i, i64 %41
  %44 = load <4 x double>, ptr %gep42.i.1, align 8
  %45 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> zeroinitializer
  %46 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 1>
  %47 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 2>
  %48 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 3>
  %49 = fmul <1 x double> %43, %45
  %50 = fmul <1 x double> %43, %46
  %51 = fmul <1 x double> %43, %47
  %52 = shufflevector <1 x double> %51, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %53 = fmul <1 x double> %43, %48
  %54 = shufflevector <1 x double> %53, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <1 x double> %49, <1 x double> %50, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %56 = shufflevector <4 x double> %55, <4 x double> %52, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %54, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %58 = fadd <4 x double> %39, %57
  store <4 x double> %58, ptr %19, align 8
  %59 = add nuw nsw i64 %20, 2
  %exitcond.not.i.1 = icmp eq i64 %59, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %60 = getelementptr double, ptr %19, i64 4
  %.promoted.1.i = load <4 x double>, ptr %60, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %61 = phi i64 [ 0, %.preheader.1.i ], [ %100, %.critedge.1.i ]
  %62 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %99, %.critedge.1.i ]
  %63 = shl nuw nsw i64 %61, 6
  %gep34.i = getelementptr double, ptr %gep.i, i64 %61
  %64 = load double, ptr %gep34.i, align 8
  %65 = insertelement <1 x double> poison, double %64, i64 0
  %gep36.i = getelementptr double, ptr %invariant.gep35.i, i64 %63
  %66 = load <4 x double>, ptr %gep36.i, align 8
  %67 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> zeroinitializer
  %68 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 1>
  %69 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 2>
  %70 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 3>
  %71 = fmul <1 x double> %65, %67
  %72 = fmul <1 x double> %65, %68
  %73 = fmul <1 x double> %65, %69
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = fmul <1 x double> %65, %70
  %76 = shufflevector <1 x double> %75, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = shufflevector <1 x double> %71, <1 x double> %72, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %79 = shufflevector <4 x double> %78, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %80 = fadd <4 x double> %62, %79
  store <4 x double> %80, ptr %60, align 8
  %81 = or disjoint i64 %61, 1
  %82 = shl nuw nsw i64 %81, 6
  %gep34.i.1 = getelementptr double, ptr %gep.i, i64 %81
  %83 = load double, ptr %gep34.i.1, align 8
  %84 = insertelement <1 x double> poison, double %83, i64 0
  %gep36.i.1 = getelementptr double, ptr %invariant.gep35.i, i64 %82
  %85 = load <4 x double>, ptr %gep36.i.1, align 8
  %86 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> zeroinitializer
  %87 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 1>
  %88 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 2>
  %89 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 3>
  %90 = fmul <1 x double> %84, %86
  %91 = fmul <1 x double> %84, %87
  %92 = fmul <1 x double> %84, %88
  %93 = shufflevector <1 x double> %92, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %94 = fmul <1 x double> %84, %89
  %95 = shufflevector <1 x double> %94, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %96 = shufflevector <1 x double> %90, <1 x double> %91, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %93, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %98 = shufflevector <4 x double> %97, <4 x double> %95, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %99 = fadd <4 x double> %80, %98
  store <4 x double> %99, ptr %60, align 8
  %100 = add nuw nsw i64 %61, 2
  %exitcond.1.not.i.1 = icmp eq i64 %100, 64
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %101 = getelementptr double, ptr %19, i64 8
  %.promoted.2.i = load <4 x double>, ptr %101, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %102 = phi i64 [ 0, %.preheader.2.i ], [ %141, %.critedge.2.i ]
  %103 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %140, %.critedge.2.i ]
  %104 = shl nuw nsw i64 %102, 6
  %gep28.i = getelementptr double, ptr %gep.i, i64 %102
  %105 = load double, ptr %gep28.i, align 8
  %106 = insertelement <1 x double> poison, double %105, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %104
  %107 = load <4 x double>, ptr %gep30.i, align 8
  %108 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> zeroinitializer
  %109 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 1>
  %110 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 2>
  %111 = shufflevector <4 x double> %107, <4 x double> poison, <1 x i32> <i32 3>
  %112 = fmul <1 x double> %106, %108
  %113 = fmul <1 x double> %106, %109
  %114 = fmul <1 x double> %106, %110
  %115 = shufflevector <1 x double> %114, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %116 = fmul <1 x double> %106, %111
  %117 = shufflevector <1 x double> %116, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %118 = shufflevector <1 x double> %112, <1 x double> %113, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %119 = shufflevector <4 x double> %118, <4 x double> %115, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %120 = shufflevector <4 x double> %119, <4 x double> %117, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %121 = fadd <4 x double> %103, %120
  store <4 x double> %121, ptr %101, align 8
  %122 = or disjoint i64 %102, 1
  %123 = shl nuw nsw i64 %122, 6
  %gep28.i.1 = getelementptr double, ptr %gep.i, i64 %122
  %124 = load double, ptr %gep28.i.1, align 8
  %125 = insertelement <1 x double> poison, double %124, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %123
  %126 = load <4 x double>, ptr %gep30.i.1, align 8
  %127 = shufflevector <4 x double> %126, <4 x double> poison, <1 x i32> zeroinitializer
  %128 = shufflevector <4 x double> %126, <4 x double> poison, <1 x i32> <i32 1>
  %129 = shufflevector <4 x double> %126, <4 x double> poison, <1 x i32> <i32 2>
  %130 = shufflevector <4 x double> %126, <4 x double> poison, <1 x i32> <i32 3>
  %131 = fmul <1 x double> %125, %127
  %132 = fmul <1 x double> %125, %128
  %133 = fmul <1 x double> %125, %129
  %134 = shufflevector <1 x double> %133, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %135 = fmul <1 x double> %125, %130
  %136 = shufflevector <1 x double> %135, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %137 = shufflevector <1 x double> %131, <1 x double> %132, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %138 = shufflevector <4 x double> %137, <4 x double> %134, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %139 = shufflevector <4 x double> %138, <4 x double> %136, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %140 = fadd <4 x double> %121, %139
  store <4 x double> %140, ptr %101, align 8
  %141 = add nuw nsw i64 %102, 2
  %exitcond.2.not.i.1 = icmp eq i64 %141, 64
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %142 = getelementptr double, ptr %19, i64 12
  %.promoted.3.i = load <4 x double>, ptr %142, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %143 = phi i64 [ 0, %.preheader.3.i ], [ %182, %.critedge.3.i ]
  %144 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %181, %.critedge.3.i ]
  %145 = shl nuw nsw i64 %143, 6
  %gep22.i = getelementptr double, ptr %gep.i, i64 %143
  %146 = load double, ptr %gep22.i, align 8
  %147 = insertelement <1 x double> poison, double %146, i64 0
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %145
  %148 = load <4 x double>, ptr %gep24.i, align 8
  %149 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> zeroinitializer
  %150 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 1>
  %151 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 2>
  %152 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 3>
  %153 = fmul <1 x double> %147, %149
  %154 = fmul <1 x double> %147, %150
  %155 = fmul <1 x double> %147, %151
  %156 = shufflevector <1 x double> %155, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %157 = fmul <1 x double> %147, %152
  %158 = shufflevector <1 x double> %157, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %159 = shufflevector <1 x double> %153, <1 x double> %154, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %160 = shufflevector <4 x double> %159, <4 x double> %156, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %161 = shufflevector <4 x double> %160, <4 x double> %158, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %162 = fadd <4 x double> %144, %161
  store <4 x double> %162, ptr %142, align 8
  %163 = or disjoint i64 %143, 1
  %164 = shl nuw nsw i64 %163, 6
  %gep22.i.1 = getelementptr double, ptr %gep.i, i64 %163
  %165 = load double, ptr %gep22.i.1, align 8
  %166 = insertelement <1 x double> poison, double %165, i64 0
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %164
  %167 = load <4 x double>, ptr %gep24.i.1, align 8
  %168 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> zeroinitializer
  %169 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 1>
  %170 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 2>
  %171 = shufflevector <4 x double> %167, <4 x double> poison, <1 x i32> <i32 3>
  %172 = fmul <1 x double> %166, %168
  %173 = fmul <1 x double> %166, %169
  %174 = fmul <1 x double> %166, %170
  %175 = shufflevector <1 x double> %174, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %176 = fmul <1 x double> %166, %171
  %177 = shufflevector <1 x double> %176, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %178 = shufflevector <1 x double> %172, <1 x double> %173, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %175, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %180 = shufflevector <4 x double> %179, <4 x double> %177, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %181 = fadd <4 x double> %162, %180
  store <4 x double> %181, ptr %142, align 8
  %182 = add nuw nsw i64 %143, 2
  %exitcond.3.not.i.1 = icmp eq i64 %182, 64
  br i1 %exitcond.3.not.i.1, label %183, label %.critedge.3.i

183:                                              ; preds = %.critedge.3.i
  %184 = add nuw nsw i64 %17, 1
  %exitcond19.not.i = icmp eq i64 %184, 16
  br i1 %exitcond19.not.i, label %185, label %.preheader16.i

185:                                              ; preds = %183
  %186 = add nuw nsw i64 %14, 16
  %187 = icmp ult i64 %14, 48
  br i1 %187, label %13, label %188

188:                                              ; preds = %185
  %189 = add nuw nsw i64 %11, 16
  %190 = icmp ult i64 %11, 48
  br i1 %190, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %188
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32.i, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  %invariant.gep.2.i.i = getelementptr double, ptr %.unpack17.i, i64 8
  %invariant.gep.3.i.i = getelementptr double, ptr %.unpack17.i, i64 12
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %187, %1
  %10 = phi i64 [ %188, %187 ], [ 0, %1 ]
  %11 = shl nuw nsw i64 %10, 6
  %invariant.gep43.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %12

12:                                               ; preds = %184, %.preheader17.i.i
  %13 = phi i64 [ 0, %.preheader17.i.i ], [ %185, %184 ]
  %14 = or disjoint i64 %13, %11
  %15 = getelementptr double, ptr %.unpack32.i, i64 %14
  %invariant.gep41.i.i = getelementptr double, ptr %.unpack17.i, i64 %13
  %invariant.gep35.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %13
  %invariant.gep29.i.i = getelementptr double, ptr %invariant.gep.2.i.i, i64 %13
  %invariant.gep23.i.i = getelementptr double, ptr %invariant.gep.3.i.i, i64 %13
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %182, %12
  %16 = phi i64 [ 0, %12 ], [ %183, %182 ]
  %17 = shl i64 %16, 6
  %18 = getelementptr double, ptr %15, i64 %17
  %.promoted.i.i = load <4 x double>, ptr %18, align 8
  %gep.i.i = getelementptr double, ptr %invariant.gep43.i.i, i64 %17
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader16.i.i
  %19 = phi i64 [ 0, %.preheader16.i.i ], [ %58, %.critedge.i.i ]
  %20 = phi <4 x double> [ %.promoted.i.i, %.preheader16.i.i ], [ %57, %.critedge.i.i ]
  %21 = shl nuw nsw i64 %19, 6
  %gep40.i.i = getelementptr double, ptr %gep.i.i, i64 %19
  %22 = load double, ptr %gep40.i.i, align 8
  %23 = insertelement <1 x double> poison, double %22, i64 0
  %gep42.i.i = getelementptr double, ptr %invariant.gep41.i.i, i64 %21
  %24 = load <4 x double>, ptr %gep42.i.i, align 8
  %25 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> zeroinitializer
  %26 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 1>
  %27 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 2>
  %28 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 3>
  %29 = fmul <1 x double> %23, %25
  %30 = fmul <1 x double> %23, %26
  %31 = fmul <1 x double> %23, %27
  %32 = shufflevector <1 x double> %31, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %33 = fmul <1 x double> %23, %28
  %34 = shufflevector <1 x double> %33, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %35 = shufflevector <1 x double> %29, <1 x double> %30, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %36 = shufflevector <4 x double> %35, <4 x double> %32, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %37 = shufflevector <4 x double> %36, <4 x double> %34, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %38 = fadd <4 x double> %20, %37
  store <4 x double> %38, ptr %18, align 8
  %39 = or disjoint i64 %19, 1
  %40 = shl nuw nsw i64 %39, 6
  %gep40.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %39
  %41 = load double, ptr %gep40.i.i.1, align 8
  %42 = insertelement <1 x double> poison, double %41, i64 0
  %gep42.i.i.1 = getelementptr double, ptr %invariant.gep41.i.i, i64 %40
  %43 = load <4 x double>, ptr %gep42.i.i.1, align 8
  %44 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> zeroinitializer
  %45 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 1>
  %46 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 2>
  %47 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 3>
  %48 = fmul <1 x double> %42, %44
  %49 = fmul <1 x double> %42, %45
  %50 = fmul <1 x double> %42, %46
  %51 = shufflevector <1 x double> %50, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %52 = fmul <1 x double> %42, %47
  %53 = shufflevector <1 x double> %52, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %54 = shufflevector <1 x double> %48, <1 x double> %49, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %55 = shufflevector <4 x double> %54, <4 x double> %51, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %56 = shufflevector <4 x double> %55, <4 x double> %53, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %57 = fadd <4 x double> %38, %56
  store <4 x double> %57, ptr %18, align 8
  %58 = add nuw nsw i64 %19, 2
  %exitcond.not.i.i.1 = icmp eq i64 %58, 64
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %59 = getelementptr double, ptr %18, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %59, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %60 = phi i64 [ 0, %.preheader.1.i.i ], [ %99, %.critedge.1.i.i ]
  %61 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %98, %.critedge.1.i.i ]
  %62 = shl nuw nsw i64 %60, 6
  %gep34.i.i = getelementptr double, ptr %gep.i.i, i64 %60
  %63 = load double, ptr %gep34.i.i, align 8
  %64 = insertelement <1 x double> poison, double %63, i64 0
  %gep36.i.i = getelementptr double, ptr %invariant.gep35.i.i, i64 %62
  %65 = load <4 x double>, ptr %gep36.i.i, align 8
  %66 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> zeroinitializer
  %67 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 1>
  %68 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 2>
  %69 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 3>
  %70 = fmul <1 x double> %64, %66
  %71 = fmul <1 x double> %64, %67
  %72 = fmul <1 x double> %64, %68
  %73 = shufflevector <1 x double> %72, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = fmul <1 x double> %64, %69
  %75 = shufflevector <1 x double> %74, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %76 = shufflevector <1 x double> %70, <1 x double> %71, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %75, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %79 = fadd <4 x double> %61, %78
  store <4 x double> %79, ptr %59, align 8
  %80 = or disjoint i64 %60, 1
  %81 = shl nuw nsw i64 %80, 6
  %gep34.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %80
  %82 = load double, ptr %gep34.i.i.1, align 8
  %83 = insertelement <1 x double> poison, double %82, i64 0
  %gep36.i.i.1 = getelementptr double, ptr %invariant.gep35.i.i, i64 %81
  %84 = load <4 x double>, ptr %gep36.i.i.1, align 8
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> zeroinitializer
  %86 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 1>
  %87 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 2>
  %88 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 3>
  %89 = fmul <1 x double> %83, %85
  %90 = fmul <1 x double> %83, %86
  %91 = fmul <1 x double> %83, %87
  %92 = shufflevector <1 x double> %91, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = fmul <1 x double> %83, %88
  %94 = shufflevector <1 x double> %93, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = shufflevector <1 x double> %89, <1 x double> %90, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %98 = fadd <4 x double> %79, %97
  store <4 x double> %98, ptr %59, align 8
  %99 = add nuw nsw i64 %60, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %99, 64
  br i1 %exitcond.1.not.i.i.1, label %.preheader.2.i.i, label %.critedge.1.i.i

.preheader.2.i.i:                                 ; preds = %.critedge.1.i.i
  %100 = getelementptr double, ptr %18, i64 8
  %.promoted.2.i.i = load <4 x double>, ptr %100, align 8
  br label %.critedge.2.i.i

.critedge.2.i.i:                                  ; preds = %.critedge.2.i.i, %.preheader.2.i.i
  %101 = phi i64 [ 0, %.preheader.2.i.i ], [ %140, %.critedge.2.i.i ]
  %102 = phi <4 x double> [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %139, %.critedge.2.i.i ]
  %103 = shl nuw nsw i64 %101, 6
  %gep28.i.i = getelementptr double, ptr %gep.i.i, i64 %101
  %104 = load double, ptr %gep28.i.i, align 8
  %105 = insertelement <1 x double> poison, double %104, i64 0
  %gep30.i.i = getelementptr double, ptr %invariant.gep29.i.i, i64 %103
  %106 = load <4 x double>, ptr %gep30.i.i, align 8
  %107 = shufflevector <4 x double> %106, <4 x double> poison, <1 x i32> zeroinitializer
  %108 = shufflevector <4 x double> %106, <4 x double> poison, <1 x i32> <i32 1>
  %109 = shufflevector <4 x double> %106, <4 x double> poison, <1 x i32> <i32 2>
  %110 = shufflevector <4 x double> %106, <4 x double> poison, <1 x i32> <i32 3>
  %111 = fmul <1 x double> %105, %107
  %112 = fmul <1 x double> %105, %108
  %113 = fmul <1 x double> %105, %109
  %114 = shufflevector <1 x double> %113, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %115 = fmul <1 x double> %105, %110
  %116 = shufflevector <1 x double> %115, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %117 = shufflevector <1 x double> %111, <1 x double> %112, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %118 = shufflevector <4 x double> %117, <4 x double> %114, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %119 = shufflevector <4 x double> %118, <4 x double> %116, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %120 = fadd <4 x double> %102, %119
  store <4 x double> %120, ptr %100, align 8
  %121 = or disjoint i64 %101, 1
  %122 = shl nuw nsw i64 %121, 6
  %gep28.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %121
  %123 = load double, ptr %gep28.i.i.1, align 8
  %124 = insertelement <1 x double> poison, double %123, i64 0
  %gep30.i.i.1 = getelementptr double, ptr %invariant.gep29.i.i, i64 %122
  %125 = load <4 x double>, ptr %gep30.i.i.1, align 8
  %126 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> zeroinitializer
  %127 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 1>
  %128 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 2>
  %129 = shufflevector <4 x double> %125, <4 x double> poison, <1 x i32> <i32 3>
  %130 = fmul <1 x double> %124, %126
  %131 = fmul <1 x double> %124, %127
  %132 = fmul <1 x double> %124, %128
  %133 = shufflevector <1 x double> %132, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %134 = fmul <1 x double> %124, %129
  %135 = shufflevector <1 x double> %134, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %136 = shufflevector <1 x double> %130, <1 x double> %131, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %137 = shufflevector <4 x double> %136, <4 x double> %133, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %138 = shufflevector <4 x double> %137, <4 x double> %135, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %139 = fadd <4 x double> %120, %138
  store <4 x double> %139, ptr %100, align 8
  %140 = add nuw nsw i64 %101, 2
  %exitcond.2.not.i.i.1 = icmp eq i64 %140, 64
  br i1 %exitcond.2.not.i.i.1, label %.preheader.3.i.i, label %.critedge.2.i.i

.preheader.3.i.i:                                 ; preds = %.critedge.2.i.i
  %141 = getelementptr double, ptr %18, i64 12
  %.promoted.3.i.i = load <4 x double>, ptr %141, align 8
  br label %.critedge.3.i.i

.critedge.3.i.i:                                  ; preds = %.critedge.3.i.i, %.preheader.3.i.i
  %142 = phi i64 [ 0, %.preheader.3.i.i ], [ %181, %.critedge.3.i.i ]
  %143 = phi <4 x double> [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %180, %.critedge.3.i.i ]
  %144 = shl nuw nsw i64 %142, 6
  %gep22.i.i = getelementptr double, ptr %gep.i.i, i64 %142
  %145 = load double, ptr %gep22.i.i, align 8
  %146 = insertelement <1 x double> poison, double %145, i64 0
  %gep24.i.i = getelementptr double, ptr %invariant.gep23.i.i, i64 %144
  %147 = load <4 x double>, ptr %gep24.i.i, align 8
  %148 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> zeroinitializer
  %149 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 1>
  %150 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 2>
  %151 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 3>
  %152 = fmul <1 x double> %146, %148
  %153 = fmul <1 x double> %146, %149
  %154 = fmul <1 x double> %146, %150
  %155 = shufflevector <1 x double> %154, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %156 = fmul <1 x double> %146, %151
  %157 = shufflevector <1 x double> %156, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %158 = shufflevector <1 x double> %152, <1 x double> %153, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %159 = shufflevector <4 x double> %158, <4 x double> %155, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %160 = shufflevector <4 x double> %159, <4 x double> %157, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %161 = fadd <4 x double> %143, %160
  store <4 x double> %161, ptr %141, align 8
  %162 = or disjoint i64 %142, 1
  %163 = shl nuw nsw i64 %162, 6
  %gep22.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %162
  %164 = load double, ptr %gep22.i.i.1, align 8
  %165 = insertelement <1 x double> poison, double %164, i64 0
  %gep24.i.i.1 = getelementptr double, ptr %invariant.gep23.i.i, i64 %163
  %166 = load <4 x double>, ptr %gep24.i.i.1, align 8
  %167 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> zeroinitializer
  %168 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 1>
  %169 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 2>
  %170 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 3>
  %171 = fmul <1 x double> %165, %167
  %172 = fmul <1 x double> %165, %168
  %173 = fmul <1 x double> %165, %169
  %174 = shufflevector <1 x double> %173, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %175 = fmul <1 x double> %165, %170
  %176 = shufflevector <1 x double> %175, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %177 = shufflevector <1 x double> %171, <1 x double> %172, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %174, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %176, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %180 = fadd <4 x double> %161, %179
  store <4 x double> %180, ptr %141, align 8
  %181 = add nuw nsw i64 %142, 2
  %exitcond.3.not.i.i.1 = icmp eq i64 %181, 64
  br i1 %exitcond.3.not.i.i.1, label %182, label %.critedge.3.i.i

182:                                              ; preds = %.critedge.3.i.i
  %183 = add nuw nsw i64 %16, 1
  %exitcond19.not.i.i = icmp eq i64 %183, 16
  br i1 %exitcond19.not.i.i, label %184, label %.preheader16.i.i

184:                                              ; preds = %182
  %185 = add nuw nsw i64 %13, 16
  %186 = icmp ult i64 %13, 48
  br i1 %186, label %12, label %187

187:                                              ; preds = %184
  %188 = add nuw nsw i64 %10, 16
  %189 = icmp ult i64 %10, 48
  br i1 %189, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %187
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
