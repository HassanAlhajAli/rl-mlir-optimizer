module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(64 : index) : i64
    %29 = llvm.mlir.constant(1 : index) : i64
    %30 = llvm.mlir.constant(4 : index) : i64
    %31 = llvm.mlir.constant(0 : index) : i64
    %32 = llvm.mlir.constant(8 : index) : i64
    %33 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%31 : i64)
  ^bb1(%34: i64):  // 2 preds: ^bb0, ^bb5
    %35 = llvm.icmp "slt" %34, %28 : i64
    llvm.cond_br %35, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%31 : i64)
  ^bb3(%36: i64):  // 2 preds: ^bb2, ^bb4
    %37 = llvm.icmp "slt" %36, %28 : i64
    llvm.cond_br %37, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %38 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %39 = llvm.mlir.constant(64 : index) : i64
    %40 = llvm.mul %34, %39  : i64
    %41 = llvm.add %40, %36  : i64
    %42 = llvm.getelementptr %38[%41] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %33, %42 : f64, !llvm.ptr
    %43 = llvm.add %36, %29  : i64
    llvm.br ^bb3(%43 : i64)
  ^bb5:  // pred: ^bb3
    %44 = llvm.add %34, %29  : i64
    llvm.br ^bb1(%44 : i64)
  ^bb6:  // pred: ^bb1
    %45 = llvm.mlir.constant(1 : index) : i64
    %46 = llvm.alloca %45 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %47 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %48 = llvm.insertvalue %46, %47[0] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.insertvalue %46, %48[1] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.mlir.constant(0 : index) : i64
    %51 = llvm.insertvalue %50, %49[2] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(1 : index) : i64
    %53 = llvm.alloca %52 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %54 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %55 = llvm.insertvalue %53, %54[0] : !llvm.struct<(ptr, ptr, i64)> 
    %56 = llvm.insertvalue %53, %55[1] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.mlir.constant(0 : index) : i64
    %58 = llvm.insertvalue %57, %56[2] : !llvm.struct<(ptr, ptr, i64)> 
    %59 = llvm.mlir.constant(1 : index) : i64
    %60 = llvm.alloca %59 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %61 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %62 = llvm.insertvalue %60, %61[0] : !llvm.struct<(ptr, ptr, i64)> 
    %63 = llvm.insertvalue %60, %62[1] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.mlir.constant(0 : index) : i64
    %65 = llvm.insertvalue %64, %63[2] : !llvm.struct<(ptr, ptr, i64)> 
    %66 = llvm.mlir.constant(1 : index) : i64
    %67 = llvm.alloca %66 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %68 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %69 = llvm.insertvalue %67, %68[0] : !llvm.struct<(ptr, ptr, i64)> 
    %70 = llvm.insertvalue %67, %69[1] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.mlir.constant(0 : index) : i64
    %72 = llvm.insertvalue %71, %70[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%31 : i64)
  ^bb7(%73: i64):  // 2 preds: ^bb6, ^bb32
    %74 = llvm.icmp "slt" %73, %28 : i64
    llvm.cond_br %74, ^bb8, ^bb33
  ^bb8:  // pred: ^bb7
    %75 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %76 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %78 = llvm.insertvalue %75, %77[0] : !llvm.struct<(ptr, ptr, i64)> 
    %79 = llvm.insertvalue %76, %78[1] : !llvm.struct<(ptr, ptr, i64)> 
    %80 = llvm.mlir.constant(0 : index) : i64
    %81 = llvm.insertvalue %80, %79[2] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.mul %73, %28  : i64
    %88 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %91 = llvm.insertvalue %88, %90[0] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.insertvalue %89, %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.mlir.constant(0 : index) : i64
    %94 = llvm.insertvalue %93, %92[2] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.mul %73, %28  : i64
    llvm.br ^bb9(%31 : i64)
  ^bb9(%101: i64):  // 2 preds: ^bb8, ^bb31
    %102 = llvm.icmp "slt" %101, %28 : i64
    llvm.cond_br %102, ^bb10, ^bb32
  ^bb10:  // pred: ^bb9
    %103 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %106 = llvm.insertvalue %103, %105[0] : !llvm.struct<(ptr, ptr, i64)> 
    %107 = llvm.insertvalue %104, %106[1] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.mlir.constant(0 : index) : i64
    %109 = llvm.insertvalue %108, %107[2] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.add %100, %101  : i64
    llvm.br ^bb11(%31 : i64)
  ^bb11(%116: i64):  // 2 preds: ^bb10, ^bb30
    %117 = llvm.icmp "slt" %116, %32 : i64
    llvm.cond_br %117, ^bb12, ^bb31
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%31 : i64)
  ^bb13(%118: i64):  // 2 preds: ^bb12, ^bb29
    %119 = llvm.icmp "slt" %118, %32 : i64
    llvm.cond_br %119, ^bb14, ^bb30
  ^bb14:  // pred: ^bb13
    llvm.br ^bb15(%31 : i64)
  ^bb15(%120: i64):  // 2 preds: ^bb14, ^bb28
    %121 = llvm.icmp "slt" %120, %28 : i64
    llvm.cond_br %121, ^bb16, ^bb29
  ^bb16:  // pred: ^bb15
    %122 = llvm.mul %116, %28  : i64
    %123 = llvm.add %87, %122  : i64
    %124 = llvm.add %123, %120  : i64
    %125 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %126 = llvm.insertvalue %75, %125[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %127 = llvm.insertvalue %76, %126[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.insertvalue %124, %127[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.mlir.constant(1 : index) : i64
    %130 = llvm.insertvalue %129, %128[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.mlir.constant(64 : index) : i64
    %132 = llvm.insertvalue %131, %130[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.mlir.constant(1 : index) : i64
    %134 = llvm.insertvalue %133, %132[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %135 = llvm.mlir.constant(1 : index) : i64
    %136 = llvm.insertvalue %135, %134[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %137 = llvm.mul %120, %28  : i64
    %138 = llvm.add %101, %137  : i64
    %139 = llvm.add %138, %118  : i64
    %140 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %141 = llvm.insertvalue %103, %140[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %142 = llvm.insertvalue %104, %141[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %143 = llvm.insertvalue %139, %142[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.mlir.constant(1 : index) : i64
    %145 = llvm.insertvalue %144, %143[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.mlir.constant(64 : index) : i64
    %147 = llvm.insertvalue %146, %145[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.mlir.constant(4 : index) : i64
    %149 = llvm.insertvalue %148, %147[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.mlir.constant(1 : index) : i64
    %151 = llvm.insertvalue %150, %149[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.mul %116, %28  : i64
    %153 = llvm.add %115, %152  : i64
    %154 = llvm.add %153, %118  : i64
    %155 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %156 = llvm.insertvalue %88, %155[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %157 = llvm.insertvalue %89, %156[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %158 = llvm.insertvalue %154, %157[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %159 = llvm.mlir.constant(1 : index) : i64
    %160 = llvm.insertvalue %159, %158[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %161 = llvm.mlir.constant(64 : index) : i64
    %162 = llvm.insertvalue %161, %160[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %163 = llvm.mlir.constant(4 : index) : i64
    %164 = llvm.insertvalue %163, %162[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %165 = llvm.mlir.constant(1 : index) : i64
    %166 = llvm.insertvalue %165, %164[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %167 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %168 = llvm.extractvalue %51[0] : !llvm.struct<(ptr, ptr, i64)> 
    %169 = llvm.insertvalue %168, %167[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %170 = llvm.extractvalue %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    %171 = llvm.insertvalue %170, %169[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %172 = llvm.mlir.constant(0 : index) : i64
    %173 = llvm.insertvalue %172, %171[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %174 = llvm.mlir.constant(1 : index) : i64
    %175 = llvm.insertvalue %174, %173[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %176 = llvm.mlir.constant(1 : index) : i64
    %177 = llvm.insertvalue %176, %175[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb17(%31 : i64)
  ^bb17(%178: i64):  // 2 preds: ^bb16, ^bb18
    %179 = llvm.icmp "slt" %178, %29 : i64
    llvm.cond_br %179, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    %180 = llvm.getelementptr %76[%124] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %181 = llvm.mlir.constant(64 : index) : i64
    %182 = llvm.mul %178, %181  : i64
    %183 = llvm.add %182, %31  : i64
    %184 = llvm.getelementptr %180[%183] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %185 = llvm.load %184 : !llvm.ptr -> f64
    %186 = llvm.mlir.undef : vector<1xf64>
    %187 = llvm.mlir.constant(0 : i32) : i32
    %188 = llvm.insertelement %185, %186[%187 : i32] : vector<1xf64>
    %189 = llvm.shufflevector %188, %186 [0] : vector<1xf64> 
    %190 = llvm.getelementptr %170[%178] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %189, %190 : vector<1xf64>, !llvm.ptr
    %191 = llvm.add %178, %29  : i64
    llvm.br ^bb17(%191 : i64)
  ^bb19:  // pred: ^bb17
    %192 = llvm.load %46 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %193 = llvm.extractvalue %192[0] : !llvm.array<1 x vector<1xf64>> 
    %194 = llvm.insertvalue %193, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %195 = llvm.insertvalue %193, %194[1] : !llvm.array<4 x vector<1xf64>> 
    %196 = llvm.insertvalue %193, %195[2] : !llvm.array<4 x vector<1xf64>> 
    %197 = llvm.insertvalue %193, %196[3] : !llvm.array<4 x vector<1xf64>> 
    %198 = llvm.insertvalue %197, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %199 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %200 = llvm.extractvalue %58[0] : !llvm.struct<(ptr, ptr, i64)> 
    %201 = llvm.insertvalue %200, %199[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %202 = llvm.extractvalue %58[1] : !llvm.struct<(ptr, ptr, i64)> 
    %203 = llvm.insertvalue %202, %201[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.mlir.constant(0 : index) : i64
    %205 = llvm.insertvalue %204, %203[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %206 = llvm.mlir.constant(1 : index) : i64
    %207 = llvm.insertvalue %206, %205[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %208 = llvm.mlir.constant(1 : index) : i64
    %209 = llvm.insertvalue %208, %207[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb20(%31 : i64)
  ^bb20(%210: i64):  // 2 preds: ^bb19, ^bb21
    %211 = llvm.icmp "slt" %210, %29 : i64
    llvm.cond_br %211, ^bb21, ^bb22
  ^bb21:  // pred: ^bb20
    %212 = llvm.extractvalue %151[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %213 = llvm.extractvalue %151[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %214 = llvm.getelementptr %212[%213] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %215 = llvm.mlir.constant(64 : index) : i64
    %216 = llvm.mul %210, %215  : i64
    %217 = llvm.add %216, %31  : i64
    %218 = llvm.getelementptr %214[%217] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %219 = llvm.load %218 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %220 = llvm.getelementptr %202[%210] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %219, %220 : vector<4xf64>, !llvm.ptr
    %221 = llvm.add %210, %29  : i64
    llvm.br ^bb20(%221 : i64)
  ^bb22:  // pred: ^bb20
    %222 = llvm.load %53 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %223 = llvm.extractvalue %222[0] : !llvm.array<1 x vector<4xf64>> 
    %224 = llvm.mlir.constant(0 : i64) : i64
    %225 = llvm.extractelement %223[%224 : i64] : vector<4xf64>
    %226 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %227 = llvm.mlir.constant(0 : i64) : i64
    %228 = llvm.insertelement %225, %226[%227 : i64] : vector<1xf64>
    %229 = llvm.insertvalue %228, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %230 = llvm.extractvalue %222[0] : !llvm.array<1 x vector<4xf64>> 
    %231 = llvm.mlir.constant(1 : i64) : i64
    %232 = llvm.extractelement %230[%231 : i64] : vector<4xf64>
    %233 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %234 = llvm.mlir.constant(0 : i64) : i64
    %235 = llvm.insertelement %232, %233[%234 : i64] : vector<1xf64>
    %236 = llvm.insertvalue %235, %229[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %237 = llvm.extractvalue %222[0] : !llvm.array<1 x vector<4xf64>> 
    %238 = llvm.mlir.constant(2 : i64) : i64
    %239 = llvm.extractelement %237[%238 : i64] : vector<4xf64>
    %240 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %241 = llvm.mlir.constant(0 : i64) : i64
    %242 = llvm.insertelement %239, %240[%241 : i64] : vector<1xf64>
    %243 = llvm.insertvalue %242, %236[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %244 = llvm.extractvalue %222[0] : !llvm.array<1 x vector<4xf64>> 
    %245 = llvm.mlir.constant(3 : i64) : i64
    %246 = llvm.extractelement %244[%245 : i64] : vector<4xf64>
    %247 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %248 = llvm.mlir.constant(0 : i64) : i64
    %249 = llvm.insertelement %246, %247[%248 : i64] : vector<1xf64>
    %250 = llvm.insertvalue %249, %243[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %251 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %252 = llvm.extractvalue %65[0] : !llvm.struct<(ptr, ptr, i64)> 
    %253 = llvm.insertvalue %252, %251[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %254 = llvm.extractvalue %65[1] : !llvm.struct<(ptr, ptr, i64)> 
    %255 = llvm.insertvalue %254, %253[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.mlir.constant(0 : index) : i64
    %257 = llvm.insertvalue %256, %255[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %258 = llvm.mlir.constant(1 : index) : i64
    %259 = llvm.insertvalue %258, %257[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %260 = llvm.mlir.constant(1 : index) : i64
    %261 = llvm.insertvalue %260, %259[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb23(%31 : i64)
  ^bb23(%262: i64):  // 2 preds: ^bb22, ^bb24
    %263 = llvm.icmp "slt" %262, %29 : i64
    llvm.cond_br %263, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %264 = llvm.extractvalue %166[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %265 = llvm.extractvalue %166[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %266 = llvm.getelementptr %264[%265] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %267 = llvm.mlir.constant(64 : index) : i64
    %268 = llvm.mul %262, %267  : i64
    %269 = llvm.add %268, %31  : i64
    %270 = llvm.getelementptr %266[%269] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %271 = llvm.load %270 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %272 = llvm.getelementptr %254[%262] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %271, %272 : vector<4xf64>, !llvm.ptr
    %273 = llvm.add %262, %29  : i64
    llvm.br ^bb23(%273 : i64)
  ^bb25:  // pred: ^bb23
    %274 = llvm.load %60 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %275 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %276 = llvm.extractvalue %198[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %277 = llvm.fmul %276, %228  : vector<1xf64>
    %278 = llvm.insertvalue %277, %275[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %279 = llvm.extractvalue %198[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %280 = llvm.fmul %279, %235  : vector<1xf64>
    %281 = llvm.insertvalue %280, %278[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %282 = llvm.extractvalue %198[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %283 = llvm.fmul %282, %242  : vector<1xf64>
    %284 = llvm.insertvalue %283, %281[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %285 = llvm.extractvalue %198[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %286 = llvm.fmul %285, %249  : vector<1xf64>
    %287 = llvm.insertvalue %286, %284[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %288 = llvm.extractvalue %287[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %289 = llvm.mlir.constant(0 : i64) : i64
    %290 = llvm.extractelement %288[%289 : i64] : vector<1xf64>
    %291 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %292 = llvm.mlir.constant(0 : i64) : i64
    %293 = llvm.insertelement %290, %291[%292 : i64] : vector<4xf64>
    %294 = llvm.insertvalue %293, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %295 = llvm.extractvalue %287[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %296 = llvm.mlir.constant(0 : i64) : i64
    %297 = llvm.extractelement %295[%296 : i64] : vector<1xf64>
    %298 = llvm.mlir.constant(1 : i64) : i64
    %299 = llvm.insertelement %297, %293[%298 : i64] : vector<4xf64>
    %300 = llvm.insertvalue %299, %294[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %301 = llvm.extractvalue %287[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %302 = llvm.mlir.constant(0 : i64) : i64
    %303 = llvm.extractelement %301[%302 : i64] : vector<1xf64>
    %304 = llvm.mlir.constant(2 : i64) : i64
    %305 = llvm.insertelement %303, %299[%304 : i64] : vector<4xf64>
    %306 = llvm.insertvalue %305, %300[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %307 = llvm.extractvalue %287[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %308 = llvm.mlir.constant(0 : i64) : i64
    %309 = llvm.extractelement %307[%308 : i64] : vector<1xf64>
    %310 = llvm.mlir.constant(3 : i64) : i64
    %311 = llvm.insertelement %309, %305[%310 : i64] : vector<4xf64>
    %312 = llvm.insertvalue %311, %306[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %313 = llvm.extractvalue %274[0] : !llvm.array<1 x vector<4xf64>> 
    %314 = llvm.fadd %311, %313  : vector<4xf64>
    %315 = llvm.insertvalue %314, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %315, %67 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %316 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %317 = llvm.extractvalue %72[0] : !llvm.struct<(ptr, ptr, i64)> 
    %318 = llvm.insertvalue %317, %316[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %319 = llvm.extractvalue %72[1] : !llvm.struct<(ptr, ptr, i64)> 
    %320 = llvm.insertvalue %319, %318[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.mlir.constant(0 : index) : i64
    %322 = llvm.insertvalue %321, %320[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %323 = llvm.mlir.constant(1 : index) : i64
    %324 = llvm.insertvalue %323, %322[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %325 = llvm.mlir.constant(1 : index) : i64
    %326 = llvm.insertvalue %325, %324[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb26(%31 : i64)
  ^bb26(%327: i64):  // 2 preds: ^bb25, ^bb27
    %328 = llvm.icmp "slt" %327, %29 : i64
    llvm.cond_br %328, ^bb27, ^bb28
  ^bb27:  // pred: ^bb26
    %329 = llvm.getelementptr %319[%327] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %330 = llvm.load %329 : !llvm.ptr -> vector<4xf64>
    %331 = llvm.extractvalue %166[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %332 = llvm.extractvalue %166[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %333 = llvm.getelementptr %331[%332] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %334 = llvm.mlir.constant(64 : index) : i64
    %335 = llvm.mul %327, %334  : i64
    %336 = llvm.add %335, %31  : i64
    %337 = llvm.getelementptr %333[%336] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %330, %337 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %338 = llvm.add %327, %29  : i64
    llvm.br ^bb26(%338 : i64)
  ^bb28:  // pred: ^bb26
    %339 = llvm.add %120, %29  : i64
    llvm.br ^bb15(%339 : i64)
  ^bb29:  // pred: ^bb15
    %340 = llvm.add %118, %30  : i64
    llvm.br ^bb13(%340 : i64)
  ^bb30:  // pred: ^bb13
    %341 = llvm.add %116, %29  : i64
    llvm.br ^bb11(%341 : i64)
  ^bb31:  // pred: ^bb11
    %342 = llvm.add %101, %32  : i64
    llvm.br ^bb9(%342 : i64)
  ^bb32:  // pred: ^bb9
    %343 = llvm.add %73, %32  : i64
    llvm.br ^bb7(%343 : i64)
  ^bb33:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
