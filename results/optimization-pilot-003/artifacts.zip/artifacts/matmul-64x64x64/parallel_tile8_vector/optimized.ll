; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %116
  %21 = phi i64 [ %117, %116 ], [ 0, %.preheader17.preheader ]
  %22 = shl nuw nsw i64 %21, 6
  %invariant.gep31 = getelementptr double, ptr %1, i64 %22
  %invariant.gep32 = getelementptr double, ptr %1, i64 %22
  br label %23

23:                                               ; preds = %.preheader17, %113
  %24 = phi i64 [ 0, %.preheader17 ], [ %114, %113 ]
  %25 = or disjoint i64 %24, %22
  %26 = getelementptr double, ptr %15, i64 %25
  %invariant.gep29 = getelementptr double, ptr %8, i64 %24
  %invariant.gep23 = getelementptr double, ptr %invariant.gep.1, i64 %24
  br label %.preheader16

.preheader16:                                     ; preds = %23, %111
  %27 = phi i64 [ 0, %23 ], [ %112, %111 ]
  %28 = shl i64 %27, 6
  %29 = getelementptr double, ptr %26, i64 %28
  %.promoted = load <4 x double>, ptr %29, align 8
  %gep = getelementptr double, ptr %invariant.gep31, i64 %28
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %30 = phi i64 [ 0, %.preheader16 ], [ %69, %.critedge ]
  %31 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %68, %.critedge ]
  %32 = shl nuw nsw i64 %30, 6
  %gep28 = getelementptr double, ptr %gep, i64 %30
  %33 = load double, ptr %gep28, align 8
  %34 = insertelement <1 x double> poison, double %33, i64 0
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %32
  %35 = load <4 x double>, ptr %gep30, align 8
  %36 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> zeroinitializer
  %37 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 1>
  %38 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 2>
  %39 = shufflevector <4 x double> %35, <4 x double> poison, <1 x i32> <i32 3>
  %40 = fmul <1 x double> %34, %36
  %41 = fmul <1 x double> %34, %37
  %42 = fmul <1 x double> %34, %38
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = fmul <1 x double> %34, %39
  %45 = shufflevector <1 x double> %44, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %46 = shufflevector <1 x double> %40, <1 x double> %41, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %45, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %49 = fadd <4 x double> %31, %48
  store <4 x double> %49, ptr %29, align 8
  %50 = or disjoint i64 %30, 1
  %51 = shl nuw nsw i64 %50, 6
  %gep28.1 = getelementptr double, ptr %gep, i64 %50
  %52 = load double, ptr %gep28.1, align 8
  %53 = insertelement <1 x double> poison, double %52, i64 0
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %51
  %54 = load <4 x double>, ptr %gep30.1, align 8
  %55 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> zeroinitializer
  %56 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 1>
  %57 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 2>
  %58 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 3>
  %59 = fmul <1 x double> %53, %55
  %60 = fmul <1 x double> %53, %56
  %61 = fmul <1 x double> %53, %57
  %62 = shufflevector <1 x double> %61, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %63 = fmul <1 x double> %53, %58
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = shufflevector <1 x double> %59, <1 x double> %60, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %62, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %68 = fadd <4 x double> %49, %67
  store <4 x double> %68, ptr %29, align 8
  %69 = add nuw nsw i64 %30, 2
  %exitcond.not.1 = icmp eq i64 %69, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %70 = getelementptr double, ptr %29, i64 4
  %.promoted.1 = load <4 x double>, ptr %70, align 8
  %gep33 = getelementptr double, ptr %invariant.gep32, i64 %28
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %71 = phi i64 [ 0, %.preheader.1 ], [ %110, %.critedge.1 ]
  %72 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %109, %.critedge.1 ]
  %73 = shl nuw nsw i64 %71, 6
  %gep22 = getelementptr double, ptr %gep33, i64 %71
  %74 = load double, ptr %gep22, align 8
  %75 = insertelement <1 x double> poison, double %74, i64 0
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %73
  %76 = load <4 x double>, ptr %gep24, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %75, %77
  %82 = fmul <1 x double> %75, %78
  %83 = fmul <1 x double> %75, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %75, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %72, %89
  store <4 x double> %90, ptr %70, align 8
  %91 = or disjoint i64 %71, 1
  %92 = shl nuw nsw i64 %91, 6
  %gep22.1 = getelementptr double, ptr %gep33, i64 %91
  %93 = load double, ptr %gep22.1, align 8
  %94 = insertelement <1 x double> poison, double %93, i64 0
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %92
  %95 = load <4 x double>, ptr %gep24.1, align 8
  %96 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> zeroinitializer
  %97 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 1>
  %98 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 2>
  %99 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 3>
  %100 = fmul <1 x double> %94, %96
  %101 = fmul <1 x double> %94, %97
  %102 = fmul <1 x double> %94, %98
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = fmul <1 x double> %94, %99
  %105 = shufflevector <1 x double> %104, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %106 = shufflevector <1 x double> %100, <1 x double> %101, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %105, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %109 = fadd <4 x double> %90, %108
  store <4 x double> %109, ptr %70, align 8
  %110 = add nuw nsw i64 %71, 2
  %exitcond.1.not.1 = icmp eq i64 %110, 64
  br i1 %exitcond.1.not.1, label %111, label %.critedge.1

111:                                              ; preds = %.critedge.1
  %112 = add nuw nsw i64 %27, 1
  %exitcond19.not = icmp eq i64 %112, 8
  br i1 %exitcond19.not, label %113, label %.preheader16

113:                                              ; preds = %111
  %114 = add nuw nsw i64 %24, 8
  %115 = icmp ult i64 %24, 56
  br i1 %115, label %23, label %116

116:                                              ; preds = %113
  %117 = add nuw nsw i64 %21, 8
  %118 = icmp ult i64 %21, 56
  br i1 %118, label %.preheader17, label %119

119:                                              ; preds = %116
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %99, %3
  %4 = phi i64 [ %100, %99 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 6
  %invariant.gep31.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %6

6:                                                ; preds = %96, %.preheader17.i
  %7 = phi i64 [ 0, %.preheader17.i ], [ %97, %96 ]
  %8 = or disjoint i64 %7, %5
  %9 = getelementptr double, ptr %.unpack32, i64 %8
  %invariant.gep29.i = getelementptr double, ptr %.unpack17, i64 %7
  %invariant.gep23.i = getelementptr double, ptr %invariant.gep.1.i, i64 %7
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %94, %6
  %10 = phi i64 [ 0, %6 ], [ %95, %94 ]
  %11 = shl i64 %10, 6
  %12 = getelementptr double, ptr %9, i64 %11
  %.promoted.i = load <4 x double>, ptr %12, align 8
  %gep.i = getelementptr double, ptr %invariant.gep31.i, i64 %11
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %13 = phi i64 [ 0, %.preheader16.i ], [ %52, %.critedge.i ]
  %14 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %51, %.critedge.i ]
  %15 = shl nuw nsw i64 %13, 6
  %gep28.i = getelementptr double, ptr %gep.i, i64 %13
  %16 = load double, ptr %gep28.i, align 8
  %17 = insertelement <1 x double> poison, double %16, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %15
  %18 = load <4 x double>, ptr %gep30.i, align 8
  %19 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> zeroinitializer
  %20 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 1>
  %21 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 2>
  %22 = shufflevector <4 x double> %18, <4 x double> poison, <1 x i32> <i32 3>
  %23 = fmul <1 x double> %17, %19
  %24 = fmul <1 x double> %17, %20
  %25 = fmul <1 x double> %17, %21
  %26 = shufflevector <1 x double> %25, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %27 = fmul <1 x double> %17, %22
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = shufflevector <1 x double> %23, <1 x double> %24, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %30 = shufflevector <4 x double> %29, <4 x double> %26, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %31 = shufflevector <4 x double> %30, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %32 = fadd <4 x double> %14, %31
  store <4 x double> %32, ptr %12, align 8
  %33 = or disjoint i64 %13, 1
  %34 = shl nuw nsw i64 %33, 6
  %gep28.i.1 = getelementptr double, ptr %gep.i, i64 %33
  %35 = load double, ptr %gep28.i.1, align 8
  %36 = insertelement <1 x double> poison, double %35, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %34
  %37 = load <4 x double>, ptr %gep30.i.1, align 8
  %38 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> zeroinitializer
  %39 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 1>
  %40 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 2>
  %41 = shufflevector <4 x double> %37, <4 x double> poison, <1 x i32> <i32 3>
  %42 = fmul <1 x double> %36, %38
  %43 = fmul <1 x double> %36, %39
  %44 = fmul <1 x double> %36, %40
  %45 = shufflevector <1 x double> %44, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %46 = fmul <1 x double> %36, %41
  %47 = shufflevector <1 x double> %46, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %48 = shufflevector <1 x double> %42, <1 x double> %43, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %45, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %47, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %51 = fadd <4 x double> %32, %50
  store <4 x double> %51, ptr %12, align 8
  %52 = add nuw nsw i64 %13, 2
  %exitcond.not.i.1 = icmp eq i64 %52, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %53 = getelementptr double, ptr %12, i64 4
  %.promoted.1.i = load <4 x double>, ptr %53, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %93, %.critedge.1.i ]
  %55 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %92, %.critedge.1.i ]
  %56 = shl nuw nsw i64 %54, 6
  %gep22.i = getelementptr double, ptr %gep.i, i64 %54
  %57 = load double, ptr %gep22.i, align 8
  %58 = insertelement <1 x double> poison, double %57, i64 0
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %56
  %59 = load <4 x double>, ptr %gep24.i, align 8
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> zeroinitializer
  %61 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 1>
  %62 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 2>
  %63 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 3>
  %64 = fmul <1 x double> %58, %60
  %65 = fmul <1 x double> %58, %61
  %66 = fmul <1 x double> %58, %62
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = fmul <1 x double> %58, %63
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = shufflevector <1 x double> %64, <1 x double> %65, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %73 = fadd <4 x double> %55, %72
  store <4 x double> %73, ptr %53, align 8
  %74 = or disjoint i64 %54, 1
  %75 = shl nuw nsw i64 %74, 6
  %gep22.i.1 = getelementptr double, ptr %gep.i, i64 %74
  %76 = load double, ptr %gep22.i.1, align 8
  %77 = insertelement <1 x double> poison, double %76, i64 0
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %75
  %78 = load <4 x double>, ptr %gep24.i.1, align 8
  %79 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> zeroinitializer
  %80 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 1>
  %81 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 2>
  %82 = shufflevector <4 x double> %78, <4 x double> poison, <1 x i32> <i32 3>
  %83 = fmul <1 x double> %77, %79
  %84 = fmul <1 x double> %77, %80
  %85 = fmul <1 x double> %77, %81
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = fmul <1 x double> %77, %82
  %88 = shufflevector <1 x double> %87, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %89 = shufflevector <1 x double> %83, <1 x double> %84, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %90 = shufflevector <4 x double> %89, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %91 = shufflevector <4 x double> %90, <4 x double> %88, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %92 = fadd <4 x double> %73, %91
  store <4 x double> %92, ptr %53, align 8
  %93 = add nuw nsw i64 %54, 2
  %exitcond.1.not.i.1 = icmp eq i64 %93, 64
  br i1 %exitcond.1.not.i.1, label %94, label %.critedge.1.i

94:                                               ; preds = %.critedge.1.i
  %95 = add nuw nsw i64 %10, 1
  %exitcond19.not.i = icmp eq i64 %95, 8
  br i1 %exitcond19.not.i, label %96, label %.preheader16.i

96:                                               ; preds = %94
  %97 = add nuw nsw i64 %7, 8
  %98 = icmp ult i64 %7, 56
  br i1 %98, label %6, label %99

99:                                               ; preds = %96
  %100 = add nuw nsw i64 %4, 8
  %101 = icmp ult i64 %4, 56
  br i1 %101, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %99
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %106, %1
  %11 = phi i64 [ %107, %106 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 6
  %invariant.gep31.i = getelementptr double, ptr %4, i64 %12
  br label %13

13:                                               ; preds = %103, %.preheader17.i
  %14 = phi i64 [ 0, %.preheader17.i ], [ %104, %103 ]
  %15 = or disjoint i64 %14, %12
  %16 = getelementptr double, ptr %10, i64 %15
  %invariant.gep29.i = getelementptr double, ptr %7, i64 %14
  %invariant.gep23.i = getelementptr double, ptr %invariant.gep.1.i, i64 %14
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %101, %13
  %17 = phi i64 [ 0, %13 ], [ %102, %101 ]
  %18 = shl i64 %17, 6
  %19 = getelementptr double, ptr %16, i64 %18
  %.promoted.i = load <4 x double>, ptr %19, align 8
  %gep.i = getelementptr double, ptr %invariant.gep31.i, i64 %18
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %20 = phi i64 [ 0, %.preheader16.i ], [ %59, %.critedge.i ]
  %21 = phi <4 x double> [ %.promoted.i, %.preheader16.i ], [ %58, %.critedge.i ]
  %22 = shl nuw nsw i64 %20, 6
  %gep28.i = getelementptr double, ptr %gep.i, i64 %20
  %23 = load double, ptr %gep28.i, align 8
  %24 = insertelement <1 x double> poison, double %23, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %22
  %25 = load <4 x double>, ptr %gep30.i, align 8
  %26 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> zeroinitializer
  %27 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 1>
  %28 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 2>
  %29 = shufflevector <4 x double> %25, <4 x double> poison, <1 x i32> <i32 3>
  %30 = fmul <1 x double> %24, %26
  %31 = fmul <1 x double> %24, %27
  %32 = fmul <1 x double> %24, %28
  %33 = shufflevector <1 x double> %32, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %34 = fmul <1 x double> %24, %29
  %35 = shufflevector <1 x double> %34, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = shufflevector <1 x double> %30, <1 x double> %31, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %37 = shufflevector <4 x double> %36, <4 x double> %33, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %38 = shufflevector <4 x double> %37, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %39 = fadd <4 x double> %21, %38
  store <4 x double> %39, ptr %19, align 8
  %40 = or disjoint i64 %20, 1
  %41 = shl nuw nsw i64 %40, 6
  %gep28.i.1 = getelementptr double, ptr %gep.i, i64 %40
  %42 = load double, ptr %gep28.i.1, align 8
  %43 = insertelement <1 x double> poison, double %42, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %41
  %44 = load <4 x double>, ptr %gep30.i.1, align 8
  %45 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> zeroinitializer
  %46 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 1>
  %47 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 2>
  %48 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 3>
  %49 = fmul <1 x double> %43, %45
  %50 = fmul <1 x double> %43, %46
  %51 = fmul <1 x double> %43, %47
  %52 = shufflevector <1 x double> %51, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %53 = fmul <1 x double> %43, %48
  %54 = shufflevector <1 x double> %53, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <1 x double> %49, <1 x double> %50, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %56 = shufflevector <4 x double> %55, <4 x double> %52, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %54, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %58 = fadd <4 x double> %39, %57
  store <4 x double> %58, ptr %19, align 8
  %59 = add nuw nsw i64 %20, 2
  %exitcond.not.i.1 = icmp eq i64 %59, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %60 = getelementptr double, ptr %19, i64 4
  %.promoted.1.i = load <4 x double>, ptr %60, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %61 = phi i64 [ 0, %.preheader.1.i ], [ %100, %.critedge.1.i ]
  %62 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %99, %.critedge.1.i ]
  %63 = shl nuw nsw i64 %61, 6
  %gep22.i = getelementptr double, ptr %gep.i, i64 %61
  %64 = load double, ptr %gep22.i, align 8
  %65 = insertelement <1 x double> poison, double %64, i64 0
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %63
  %66 = load <4 x double>, ptr %gep24.i, align 8
  %67 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> zeroinitializer
  %68 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 1>
  %69 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 2>
  %70 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 3>
  %71 = fmul <1 x double> %65, %67
  %72 = fmul <1 x double> %65, %68
  %73 = fmul <1 x double> %65, %69
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = fmul <1 x double> %65, %70
  %76 = shufflevector <1 x double> %75, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = shufflevector <1 x double> %71, <1 x double> %72, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %79 = shufflevector <4 x double> %78, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %80 = fadd <4 x double> %62, %79
  store <4 x double> %80, ptr %60, align 8
  %81 = or disjoint i64 %61, 1
  %82 = shl nuw nsw i64 %81, 6
  %gep22.i.1 = getelementptr double, ptr %gep.i, i64 %81
  %83 = load double, ptr %gep22.i.1, align 8
  %84 = insertelement <1 x double> poison, double %83, i64 0
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %82
  %85 = load <4 x double>, ptr %gep24.i.1, align 8
  %86 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> zeroinitializer
  %87 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 1>
  %88 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 2>
  %89 = shufflevector <4 x double> %85, <4 x double> poison, <1 x i32> <i32 3>
  %90 = fmul <1 x double> %84, %86
  %91 = fmul <1 x double> %84, %87
  %92 = fmul <1 x double> %84, %88
  %93 = shufflevector <1 x double> %92, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %94 = fmul <1 x double> %84, %89
  %95 = shufflevector <1 x double> %94, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %96 = shufflevector <1 x double> %90, <1 x double> %91, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %93, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %98 = shufflevector <4 x double> %97, <4 x double> %95, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %99 = fadd <4 x double> %80, %98
  store <4 x double> %99, ptr %60, align 8
  %100 = add nuw nsw i64 %61, 2
  %exitcond.1.not.i.1 = icmp eq i64 %100, 64
  br i1 %exitcond.1.not.i.1, label %101, label %.critedge.1.i

101:                                              ; preds = %.critedge.1.i
  %102 = add nuw nsw i64 %17, 1
  %exitcond19.not.i = icmp eq i64 %102, 8
  br i1 %exitcond19.not.i, label %103, label %.preheader16.i

103:                                              ; preds = %101
  %104 = add nuw nsw i64 %14, 8
  %105 = icmp ult i64 %14, 56
  br i1 %105, label %13, label %106

106:                                              ; preds = %103
  %107 = add nuw nsw i64 %11, 8
  %108 = icmp ult i64 %11, 56
  br i1 %108, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %106
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32.i, i8 0, i64 32768, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %105, %1
  %10 = phi i64 [ %106, %105 ], [ 0, %1 ]
  %11 = shl nuw nsw i64 %10, 6
  %invariant.gep31.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %12

12:                                               ; preds = %102, %.preheader17.i.i
  %13 = phi i64 [ 0, %.preheader17.i.i ], [ %103, %102 ]
  %14 = or disjoint i64 %13, %11
  %15 = getelementptr double, ptr %.unpack32.i, i64 %14
  %invariant.gep29.i.i = getelementptr double, ptr %.unpack17.i, i64 %13
  %invariant.gep23.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %13
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %100, %12
  %16 = phi i64 [ 0, %12 ], [ %101, %100 ]
  %17 = shl i64 %16, 6
  %18 = getelementptr double, ptr %15, i64 %17
  %.promoted.i.i = load <4 x double>, ptr %18, align 8
  %gep.i.i = getelementptr double, ptr %invariant.gep31.i.i, i64 %17
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader16.i.i
  %19 = phi i64 [ 0, %.preheader16.i.i ], [ %58, %.critedge.i.i ]
  %20 = phi <4 x double> [ %.promoted.i.i, %.preheader16.i.i ], [ %57, %.critedge.i.i ]
  %21 = shl nuw nsw i64 %19, 6
  %gep28.i.i = getelementptr double, ptr %gep.i.i, i64 %19
  %22 = load double, ptr %gep28.i.i, align 8
  %23 = insertelement <1 x double> poison, double %22, i64 0
  %gep30.i.i = getelementptr double, ptr %invariant.gep29.i.i, i64 %21
  %24 = load <4 x double>, ptr %gep30.i.i, align 8
  %25 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> zeroinitializer
  %26 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 1>
  %27 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 2>
  %28 = shufflevector <4 x double> %24, <4 x double> poison, <1 x i32> <i32 3>
  %29 = fmul <1 x double> %23, %25
  %30 = fmul <1 x double> %23, %26
  %31 = fmul <1 x double> %23, %27
  %32 = shufflevector <1 x double> %31, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %33 = fmul <1 x double> %23, %28
  %34 = shufflevector <1 x double> %33, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %35 = shufflevector <1 x double> %29, <1 x double> %30, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %36 = shufflevector <4 x double> %35, <4 x double> %32, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %37 = shufflevector <4 x double> %36, <4 x double> %34, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %38 = fadd <4 x double> %20, %37
  store <4 x double> %38, ptr %18, align 8
  %39 = or disjoint i64 %19, 1
  %40 = shl nuw nsw i64 %39, 6
  %gep28.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %39
  %41 = load double, ptr %gep28.i.i.1, align 8
  %42 = insertelement <1 x double> poison, double %41, i64 0
  %gep30.i.i.1 = getelementptr double, ptr %invariant.gep29.i.i, i64 %40
  %43 = load <4 x double>, ptr %gep30.i.i.1, align 8
  %44 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> zeroinitializer
  %45 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 1>
  %46 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 2>
  %47 = shufflevector <4 x double> %43, <4 x double> poison, <1 x i32> <i32 3>
  %48 = fmul <1 x double> %42, %44
  %49 = fmul <1 x double> %42, %45
  %50 = fmul <1 x double> %42, %46
  %51 = shufflevector <1 x double> %50, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %52 = fmul <1 x double> %42, %47
  %53 = shufflevector <1 x double> %52, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %54 = shufflevector <1 x double> %48, <1 x double> %49, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %55 = shufflevector <4 x double> %54, <4 x double> %51, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %56 = shufflevector <4 x double> %55, <4 x double> %53, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %57 = fadd <4 x double> %38, %56
  store <4 x double> %57, ptr %18, align 8
  %58 = add nuw nsw i64 %19, 2
  %exitcond.not.i.i.1 = icmp eq i64 %58, 64
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %59 = getelementptr double, ptr %18, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %59, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %60 = phi i64 [ 0, %.preheader.1.i.i ], [ %99, %.critedge.1.i.i ]
  %61 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %98, %.critedge.1.i.i ]
  %62 = shl nuw nsw i64 %60, 6
  %gep22.i.i = getelementptr double, ptr %gep.i.i, i64 %60
  %63 = load double, ptr %gep22.i.i, align 8
  %64 = insertelement <1 x double> poison, double %63, i64 0
  %gep24.i.i = getelementptr double, ptr %invariant.gep23.i.i, i64 %62
  %65 = load <4 x double>, ptr %gep24.i.i, align 8
  %66 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> zeroinitializer
  %67 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 1>
  %68 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 2>
  %69 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 3>
  %70 = fmul <1 x double> %64, %66
  %71 = fmul <1 x double> %64, %67
  %72 = fmul <1 x double> %64, %68
  %73 = shufflevector <1 x double> %72, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = fmul <1 x double> %64, %69
  %75 = shufflevector <1 x double> %74, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %76 = shufflevector <1 x double> %70, <1 x double> %71, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %75, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %79 = fadd <4 x double> %61, %78
  store <4 x double> %79, ptr %59, align 8
  %80 = or disjoint i64 %60, 1
  %81 = shl nuw nsw i64 %80, 6
  %gep22.i.i.1 = getelementptr double, ptr %gep.i.i, i64 %80
  %82 = load double, ptr %gep22.i.i.1, align 8
  %83 = insertelement <1 x double> poison, double %82, i64 0
  %gep24.i.i.1 = getelementptr double, ptr %invariant.gep23.i.i, i64 %81
  %84 = load <4 x double>, ptr %gep24.i.i.1, align 8
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> zeroinitializer
  %86 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 1>
  %87 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 2>
  %88 = shufflevector <4 x double> %84, <4 x double> poison, <1 x i32> <i32 3>
  %89 = fmul <1 x double> %83, %85
  %90 = fmul <1 x double> %83, %86
  %91 = fmul <1 x double> %83, %87
  %92 = shufflevector <1 x double> %91, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = fmul <1 x double> %83, %88
  %94 = shufflevector <1 x double> %93, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = shufflevector <1 x double> %89, <1 x double> %90, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %97 = shufflevector <4 x double> %96, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %98 = fadd <4 x double> %79, %97
  store <4 x double> %98, ptr %59, align 8
  %99 = add nuw nsw i64 %60, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %99, 64
  br i1 %exitcond.1.not.i.i.1, label %100, label %.critedge.1.i.i

100:                                              ; preds = %.critedge.1.i.i
  %101 = add nuw nsw i64 %16, 1
  %exitcond19.not.i.i = icmp eq i64 %101, 8
  br i1 %exitcond19.not.i.i, label %102, label %.preheader16.i.i

102:                                              ; preds = %100
  %103 = add nuw nsw i64 %13, 8
  %104 = icmp ult i64 %13, 56
  br i1 %104, label %12, label %105

105:                                              ; preds = %102
  %106 = add nuw nsw i64 %10, 8
  %107 = icmp ult i64 %10, 56
  br i1 %107, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %105
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
