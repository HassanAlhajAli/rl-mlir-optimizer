module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %22 = llvm.mlir.constant(256 : index) : i64
    %23 = llvm.mlir.constant(4 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.constant(8 : index) : i64
    %26 = llvm.mlir.constant(0 : index) : i64
    %27 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%26 : i64)
  ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb2
    %29 = llvm.icmp "slt" %28, %22 : i64
    llvm.cond_br %29, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %30 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %31 = llvm.getelementptr %30[%28] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %27, %31 : f64, !llvm.ptr
    %32 = llvm.add %28, %24  : i64
    llvm.br ^bb1(%32 : i64)
  ^bb3:  // pred: ^bb1
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.alloca %33 x !llvm.array<4 x vector<1xf64>> : (i64) -> !llvm.ptr
    %35 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %36 = llvm.insertvalue %34, %35[0] : !llvm.struct<(ptr, ptr, i64)> 
    %37 = llvm.insertvalue %34, %36[1] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.mlir.constant(0 : index) : i64
    %39 = llvm.insertvalue %38, %37[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%26 : i64)
  ^bb4(%40: i64):  // 2 preds: ^bb3, ^bb14
    %41 = llvm.icmp "slt" %40, %22 : i64
    llvm.cond_br %41, ^bb5, ^bb15
  ^bb5:  // pred: ^bb4
    %42 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %45 = llvm.insertvalue %42, %44[0] : !llvm.struct<(ptr, ptr, i64)> 
    %46 = llvm.insertvalue %43, %45[1] : !llvm.struct<(ptr, ptr, i64)> 
    %47 = llvm.mlir.constant(0 : index) : i64
    %48 = llvm.insertvalue %47, %46[2] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %50 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %51 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %52 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %54 = llvm.mul %40, %22  : i64
    %55 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %58 = llvm.insertvalue %55, %57[0] : !llvm.struct<(ptr, ptr, i64)> 
    %59 = llvm.insertvalue %56, %58[1] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.mlir.constant(0 : index) : i64
    %61 = llvm.insertvalue %60, %59[2] : !llvm.struct<(ptr, ptr, i64)> 
    %62 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %63 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %64 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%26 : i64)
  ^bb6(%65: i64):  // 2 preds: ^bb5, ^bb13
    %66 = llvm.icmp "slt" %65, %25 : i64
    llvm.cond_br %66, ^bb7, ^bb14
  ^bb7:  // pred: ^bb6
    llvm.br ^bb8(%26 : i64)
  ^bb8(%67: i64):  // 2 preds: ^bb7, ^bb12
    %68 = llvm.icmp "slt" %67, %22 : i64
    llvm.cond_br %68, ^bb9, ^bb13
  ^bb9:  // pred: ^bb8
    %69 = llvm.mul %65, %22  : i64
    %70 = llvm.add %54, %69  : i64
    %71 = llvm.add %70, %67  : i64
    %72 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %73 = llvm.insertvalue %42, %72[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %74 = llvm.insertvalue %43, %73[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %75 = llvm.insertvalue %71, %74[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %76 = llvm.mlir.constant(4 : index) : i64
    %77 = llvm.insertvalue %76, %75[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.mlir.constant(256 : index) : i64
    %79 = llvm.insertvalue %78, %77[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.mlir.constant(1 : index) : i64
    %81 = llvm.insertvalue %80, %79[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %82 = llvm.mlir.constant(1 : index) : i64
    %83 = llvm.insertvalue %82, %81[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %85 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %86 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %87 = llvm.insertvalue %84, %86[0] : !llvm.struct<(ptr, ptr, i64)> 
    %88 = llvm.insertvalue %85, %87[1] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.mlir.constant(0 : index) : i64
    %90 = llvm.insertvalue %89, %88[2] : !llvm.struct<(ptr, ptr, i64)> 
    %91 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %92 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %93 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %94 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %95 = llvm.insertvalue %84, %94[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.insertvalue %85, %95[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.insertvalue %67, %96[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.mlir.constant(1 : index) : i64
    %99 = llvm.insertvalue %98, %97[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.mlir.constant(1 : index) : i64
    %101 = llvm.insertvalue %100, %99[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.add %40, %65  : i64
    %103 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %104 = llvm.insertvalue %55, %103[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %105 = llvm.insertvalue %56, %104[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.insertvalue %102, %105[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %107 = llvm.mlir.constant(4 : index) : i64
    %108 = llvm.insertvalue %107, %106[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.mlir.constant(1 : index) : i64
    %110 = llvm.insertvalue %109, %108[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %112 = llvm.extractvalue %39[0] : !llvm.struct<(ptr, ptr, i64)> 
    %113 = llvm.insertvalue %112, %111[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %114 = llvm.extractvalue %39[1] : !llvm.struct<(ptr, ptr, i64)> 
    %115 = llvm.insertvalue %114, %113[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %116 = llvm.mlir.constant(0 : index) : i64
    %117 = llvm.insertvalue %116, %115[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %118 = llvm.mlir.constant(4 : index) : i64
    %119 = llvm.insertvalue %118, %117[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %120 = llvm.mlir.constant(1 : index) : i64
    %121 = llvm.insertvalue %120, %119[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb10(%26 : i64)
  ^bb10(%122: i64):  // 2 preds: ^bb9, ^bb11
    %123 = llvm.icmp "slt" %122, %23 : i64
    llvm.cond_br %123, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %124 = llvm.getelementptr %43[%71] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %125 = llvm.mlir.constant(256 : index) : i64
    %126 = llvm.mul %122, %125  : i64
    %127 = llvm.add %126, %26  : i64
    %128 = llvm.getelementptr %124[%127] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %129 = llvm.load %128 : !llvm.ptr -> f64
    %130 = llvm.mlir.undef : vector<1xf64>
    %131 = llvm.mlir.constant(0 : i32) : i32
    %132 = llvm.insertelement %129, %130[%131 : i32] : vector<1xf64>
    %133 = llvm.shufflevector %132, %130 [0] : vector<1xf64> 
    %134 = llvm.getelementptr %114[%122] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %133, %134 : vector<1xf64>, !llvm.ptr
    %135 = llvm.add %122, %24  : i64
    llvm.br ^bb10(%135 : i64)
  ^bb12:  // pred: ^bb10
    %136 = llvm.load %34 : !llvm.ptr -> !llvm.array<4 x vector<1xf64>>
    %137 = llvm.getelementptr %85[%67] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %138 = llvm.getelementptr %137[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %139 = llvm.load %138 : !llvm.ptr -> f64
    %140 = llvm.mlir.undef : vector<1xf64>
    %141 = llvm.mlir.constant(0 : i32) : i32
    %142 = llvm.insertelement %139, %140[%141 : i32] : vector<1xf64>
    %143 = llvm.shufflevector %142, %140 [0] : vector<1xf64> 
    %144 = llvm.insertvalue %143, %21[0] : !llvm.array<4 x vector<1xf64>> 
    %145 = llvm.insertvalue %143, %144[1] : !llvm.array<4 x vector<1xf64>> 
    %146 = llvm.insertvalue %143, %145[2] : !llvm.array<4 x vector<1xf64>> 
    %147 = llvm.insertvalue %143, %146[3] : !llvm.array<4 x vector<1xf64>> 
    %148 = llvm.extractvalue %110[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %149 = llvm.extractvalue %110[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.getelementptr %148[%149] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %151 = llvm.getelementptr %150[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %152 = llvm.load %151 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %153 = llvm.mlir.undef : !llvm.array<4 x vector<1xf64>>
    %154 = llvm.extractvalue %136[0] : !llvm.array<4 x vector<1xf64>> 
    %155 = llvm.fmul %154, %143  : vector<1xf64>
    %156 = llvm.insertvalue %155, %153[0] : !llvm.array<4 x vector<1xf64>> 
    %157 = llvm.extractvalue %136[1] : !llvm.array<4 x vector<1xf64>> 
    %158 = llvm.fmul %157, %143  : vector<1xf64>
    %159 = llvm.insertvalue %158, %156[1] : !llvm.array<4 x vector<1xf64>> 
    %160 = llvm.extractvalue %136[2] : !llvm.array<4 x vector<1xf64>> 
    %161 = llvm.fmul %160, %143  : vector<1xf64>
    %162 = llvm.insertvalue %161, %159[2] : !llvm.array<4 x vector<1xf64>> 
    %163 = llvm.extractvalue %136[3] : !llvm.array<4 x vector<1xf64>> 
    %164 = llvm.fmul %163, %143  : vector<1xf64>
    %165 = llvm.insertvalue %164, %162[3] : !llvm.array<4 x vector<1xf64>> 
    %166 = llvm.extractvalue %165[0] : !llvm.array<4 x vector<1xf64>> 
    %167 = llvm.mlir.constant(0 : i64) : i64
    %168 = llvm.extractelement %166[%167 : i64] : vector<1xf64>
    %169 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<4xf64>> 
    %170 = llvm.mlir.constant(0 : i64) : i64
    %171 = llvm.insertelement %168, %169[%170 : i64] : vector<4xf64>
    %172 = llvm.insertvalue %171, %20[0] : !llvm.array<1 x vector<4xf64>> 
    %173 = llvm.extractvalue %165[1] : !llvm.array<4 x vector<1xf64>> 
    %174 = llvm.mlir.constant(0 : i64) : i64
    %175 = llvm.extractelement %173[%174 : i64] : vector<1xf64>
    %176 = llvm.mlir.constant(1 : i64) : i64
    %177 = llvm.insertelement %175, %171[%176 : i64] : vector<4xf64>
    %178 = llvm.insertvalue %177, %172[0] : !llvm.array<1 x vector<4xf64>> 
    %179 = llvm.extractvalue %165[2] : !llvm.array<4 x vector<1xf64>> 
    %180 = llvm.mlir.constant(0 : i64) : i64
    %181 = llvm.extractelement %179[%180 : i64] : vector<1xf64>
    %182 = llvm.mlir.constant(2 : i64) : i64
    %183 = llvm.insertelement %181, %177[%182 : i64] : vector<4xf64>
    %184 = llvm.insertvalue %183, %178[0] : !llvm.array<1 x vector<4xf64>> 
    %185 = llvm.extractvalue %165[3] : !llvm.array<4 x vector<1xf64>> 
    %186 = llvm.mlir.constant(0 : i64) : i64
    %187 = llvm.extractelement %185[%186 : i64] : vector<1xf64>
    %188 = llvm.mlir.constant(3 : i64) : i64
    %189 = llvm.insertelement %187, %183[%188 : i64] : vector<4xf64>
    %190 = llvm.insertvalue %189, %184[0] : !llvm.array<1 x vector<4xf64>> 
    %191 = llvm.fadd %189, %152  : vector<4xf64>
    %192 = llvm.extractvalue %110[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %193 = llvm.extractvalue %110[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %194 = llvm.getelementptr %192[%193] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %195 = llvm.getelementptr %194[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %191, %195 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %196 = llvm.add %67, %24  : i64
    llvm.br ^bb8(%196 : i64)
  ^bb13:  // pred: ^bb8
    %197 = llvm.add %65, %23  : i64
    llvm.br ^bb6(%197 : i64)
  ^bb14:  // pred: ^bb6
    %198 = llvm.add %40, %25  : i64
    llvm.br ^bb4(%198 : i64)
  ^bb15:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
