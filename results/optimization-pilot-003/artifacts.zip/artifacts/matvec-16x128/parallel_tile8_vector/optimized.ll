; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader10:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader10
  %18 = phi i64 [ 0, %.preheader10 ], [ %57, %17 ]
  %19 = phi <4 x double> [ zeroinitializer, %.preheader10 ], [ %56, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 128
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 256
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 384
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %8, i64 %18
  %29 = load double, ptr %28, align 8
  %30 = insertelement <4 x double> poison, double %21, i64 0
  %31 = insertelement <4 x double> %30, double %23, i64 1
  %32 = insertelement <4 x double> %31, double %25, i64 2
  %33 = insertelement <4 x double> %32, double %27, i64 3
  %34 = insertelement <4 x double> poison, double %29, i64 0
  %35 = shufflevector <4 x double> %34, <4 x double> poison, <4 x i32> zeroinitializer
  %36 = fmul <4 x double> %33, %35
  %37 = fadd <4 x double> %19, %36
  store <4 x double> %37, ptr %13, align 8
  %38 = or disjoint i64 %18, 1
  %39 = getelementptr double, ptr %1, i64 %38
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %39, i64 128
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %39, i64 256
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %39, i64 384
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %8, i64 %38
  %48 = load double, ptr %47, align 8
  %49 = insertelement <4 x double> poison, double %40, i64 0
  %50 = insertelement <4 x double> %49, double %42, i64 1
  %51 = insertelement <4 x double> %50, double %44, i64 2
  %52 = insertelement <4 x double> %51, double %46, i64 3
  %53 = insertelement <4 x double> poison, double %48, i64 0
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = fmul <4 x double> %52, %54
  %56 = fadd <4 x double> %37, %55
  store <4 x double> %56, ptr %13, align 8
  %57 = add nuw nsw i64 %18, 2
  %exitcond.not.1 = icmp eq i64 %57, 128
  br i1 %exitcond.not.1, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %58 = getelementptr double, ptr %13, i64 4
  br label %59

59:                                               ; preds = %59, %.preheader.1
  %60 = phi i64 [ 0, %.preheader.1 ], [ %101, %59 ]
  %61 = phi <4 x double> [ zeroinitializer, %.preheader.1 ], [ %100, %59 ]
  %62 = getelementptr double, ptr %1, i64 %60
  %63 = getelementptr double, ptr %62, i64 512
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %62, i64 640
  %66 = load double, ptr %65, align 8
  %67 = getelementptr double, ptr %62, i64 768
  %68 = load double, ptr %67, align 8
  %69 = getelementptr double, ptr %62, i64 896
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %60
  %72 = load double, ptr %71, align 8
  %73 = insertelement <4 x double> poison, double %64, i64 0
  %74 = insertelement <4 x double> %73, double %66, i64 1
  %75 = insertelement <4 x double> %74, double %68, i64 2
  %76 = insertelement <4 x double> %75, double %70, i64 3
  %77 = insertelement <4 x double> poison, double %72, i64 0
  %78 = shufflevector <4 x double> %77, <4 x double> poison, <4 x i32> zeroinitializer
  %79 = fmul <4 x double> %76, %78
  %80 = fadd <4 x double> %61, %79
  store <4 x double> %80, ptr %58, align 8
  %81 = or disjoint i64 %60, 1
  %82 = getelementptr double, ptr %1, i64 %81
  %83 = getelementptr double, ptr %82, i64 512
  %84 = load double, ptr %83, align 8
  %85 = getelementptr double, ptr %82, i64 640
  %86 = load double, ptr %85, align 8
  %87 = getelementptr double, ptr %82, i64 768
  %88 = load double, ptr %87, align 8
  %89 = getelementptr double, ptr %82, i64 896
  %90 = load double, ptr %89, align 8
  %91 = getelementptr double, ptr %8, i64 %81
  %92 = load double, ptr %91, align 8
  %93 = insertelement <4 x double> poison, double %84, i64 0
  %94 = insertelement <4 x double> %93, double %86, i64 1
  %95 = insertelement <4 x double> %94, double %88, i64 2
  %96 = insertelement <4 x double> %95, double %90, i64 3
  %97 = insertelement <4 x double> poison, double %92, i64 0
  %98 = shufflevector <4 x double> %97, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = fmul <4 x double> %96, %98
  %100 = fadd <4 x double> %80, %99
  store <4 x double> %100, ptr %58, align 8
  %101 = add nuw nsw i64 %60, 2
  %exitcond.1.not.1 = icmp eq i64 %101, 128
  br i1 %exitcond.1.not.1, label %.preheader10.1, label %59

.preheader10.1:                                   ; preds = %59
  %102 = getelementptr double, ptr %13, i64 8
  br label %103

103:                                              ; preds = %103, %.preheader10.1
  %104 = phi i64 [ 0, %.preheader10.1 ], [ %145, %103 ]
  %105 = phi <4 x double> [ zeroinitializer, %.preheader10.1 ], [ %144, %103 ]
  %106 = getelementptr double, ptr %1, i64 %104
  %107 = getelementptr double, ptr %106, i64 1024
  %108 = load double, ptr %107, align 8
  %109 = getelementptr double, ptr %106, i64 1152
  %110 = load double, ptr %109, align 8
  %111 = getelementptr double, ptr %106, i64 1280
  %112 = load double, ptr %111, align 8
  %113 = getelementptr double, ptr %106, i64 1408
  %114 = load double, ptr %113, align 8
  %115 = getelementptr double, ptr %8, i64 %104
  %116 = load double, ptr %115, align 8
  %117 = insertelement <4 x double> poison, double %108, i64 0
  %118 = insertelement <4 x double> %117, double %110, i64 1
  %119 = insertelement <4 x double> %118, double %112, i64 2
  %120 = insertelement <4 x double> %119, double %114, i64 3
  %121 = insertelement <4 x double> poison, double %116, i64 0
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <4 x i32> zeroinitializer
  %123 = fmul <4 x double> %120, %122
  %124 = fadd <4 x double> %105, %123
  store <4 x double> %124, ptr %102, align 8
  %125 = or disjoint i64 %104, 1
  %126 = getelementptr double, ptr %1, i64 %125
  %127 = getelementptr double, ptr %126, i64 1024
  %128 = load double, ptr %127, align 8
  %129 = getelementptr double, ptr %126, i64 1152
  %130 = load double, ptr %129, align 8
  %131 = getelementptr double, ptr %126, i64 1280
  %132 = load double, ptr %131, align 8
  %133 = getelementptr double, ptr %126, i64 1408
  %134 = load double, ptr %133, align 8
  %135 = getelementptr double, ptr %8, i64 %125
  %136 = load double, ptr %135, align 8
  %137 = insertelement <4 x double> poison, double %128, i64 0
  %138 = insertelement <4 x double> %137, double %130, i64 1
  %139 = insertelement <4 x double> %138, double %132, i64 2
  %140 = insertelement <4 x double> %139, double %134, i64 3
  %141 = insertelement <4 x double> poison, double %136, i64 0
  %142 = shufflevector <4 x double> %141, <4 x double> poison, <4 x i32> zeroinitializer
  %143 = fmul <4 x double> %140, %142
  %144 = fadd <4 x double> %124, %143
  store <4 x double> %144, ptr %102, align 8
  %145 = add nuw nsw i64 %104, 2
  %exitcond.117.not.1 = icmp eq i64 %145, 128
  br i1 %exitcond.117.not.1, label %.preheader.1.1, label %103

.preheader.1.1:                                   ; preds = %103
  %146 = getelementptr double, ptr %13, i64 12
  br label %147

147:                                              ; preds = %147, %.preheader.1.1
  %148 = phi i64 [ 0, %.preheader.1.1 ], [ %189, %147 ]
  %149 = phi <4 x double> [ zeroinitializer, %.preheader.1.1 ], [ %188, %147 ]
  %150 = getelementptr double, ptr %1, i64 %148
  %151 = getelementptr double, ptr %150, i64 1536
  %152 = load double, ptr %151, align 8
  %153 = getelementptr double, ptr %150, i64 1664
  %154 = load double, ptr %153, align 8
  %155 = getelementptr double, ptr %150, i64 1792
  %156 = load double, ptr %155, align 8
  %157 = getelementptr double, ptr %150, i64 1920
  %158 = load double, ptr %157, align 8
  %159 = getelementptr double, ptr %8, i64 %148
  %160 = load double, ptr %159, align 8
  %161 = insertelement <4 x double> poison, double %152, i64 0
  %162 = insertelement <4 x double> %161, double %154, i64 1
  %163 = insertelement <4 x double> %162, double %156, i64 2
  %164 = insertelement <4 x double> %163, double %158, i64 3
  %165 = insertelement <4 x double> poison, double %160, i64 0
  %166 = shufflevector <4 x double> %165, <4 x double> poison, <4 x i32> zeroinitializer
  %167 = fmul <4 x double> %164, %166
  %168 = fadd <4 x double> %149, %167
  store <4 x double> %168, ptr %146, align 8
  %169 = or disjoint i64 %148, 1
  %170 = getelementptr double, ptr %1, i64 %169
  %171 = getelementptr double, ptr %170, i64 1536
  %172 = load double, ptr %171, align 8
  %173 = getelementptr double, ptr %170, i64 1664
  %174 = load double, ptr %173, align 8
  %175 = getelementptr double, ptr %170, i64 1792
  %176 = load double, ptr %175, align 8
  %177 = getelementptr double, ptr %170, i64 1920
  %178 = load double, ptr %177, align 8
  %179 = getelementptr double, ptr %8, i64 %169
  %180 = load double, ptr %179, align 8
  %181 = insertelement <4 x double> poison, double %172, i64 0
  %182 = insertelement <4 x double> %181, double %174, i64 1
  %183 = insertelement <4 x double> %182, double %176, i64 2
  %184 = insertelement <4 x double> %183, double %178, i64 3
  %185 = insertelement <4 x double> poison, double %180, i64 0
  %186 = shufflevector <4 x double> %185, <4 x double> poison, <4 x i32> zeroinitializer
  %187 = fmul <4 x double> %184, %186
  %188 = fadd <4 x double> %168, %187
  store <4 x double> %188, ptr %146, align 8
  %189 = add nuw nsw i64 %148, 2
  %exitcond.1.1.not.1 = icmp eq i64 %189, 128
  br i1 %exitcond.1.1.not.1, label %190, label %147

190:                                              ; preds = %147
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28, i8 0, i64 128, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %44, %4 ]
  %6 = phi <4 x double> [ zeroinitializer, %3 ], [ %43, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %7, i64 128
  %10 = load double, ptr %9, align 8
  %11 = getelementptr double, ptr %7, i64 256
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %7, i64 384
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %.unpack17, i64 %5
  %16 = load double, ptr %15, align 8
  %17 = insertelement <4 x double> poison, double %8, i64 0
  %18 = insertelement <4 x double> %17, double %10, i64 1
  %19 = insertelement <4 x double> %18, double %12, i64 2
  %20 = insertelement <4 x double> %19, double %14, i64 3
  %21 = insertelement <4 x double> poison, double %16, i64 0
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <4 x i32> zeroinitializer
  %23 = fmul <4 x double> %20, %22
  %24 = fadd <4 x double> %6, %23
  store <4 x double> %24, ptr %.unpack28, align 8
  %25 = or disjoint i64 %5, 1
  %26 = getelementptr double, ptr %.unpack2, i64 %25
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %26, i64 128
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %26, i64 256
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %26, i64 384
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %.unpack17, i64 %25
  %35 = load double, ptr %34, align 8
  %36 = insertelement <4 x double> poison, double %27, i64 0
  %37 = insertelement <4 x double> %36, double %29, i64 1
  %38 = insertelement <4 x double> %37, double %31, i64 2
  %39 = insertelement <4 x double> %38, double %33, i64 3
  %40 = insertelement <4 x double> poison, double %35, i64 0
  %41 = shufflevector <4 x double> %40, <4 x double> poison, <4 x i32> zeroinitializer
  %42 = fmul <4 x double> %39, %41
  %43 = fadd <4 x double> %24, %42
  store <4 x double> %43, ptr %.unpack28, align 8
  %44 = add nuw nsw i64 %5, 2
  %exitcond.not.i.1 = icmp eq i64 %44, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %45 = getelementptr double, ptr %.unpack28, i64 4
  br label %46

46:                                               ; preds = %46, %.preheader.1.i
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %88, %46 ]
  %48 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %87, %46 ]
  %49 = getelementptr double, ptr %.unpack2, i64 %47
  %50 = getelementptr double, ptr %49, i64 512
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %49, i64 640
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %49, i64 768
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %49, i64 896
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %47
  %59 = load double, ptr %58, align 8
  %60 = insertelement <4 x double> poison, double %51, i64 0
  %61 = insertelement <4 x double> %60, double %53, i64 1
  %62 = insertelement <4 x double> %61, double %55, i64 2
  %63 = insertelement <4 x double> %62, double %57, i64 3
  %64 = insertelement <4 x double> poison, double %59, i64 0
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = fmul <4 x double> %63, %65
  %67 = fadd <4 x double> %48, %66
  store <4 x double> %67, ptr %45, align 8
  %68 = or disjoint i64 %47, 1
  %69 = getelementptr double, ptr %.unpack2, i64 %68
  %70 = getelementptr double, ptr %69, i64 512
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %69, i64 640
  %73 = load double, ptr %72, align 8
  %74 = getelementptr double, ptr %69, i64 768
  %75 = load double, ptr %74, align 8
  %76 = getelementptr double, ptr %69, i64 896
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %.unpack17, i64 %68
  %79 = load double, ptr %78, align 8
  %80 = insertelement <4 x double> poison, double %71, i64 0
  %81 = insertelement <4 x double> %80, double %73, i64 1
  %82 = insertelement <4 x double> %81, double %75, i64 2
  %83 = insertelement <4 x double> %82, double %77, i64 3
  %84 = insertelement <4 x double> poison, double %79, i64 0
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = fmul <4 x double> %83, %85
  %87 = fadd <4 x double> %67, %86
  store <4 x double> %87, ptr %45, align 8
  %88 = add nuw nsw i64 %47, 2
  %exitcond.1.not.i.1 = icmp eq i64 %88, 128
  br i1 %exitcond.1.not.i.1, label %.preheader10.1.i, label %46

.preheader10.1.i:                                 ; preds = %46
  %89 = getelementptr double, ptr %.unpack28, i64 8
  br label %90

90:                                               ; preds = %90, %.preheader10.1.i
  %91 = phi i64 [ 0, %.preheader10.1.i ], [ %132, %90 ]
  %92 = phi <4 x double> [ zeroinitializer, %.preheader10.1.i ], [ %131, %90 ]
  %93 = getelementptr double, ptr %.unpack2, i64 %91
  %94 = getelementptr double, ptr %93, i64 1024
  %95 = load double, ptr %94, align 8
  %96 = getelementptr double, ptr %93, i64 1152
  %97 = load double, ptr %96, align 8
  %98 = getelementptr double, ptr %93, i64 1280
  %99 = load double, ptr %98, align 8
  %100 = getelementptr double, ptr %93, i64 1408
  %101 = load double, ptr %100, align 8
  %102 = getelementptr double, ptr %.unpack17, i64 %91
  %103 = load double, ptr %102, align 8
  %104 = insertelement <4 x double> poison, double %95, i64 0
  %105 = insertelement <4 x double> %104, double %97, i64 1
  %106 = insertelement <4 x double> %105, double %99, i64 2
  %107 = insertelement <4 x double> %106, double %101, i64 3
  %108 = insertelement <4 x double> poison, double %103, i64 0
  %109 = shufflevector <4 x double> %108, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = fmul <4 x double> %107, %109
  %111 = fadd <4 x double> %92, %110
  store <4 x double> %111, ptr %89, align 8
  %112 = or disjoint i64 %91, 1
  %113 = getelementptr double, ptr %.unpack2, i64 %112
  %114 = getelementptr double, ptr %113, i64 1024
  %115 = load double, ptr %114, align 8
  %116 = getelementptr double, ptr %113, i64 1152
  %117 = load double, ptr %116, align 8
  %118 = getelementptr double, ptr %113, i64 1280
  %119 = load double, ptr %118, align 8
  %120 = getelementptr double, ptr %113, i64 1408
  %121 = load double, ptr %120, align 8
  %122 = getelementptr double, ptr %.unpack17, i64 %112
  %123 = load double, ptr %122, align 8
  %124 = insertelement <4 x double> poison, double %115, i64 0
  %125 = insertelement <4 x double> %124, double %117, i64 1
  %126 = insertelement <4 x double> %125, double %119, i64 2
  %127 = insertelement <4 x double> %126, double %121, i64 3
  %128 = insertelement <4 x double> poison, double %123, i64 0
  %129 = shufflevector <4 x double> %128, <4 x double> poison, <4 x i32> zeroinitializer
  %130 = fmul <4 x double> %127, %129
  %131 = fadd <4 x double> %111, %130
  store <4 x double> %131, ptr %89, align 8
  %132 = add nuw nsw i64 %91, 2
  %exitcond.117.not.i.1 = icmp eq i64 %132, 128
  br i1 %exitcond.117.not.i.1, label %.preheader.1.1.i, label %90

.preheader.1.1.i:                                 ; preds = %90
  %133 = getelementptr double, ptr %.unpack28, i64 12
  br label %134

134:                                              ; preds = %134, %.preheader.1.1.i
  %135 = phi i64 [ 0, %.preheader.1.1.i ], [ %176, %134 ]
  %136 = phi <4 x double> [ zeroinitializer, %.preheader.1.1.i ], [ %175, %134 ]
  %137 = getelementptr double, ptr %.unpack2, i64 %135
  %138 = getelementptr double, ptr %137, i64 1536
  %139 = load double, ptr %138, align 8
  %140 = getelementptr double, ptr %137, i64 1664
  %141 = load double, ptr %140, align 8
  %142 = getelementptr double, ptr %137, i64 1792
  %143 = load double, ptr %142, align 8
  %144 = getelementptr double, ptr %137, i64 1920
  %145 = load double, ptr %144, align 8
  %146 = getelementptr double, ptr %.unpack17, i64 %135
  %147 = load double, ptr %146, align 8
  %148 = insertelement <4 x double> poison, double %139, i64 0
  %149 = insertelement <4 x double> %148, double %141, i64 1
  %150 = insertelement <4 x double> %149, double %143, i64 2
  %151 = insertelement <4 x double> %150, double %145, i64 3
  %152 = insertelement <4 x double> poison, double %147, i64 0
  %153 = shufflevector <4 x double> %152, <4 x double> poison, <4 x i32> zeroinitializer
  %154 = fmul <4 x double> %151, %153
  %155 = fadd <4 x double> %136, %154
  store <4 x double> %155, ptr %133, align 8
  %156 = or disjoint i64 %135, 1
  %157 = getelementptr double, ptr %.unpack2, i64 %156
  %158 = getelementptr double, ptr %157, i64 1536
  %159 = load double, ptr %158, align 8
  %160 = getelementptr double, ptr %157, i64 1664
  %161 = load double, ptr %160, align 8
  %162 = getelementptr double, ptr %157, i64 1792
  %163 = load double, ptr %162, align 8
  %164 = getelementptr double, ptr %157, i64 1920
  %165 = load double, ptr %164, align 8
  %166 = getelementptr double, ptr %.unpack17, i64 %156
  %167 = load double, ptr %166, align 8
  %168 = insertelement <4 x double> poison, double %159, i64 0
  %169 = insertelement <4 x double> %168, double %161, i64 1
  %170 = insertelement <4 x double> %169, double %163, i64 2
  %171 = insertelement <4 x double> %170, double %165, i64 3
  %172 = insertelement <4 x double> poison, double %167, i64 0
  %173 = shufflevector <4 x double> %172, <4 x double> poison, <4 x i32> zeroinitializer
  %174 = fmul <4 x double> %171, %173
  %175 = fadd <4 x double> %155, %174
  store <4 x double> %175, ptr %133, align 8
  %176 = add nuw nsw i64 %135, 2
  %exitcond.1.1.not.i.1 = icmp eq i64 %176, 128
  br i1 %exitcond.1.1.not.i.1, label %kernel.exit, label %134

kernel.exit:                                      ; preds = %134
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %10, i8 0, i64 128, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %51, %11 ]
  %13 = phi <4 x double> [ zeroinitializer, %1 ], [ %50, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %14, i64 128
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %14, i64 256
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %14, i64 384
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %7, i64 %12
  %23 = load double, ptr %22, align 8
  %24 = insertelement <4 x double> poison, double %15, i64 0
  %25 = insertelement <4 x double> %24, double %17, i64 1
  %26 = insertelement <4 x double> %25, double %19, i64 2
  %27 = insertelement <4 x double> %26, double %21, i64 3
  %28 = insertelement <4 x double> poison, double %23, i64 0
  %29 = shufflevector <4 x double> %28, <4 x double> poison, <4 x i32> zeroinitializer
  %30 = fmul <4 x double> %27, %29
  %31 = fadd <4 x double> %13, %30
  store <4 x double> %31, ptr %10, align 8
  %32 = or disjoint i64 %12, 1
  %33 = getelementptr double, ptr %4, i64 %32
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %33, i64 128
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %33, i64 256
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %33, i64 384
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %7, i64 %32
  %42 = load double, ptr %41, align 8
  %43 = insertelement <4 x double> poison, double %34, i64 0
  %44 = insertelement <4 x double> %43, double %36, i64 1
  %45 = insertelement <4 x double> %44, double %38, i64 2
  %46 = insertelement <4 x double> %45, double %40, i64 3
  %47 = insertelement <4 x double> poison, double %42, i64 0
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = fmul <4 x double> %46, %48
  %50 = fadd <4 x double> %31, %49
  store <4 x double> %50, ptr %10, align 8
  %51 = add nuw nsw i64 %12, 2
  %exitcond.not.i.1 = icmp eq i64 %51, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %52 = getelementptr double, ptr %10, i64 4
  br label %53

53:                                               ; preds = %53, %.preheader.1.i
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %95, %53 ]
  %55 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %94, %53 ]
  %56 = getelementptr double, ptr %4, i64 %54
  %57 = getelementptr double, ptr %56, i64 512
  %58 = load double, ptr %57, align 8
  %59 = getelementptr double, ptr %56, i64 640
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %56, i64 768
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %56, i64 896
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %54
  %66 = load double, ptr %65, align 8
  %67 = insertelement <4 x double> poison, double %58, i64 0
  %68 = insertelement <4 x double> %67, double %60, i64 1
  %69 = insertelement <4 x double> %68, double %62, i64 2
  %70 = insertelement <4 x double> %69, double %64, i64 3
  %71 = insertelement <4 x double> poison, double %66, i64 0
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = fmul <4 x double> %70, %72
  %74 = fadd <4 x double> %55, %73
  store <4 x double> %74, ptr %52, align 8
  %75 = or disjoint i64 %54, 1
  %76 = getelementptr double, ptr %4, i64 %75
  %77 = getelementptr double, ptr %76, i64 512
  %78 = load double, ptr %77, align 8
  %79 = getelementptr double, ptr %76, i64 640
  %80 = load double, ptr %79, align 8
  %81 = getelementptr double, ptr %76, i64 768
  %82 = load double, ptr %81, align 8
  %83 = getelementptr double, ptr %76, i64 896
  %84 = load double, ptr %83, align 8
  %85 = getelementptr double, ptr %7, i64 %75
  %86 = load double, ptr %85, align 8
  %87 = insertelement <4 x double> poison, double %78, i64 0
  %88 = insertelement <4 x double> %87, double %80, i64 1
  %89 = insertelement <4 x double> %88, double %82, i64 2
  %90 = insertelement <4 x double> %89, double %84, i64 3
  %91 = insertelement <4 x double> poison, double %86, i64 0
  %92 = shufflevector <4 x double> %91, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = fmul <4 x double> %90, %92
  %94 = fadd <4 x double> %74, %93
  store <4 x double> %94, ptr %52, align 8
  %95 = add nuw nsw i64 %54, 2
  %exitcond.1.not.i.1 = icmp eq i64 %95, 128
  br i1 %exitcond.1.not.i.1, label %.preheader10.1.i, label %53

.preheader10.1.i:                                 ; preds = %53
  %96 = getelementptr double, ptr %10, i64 8
  br label %97

97:                                               ; preds = %97, %.preheader10.1.i
  %98 = phi i64 [ 0, %.preheader10.1.i ], [ %139, %97 ]
  %99 = phi <4 x double> [ zeroinitializer, %.preheader10.1.i ], [ %138, %97 ]
  %100 = getelementptr double, ptr %4, i64 %98
  %101 = getelementptr double, ptr %100, i64 1024
  %102 = load double, ptr %101, align 8
  %103 = getelementptr double, ptr %100, i64 1152
  %104 = load double, ptr %103, align 8
  %105 = getelementptr double, ptr %100, i64 1280
  %106 = load double, ptr %105, align 8
  %107 = getelementptr double, ptr %100, i64 1408
  %108 = load double, ptr %107, align 8
  %109 = getelementptr double, ptr %7, i64 %98
  %110 = load double, ptr %109, align 8
  %111 = insertelement <4 x double> poison, double %102, i64 0
  %112 = insertelement <4 x double> %111, double %104, i64 1
  %113 = insertelement <4 x double> %112, double %106, i64 2
  %114 = insertelement <4 x double> %113, double %108, i64 3
  %115 = insertelement <4 x double> poison, double %110, i64 0
  %116 = shufflevector <4 x double> %115, <4 x double> poison, <4 x i32> zeroinitializer
  %117 = fmul <4 x double> %114, %116
  %118 = fadd <4 x double> %99, %117
  store <4 x double> %118, ptr %96, align 8
  %119 = or disjoint i64 %98, 1
  %120 = getelementptr double, ptr %4, i64 %119
  %121 = getelementptr double, ptr %120, i64 1024
  %122 = load double, ptr %121, align 8
  %123 = getelementptr double, ptr %120, i64 1152
  %124 = load double, ptr %123, align 8
  %125 = getelementptr double, ptr %120, i64 1280
  %126 = load double, ptr %125, align 8
  %127 = getelementptr double, ptr %120, i64 1408
  %128 = load double, ptr %127, align 8
  %129 = getelementptr double, ptr %7, i64 %119
  %130 = load double, ptr %129, align 8
  %131 = insertelement <4 x double> poison, double %122, i64 0
  %132 = insertelement <4 x double> %131, double %124, i64 1
  %133 = insertelement <4 x double> %132, double %126, i64 2
  %134 = insertelement <4 x double> %133, double %128, i64 3
  %135 = insertelement <4 x double> poison, double %130, i64 0
  %136 = shufflevector <4 x double> %135, <4 x double> poison, <4 x i32> zeroinitializer
  %137 = fmul <4 x double> %134, %136
  %138 = fadd <4 x double> %118, %137
  store <4 x double> %138, ptr %96, align 8
  %139 = add nuw nsw i64 %98, 2
  %exitcond.117.not.i.1 = icmp eq i64 %139, 128
  br i1 %exitcond.117.not.i.1, label %.preheader.1.1.i, label %97

.preheader.1.1.i:                                 ; preds = %97
  %140 = getelementptr double, ptr %10, i64 12
  br label %141

141:                                              ; preds = %141, %.preheader.1.1.i
  %142 = phi i64 [ 0, %.preheader.1.1.i ], [ %183, %141 ]
  %143 = phi <4 x double> [ zeroinitializer, %.preheader.1.1.i ], [ %182, %141 ]
  %144 = getelementptr double, ptr %4, i64 %142
  %145 = getelementptr double, ptr %144, i64 1536
  %146 = load double, ptr %145, align 8
  %147 = getelementptr double, ptr %144, i64 1664
  %148 = load double, ptr %147, align 8
  %149 = getelementptr double, ptr %144, i64 1792
  %150 = load double, ptr %149, align 8
  %151 = getelementptr double, ptr %144, i64 1920
  %152 = load double, ptr %151, align 8
  %153 = getelementptr double, ptr %7, i64 %142
  %154 = load double, ptr %153, align 8
  %155 = insertelement <4 x double> poison, double %146, i64 0
  %156 = insertelement <4 x double> %155, double %148, i64 1
  %157 = insertelement <4 x double> %156, double %150, i64 2
  %158 = insertelement <4 x double> %157, double %152, i64 3
  %159 = insertelement <4 x double> poison, double %154, i64 0
  %160 = shufflevector <4 x double> %159, <4 x double> poison, <4 x i32> zeroinitializer
  %161 = fmul <4 x double> %158, %160
  %162 = fadd <4 x double> %143, %161
  store <4 x double> %162, ptr %140, align 8
  %163 = or disjoint i64 %142, 1
  %164 = getelementptr double, ptr %4, i64 %163
  %165 = getelementptr double, ptr %164, i64 1536
  %166 = load double, ptr %165, align 8
  %167 = getelementptr double, ptr %164, i64 1664
  %168 = load double, ptr %167, align 8
  %169 = getelementptr double, ptr %164, i64 1792
  %170 = load double, ptr %169, align 8
  %171 = getelementptr double, ptr %164, i64 1920
  %172 = load double, ptr %171, align 8
  %173 = getelementptr double, ptr %7, i64 %163
  %174 = load double, ptr %173, align 8
  %175 = insertelement <4 x double> poison, double %166, i64 0
  %176 = insertelement <4 x double> %175, double %168, i64 1
  %177 = insertelement <4 x double> %176, double %170, i64 2
  %178 = insertelement <4 x double> %177, double %172, i64 3
  %179 = insertelement <4 x double> poison, double %174, i64 0
  %180 = shufflevector <4 x double> %179, <4 x double> poison, <4 x i32> zeroinitializer
  %181 = fmul <4 x double> %178, %180
  %182 = fadd <4 x double> %162, %181
  store <4 x double> %182, ptr %140, align 8
  %183 = add nuw nsw i64 %142, 2
  %exitcond.1.1.not.i.1 = icmp eq i64 %183, 128
  br i1 %exitcond.1.1.not.i.1, label %kernel.exit, label %141

kernel.exit:                                      ; preds = %141
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28.i, i8 0, i64 128, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi i64 [ 0, %1 ], [ %50, %10 ]
  %12 = phi <4 x double> [ zeroinitializer, %1 ], [ %49, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 384
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %.unpack17.i, i64 %11
  %22 = load double, ptr %21, align 8
  %23 = insertelement <4 x double> poison, double %14, i64 0
  %24 = insertelement <4 x double> %23, double %16, i64 1
  %25 = insertelement <4 x double> %24, double %18, i64 2
  %26 = insertelement <4 x double> %25, double %20, i64 3
  %27 = insertelement <4 x double> poison, double %22, i64 0
  %28 = shufflevector <4 x double> %27, <4 x double> poison, <4 x i32> zeroinitializer
  %29 = fmul <4 x double> %26, %28
  %30 = fadd <4 x double> %12, %29
  store <4 x double> %30, ptr %.unpack28.i, align 8
  %31 = or disjoint i64 %11, 1
  %32 = getelementptr double, ptr %.unpack2.i, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %32, i64 128
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %32, i64 256
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %32, i64 384
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %.unpack17.i, i64 %31
  %41 = load double, ptr %40, align 8
  %42 = insertelement <4 x double> poison, double %33, i64 0
  %43 = insertelement <4 x double> %42, double %35, i64 1
  %44 = insertelement <4 x double> %43, double %37, i64 2
  %45 = insertelement <4 x double> %44, double %39, i64 3
  %46 = insertelement <4 x double> poison, double %41, i64 0
  %47 = shufflevector <4 x double> %46, <4 x double> poison, <4 x i32> zeroinitializer
  %48 = fmul <4 x double> %45, %47
  %49 = fadd <4 x double> %30, %48
  store <4 x double> %49, ptr %.unpack28.i, align 8
  %50 = add nuw nsw i64 %11, 2
  %exitcond.not.i.i.1 = icmp eq i64 %50, 128
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %10

.preheader.1.i.i:                                 ; preds = %10
  %51 = getelementptr double, ptr %.unpack28.i, i64 4
  br label %52

52:                                               ; preds = %52, %.preheader.1.i.i
  %53 = phi i64 [ 0, %.preheader.1.i.i ], [ %94, %52 ]
  %54 = phi <4 x double> [ zeroinitializer, %.preheader.1.i.i ], [ %93, %52 ]
  %55 = getelementptr double, ptr %.unpack2.i, i64 %53
  %56 = getelementptr double, ptr %55, i64 512
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %55, i64 640
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %55, i64 768
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %55, i64 896
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %.unpack17.i, i64 %53
  %65 = load double, ptr %64, align 8
  %66 = insertelement <4 x double> poison, double %57, i64 0
  %67 = insertelement <4 x double> %66, double %59, i64 1
  %68 = insertelement <4 x double> %67, double %61, i64 2
  %69 = insertelement <4 x double> %68, double %63, i64 3
  %70 = insertelement <4 x double> poison, double %65, i64 0
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = fmul <4 x double> %69, %71
  %73 = fadd <4 x double> %54, %72
  store <4 x double> %73, ptr %51, align 8
  %74 = or disjoint i64 %53, 1
  %75 = getelementptr double, ptr %.unpack2.i, i64 %74
  %76 = getelementptr double, ptr %75, i64 512
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %75, i64 640
  %79 = load double, ptr %78, align 8
  %80 = getelementptr double, ptr %75, i64 768
  %81 = load double, ptr %80, align 8
  %82 = getelementptr double, ptr %75, i64 896
  %83 = load double, ptr %82, align 8
  %84 = getelementptr double, ptr %.unpack17.i, i64 %74
  %85 = load double, ptr %84, align 8
  %86 = insertelement <4 x double> poison, double %77, i64 0
  %87 = insertelement <4 x double> %86, double %79, i64 1
  %88 = insertelement <4 x double> %87, double %81, i64 2
  %89 = insertelement <4 x double> %88, double %83, i64 3
  %90 = insertelement <4 x double> poison, double %85, i64 0
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = fmul <4 x double> %89, %91
  %93 = fadd <4 x double> %73, %92
  store <4 x double> %93, ptr %51, align 8
  %94 = add nuw nsw i64 %53, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %94, 128
  br i1 %exitcond.1.not.i.i.1, label %.preheader10.1.i.i, label %52

.preheader10.1.i.i:                               ; preds = %52
  %95 = getelementptr double, ptr %.unpack28.i, i64 8
  br label %96

96:                                               ; preds = %96, %.preheader10.1.i.i
  %97 = phi i64 [ 0, %.preheader10.1.i.i ], [ %138, %96 ]
  %98 = phi <4 x double> [ zeroinitializer, %.preheader10.1.i.i ], [ %137, %96 ]
  %99 = getelementptr double, ptr %.unpack2.i, i64 %97
  %100 = getelementptr double, ptr %99, i64 1024
  %101 = load double, ptr %100, align 8
  %102 = getelementptr double, ptr %99, i64 1152
  %103 = load double, ptr %102, align 8
  %104 = getelementptr double, ptr %99, i64 1280
  %105 = load double, ptr %104, align 8
  %106 = getelementptr double, ptr %99, i64 1408
  %107 = load double, ptr %106, align 8
  %108 = getelementptr double, ptr %.unpack17.i, i64 %97
  %109 = load double, ptr %108, align 8
  %110 = insertelement <4 x double> poison, double %101, i64 0
  %111 = insertelement <4 x double> %110, double %103, i64 1
  %112 = insertelement <4 x double> %111, double %105, i64 2
  %113 = insertelement <4 x double> %112, double %107, i64 3
  %114 = insertelement <4 x double> poison, double %109, i64 0
  %115 = shufflevector <4 x double> %114, <4 x double> poison, <4 x i32> zeroinitializer
  %116 = fmul <4 x double> %113, %115
  %117 = fadd <4 x double> %98, %116
  store <4 x double> %117, ptr %95, align 8
  %118 = or disjoint i64 %97, 1
  %119 = getelementptr double, ptr %.unpack2.i, i64 %118
  %120 = getelementptr double, ptr %119, i64 1024
  %121 = load double, ptr %120, align 8
  %122 = getelementptr double, ptr %119, i64 1152
  %123 = load double, ptr %122, align 8
  %124 = getelementptr double, ptr %119, i64 1280
  %125 = load double, ptr %124, align 8
  %126 = getelementptr double, ptr %119, i64 1408
  %127 = load double, ptr %126, align 8
  %128 = getelementptr double, ptr %.unpack17.i, i64 %118
  %129 = load double, ptr %128, align 8
  %130 = insertelement <4 x double> poison, double %121, i64 0
  %131 = insertelement <4 x double> %130, double %123, i64 1
  %132 = insertelement <4 x double> %131, double %125, i64 2
  %133 = insertelement <4 x double> %132, double %127, i64 3
  %134 = insertelement <4 x double> poison, double %129, i64 0
  %135 = shufflevector <4 x double> %134, <4 x double> poison, <4 x i32> zeroinitializer
  %136 = fmul <4 x double> %133, %135
  %137 = fadd <4 x double> %117, %136
  store <4 x double> %137, ptr %95, align 8
  %138 = add nuw nsw i64 %97, 2
  %exitcond.117.not.i.i.1 = icmp eq i64 %138, 128
  br i1 %exitcond.117.not.i.i.1, label %.preheader.1.1.i.i, label %96

.preheader.1.1.i.i:                               ; preds = %96
  %139 = getelementptr double, ptr %.unpack28.i, i64 12
  br label %140

140:                                              ; preds = %140, %.preheader.1.1.i.i
  %141 = phi i64 [ 0, %.preheader.1.1.i.i ], [ %182, %140 ]
  %142 = phi <4 x double> [ zeroinitializer, %.preheader.1.1.i.i ], [ %181, %140 ]
  %143 = getelementptr double, ptr %.unpack2.i, i64 %141
  %144 = getelementptr double, ptr %143, i64 1536
  %145 = load double, ptr %144, align 8
  %146 = getelementptr double, ptr %143, i64 1664
  %147 = load double, ptr %146, align 8
  %148 = getelementptr double, ptr %143, i64 1792
  %149 = load double, ptr %148, align 8
  %150 = getelementptr double, ptr %143, i64 1920
  %151 = load double, ptr %150, align 8
  %152 = getelementptr double, ptr %.unpack17.i, i64 %141
  %153 = load double, ptr %152, align 8
  %154 = insertelement <4 x double> poison, double %145, i64 0
  %155 = insertelement <4 x double> %154, double %147, i64 1
  %156 = insertelement <4 x double> %155, double %149, i64 2
  %157 = insertelement <4 x double> %156, double %151, i64 3
  %158 = insertelement <4 x double> poison, double %153, i64 0
  %159 = shufflevector <4 x double> %158, <4 x double> poison, <4 x i32> zeroinitializer
  %160 = fmul <4 x double> %157, %159
  %161 = fadd <4 x double> %142, %160
  store <4 x double> %161, ptr %139, align 8
  %162 = or disjoint i64 %141, 1
  %163 = getelementptr double, ptr %.unpack2.i, i64 %162
  %164 = getelementptr double, ptr %163, i64 1536
  %165 = load double, ptr %164, align 8
  %166 = getelementptr double, ptr %163, i64 1664
  %167 = load double, ptr %166, align 8
  %168 = getelementptr double, ptr %163, i64 1792
  %169 = load double, ptr %168, align 8
  %170 = getelementptr double, ptr %163, i64 1920
  %171 = load double, ptr %170, align 8
  %172 = getelementptr double, ptr %.unpack17.i, i64 %162
  %173 = load double, ptr %172, align 8
  %174 = insertelement <4 x double> poison, double %165, i64 0
  %175 = insertelement <4 x double> %174, double %167, i64 1
  %176 = insertelement <4 x double> %175, double %169, i64 2
  %177 = insertelement <4 x double> %176, double %171, i64 3
  %178 = insertelement <4 x double> poison, double %173, i64 0
  %179 = shufflevector <4 x double> %178, <4 x double> poison, <4 x i32> zeroinitializer
  %180 = fmul <4 x double> %177, %179
  %181 = fadd <4 x double> %161, %180
  store <4 x double> %181, ptr %139, align 8
  %182 = add nuw nsw i64 %141, 2
  %exitcond.1.1.not.i.i.1 = icmp eq i64 %182, 128
  br i1 %exitcond.1.1.not.i.i.1, label %_mlir_ciface_kernel.exit, label %140

_mlir_ciface_kernel.exit:                         ; preds = %140
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
