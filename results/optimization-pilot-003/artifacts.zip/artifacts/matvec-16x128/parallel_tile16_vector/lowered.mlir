module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %22 = llvm.mlir.constant(128 : index) : i64
    %23 = llvm.mlir.constant(4 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.constant(16 : index) : i64
    %26 = llvm.mlir.constant(0 : index) : i64
    %27 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%26 : i64)
  ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb2
    %29 = llvm.icmp "slt" %28, %25 : i64
    llvm.cond_br %29, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %30 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %31 = llvm.getelementptr %30[%28] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %27, %31 : f64, !llvm.ptr
    %32 = llvm.add %28, %24  : i64
    llvm.br ^bb1(%32 : i64)
  ^bb3:  // pred: ^bb1
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.alloca %33 x !llvm.array<4 x vector<1xf64>> : (i64) -> !llvm.ptr
    %35 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %36 = llvm.insertvalue %34, %35[0] : !llvm.struct<(ptr, ptr, i64)> 
    %37 = llvm.insertvalue %34, %36[1] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.mlir.constant(0 : index) : i64
    %39 = llvm.insertvalue %38, %37[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%26 : i64)
  ^bb4(%40: i64):  // 2 preds: ^bb3, ^bb11
    %41 = llvm.icmp "slt" %40, %25 : i64
    llvm.cond_br %41, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    llvm.br ^bb6(%26 : i64)
  ^bb6(%42: i64):  // 2 preds: ^bb5, ^bb10
    %43 = llvm.icmp "slt" %42, %22 : i64
    llvm.cond_br %43, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %44 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %45 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %46 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %47 = llvm.insertvalue %44, %46[0] : !llvm.struct<(ptr, ptr, i64)> 
    %48 = llvm.insertvalue %45, %47[1] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.mlir.constant(0 : index) : i64
    %50 = llvm.insertvalue %49, %48[2] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %52 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %54 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %55 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %56 = llvm.mul %40, %22  : i64
    %57 = llvm.add %56, %42  : i64
    %58 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %59 = llvm.insertvalue %44, %58[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %60 = llvm.insertvalue %45, %59[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %61 = llvm.insertvalue %57, %60[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %62 = llvm.mlir.constant(4 : index) : i64
    %63 = llvm.insertvalue %62, %61[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %64 = llvm.mlir.constant(128 : index) : i64
    %65 = llvm.insertvalue %64, %63[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %66 = llvm.mlir.constant(1 : index) : i64
    %67 = llvm.insertvalue %66, %65[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %68 = llvm.mlir.constant(1 : index) : i64
    %69 = llvm.insertvalue %68, %67[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %70 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %71 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %72 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %73 = llvm.insertvalue %70, %72[0] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.insertvalue %71, %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %75 = llvm.mlir.constant(0 : index) : i64
    %76 = llvm.insertvalue %75, %74[2] : !llvm.struct<(ptr, ptr, i64)> 
    %77 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %78 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %79 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %80 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %81 = llvm.insertvalue %70, %80[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %82 = llvm.insertvalue %71, %81[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %83 = llvm.insertvalue %42, %82[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %84 = llvm.mlir.constant(1 : index) : i64
    %85 = llvm.insertvalue %84, %83[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %86 = llvm.mlir.constant(1 : index) : i64
    %87 = llvm.insertvalue %86, %85[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %91 = llvm.insertvalue %88, %90[0] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.insertvalue %89, %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.mlir.constant(0 : index) : i64
    %94 = llvm.insertvalue %93, %92[2] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %99 = llvm.insertvalue %88, %98[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %89, %99[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %40, %100[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.mlir.constant(4 : index) : i64
    %103 = llvm.insertvalue %102, %101[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %104 = llvm.mlir.constant(1 : index) : i64
    %105 = llvm.insertvalue %104, %103[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %107 = llvm.extractvalue %39[0] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.insertvalue %107, %106[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.extractvalue %39[1] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.insertvalue %109, %108[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.mlir.constant(0 : index) : i64
    %112 = llvm.insertvalue %111, %110[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %113 = llvm.mlir.constant(4 : index) : i64
    %114 = llvm.insertvalue %113, %112[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.mlir.constant(1 : index) : i64
    %116 = llvm.insertvalue %115, %114[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%26 : i64)
  ^bb8(%117: i64):  // 2 preds: ^bb7, ^bb9
    %118 = llvm.icmp "slt" %117, %23 : i64
    llvm.cond_br %118, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %119 = llvm.getelementptr %45[%57] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %120 = llvm.mlir.constant(128 : index) : i64
    %121 = llvm.mul %117, %120  : i64
    %122 = llvm.add %121, %26  : i64
    %123 = llvm.getelementptr %119[%122] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %124 = llvm.load %123 : !llvm.ptr -> f64
    %125 = llvm.mlir.undef : vector<1xf64>
    %126 = llvm.mlir.constant(0 : i32) : i32
    %127 = llvm.insertelement %124, %125[%126 : i32] : vector<1xf64>
    %128 = llvm.shufflevector %127, %125 [0] : vector<1xf64> 
    %129 = llvm.getelementptr %109[%117] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %128, %129 : vector<1xf64>, !llvm.ptr
    %130 = llvm.add %117, %24  : i64
    llvm.br ^bb8(%130 : i64)
  ^bb10:  // pred: ^bb8
    %131 = llvm.load %34 : !llvm.ptr -> !llvm.array<4 x vector<1xf64>>
    %132 = llvm.getelementptr %71[%42] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %133 = llvm.getelementptr %132[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %134 = llvm.load %133 : !llvm.ptr -> f64
    %135 = llvm.mlir.undef : vector<1xf64>
    %136 = llvm.mlir.constant(0 : i32) : i32
    %137 = llvm.insertelement %134, %135[%136 : i32] : vector<1xf64>
    %138 = llvm.shufflevector %137, %135 [0] : vector<1xf64> 
    %139 = llvm.insertvalue %138, %21[0] : !llvm.array<4 x vector<1xf64>> 
    %140 = llvm.insertvalue %138, %139[1] : !llvm.array<4 x vector<1xf64>> 
    %141 = llvm.insertvalue %138, %140[2] : !llvm.array<4 x vector<1xf64>> 
    %142 = llvm.insertvalue %138, %141[3] : !llvm.array<4 x vector<1xf64>> 
    %143 = llvm.extractvalue %105[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.extractvalue %105[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %145 = llvm.getelementptr %143[%144] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %146 = llvm.getelementptr %145[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %147 = llvm.load %146 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %148 = llvm.mlir.undef : !llvm.array<4 x vector<1xf64>>
    %149 = llvm.extractvalue %131[0] : !llvm.array<4 x vector<1xf64>> 
    %150 = llvm.fmul %149, %138  : vector<1xf64>
    %151 = llvm.insertvalue %150, %148[0] : !llvm.array<4 x vector<1xf64>> 
    %152 = llvm.extractvalue %131[1] : !llvm.array<4 x vector<1xf64>> 
    %153 = llvm.fmul %152, %138  : vector<1xf64>
    %154 = llvm.insertvalue %153, %151[1] : !llvm.array<4 x vector<1xf64>> 
    %155 = llvm.extractvalue %131[2] : !llvm.array<4 x vector<1xf64>> 
    %156 = llvm.fmul %155, %138  : vector<1xf64>
    %157 = llvm.insertvalue %156, %154[2] : !llvm.array<4 x vector<1xf64>> 
    %158 = llvm.extractvalue %131[3] : !llvm.array<4 x vector<1xf64>> 
    %159 = llvm.fmul %158, %138  : vector<1xf64>
    %160 = llvm.insertvalue %159, %157[3] : !llvm.array<4 x vector<1xf64>> 
    %161 = llvm.extractvalue %160[0] : !llvm.array<4 x vector<1xf64>> 
    %162 = llvm.mlir.constant(0 : i64) : i64
    %163 = llvm.extractelement %161[%162 : i64] : vector<1xf64>
    %164 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<4xf64>> 
    %165 = llvm.mlir.constant(0 : i64) : i64
    %166 = llvm.insertelement %163, %164[%165 : i64] : vector<4xf64>
    %167 = llvm.insertvalue %166, %20[0] : !llvm.array<1 x vector<4xf64>> 
    %168 = llvm.extractvalue %160[1] : !llvm.array<4 x vector<1xf64>> 
    %169 = llvm.mlir.constant(0 : i64) : i64
    %170 = llvm.extractelement %168[%169 : i64] : vector<1xf64>
    %171 = llvm.mlir.constant(1 : i64) : i64
    %172 = llvm.insertelement %170, %166[%171 : i64] : vector<4xf64>
    %173 = llvm.insertvalue %172, %167[0] : !llvm.array<1 x vector<4xf64>> 
    %174 = llvm.extractvalue %160[2] : !llvm.array<4 x vector<1xf64>> 
    %175 = llvm.mlir.constant(0 : i64) : i64
    %176 = llvm.extractelement %174[%175 : i64] : vector<1xf64>
    %177 = llvm.mlir.constant(2 : i64) : i64
    %178 = llvm.insertelement %176, %172[%177 : i64] : vector<4xf64>
    %179 = llvm.insertvalue %178, %173[0] : !llvm.array<1 x vector<4xf64>> 
    %180 = llvm.extractvalue %160[3] : !llvm.array<4 x vector<1xf64>> 
    %181 = llvm.mlir.constant(0 : i64) : i64
    %182 = llvm.extractelement %180[%181 : i64] : vector<1xf64>
    %183 = llvm.mlir.constant(3 : i64) : i64
    %184 = llvm.insertelement %182, %178[%183 : i64] : vector<4xf64>
    %185 = llvm.insertvalue %184, %179[0] : !llvm.array<1 x vector<4xf64>> 
    %186 = llvm.fadd %184, %147  : vector<4xf64>
    %187 = llvm.extractvalue %105[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %188 = llvm.extractvalue %105[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %189 = llvm.getelementptr %187[%188] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %190 = llvm.getelementptr %189[%26] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %186, %190 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %191 = llvm.add %42, %24  : i64
    llvm.br ^bb6(%191 : i64)
  ^bb11:  // pred: ^bb6
    %192 = llvm.add %40, %23  : i64
    llvm.br ^bb4(%192 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
