; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %13, i8 0, i64 512, i1 false)
  br label %.preheader10

.preheader10:                                     ; preds = %17, %102
  %18 = phi i64 [ 0, %17 ], [ %103, %102 ]
  %19 = getelementptr double, ptr %13, i64 %18
  %20 = shl nuw nsw i64 %18, 7
  %.promoted = load <4 x double>, ptr %19, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %20
  br label %21

21:                                               ; preds = %21, %.preheader10
  %22 = phi i64 [ 0, %.preheader10 ], [ %59, %21 ]
  %23 = phi <4 x double> [ %.promoted, %.preheader10 ], [ %58, %21 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %22
  %24 = load double, ptr %gep, align 8
  %25 = getelementptr double, ptr %gep, i64 128
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep, i64 256
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep, i64 384
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %8, i64 %22
  %32 = load double, ptr %31, align 8
  %33 = insertelement <4 x double> poison, double %24, i64 0
  %34 = insertelement <4 x double> %33, double %26, i64 1
  %35 = insertelement <4 x double> %34, double %28, i64 2
  %36 = insertelement <4 x double> %35, double %30, i64 3
  %37 = insertelement <4 x double> poison, double %32, i64 0
  %38 = shufflevector <4 x double> %37, <4 x double> poison, <4 x i32> zeroinitializer
  %39 = fmul <4 x double> %36, %38
  %40 = fadd <4 x double> %23, %39
  store <4 x double> %40, ptr %19, align 8
  %41 = or disjoint i64 %22, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %41
  %42 = load double, ptr %gep.1, align 8
  %43 = getelementptr double, ptr %gep.1, i64 128
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %gep.1, i64 256
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %gep.1, i64 384
  %48 = load double, ptr %47, align 8
  %49 = getelementptr double, ptr %8, i64 %41
  %50 = load double, ptr %49, align 8
  %51 = insertelement <4 x double> poison, double %42, i64 0
  %52 = insertelement <4 x double> %51, double %44, i64 1
  %53 = insertelement <4 x double> %52, double %46, i64 2
  %54 = insertelement <4 x double> %53, double %48, i64 3
  %55 = insertelement <4 x double> poison, double %50, i64 0
  %56 = shufflevector <4 x double> %55, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = fmul <4 x double> %54, %56
  %58 = fadd <4 x double> %40, %57
  store <4 x double> %58, ptr %19, align 8
  %59 = add nuw nsw i64 %22, 2
  %exitcond.not.1 = icmp eq i64 %59, 128
  br i1 %exitcond.not.1, label %.preheader.1, label %21

.preheader.1:                                     ; preds = %21
  %60 = shl i64 %18, 7
  %61 = or disjoint i64 %60, 512
  %62 = getelementptr double, ptr %19, i64 4
  %.promoted.1 = load <4 x double>, ptr %62, align 8
  %invariant.gep11 = getelementptr double, ptr %1, i64 %61
  br label %63

63:                                               ; preds = %63, %.preheader.1
  %64 = phi i64 [ 0, %.preheader.1 ], [ %101, %63 ]
  %65 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %100, %63 ]
  %gep12 = getelementptr double, ptr %invariant.gep11, i64 %64
  %66 = load double, ptr %gep12, align 8
  %67 = getelementptr double, ptr %gep12, i64 128
  %68 = load double, ptr %67, align 8
  %69 = getelementptr double, ptr %gep12, i64 256
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %gep12, i64 384
  %72 = load double, ptr %71, align 8
  %73 = getelementptr double, ptr %8, i64 %64
  %74 = load double, ptr %73, align 8
  %75 = insertelement <4 x double> poison, double %66, i64 0
  %76 = insertelement <4 x double> %75, double %68, i64 1
  %77 = insertelement <4 x double> %76, double %70, i64 2
  %78 = insertelement <4 x double> %77, double %72, i64 3
  %79 = insertelement <4 x double> poison, double %74, i64 0
  %80 = shufflevector <4 x double> %79, <4 x double> poison, <4 x i32> zeroinitializer
  %81 = fmul <4 x double> %78, %80
  %82 = fadd <4 x double> %65, %81
  store <4 x double> %82, ptr %62, align 8
  %83 = or disjoint i64 %64, 1
  %gep12.1 = getelementptr double, ptr %invariant.gep11, i64 %83
  %84 = load double, ptr %gep12.1, align 8
  %85 = getelementptr double, ptr %gep12.1, i64 128
  %86 = load double, ptr %85, align 8
  %87 = getelementptr double, ptr %gep12.1, i64 256
  %88 = load double, ptr %87, align 8
  %89 = getelementptr double, ptr %gep12.1, i64 384
  %90 = load double, ptr %89, align 8
  %91 = getelementptr double, ptr %8, i64 %83
  %92 = load double, ptr %91, align 8
  %93 = insertelement <4 x double> poison, double %84, i64 0
  %94 = insertelement <4 x double> %93, double %86, i64 1
  %95 = insertelement <4 x double> %94, double %88, i64 2
  %96 = insertelement <4 x double> %95, double %90, i64 3
  %97 = insertelement <4 x double> poison, double %92, i64 0
  %98 = shufflevector <4 x double> %97, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = fmul <4 x double> %96, %98
  %100 = fadd <4 x double> %82, %99
  store <4 x double> %100, ptr %62, align 8
  %101 = add nuw nsw i64 %64, 2
  %exitcond.1.not.1 = icmp eq i64 %101, 128
  br i1 %exitcond.1.not.1, label %102, label %63

102:                                              ; preds = %63
  %103 = add nuw nsw i64 %18, 8
  %104 = icmp ult i64 %18, 56
  br i1 %104, label %.preheader10, label %105

105:                                              ; preds = %102
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %.unpack28, i8 0, i64 512, i1 false)
  br label %.preheader10.i

.preheader10.i:                                   ; preds = %87, %3
  %4 = phi i64 [ 0, %3 ], [ %88, %87 ]
  %5 = getelementptr double, ptr %.unpack28, i64 %4
  %6 = shl nuw nsw i64 %4, 7
  %.promoted.i = load <4 x double>, ptr %5, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %7

7:                                                ; preds = %7, %.preheader10.i
  %8 = phi i64 [ 0, %.preheader10.i ], [ %45, %7 ]
  %9 = phi <4 x double> [ %.promoted.i, %.preheader10.i ], [ %44, %7 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %8
  %10 = load double, ptr %gep.i, align 8
  %11 = getelementptr double, ptr %gep.i, i64 128
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %gep.i, i64 256
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %gep.i, i64 384
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %.unpack17, i64 %8
  %18 = load double, ptr %17, align 8
  %19 = insertelement <4 x double> poison, double %10, i64 0
  %20 = insertelement <4 x double> %19, double %12, i64 1
  %21 = insertelement <4 x double> %20, double %14, i64 2
  %22 = insertelement <4 x double> %21, double %16, i64 3
  %23 = insertelement <4 x double> poison, double %18, i64 0
  %24 = shufflevector <4 x double> %23, <4 x double> poison, <4 x i32> zeroinitializer
  %25 = fmul <4 x double> %22, %24
  %26 = fadd <4 x double> %9, %25
  store <4 x double> %26, ptr %5, align 8
  %27 = or disjoint i64 %8, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %27
  %28 = load double, ptr %gep.i.1, align 8
  %29 = getelementptr double, ptr %gep.i.1, i64 128
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i.1, i64 256
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %gep.i.1, i64 384
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %.unpack17, i64 %27
  %36 = load double, ptr %35, align 8
  %37 = insertelement <4 x double> poison, double %28, i64 0
  %38 = insertelement <4 x double> %37, double %30, i64 1
  %39 = insertelement <4 x double> %38, double %32, i64 2
  %40 = insertelement <4 x double> %39, double %34, i64 3
  %41 = insertelement <4 x double> poison, double %36, i64 0
  %42 = shufflevector <4 x double> %41, <4 x double> poison, <4 x i32> zeroinitializer
  %43 = fmul <4 x double> %40, %42
  %44 = fadd <4 x double> %26, %43
  store <4 x double> %44, ptr %5, align 8
  %45 = add nuw nsw i64 %8, 2
  %exitcond.not.i.1 = icmp eq i64 %45, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %7

.preheader.1.i:                                   ; preds = %7
  %46 = or disjoint i64 %6, 512
  %47 = getelementptr double, ptr %5, i64 4
  %.promoted.1.i = load <4 x double>, ptr %47, align 8
  %invariant.gep11.i = getelementptr double, ptr %.unpack2, i64 %46
  br label %48

48:                                               ; preds = %48, %.preheader.1.i
  %49 = phi i64 [ 0, %.preheader.1.i ], [ %86, %48 ]
  %50 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %85, %48 ]
  %gep12.i = getelementptr double, ptr %invariant.gep11.i, i64 %49
  %51 = load double, ptr %gep12.i, align 8
  %52 = getelementptr double, ptr %gep12.i, i64 128
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %gep12.i, i64 256
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %gep12.i, i64 384
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %49
  %59 = load double, ptr %58, align 8
  %60 = insertelement <4 x double> poison, double %51, i64 0
  %61 = insertelement <4 x double> %60, double %53, i64 1
  %62 = insertelement <4 x double> %61, double %55, i64 2
  %63 = insertelement <4 x double> %62, double %57, i64 3
  %64 = insertelement <4 x double> poison, double %59, i64 0
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = fmul <4 x double> %63, %65
  %67 = fadd <4 x double> %50, %66
  store <4 x double> %67, ptr %47, align 8
  %68 = or disjoint i64 %49, 1
  %gep12.i.1 = getelementptr double, ptr %invariant.gep11.i, i64 %68
  %69 = load double, ptr %gep12.i.1, align 8
  %70 = getelementptr double, ptr %gep12.i.1, i64 128
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %gep12.i.1, i64 256
  %73 = load double, ptr %72, align 8
  %74 = getelementptr double, ptr %gep12.i.1, i64 384
  %75 = load double, ptr %74, align 8
  %76 = getelementptr double, ptr %.unpack17, i64 %68
  %77 = load double, ptr %76, align 8
  %78 = insertelement <4 x double> poison, double %69, i64 0
  %79 = insertelement <4 x double> %78, double %71, i64 1
  %80 = insertelement <4 x double> %79, double %73, i64 2
  %81 = insertelement <4 x double> %80, double %75, i64 3
  %82 = insertelement <4 x double> poison, double %77, i64 0
  %83 = shufflevector <4 x double> %82, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = fmul <4 x double> %81, %83
  %85 = fadd <4 x double> %67, %84
  store <4 x double> %85, ptr %47, align 8
  %86 = add nuw nsw i64 %49, 2
  %exitcond.1.not.i.1 = icmp eq i64 %86, 128
  br i1 %exitcond.1.not.i.1, label %87, label %48

87:                                               ; preds = %48
  %88 = add nuw nsw i64 %4, 8
  %89 = icmp ult i64 %4, 56
  br i1 %89, label %.preheader10.i, label %kernel.exit

kernel.exit:                                      ; preds = %87
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %10, i8 0, i64 512, i1 false)
  br label %.preheader10.i

.preheader10.i:                                   ; preds = %94, %1
  %11 = phi i64 [ 0, %1 ], [ %95, %94 ]
  %12 = getelementptr double, ptr %10, i64 %11
  %13 = shl nuw nsw i64 %11, 7
  %.promoted.i = load <4 x double>, ptr %12, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %13
  br label %14

14:                                               ; preds = %14, %.preheader10.i
  %15 = phi i64 [ 0, %.preheader10.i ], [ %52, %14 ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader10.i ], [ %51, %14 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %17 = load double, ptr %gep.i, align 8
  %18 = getelementptr double, ptr %gep.i, i64 128
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 256
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 384
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %7, i64 %15
  %25 = load double, ptr %24, align 8
  %26 = insertelement <4 x double> poison, double %17, i64 0
  %27 = insertelement <4 x double> %26, double %19, i64 1
  %28 = insertelement <4 x double> %27, double %21, i64 2
  %29 = insertelement <4 x double> %28, double %23, i64 3
  %30 = insertelement <4 x double> poison, double %25, i64 0
  %31 = shufflevector <4 x double> %30, <4 x double> poison, <4 x i32> zeroinitializer
  %32 = fmul <4 x double> %29, %31
  %33 = fadd <4 x double> %16, %32
  store <4 x double> %33, ptr %12, align 8
  %34 = or disjoint i64 %15, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %34
  %35 = load double, ptr %gep.i.1, align 8
  %36 = getelementptr double, ptr %gep.i.1, i64 128
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep.i.1, i64 256
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep.i.1, i64 384
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %7, i64 %34
  %43 = load double, ptr %42, align 8
  %44 = insertelement <4 x double> poison, double %35, i64 0
  %45 = insertelement <4 x double> %44, double %37, i64 1
  %46 = insertelement <4 x double> %45, double %39, i64 2
  %47 = insertelement <4 x double> %46, double %41, i64 3
  %48 = insertelement <4 x double> poison, double %43, i64 0
  %49 = shufflevector <4 x double> %48, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = fmul <4 x double> %47, %49
  %51 = fadd <4 x double> %33, %50
  store <4 x double> %51, ptr %12, align 8
  %52 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %52, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %14

.preheader.1.i:                                   ; preds = %14
  %53 = or disjoint i64 %13, 512
  %54 = getelementptr double, ptr %12, i64 4
  %.promoted.1.i = load <4 x double>, ptr %54, align 8
  %invariant.gep11.i = getelementptr double, ptr %4, i64 %53
  br label %55

55:                                               ; preds = %55, %.preheader.1.i
  %56 = phi i64 [ 0, %.preheader.1.i ], [ %93, %55 ]
  %57 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %92, %55 ]
  %gep12.i = getelementptr double, ptr %invariant.gep11.i, i64 %56
  %58 = load double, ptr %gep12.i, align 8
  %59 = getelementptr double, ptr %gep12.i, i64 128
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %gep12.i, i64 256
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %gep12.i, i64 384
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %56
  %66 = load double, ptr %65, align 8
  %67 = insertelement <4 x double> poison, double %58, i64 0
  %68 = insertelement <4 x double> %67, double %60, i64 1
  %69 = insertelement <4 x double> %68, double %62, i64 2
  %70 = insertelement <4 x double> %69, double %64, i64 3
  %71 = insertelement <4 x double> poison, double %66, i64 0
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = fmul <4 x double> %70, %72
  %74 = fadd <4 x double> %57, %73
  store <4 x double> %74, ptr %54, align 8
  %75 = or disjoint i64 %56, 1
  %gep12.i.1 = getelementptr double, ptr %invariant.gep11.i, i64 %75
  %76 = load double, ptr %gep12.i.1, align 8
  %77 = getelementptr double, ptr %gep12.i.1, i64 128
  %78 = load double, ptr %77, align 8
  %79 = getelementptr double, ptr %gep12.i.1, i64 256
  %80 = load double, ptr %79, align 8
  %81 = getelementptr double, ptr %gep12.i.1, i64 384
  %82 = load double, ptr %81, align 8
  %83 = getelementptr double, ptr %7, i64 %75
  %84 = load double, ptr %83, align 8
  %85 = insertelement <4 x double> poison, double %76, i64 0
  %86 = insertelement <4 x double> %85, double %78, i64 1
  %87 = insertelement <4 x double> %86, double %80, i64 2
  %88 = insertelement <4 x double> %87, double %82, i64 3
  %89 = insertelement <4 x double> poison, double %84, i64 0
  %90 = shufflevector <4 x double> %89, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = fmul <4 x double> %88, %90
  %92 = fadd <4 x double> %74, %91
  store <4 x double> %92, ptr %54, align 8
  %93 = add nuw nsw i64 %56, 2
  %exitcond.1.not.i.1 = icmp eq i64 %93, 128
  br i1 %exitcond.1.not.i.1, label %94, label %55

94:                                               ; preds = %55
  %95 = add nuw nsw i64 %11, 8
  %96 = icmp ult i64 %11, 56
  br i1 %96, label %.preheader10.i, label %kernel.exit

kernel.exit:                                      ; preds = %94
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(512) %.unpack28.i, i8 0, i64 512, i1 false)
  br label %.preheader10.i.i

.preheader10.i.i:                                 ; preds = %93, %1
  %10 = phi i64 [ 0, %1 ], [ %94, %93 ]
  %11 = getelementptr double, ptr %.unpack28.i, i64 %10
  %12 = shl nuw nsw i64 %10, 7
  %.promoted.i.i = load <4 x double>, ptr %11, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %13

13:                                               ; preds = %13, %.preheader10.i.i
  %14 = phi i64 [ 0, %.preheader10.i.i ], [ %51, %13 ]
  %15 = phi <4 x double> [ %.promoted.i.i, %.preheader10.i.i ], [ %50, %13 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %14
  %16 = load double, ptr %gep.i.i, align 8
  %17 = getelementptr double, ptr %gep.i.i, i64 128
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i.i, i64 256
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i.i, i64 384
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17.i, i64 %14
  %24 = load double, ptr %23, align 8
  %25 = insertelement <4 x double> poison, double %16, i64 0
  %26 = insertelement <4 x double> %25, double %18, i64 1
  %27 = insertelement <4 x double> %26, double %20, i64 2
  %28 = insertelement <4 x double> %27, double %22, i64 3
  %29 = insertelement <4 x double> poison, double %24, i64 0
  %30 = shufflevector <4 x double> %29, <4 x double> poison, <4 x i32> zeroinitializer
  %31 = fmul <4 x double> %28, %30
  %32 = fadd <4 x double> %15, %31
  store <4 x double> %32, ptr %11, align 8
  %33 = or disjoint i64 %14, 1
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %33
  %34 = load double, ptr %gep.i.i.1, align 8
  %35 = getelementptr double, ptr %gep.i.i.1, i64 128
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %gep.i.i.1, i64 256
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %gep.i.i.1, i64 384
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %.unpack17.i, i64 %33
  %42 = load double, ptr %41, align 8
  %43 = insertelement <4 x double> poison, double %34, i64 0
  %44 = insertelement <4 x double> %43, double %36, i64 1
  %45 = insertelement <4 x double> %44, double %38, i64 2
  %46 = insertelement <4 x double> %45, double %40, i64 3
  %47 = insertelement <4 x double> poison, double %42, i64 0
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = fmul <4 x double> %46, %48
  %50 = fadd <4 x double> %32, %49
  store <4 x double> %50, ptr %11, align 8
  %51 = add nuw nsw i64 %14, 2
  %exitcond.not.i.i.1 = icmp eq i64 %51, 128
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %13

.preheader.1.i.i:                                 ; preds = %13
  %52 = or disjoint i64 %12, 512
  %53 = getelementptr double, ptr %11, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %53, align 8
  %invariant.gep11.i.i = getelementptr double, ptr %.unpack2.i, i64 %52
  br label %54

54:                                               ; preds = %54, %.preheader.1.i.i
  %55 = phi i64 [ 0, %.preheader.1.i.i ], [ %92, %54 ]
  %56 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %91, %54 ]
  %gep12.i.i = getelementptr double, ptr %invariant.gep11.i.i, i64 %55
  %57 = load double, ptr %gep12.i.i, align 8
  %58 = getelementptr double, ptr %gep12.i.i, i64 128
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %gep12.i.i, i64 256
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %gep12.i.i, i64 384
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %.unpack17.i, i64 %55
  %65 = load double, ptr %64, align 8
  %66 = insertelement <4 x double> poison, double %57, i64 0
  %67 = insertelement <4 x double> %66, double %59, i64 1
  %68 = insertelement <4 x double> %67, double %61, i64 2
  %69 = insertelement <4 x double> %68, double %63, i64 3
  %70 = insertelement <4 x double> poison, double %65, i64 0
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = fmul <4 x double> %69, %71
  %73 = fadd <4 x double> %56, %72
  store <4 x double> %73, ptr %53, align 8
  %74 = or disjoint i64 %55, 1
  %gep12.i.i.1 = getelementptr double, ptr %invariant.gep11.i.i, i64 %74
  %75 = load double, ptr %gep12.i.i.1, align 8
  %76 = getelementptr double, ptr %gep12.i.i.1, i64 128
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %gep12.i.i.1, i64 256
  %79 = load double, ptr %78, align 8
  %80 = getelementptr double, ptr %gep12.i.i.1, i64 384
  %81 = load double, ptr %80, align 8
  %82 = getelementptr double, ptr %.unpack17.i, i64 %74
  %83 = load double, ptr %82, align 8
  %84 = insertelement <4 x double> poison, double %75, i64 0
  %85 = insertelement <4 x double> %84, double %77, i64 1
  %86 = insertelement <4 x double> %85, double %79, i64 2
  %87 = insertelement <4 x double> %86, double %81, i64 3
  %88 = insertelement <4 x double> poison, double %83, i64 0
  %89 = shufflevector <4 x double> %88, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = fmul <4 x double> %87, %89
  %91 = fadd <4 x double> %73, %90
  store <4 x double> %91, ptr %53, align 8
  %92 = add nuw nsw i64 %55, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %92, 128
  br i1 %exitcond.1.not.i.i.1, label %93, label %54

93:                                               ; preds = %54
  %94 = add nuw nsw i64 %10, 8
  %95 = icmp ult i64 %10, 56
  br i1 %95, label %.preheader10.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %93
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
