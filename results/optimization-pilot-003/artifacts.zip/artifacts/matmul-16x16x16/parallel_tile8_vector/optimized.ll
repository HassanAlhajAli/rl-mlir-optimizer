; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %15, i8 0, i64 2048, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17.preheader, %109
  %21 = phi i64 [ 0, %.preheader17.preheader ], [ %110, %109 ]
  %22 = shl i64 %21, 4
  %23 = getelementptr double, ptr %15, i64 %22
  %.promoted = load <4 x double>, ptr %23, align 8
  %invariant.gep44 = getelementptr double, ptr %1, i64 %22
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %24 = phi i64 [ 0, %.preheader16 ], [ %65, %.critedge ]
  %25 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %64, %.critedge ]
  %26 = shl nuw nsw i64 %24, 4
  %gep45 = getelementptr double, ptr %invariant.gep44, i64 %24
  %27 = load double, ptr %gep45, align 8
  %28 = insertelement <1 x double> poison, double %27, i64 0
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load <4 x double>, ptr %29, align 8
  %31 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> zeroinitializer
  %32 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 1>
  %33 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 2>
  %34 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 3>
  %35 = fmul <1 x double> %28, %31
  %36 = fmul <1 x double> %28, %32
  %37 = fmul <1 x double> %28, %33
  %38 = shufflevector <1 x double> %37, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = fmul <1 x double> %28, %34
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = shufflevector <1 x double> %35, <1 x double> %36, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %43 = shufflevector <4 x double> %42, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %44 = fadd <4 x double> %25, %43
  store <4 x double> %44, ptr %23, align 8
  %45 = or disjoint i64 %24, 1
  %46 = shl nuw nsw i64 %45, 4
  %gep45.1 = getelementptr double, ptr %invariant.gep44, i64 %45
  %47 = load double, ptr %gep45.1, align 8
  %48 = insertelement <1 x double> poison, double %47, i64 0
  %49 = getelementptr double, ptr %8, i64 %46
  %50 = load <4 x double>, ptr %49, align 8
  %51 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> zeroinitializer
  %52 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 1>
  %53 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 2>
  %54 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 3>
  %55 = fmul <1 x double> %48, %51
  %56 = fmul <1 x double> %48, %52
  %57 = fmul <1 x double> %48, %53
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = fmul <1 x double> %48, %54
  %60 = shufflevector <1 x double> %59, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <1 x double> %55, <1 x double> %56, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %64 = fadd <4 x double> %44, %63
  store <4 x double> %64, ptr %23, align 8
  %65 = add nuw nsw i64 %24, 2
  %exitcond.not.1 = icmp eq i64 %65, 16
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %66 = getelementptr double, ptr %23, i64 4
  %.promoted.1 = load <4 x double>, ptr %66, align 8
  %invariant.gep42 = getelementptr double, ptr %1, i64 %22
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %67 = phi i64 [ 0, %.preheader.1 ], [ %108, %.critedge.1 ]
  %68 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %107, %.critedge.1 ]
  %69 = shl nuw nsw i64 %67, 4
  %gep43 = getelementptr double, ptr %invariant.gep42, i64 %67
  %70 = load double, ptr %gep43, align 8
  %71 = insertelement <1 x double> poison, double %70, i64 0
  %72 = getelementptr double, ptr %invariant.gep.1, i64 %69
  %73 = load <4 x double>, ptr %72, align 8
  %74 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> zeroinitializer
  %75 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 1>
  %76 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 2>
  %77 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 3>
  %78 = fmul <1 x double> %71, %74
  %79 = fmul <1 x double> %71, %75
  %80 = fmul <1 x double> %71, %76
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = fmul <1 x double> %71, %77
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = shufflevector <1 x double> %78, <1 x double> %79, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %85 = shufflevector <4 x double> %84, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %87 = fadd <4 x double> %68, %86
  store <4 x double> %87, ptr %66, align 8
  %88 = or disjoint i64 %67, 1
  %89 = shl nuw nsw i64 %88, 4
  %gep43.1 = getelementptr double, ptr %invariant.gep42, i64 %88
  %90 = load double, ptr %gep43.1, align 8
  %91 = insertelement <1 x double> poison, double %90, i64 0
  %92 = getelementptr double, ptr %invariant.gep.1, i64 %89
  %93 = load <4 x double>, ptr %92, align 8
  %94 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> zeroinitializer
  %95 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 1>
  %96 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 2>
  %97 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 3>
  %98 = fmul <1 x double> %91, %94
  %99 = fmul <1 x double> %91, %95
  %100 = fmul <1 x double> %91, %96
  %101 = shufflevector <1 x double> %100, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %102 = fmul <1 x double> %91, %97
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <1 x double> %98, <1 x double> %99, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %101, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %106 = shufflevector <4 x double> %105, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %107 = fadd <4 x double> %87, %106
  store <4 x double> %107, ptr %66, align 8
  %108 = add nuw nsw i64 %67, 2
  %exitcond.1.not.1 = icmp eq i64 %108, 16
  br i1 %exitcond.1.not.1, label %109, label %.critedge.1

109:                                              ; preds = %.critedge.1
  %110 = add nuw nsw i64 %21, 1
  %exitcond19.not = icmp eq i64 %110, 8
  br i1 %exitcond19.not, label %111, label %.preheader16

111:                                              ; preds = %109
  %112 = getelementptr double, ptr %15, i64 8
  %invariant.gep36 = getelementptr double, ptr %8, i64 8
  %invariant.gep40 = getelementptr double, ptr %8, i64 12
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %197, %111
  %113 = phi i64 [ 0, %111 ], [ %198, %197 ]
  %114 = shl i64 %113, 4
  %115 = getelementptr double, ptr %112, i64 %114
  %.promoted.120 = load <4 x double>, ptr %115, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %114
  br label %.critedge.124

.critedge.124:                                    ; preds = %.critedge.124, %.preheader16.1
  %116 = phi i64 [ 0, %.preheader16.1 ], [ %155, %.critedge.124 ]
  %117 = phi <4 x double> [ %.promoted.120, %.preheader16.1 ], [ %154, %.critedge.124 ]
  %118 = shl nuw nsw i64 %116, 4
  %gep = getelementptr double, ptr %invariant.gep, i64 %116
  %119 = load double, ptr %gep, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %gep37 = getelementptr double, ptr %invariant.gep36, i64 %118
  %121 = load <4 x double>, ptr %gep37, align 8
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> zeroinitializer
  %123 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 1>
  %124 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 2>
  %125 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 3>
  %126 = fmul <1 x double> %120, %122
  %127 = fmul <1 x double> %120, %123
  %128 = fmul <1 x double> %120, %124
  %129 = shufflevector <1 x double> %128, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %130 = fmul <1 x double> %120, %125
  %131 = shufflevector <1 x double> %130, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %132 = shufflevector <1 x double> %126, <1 x double> %127, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %129, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %131, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %135 = fadd <4 x double> %117, %134
  store <4 x double> %135, ptr %115, align 8
  %136 = or disjoint i64 %116, 1
  %137 = shl nuw nsw i64 %136, 4
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %136
  %138 = load double, ptr %gep.1, align 8
  %139 = insertelement <1 x double> poison, double %138, i64 0
  %gep37.1 = getelementptr double, ptr %invariant.gep36, i64 %137
  %140 = load <4 x double>, ptr %gep37.1, align 8
  %141 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> zeroinitializer
  %142 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 1>
  %143 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 2>
  %144 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 3>
  %145 = fmul <1 x double> %139, %141
  %146 = fmul <1 x double> %139, %142
  %147 = fmul <1 x double> %139, %143
  %148 = shufflevector <1 x double> %147, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %149 = fmul <1 x double> %139, %144
  %150 = shufflevector <1 x double> %149, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %151 = shufflevector <1 x double> %145, <1 x double> %146, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %152 = shufflevector <4 x double> %151, <4 x double> %148, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %150, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %154 = fadd <4 x double> %135, %153
  store <4 x double> %154, ptr %115, align 8
  %155 = add nuw nsw i64 %116, 2
  %exitcond.123.not.1 = icmp eq i64 %155, 16
  br i1 %exitcond.123.not.1, label %.preheader.1.1, label %.critedge.124

.preheader.1.1:                                   ; preds = %.critedge.124
  %156 = getelementptr double, ptr %115, i64 4
  %.promoted.1.1 = load <4 x double>, ptr %156, align 8
  %invariant.gep38 = getelementptr double, ptr %1, i64 %114
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1, %.preheader.1.1
  %157 = phi i64 [ 0, %.preheader.1.1 ], [ %196, %.critedge.1.1 ]
  %158 = phi <4 x double> [ %.promoted.1.1, %.preheader.1.1 ], [ %195, %.critedge.1.1 ]
  %159 = shl nuw nsw i64 %157, 4
  %gep39 = getelementptr double, ptr %invariant.gep38, i64 %157
  %160 = load double, ptr %gep39, align 8
  %161 = insertelement <1 x double> poison, double %160, i64 0
  %gep41 = getelementptr double, ptr %invariant.gep40, i64 %159
  %162 = load <4 x double>, ptr %gep41, align 8
  %163 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> zeroinitializer
  %164 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 1>
  %165 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 2>
  %166 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 3>
  %167 = fmul <1 x double> %161, %163
  %168 = fmul <1 x double> %161, %164
  %169 = fmul <1 x double> %161, %165
  %170 = shufflevector <1 x double> %169, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %171 = fmul <1 x double> %161, %166
  %172 = shufflevector <1 x double> %171, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %173 = shufflevector <1 x double> %167, <1 x double> %168, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %174 = shufflevector <4 x double> %173, <4 x double> %170, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %175 = shufflevector <4 x double> %174, <4 x double> %172, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %176 = fadd <4 x double> %158, %175
  store <4 x double> %176, ptr %156, align 8
  %177 = or disjoint i64 %157, 1
  %178 = shl nuw nsw i64 %177, 4
  %gep39.1 = getelementptr double, ptr %invariant.gep38, i64 %177
  %179 = load double, ptr %gep39.1, align 8
  %180 = insertelement <1 x double> poison, double %179, i64 0
  %gep41.1 = getelementptr double, ptr %invariant.gep40, i64 %178
  %181 = load <4 x double>, ptr %gep41.1, align 8
  %182 = shufflevector <4 x double> %181, <4 x double> poison, <1 x i32> zeroinitializer
  %183 = shufflevector <4 x double> %181, <4 x double> poison, <1 x i32> <i32 1>
  %184 = shufflevector <4 x double> %181, <4 x double> poison, <1 x i32> <i32 2>
  %185 = shufflevector <4 x double> %181, <4 x double> poison, <1 x i32> <i32 3>
  %186 = fmul <1 x double> %180, %182
  %187 = fmul <1 x double> %180, %183
  %188 = fmul <1 x double> %180, %184
  %189 = shufflevector <1 x double> %188, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %190 = fmul <1 x double> %180, %185
  %191 = shufflevector <1 x double> %190, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %192 = shufflevector <1 x double> %186, <1 x double> %187, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %193 = shufflevector <4 x double> %192, <4 x double> %189, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %194 = shufflevector <4 x double> %193, <4 x double> %191, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %195 = fadd <4 x double> %176, %194
  store <4 x double> %195, ptr %156, align 8
  %196 = add nuw nsw i64 %157, 2
  %exitcond.1.1.not.1 = icmp eq i64 %196, 16
  br i1 %exitcond.1.1.not.1, label %197, label %.critedge.1.1

197:                                              ; preds = %.critedge.1.1
  %198 = add nuw nsw i64 %113, 1
  %exitcond19.1.not = icmp eq i64 %198, 8
  br i1 %exitcond19.1.not, label %.preheader17.1, label %.preheader16.1

.preheader17.1:                                   ; preds = %197
  %199 = getelementptr double, ptr %15, i64 128
  %invariant.gep54 = getelementptr double, ptr %1, i64 128
  %invariant.gep56 = getelementptr double, ptr %1, i64 128
  br label %.preheader16.125

.preheader16.125:                                 ; preds = %288, %.preheader17.1
  %200 = phi i64 [ 0, %.preheader17.1 ], [ %289, %288 ]
  %201 = shl i64 %200, 4
  %202 = getelementptr double, ptr %199, i64 %201
  %.promoted.126 = load <4 x double>, ptr %202, align 8
  %gep55 = getelementptr double, ptr %invariant.gep54, i64 %201
  br label %.critedge.129

.critedge.129:                                    ; preds = %.critedge.129, %.preheader16.125
  %203 = phi i64 [ 0, %.preheader16.125 ], [ %244, %.critedge.129 ]
  %204 = phi <4 x double> [ %.promoted.126, %.preheader16.125 ], [ %243, %.critedge.129 ]
  %205 = shl nuw nsw i64 %203, 4
  %gep49 = getelementptr double, ptr %gep55, i64 %203
  %206 = load double, ptr %gep49, align 8
  %207 = insertelement <1 x double> poison, double %206, i64 0
  %208 = getelementptr double, ptr %8, i64 %205
  %209 = load <4 x double>, ptr %208, align 8
  %210 = shufflevector <4 x double> %209, <4 x double> poison, <1 x i32> zeroinitializer
  %211 = shufflevector <4 x double> %209, <4 x double> poison, <1 x i32> <i32 1>
  %212 = shufflevector <4 x double> %209, <4 x double> poison, <1 x i32> <i32 2>
  %213 = shufflevector <4 x double> %209, <4 x double> poison, <1 x i32> <i32 3>
  %214 = fmul <1 x double> %207, %210
  %215 = fmul <1 x double> %207, %211
  %216 = fmul <1 x double> %207, %212
  %217 = shufflevector <1 x double> %216, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %218 = fmul <1 x double> %207, %213
  %219 = shufflevector <1 x double> %218, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %220 = shufflevector <1 x double> %214, <1 x double> %215, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %221 = shufflevector <4 x double> %220, <4 x double> %217, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %222 = shufflevector <4 x double> %221, <4 x double> %219, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %223 = fadd <4 x double> %204, %222
  store <4 x double> %223, ptr %202, align 8
  %224 = or disjoint i64 %203, 1
  %225 = shl nuw nsw i64 %224, 4
  %gep49.1 = getelementptr double, ptr %gep55, i64 %224
  %226 = load double, ptr %gep49.1, align 8
  %227 = insertelement <1 x double> poison, double %226, i64 0
  %228 = getelementptr double, ptr %8, i64 %225
  %229 = load <4 x double>, ptr %228, align 8
  %230 = shufflevector <4 x double> %229, <4 x double> poison, <1 x i32> zeroinitializer
  %231 = shufflevector <4 x double> %229, <4 x double> poison, <1 x i32> <i32 1>
  %232 = shufflevector <4 x double> %229, <4 x double> poison, <1 x i32> <i32 2>
  %233 = shufflevector <4 x double> %229, <4 x double> poison, <1 x i32> <i32 3>
  %234 = fmul <1 x double> %227, %230
  %235 = fmul <1 x double> %227, %231
  %236 = fmul <1 x double> %227, %232
  %237 = shufflevector <1 x double> %236, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %238 = fmul <1 x double> %227, %233
  %239 = shufflevector <1 x double> %238, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %240 = shufflevector <1 x double> %234, <1 x double> %235, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %241 = shufflevector <4 x double> %240, <4 x double> %237, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %242 = shufflevector <4 x double> %241, <4 x double> %239, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %243 = fadd <4 x double> %223, %242
  store <4 x double> %243, ptr %202, align 8
  %244 = add nuw nsw i64 %203, 2
  %exitcond.128.not.1 = icmp eq i64 %244, 16
  br i1 %exitcond.128.not.1, label %.preheader.1.132, label %.critedge.129

.preheader.1.132:                                 ; preds = %.critedge.129
  %245 = getelementptr double, ptr %202, i64 4
  %.promoted.1.131 = load <4 x double>, ptr %245, align 8
  %gep57 = getelementptr double, ptr %invariant.gep56, i64 %201
  br label %.critedge.1.134

.critedge.1.134:                                  ; preds = %.critedge.1.134, %.preheader.1.132
  %246 = phi i64 [ 0, %.preheader.1.132 ], [ %287, %.critedge.1.134 ]
  %247 = phi <4 x double> [ %.promoted.1.131, %.preheader.1.132 ], [ %286, %.critedge.1.134 ]
  %248 = shl nuw nsw i64 %246, 4
  %gep53 = getelementptr double, ptr %gep57, i64 %246
  %249 = load double, ptr %gep53, align 8
  %250 = insertelement <1 x double> poison, double %249, i64 0
  %251 = getelementptr double, ptr %invariant.gep.1, i64 %248
  %252 = load <4 x double>, ptr %251, align 8
  %253 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> zeroinitializer
  %254 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 1>
  %255 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 2>
  %256 = shufflevector <4 x double> %252, <4 x double> poison, <1 x i32> <i32 3>
  %257 = fmul <1 x double> %250, %253
  %258 = fmul <1 x double> %250, %254
  %259 = fmul <1 x double> %250, %255
  %260 = shufflevector <1 x double> %259, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %261 = fmul <1 x double> %250, %256
  %262 = shufflevector <1 x double> %261, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %263 = shufflevector <1 x double> %257, <1 x double> %258, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %264 = shufflevector <4 x double> %263, <4 x double> %260, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %265 = shufflevector <4 x double> %264, <4 x double> %262, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %266 = fadd <4 x double> %247, %265
  store <4 x double> %266, ptr %245, align 8
  %267 = or disjoint i64 %246, 1
  %268 = shl nuw nsw i64 %267, 4
  %gep53.1 = getelementptr double, ptr %gep57, i64 %267
  %269 = load double, ptr %gep53.1, align 8
  %270 = insertelement <1 x double> poison, double %269, i64 0
  %271 = getelementptr double, ptr %invariant.gep.1, i64 %268
  %272 = load <4 x double>, ptr %271, align 8
  %273 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> zeroinitializer
  %274 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 1>
  %275 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 2>
  %276 = shufflevector <4 x double> %272, <4 x double> poison, <1 x i32> <i32 3>
  %277 = fmul <1 x double> %270, %273
  %278 = fmul <1 x double> %270, %274
  %279 = fmul <1 x double> %270, %275
  %280 = shufflevector <1 x double> %279, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %281 = fmul <1 x double> %270, %276
  %282 = shufflevector <1 x double> %281, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %283 = shufflevector <1 x double> %277, <1 x double> %278, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %284 = shufflevector <4 x double> %283, <4 x double> %280, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %285 = shufflevector <4 x double> %284, <4 x double> %282, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %286 = fadd <4 x double> %266, %285
  store <4 x double> %286, ptr %245, align 8
  %287 = add nuw nsw i64 %246, 2
  %exitcond.1.133.not.1 = icmp eq i64 %287, 16
  br i1 %exitcond.1.133.not.1, label %288, label %.critedge.1.134

288:                                              ; preds = %.critedge.1.134
  %289 = add nuw nsw i64 %200, 1
  %exitcond19.135.not = icmp eq i64 %289, 8
  br i1 %exitcond19.135.not, label %290, label %.preheader16.125

290:                                              ; preds = %288
  %291 = getelementptr double, ptr %15, i64 136
  %invariant.gep70 = getelementptr double, ptr %1, i64 128
  %invariant.gep62 = getelementptr double, ptr %8, i64 8
  %invariant.gep72 = getelementptr double, ptr %1, i64 128
  %invariant.gep68 = getelementptr double, ptr %8, i64 12
  br label %.preheader16.1.1

.preheader16.1.1:                                 ; preds = %376, %290
  %292 = phi i64 [ 0, %290 ], [ %377, %376 ]
  %293 = shl i64 %292, 4
  %294 = getelementptr double, ptr %291, i64 %293
  %.promoted.120.1 = load <4 x double>, ptr %294, align 8
  %gep71 = getelementptr double, ptr %invariant.gep70, i64 %293
  br label %.critedge.124.1

.critedge.124.1:                                  ; preds = %.critedge.124.1, %.preheader16.1.1
  %295 = phi i64 [ 0, %.preheader16.1.1 ], [ %334, %.critedge.124.1 ]
  %296 = phi <4 x double> [ %.promoted.120.1, %.preheader16.1.1 ], [ %333, %.critedge.124.1 ]
  %297 = shl nuw nsw i64 %295, 4
  %gep61 = getelementptr double, ptr %gep71, i64 %295
  %298 = load double, ptr %gep61, align 8
  %299 = insertelement <1 x double> poison, double %298, i64 0
  %gep63 = getelementptr double, ptr %invariant.gep62, i64 %297
  %300 = load <4 x double>, ptr %gep63, align 8
  %301 = shufflevector <4 x double> %300, <4 x double> poison, <1 x i32> zeroinitializer
  %302 = shufflevector <4 x double> %300, <4 x double> poison, <1 x i32> <i32 1>
  %303 = shufflevector <4 x double> %300, <4 x double> poison, <1 x i32> <i32 2>
  %304 = shufflevector <4 x double> %300, <4 x double> poison, <1 x i32> <i32 3>
  %305 = fmul <1 x double> %299, %301
  %306 = fmul <1 x double> %299, %302
  %307 = fmul <1 x double> %299, %303
  %308 = shufflevector <1 x double> %307, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %309 = fmul <1 x double> %299, %304
  %310 = shufflevector <1 x double> %309, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %311 = shufflevector <1 x double> %305, <1 x double> %306, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %312 = shufflevector <4 x double> %311, <4 x double> %308, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %313 = shufflevector <4 x double> %312, <4 x double> %310, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %314 = fadd <4 x double> %296, %313
  store <4 x double> %314, ptr %294, align 8
  %315 = or disjoint i64 %295, 1
  %316 = shl nuw nsw i64 %315, 4
  %gep61.1 = getelementptr double, ptr %gep71, i64 %315
  %317 = load double, ptr %gep61.1, align 8
  %318 = insertelement <1 x double> poison, double %317, i64 0
  %gep63.1 = getelementptr double, ptr %invariant.gep62, i64 %316
  %319 = load <4 x double>, ptr %gep63.1, align 8
  %320 = shufflevector <4 x double> %319, <4 x double> poison, <1 x i32> zeroinitializer
  %321 = shufflevector <4 x double> %319, <4 x double> poison, <1 x i32> <i32 1>
  %322 = shufflevector <4 x double> %319, <4 x double> poison, <1 x i32> <i32 2>
  %323 = shufflevector <4 x double> %319, <4 x double> poison, <1 x i32> <i32 3>
  %324 = fmul <1 x double> %318, %320
  %325 = fmul <1 x double> %318, %321
  %326 = fmul <1 x double> %318, %322
  %327 = shufflevector <1 x double> %326, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %328 = fmul <1 x double> %318, %323
  %329 = shufflevector <1 x double> %328, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %330 = shufflevector <1 x double> %324, <1 x double> %325, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %331 = shufflevector <4 x double> %330, <4 x double> %327, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %332 = shufflevector <4 x double> %331, <4 x double> %329, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %333 = fadd <4 x double> %314, %332
  store <4 x double> %333, ptr %294, align 8
  %334 = add nuw nsw i64 %295, 2
  %exitcond.123.1.not.1 = icmp eq i64 %334, 16
  br i1 %exitcond.123.1.not.1, label %.preheader.1.1.1, label %.critedge.124.1

.preheader.1.1.1:                                 ; preds = %.critedge.124.1
  %335 = getelementptr double, ptr %294, i64 4
  %.promoted.1.1.1 = load <4 x double>, ptr %335, align 8
  %gep73 = getelementptr double, ptr %invariant.gep72, i64 %293
  br label %.critedge.1.1.1

.critedge.1.1.1:                                  ; preds = %.critedge.1.1.1, %.preheader.1.1.1
  %336 = phi i64 [ 0, %.preheader.1.1.1 ], [ %375, %.critedge.1.1.1 ]
  %337 = phi <4 x double> [ %.promoted.1.1.1, %.preheader.1.1.1 ], [ %374, %.critedge.1.1.1 ]
  %338 = shl nuw nsw i64 %336, 4
  %gep67 = getelementptr double, ptr %gep73, i64 %336
  %339 = load double, ptr %gep67, align 8
  %340 = insertelement <1 x double> poison, double %339, i64 0
  %gep69 = getelementptr double, ptr %invariant.gep68, i64 %338
  %341 = load <4 x double>, ptr %gep69, align 8
  %342 = shufflevector <4 x double> %341, <4 x double> poison, <1 x i32> zeroinitializer
  %343 = shufflevector <4 x double> %341, <4 x double> poison, <1 x i32> <i32 1>
  %344 = shufflevector <4 x double> %341, <4 x double> poison, <1 x i32> <i32 2>
  %345 = shufflevector <4 x double> %341, <4 x double> poison, <1 x i32> <i32 3>
  %346 = fmul <1 x double> %340, %342
  %347 = fmul <1 x double> %340, %343
  %348 = fmul <1 x double> %340, %344
  %349 = shufflevector <1 x double> %348, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %350 = fmul <1 x double> %340, %345
  %351 = shufflevector <1 x double> %350, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %352 = shufflevector <1 x double> %346, <1 x double> %347, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %353 = shufflevector <4 x double> %352, <4 x double> %349, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %354 = shufflevector <4 x double> %353, <4 x double> %351, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %355 = fadd <4 x double> %337, %354
  store <4 x double> %355, ptr %335, align 8
  %356 = or disjoint i64 %336, 1
  %357 = shl nuw nsw i64 %356, 4
  %gep67.1 = getelementptr double, ptr %gep73, i64 %356
  %358 = load double, ptr %gep67.1, align 8
  %359 = insertelement <1 x double> poison, double %358, i64 0
  %gep69.1 = getelementptr double, ptr %invariant.gep68, i64 %357
  %360 = load <4 x double>, ptr %gep69.1, align 8
  %361 = shufflevector <4 x double> %360, <4 x double> poison, <1 x i32> zeroinitializer
  %362 = shufflevector <4 x double> %360, <4 x double> poison, <1 x i32> <i32 1>
  %363 = shufflevector <4 x double> %360, <4 x double> poison, <1 x i32> <i32 2>
  %364 = shufflevector <4 x double> %360, <4 x double> poison, <1 x i32> <i32 3>
  %365 = fmul <1 x double> %359, %361
  %366 = fmul <1 x double> %359, %362
  %367 = fmul <1 x double> %359, %363
  %368 = shufflevector <1 x double> %367, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %369 = fmul <1 x double> %359, %364
  %370 = shufflevector <1 x double> %369, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %371 = shufflevector <1 x double> %365, <1 x double> %366, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %372 = shufflevector <4 x double> %371, <4 x double> %368, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %373 = shufflevector <4 x double> %372, <4 x double> %370, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %374 = fadd <4 x double> %355, %373
  store <4 x double> %374, ptr %335, align 8
  %375 = add nuw nsw i64 %336, 2
  %exitcond.1.1.1.not.1 = icmp eq i64 %375, 16
  br i1 %exitcond.1.1.1.not.1, label %376, label %.critedge.1.1.1

376:                                              ; preds = %.critedge.1.1.1
  %377 = add nuw nsw i64 %292, 1
  %exitcond19.1.1.not = icmp eq i64 %377, 8
  br i1 %exitcond19.1.1.not, label %378, label %.preheader16.1.1

378:                                              ; preds = %376
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
