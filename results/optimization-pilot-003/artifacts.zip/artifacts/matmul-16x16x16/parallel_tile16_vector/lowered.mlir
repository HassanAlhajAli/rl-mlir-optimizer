module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(1 : index) : i64
    %29 = llvm.mlir.constant(4 : index) : i64
    %30 = llvm.mlir.constant(0 : index) : i64
    %31 = llvm.mlir.constant(16 : index) : i64
    %32 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%30 : i64)
  ^bb1(%33: i64):  // 2 preds: ^bb0, ^bb5
    %34 = llvm.icmp "slt" %33, %31 : i64
    llvm.cond_br %34, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%30 : i64)
  ^bb3(%35: i64):  // 2 preds: ^bb2, ^bb4
    %36 = llvm.icmp "slt" %35, %31 : i64
    llvm.cond_br %36, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %37 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %38 = llvm.mlir.constant(16 : index) : i64
    %39 = llvm.mul %33, %38  : i64
    %40 = llvm.add %39, %35  : i64
    %41 = llvm.getelementptr %37[%40] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %32, %41 : f64, !llvm.ptr
    %42 = llvm.add %35, %28  : i64
    llvm.br ^bb3(%42 : i64)
  ^bb5:  // pred: ^bb3
    %43 = llvm.add %33, %28  : i64
    llvm.br ^bb1(%43 : i64)
  ^bb6:  // pred: ^bb1
    %44 = llvm.mlir.constant(1 : index) : i64
    %45 = llvm.alloca %44 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %46 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %47 = llvm.insertvalue %45, %46[0] : !llvm.struct<(ptr, ptr, i64)> 
    %48 = llvm.insertvalue %45, %47[1] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.mlir.constant(0 : index) : i64
    %50 = llvm.insertvalue %49, %48[2] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.mlir.constant(1 : index) : i64
    %52 = llvm.alloca %51 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %53 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %54 = llvm.insertvalue %52, %53[0] : !llvm.struct<(ptr, ptr, i64)> 
    %55 = llvm.insertvalue %52, %54[1] : !llvm.struct<(ptr, ptr, i64)> 
    %56 = llvm.mlir.constant(0 : index) : i64
    %57 = llvm.insertvalue %56, %55[2] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.mlir.constant(1 : index) : i64
    %59 = llvm.alloca %58 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %60 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %61 = llvm.insertvalue %59, %60[0] : !llvm.struct<(ptr, ptr, i64)> 
    %62 = llvm.insertvalue %59, %61[1] : !llvm.struct<(ptr, ptr, i64)> 
    %63 = llvm.mlir.constant(0 : index) : i64
    %64 = llvm.insertvalue %63, %62[2] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.mlir.constant(1 : index) : i64
    %66 = llvm.alloca %65 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %67 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %68 = llvm.insertvalue %66, %67[0] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.insertvalue %66, %68[1] : !llvm.struct<(ptr, ptr, i64)> 
    %70 = llvm.mlir.constant(0 : index) : i64
    %71 = llvm.insertvalue %70, %69[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%30 : i64)
  ^bb7(%72: i64):  // 2 preds: ^bb6, ^bb26
    %73 = llvm.icmp "slt" %72, %31 : i64
    llvm.cond_br %73, ^bb8, ^bb27
  ^bb8:  // pred: ^bb7
    llvm.br ^bb9(%30 : i64)
  ^bb9(%74: i64):  // 2 preds: ^bb8, ^bb25
    %75 = llvm.icmp "slt" %74, %31 : i64
    llvm.cond_br %75, ^bb10, ^bb26
  ^bb10:  // pred: ^bb9
    llvm.br ^bb11(%30 : i64)
  ^bb11(%76: i64):  // 2 preds: ^bb10, ^bb24
    %77 = llvm.icmp "slt" %76, %31 : i64
    llvm.cond_br %77, ^bb12, ^bb25
  ^bb12:  // pred: ^bb11
    %78 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %81 = llvm.insertvalue %78, %80[0] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.insertvalue %79, %81[1] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.mlir.constant(0 : index) : i64
    %84 = llvm.insertvalue %83, %82[2] : !llvm.struct<(ptr, ptr, i64)> 
    %85 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.mul %72, %31  : i64
    %91 = llvm.add %90, %76  : i64
    %92 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %93 = llvm.insertvalue %78, %92[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %94 = llvm.insertvalue %79, %93[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %95 = llvm.insertvalue %91, %94[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.mlir.constant(1 : index) : i64
    %97 = llvm.insertvalue %96, %95[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.mlir.constant(16 : index) : i64
    %99 = llvm.insertvalue %98, %97[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.mlir.constant(1 : index) : i64
    %101 = llvm.insertvalue %100, %99[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %102 = llvm.mlir.constant(1 : index) : i64
    %103 = llvm.insertvalue %102, %101[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %107 = llvm.insertvalue %104, %106[0] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.insertvalue %105, %107[1] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.mlir.constant(0 : index) : i64
    %110 = llvm.insertvalue %109, %108[2] : !llvm.struct<(ptr, ptr, i64)> 
    %111 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.mul %76, %31  : i64
    %117 = llvm.add %116, %74  : i64
    %118 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %119 = llvm.insertvalue %104, %118[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %120 = llvm.insertvalue %105, %119[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %121 = llvm.insertvalue %117, %120[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %122 = llvm.mlir.constant(1 : index) : i64
    %123 = llvm.insertvalue %122, %121[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.mlir.constant(16 : index) : i64
    %125 = llvm.insertvalue %124, %123[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %126 = llvm.mlir.constant(4 : index) : i64
    %127 = llvm.insertvalue %126, %125[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.mlir.constant(1 : index) : i64
    %129 = llvm.insertvalue %128, %127[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %133 = llvm.insertvalue %130, %132[0] : !llvm.struct<(ptr, ptr, i64)> 
    %134 = llvm.insertvalue %131, %133[1] : !llvm.struct<(ptr, ptr, i64)> 
    %135 = llvm.mlir.constant(0 : index) : i64
    %136 = llvm.insertvalue %135, %134[2] : !llvm.struct<(ptr, ptr, i64)> 
    %137 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %140 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %141 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %142 = llvm.mul %72, %31  : i64
    %143 = llvm.add %142, %74  : i64
    %144 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %145 = llvm.insertvalue %130, %144[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.insertvalue %131, %145[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.insertvalue %143, %146[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.mlir.constant(1 : index) : i64
    %149 = llvm.insertvalue %148, %147[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.mlir.constant(16 : index) : i64
    %151 = llvm.insertvalue %150, %149[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.mlir.constant(4 : index) : i64
    %153 = llvm.insertvalue %152, %151[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.mlir.constant(1 : index) : i64
    %155 = llvm.insertvalue %154, %153[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %156 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %157 = llvm.extractvalue %50[0] : !llvm.struct<(ptr, ptr, i64)> 
    %158 = llvm.insertvalue %157, %156[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.extractvalue %50[1] : !llvm.struct<(ptr, ptr, i64)> 
    %160 = llvm.insertvalue %159, %158[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %161 = llvm.mlir.constant(0 : index) : i64
    %162 = llvm.insertvalue %161, %160[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %163 = llvm.mlir.constant(1 : index) : i64
    %164 = llvm.insertvalue %163, %162[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.mlir.constant(1 : index) : i64
    %166 = llvm.insertvalue %165, %164[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb13(%30 : i64)
  ^bb13(%167: i64):  // 2 preds: ^bb12, ^bb14
    %168 = llvm.icmp "slt" %167, %28 : i64
    llvm.cond_br %168, ^bb14, ^bb15
  ^bb14:  // pred: ^bb13
    %169 = llvm.getelementptr %79[%91] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %170 = llvm.mlir.constant(16 : index) : i64
    %171 = llvm.mul %167, %170  : i64
    %172 = llvm.add %171, %30  : i64
    %173 = llvm.getelementptr %169[%172] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %174 = llvm.load %173 : !llvm.ptr -> f64
    %175 = llvm.mlir.undef : vector<1xf64>
    %176 = llvm.mlir.constant(0 : i32) : i32
    %177 = llvm.insertelement %174, %175[%176 : i32] : vector<1xf64>
    %178 = llvm.shufflevector %177, %175 [0] : vector<1xf64> 
    %179 = llvm.getelementptr %159[%167] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %178, %179 : vector<1xf64>, !llvm.ptr
    %180 = llvm.add %167, %28  : i64
    llvm.br ^bb13(%180 : i64)
  ^bb15:  // pred: ^bb13
    %181 = llvm.load %45 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %182 = llvm.extractvalue %181[0] : !llvm.array<1 x vector<1xf64>> 
    %183 = llvm.insertvalue %182, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %184 = llvm.insertvalue %182, %183[1] : !llvm.array<4 x vector<1xf64>> 
    %185 = llvm.insertvalue %182, %184[2] : !llvm.array<4 x vector<1xf64>> 
    %186 = llvm.insertvalue %182, %185[3] : !llvm.array<4 x vector<1xf64>> 
    %187 = llvm.insertvalue %186, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %188 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %189 = llvm.extractvalue %57[0] : !llvm.struct<(ptr, ptr, i64)> 
    %190 = llvm.insertvalue %189, %188[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %191 = llvm.extractvalue %57[1] : !llvm.struct<(ptr, ptr, i64)> 
    %192 = llvm.insertvalue %191, %190[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %193 = llvm.mlir.constant(0 : index) : i64
    %194 = llvm.insertvalue %193, %192[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.mlir.constant(1 : index) : i64
    %196 = llvm.insertvalue %195, %194[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.mlir.constant(1 : index) : i64
    %198 = llvm.insertvalue %197, %196[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb16(%30 : i64)
  ^bb16(%199: i64):  // 2 preds: ^bb15, ^bb17
    %200 = llvm.icmp "slt" %199, %28 : i64
    llvm.cond_br %200, ^bb17, ^bb18
  ^bb17:  // pred: ^bb16
    %201 = llvm.extractvalue %129[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %202 = llvm.extractvalue %129[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %203 = llvm.getelementptr %201[%202] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %204 = llvm.mlir.constant(16 : index) : i64
    %205 = llvm.mul %199, %204  : i64
    %206 = llvm.add %205, %30  : i64
    %207 = llvm.getelementptr %203[%206] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %208 = llvm.load %207 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %209 = llvm.getelementptr %191[%199] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %208, %209 : vector<4xf64>, !llvm.ptr
    %210 = llvm.add %199, %28  : i64
    llvm.br ^bb16(%210 : i64)
  ^bb18:  // pred: ^bb16
    %211 = llvm.load %52 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %212 = llvm.extractvalue %211[0] : !llvm.array<1 x vector<4xf64>> 
    %213 = llvm.mlir.constant(0 : i64) : i64
    %214 = llvm.extractelement %212[%213 : i64] : vector<4xf64>
    %215 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %216 = llvm.mlir.constant(0 : i64) : i64
    %217 = llvm.insertelement %214, %215[%216 : i64] : vector<1xf64>
    %218 = llvm.insertvalue %217, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %219 = llvm.extractvalue %211[0] : !llvm.array<1 x vector<4xf64>> 
    %220 = llvm.mlir.constant(1 : i64) : i64
    %221 = llvm.extractelement %219[%220 : i64] : vector<4xf64>
    %222 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %223 = llvm.mlir.constant(0 : i64) : i64
    %224 = llvm.insertelement %221, %222[%223 : i64] : vector<1xf64>
    %225 = llvm.insertvalue %224, %218[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %226 = llvm.extractvalue %211[0] : !llvm.array<1 x vector<4xf64>> 
    %227 = llvm.mlir.constant(2 : i64) : i64
    %228 = llvm.extractelement %226[%227 : i64] : vector<4xf64>
    %229 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %230 = llvm.mlir.constant(0 : i64) : i64
    %231 = llvm.insertelement %228, %229[%230 : i64] : vector<1xf64>
    %232 = llvm.insertvalue %231, %225[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %233 = llvm.extractvalue %211[0] : !llvm.array<1 x vector<4xf64>> 
    %234 = llvm.mlir.constant(3 : i64) : i64
    %235 = llvm.extractelement %233[%234 : i64] : vector<4xf64>
    %236 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %237 = llvm.mlir.constant(0 : i64) : i64
    %238 = llvm.insertelement %235, %236[%237 : i64] : vector<1xf64>
    %239 = llvm.insertvalue %238, %232[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %240 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %241 = llvm.extractvalue %64[0] : !llvm.struct<(ptr, ptr, i64)> 
    %242 = llvm.insertvalue %241, %240[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %243 = llvm.extractvalue %64[1] : !llvm.struct<(ptr, ptr, i64)> 
    %244 = llvm.insertvalue %243, %242[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %245 = llvm.mlir.constant(0 : index) : i64
    %246 = llvm.insertvalue %245, %244[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %247 = llvm.mlir.constant(1 : index) : i64
    %248 = llvm.insertvalue %247, %246[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.mlir.constant(1 : index) : i64
    %250 = llvm.insertvalue %249, %248[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb19(%30 : i64)
  ^bb19(%251: i64):  // 2 preds: ^bb18, ^bb20
    %252 = llvm.icmp "slt" %251, %28 : i64
    llvm.cond_br %252, ^bb20, ^bb21
  ^bb20:  // pred: ^bb19
    %253 = llvm.extractvalue %155[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %254 = llvm.extractvalue %155[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %255 = llvm.getelementptr %253[%254] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %256 = llvm.mlir.constant(16 : index) : i64
    %257 = llvm.mul %251, %256  : i64
    %258 = llvm.add %257, %30  : i64
    %259 = llvm.getelementptr %255[%258] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %260 = llvm.load %259 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %261 = llvm.getelementptr %243[%251] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %260, %261 : vector<4xf64>, !llvm.ptr
    %262 = llvm.add %251, %28  : i64
    llvm.br ^bb19(%262 : i64)
  ^bb21:  // pred: ^bb19
    %263 = llvm.load %59 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %264 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %265 = llvm.extractvalue %187[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %266 = llvm.fmul %265, %217  : vector<1xf64>
    %267 = llvm.insertvalue %266, %264[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %268 = llvm.extractvalue %187[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %269 = llvm.fmul %268, %224  : vector<1xf64>
    %270 = llvm.insertvalue %269, %267[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %271 = llvm.extractvalue %187[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %272 = llvm.fmul %271, %231  : vector<1xf64>
    %273 = llvm.insertvalue %272, %270[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %274 = llvm.extractvalue %187[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %275 = llvm.fmul %274, %238  : vector<1xf64>
    %276 = llvm.insertvalue %275, %273[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %277 = llvm.extractvalue %276[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %278 = llvm.mlir.constant(0 : i64) : i64
    %279 = llvm.extractelement %277[%278 : i64] : vector<1xf64>
    %280 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %281 = llvm.mlir.constant(0 : i64) : i64
    %282 = llvm.insertelement %279, %280[%281 : i64] : vector<4xf64>
    %283 = llvm.insertvalue %282, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %284 = llvm.extractvalue %276[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %285 = llvm.mlir.constant(0 : i64) : i64
    %286 = llvm.extractelement %284[%285 : i64] : vector<1xf64>
    %287 = llvm.mlir.constant(1 : i64) : i64
    %288 = llvm.insertelement %286, %282[%287 : i64] : vector<4xf64>
    %289 = llvm.insertvalue %288, %283[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %290 = llvm.extractvalue %276[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %291 = llvm.mlir.constant(0 : i64) : i64
    %292 = llvm.extractelement %290[%291 : i64] : vector<1xf64>
    %293 = llvm.mlir.constant(2 : i64) : i64
    %294 = llvm.insertelement %292, %288[%293 : i64] : vector<4xf64>
    %295 = llvm.insertvalue %294, %289[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %296 = llvm.extractvalue %276[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %297 = llvm.mlir.constant(0 : i64) : i64
    %298 = llvm.extractelement %296[%297 : i64] : vector<1xf64>
    %299 = llvm.mlir.constant(3 : i64) : i64
    %300 = llvm.insertelement %298, %294[%299 : i64] : vector<4xf64>
    %301 = llvm.insertvalue %300, %295[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %302 = llvm.extractvalue %263[0] : !llvm.array<1 x vector<4xf64>> 
    %303 = llvm.fadd %300, %302  : vector<4xf64>
    %304 = llvm.insertvalue %303, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %304, %66 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %305 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %306 = llvm.extractvalue %71[0] : !llvm.struct<(ptr, ptr, i64)> 
    %307 = llvm.insertvalue %306, %305[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.extractvalue %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %309 = llvm.insertvalue %308, %307[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %310 = llvm.mlir.constant(0 : index) : i64
    %311 = llvm.insertvalue %310, %309[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %312 = llvm.mlir.constant(1 : index) : i64
    %313 = llvm.insertvalue %312, %311[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.mlir.constant(1 : index) : i64
    %315 = llvm.insertvalue %314, %313[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb22(%30 : i64)
  ^bb22(%316: i64):  // 2 preds: ^bb21, ^bb23
    %317 = llvm.icmp "slt" %316, %28 : i64
    llvm.cond_br %317, ^bb23, ^bb24
  ^bb23:  // pred: ^bb22
    %318 = llvm.getelementptr %308[%316] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %319 = llvm.load %318 : !llvm.ptr -> vector<4xf64>
    %320 = llvm.extractvalue %155[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %321 = llvm.extractvalue %155[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %322 = llvm.getelementptr %320[%321] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %323 = llvm.mlir.constant(16 : index) : i64
    %324 = llvm.mul %316, %323  : i64
    %325 = llvm.add %324, %30  : i64
    %326 = llvm.getelementptr %322[%325] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %319, %326 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %327 = llvm.add %316, %28  : i64
    llvm.br ^bb22(%327 : i64)
  ^bb24:  // pred: ^bb22
    %328 = llvm.add %76, %28  : i64
    llvm.br ^bb11(%328 : i64)
  ^bb25:  // pred: ^bb11
    %329 = llvm.add %74, %29  : i64
    llvm.br ^bb9(%329 : i64)
  ^bb26:  // pred: ^bb9
    %330 = llvm.add %72, %28  : i64
    llvm.br ^bb7(%330 : i64)
  ^bb27:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
