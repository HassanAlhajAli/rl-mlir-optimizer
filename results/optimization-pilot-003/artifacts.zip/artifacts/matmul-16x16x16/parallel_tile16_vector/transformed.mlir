#map = affine_map<(d0, d1) -> (d0, 0, d1)>
#map1 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<16x16xf64>, %arg1: memref<16x16xf64>, %arg2: memref<16x16xf64>) attributes {llvm.emit_c_interface} {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c1_0 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_1 = arith.constant 0 : index
    %c16_2 = arith.constant 16 : index
    %c0_3 = arith.constant 0 : index
    %c0_4 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<16x16xf64>)
    %c0_5 = arith.constant 0 : index
    %c16_6 = arith.constant 16 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_5 to %c16_6 step %c16_7 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 16] [1, 1] : memref<16x16xf64> to memref<16x16xf64, strided<[16, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [16, 16] [1, 1] : memref<16x16xf64> to memref<16x16xf64, strided<[16, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c16_10 = arith.constant 16 : index
      %c16_11 = arith.constant 16 : index
      scf.for %arg4 = %c0_9 to %c16_10 step %c16_11 {
        %subview_12 = memref.subview %arg1[0, %arg4] [16, 16] [1, 1] : memref<16x16xf64> to memref<16x16xf64, strided<[16, 1], offset: ?>>
        %subview_13 = memref.subview %subview_8[0, %arg4] [16, 16] [1, 1] : memref<16x16xf64, strided<[16, 1], offset: ?>> to memref<16x16xf64, strided<[16, 1], offset: ?>>
        %c0_14 = arith.constant 0 : index
        %c16_15 = arith.constant 16 : index
        %c1_16 = arith.constant 1 : index
        %c0_17 = arith.constant 0 : index
        %c16_18 = arith.constant 16 : index
        %c4_19 = arith.constant 4 : index
        %c0_20 = arith.constant 0 : index
        %c16_21 = arith.constant 16 : index
        %c1_22 = arith.constant 1 : index
        scf.for %arg5 = %c0_14 to %c16_15 step %c1_16 {
          scf.for %arg6 = %c0_17 to %c16_18 step %c4_19 {
            scf.for %arg7 = %c0_20 to %c16_21 step %c1_22 {
              %subview_23 = memref.subview %subview[%arg5, %arg7] [1, 1] [1, 1] : memref<16x16xf64, strided<[16, 1], offset: ?>> to memref<1x1xf64, strided<[16, 1], offset: ?>>
              %subview_24 = memref.subview %subview_12[%arg7, %arg6] [1, 4] [1, 1] : memref<16x16xf64, strided<[16, 1], offset: ?>> to memref<1x4xf64, strided<[16, 1], offset: ?>>
              %subview_25 = memref.subview %subview_13[%arg5, %arg6] [1, 4] [1, 1] : memref<16x16xf64, strided<[16, 1], offset: ?>> to memref<1x4xf64, strided<[16, 1], offset: ?>>
              %c1_26 = arith.constant 1 : index
              %c4_27 = arith.constant 4 : index
              %c1_28 = arith.constant 1 : index
              %c0_29 = arith.constant 0 : index
              %cst_30 = arith.constant 0.000000e+00 : f64
              %0 = vector.transfer_read %subview_23[%c0_29, %c0_29], %cst_30 {permutation_map = #map} : memref<1x1xf64, strided<[16, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_31 = arith.constant 0.000000e+00 : f64
              %1 = vector.transfer_read %subview_24[%c0_29, %c0_29], %cst_31 {permutation_map = #map1} : memref<1x4xf64, strided<[16, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_32 = arith.constant 0.000000e+00 : f64
              %2 = vector.transfer_read %subview_25[%c0_29, %c0_29], %cst_32 : memref<1x4xf64, strided<[16, 1], offset: ?>>, vector<1x4xf64>
              %3 = arith.mulf %0, %1 : vector<1x4x1xf64>
              %4 = vector.multi_reduction <add>, %3, %2 [2] : vector<1x4x1xf64> to vector<1x4xf64>
              %c0_33 = arith.constant 0 : index
              vector.transfer_write %4, %subview_25[%c0_33, %c0_33] : vector<1x4xf64>, memref<1x4xf64, strided<[16, 1], offset: ?>>
            }
          }
        }
      }
    }
    return
  }
}
