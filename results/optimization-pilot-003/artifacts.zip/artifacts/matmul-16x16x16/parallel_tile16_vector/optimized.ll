; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader14.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %15, i8 0, i64 2048, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  br label %.preheader14

.preheader14:                                     ; preds = %.preheader14.preheader, %182
  %21 = phi i64 [ %183, %182 ], [ 0, %.preheader14.preheader ]
  %22 = shl i64 %21, 4
  %23 = getelementptr double, ptr %15, i64 %22
  %.promoted = load <4 x double>, ptr %23, align 8
  br label %.critedge

.critedge:                                        ; preds = %.preheader14, %.critedge
  %24 = phi i64 [ 0, %.preheader14 ], [ %46, %.critedge ]
  %25 = phi <4 x double> [ %.promoted, %.preheader14 ], [ %45, %.critedge ]
  %26 = or disjoint i64 %24, %22
  %27 = shl nuw nsw i64 %24, 4
  %28 = getelementptr double, ptr %1, i64 %26
  %29 = load double, ptr %28, align 8
  %30 = insertelement <1 x double> poison, double %29, i64 0
  %gep = getelementptr double, ptr %8, i64 %27
  %31 = load <4 x double>, ptr %gep, align 8
  %32 = shufflevector <4 x double> %31, <4 x double> poison, <1 x i32> zeroinitializer
  %33 = shufflevector <4 x double> %31, <4 x double> poison, <1 x i32> <i32 1>
  %34 = shufflevector <4 x double> %31, <4 x double> poison, <1 x i32> <i32 2>
  %35 = shufflevector <4 x double> %31, <4 x double> poison, <1 x i32> <i32 3>
  %36 = fmul <1 x double> %30, %32
  %37 = fmul <1 x double> %30, %33
  %38 = fmul <1 x double> %30, %34
  %39 = shufflevector <1 x double> %38, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %40 = fmul <1 x double> %30, %35
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = shufflevector <1 x double> %36, <1 x double> %37, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %43 = shufflevector <4 x double> %42, <4 x double> %39, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %45 = fadd <4 x double> %25, %44
  store <4 x double> %45, ptr %23, align 8
  %46 = add nuw nsw i64 %24, 1
  %exitcond.not = icmp eq i64 %46, 16
  br i1 %exitcond.not, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %47 = getelementptr double, ptr %23, i64 4
  %.promoted.1 = load <4 x double>, ptr %47, align 8
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %48 = phi i64 [ 0, %.preheader.1 ], [ %91, %.critedge.1 ]
  %49 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %90, %.critedge.1 ]
  %50 = or disjoint i64 %48, %22
  %51 = shl nuw nsw i64 %48, 4
  %52 = getelementptr double, ptr %1, i64 %50
  %53 = load double, ptr %52, align 8
  %54 = insertelement <1 x double> poison, double %53, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %51
  %55 = load <4 x double>, ptr %gep.1, align 8
  %56 = shufflevector <4 x double> %55, <4 x double> poison, <1 x i32> zeroinitializer
  %57 = shufflevector <4 x double> %55, <4 x double> poison, <1 x i32> <i32 1>
  %58 = shufflevector <4 x double> %55, <4 x double> poison, <1 x i32> <i32 2>
  %59 = shufflevector <4 x double> %55, <4 x double> poison, <1 x i32> <i32 3>
  %60 = fmul <1 x double> %54, %56
  %61 = fmul <1 x double> %54, %57
  %62 = fmul <1 x double> %54, %58
  %63 = shufflevector <1 x double> %62, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %64 = fmul <1 x double> %54, %59
  %65 = shufflevector <1 x double> %64, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %66 = shufflevector <1 x double> %60, <1 x double> %61, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %63, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %68 = shufflevector <4 x double> %67, <4 x double> %65, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %69 = fadd <4 x double> %49, %68
  store <4 x double> %69, ptr %47, align 8
  %70 = or disjoint i64 %48, 1
  %71 = or disjoint i64 %70, %22
  %72 = shl nuw nsw i64 %70, 4
  %73 = getelementptr double, ptr %1, i64 %71
  %74 = load double, ptr %73, align 8
  %75 = insertelement <1 x double> poison, double %74, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %72
  %76 = load <4 x double>, ptr %gep.1.1, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %75, %77
  %82 = fmul <1 x double> %75, %78
  %83 = fmul <1 x double> %75, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %75, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %69, %89
  store <4 x double> %90, ptr %47, align 8
  %91 = add nuw nsw i64 %48, 2
  %exitcond.1.not.1 = icmp eq i64 %91, 16
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %92 = getelementptr double, ptr %23, i64 8
  %.promoted.2 = load <4 x double>, ptr %92, align 8
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %93 = phi i64 [ 0, %.preheader.2 ], [ %136, %.critedge.2 ]
  %94 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %135, %.critedge.2 ]
  %95 = or disjoint i64 %93, %22
  %96 = shl nuw nsw i64 %93, 4
  %97 = getelementptr double, ptr %1, i64 %95
  %98 = load double, ptr %97, align 8
  %99 = insertelement <1 x double> poison, double %98, i64 0
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %96
  %100 = load <4 x double>, ptr %gep.2, align 8
  %101 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> zeroinitializer
  %102 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 1>
  %103 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 2>
  %104 = shufflevector <4 x double> %100, <4 x double> poison, <1 x i32> <i32 3>
  %105 = fmul <1 x double> %99, %101
  %106 = fmul <1 x double> %99, %102
  %107 = fmul <1 x double> %99, %103
  %108 = shufflevector <1 x double> %107, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %109 = fmul <1 x double> %99, %104
  %110 = shufflevector <1 x double> %109, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <1 x double> %105, <1 x double> %106, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %112 = shufflevector <4 x double> %111, <4 x double> %108, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %110, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %114 = fadd <4 x double> %94, %113
  store <4 x double> %114, ptr %92, align 8
  %115 = or disjoint i64 %93, 1
  %116 = or disjoint i64 %115, %22
  %117 = shl nuw nsw i64 %115, 4
  %118 = getelementptr double, ptr %1, i64 %116
  %119 = load double, ptr %118, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %117
  %121 = load <4 x double>, ptr %gep.2.1, align 8
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> zeroinitializer
  %123 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 1>
  %124 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 2>
  %125 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 3>
  %126 = fmul <1 x double> %120, %122
  %127 = fmul <1 x double> %120, %123
  %128 = fmul <1 x double> %120, %124
  %129 = shufflevector <1 x double> %128, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %130 = fmul <1 x double> %120, %125
  %131 = shufflevector <1 x double> %130, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %132 = shufflevector <1 x double> %126, <1 x double> %127, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %129, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %131, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %135 = fadd <4 x double> %114, %134
  store <4 x double> %135, ptr %92, align 8
  %136 = add nuw nsw i64 %93, 2
  %exitcond.2.not.1 = icmp eq i64 %136, 16
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %137 = getelementptr double, ptr %23, i64 12
  %.promoted.3 = load <4 x double>, ptr %137, align 8
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %138 = phi i64 [ 0, %.preheader.3 ], [ %181, %.critedge.3 ]
  %139 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %180, %.critedge.3 ]
  %140 = or disjoint i64 %138, %22
  %141 = shl nuw nsw i64 %138, 4
  %142 = getelementptr double, ptr %1, i64 %140
  %143 = load double, ptr %142, align 8
  %144 = insertelement <1 x double> poison, double %143, i64 0
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %141
  %145 = load <4 x double>, ptr %gep.3, align 8
  %146 = shufflevector <4 x double> %145, <4 x double> poison, <1 x i32> zeroinitializer
  %147 = shufflevector <4 x double> %145, <4 x double> poison, <1 x i32> <i32 1>
  %148 = shufflevector <4 x double> %145, <4 x double> poison, <1 x i32> <i32 2>
  %149 = shufflevector <4 x double> %145, <4 x double> poison, <1 x i32> <i32 3>
  %150 = fmul <1 x double> %144, %146
  %151 = fmul <1 x double> %144, %147
  %152 = fmul <1 x double> %144, %148
  %153 = shufflevector <1 x double> %152, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %154 = fmul <1 x double> %144, %149
  %155 = shufflevector <1 x double> %154, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %156 = shufflevector <1 x double> %150, <1 x double> %151, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %157 = shufflevector <4 x double> %156, <4 x double> %153, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %158 = shufflevector <4 x double> %157, <4 x double> %155, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %159 = fadd <4 x double> %139, %158
  store <4 x double> %159, ptr %137, align 8
  %160 = or disjoint i64 %138, 1
  %161 = or disjoint i64 %160, %22
  %162 = shl nuw nsw i64 %160, 4
  %163 = getelementptr double, ptr %1, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = insertelement <1 x double> poison, double %164, i64 0
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %162
  %166 = load <4 x double>, ptr %gep.3.1, align 8
  %167 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> zeroinitializer
  %168 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 1>
  %169 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 2>
  %170 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 3>
  %171 = fmul <1 x double> %165, %167
  %172 = fmul <1 x double> %165, %168
  %173 = fmul <1 x double> %165, %169
  %174 = shufflevector <1 x double> %173, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %175 = fmul <1 x double> %165, %170
  %176 = shufflevector <1 x double> %175, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %177 = shufflevector <1 x double> %171, <1 x double> %172, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %174, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %176, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %180 = fadd <4 x double> %159, %179
  store <4 x double> %180, ptr %137, align 8
  %181 = add nuw nsw i64 %138, 2
  %exitcond.3.not.1 = icmp eq i64 %181, 16
  br i1 %exitcond.3.not.1, label %182, label %.critedge.3

182:                                              ; preds = %.critedge.3
  %183 = add nuw nsw i64 %21, 1
  %exitcond17.not = icmp eq i64 %183, 16
  br i1 %exitcond17.not, label %184, label %.preheader14

184:                                              ; preds = %182
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack32, i8 0, i64 2048, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 12
  br label %.preheader14.i

.preheader14.i:                                   ; preds = %165, %3
  %4 = phi i64 [ %166, %165 ], [ 0, %3 ]
  %5 = shl i64 %4, 4
  %6 = getelementptr double, ptr %.unpack32, i64 %5
  %.promoted.i = load <4 x double>, ptr %6, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader14.i
  %7 = phi i64 [ 0, %.preheader14.i ], [ %29, %.critedge.i ]
  %8 = phi <4 x double> [ %.promoted.i, %.preheader14.i ], [ %28, %.critedge.i ]
  %9 = or disjoint i64 %7, %5
  %10 = shl nuw nsw i64 %7, 4
  %11 = getelementptr double, ptr %.unpack2, i64 %9
  %12 = load double, ptr %11, align 8
  %13 = insertelement <1 x double> poison, double %12, i64 0
  %gep.i = getelementptr double, ptr %.unpack17, i64 %10
  %14 = load <4 x double>, ptr %gep.i, align 8
  %15 = shufflevector <4 x double> %14, <4 x double> poison, <1 x i32> zeroinitializer
  %16 = shufflevector <4 x double> %14, <4 x double> poison, <1 x i32> <i32 1>
  %17 = shufflevector <4 x double> %14, <4 x double> poison, <1 x i32> <i32 2>
  %18 = shufflevector <4 x double> %14, <4 x double> poison, <1 x i32> <i32 3>
  %19 = fmul <1 x double> %13, %15
  %20 = fmul <1 x double> %13, %16
  %21 = fmul <1 x double> %13, %17
  %22 = shufflevector <1 x double> %21, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = fmul <1 x double> %13, %18
  %24 = shufflevector <1 x double> %23, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = shufflevector <1 x double> %19, <1 x double> %20, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %26 = shufflevector <4 x double> %25, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %27 = shufflevector <4 x double> %26, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %28 = fadd <4 x double> %8, %27
  store <4 x double> %28, ptr %6, align 8
  %29 = add nuw nsw i64 %7, 1
  %exitcond.not.i = icmp eq i64 %29, 16
  br i1 %exitcond.not.i, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %30 = getelementptr double, ptr %6, i64 4
  %.promoted.1.i = load <4 x double>, ptr %30, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %31 = phi i64 [ 0, %.preheader.1.i ], [ %74, %.critedge.1.i ]
  %32 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %73, %.critedge.1.i ]
  %33 = or disjoint i64 %31, %5
  %34 = shl nuw nsw i64 %31, 4
  %35 = getelementptr double, ptr %.unpack2, i64 %33
  %36 = load double, ptr %35, align 8
  %37 = insertelement <1 x double> poison, double %36, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %34
  %38 = load <4 x double>, ptr %gep.1.i, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %37, %39
  %44 = fmul <1 x double> %37, %40
  %45 = fmul <1 x double> %37, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %37, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %32, %51
  store <4 x double> %52, ptr %30, align 8
  %53 = or disjoint i64 %31, 1
  %54 = or disjoint i64 %53, %5
  %55 = shl nuw nsw i64 %53, 4
  %56 = getelementptr double, ptr %.unpack2, i64 %54
  %57 = load double, ptr %56, align 8
  %58 = insertelement <1 x double> poison, double %57, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %55
  %59 = load <4 x double>, ptr %gep.1.i.1, align 8
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> zeroinitializer
  %61 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 1>
  %62 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 2>
  %63 = shufflevector <4 x double> %59, <4 x double> poison, <1 x i32> <i32 3>
  %64 = fmul <1 x double> %58, %60
  %65 = fmul <1 x double> %58, %61
  %66 = fmul <1 x double> %58, %62
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = fmul <1 x double> %58, %63
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = shufflevector <1 x double> %64, <1 x double> %65, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %73 = fadd <4 x double> %52, %72
  store <4 x double> %73, ptr %30, align 8
  %74 = add nuw nsw i64 %31, 2
  %exitcond.1.not.i.1 = icmp eq i64 %74, 16
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %75 = getelementptr double, ptr %6, i64 8
  %.promoted.2.i = load <4 x double>, ptr %75, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %76 = phi i64 [ 0, %.preheader.2.i ], [ %119, %.critedge.2.i ]
  %77 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %118, %.critedge.2.i ]
  %78 = or disjoint i64 %76, %5
  %79 = shl nuw nsw i64 %76, 4
  %80 = getelementptr double, ptr %.unpack2, i64 %78
  %81 = load double, ptr %80, align 8
  %82 = insertelement <1 x double> poison, double %81, i64 0
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %79
  %83 = load <4 x double>, ptr %gep.2.i, align 8
  %84 = shufflevector <4 x double> %83, <4 x double> poison, <1 x i32> zeroinitializer
  %85 = shufflevector <4 x double> %83, <4 x double> poison, <1 x i32> <i32 1>
  %86 = shufflevector <4 x double> %83, <4 x double> poison, <1 x i32> <i32 2>
  %87 = shufflevector <4 x double> %83, <4 x double> poison, <1 x i32> <i32 3>
  %88 = fmul <1 x double> %82, %84
  %89 = fmul <1 x double> %82, %85
  %90 = fmul <1 x double> %82, %86
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = fmul <1 x double> %82, %87
  %93 = shufflevector <1 x double> %92, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %94 = shufflevector <1 x double> %88, <1 x double> %89, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %95 = shufflevector <4 x double> %94, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %93, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %97 = fadd <4 x double> %77, %96
  store <4 x double> %97, ptr %75, align 8
  %98 = or disjoint i64 %76, 1
  %99 = or disjoint i64 %98, %5
  %100 = shl nuw nsw i64 %98, 4
  %101 = getelementptr double, ptr %.unpack2, i64 %99
  %102 = load double, ptr %101, align 8
  %103 = insertelement <1 x double> poison, double %102, i64 0
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %100
  %104 = load <4 x double>, ptr %gep.2.i.1, align 8
  %105 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> zeroinitializer
  %106 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 1>
  %107 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 2>
  %108 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 3>
  %109 = fmul <1 x double> %103, %105
  %110 = fmul <1 x double> %103, %106
  %111 = fmul <1 x double> %103, %107
  %112 = shufflevector <1 x double> %111, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %113 = fmul <1 x double> %103, %108
  %114 = shufflevector <1 x double> %113, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %115 = shufflevector <1 x double> %109, <1 x double> %110, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %116 = shufflevector <4 x double> %115, <4 x double> %112, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %117 = shufflevector <4 x double> %116, <4 x double> %114, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %118 = fadd <4 x double> %97, %117
  store <4 x double> %118, ptr %75, align 8
  %119 = add nuw nsw i64 %76, 2
  %exitcond.2.not.i.1 = icmp eq i64 %119, 16
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %120 = getelementptr double, ptr %6, i64 12
  %.promoted.3.i = load <4 x double>, ptr %120, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %121 = phi i64 [ 0, %.preheader.3.i ], [ %164, %.critedge.3.i ]
  %122 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %163, %.critedge.3.i ]
  %123 = or disjoint i64 %121, %5
  %124 = shl nuw nsw i64 %121, 4
  %125 = getelementptr double, ptr %.unpack2, i64 %123
  %126 = load double, ptr %125, align 8
  %127 = insertelement <1 x double> poison, double %126, i64 0
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %124
  %128 = load <4 x double>, ptr %gep.3.i, align 8
  %129 = shufflevector <4 x double> %128, <4 x double> poison, <1 x i32> zeroinitializer
  %130 = shufflevector <4 x double> %128, <4 x double> poison, <1 x i32> <i32 1>
  %131 = shufflevector <4 x double> %128, <4 x double> poison, <1 x i32> <i32 2>
  %132 = shufflevector <4 x double> %128, <4 x double> poison, <1 x i32> <i32 3>
  %133 = fmul <1 x double> %127, %129
  %134 = fmul <1 x double> %127, %130
  %135 = fmul <1 x double> %127, %131
  %136 = shufflevector <1 x double> %135, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %137 = fmul <1 x double> %127, %132
  %138 = shufflevector <1 x double> %137, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %139 = shufflevector <1 x double> %133, <1 x double> %134, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %140 = shufflevector <4 x double> %139, <4 x double> %136, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %141 = shufflevector <4 x double> %140, <4 x double> %138, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %142 = fadd <4 x double> %122, %141
  store <4 x double> %142, ptr %120, align 8
  %143 = or disjoint i64 %121, 1
  %144 = or disjoint i64 %143, %5
  %145 = shl nuw nsw i64 %143, 4
  %146 = getelementptr double, ptr %.unpack2, i64 %144
  %147 = load double, ptr %146, align 8
  %148 = insertelement <1 x double> poison, double %147, i64 0
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %145
  %149 = load <4 x double>, ptr %gep.3.i.1, align 8
  %150 = shufflevector <4 x double> %149, <4 x double> poison, <1 x i32> zeroinitializer
  %151 = shufflevector <4 x double> %149, <4 x double> poison, <1 x i32> <i32 1>
  %152 = shufflevector <4 x double> %149, <4 x double> poison, <1 x i32> <i32 2>
  %153 = shufflevector <4 x double> %149, <4 x double> poison, <1 x i32> <i32 3>
  %154 = fmul <1 x double> %148, %150
  %155 = fmul <1 x double> %148, %151
  %156 = fmul <1 x double> %148, %152
  %157 = shufflevector <1 x double> %156, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %158 = fmul <1 x double> %148, %153
  %159 = shufflevector <1 x double> %158, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %160 = shufflevector <1 x double> %154, <1 x double> %155, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %161 = shufflevector <4 x double> %160, <4 x double> %157, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %162 = shufflevector <4 x double> %161, <4 x double> %159, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %163 = fadd <4 x double> %142, %162
  store <4 x double> %163, ptr %120, align 8
  %164 = add nuw nsw i64 %121, 2
  %exitcond.3.not.i.1 = icmp eq i64 %164, 16
  br i1 %exitcond.3.not.i.1, label %165, label %.critedge.3.i

165:                                              ; preds = %.critedge.3.i
  %166 = add nuw nsw i64 %4, 1
  %exitcond17.not.i = icmp eq i64 %166, 16
  br i1 %exitcond17.not.i, label %kernel.exit, label %.preheader14.i

kernel.exit:                                      ; preds = %165
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %10, i8 0, i64 2048, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 12
  br label %.preheader14.i

.preheader14.i:                                   ; preds = %172, %1
  %11 = phi i64 [ %173, %172 ], [ 0, %1 ]
  %12 = shl i64 %11, 4
  %13 = getelementptr double, ptr %10, i64 %12
  %.promoted.i = load <4 x double>, ptr %13, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader14.i
  %14 = phi i64 [ 0, %.preheader14.i ], [ %36, %.critedge.i ]
  %15 = phi <4 x double> [ %.promoted.i, %.preheader14.i ], [ %35, %.critedge.i ]
  %16 = or disjoint i64 %14, %12
  %17 = shl nuw nsw i64 %14, 4
  %18 = getelementptr double, ptr %4, i64 %16
  %19 = load double, ptr %18, align 8
  %20 = insertelement <1 x double> poison, double %19, i64 0
  %gep.i = getelementptr double, ptr %7, i64 %17
  %21 = load <4 x double>, ptr %gep.i, align 8
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> zeroinitializer
  %23 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 1>
  %24 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 2>
  %25 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 3>
  %26 = fmul <1 x double> %20, %22
  %27 = fmul <1 x double> %20, %23
  %28 = fmul <1 x double> %20, %24
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = fmul <1 x double> %20, %25
  %31 = shufflevector <1 x double> %30, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = shufflevector <1 x double> %26, <1 x double> %27, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = fadd <4 x double> %15, %34
  store <4 x double> %35, ptr %13, align 8
  %36 = add nuw nsw i64 %14, 1
  %exitcond.not.i = icmp eq i64 %36, 16
  br i1 %exitcond.not.i, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %37 = getelementptr double, ptr %13, i64 4
  %.promoted.1.i = load <4 x double>, ptr %37, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %38 = phi i64 [ 0, %.preheader.1.i ], [ %81, %.critedge.1.i ]
  %39 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %80, %.critedge.1.i ]
  %40 = or disjoint i64 %38, %12
  %41 = shl nuw nsw i64 %38, 4
  %42 = getelementptr double, ptr %4, i64 %40
  %43 = load double, ptr %42, align 8
  %44 = insertelement <1 x double> poison, double %43, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %41
  %45 = load <4 x double>, ptr %gep.1.i, align 8
  %46 = shufflevector <4 x double> %45, <4 x double> poison, <1 x i32> zeroinitializer
  %47 = shufflevector <4 x double> %45, <4 x double> poison, <1 x i32> <i32 1>
  %48 = shufflevector <4 x double> %45, <4 x double> poison, <1 x i32> <i32 2>
  %49 = shufflevector <4 x double> %45, <4 x double> poison, <1 x i32> <i32 3>
  %50 = fmul <1 x double> %44, %46
  %51 = fmul <1 x double> %44, %47
  %52 = fmul <1 x double> %44, %48
  %53 = shufflevector <1 x double> %52, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %54 = fmul <1 x double> %44, %49
  %55 = shufflevector <1 x double> %54, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <1 x double> %50, <1 x double> %51, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %53, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %55, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %59 = fadd <4 x double> %39, %58
  store <4 x double> %59, ptr %37, align 8
  %60 = or disjoint i64 %38, 1
  %61 = or disjoint i64 %60, %12
  %62 = shl nuw nsw i64 %60, 4
  %63 = getelementptr double, ptr %4, i64 %61
  %64 = load double, ptr %63, align 8
  %65 = insertelement <1 x double> poison, double %64, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %62
  %66 = load <4 x double>, ptr %gep.1.i.1, align 8
  %67 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> zeroinitializer
  %68 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 1>
  %69 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 2>
  %70 = shufflevector <4 x double> %66, <4 x double> poison, <1 x i32> <i32 3>
  %71 = fmul <1 x double> %65, %67
  %72 = fmul <1 x double> %65, %68
  %73 = fmul <1 x double> %65, %69
  %74 = shufflevector <1 x double> %73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = fmul <1 x double> %65, %70
  %76 = shufflevector <1 x double> %75, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = shufflevector <1 x double> %71, <1 x double> %72, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %79 = shufflevector <4 x double> %78, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %80 = fadd <4 x double> %59, %79
  store <4 x double> %80, ptr %37, align 8
  %81 = add nuw nsw i64 %38, 2
  %exitcond.1.not.i.1 = icmp eq i64 %81, 16
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %82 = getelementptr double, ptr %13, i64 8
  %.promoted.2.i = load <4 x double>, ptr %82, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %83 = phi i64 [ 0, %.preheader.2.i ], [ %126, %.critedge.2.i ]
  %84 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %125, %.critedge.2.i ]
  %85 = or disjoint i64 %83, %12
  %86 = shl nuw nsw i64 %83, 4
  %87 = getelementptr double, ptr %4, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = insertelement <1 x double> poison, double %88, i64 0
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %86
  %90 = load <4 x double>, ptr %gep.2.i, align 8
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> zeroinitializer
  %92 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 1>
  %93 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 2>
  %94 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 3>
  %95 = fmul <1 x double> %89, %91
  %96 = fmul <1 x double> %89, %92
  %97 = fmul <1 x double> %89, %93
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = fmul <1 x double> %89, %94
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %95, <1 x double> %96, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %104 = fadd <4 x double> %84, %103
  store <4 x double> %104, ptr %82, align 8
  %105 = or disjoint i64 %83, 1
  %106 = or disjoint i64 %105, %12
  %107 = shl nuw nsw i64 %105, 4
  %108 = getelementptr double, ptr %4, i64 %106
  %109 = load double, ptr %108, align 8
  %110 = insertelement <1 x double> poison, double %109, i64 0
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %107
  %111 = load <4 x double>, ptr %gep.2.i.1, align 8
  %112 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> zeroinitializer
  %113 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 1>
  %114 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 2>
  %115 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 3>
  %116 = fmul <1 x double> %110, %112
  %117 = fmul <1 x double> %110, %113
  %118 = fmul <1 x double> %110, %114
  %119 = shufflevector <1 x double> %118, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %120 = fmul <1 x double> %110, %115
  %121 = shufflevector <1 x double> %120, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %122 = shufflevector <1 x double> %116, <1 x double> %117, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %123 = shufflevector <4 x double> %122, <4 x double> %119, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %124 = shufflevector <4 x double> %123, <4 x double> %121, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %125 = fadd <4 x double> %104, %124
  store <4 x double> %125, ptr %82, align 8
  %126 = add nuw nsw i64 %83, 2
  %exitcond.2.not.i.1 = icmp eq i64 %126, 16
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %127 = getelementptr double, ptr %13, i64 12
  %.promoted.3.i = load <4 x double>, ptr %127, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %128 = phi i64 [ 0, %.preheader.3.i ], [ %171, %.critedge.3.i ]
  %129 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %170, %.critedge.3.i ]
  %130 = or disjoint i64 %128, %12
  %131 = shl nuw nsw i64 %128, 4
  %132 = getelementptr double, ptr %4, i64 %130
  %133 = load double, ptr %132, align 8
  %134 = insertelement <1 x double> poison, double %133, i64 0
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %131
  %135 = load <4 x double>, ptr %gep.3.i, align 8
  %136 = shufflevector <4 x double> %135, <4 x double> poison, <1 x i32> zeroinitializer
  %137 = shufflevector <4 x double> %135, <4 x double> poison, <1 x i32> <i32 1>
  %138 = shufflevector <4 x double> %135, <4 x double> poison, <1 x i32> <i32 2>
  %139 = shufflevector <4 x double> %135, <4 x double> poison, <1 x i32> <i32 3>
  %140 = fmul <1 x double> %134, %136
  %141 = fmul <1 x double> %134, %137
  %142 = fmul <1 x double> %134, %138
  %143 = shufflevector <1 x double> %142, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %144 = fmul <1 x double> %134, %139
  %145 = shufflevector <1 x double> %144, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %146 = shufflevector <1 x double> %140, <1 x double> %141, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %147 = shufflevector <4 x double> %146, <4 x double> %143, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %148 = shufflevector <4 x double> %147, <4 x double> %145, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %149 = fadd <4 x double> %129, %148
  store <4 x double> %149, ptr %127, align 8
  %150 = or disjoint i64 %128, 1
  %151 = or disjoint i64 %150, %12
  %152 = shl nuw nsw i64 %150, 4
  %153 = getelementptr double, ptr %4, i64 %151
  %154 = load double, ptr %153, align 8
  %155 = insertelement <1 x double> poison, double %154, i64 0
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %152
  %156 = load <4 x double>, ptr %gep.3.i.1, align 8
  %157 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> zeroinitializer
  %158 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 1>
  %159 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 2>
  %160 = shufflevector <4 x double> %156, <4 x double> poison, <1 x i32> <i32 3>
  %161 = fmul <1 x double> %155, %157
  %162 = fmul <1 x double> %155, %158
  %163 = fmul <1 x double> %155, %159
  %164 = shufflevector <1 x double> %163, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %165 = fmul <1 x double> %155, %160
  %166 = shufflevector <1 x double> %165, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %167 = shufflevector <1 x double> %161, <1 x double> %162, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %168 = shufflevector <4 x double> %167, <4 x double> %164, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %169 = shufflevector <4 x double> %168, <4 x double> %166, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %170 = fadd <4 x double> %149, %169
  store <4 x double> %170, ptr %127, align 8
  %171 = add nuw nsw i64 %128, 2
  %exitcond.3.not.i.1 = icmp eq i64 %171, 16
  br i1 %exitcond.3.not.i.1, label %172, label %.critedge.3.i

172:                                              ; preds = %.critedge.3.i
  %173 = add nuw nsw i64 %11, 1
  %exitcond17.not.i = icmp eq i64 %173, 16
  br i1 %exitcond17.not.i, label %kernel.exit, label %.preheader14.i

kernel.exit:                                      ; preds = %172
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack32.i, i8 0, i64 2048, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  %invariant.gep.2.i.i = getelementptr double, ptr %.unpack17.i, i64 8
  %invariant.gep.3.i.i = getelementptr double, ptr %.unpack17.i, i64 12
  br label %.preheader14.i.i

.preheader14.i.i:                                 ; preds = %171, %1
  %10 = phi i64 [ %172, %171 ], [ 0, %1 ]
  %11 = shl i64 %10, 4
  %12 = getelementptr double, ptr %.unpack32.i, i64 %11
  %.promoted.i.i = load <4 x double>, ptr %12, align 8
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader14.i.i
  %13 = phi i64 [ 0, %.preheader14.i.i ], [ %35, %.critedge.i.i ]
  %14 = phi <4 x double> [ %.promoted.i.i, %.preheader14.i.i ], [ %34, %.critedge.i.i ]
  %15 = or disjoint i64 %13, %11
  %16 = shl nuw nsw i64 %13, 4
  %17 = getelementptr double, ptr %.unpack2.i, i64 %15
  %18 = load double, ptr %17, align 8
  %19 = insertelement <1 x double> poison, double %18, i64 0
  %gep.i.i = getelementptr double, ptr %.unpack17.i, i64 %16
  %20 = load <4 x double>, ptr %gep.i.i, align 8
  %21 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> zeroinitializer
  %22 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 1>
  %23 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 2>
  %24 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 3>
  %25 = fmul <1 x double> %19, %21
  %26 = fmul <1 x double> %19, %22
  %27 = fmul <1 x double> %19, %23
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = fmul <1 x double> %19, %24
  %30 = shufflevector <1 x double> %29, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = shufflevector <1 x double> %25, <1 x double> %26, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %32 = shufflevector <4 x double> %31, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %34 = fadd <4 x double> %14, %33
  store <4 x double> %34, ptr %12, align 8
  %35 = add nuw nsw i64 %13, 1
  %exitcond.not.i.i = icmp eq i64 %35, 16
  br i1 %exitcond.not.i.i, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %36 = getelementptr double, ptr %12, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %36, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %37 = phi i64 [ 0, %.preheader.1.i.i ], [ %80, %.critedge.1.i.i ]
  %38 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %79, %.critedge.1.i.i ]
  %39 = or disjoint i64 %37, %11
  %40 = shl nuw nsw i64 %37, 4
  %41 = getelementptr double, ptr %.unpack2.i, i64 %39
  %42 = load double, ptr %41, align 8
  %43 = insertelement <1 x double> poison, double %42, i64 0
  %gep.1.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %40
  %44 = load <4 x double>, ptr %gep.1.i.i, align 8
  %45 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> zeroinitializer
  %46 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 1>
  %47 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 2>
  %48 = shufflevector <4 x double> %44, <4 x double> poison, <1 x i32> <i32 3>
  %49 = fmul <1 x double> %43, %45
  %50 = fmul <1 x double> %43, %46
  %51 = fmul <1 x double> %43, %47
  %52 = shufflevector <1 x double> %51, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %53 = fmul <1 x double> %43, %48
  %54 = shufflevector <1 x double> %53, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <1 x double> %49, <1 x double> %50, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %56 = shufflevector <4 x double> %55, <4 x double> %52, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %54, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %58 = fadd <4 x double> %38, %57
  store <4 x double> %58, ptr %36, align 8
  %59 = or disjoint i64 %37, 1
  %60 = or disjoint i64 %59, %11
  %61 = shl nuw nsw i64 %59, 4
  %62 = getelementptr double, ptr %.unpack2.i, i64 %60
  %63 = load double, ptr %62, align 8
  %64 = insertelement <1 x double> poison, double %63, i64 0
  %gep.1.i.i.1 = getelementptr double, ptr %invariant.gep.1.i.i, i64 %61
  %65 = load <4 x double>, ptr %gep.1.i.i.1, align 8
  %66 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> zeroinitializer
  %67 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 1>
  %68 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 2>
  %69 = shufflevector <4 x double> %65, <4 x double> poison, <1 x i32> <i32 3>
  %70 = fmul <1 x double> %64, %66
  %71 = fmul <1 x double> %64, %67
  %72 = fmul <1 x double> %64, %68
  %73 = shufflevector <1 x double> %72, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = fmul <1 x double> %64, %69
  %75 = shufflevector <1 x double> %74, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %76 = shufflevector <1 x double> %70, <1 x double> %71, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %77 = shufflevector <4 x double> %76, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %78 = shufflevector <4 x double> %77, <4 x double> %75, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %79 = fadd <4 x double> %58, %78
  store <4 x double> %79, ptr %36, align 8
  %80 = add nuw nsw i64 %37, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %80, 16
  br i1 %exitcond.1.not.i.i.1, label %.preheader.2.i.i, label %.critedge.1.i.i

.preheader.2.i.i:                                 ; preds = %.critedge.1.i.i
  %81 = getelementptr double, ptr %12, i64 8
  %.promoted.2.i.i = load <4 x double>, ptr %81, align 8
  br label %.critedge.2.i.i

.critedge.2.i.i:                                  ; preds = %.critedge.2.i.i, %.preheader.2.i.i
  %82 = phi i64 [ 0, %.preheader.2.i.i ], [ %125, %.critedge.2.i.i ]
  %83 = phi <4 x double> [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %124, %.critedge.2.i.i ]
  %84 = or disjoint i64 %82, %11
  %85 = shl nuw nsw i64 %82, 4
  %86 = getelementptr double, ptr %.unpack2.i, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = insertelement <1 x double> poison, double %87, i64 0
  %gep.2.i.i = getelementptr double, ptr %invariant.gep.2.i.i, i64 %85
  %89 = load <4 x double>, ptr %gep.2.i.i, align 8
  %90 = shufflevector <4 x double> %89, <4 x double> poison, <1 x i32> zeroinitializer
  %91 = shufflevector <4 x double> %89, <4 x double> poison, <1 x i32> <i32 1>
  %92 = shufflevector <4 x double> %89, <4 x double> poison, <1 x i32> <i32 2>
  %93 = shufflevector <4 x double> %89, <4 x double> poison, <1 x i32> <i32 3>
  %94 = fmul <1 x double> %88, %90
  %95 = fmul <1 x double> %88, %91
  %96 = fmul <1 x double> %88, %92
  %97 = shufflevector <1 x double> %96, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %98 = fmul <1 x double> %88, %93
  %99 = shufflevector <1 x double> %98, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %100 = shufflevector <1 x double> %94, <1 x double> %95, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %97, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %99, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %103 = fadd <4 x double> %83, %102
  store <4 x double> %103, ptr %81, align 8
  %104 = or disjoint i64 %82, 1
  %105 = or disjoint i64 %104, %11
  %106 = shl nuw nsw i64 %104, 4
  %107 = getelementptr double, ptr %.unpack2.i, i64 %105
  %108 = load double, ptr %107, align 8
  %109 = insertelement <1 x double> poison, double %108, i64 0
  %gep.2.i.i.1 = getelementptr double, ptr %invariant.gep.2.i.i, i64 %106
  %110 = load <4 x double>, ptr %gep.2.i.i.1, align 8
  %111 = shufflevector <4 x double> %110, <4 x double> poison, <1 x i32> zeroinitializer
  %112 = shufflevector <4 x double> %110, <4 x double> poison, <1 x i32> <i32 1>
  %113 = shufflevector <4 x double> %110, <4 x double> poison, <1 x i32> <i32 2>
  %114 = shufflevector <4 x double> %110, <4 x double> poison, <1 x i32> <i32 3>
  %115 = fmul <1 x double> %109, %111
  %116 = fmul <1 x double> %109, %112
  %117 = fmul <1 x double> %109, %113
  %118 = shufflevector <1 x double> %117, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %119 = fmul <1 x double> %109, %114
  %120 = shufflevector <1 x double> %119, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %121 = shufflevector <1 x double> %115, <1 x double> %116, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %122 = shufflevector <4 x double> %121, <4 x double> %118, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %123 = shufflevector <4 x double> %122, <4 x double> %120, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %124 = fadd <4 x double> %103, %123
  store <4 x double> %124, ptr %81, align 8
  %125 = add nuw nsw i64 %82, 2
  %exitcond.2.not.i.i.1 = icmp eq i64 %125, 16
  br i1 %exitcond.2.not.i.i.1, label %.preheader.3.i.i, label %.critedge.2.i.i

.preheader.3.i.i:                                 ; preds = %.critedge.2.i.i
  %126 = getelementptr double, ptr %12, i64 12
  %.promoted.3.i.i = load <4 x double>, ptr %126, align 8
  br label %.critedge.3.i.i

.critedge.3.i.i:                                  ; preds = %.critedge.3.i.i, %.preheader.3.i.i
  %127 = phi i64 [ 0, %.preheader.3.i.i ], [ %170, %.critedge.3.i.i ]
  %128 = phi <4 x double> [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %169, %.critedge.3.i.i ]
  %129 = or disjoint i64 %127, %11
  %130 = shl nuw nsw i64 %127, 4
  %131 = getelementptr double, ptr %.unpack2.i, i64 %129
  %132 = load double, ptr %131, align 8
  %133 = insertelement <1 x double> poison, double %132, i64 0
  %gep.3.i.i = getelementptr double, ptr %invariant.gep.3.i.i, i64 %130
  %134 = load <4 x double>, ptr %gep.3.i.i, align 8
  %135 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> zeroinitializer
  %136 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 1>
  %137 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 2>
  %138 = shufflevector <4 x double> %134, <4 x double> poison, <1 x i32> <i32 3>
  %139 = fmul <1 x double> %133, %135
  %140 = fmul <1 x double> %133, %136
  %141 = fmul <1 x double> %133, %137
  %142 = shufflevector <1 x double> %141, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %143 = fmul <1 x double> %133, %138
  %144 = shufflevector <1 x double> %143, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %145 = shufflevector <1 x double> %139, <1 x double> %140, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %146 = shufflevector <4 x double> %145, <4 x double> %142, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %147 = shufflevector <4 x double> %146, <4 x double> %144, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %148 = fadd <4 x double> %128, %147
  store <4 x double> %148, ptr %126, align 8
  %149 = or disjoint i64 %127, 1
  %150 = or disjoint i64 %149, %11
  %151 = shl nuw nsw i64 %149, 4
  %152 = getelementptr double, ptr %.unpack2.i, i64 %150
  %153 = load double, ptr %152, align 8
  %154 = insertelement <1 x double> poison, double %153, i64 0
  %gep.3.i.i.1 = getelementptr double, ptr %invariant.gep.3.i.i, i64 %151
  %155 = load <4 x double>, ptr %gep.3.i.i.1, align 8
  %156 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> zeroinitializer
  %157 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 1>
  %158 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 2>
  %159 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 3>
  %160 = fmul <1 x double> %154, %156
  %161 = fmul <1 x double> %154, %157
  %162 = fmul <1 x double> %154, %158
  %163 = shufflevector <1 x double> %162, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %164 = fmul <1 x double> %154, %159
  %165 = shufflevector <1 x double> %164, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %166 = shufflevector <1 x double> %160, <1 x double> %161, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %167 = shufflevector <4 x double> %166, <4 x double> %163, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %168 = shufflevector <4 x double> %167, <4 x double> %165, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %169 = fadd <4 x double> %148, %168
  store <4 x double> %169, ptr %126, align 8
  %170 = add nuw nsw i64 %127, 2
  %exitcond.3.not.i.i.1 = icmp eq i64 %170, 16
  br i1 %exitcond.3.not.i.i.1, label %171, label %.critedge.3.i.i

171:                                              ; preds = %.critedge.3.i.i
  %172 = add nuw nsw i64 %10, 1
  %exitcond17.not.i.i = icmp eq i64 %172, 16
  br i1 %exitcond17.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader14.i.i

_mlir_ciface_kernel.exit:                         ; preds = %171
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
