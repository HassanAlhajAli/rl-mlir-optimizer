#map = affine_map<(d0) -> (-d0 + 8, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0, d1) -> (d0 - d1, 4)>
#map3 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map4 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<64x32xf64>, %arg1: memref<32x8xf64>, %arg2: memref<64x8xf64>) attributes {llvm.emit_c_interface} {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c1_0 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_1 = arith.constant 0 : index
    %c16_2 = arith.constant 16 : index
    %c0_3 = arith.constant 0 : index
    %c0_4 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<64x8xf64>)
    %c0_5 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c16_6 = arith.constant 16 : index
    scf.for %arg3 = %c0_5 to %c64 step %c16_6 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 32] [1, 1] : memref<64x32xf64> to memref<16x32xf64, strided<[32, 1], offset: ?>>
      %subview_7 = memref.subview %arg2[%arg3, 0] [16, 8] [1, 1] : memref<64x8xf64> to memref<16x8xf64, strided<[8, 1], offset: ?>>
      %c0_8 = arith.constant 0 : index
      %c8 = arith.constant 8 : index
      %c16_9 = arith.constant 16 : index
      scf.for %arg4 = %c0_8 to %c8 step %c16_9 {
        %0 = affine.min #map(%arg4)
        %1 = affine.min #map(%arg4)
        %subview_10 = memref.subview %arg1[0, %arg4] [32, %0] [1, 1] : memref<32x8xf64> to memref<32x?xf64, strided<[8, 1], offset: ?>>
        %subview_11 = memref.subview %subview_7[0, %arg4] [16, %1] [1, 1] : memref<16x8xf64, strided<[8, 1], offset: ?>> to memref<16x?xf64, strided<[8, 1], offset: ?>>
        %c1_12 = arith.constant 1 : index
        %c1_13 = arith.constant 1 : index
        %c0_14 = arith.constant 0 : index
        %c16_15 = arith.constant 16 : index
        %c1_16 = arith.constant 1 : index
        %c0_17 = arith.constant 0 : index
        %c4_18 = arith.constant 4 : index
        %c0_19 = arith.constant 0 : index
        %c32 = arith.constant 32 : index
        %c1_20 = arith.constant 1 : index
        scf.for %arg5 = %c0_14 to %c16_15 step %c1_16 {
          scf.for %arg6 = %c0_17 to %0 step %c4_18 {
            scf.for %arg7 = %c0_19 to %c32 step %c1_20 {
              %2 = affine.apply #map1(%0)
              %3 = affine.apply #map1(%0)
              %4 = affine.min #map2(%0, %arg6)
              %5 = affine.apply #map1(%0)
              %6 = affine.apply #map1(%0)
              %7 = affine.min #map2(%0, %arg6)
              %subview_21 = memref.subview %subview[%arg5, %arg7] [1, 1] [1, 1] : memref<16x32xf64, strided<[32, 1], offset: ?>> to memref<1x1xf64, strided<[32, 1], offset: ?>>
              %subview_22 = memref.subview %subview_10[%arg7, %arg6] [1, %4] [1, 1] : memref<32x?xf64, strided<[8, 1], offset: ?>> to memref<1x?xf64, strided<[8, 1], offset: ?>>
              %subview_23 = memref.subview %subview_11[%arg5, %arg6] [1, %7] [1, 1] : memref<16x?xf64, strided<[8, 1], offset: ?>> to memref<1x?xf64, strided<[8, 1], offset: ?>>
              %c1_24 = arith.constant 1 : index
              %c1_25 = arith.constant 1 : index
              %dim = memref.dim %subview_22, %c1_25 : memref<1x?xf64, strided<[8, 1], offset: ?>>
              %c1_26 = arith.constant 1 : index
              %c0_27 = arith.constant 0 : index
              %cst_28 = arith.constant 0.000000e+00 : f64
              %8 = vector.transfer_read %subview_21[%c0_27, %c0_27], %cst_28 {permutation_map = #map3} : memref<1x1xf64, strided<[32, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_29 = arith.constant 0.000000e+00 : f64
              %9 = vector.create_mask %c1_26, %dim : vector<1x4xi1>
              %10 = vector.mask %9 { vector.transfer_read %subview_22[%c0_27, %c0_27], %cst_29 {in_bounds = [true, true, true], permutation_map = #map4} : memref<1x?xf64, strided<[8, 1], offset: ?>>, vector<1x4x1xf64> } : vector<1x4xi1> -> vector<1x4x1xf64>
              %cst_30 = arith.constant 0.000000e+00 : f64
              %11 = vector.create_mask %c1_24, %dim : vector<1x4xi1>
              %12 = vector.mask %11 { vector.transfer_read %subview_23[%c0_27, %c0_27], %cst_30 {in_bounds = [true, true]} : memref<1x?xf64, strided<[8, 1], offset: ?>>, vector<1x4xf64> } : vector<1x4xi1> -> vector<1x4xf64>
              %13 = arith.mulf %8, %10 : vector<1x4x1xf64>
              %14 = vector.create_mask %c1_24, %dim, %c1_26 : vector<1x4x1xi1>
              %15 = vector.mask %14 { vector.multi_reduction <add>, %13, %12 [2] : vector<1x4x1xf64> to vector<1x4xf64> } : vector<1x4x1xi1> -> vector<1x4xf64>
              %c0_31 = arith.constant 0 : index
              vector.mask %11 { vector.transfer_write %15, %subview_23[%c0_31, %c0_31] {in_bounds = [true, true]} : vector<1x4xf64>, memref<1x?xf64, strided<[8, 1], offset: ?>> } : vector<1x4xi1>
            }
          }
        }
      }
    }
    return
  }
}
