module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<false> : vector<4xi1>) : vector<4xi1>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<4xf64>) : vector<4xf64>
    %27 = llvm.mlir.constant(dense<false> : vector<1x4xi1>) : !llvm.array<1 x vector<4xi1>>
    %28 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %29 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %30 = llvm.mlir.constant(-1 : index) : i64
    %31 = llvm.mlir.constant(8 : index) : i64
    %32 = llvm.mlir.constant(32 : index) : i64
    %33 = llvm.mlir.constant(64 : index) : i64
    %34 = llvm.mlir.constant(1 : index) : i64
    %35 = llvm.mlir.constant(4 : index) : i64
    %36 = llvm.mlir.constant(0 : index) : i64
    %37 = llvm.mlir.constant(16 : index) : i64
    %38 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%36 : i64)
  ^bb1(%39: i64):  // 2 preds: ^bb0, ^bb5
    %40 = llvm.icmp "slt" %39, %33 : i64
    llvm.cond_br %40, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%36 : i64)
  ^bb3(%41: i64):  // 2 preds: ^bb2, ^bb4
    %42 = llvm.icmp "slt" %41, %31 : i64
    llvm.cond_br %42, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %43 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.mlir.constant(8 : index) : i64
    %45 = llvm.mul %39, %44  : i64
    %46 = llvm.add %45, %41  : i64
    %47 = llvm.getelementptr %43[%46] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %38, %47 : f64, !llvm.ptr
    %48 = llvm.add %41, %34  : i64
    llvm.br ^bb3(%48 : i64)
  ^bb5:  // pred: ^bb3
    %49 = llvm.add %39, %34  : i64
    llvm.br ^bb1(%49 : i64)
  ^bb6:  // pred: ^bb1
    %50 = llvm.mlir.constant(1 : index) : i64
    %51 = llvm.alloca %50 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %52 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %53 = llvm.insertvalue %51, %52[0] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.insertvalue %51, %53[1] : !llvm.struct<(ptr, ptr, i64)> 
    %55 = llvm.mlir.constant(0 : index) : i64
    %56 = llvm.insertvalue %55, %54[2] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.mlir.constant(1 : index) : i64
    %58 = llvm.alloca %57 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %59 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %60 = llvm.insertvalue %58, %59[0] : !llvm.struct<(ptr, ptr, i64)> 
    %61 = llvm.insertvalue %58, %60[1] : !llvm.struct<(ptr, ptr, i64)> 
    %62 = llvm.mlir.constant(0 : index) : i64
    %63 = llvm.insertvalue %62, %61[2] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.mlir.constant(1 : index) : i64
    %65 = llvm.alloca %64 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %66 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %67 = llvm.insertvalue %65, %66[0] : !llvm.struct<(ptr, ptr, i64)> 
    %68 = llvm.insertvalue %65, %67[1] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.mlir.constant(0 : index) : i64
    %70 = llvm.insertvalue %69, %68[2] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.mlir.constant(1 : index) : i64
    %72 = llvm.alloca %71 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %73 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %74 = llvm.insertvalue %72, %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %75 = llvm.insertvalue %72, %74[1] : !llvm.struct<(ptr, ptr, i64)> 
    %76 = llvm.mlir.constant(0 : index) : i64
    %77 = llvm.insertvalue %76, %75[2] : !llvm.struct<(ptr, ptr, i64)> 
    %78 = llvm.mlir.constant(1 : index) : i64
    %79 = llvm.alloca %78 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %80 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %81 = llvm.insertvalue %79, %80[0] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.insertvalue %79, %81[1] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.mlir.constant(0 : index) : i64
    %84 = llvm.insertvalue %83, %82[2] : !llvm.struct<(ptr, ptr, i64)> 
    %85 = llvm.mlir.constant(1 : index) : i64
    %86 = llvm.alloca %85 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %87 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %88 = llvm.insertvalue %86, %87[0] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.insertvalue %86, %88[1] : !llvm.struct<(ptr, ptr, i64)> 
    %90 = llvm.mlir.constant(0 : index) : i64
    %91 = llvm.insertvalue %90, %89[2] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.mlir.constant(1 : index) : i64
    %93 = llvm.alloca %92 x !llvm.array<1 x vector<4xi1>> : (i64) -> !llvm.ptr
    %94 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %95 = llvm.insertvalue %93, %94[0] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.insertvalue %93, %95[1] : !llvm.struct<(ptr, ptr, i64)> 
    %97 = llvm.mlir.constant(0 : index) : i64
    %98 = llvm.insertvalue %97, %96[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%36 : i64)
  ^bb7(%99: i64):  // 2 preds: ^bb6, ^bb29
    %100 = llvm.icmp "slt" %99, %33 : i64
    llvm.cond_br %100, ^bb8, ^bb30
  ^bb8:  // pred: ^bb7
    %101 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %102 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %103 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %104 = llvm.insertvalue %101, %103[0] : !llvm.struct<(ptr, ptr, i64)> 
    %105 = llvm.insertvalue %102, %104[1] : !llvm.struct<(ptr, ptr, i64)> 
    %106 = llvm.mlir.constant(0 : index) : i64
    %107 = llvm.insertvalue %106, %105[2] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %110 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.mul %99, %32  : i64
    %114 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %117 = llvm.insertvalue %114, %116[0] : !llvm.struct<(ptr, ptr, i64)> 
    %118 = llvm.insertvalue %115, %117[1] : !llvm.struct<(ptr, ptr, i64)> 
    %119 = llvm.mlir.constant(0 : index) : i64
    %120 = llvm.insertvalue %119, %118[2] : !llvm.struct<(ptr, ptr, i64)> 
    %121 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %122 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %125 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %126 = llvm.mul %99, %31  : i64
    llvm.br ^bb9(%36 : i64)
  ^bb9(%127: i64):  // 2 preds: ^bb8, ^bb28
    %128 = llvm.icmp "slt" %127, %37 : i64
    llvm.cond_br %128, ^bb10, ^bb29
  ^bb10:  // pred: ^bb9
    llvm.br ^bb11(%36 : i64)
  ^bb11(%129: i64):  // 2 preds: ^bb10, ^bb27
    %130 = llvm.icmp "slt" %129, %31 : i64
    llvm.cond_br %130, ^bb12, ^bb28
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%36 : i64)
  ^bb13(%131: i64):  // 2 preds: ^bb12, ^bb26
    %132 = llvm.icmp "slt" %131, %32 : i64
    llvm.cond_br %132, ^bb14, ^bb27
  ^bb14:  // pred: ^bb13
    %133 = llvm.mul %129, %30  : i64
    %134 = llvm.add %133, %31  : i64
    %135 = llvm.icmp "slt" %134, %35 : i64
    %136 = llvm.select %135, %134, %35 : i1, i64
    %137 = llvm.mul %129, %30  : i64
    %138 = llvm.add %137, %31  : i64
    %139 = llvm.icmp "slt" %138, %35 : i64
    %140 = llvm.select %139, %138, %35 : i1, i64
    %141 = llvm.mul %127, %32  : i64
    %142 = llvm.add %113, %141  : i64
    %143 = llvm.add %142, %131  : i64
    %144 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %145 = llvm.insertvalue %101, %144[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.insertvalue %102, %145[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.insertvalue %143, %146[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.mlir.constant(1 : index) : i64
    %149 = llvm.insertvalue %148, %147[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %150 = llvm.mlir.constant(32 : index) : i64
    %151 = llvm.insertvalue %150, %149[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.mlir.constant(1 : index) : i64
    %153 = llvm.insertvalue %152, %151[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.mlir.constant(1 : index) : i64
    %155 = llvm.insertvalue %154, %153[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %156 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %157 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %158 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %159 = llvm.insertvalue %156, %158[0] : !llvm.struct<(ptr, ptr, i64)> 
    %160 = llvm.insertvalue %157, %159[1] : !llvm.struct<(ptr, ptr, i64)> 
    %161 = llvm.mlir.constant(0 : index) : i64
    %162 = llvm.insertvalue %161, %160[2] : !llvm.struct<(ptr, ptr, i64)> 
    %163 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %164 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %165 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %166 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %167 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %168 = llvm.mul %131, %31  : i64
    %169 = llvm.add %168, %129  : i64
    %170 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %171 = llvm.insertvalue %156, %170[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %172 = llvm.insertvalue %157, %171[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %173 = llvm.insertvalue %169, %172[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %174 = llvm.mlir.constant(1 : index) : i64
    %175 = llvm.insertvalue %174, %173[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %176 = llvm.mlir.constant(8 : index) : i64
    %177 = llvm.insertvalue %176, %175[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %178 = llvm.insertvalue %136, %177[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %179 = llvm.mlir.constant(1 : index) : i64
    %180 = llvm.insertvalue %179, %178[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %181 = llvm.mul %127, %31  : i64
    %182 = llvm.add %126, %181  : i64
    %183 = llvm.add %182, %129  : i64
    %184 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %185 = llvm.insertvalue %114, %184[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %186 = llvm.insertvalue %115, %185[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %187 = llvm.insertvalue %183, %186[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %188 = llvm.mlir.constant(1 : index) : i64
    %189 = llvm.insertvalue %188, %187[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %190 = llvm.mlir.constant(8 : index) : i64
    %191 = llvm.insertvalue %190, %189[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %192 = llvm.insertvalue %140, %191[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %193 = llvm.mlir.constant(1 : index) : i64
    %194 = llvm.insertvalue %193, %192[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %195 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %196 = llvm.extractvalue %56[0] : !llvm.struct<(ptr, ptr, i64)> 
    %197 = llvm.insertvalue %196, %195[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %198 = llvm.extractvalue %56[1] : !llvm.struct<(ptr, ptr, i64)> 
    %199 = llvm.insertvalue %198, %197[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %200 = llvm.mlir.constant(0 : index) : i64
    %201 = llvm.insertvalue %200, %199[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %202 = llvm.mlir.constant(1 : index) : i64
    %203 = llvm.insertvalue %202, %201[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.mlir.constant(1 : index) : i64
    %205 = llvm.insertvalue %204, %203[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb15(%36 : i64)
  ^bb15(%206: i64):  // 2 preds: ^bb14, ^bb16
    %207 = llvm.icmp "slt" %206, %34 : i64
    llvm.cond_br %207, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %208 = llvm.getelementptr %102[%143] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %209 = llvm.mlir.constant(32 : index) : i64
    %210 = llvm.mul %206, %209  : i64
    %211 = llvm.add %210, %36  : i64
    %212 = llvm.getelementptr %208[%211] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %213 = llvm.load %212 : !llvm.ptr -> f64
    %214 = llvm.mlir.undef : vector<1xf64>
    %215 = llvm.mlir.constant(0 : i32) : i32
    %216 = llvm.insertelement %213, %214[%215 : i32] : vector<1xf64>
    %217 = llvm.shufflevector %216, %214 [0] : vector<1xf64> 
    %218 = llvm.getelementptr %198[%206] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %217, %218 : vector<1xf64>, !llvm.ptr
    %219 = llvm.add %206, %34  : i64
    llvm.br ^bb15(%219 : i64)
  ^bb17:  // pred: ^bb15
    %220 = llvm.load %51 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %221 = llvm.extractvalue %220[0] : !llvm.array<1 x vector<1xf64>> 
    %222 = llvm.insertvalue %221, %29[0] : !llvm.array<4 x vector<1xf64>> 
    %223 = llvm.insertvalue %221, %222[1] : !llvm.array<4 x vector<1xf64>> 
    %224 = llvm.insertvalue %221, %223[2] : !llvm.array<4 x vector<1xf64>> 
    %225 = llvm.insertvalue %221, %224[3] : !llvm.array<4 x vector<1xf64>> 
    %226 = llvm.insertvalue %225, %28[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %227 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %228 = llvm.trunc %136 : i64 to i32
    %229 = llvm.mlir.undef : vector<4xi32>
    %230 = llvm.mlir.constant(0 : i32) : i32
    %231 = llvm.insertelement %228, %229[%230 : i32] : vector<4xi32>
    %232 = llvm.shufflevector %231, %229 [0, 0, 0, 0] : vector<4xi32> 
    %233 = llvm.icmp "sgt" %232, %227 : vector<4xi32>
    %234 = llvm.insertvalue %233, %27[0] : !llvm.array<1 x vector<4xi1>> 
    llvm.store %234, %65 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    %235 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %236 = llvm.extractvalue %63[0] : !llvm.struct<(ptr, ptr, i64)> 
    %237 = llvm.insertvalue %236, %235[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %238 = llvm.extractvalue %63[1] : !llvm.struct<(ptr, ptr, i64)> 
    %239 = llvm.insertvalue %238, %237[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %240 = llvm.mlir.constant(0 : index) : i64
    %241 = llvm.insertvalue %240, %239[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %242 = llvm.mlir.constant(1 : index) : i64
    %243 = llvm.insertvalue %242, %241[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %244 = llvm.mlir.constant(1 : index) : i64
    %245 = llvm.insertvalue %244, %243[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %246 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %247 = llvm.extractvalue %70[0] : !llvm.struct<(ptr, ptr, i64)> 
    %248 = llvm.insertvalue %247, %246[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.extractvalue %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %250 = llvm.insertvalue %249, %248[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %251 = llvm.mlir.constant(0 : index) : i64
    %252 = llvm.insertvalue %251, %250[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %253 = llvm.mlir.constant(1 : index) : i64
    %254 = llvm.insertvalue %253, %252[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %255 = llvm.mlir.constant(1 : index) : i64
    %256 = llvm.insertvalue %255, %254[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb18(%36 : i64)
  ^bb18(%257: i64):  // 2 preds: ^bb17, ^bb19
    %258 = llvm.icmp "slt" %257, %34 : i64
    llvm.cond_br %258, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %259 = llvm.getelementptr %249[%257] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %260 = llvm.load %259 : !llvm.ptr -> vector<4xi1>
    %261 = llvm.extractvalue %180[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %262 = llvm.extractvalue %180[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %263 = llvm.getelementptr %261[%262] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %264 = llvm.mlir.constant(8 : index) : i64
    %265 = llvm.mul %257, %264  : i64
    %266 = llvm.add %265, %36  : i64
    %267 = llvm.getelementptr %263[%266] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %268 = llvm.intr.masked.load %267, %260, %26 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %269 = llvm.getelementptr %238[%257] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %268, %269 : vector<4xf64>, !llvm.ptr
    %270 = llvm.add %257, %34  : i64
    llvm.br ^bb18(%270 : i64)
  ^bb20:  // pred: ^bb18
    %271 = llvm.load %58 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %272 = llvm.extractvalue %271[0] : !llvm.array<1 x vector<4xf64>> 
    %273 = llvm.mlir.constant(0 : i64) : i64
    %274 = llvm.extractelement %272[%273 : i64] : vector<4xf64>
    %275 = llvm.extractvalue %28[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %276 = llvm.mlir.constant(0 : i64) : i64
    %277 = llvm.insertelement %274, %275[%276 : i64] : vector<1xf64>
    %278 = llvm.insertvalue %277, %28[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %279 = llvm.extractvalue %271[0] : !llvm.array<1 x vector<4xf64>> 
    %280 = llvm.mlir.constant(1 : i64) : i64
    %281 = llvm.extractelement %279[%280 : i64] : vector<4xf64>
    %282 = llvm.extractvalue %28[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %283 = llvm.mlir.constant(0 : i64) : i64
    %284 = llvm.insertelement %281, %282[%283 : i64] : vector<1xf64>
    %285 = llvm.insertvalue %284, %278[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %286 = llvm.extractvalue %271[0] : !llvm.array<1 x vector<4xf64>> 
    %287 = llvm.mlir.constant(2 : i64) : i64
    %288 = llvm.extractelement %286[%287 : i64] : vector<4xf64>
    %289 = llvm.extractvalue %28[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %290 = llvm.mlir.constant(0 : i64) : i64
    %291 = llvm.insertelement %288, %289[%290 : i64] : vector<1xf64>
    %292 = llvm.insertvalue %291, %285[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %293 = llvm.extractvalue %271[0] : !llvm.array<1 x vector<4xf64>> 
    %294 = llvm.mlir.constant(3 : i64) : i64
    %295 = llvm.extractelement %293[%294 : i64] : vector<4xf64>
    %296 = llvm.extractvalue %28[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %297 = llvm.mlir.constant(0 : i64) : i64
    %298 = llvm.insertelement %295, %296[%297 : i64] : vector<1xf64>
    %299 = llvm.insertvalue %298, %292[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %300 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %301 = llvm.trunc %136 : i64 to i32
    %302 = llvm.mlir.undef : vector<4xi32>
    %303 = llvm.mlir.constant(0 : i32) : i32
    %304 = llvm.insertelement %301, %302[%303 : i32] : vector<4xi32>
    %305 = llvm.shufflevector %304, %302 [0, 0, 0, 0] : vector<4xi32> 
    %306 = llvm.icmp "sgt" %305, %300 : vector<4xi32>
    %307 = llvm.insertvalue %306, %27[0] : !llvm.array<1 x vector<4xi1>> 
    llvm.store %307, %79 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    %308 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %309 = llvm.extractvalue %77[0] : !llvm.struct<(ptr, ptr, i64)> 
    %310 = llvm.insertvalue %309, %308[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %311 = llvm.extractvalue %77[1] : !llvm.struct<(ptr, ptr, i64)> 
    %312 = llvm.insertvalue %311, %310[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %313 = llvm.mlir.constant(0 : index) : i64
    %314 = llvm.insertvalue %313, %312[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %315 = llvm.mlir.constant(1 : index) : i64
    %316 = llvm.insertvalue %315, %314[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %317 = llvm.mlir.constant(1 : index) : i64
    %318 = llvm.insertvalue %317, %316[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %319 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %320 = llvm.extractvalue %84[0] : !llvm.struct<(ptr, ptr, i64)> 
    %321 = llvm.insertvalue %320, %319[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.extractvalue %84[1] : !llvm.struct<(ptr, ptr, i64)> 
    %323 = llvm.insertvalue %322, %321[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %324 = llvm.mlir.constant(0 : index) : i64
    %325 = llvm.insertvalue %324, %323[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %326 = llvm.mlir.constant(1 : index) : i64
    %327 = llvm.insertvalue %326, %325[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %328 = llvm.mlir.constant(1 : index) : i64
    %329 = llvm.insertvalue %328, %327[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb21(%36 : i64)
  ^bb21(%330: i64):  // 2 preds: ^bb20, ^bb22
    %331 = llvm.icmp "slt" %330, %34 : i64
    llvm.cond_br %331, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    %332 = llvm.getelementptr %322[%330] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %333 = llvm.load %332 : !llvm.ptr -> vector<4xi1>
    %334 = llvm.extractvalue %194[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %335 = llvm.extractvalue %194[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %336 = llvm.getelementptr %334[%335] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %337 = llvm.mlir.constant(8 : index) : i64
    %338 = llvm.mul %330, %337  : i64
    %339 = llvm.add %338, %36  : i64
    %340 = llvm.getelementptr %336[%339] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %341 = llvm.intr.masked.load %340, %333, %26 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %342 = llvm.getelementptr %311[%330] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %341, %342 : vector<4xf64>, !llvm.ptr
    %343 = llvm.add %330, %34  : i64
    llvm.br ^bb21(%343 : i64)
  ^bb23:  // pred: ^bb21
    %344 = llvm.load %72 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %345 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %346 = llvm.extractvalue %226[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %347 = llvm.fmul %346, %277  : vector<1xf64>
    %348 = llvm.insertvalue %347, %345[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %349 = llvm.extractvalue %226[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %350 = llvm.fmul %349, %284  : vector<1xf64>
    %351 = llvm.insertvalue %350, %348[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %352 = llvm.extractvalue %226[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %353 = llvm.fmul %352, %291  : vector<1xf64>
    %354 = llvm.insertvalue %353, %351[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %355 = llvm.extractvalue %226[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %356 = llvm.fmul %355, %298  : vector<1xf64>
    %357 = llvm.insertvalue %356, %354[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %358 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %359 = llvm.trunc %136 : i64 to i32
    %360 = llvm.mlir.undef : vector<4xi32>
    %361 = llvm.mlir.constant(0 : i32) : i32
    %362 = llvm.insertelement %359, %360[%361 : i32] : vector<4xi32>
    %363 = llvm.shufflevector %362, %360 [0, 0, 0, 0] : vector<4xi32> 
    %364 = llvm.icmp "sgt" %363, %358 : vector<4xi32>
    %365 = llvm.extractvalue %344[0] : !llvm.array<1 x vector<4xf64>> 
    %366 = llvm.mlir.constant(0 : i64) : i64
    %367 = llvm.extractelement %364[%366 : i64] : vector<4xi1>
    %368 = llvm.mlir.constant(0 : i64) : i64
    %369 = llvm.insertelement %367, %25[%368 : i64] : vector<4xi1>
    %370 = llvm.mlir.constant(1 : i64) : i64
    %371 = llvm.extractelement %364[%370 : i64] : vector<4xi1>
    %372 = llvm.mlir.constant(1 : i64) : i64
    %373 = llvm.insertelement %371, %369[%372 : i64] : vector<4xi1>
    %374 = llvm.mlir.constant(2 : i64) : i64
    %375 = llvm.extractelement %364[%374 : i64] : vector<4xi1>
    %376 = llvm.mlir.constant(2 : i64) : i64
    %377 = llvm.insertelement %375, %373[%376 : i64] : vector<4xi1>
    %378 = llvm.mlir.constant(3 : i64) : i64
    %379 = llvm.extractelement %364[%378 : i64] : vector<4xi1>
    %380 = llvm.mlir.constant(3 : i64) : i64
    %381 = llvm.insertelement %379, %377[%380 : i64] : vector<4xi1>
    %382 = llvm.extractvalue %357[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %383 = llvm.mlir.constant(0 : i64) : i64
    %384 = llvm.extractelement %382[%383 : i64] : vector<1xf64>
    %385 = llvm.mlir.constant(0 : i64) : i64
    %386 = llvm.insertelement %384, %26[%385 : i64] : vector<4xf64>
    %387 = llvm.extractvalue %357[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %388 = llvm.mlir.constant(0 : i64) : i64
    %389 = llvm.extractelement %387[%388 : i64] : vector<1xf64>
    %390 = llvm.mlir.constant(1 : i64) : i64
    %391 = llvm.insertelement %389, %386[%390 : i64] : vector<4xf64>
    %392 = llvm.extractvalue %357[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %393 = llvm.mlir.constant(0 : i64) : i64
    %394 = llvm.extractelement %392[%393 : i64] : vector<1xf64>
    %395 = llvm.mlir.constant(2 : i64) : i64
    %396 = llvm.insertelement %394, %391[%395 : i64] : vector<4xf64>
    %397 = llvm.extractvalue %357[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %398 = llvm.mlir.constant(0 : i64) : i64
    %399 = llvm.extractelement %397[%398 : i64] : vector<1xf64>
    %400 = llvm.mlir.constant(3 : i64) : i64
    %401 = llvm.insertelement %399, %396[%400 : i64] : vector<4xf64>
    %402 = llvm.fadd %365, %401  : vector<4xf64>
    %403 = llvm.select %381, %402, %401 : vector<4xi1>, vector<4xf64>
    %404 = llvm.insertvalue %403, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %307, %93 : !llvm.array<1 x vector<4xi1>>, !llvm.ptr
    llvm.store %404, %86 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %405 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %406 = llvm.extractvalue %91[0] : !llvm.struct<(ptr, ptr, i64)> 
    %407 = llvm.insertvalue %406, %405[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %408 = llvm.extractvalue %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %409 = llvm.insertvalue %408, %407[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %410 = llvm.mlir.constant(0 : index) : i64
    %411 = llvm.insertvalue %410, %409[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %412 = llvm.mlir.constant(1 : index) : i64
    %413 = llvm.insertvalue %412, %411[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %414 = llvm.mlir.constant(1 : index) : i64
    %415 = llvm.insertvalue %414, %413[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %416 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %417 = llvm.extractvalue %98[0] : !llvm.struct<(ptr, ptr, i64)> 
    %418 = llvm.insertvalue %417, %416[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %419 = llvm.extractvalue %98[1] : !llvm.struct<(ptr, ptr, i64)> 
    %420 = llvm.insertvalue %419, %418[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %421 = llvm.mlir.constant(0 : index) : i64
    %422 = llvm.insertvalue %421, %420[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %423 = llvm.mlir.constant(1 : index) : i64
    %424 = llvm.insertvalue %423, %422[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %425 = llvm.mlir.constant(1 : index) : i64
    %426 = llvm.insertvalue %425, %424[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb24(%36 : i64)
  ^bb24(%427: i64):  // 2 preds: ^bb23, ^bb25
    %428 = llvm.icmp "slt" %427, %34 : i64
    llvm.cond_br %428, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %429 = llvm.getelementptr %408[%427] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %430 = llvm.load %429 : !llvm.ptr -> vector<4xf64>
    %431 = llvm.getelementptr %419[%427] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xi1>
    %432 = llvm.load %431 : !llvm.ptr -> vector<4xi1>
    %433 = llvm.extractvalue %194[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %434 = llvm.extractvalue %194[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %435 = llvm.getelementptr %433[%434] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %436 = llvm.mlir.constant(8 : index) : i64
    %437 = llvm.mul %427, %436  : i64
    %438 = llvm.add %437, %36  : i64
    %439 = llvm.getelementptr %435[%438] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.intr.masked.store %430, %439, %432 {alignment = 8 : i32} : vector<4xf64>, vector<4xi1> into !llvm.ptr
    %440 = llvm.add %427, %34  : i64
    llvm.br ^bb24(%440 : i64)
  ^bb26:  // pred: ^bb24
    %441 = llvm.add %131, %34  : i64
    llvm.br ^bb13(%441 : i64)
  ^bb27:  // pred: ^bb13
    %442 = llvm.add %129, %35  : i64
    llvm.br ^bb11(%442 : i64)
  ^bb28:  // pred: ^bb11
    %443 = llvm.add %127, %34  : i64
    llvm.br ^bb9(%443 : i64)
  ^bb29:  // pred: ^bb9
    %444 = llvm.add %99, %37  : i64
    llvm.br ^bb7(%444 : i64)
  ^bb30:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
