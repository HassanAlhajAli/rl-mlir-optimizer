; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader16.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader16.preheader, %106
  %21 = phi i64 [ %107, %106 ], [ 0, %.preheader16.preheader ]
  br label %.preheader15

.preheader15:                                     ; preds = %.preheader16, %104
  %22 = phi i64 [ 0, %.preheader16 ], [ %105, %104 ]
  %23 = add nuw nsw i64 %22, %21
  %24 = shl i64 %23, 5
  %25 = shl i64 %23, 3
  %26 = getelementptr double, ptr %15, i64 %25
  %invariant.gep24 = getelementptr double, ptr %1, i64 %24
  %.promoted26 = load <4 x double>, ptr %26, align 8
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader15
  %27 = phi <4 x double> [ %.promoted26, %.preheader15 ], [ %63, %.critedge ]
  %28 = phi i64 [ 0, %.preheader15 ], [ %64, %.critedge ]
  %29 = shl nuw nsw i64 %28, 3
  %gep25 = getelementptr double, ptr %invariant.gep24, i64 %28
  %30 = load double, ptr %gep25, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %gep = getelementptr double, ptr %8, i64 %29
  %unmaskedload = load <4 x double>, ptr %gep, align 8
  %32 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %33 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %34 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %35 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %36 = fmul <1 x double> %31, %32
  %37 = fmul <1 x double> %31, %33
  %38 = fmul <1 x double> %31, %34
  %39 = shufflevector <1 x double> %38, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %40 = fmul <1 x double> %31, %35
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = shufflevector <1 x double> %36, <1 x double> %37, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %43 = shufflevector <4 x double> %42, <4 x double> %39, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %45 = fadd <4 x double> %27, %44
  store <4 x double> %45, ptr %26, align 8
  %46 = or disjoint i64 %28, 1
  %47 = shl nuw nsw i64 %46, 3
  %gep25.1 = getelementptr double, ptr %invariant.gep24, i64 %46
  %48 = load double, ptr %gep25.1, align 8
  %49 = insertelement <1 x double> poison, double %48, i64 0
  %gep.127 = getelementptr double, ptr %8, i64 %47
  %unmaskedload.1 = load <4 x double>, ptr %gep.127, align 8
  %50 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> zeroinitializer
  %51 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 1>
  %52 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 2>
  %53 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 3>
  %54 = fmul <1 x double> %49, %50
  %55 = fmul <1 x double> %49, %51
  %56 = fmul <1 x double> %49, %52
  %57 = shufflevector <1 x double> %56, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %58 = fmul <1 x double> %49, %53
  %59 = shufflevector <1 x double> %58, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %60 = shufflevector <1 x double> %54, <1 x double> %55, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %61 = shufflevector <4 x double> %60, <4 x double> %57, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %59, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %63 = fadd <4 x double> %45, %62
  store <4 x double> %63, ptr %26, align 8
  %64 = add nuw nsw i64 %28, 2
  %exitcond.not.1 = icmp eq i64 %64, 32
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %65 = getelementptr double, ptr %26, i64 4
  %invariant.gep = getelementptr double, ptr %1, i64 %24
  %.promoted = load <4 x double>, ptr %65, align 8
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %66 = phi <4 x double> [ %.promoted, %.preheader.1 ], [ %102, %.critedge.1 ]
  %67 = phi i64 [ 0, %.preheader.1 ], [ %103, %.critedge.1 ]
  %68 = shl nuw nsw i64 %67, 3
  %gep23 = getelementptr double, ptr %invariant.gep, i64 %67
  %69 = load double, ptr %gep23, align 8
  %70 = insertelement <1 x double> poison, double %69, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %68
  %unmaskedload21 = load <4 x double>, ptr %gep.1, align 8
  %71 = shufflevector <4 x double> %unmaskedload21, <4 x double> poison, <1 x i32> zeroinitializer
  %72 = shufflevector <4 x double> %unmaskedload21, <4 x double> poison, <1 x i32> <i32 1>
  %73 = shufflevector <4 x double> %unmaskedload21, <4 x double> poison, <1 x i32> <i32 2>
  %74 = shufflevector <4 x double> %unmaskedload21, <4 x double> poison, <1 x i32> <i32 3>
  %75 = fmul <1 x double> %70, %71
  %76 = fmul <1 x double> %70, %72
  %77 = fmul <1 x double> %70, %73
  %78 = shufflevector <1 x double> %77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = fmul <1 x double> %70, %74
  %80 = shufflevector <1 x double> %79, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = shufflevector <1 x double> %75, <1 x double> %76, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %82 = shufflevector <4 x double> %81, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %84 = fadd <4 x double> %66, %83
  store <4 x double> %84, ptr %65, align 8
  %85 = or disjoint i64 %67, 1
  %86 = shl nuw nsw i64 %85, 3
  %gep23.1 = getelementptr double, ptr %invariant.gep, i64 %85
  %87 = load double, ptr %gep23.1, align 8
  %88 = insertelement <1 x double> poison, double %87, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %86
  %unmaskedload21.1 = load <4 x double>, ptr %gep.1.1, align 8
  %89 = shufflevector <4 x double> %unmaskedload21.1, <4 x double> poison, <1 x i32> zeroinitializer
  %90 = shufflevector <4 x double> %unmaskedload21.1, <4 x double> poison, <1 x i32> <i32 1>
  %91 = shufflevector <4 x double> %unmaskedload21.1, <4 x double> poison, <1 x i32> <i32 2>
  %92 = shufflevector <4 x double> %unmaskedload21.1, <4 x double> poison, <1 x i32> <i32 3>
  %93 = fmul <1 x double> %88, %89
  %94 = fmul <1 x double> %88, %90
  %95 = fmul <1 x double> %88, %91
  %96 = shufflevector <1 x double> %95, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %97 = fmul <1 x double> %88, %92
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = shufflevector <1 x double> %93, <1 x double> %94, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %96, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %102 = fadd <4 x double> %84, %101
  store <4 x double> %102, ptr %65, align 8
  %103 = add nuw nsw i64 %67, 2
  %exitcond.1.not.1 = icmp eq i64 %103, 32
  br i1 %exitcond.1.not.1, label %104, label %.critedge.1

104:                                              ; preds = %.critedge.1
  %105 = add nuw nsw i64 %22, 1
  %exitcond19.not = icmp eq i64 %105, 16
  br i1 %exitcond19.not, label %106, label %.preheader15

106:                                              ; preds = %104
  %107 = add nuw nsw i64 %21, 16
  %108 = icmp ult i64 %21, 48
  br i1 %108, label %.preheader16, label %109

109:                                              ; preds = %106
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
.preheader16.i:
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %84, %.preheader16.i
  %3 = phi i64 [ 0, %.preheader16.i ], [ %85, %84 ]
  %4 = shl i64 %3, 5
  %5 = shl i64 %3, 3
  %6 = getelementptr double, ptr %.unpack32, i64 %5
  %invariant.gep24.i = getelementptr double, ptr %.unpack2, i64 %4
  %.promoted26.i = load <4 x double>, ptr %6, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %7 = phi <4 x double> [ %.promoted26.i, %.preheader15.i ], [ %43, %.critedge.i ]
  %8 = phi i64 [ 0, %.preheader15.i ], [ %44, %.critedge.i ]
  %9 = shl nuw nsw i64 %8, 3
  %gep25.i = getelementptr double, ptr %invariant.gep24.i, i64 %8
  %10 = load double, ptr %gep25.i, align 8
  %11 = insertelement <1 x double> poison, double %10, i64 0
  %gep.i = getelementptr double, ptr %.unpack17, i64 %9
  %unmaskedload.i = load <4 x double>, ptr %gep.i, align 8
  %12 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> zeroinitializer
  %13 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 1>
  %14 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 2>
  %15 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 3>
  %16 = fmul <1 x double> %11, %12
  %17 = fmul <1 x double> %11, %13
  %18 = fmul <1 x double> %11, %14
  %19 = shufflevector <1 x double> %18, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %20 = fmul <1 x double> %11, %15
  %21 = shufflevector <1 x double> %20, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %22 = shufflevector <1 x double> %16, <1 x double> %17, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %23 = shufflevector <4 x double> %22, <4 x double> %19, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %24 = shufflevector <4 x double> %23, <4 x double> %21, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %25 = fadd <4 x double> %7, %24
  store <4 x double> %25, ptr %6, align 8
  %26 = or disjoint i64 %8, 1
  %27 = shl nuw nsw i64 %26, 3
  %gep25.i.145 = getelementptr double, ptr %invariant.gep24.i, i64 %26
  %28 = load double, ptr %gep25.i.145, align 8
  %29 = insertelement <1 x double> poison, double %28, i64 0
  %gep.i.146 = getelementptr double, ptr %.unpack17, i64 %27
  %unmaskedload.i.147 = load <4 x double>, ptr %gep.i.146, align 8
  %30 = shufflevector <4 x double> %unmaskedload.i.147, <4 x double> poison, <1 x i32> zeroinitializer
  %31 = shufflevector <4 x double> %unmaskedload.i.147, <4 x double> poison, <1 x i32> <i32 1>
  %32 = shufflevector <4 x double> %unmaskedload.i.147, <4 x double> poison, <1 x i32> <i32 2>
  %33 = shufflevector <4 x double> %unmaskedload.i.147, <4 x double> poison, <1 x i32> <i32 3>
  %34 = fmul <1 x double> %29, %30
  %35 = fmul <1 x double> %29, %31
  %36 = fmul <1 x double> %29, %32
  %37 = shufflevector <1 x double> %36, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = fmul <1 x double> %29, %33
  %39 = shufflevector <1 x double> %38, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %40 = shufflevector <1 x double> %34, <1 x double> %35, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %39, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %43 = fadd <4 x double> %25, %42
  store <4 x double> %43, ptr %6, align 8
  %44 = add nuw nsw i64 %8, 2
  %exitcond.not.i.148 = icmp eq i64 %44, 32
  br i1 %exitcond.not.i.148, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %45 = getelementptr double, ptr %6, i64 4
  %.promoted.i = load <4 x double>, ptr %45, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %46 = phi <4 x double> [ %.promoted.i, %.preheader.1.i ], [ %82, %.critedge.1.i ]
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %83, %.critedge.1.i ]
  %48 = shl nuw nsw i64 %47, 3
  %gep23.i = getelementptr double, ptr %invariant.gep24.i, i64 %47
  %49 = load double, ptr %gep23.i, align 8
  %50 = insertelement <1 x double> poison, double %49, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %48
  %unmaskedload21.i = load <4 x double>, ptr %gep.1.i, align 8
  %51 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> zeroinitializer
  %52 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 1>
  %53 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 2>
  %54 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 3>
  %55 = fmul <1 x double> %50, %51
  %56 = fmul <1 x double> %50, %52
  %57 = fmul <1 x double> %50, %53
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = fmul <1 x double> %50, %54
  %60 = shufflevector <1 x double> %59, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <1 x double> %55, <1 x double> %56, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %64 = fadd <4 x double> %46, %63
  store <4 x double> %64, ptr %45, align 8
  %65 = or disjoint i64 %47, 1
  %66 = shl nuw nsw i64 %65, 3
  %gep23.i.150 = getelementptr double, ptr %invariant.gep24.i, i64 %65
  %67 = load double, ptr %gep23.i.150, align 8
  %68 = insertelement <1 x double> poison, double %67, i64 0
  %gep.1.i.151 = getelementptr double, ptr %invariant.gep.1.i, i64 %66
  %unmaskedload21.i.152 = load <4 x double>, ptr %gep.1.i.151, align 8
  %69 = shufflevector <4 x double> %unmaskedload21.i.152, <4 x double> poison, <1 x i32> zeroinitializer
  %70 = shufflevector <4 x double> %unmaskedload21.i.152, <4 x double> poison, <1 x i32> <i32 1>
  %71 = shufflevector <4 x double> %unmaskedload21.i.152, <4 x double> poison, <1 x i32> <i32 2>
  %72 = shufflevector <4 x double> %unmaskedload21.i.152, <4 x double> poison, <1 x i32> <i32 3>
  %73 = fmul <1 x double> %68, %69
  %74 = fmul <1 x double> %68, %70
  %75 = fmul <1 x double> %68, %71
  %76 = shufflevector <1 x double> %75, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = fmul <1 x double> %68, %72
  %78 = shufflevector <1 x double> %77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = shufflevector <1 x double> %73, <1 x double> %74, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %80 = shufflevector <4 x double> %79, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %81 = shufflevector <4 x double> %80, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %82 = fadd <4 x double> %64, %81
  store <4 x double> %82, ptr %45, align 8
  %83 = add nuw nsw i64 %47, 2
  %exitcond.1.not.i.153 = icmp eq i64 %83, 32
  br i1 %exitcond.1.not.i.153, label %84, label %.critedge.1.i

84:                                               ; preds = %.critedge.1.i
  %85 = add nuw nsw i64 %3, 1
  %exitcond19.not.i = icmp eq i64 %85, 16
  br i1 %exitcond19.not.i, label %.preheader15.i.1, label %.preheader15.i

.preheader15.i.1:                                 ; preds = %84, %168
  %86 = phi i64 [ %169, %168 ], [ 0, %84 ]
  %87 = add nuw nsw i64 %86, 16
  %88 = shl i64 %87, 5
  %89 = shl i64 %87, 3
  %90 = getelementptr double, ptr %.unpack32, i64 %89
  %invariant.gep24.i.1 = getelementptr double, ptr %.unpack2, i64 %88
  %.promoted26.i.1 = load <4 x double>, ptr %90, align 8
  br label %.critedge.i.1

.critedge.i.1:                                    ; preds = %.critedge.i.1, %.preheader15.i.1
  %91 = phi <4 x double> [ %.promoted26.i.1, %.preheader15.i.1 ], [ %127, %.critedge.i.1 ]
  %92 = phi i64 [ 0, %.preheader15.i.1 ], [ %128, %.critedge.i.1 ]
  %93 = shl nuw nsw i64 %92, 3
  %gep25.i.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %92
  %94 = load double, ptr %gep25.i.1, align 8
  %95 = insertelement <1 x double> poison, double %94, i64 0
  %gep.i.1 = getelementptr double, ptr %.unpack17, i64 %93
  %unmaskedload.i.1 = load <4 x double>, ptr %gep.i.1, align 8
  %96 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> zeroinitializer
  %97 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 1>
  %98 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 2>
  %99 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 3>
  %100 = fmul <1 x double> %95, %96
  %101 = fmul <1 x double> %95, %97
  %102 = fmul <1 x double> %95, %98
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = fmul <1 x double> %95, %99
  %105 = shufflevector <1 x double> %104, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %106 = shufflevector <1 x double> %100, <1 x double> %101, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %105, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %109 = fadd <4 x double> %91, %108
  store <4 x double> %109, ptr %90, align 8
  %110 = or disjoint i64 %92, 1
  %111 = shl nuw nsw i64 %110, 3
  %gep25.i.1.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %110
  %112 = load double, ptr %gep25.i.1.1, align 8
  %113 = insertelement <1 x double> poison, double %112, i64 0
  %gep.i.1.1 = getelementptr double, ptr %.unpack17, i64 %111
  %unmaskedload.i.1.1 = load <4 x double>, ptr %gep.i.1.1, align 8
  %114 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> zeroinitializer
  %115 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 1>
  %116 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 2>
  %117 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 3>
  %118 = fmul <1 x double> %113, %114
  %119 = fmul <1 x double> %113, %115
  %120 = fmul <1 x double> %113, %116
  %121 = shufflevector <1 x double> %120, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %122 = fmul <1 x double> %113, %117
  %123 = shufflevector <1 x double> %122, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %124 = shufflevector <1 x double> %118, <1 x double> %119, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %125 = shufflevector <4 x double> %124, <4 x double> %121, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %126 = shufflevector <4 x double> %125, <4 x double> %123, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %127 = fadd <4 x double> %109, %126
  store <4 x double> %127, ptr %90, align 8
  %128 = add nuw nsw i64 %92, 2
  %exitcond.not.i.1.1 = icmp eq i64 %128, 32
  br i1 %exitcond.not.i.1.1, label %.preheader.1.i.1, label %.critedge.i.1

.preheader.1.i.1:                                 ; preds = %.critedge.i.1
  %129 = getelementptr double, ptr %90, i64 4
  %.promoted.i.1 = load <4 x double>, ptr %129, align 8
  br label %.critedge.1.i.1

.critedge.1.i.1:                                  ; preds = %.critedge.1.i.1, %.preheader.1.i.1
  %130 = phi <4 x double> [ %.promoted.i.1, %.preheader.1.i.1 ], [ %166, %.critedge.1.i.1 ]
  %131 = phi i64 [ 0, %.preheader.1.i.1 ], [ %167, %.critedge.1.i.1 ]
  %132 = shl nuw nsw i64 %131, 3
  %gep23.i.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %131
  %133 = load double, ptr %gep23.i.1, align 8
  %134 = insertelement <1 x double> poison, double %133, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %132
  %unmaskedload21.i.1 = load <4 x double>, ptr %gep.1.i.1, align 8
  %135 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> zeroinitializer
  %136 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 1>
  %137 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 2>
  %138 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 3>
  %139 = fmul <1 x double> %134, %135
  %140 = fmul <1 x double> %134, %136
  %141 = fmul <1 x double> %134, %137
  %142 = shufflevector <1 x double> %141, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %143 = fmul <1 x double> %134, %138
  %144 = shufflevector <1 x double> %143, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %145 = shufflevector <1 x double> %139, <1 x double> %140, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %146 = shufflevector <4 x double> %145, <4 x double> %142, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %147 = shufflevector <4 x double> %146, <4 x double> %144, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %148 = fadd <4 x double> %130, %147
  store <4 x double> %148, ptr %129, align 8
  %149 = or disjoint i64 %131, 1
  %150 = shl nuw nsw i64 %149, 3
  %gep23.i.1.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %149
  %151 = load double, ptr %gep23.i.1.1, align 8
  %152 = insertelement <1 x double> poison, double %151, i64 0
  %gep.1.i.1.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %150
  %unmaskedload21.i.1.1 = load <4 x double>, ptr %gep.1.i.1.1, align 8
  %153 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> zeroinitializer
  %154 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 1>
  %155 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 2>
  %156 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 3>
  %157 = fmul <1 x double> %152, %153
  %158 = fmul <1 x double> %152, %154
  %159 = fmul <1 x double> %152, %155
  %160 = shufflevector <1 x double> %159, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %161 = fmul <1 x double> %152, %156
  %162 = shufflevector <1 x double> %161, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %163 = shufflevector <1 x double> %157, <1 x double> %158, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %164 = shufflevector <4 x double> %163, <4 x double> %160, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %165 = shufflevector <4 x double> %164, <4 x double> %162, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %166 = fadd <4 x double> %148, %165
  store <4 x double> %166, ptr %129, align 8
  %167 = add nuw nsw i64 %131, 2
  %exitcond.1.not.i.1.1 = icmp eq i64 %167, 32
  br i1 %exitcond.1.not.i.1.1, label %168, label %.critedge.1.i.1

168:                                              ; preds = %.critedge.1.i.1
  %169 = add nuw nsw i64 %86, 1
  %exitcond19.not.i.1 = icmp eq i64 %169, 16
  br i1 %exitcond19.not.i.1, label %.preheader15.i.2, label %.preheader15.i.1

.preheader15.i.2:                                 ; preds = %168, %252
  %170 = phi i64 [ %253, %252 ], [ 0, %168 ]
  %171 = add nuw nsw i64 %170, 32
  %172 = shl i64 %171, 5
  %173 = shl i64 %171, 3
  %174 = getelementptr double, ptr %.unpack32, i64 %173
  %invariant.gep24.i.2 = getelementptr double, ptr %.unpack2, i64 %172
  %.promoted26.i.2 = load <4 x double>, ptr %174, align 8
  br label %.critedge.i.2

.critedge.i.2:                                    ; preds = %.critedge.i.2, %.preheader15.i.2
  %175 = phi <4 x double> [ %.promoted26.i.2, %.preheader15.i.2 ], [ %211, %.critedge.i.2 ]
  %176 = phi i64 [ 0, %.preheader15.i.2 ], [ %212, %.critedge.i.2 ]
  %177 = shl nuw nsw i64 %176, 3
  %gep25.i.2 = getelementptr double, ptr %invariant.gep24.i.2, i64 %176
  %178 = load double, ptr %gep25.i.2, align 8
  %179 = insertelement <1 x double> poison, double %178, i64 0
  %gep.i.2 = getelementptr double, ptr %.unpack17, i64 %177
  %unmaskedload.i.2 = load <4 x double>, ptr %gep.i.2, align 8
  %180 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> zeroinitializer
  %181 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 1>
  %182 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 2>
  %183 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 3>
  %184 = fmul <1 x double> %179, %180
  %185 = fmul <1 x double> %179, %181
  %186 = fmul <1 x double> %179, %182
  %187 = shufflevector <1 x double> %186, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %188 = fmul <1 x double> %179, %183
  %189 = shufflevector <1 x double> %188, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %190 = shufflevector <1 x double> %184, <1 x double> %185, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %191 = shufflevector <4 x double> %190, <4 x double> %187, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %192 = shufflevector <4 x double> %191, <4 x double> %189, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %193 = fadd <4 x double> %175, %192
  store <4 x double> %193, ptr %174, align 8
  %194 = or disjoint i64 %176, 1
  %195 = shl nuw nsw i64 %194, 3
  %gep25.i.2.1 = getelementptr double, ptr %invariant.gep24.i.2, i64 %194
  %196 = load double, ptr %gep25.i.2.1, align 8
  %197 = insertelement <1 x double> poison, double %196, i64 0
  %gep.i.2.1 = getelementptr double, ptr %.unpack17, i64 %195
  %unmaskedload.i.2.1 = load <4 x double>, ptr %gep.i.2.1, align 8
  %198 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> zeroinitializer
  %199 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 1>
  %200 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 2>
  %201 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 3>
  %202 = fmul <1 x double> %197, %198
  %203 = fmul <1 x double> %197, %199
  %204 = fmul <1 x double> %197, %200
  %205 = shufflevector <1 x double> %204, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %206 = fmul <1 x double> %197, %201
  %207 = shufflevector <1 x double> %206, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %208 = shufflevector <1 x double> %202, <1 x double> %203, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %209 = shufflevector <4 x double> %208, <4 x double> %205, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %210 = shufflevector <4 x double> %209, <4 x double> %207, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %211 = fadd <4 x double> %193, %210
  store <4 x double> %211, ptr %174, align 8
  %212 = add nuw nsw i64 %176, 2
  %exitcond.not.i.2.1 = icmp eq i64 %212, 32
  br i1 %exitcond.not.i.2.1, label %.preheader.1.i.2, label %.critedge.i.2

.preheader.1.i.2:                                 ; preds = %.critedge.i.2
  %213 = getelementptr double, ptr %174, i64 4
  %.promoted.i.2 = load <4 x double>, ptr %213, align 8
  br label %.critedge.1.i.2

.critedge.1.i.2:                                  ; preds = %.critedge.1.i.2, %.preheader.1.i.2
  %214 = phi <4 x double> [ %.promoted.i.2, %.preheader.1.i.2 ], [ %250, %.critedge.1.i.2 ]
  %215 = phi i64 [ 0, %.preheader.1.i.2 ], [ %251, %.critedge.1.i.2 ]
  %216 = shl nuw nsw i64 %215, 3
  %gep23.i.2 = getelementptr double, ptr %invariant.gep24.i.2, i64 %215
  %217 = load double, ptr %gep23.i.2, align 8
  %218 = insertelement <1 x double> poison, double %217, i64 0
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %216
  %unmaskedload21.i.2 = load <4 x double>, ptr %gep.1.i.2, align 8
  %219 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> zeroinitializer
  %220 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 1>
  %221 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 2>
  %222 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 3>
  %223 = fmul <1 x double> %218, %219
  %224 = fmul <1 x double> %218, %220
  %225 = fmul <1 x double> %218, %221
  %226 = shufflevector <1 x double> %225, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %227 = fmul <1 x double> %218, %222
  %228 = shufflevector <1 x double> %227, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %229 = shufflevector <1 x double> %223, <1 x double> %224, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %230 = shufflevector <4 x double> %229, <4 x double> %226, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %231 = shufflevector <4 x double> %230, <4 x double> %228, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %232 = fadd <4 x double> %214, %231
  store <4 x double> %232, ptr %213, align 8
  %233 = or disjoint i64 %215, 1
  %234 = shl nuw nsw i64 %233, 3
  %gep23.i.2.1 = getelementptr double, ptr %invariant.gep24.i.2, i64 %233
  %235 = load double, ptr %gep23.i.2.1, align 8
  %236 = insertelement <1 x double> poison, double %235, i64 0
  %gep.1.i.2.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %234
  %unmaskedload21.i.2.1 = load <4 x double>, ptr %gep.1.i.2.1, align 8
  %237 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> zeroinitializer
  %238 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 1>
  %239 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 2>
  %240 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 3>
  %241 = fmul <1 x double> %236, %237
  %242 = fmul <1 x double> %236, %238
  %243 = fmul <1 x double> %236, %239
  %244 = shufflevector <1 x double> %243, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %245 = fmul <1 x double> %236, %240
  %246 = shufflevector <1 x double> %245, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %247 = shufflevector <1 x double> %241, <1 x double> %242, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %248 = shufflevector <4 x double> %247, <4 x double> %244, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %249 = shufflevector <4 x double> %248, <4 x double> %246, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %250 = fadd <4 x double> %232, %249
  store <4 x double> %250, ptr %213, align 8
  %251 = add nuw nsw i64 %215, 2
  %exitcond.1.not.i.2.1 = icmp eq i64 %251, 32
  br i1 %exitcond.1.not.i.2.1, label %252, label %.critedge.1.i.2

252:                                              ; preds = %.critedge.1.i.2
  %253 = add nuw nsw i64 %170, 1
  %exitcond19.not.i.2 = icmp eq i64 %253, 16
  br i1 %exitcond19.not.i.2, label %.preheader15.i.3, label %.preheader15.i.2

.preheader15.i.3:                                 ; preds = %252, %336
  %254 = phi i64 [ %337, %336 ], [ 0, %252 ]
  %255 = add nuw nsw i64 %254, 48
  %256 = shl i64 %255, 5
  %257 = shl i64 %255, 3
  %258 = getelementptr double, ptr %.unpack32, i64 %257
  %invariant.gep24.i.3 = getelementptr double, ptr %.unpack2, i64 %256
  %.promoted26.i.3 = load <4 x double>, ptr %258, align 8
  br label %.critedge.i.3

.critedge.i.3:                                    ; preds = %.critedge.i.3, %.preheader15.i.3
  %259 = phi <4 x double> [ %.promoted26.i.3, %.preheader15.i.3 ], [ %295, %.critedge.i.3 ]
  %260 = phi i64 [ 0, %.preheader15.i.3 ], [ %296, %.critedge.i.3 ]
  %261 = shl nuw nsw i64 %260, 3
  %gep25.i.3 = getelementptr double, ptr %invariant.gep24.i.3, i64 %260
  %262 = load double, ptr %gep25.i.3, align 8
  %263 = insertelement <1 x double> poison, double %262, i64 0
  %gep.i.3 = getelementptr double, ptr %.unpack17, i64 %261
  %unmaskedload.i.3 = load <4 x double>, ptr %gep.i.3, align 8
  %264 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> zeroinitializer
  %265 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 1>
  %266 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 2>
  %267 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 3>
  %268 = fmul <1 x double> %263, %264
  %269 = fmul <1 x double> %263, %265
  %270 = fmul <1 x double> %263, %266
  %271 = shufflevector <1 x double> %270, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %272 = fmul <1 x double> %263, %267
  %273 = shufflevector <1 x double> %272, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %274 = shufflevector <1 x double> %268, <1 x double> %269, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %275 = shufflevector <4 x double> %274, <4 x double> %271, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %276 = shufflevector <4 x double> %275, <4 x double> %273, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %277 = fadd <4 x double> %259, %276
  store <4 x double> %277, ptr %258, align 8
  %278 = or disjoint i64 %260, 1
  %279 = shl nuw nsw i64 %278, 3
  %gep25.i.3.1 = getelementptr double, ptr %invariant.gep24.i.3, i64 %278
  %280 = load double, ptr %gep25.i.3.1, align 8
  %281 = insertelement <1 x double> poison, double %280, i64 0
  %gep.i.3.1 = getelementptr double, ptr %.unpack17, i64 %279
  %unmaskedload.i.3.1 = load <4 x double>, ptr %gep.i.3.1, align 8
  %282 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> zeroinitializer
  %283 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 1>
  %284 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 2>
  %285 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 3>
  %286 = fmul <1 x double> %281, %282
  %287 = fmul <1 x double> %281, %283
  %288 = fmul <1 x double> %281, %284
  %289 = shufflevector <1 x double> %288, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %290 = fmul <1 x double> %281, %285
  %291 = shufflevector <1 x double> %290, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %292 = shufflevector <1 x double> %286, <1 x double> %287, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %293 = shufflevector <4 x double> %292, <4 x double> %289, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %294 = shufflevector <4 x double> %293, <4 x double> %291, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %295 = fadd <4 x double> %277, %294
  store <4 x double> %295, ptr %258, align 8
  %296 = add nuw nsw i64 %260, 2
  %exitcond.not.i.3.1 = icmp eq i64 %296, 32
  br i1 %exitcond.not.i.3.1, label %.preheader.1.i.3, label %.critedge.i.3

.preheader.1.i.3:                                 ; preds = %.critedge.i.3
  %297 = getelementptr double, ptr %258, i64 4
  %.promoted.i.3 = load <4 x double>, ptr %297, align 8
  br label %.critedge.1.i.3

.critedge.1.i.3:                                  ; preds = %.critedge.1.i.3, %.preheader.1.i.3
  %298 = phi <4 x double> [ %.promoted.i.3, %.preheader.1.i.3 ], [ %334, %.critedge.1.i.3 ]
  %299 = phi i64 [ 0, %.preheader.1.i.3 ], [ %335, %.critedge.1.i.3 ]
  %300 = shl nuw nsw i64 %299, 3
  %gep23.i.3 = getelementptr double, ptr %invariant.gep24.i.3, i64 %299
  %301 = load double, ptr %gep23.i.3, align 8
  %302 = insertelement <1 x double> poison, double %301, i64 0
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %300
  %unmaskedload21.i.3 = load <4 x double>, ptr %gep.1.i.3, align 8
  %303 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> zeroinitializer
  %304 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 1>
  %305 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 2>
  %306 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 3>
  %307 = fmul <1 x double> %302, %303
  %308 = fmul <1 x double> %302, %304
  %309 = fmul <1 x double> %302, %305
  %310 = shufflevector <1 x double> %309, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %311 = fmul <1 x double> %302, %306
  %312 = shufflevector <1 x double> %311, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %313 = shufflevector <1 x double> %307, <1 x double> %308, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %314 = shufflevector <4 x double> %313, <4 x double> %310, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %315 = shufflevector <4 x double> %314, <4 x double> %312, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %316 = fadd <4 x double> %298, %315
  store <4 x double> %316, ptr %297, align 8
  %317 = or disjoint i64 %299, 1
  %318 = shl nuw nsw i64 %317, 3
  %gep23.i.3.1 = getelementptr double, ptr %invariant.gep24.i.3, i64 %317
  %319 = load double, ptr %gep23.i.3.1, align 8
  %320 = insertelement <1 x double> poison, double %319, i64 0
  %gep.1.i.3.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %318
  %unmaskedload21.i.3.1 = load <4 x double>, ptr %gep.1.i.3.1, align 8
  %321 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> zeroinitializer
  %322 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 1>
  %323 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 2>
  %324 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 3>
  %325 = fmul <1 x double> %320, %321
  %326 = fmul <1 x double> %320, %322
  %327 = fmul <1 x double> %320, %323
  %328 = shufflevector <1 x double> %327, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %329 = fmul <1 x double> %320, %324
  %330 = shufflevector <1 x double> %329, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %331 = shufflevector <1 x double> %325, <1 x double> %326, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %332 = shufflevector <4 x double> %331, <4 x double> %328, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %333 = shufflevector <4 x double> %332, <4 x double> %330, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %334 = fadd <4 x double> %316, %333
  store <4 x double> %334, ptr %297, align 8
  %335 = add nuw nsw i64 %299, 2
  %exitcond.1.not.i.3.1 = icmp eq i64 %335, 32
  br i1 %exitcond.1.not.i.3.1, label %336, label %.critedge.1.i.3

336:                                              ; preds = %.critedge.1.i.3
  %337 = add nuw nsw i64 %254, 1
  %exitcond19.not.i.3 = icmp eq i64 %337, 16
  br i1 %exitcond19.not.i.3, label %kernel.exit, label %.preheader15.i.3

kernel.exit:                                      ; preds = %336
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
.preheader16.i:
  %1 = getelementptr ptr, ptr %0, i64 1
  %2 = load ptr, ptr %1, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 15
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %9, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %6, i64 4
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %91, %.preheader16.i
  %10 = phi i64 [ 0, %.preheader16.i ], [ %92, %91 ]
  %11 = shl i64 %10, 5
  %12 = shl i64 %10, 3
  %13 = getelementptr double, ptr %9, i64 %12
  %invariant.gep24.i = getelementptr double, ptr %3, i64 %11
  %.promoted26.i = load <4 x double>, ptr %13, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %14 = phi <4 x double> [ %.promoted26.i, %.preheader15.i ], [ %50, %.critedge.i ]
  %15 = phi i64 [ 0, %.preheader15.i ], [ %51, %.critedge.i ]
  %16 = shl nuw nsw i64 %15, 3
  %gep25.i = getelementptr double, ptr %invariant.gep24.i, i64 %15
  %17 = load double, ptr %gep25.i, align 8
  %18 = insertelement <1 x double> poison, double %17, i64 0
  %gep.i = getelementptr double, ptr %6, i64 %16
  %unmaskedload.i = load <4 x double>, ptr %gep.i, align 8
  %19 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> zeroinitializer
  %20 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 1>
  %21 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 2>
  %22 = shufflevector <4 x double> %unmaskedload.i, <4 x double> poison, <1 x i32> <i32 3>
  %23 = fmul <1 x double> %18, %19
  %24 = fmul <1 x double> %18, %20
  %25 = fmul <1 x double> %18, %21
  %26 = shufflevector <1 x double> %25, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %27 = fmul <1 x double> %18, %22
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = shufflevector <1 x double> %23, <1 x double> %24, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %30 = shufflevector <4 x double> %29, <4 x double> %26, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %31 = shufflevector <4 x double> %30, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %32 = fadd <4 x double> %14, %31
  store <4 x double> %32, ptr %13, align 8
  %33 = or disjoint i64 %15, 1
  %34 = shl nuw nsw i64 %33, 3
  %gep25.i.11 = getelementptr double, ptr %invariant.gep24.i, i64 %33
  %35 = load double, ptr %gep25.i.11, align 8
  %36 = insertelement <1 x double> poison, double %35, i64 0
  %gep.i.12 = getelementptr double, ptr %6, i64 %34
  %unmaskedload.i.13 = load <4 x double>, ptr %gep.i.12, align 8
  %37 = shufflevector <4 x double> %unmaskedload.i.13, <4 x double> poison, <1 x i32> zeroinitializer
  %38 = shufflevector <4 x double> %unmaskedload.i.13, <4 x double> poison, <1 x i32> <i32 1>
  %39 = shufflevector <4 x double> %unmaskedload.i.13, <4 x double> poison, <1 x i32> <i32 2>
  %40 = shufflevector <4 x double> %unmaskedload.i.13, <4 x double> poison, <1 x i32> <i32 3>
  %41 = fmul <1 x double> %36, %37
  %42 = fmul <1 x double> %36, %38
  %43 = fmul <1 x double> %36, %39
  %44 = shufflevector <1 x double> %43, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %45 = fmul <1 x double> %36, %40
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = shufflevector <1 x double> %41, <1 x double> %42, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %44, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %50 = fadd <4 x double> %32, %49
  store <4 x double> %50, ptr %13, align 8
  %51 = add nuw nsw i64 %15, 2
  %exitcond.not.i.14 = icmp eq i64 %51, 32
  br i1 %exitcond.not.i.14, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %52 = getelementptr double, ptr %13, i64 4
  %.promoted.i = load <4 x double>, ptr %52, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %53 = phi <4 x double> [ %.promoted.i, %.preheader.1.i ], [ %89, %.critedge.1.i ]
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %90, %.critedge.1.i ]
  %55 = shl nuw nsw i64 %54, 3
  %gep23.i = getelementptr double, ptr %invariant.gep24.i, i64 %54
  %56 = load double, ptr %gep23.i, align 8
  %57 = insertelement <1 x double> poison, double %56, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %55
  %unmaskedload21.i = load <4 x double>, ptr %gep.1.i, align 8
  %58 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> zeroinitializer
  %59 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 1>
  %60 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 2>
  %61 = shufflevector <4 x double> %unmaskedload21.i, <4 x double> poison, <1 x i32> <i32 3>
  %62 = fmul <1 x double> %57, %58
  %63 = fmul <1 x double> %57, %59
  %64 = fmul <1 x double> %57, %60
  %65 = shufflevector <1 x double> %64, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %66 = fmul <1 x double> %57, %61
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = shufflevector <1 x double> %62, <1 x double> %63, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %69 = shufflevector <4 x double> %68, <4 x double> %65, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %71 = fadd <4 x double> %53, %70
  store <4 x double> %71, ptr %52, align 8
  %72 = or disjoint i64 %54, 1
  %73 = shl nuw nsw i64 %72, 3
  %gep23.i.16 = getelementptr double, ptr %invariant.gep24.i, i64 %72
  %74 = load double, ptr %gep23.i.16, align 8
  %75 = insertelement <1 x double> poison, double %74, i64 0
  %gep.1.i.17 = getelementptr double, ptr %invariant.gep.1.i, i64 %73
  %unmaskedload21.i.18 = load <4 x double>, ptr %gep.1.i.17, align 8
  %76 = shufflevector <4 x double> %unmaskedload21.i.18, <4 x double> poison, <1 x i32> zeroinitializer
  %77 = shufflevector <4 x double> %unmaskedload21.i.18, <4 x double> poison, <1 x i32> <i32 1>
  %78 = shufflevector <4 x double> %unmaskedload21.i.18, <4 x double> poison, <1 x i32> <i32 2>
  %79 = shufflevector <4 x double> %unmaskedload21.i.18, <4 x double> poison, <1 x i32> <i32 3>
  %80 = fmul <1 x double> %75, %76
  %81 = fmul <1 x double> %75, %77
  %82 = fmul <1 x double> %75, %78
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = fmul <1 x double> %75, %79
  %85 = shufflevector <1 x double> %84, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = shufflevector <1 x double> %80, <1 x double> %81, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %87 = shufflevector <4 x double> %86, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %89 = fadd <4 x double> %71, %88
  store <4 x double> %89, ptr %52, align 8
  %90 = add nuw nsw i64 %54, 2
  %exitcond.1.not.i.19 = icmp eq i64 %90, 32
  br i1 %exitcond.1.not.i.19, label %91, label %.critedge.1.i

91:                                               ; preds = %.critedge.1.i
  %92 = add nuw nsw i64 %10, 1
  %exitcond19.not.i = icmp eq i64 %92, 16
  br i1 %exitcond19.not.i, label %.preheader15.i.1, label %.preheader15.i

.preheader15.i.1:                                 ; preds = %91, %175
  %93 = phi i64 [ %176, %175 ], [ 0, %91 ]
  %94 = add nuw nsw i64 %93, 16
  %95 = shl i64 %94, 5
  %96 = shl i64 %94, 3
  %97 = getelementptr double, ptr %9, i64 %96
  %invariant.gep24.i.1 = getelementptr double, ptr %3, i64 %95
  %.promoted26.i.1 = load <4 x double>, ptr %97, align 8
  br label %.critedge.i.1

.critedge.i.1:                                    ; preds = %.critedge.i.1, %.preheader15.i.1
  %98 = phi <4 x double> [ %.promoted26.i.1, %.preheader15.i.1 ], [ %134, %.critedge.i.1 ]
  %99 = phi i64 [ 0, %.preheader15.i.1 ], [ %135, %.critedge.i.1 ]
  %100 = shl nuw nsw i64 %99, 3
  %gep25.i.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %99
  %101 = load double, ptr %gep25.i.1, align 8
  %102 = insertelement <1 x double> poison, double %101, i64 0
  %gep.i.1 = getelementptr double, ptr %6, i64 %100
  %unmaskedload.i.1 = load <4 x double>, ptr %gep.i.1, align 8
  %103 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> zeroinitializer
  %104 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 1>
  %105 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 2>
  %106 = shufflevector <4 x double> %unmaskedload.i.1, <4 x double> poison, <1 x i32> <i32 3>
  %107 = fmul <1 x double> %102, %103
  %108 = fmul <1 x double> %102, %104
  %109 = fmul <1 x double> %102, %105
  %110 = shufflevector <1 x double> %109, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %111 = fmul <1 x double> %102, %106
  %112 = shufflevector <1 x double> %111, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %113 = shufflevector <1 x double> %107, <1 x double> %108, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %110, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %115 = shufflevector <4 x double> %114, <4 x double> %112, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %116 = fadd <4 x double> %98, %115
  store <4 x double> %116, ptr %97, align 8
  %117 = or disjoint i64 %99, 1
  %118 = shl nuw nsw i64 %117, 3
  %gep25.i.1.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %117
  %119 = load double, ptr %gep25.i.1.1, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %gep.i.1.1 = getelementptr double, ptr %6, i64 %118
  %unmaskedload.i.1.1 = load <4 x double>, ptr %gep.i.1.1, align 8
  %121 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> zeroinitializer
  %122 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 1>
  %123 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 2>
  %124 = shufflevector <4 x double> %unmaskedload.i.1.1, <4 x double> poison, <1 x i32> <i32 3>
  %125 = fmul <1 x double> %120, %121
  %126 = fmul <1 x double> %120, %122
  %127 = fmul <1 x double> %120, %123
  %128 = shufflevector <1 x double> %127, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %129 = fmul <1 x double> %120, %124
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = shufflevector <1 x double> %125, <1 x double> %126, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %132 = shufflevector <4 x double> %131, <4 x double> %128, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %134 = fadd <4 x double> %116, %133
  store <4 x double> %134, ptr %97, align 8
  %135 = add nuw nsw i64 %99, 2
  %exitcond.not.i.1.1 = icmp eq i64 %135, 32
  br i1 %exitcond.not.i.1.1, label %.preheader.1.i.1, label %.critedge.i.1

.preheader.1.i.1:                                 ; preds = %.critedge.i.1
  %136 = getelementptr double, ptr %97, i64 4
  %.promoted.i.1 = load <4 x double>, ptr %136, align 8
  br label %.critedge.1.i.1

.critedge.1.i.1:                                  ; preds = %.critedge.1.i.1, %.preheader.1.i.1
  %137 = phi <4 x double> [ %.promoted.i.1, %.preheader.1.i.1 ], [ %173, %.critedge.1.i.1 ]
  %138 = phi i64 [ 0, %.preheader.1.i.1 ], [ %174, %.critedge.1.i.1 ]
  %139 = shl nuw nsw i64 %138, 3
  %gep23.i.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %138
  %140 = load double, ptr %gep23.i.1, align 8
  %141 = insertelement <1 x double> poison, double %140, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %139
  %unmaskedload21.i.1 = load <4 x double>, ptr %gep.1.i.1, align 8
  %142 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> zeroinitializer
  %143 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 1>
  %144 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 2>
  %145 = shufflevector <4 x double> %unmaskedload21.i.1, <4 x double> poison, <1 x i32> <i32 3>
  %146 = fmul <1 x double> %141, %142
  %147 = fmul <1 x double> %141, %143
  %148 = fmul <1 x double> %141, %144
  %149 = shufflevector <1 x double> %148, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %150 = fmul <1 x double> %141, %145
  %151 = shufflevector <1 x double> %150, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %152 = shufflevector <1 x double> %146, <1 x double> %147, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %149, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %151, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %155 = fadd <4 x double> %137, %154
  store <4 x double> %155, ptr %136, align 8
  %156 = or disjoint i64 %138, 1
  %157 = shl nuw nsw i64 %156, 3
  %gep23.i.1.1 = getelementptr double, ptr %invariant.gep24.i.1, i64 %156
  %158 = load double, ptr %gep23.i.1.1, align 8
  %159 = insertelement <1 x double> poison, double %158, i64 0
  %gep.1.i.1.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %157
  %unmaskedload21.i.1.1 = load <4 x double>, ptr %gep.1.i.1.1, align 8
  %160 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> zeroinitializer
  %161 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 1>
  %162 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 2>
  %163 = shufflevector <4 x double> %unmaskedload21.i.1.1, <4 x double> poison, <1 x i32> <i32 3>
  %164 = fmul <1 x double> %159, %160
  %165 = fmul <1 x double> %159, %161
  %166 = fmul <1 x double> %159, %162
  %167 = shufflevector <1 x double> %166, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %168 = fmul <1 x double> %159, %163
  %169 = shufflevector <1 x double> %168, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %170 = shufflevector <1 x double> %164, <1 x double> %165, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %171 = shufflevector <4 x double> %170, <4 x double> %167, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %172 = shufflevector <4 x double> %171, <4 x double> %169, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %173 = fadd <4 x double> %155, %172
  store <4 x double> %173, ptr %136, align 8
  %174 = add nuw nsw i64 %138, 2
  %exitcond.1.not.i.1.1 = icmp eq i64 %174, 32
  br i1 %exitcond.1.not.i.1.1, label %175, label %.critedge.1.i.1

175:                                              ; preds = %.critedge.1.i.1
  %176 = add nuw nsw i64 %93, 1
  %exitcond19.not.i.1 = icmp eq i64 %176, 16
  br i1 %exitcond19.not.i.1, label %.preheader15.i.2, label %.preheader15.i.1

.preheader15.i.2:                                 ; preds = %175, %259
  %177 = phi i64 [ %260, %259 ], [ 0, %175 ]
  %178 = add nuw nsw i64 %177, 32
  %179 = shl i64 %178, 5
  %180 = shl i64 %178, 3
  %181 = getelementptr double, ptr %9, i64 %180
  %invariant.gep24.i.2 = getelementptr double, ptr %3, i64 %179
  %.promoted26.i.2 = load <4 x double>, ptr %181, align 8
  br label %.critedge.i.2

.critedge.i.2:                                    ; preds = %.critedge.i.2, %.preheader15.i.2
  %182 = phi <4 x double> [ %.promoted26.i.2, %.preheader15.i.2 ], [ %218, %.critedge.i.2 ]
  %183 = phi i64 [ 0, %.preheader15.i.2 ], [ %219, %.critedge.i.2 ]
  %184 = shl nuw nsw i64 %183, 3
  %gep25.i.2 = getelementptr double, ptr %invariant.gep24.i.2, i64 %183
  %185 = load double, ptr %gep25.i.2, align 8
  %186 = insertelement <1 x double> poison, double %185, i64 0
  %gep.i.2 = getelementptr double, ptr %6, i64 %184
  %unmaskedload.i.2 = load <4 x double>, ptr %gep.i.2, align 8
  %187 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> zeroinitializer
  %188 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 1>
  %189 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 2>
  %190 = shufflevector <4 x double> %unmaskedload.i.2, <4 x double> poison, <1 x i32> <i32 3>
  %191 = fmul <1 x double> %186, %187
  %192 = fmul <1 x double> %186, %188
  %193 = fmul <1 x double> %186, %189
  %194 = shufflevector <1 x double> %193, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %195 = fmul <1 x double> %186, %190
  %196 = shufflevector <1 x double> %195, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %197 = shufflevector <1 x double> %191, <1 x double> %192, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %198 = shufflevector <4 x double> %197, <4 x double> %194, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %199 = shufflevector <4 x double> %198, <4 x double> %196, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %200 = fadd <4 x double> %182, %199
  store <4 x double> %200, ptr %181, align 8
  %201 = or disjoint i64 %183, 1
  %202 = shl nuw nsw i64 %201, 3
  %gep25.i.2.1 = getelementptr double, ptr %invariant.gep24.i.2, i64 %201
  %203 = load double, ptr %gep25.i.2.1, align 8
  %204 = insertelement <1 x double> poison, double %203, i64 0
  %gep.i.2.1 = getelementptr double, ptr %6, i64 %202
  %unmaskedload.i.2.1 = load <4 x double>, ptr %gep.i.2.1, align 8
  %205 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> zeroinitializer
  %206 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 1>
  %207 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 2>
  %208 = shufflevector <4 x double> %unmaskedload.i.2.1, <4 x double> poison, <1 x i32> <i32 3>
  %209 = fmul <1 x double> %204, %205
  %210 = fmul <1 x double> %204, %206
  %211 = fmul <1 x double> %204, %207
  %212 = shufflevector <1 x double> %211, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %213 = fmul <1 x double> %204, %208
  %214 = shufflevector <1 x double> %213, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %215 = shufflevector <1 x double> %209, <1 x double> %210, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %216 = shufflevector <4 x double> %215, <4 x double> %212, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %217 = shufflevector <4 x double> %216, <4 x double> %214, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %218 = fadd <4 x double> %200, %217
  store <4 x double> %218, ptr %181, align 8
  %219 = add nuw nsw i64 %183, 2
  %exitcond.not.i.2.1 = icmp eq i64 %219, 32
  br i1 %exitcond.not.i.2.1, label %.preheader.1.i.2, label %.critedge.i.2

.preheader.1.i.2:                                 ; preds = %.critedge.i.2
  %220 = getelementptr double, ptr %181, i64 4
  %.promoted.i.2 = load <4 x double>, ptr %220, align 8
  br label %.critedge.1.i.2

.critedge.1.i.2:                                  ; preds = %.critedge.1.i.2, %.preheader.1.i.2
  %221 = phi <4 x double> [ %.promoted.i.2, %.preheader.1.i.2 ], [ %257, %.critedge.1.i.2 ]
  %222 = phi i64 [ 0, %.preheader.1.i.2 ], [ %258, %.critedge.1.i.2 ]
  %223 = shl nuw nsw i64 %222, 3
  %gep23.i.2 = getelementptr double, ptr %invariant.gep24.i.2, i64 %222
  %224 = load double, ptr %gep23.i.2, align 8
  %225 = insertelement <1 x double> poison, double %224, i64 0
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %223
  %unmaskedload21.i.2 = load <4 x double>, ptr %gep.1.i.2, align 8
  %226 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> zeroinitializer
  %227 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 1>
  %228 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 2>
  %229 = shufflevector <4 x double> %unmaskedload21.i.2, <4 x double> poison, <1 x i32> <i32 3>
  %230 = fmul <1 x double> %225, %226
  %231 = fmul <1 x double> %225, %227
  %232 = fmul <1 x double> %225, %228
  %233 = shufflevector <1 x double> %232, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %234 = fmul <1 x double> %225, %229
  %235 = shufflevector <1 x double> %234, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %236 = shufflevector <1 x double> %230, <1 x double> %231, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %237 = shufflevector <4 x double> %236, <4 x double> %233, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %238 = shufflevector <4 x double> %237, <4 x double> %235, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %239 = fadd <4 x double> %221, %238
  store <4 x double> %239, ptr %220, align 8
  %240 = or disjoint i64 %222, 1
  %241 = shl nuw nsw i64 %240, 3
  %gep23.i.2.1 = getelementptr double, ptr %invariant.gep24.i.2, i64 %240
  %242 = load double, ptr %gep23.i.2.1, align 8
  %243 = insertelement <1 x double> poison, double %242, i64 0
  %gep.1.i.2.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %241
  %unmaskedload21.i.2.1 = load <4 x double>, ptr %gep.1.i.2.1, align 8
  %244 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> zeroinitializer
  %245 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 1>
  %246 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 2>
  %247 = shufflevector <4 x double> %unmaskedload21.i.2.1, <4 x double> poison, <1 x i32> <i32 3>
  %248 = fmul <1 x double> %243, %244
  %249 = fmul <1 x double> %243, %245
  %250 = fmul <1 x double> %243, %246
  %251 = shufflevector <1 x double> %250, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %252 = fmul <1 x double> %243, %247
  %253 = shufflevector <1 x double> %252, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %254 = shufflevector <1 x double> %248, <1 x double> %249, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %255 = shufflevector <4 x double> %254, <4 x double> %251, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %256 = shufflevector <4 x double> %255, <4 x double> %253, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %257 = fadd <4 x double> %239, %256
  store <4 x double> %257, ptr %220, align 8
  %258 = add nuw nsw i64 %222, 2
  %exitcond.1.not.i.2.1 = icmp eq i64 %258, 32
  br i1 %exitcond.1.not.i.2.1, label %259, label %.critedge.1.i.2

259:                                              ; preds = %.critedge.1.i.2
  %260 = add nuw nsw i64 %177, 1
  %exitcond19.not.i.2 = icmp eq i64 %260, 16
  br i1 %exitcond19.not.i.2, label %.preheader15.i.3, label %.preheader15.i.2

.preheader15.i.3:                                 ; preds = %259, %343
  %261 = phi i64 [ %344, %343 ], [ 0, %259 ]
  %262 = add nuw nsw i64 %261, 48
  %263 = shl i64 %262, 5
  %264 = shl i64 %262, 3
  %265 = getelementptr double, ptr %9, i64 %264
  %invariant.gep24.i.3 = getelementptr double, ptr %3, i64 %263
  %.promoted26.i.3 = load <4 x double>, ptr %265, align 8
  br label %.critedge.i.3

.critedge.i.3:                                    ; preds = %.critedge.i.3, %.preheader15.i.3
  %266 = phi <4 x double> [ %.promoted26.i.3, %.preheader15.i.3 ], [ %302, %.critedge.i.3 ]
  %267 = phi i64 [ 0, %.preheader15.i.3 ], [ %303, %.critedge.i.3 ]
  %268 = shl nuw nsw i64 %267, 3
  %gep25.i.3 = getelementptr double, ptr %invariant.gep24.i.3, i64 %267
  %269 = load double, ptr %gep25.i.3, align 8
  %270 = insertelement <1 x double> poison, double %269, i64 0
  %gep.i.3 = getelementptr double, ptr %6, i64 %268
  %unmaskedload.i.3 = load <4 x double>, ptr %gep.i.3, align 8
  %271 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> zeroinitializer
  %272 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 1>
  %273 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 2>
  %274 = shufflevector <4 x double> %unmaskedload.i.3, <4 x double> poison, <1 x i32> <i32 3>
  %275 = fmul <1 x double> %270, %271
  %276 = fmul <1 x double> %270, %272
  %277 = fmul <1 x double> %270, %273
  %278 = shufflevector <1 x double> %277, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %279 = fmul <1 x double> %270, %274
  %280 = shufflevector <1 x double> %279, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %281 = shufflevector <1 x double> %275, <1 x double> %276, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %282 = shufflevector <4 x double> %281, <4 x double> %278, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %283 = shufflevector <4 x double> %282, <4 x double> %280, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %284 = fadd <4 x double> %266, %283
  store <4 x double> %284, ptr %265, align 8
  %285 = or disjoint i64 %267, 1
  %286 = shl nuw nsw i64 %285, 3
  %gep25.i.3.1 = getelementptr double, ptr %invariant.gep24.i.3, i64 %285
  %287 = load double, ptr %gep25.i.3.1, align 8
  %288 = insertelement <1 x double> poison, double %287, i64 0
  %gep.i.3.1 = getelementptr double, ptr %6, i64 %286
  %unmaskedload.i.3.1 = load <4 x double>, ptr %gep.i.3.1, align 8
  %289 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> zeroinitializer
  %290 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 1>
  %291 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 2>
  %292 = shufflevector <4 x double> %unmaskedload.i.3.1, <4 x double> poison, <1 x i32> <i32 3>
  %293 = fmul <1 x double> %288, %289
  %294 = fmul <1 x double> %288, %290
  %295 = fmul <1 x double> %288, %291
  %296 = shufflevector <1 x double> %295, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %297 = fmul <1 x double> %288, %292
  %298 = shufflevector <1 x double> %297, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %299 = shufflevector <1 x double> %293, <1 x double> %294, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %300 = shufflevector <4 x double> %299, <4 x double> %296, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %301 = shufflevector <4 x double> %300, <4 x double> %298, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %302 = fadd <4 x double> %284, %301
  store <4 x double> %302, ptr %265, align 8
  %303 = add nuw nsw i64 %267, 2
  %exitcond.not.i.3.1 = icmp eq i64 %303, 32
  br i1 %exitcond.not.i.3.1, label %.preheader.1.i.3, label %.critedge.i.3

.preheader.1.i.3:                                 ; preds = %.critedge.i.3
  %304 = getelementptr double, ptr %265, i64 4
  %.promoted.i.3 = load <4 x double>, ptr %304, align 8
  br label %.critedge.1.i.3

.critedge.1.i.3:                                  ; preds = %.critedge.1.i.3, %.preheader.1.i.3
  %305 = phi <4 x double> [ %.promoted.i.3, %.preheader.1.i.3 ], [ %341, %.critedge.1.i.3 ]
  %306 = phi i64 [ 0, %.preheader.1.i.3 ], [ %342, %.critedge.1.i.3 ]
  %307 = shl nuw nsw i64 %306, 3
  %gep23.i.3 = getelementptr double, ptr %invariant.gep24.i.3, i64 %306
  %308 = load double, ptr %gep23.i.3, align 8
  %309 = insertelement <1 x double> poison, double %308, i64 0
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %307
  %unmaskedload21.i.3 = load <4 x double>, ptr %gep.1.i.3, align 8
  %310 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> zeroinitializer
  %311 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 1>
  %312 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 2>
  %313 = shufflevector <4 x double> %unmaskedload21.i.3, <4 x double> poison, <1 x i32> <i32 3>
  %314 = fmul <1 x double> %309, %310
  %315 = fmul <1 x double> %309, %311
  %316 = fmul <1 x double> %309, %312
  %317 = shufflevector <1 x double> %316, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %318 = fmul <1 x double> %309, %313
  %319 = shufflevector <1 x double> %318, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %320 = shufflevector <1 x double> %314, <1 x double> %315, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %321 = shufflevector <4 x double> %320, <4 x double> %317, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %322 = shufflevector <4 x double> %321, <4 x double> %319, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %323 = fadd <4 x double> %305, %322
  store <4 x double> %323, ptr %304, align 8
  %324 = or disjoint i64 %306, 1
  %325 = shl nuw nsw i64 %324, 3
  %gep23.i.3.1 = getelementptr double, ptr %invariant.gep24.i.3, i64 %324
  %326 = load double, ptr %gep23.i.3.1, align 8
  %327 = insertelement <1 x double> poison, double %326, i64 0
  %gep.1.i.3.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %325
  %unmaskedload21.i.3.1 = load <4 x double>, ptr %gep.1.i.3.1, align 8
  %328 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> zeroinitializer
  %329 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 1>
  %330 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 2>
  %331 = shufflevector <4 x double> %unmaskedload21.i.3.1, <4 x double> poison, <1 x i32> <i32 3>
  %332 = fmul <1 x double> %327, %328
  %333 = fmul <1 x double> %327, %329
  %334 = fmul <1 x double> %327, %330
  %335 = shufflevector <1 x double> %334, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %336 = fmul <1 x double> %327, %331
  %337 = shufflevector <1 x double> %336, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %338 = shufflevector <1 x double> %332, <1 x double> %333, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %339 = shufflevector <4 x double> %338, <4 x double> %335, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %340 = shufflevector <4 x double> %339, <4 x double> %337, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %341 = fadd <4 x double> %323, %340
  store <4 x double> %341, ptr %304, align 8
  %342 = add nuw nsw i64 %306, 2
  %exitcond.1.not.i.3.1 = icmp eq i64 %342, 32
  br i1 %exitcond.1.not.i.3.1, label %343, label %.critedge.1.i.3

343:                                              ; preds = %.critedge.1.i.3
  %344 = add nuw nsw i64 %261, 1
  %exitcond19.not.i.3 = icmp eq i64 %344, 16
  br i1 %exitcond19.not.i.3, label %kernel.exit, label %.preheader15.i.3

kernel.exit:                                      ; preds = %343
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
