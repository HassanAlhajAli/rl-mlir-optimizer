; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader16.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader16.preheader, %110
  %21 = phi i64 [ %111, %110 ], [ 0, %.preheader16.preheader ]
  br label %.preheader15

.preheader15:                                     ; preds = %.preheader16, %108
  %22 = phi i64 [ 0, %.preheader16 ], [ %109, %108 ]
  %23 = add nuw nsw i64 %22, %21
  %24 = shl i64 %23, 5
  %25 = shl i64 %23, 3
  %26 = getelementptr double, ptr %15, i64 %25
  %.promoted = load <4 x double>, ptr %26, align 8
  %invariant.gep21 = getelementptr double, ptr %1, i64 %24
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader15
  %27 = phi i64 [ 0, %.preheader15 ], [ %66, %.critedge ]
  %28 = phi <4 x double> [ %.promoted, %.preheader15 ], [ %65, %.critedge ]
  %29 = shl nuw nsw i64 %27, 3
  %gep22 = getelementptr double, ptr %invariant.gep21, i64 %27
  %30 = load double, ptr %gep22, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %gep = getelementptr double, ptr %8, i64 %29
  %32 = load <4 x double>, ptr %gep, align 8
  %33 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> zeroinitializer
  %34 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 1>
  %35 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 2>
  %36 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 3>
  %37 = fmul <1 x double> %31, %33
  %38 = fmul <1 x double> %31, %34
  %39 = fmul <1 x double> %31, %35
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = fmul <1 x double> %31, %36
  %42 = shufflevector <1 x double> %41, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %43 = shufflevector <1 x double> %37, <1 x double> %38, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %42, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %46 = fadd <4 x double> %28, %45
  store <4 x double> %46, ptr %26, align 8
  %47 = or disjoint i64 %27, 1
  %48 = shl nuw nsw i64 %47, 3
  %gep22.1 = getelementptr double, ptr %invariant.gep21, i64 %47
  %49 = load double, ptr %gep22.1, align 8
  %50 = insertelement <1 x double> poison, double %49, i64 0
  %gep.123 = getelementptr double, ptr %8, i64 %48
  %51 = load <4 x double>, ptr %gep.123, align 8
  %52 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> zeroinitializer
  %53 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 1>
  %54 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 2>
  %55 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 3>
  %56 = fmul <1 x double> %50, %52
  %57 = fmul <1 x double> %50, %53
  %58 = fmul <1 x double> %50, %54
  %59 = shufflevector <1 x double> %58, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %60 = fmul <1 x double> %50, %55
  %61 = shufflevector <1 x double> %60, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <1 x double> %56, <1 x double> %57, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %59, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %64 = shufflevector <4 x double> %63, <4 x double> %61, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %65 = fadd <4 x double> %46, %64
  store <4 x double> %65, ptr %26, align 8
  %66 = add nuw nsw i64 %27, 2
  %exitcond.not.1 = icmp eq i64 %66, 32
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %67 = getelementptr double, ptr %26, i64 4
  %.promoted.1 = load <4 x double>, ptr %67, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %24
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %68 = phi i64 [ 0, %.preheader.1 ], [ %107, %.critedge.1 ]
  %69 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %106, %.critedge.1 ]
  %70 = shl nuw nsw i64 %68, 3
  %gep20 = getelementptr double, ptr %invariant.gep, i64 %68
  %71 = load double, ptr %gep20, align 8
  %72 = insertelement <1 x double> poison, double %71, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %70
  %73 = load <4 x double>, ptr %gep.1, align 8
  %74 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> zeroinitializer
  %75 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 1>
  %76 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 2>
  %77 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 3>
  %78 = fmul <1 x double> %72, %74
  %79 = fmul <1 x double> %72, %75
  %80 = fmul <1 x double> %72, %76
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = fmul <1 x double> %72, %77
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = shufflevector <1 x double> %78, <1 x double> %79, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %85 = shufflevector <4 x double> %84, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %87 = fadd <4 x double> %69, %86
  store <4 x double> %87, ptr %67, align 8
  %88 = or disjoint i64 %68, 1
  %89 = shl nuw nsw i64 %88, 3
  %gep20.1 = getelementptr double, ptr %invariant.gep, i64 %88
  %90 = load double, ptr %gep20.1, align 8
  %91 = insertelement <1 x double> poison, double %90, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %89
  %92 = load <4 x double>, ptr %gep.1.1, align 8
  %93 = shufflevector <4 x double> %92, <4 x double> poison, <1 x i32> zeroinitializer
  %94 = shufflevector <4 x double> %92, <4 x double> poison, <1 x i32> <i32 1>
  %95 = shufflevector <4 x double> %92, <4 x double> poison, <1 x i32> <i32 2>
  %96 = shufflevector <4 x double> %92, <4 x double> poison, <1 x i32> <i32 3>
  %97 = fmul <1 x double> %91, %93
  %98 = fmul <1 x double> %91, %94
  %99 = fmul <1 x double> %91, %95
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = fmul <1 x double> %91, %96
  %102 = shufflevector <1 x double> %101, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %103 = shufflevector <1 x double> %97, <1 x double> %98, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %102, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %106 = fadd <4 x double> %87, %105
  store <4 x double> %106, ptr %67, align 8
  %107 = add nuw nsw i64 %68, 2
  %exitcond.1.not.1 = icmp eq i64 %107, 32
  br i1 %exitcond.1.not.1, label %108, label %.critedge.1

108:                                              ; preds = %.critedge.1
  %109 = add nuw nsw i64 %22, 1
  %exitcond19.not = icmp eq i64 %109, 8
  br i1 %exitcond19.not, label %110, label %.preheader15

110:                                              ; preds = %108
  %111 = add nuw nsw i64 %21, 8
  %112 = icmp ult i64 %21, 56
  br i1 %112, label %.preheader16, label %113

113:                                              ; preds = %110
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %93, %3
  %4 = phi i64 [ %94, %93 ], [ 0, %3 ]
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %91, %.preheader16.i
  %5 = phi i64 [ 0, %.preheader16.i ], [ %92, %91 ]
  %6 = add nuw nsw i64 %5, %4
  %7 = shl i64 %6, 5
  %8 = shl i64 %6, 3
  %9 = getelementptr double, ptr %.unpack32, i64 %8
  %.promoted.i = load <4 x double>, ptr %9, align 8
  %invariant.gep21.i = getelementptr double, ptr %.unpack2, i64 %7
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %10 = phi i64 [ 0, %.preheader15.i ], [ %49, %.critedge.i ]
  %11 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %48, %.critedge.i ]
  %12 = shl nuw nsw i64 %10, 3
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %10
  %13 = load double, ptr %gep22.i, align 8
  %14 = insertelement <1 x double> poison, double %13, i64 0
  %gep.i = getelementptr double, ptr %.unpack17, i64 %12
  %15 = load <4 x double>, ptr %gep.i, align 8
  %16 = shufflevector <4 x double> %15, <4 x double> poison, <1 x i32> zeroinitializer
  %17 = shufflevector <4 x double> %15, <4 x double> poison, <1 x i32> <i32 1>
  %18 = shufflevector <4 x double> %15, <4 x double> poison, <1 x i32> <i32 2>
  %19 = shufflevector <4 x double> %15, <4 x double> poison, <1 x i32> <i32 3>
  %20 = fmul <1 x double> %14, %16
  %21 = fmul <1 x double> %14, %17
  %22 = fmul <1 x double> %14, %18
  %23 = shufflevector <1 x double> %22, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = fmul <1 x double> %14, %19
  %25 = shufflevector <1 x double> %24, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %26 = shufflevector <1 x double> %20, <1 x double> %21, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %27 = shufflevector <4 x double> %26, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %28 = shufflevector <4 x double> %27, <4 x double> %25, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %29 = fadd <4 x double> %11, %28
  store <4 x double> %29, ptr %9, align 8
  %30 = or disjoint i64 %10, 1
  %31 = shl nuw nsw i64 %30, 3
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %30
  %32 = load double, ptr %gep22.i.1, align 8
  %33 = insertelement <1 x double> poison, double %32, i64 0
  %gep.i.1 = getelementptr double, ptr %.unpack17, i64 %31
  %34 = load <4 x double>, ptr %gep.i.1, align 8
  %35 = shufflevector <4 x double> %34, <4 x double> poison, <1 x i32> zeroinitializer
  %36 = shufflevector <4 x double> %34, <4 x double> poison, <1 x i32> <i32 1>
  %37 = shufflevector <4 x double> %34, <4 x double> poison, <1 x i32> <i32 2>
  %38 = shufflevector <4 x double> %34, <4 x double> poison, <1 x i32> <i32 3>
  %39 = fmul <1 x double> %33, %35
  %40 = fmul <1 x double> %33, %36
  %41 = fmul <1 x double> %33, %37
  %42 = shufflevector <1 x double> %41, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %43 = fmul <1 x double> %33, %38
  %44 = shufflevector <1 x double> %43, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %45 = shufflevector <1 x double> %39, <1 x double> %40, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %42, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %44, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %48 = fadd <4 x double> %29, %47
  store <4 x double> %48, ptr %9, align 8
  %49 = add nuw nsw i64 %10, 2
  %exitcond.not.i.1 = icmp eq i64 %49, 32
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %50 = getelementptr double, ptr %9, i64 4
  %.promoted.1.i = load <4 x double>, ptr %50, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %51 = phi i64 [ 0, %.preheader.1.i ], [ %90, %.critedge.1.i ]
  %52 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %89, %.critedge.1.i ]
  %53 = shl nuw nsw i64 %51, 3
  %gep20.i = getelementptr double, ptr %invariant.gep21.i, i64 %51
  %54 = load double, ptr %gep20.i, align 8
  %55 = insertelement <1 x double> poison, double %54, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %53
  %56 = load <4 x double>, ptr %gep.1.i, align 8
  %57 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> zeroinitializer
  %58 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 1>
  %59 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 2>
  %60 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 3>
  %61 = fmul <1 x double> %55, %57
  %62 = fmul <1 x double> %55, %58
  %63 = fmul <1 x double> %55, %59
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = fmul <1 x double> %55, %60
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = shufflevector <1 x double> %61, <1 x double> %62, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %68 = shufflevector <4 x double> %67, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %69 = shufflevector <4 x double> %68, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %70 = fadd <4 x double> %52, %69
  store <4 x double> %70, ptr %50, align 8
  %71 = or disjoint i64 %51, 1
  %72 = shl nuw nsw i64 %71, 3
  %gep20.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %71
  %73 = load double, ptr %gep20.i.1, align 8
  %74 = insertelement <1 x double> poison, double %73, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %72
  %75 = load <4 x double>, ptr %gep.1.i.1, align 8
  %76 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> zeroinitializer
  %77 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 1>
  %78 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 2>
  %79 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 3>
  %80 = fmul <1 x double> %74, %76
  %81 = fmul <1 x double> %74, %77
  %82 = fmul <1 x double> %74, %78
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = fmul <1 x double> %74, %79
  %85 = shufflevector <1 x double> %84, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = shufflevector <1 x double> %80, <1 x double> %81, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %87 = shufflevector <4 x double> %86, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %89 = fadd <4 x double> %70, %88
  store <4 x double> %89, ptr %50, align 8
  %90 = add nuw nsw i64 %51, 2
  %exitcond.1.not.i.1 = icmp eq i64 %90, 32
  br i1 %exitcond.1.not.i.1, label %91, label %.critedge.1.i

91:                                               ; preds = %.critedge.1.i
  %92 = add nuw nsw i64 %5, 1
  %exitcond19.not.i = icmp eq i64 %92, 8
  br i1 %exitcond19.not.i, label %93, label %.preheader15.i

93:                                               ; preds = %91
  %94 = add nuw nsw i64 %4, 8
  %95 = icmp ult i64 %4, 56
  br i1 %95, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %93
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %10, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %100, %1
  %11 = phi i64 [ %101, %100 ], [ 0, %1 ]
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %98, %.preheader16.i
  %12 = phi i64 [ 0, %.preheader16.i ], [ %99, %98 ]
  %13 = add nuw nsw i64 %12, %11
  %14 = shl i64 %13, 5
  %15 = shl i64 %13, 3
  %16 = getelementptr double, ptr %10, i64 %15
  %.promoted.i = load <4 x double>, ptr %16, align 8
  %invariant.gep21.i = getelementptr double, ptr %4, i64 %14
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %17 = phi i64 [ 0, %.preheader15.i ], [ %56, %.critedge.i ]
  %18 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %55, %.critedge.i ]
  %19 = shl nuw nsw i64 %17, 3
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %17
  %20 = load double, ptr %gep22.i, align 8
  %21 = insertelement <1 x double> poison, double %20, i64 0
  %gep.i = getelementptr double, ptr %7, i64 %19
  %22 = load <4 x double>, ptr %gep.i, align 8
  %23 = shufflevector <4 x double> %22, <4 x double> poison, <1 x i32> zeroinitializer
  %24 = shufflevector <4 x double> %22, <4 x double> poison, <1 x i32> <i32 1>
  %25 = shufflevector <4 x double> %22, <4 x double> poison, <1 x i32> <i32 2>
  %26 = shufflevector <4 x double> %22, <4 x double> poison, <1 x i32> <i32 3>
  %27 = fmul <1 x double> %21, %23
  %28 = fmul <1 x double> %21, %24
  %29 = fmul <1 x double> %21, %25
  %30 = shufflevector <1 x double> %29, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = fmul <1 x double> %21, %26
  %32 = shufflevector <1 x double> %31, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %33 = shufflevector <1 x double> %27, <1 x double> %28, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %35 = shufflevector <4 x double> %34, <4 x double> %32, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %36 = fadd <4 x double> %18, %35
  store <4 x double> %36, ptr %16, align 8
  %37 = or disjoint i64 %17, 1
  %38 = shl nuw nsw i64 %37, 3
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %37
  %39 = load double, ptr %gep22.i.1, align 8
  %40 = insertelement <1 x double> poison, double %39, i64 0
  %gep.i.1 = getelementptr double, ptr %7, i64 %38
  %41 = load <4 x double>, ptr %gep.i.1, align 8
  %42 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> zeroinitializer
  %43 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 1>
  %44 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 2>
  %45 = shufflevector <4 x double> %41, <4 x double> poison, <1 x i32> <i32 3>
  %46 = fmul <1 x double> %40, %42
  %47 = fmul <1 x double> %40, %43
  %48 = fmul <1 x double> %40, %44
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = fmul <1 x double> %40, %45
  %51 = shufflevector <1 x double> %50, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %52 = shufflevector <1 x double> %46, <1 x double> %47, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %54 = shufflevector <4 x double> %53, <4 x double> %51, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %55 = fadd <4 x double> %36, %54
  store <4 x double> %55, ptr %16, align 8
  %56 = add nuw nsw i64 %17, 2
  %exitcond.not.i.1 = icmp eq i64 %56, 32
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %57 = getelementptr double, ptr %16, i64 4
  %.promoted.1.i = load <4 x double>, ptr %57, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %58 = phi i64 [ 0, %.preheader.1.i ], [ %97, %.critedge.1.i ]
  %59 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %96, %.critedge.1.i ]
  %60 = shl nuw nsw i64 %58, 3
  %gep20.i = getelementptr double, ptr %invariant.gep21.i, i64 %58
  %61 = load double, ptr %gep20.i, align 8
  %62 = insertelement <1 x double> poison, double %61, i64 0
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %60
  %63 = load <4 x double>, ptr %gep.1.i, align 8
  %64 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> zeroinitializer
  %65 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 1>
  %66 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 2>
  %67 = shufflevector <4 x double> %63, <4 x double> poison, <1 x i32> <i32 3>
  %68 = fmul <1 x double> %62, %64
  %69 = fmul <1 x double> %62, %65
  %70 = fmul <1 x double> %62, %66
  %71 = shufflevector <1 x double> %70, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %72 = fmul <1 x double> %62, %67
  %73 = shufflevector <1 x double> %72, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = shufflevector <1 x double> %68, <1 x double> %69, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %75 = shufflevector <4 x double> %74, <4 x double> %71, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %76 = shufflevector <4 x double> %75, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %77 = fadd <4 x double> %59, %76
  store <4 x double> %77, ptr %57, align 8
  %78 = or disjoint i64 %58, 1
  %79 = shl nuw nsw i64 %78, 3
  %gep20.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %78
  %80 = load double, ptr %gep20.i.1, align 8
  %81 = insertelement <1 x double> poison, double %80, i64 0
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %79
  %82 = load <4 x double>, ptr %gep.1.i.1, align 8
  %83 = shufflevector <4 x double> %82, <4 x double> poison, <1 x i32> zeroinitializer
  %84 = shufflevector <4 x double> %82, <4 x double> poison, <1 x i32> <i32 1>
  %85 = shufflevector <4 x double> %82, <4 x double> poison, <1 x i32> <i32 2>
  %86 = shufflevector <4 x double> %82, <4 x double> poison, <1 x i32> <i32 3>
  %87 = fmul <1 x double> %81, %83
  %88 = fmul <1 x double> %81, %84
  %89 = fmul <1 x double> %81, %85
  %90 = shufflevector <1 x double> %89, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %91 = fmul <1 x double> %81, %86
  %92 = shufflevector <1 x double> %91, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = shufflevector <1 x double> %87, <1 x double> %88, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %90, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %95 = shufflevector <4 x double> %94, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %96 = fadd <4 x double> %77, %95
  store <4 x double> %96, ptr %57, align 8
  %97 = add nuw nsw i64 %58, 2
  %exitcond.1.not.i.1 = icmp eq i64 %97, 32
  br i1 %exitcond.1.not.i.1, label %98, label %.critedge.1.i

98:                                               ; preds = %.critedge.1.i
  %99 = add nuw nsw i64 %12, 1
  %exitcond19.not.i = icmp eq i64 %99, 8
  br i1 %exitcond19.not.i, label %100, label %.preheader15.i

100:                                              ; preds = %98
  %101 = add nuw nsw i64 %11, 8
  %102 = icmp ult i64 %11, 56
  br i1 %102, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %100
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32.i, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %99, %1
  %10 = phi i64 [ %100, %99 ], [ 0, %1 ]
  br label %.preheader15.i.i

.preheader15.i.i:                                 ; preds = %97, %.preheader16.i.i
  %11 = phi i64 [ 0, %.preheader16.i.i ], [ %98, %97 ]
  %12 = add nuw nsw i64 %11, %10
  %13 = shl i64 %12, 5
  %14 = shl i64 %12, 3
  %15 = getelementptr double, ptr %.unpack32.i, i64 %14
  %.promoted.i.i = load <4 x double>, ptr %15, align 8
  %invariant.gep21.i.i = getelementptr double, ptr %.unpack2.i, i64 %13
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader15.i.i
  %16 = phi i64 [ 0, %.preheader15.i.i ], [ %55, %.critedge.i.i ]
  %17 = phi <4 x double> [ %.promoted.i.i, %.preheader15.i.i ], [ %54, %.critedge.i.i ]
  %18 = shl nuw nsw i64 %16, 3
  %gep22.i.i = getelementptr double, ptr %invariant.gep21.i.i, i64 %16
  %19 = load double, ptr %gep22.i.i, align 8
  %20 = insertelement <1 x double> poison, double %19, i64 0
  %gep.i.i = getelementptr double, ptr %.unpack17.i, i64 %18
  %21 = load <4 x double>, ptr %gep.i.i, align 8
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> zeroinitializer
  %23 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 1>
  %24 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 2>
  %25 = shufflevector <4 x double> %21, <4 x double> poison, <1 x i32> <i32 3>
  %26 = fmul <1 x double> %20, %22
  %27 = fmul <1 x double> %20, %23
  %28 = fmul <1 x double> %20, %24
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = fmul <1 x double> %20, %25
  %31 = shufflevector <1 x double> %30, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = shufflevector <1 x double> %26, <1 x double> %27, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %35 = fadd <4 x double> %17, %34
  store <4 x double> %35, ptr %15, align 8
  %36 = or disjoint i64 %16, 1
  %37 = shl nuw nsw i64 %36, 3
  %gep22.i.i.1 = getelementptr double, ptr %invariant.gep21.i.i, i64 %36
  %38 = load double, ptr %gep22.i.i.1, align 8
  %39 = insertelement <1 x double> poison, double %38, i64 0
  %gep.i.i.1 = getelementptr double, ptr %.unpack17.i, i64 %37
  %40 = load <4 x double>, ptr %gep.i.i.1, align 8
  %41 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> zeroinitializer
  %42 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 1>
  %43 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 2>
  %44 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 3>
  %45 = fmul <1 x double> %39, %41
  %46 = fmul <1 x double> %39, %42
  %47 = fmul <1 x double> %39, %43
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = fmul <1 x double> %39, %44
  %50 = shufflevector <1 x double> %49, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %51 = shufflevector <1 x double> %45, <1 x double> %46, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %50, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %54 = fadd <4 x double> %35, %53
  store <4 x double> %54, ptr %15, align 8
  %55 = add nuw nsw i64 %16, 2
  %exitcond.not.i.i.1 = icmp eq i64 %55, 32
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %56 = getelementptr double, ptr %15, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %56, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %57 = phi i64 [ 0, %.preheader.1.i.i ], [ %96, %.critedge.1.i.i ]
  %58 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %95, %.critedge.1.i.i ]
  %59 = shl nuw nsw i64 %57, 3
  %gep20.i.i = getelementptr double, ptr %invariant.gep21.i.i, i64 %57
  %60 = load double, ptr %gep20.i.i, align 8
  %61 = insertelement <1 x double> poison, double %60, i64 0
  %gep.1.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %59
  %62 = load <4 x double>, ptr %gep.1.i.i, align 8
  %63 = shufflevector <4 x double> %62, <4 x double> poison, <1 x i32> zeroinitializer
  %64 = shufflevector <4 x double> %62, <4 x double> poison, <1 x i32> <i32 1>
  %65 = shufflevector <4 x double> %62, <4 x double> poison, <1 x i32> <i32 2>
  %66 = shufflevector <4 x double> %62, <4 x double> poison, <1 x i32> <i32 3>
  %67 = fmul <1 x double> %61, %63
  %68 = fmul <1 x double> %61, %64
  %69 = fmul <1 x double> %61, %65
  %70 = shufflevector <1 x double> %69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %71 = fmul <1 x double> %61, %66
  %72 = shufflevector <1 x double> %71, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = shufflevector <1 x double> %67, <1 x double> %68, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %74 = shufflevector <4 x double> %73, <4 x double> %70, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %75 = shufflevector <4 x double> %74, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %76 = fadd <4 x double> %58, %75
  store <4 x double> %76, ptr %56, align 8
  %77 = or disjoint i64 %57, 1
  %78 = shl nuw nsw i64 %77, 3
  %gep20.i.i.1 = getelementptr double, ptr %invariant.gep21.i.i, i64 %77
  %79 = load double, ptr %gep20.i.i.1, align 8
  %80 = insertelement <1 x double> poison, double %79, i64 0
  %gep.1.i.i.1 = getelementptr double, ptr %invariant.gep.1.i.i, i64 %78
  %81 = load <4 x double>, ptr %gep.1.i.i.1, align 8
  %82 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %80, %82
  %87 = fmul <1 x double> %80, %83
  %88 = fmul <1 x double> %80, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %80, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %56, align 8
  %96 = add nuw nsw i64 %57, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %96, 32
  br i1 %exitcond.1.not.i.i.1, label %97, label %.critedge.1.i.i

97:                                               ; preds = %.critedge.1.i.i
  %98 = add nuw nsw i64 %11, 1
  %exitcond19.not.i.i = icmp eq i64 %98, 8
  br i1 %exitcond19.not.i.i, label %99, label %.preheader15.i.i

99:                                               ; preds = %97
  %100 = add nuw nsw i64 %10, 8
  %101 = icmp ult i64 %10, 56
  br i1 %101, label %.preheader16.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %99
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
