module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(32 : index) : i64
    %29 = llvm.mlir.constant(64 : index) : i64
    %30 = llvm.mlir.constant(1 : index) : i64
    %31 = llvm.mlir.constant(4 : index) : i64
    %32 = llvm.mlir.constant(0 : index) : i64
    %33 = llvm.mlir.constant(8 : index) : i64
    %34 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%32 : i64)
  ^bb1(%35: i64):  // 2 preds: ^bb0, ^bb5
    %36 = llvm.icmp "slt" %35, %29 : i64
    llvm.cond_br %36, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%32 : i64)
  ^bb3(%37: i64):  // 2 preds: ^bb2, ^bb4
    %38 = llvm.icmp "slt" %37, %33 : i64
    llvm.cond_br %38, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %39 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %40 = llvm.mlir.constant(8 : index) : i64
    %41 = llvm.mul %35, %40  : i64
    %42 = llvm.add %41, %37  : i64
    %43 = llvm.getelementptr %39[%42] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %34, %43 : f64, !llvm.ptr
    %44 = llvm.add %37, %30  : i64
    llvm.br ^bb3(%44 : i64)
  ^bb5:  // pred: ^bb3
    %45 = llvm.add %35, %30  : i64
    llvm.br ^bb1(%45 : i64)
  ^bb6:  // pred: ^bb1
    %46 = llvm.mlir.constant(1 : index) : i64
    %47 = llvm.alloca %46 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %48 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %49 = llvm.insertvalue %47, %48[0] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.insertvalue %47, %49[1] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.mlir.constant(0 : index) : i64
    %52 = llvm.insertvalue %51, %50[2] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.mlir.constant(1 : index) : i64
    %54 = llvm.alloca %53 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %55 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %56 = llvm.insertvalue %54, %55[0] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.insertvalue %54, %56[1] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.mlir.constant(0 : index) : i64
    %59 = llvm.insertvalue %58, %57[2] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.mlir.constant(1 : index) : i64
    %61 = llvm.alloca %60 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %62 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %63 = llvm.insertvalue %61, %62[0] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.insertvalue %61, %63[1] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.mlir.constant(0 : index) : i64
    %66 = llvm.insertvalue %65, %64[2] : !llvm.struct<(ptr, ptr, i64)> 
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.alloca %67 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %68, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%32 : i64)
  ^bb7(%74: i64):  // 2 preds: ^bb6, ^bb29
    %75 = llvm.icmp "slt" %74, %29 : i64
    llvm.cond_br %75, ^bb8, ^bb30
  ^bb8:  // pred: ^bb7
    %76 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %79 = llvm.insertvalue %76, %78[0] : !llvm.struct<(ptr, ptr, i64)> 
    %80 = llvm.insertvalue %77, %79[1] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.mlir.constant(0 : index) : i64
    %82 = llvm.insertvalue %81, %80[2] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.mul %74, %28  : i64
    %89 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %92 = llvm.insertvalue %89, %91[0] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.insertvalue %90, %92[1] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.mlir.constant(0 : index) : i64
    %95 = llvm.insertvalue %94, %93[2] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %101 = llvm.mul %74, %33  : i64
    llvm.br ^bb9(%32 : i64)
  ^bb9(%102: i64):  // 2 preds: ^bb8, ^bb28
    %103 = llvm.icmp "slt" %102, %33 : i64
    llvm.cond_br %103, ^bb10, ^bb29
  ^bb10:  // pred: ^bb9
    llvm.br ^bb11(%32 : i64)
  ^bb11(%104: i64):  // 2 preds: ^bb10, ^bb27
    %105 = llvm.icmp "slt" %104, %33 : i64
    llvm.cond_br %105, ^bb12, ^bb28
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%32 : i64)
  ^bb13(%106: i64):  // 2 preds: ^bb12, ^bb26
    %107 = llvm.icmp "slt" %106, %28 : i64
    llvm.cond_br %107, ^bb14, ^bb27
  ^bb14:  // pred: ^bb13
    %108 = llvm.mul %102, %28  : i64
    %109 = llvm.add %88, %108  : i64
    %110 = llvm.add %109, %106  : i64
    %111 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %112 = llvm.insertvalue %76, %111[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.insertvalue %77, %112[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.insertvalue %110, %113[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.mlir.constant(1 : index) : i64
    %116 = llvm.insertvalue %115, %114[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.mlir.constant(32 : index) : i64
    %118 = llvm.insertvalue %117, %116[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %119 = llvm.mlir.constant(1 : index) : i64
    %120 = llvm.insertvalue %119, %118[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %121 = llvm.mlir.constant(1 : index) : i64
    %122 = llvm.insertvalue %121, %120[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %125 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %126 = llvm.insertvalue %123, %125[0] : !llvm.struct<(ptr, ptr, i64)> 
    %127 = llvm.insertvalue %124, %126[1] : !llvm.struct<(ptr, ptr, i64)> 
    %128 = llvm.mlir.constant(0 : index) : i64
    %129 = llvm.insertvalue %128, %127[2] : !llvm.struct<(ptr, ptr, i64)> 
    %130 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %134 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %135 = llvm.mul %106, %33  : i64
    %136 = llvm.add %135, %104  : i64
    %137 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %138 = llvm.insertvalue %123, %137[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.insertvalue %124, %138[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %140 = llvm.insertvalue %136, %139[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %141 = llvm.mlir.constant(1 : index) : i64
    %142 = llvm.insertvalue %141, %140[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %143 = llvm.mlir.constant(8 : index) : i64
    %144 = llvm.insertvalue %143, %142[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.mlir.constant(4 : index) : i64
    %146 = llvm.insertvalue %145, %144[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.mlir.constant(1 : index) : i64
    %148 = llvm.insertvalue %147, %146[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %149 = llvm.mul %102, %33  : i64
    %150 = llvm.add %101, %149  : i64
    %151 = llvm.add %150, %104  : i64
    %152 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %153 = llvm.insertvalue %89, %152[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.insertvalue %90, %153[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %155 = llvm.insertvalue %151, %154[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %156 = llvm.mlir.constant(1 : index) : i64
    %157 = llvm.insertvalue %156, %155[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %158 = llvm.mlir.constant(8 : index) : i64
    %159 = llvm.insertvalue %158, %157[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %160 = llvm.mlir.constant(4 : index) : i64
    %161 = llvm.insertvalue %160, %159[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %162 = llvm.mlir.constant(1 : index) : i64
    %163 = llvm.insertvalue %162, %161[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %164 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %165 = llvm.extractvalue %52[0] : !llvm.struct<(ptr, ptr, i64)> 
    %166 = llvm.insertvalue %165, %164[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.extractvalue %52[1] : !llvm.struct<(ptr, ptr, i64)> 
    %168 = llvm.insertvalue %167, %166[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.mlir.constant(0 : index) : i64
    %170 = llvm.insertvalue %169, %168[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.mlir.constant(1 : index) : i64
    %172 = llvm.insertvalue %171, %170[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %173 = llvm.mlir.constant(1 : index) : i64
    %174 = llvm.insertvalue %173, %172[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb15(%32 : i64)
  ^bb15(%175: i64):  // 2 preds: ^bb14, ^bb16
    %176 = llvm.icmp "slt" %175, %30 : i64
    llvm.cond_br %176, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %177 = llvm.getelementptr %77[%110] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %178 = llvm.mlir.constant(32 : index) : i64
    %179 = llvm.mul %175, %178  : i64
    %180 = llvm.add %179, %32  : i64
    %181 = llvm.getelementptr %177[%180] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %182 = llvm.load %181 : !llvm.ptr -> f64
    %183 = llvm.mlir.undef : vector<1xf64>
    %184 = llvm.mlir.constant(0 : i32) : i32
    %185 = llvm.insertelement %182, %183[%184 : i32] : vector<1xf64>
    %186 = llvm.shufflevector %185, %183 [0] : vector<1xf64> 
    %187 = llvm.getelementptr %167[%175] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %186, %187 : vector<1xf64>, !llvm.ptr
    %188 = llvm.add %175, %30  : i64
    llvm.br ^bb15(%188 : i64)
  ^bb17:  // pred: ^bb15
    %189 = llvm.load %47 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %190 = llvm.extractvalue %189[0] : !llvm.array<1 x vector<1xf64>> 
    %191 = llvm.insertvalue %190, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %192 = llvm.insertvalue %190, %191[1] : !llvm.array<4 x vector<1xf64>> 
    %193 = llvm.insertvalue %190, %192[2] : !llvm.array<4 x vector<1xf64>> 
    %194 = llvm.insertvalue %190, %193[3] : !llvm.array<4 x vector<1xf64>> 
    %195 = llvm.insertvalue %194, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %196 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %197 = llvm.extractvalue %59[0] : !llvm.struct<(ptr, ptr, i64)> 
    %198 = llvm.insertvalue %197, %196[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %199 = llvm.extractvalue %59[1] : !llvm.struct<(ptr, ptr, i64)> 
    %200 = llvm.insertvalue %199, %198[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %201 = llvm.mlir.constant(0 : index) : i64
    %202 = llvm.insertvalue %201, %200[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.mlir.constant(1 : index) : i64
    %204 = llvm.insertvalue %203, %202[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.mlir.constant(1 : index) : i64
    %206 = llvm.insertvalue %205, %204[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb18(%32 : i64)
  ^bb18(%207: i64):  // 2 preds: ^bb17, ^bb19
    %208 = llvm.icmp "slt" %207, %30 : i64
    llvm.cond_br %208, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %209 = llvm.extractvalue %148[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %210 = llvm.extractvalue %148[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %211 = llvm.getelementptr %209[%210] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %212 = llvm.mlir.constant(8 : index) : i64
    %213 = llvm.mul %207, %212  : i64
    %214 = llvm.add %213, %32  : i64
    %215 = llvm.getelementptr %211[%214] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %216 = llvm.load %215 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %217 = llvm.getelementptr %199[%207] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %216, %217 : vector<4xf64>, !llvm.ptr
    %218 = llvm.add %207, %30  : i64
    llvm.br ^bb18(%218 : i64)
  ^bb20:  // pred: ^bb18
    %219 = llvm.load %54 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %220 = llvm.extractvalue %219[0] : !llvm.array<1 x vector<4xf64>> 
    %221 = llvm.mlir.constant(0 : i64) : i64
    %222 = llvm.extractelement %220[%221 : i64] : vector<4xf64>
    %223 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %224 = llvm.mlir.constant(0 : i64) : i64
    %225 = llvm.insertelement %222, %223[%224 : i64] : vector<1xf64>
    %226 = llvm.insertvalue %225, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %227 = llvm.extractvalue %219[0] : !llvm.array<1 x vector<4xf64>> 
    %228 = llvm.mlir.constant(1 : i64) : i64
    %229 = llvm.extractelement %227[%228 : i64] : vector<4xf64>
    %230 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %231 = llvm.mlir.constant(0 : i64) : i64
    %232 = llvm.insertelement %229, %230[%231 : i64] : vector<1xf64>
    %233 = llvm.insertvalue %232, %226[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %234 = llvm.extractvalue %219[0] : !llvm.array<1 x vector<4xf64>> 
    %235 = llvm.mlir.constant(2 : i64) : i64
    %236 = llvm.extractelement %234[%235 : i64] : vector<4xf64>
    %237 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %238 = llvm.mlir.constant(0 : i64) : i64
    %239 = llvm.insertelement %236, %237[%238 : i64] : vector<1xf64>
    %240 = llvm.insertvalue %239, %233[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %241 = llvm.extractvalue %219[0] : !llvm.array<1 x vector<4xf64>> 
    %242 = llvm.mlir.constant(3 : i64) : i64
    %243 = llvm.extractelement %241[%242 : i64] : vector<4xf64>
    %244 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %245 = llvm.mlir.constant(0 : i64) : i64
    %246 = llvm.insertelement %243, %244[%245 : i64] : vector<1xf64>
    %247 = llvm.insertvalue %246, %240[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %248 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %249 = llvm.extractvalue %66[0] : !llvm.struct<(ptr, ptr, i64)> 
    %250 = llvm.insertvalue %249, %248[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %251 = llvm.extractvalue %66[1] : !llvm.struct<(ptr, ptr, i64)> 
    %252 = llvm.insertvalue %251, %250[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %253 = llvm.mlir.constant(0 : index) : i64
    %254 = llvm.insertvalue %253, %252[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %255 = llvm.mlir.constant(1 : index) : i64
    %256 = llvm.insertvalue %255, %254[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %257 = llvm.mlir.constant(1 : index) : i64
    %258 = llvm.insertvalue %257, %256[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb21(%32 : i64)
  ^bb21(%259: i64):  // 2 preds: ^bb20, ^bb22
    %260 = llvm.icmp "slt" %259, %30 : i64
    llvm.cond_br %260, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    %261 = llvm.extractvalue %163[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %262 = llvm.extractvalue %163[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %263 = llvm.getelementptr %261[%262] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %264 = llvm.mlir.constant(8 : index) : i64
    %265 = llvm.mul %259, %264  : i64
    %266 = llvm.add %265, %32  : i64
    %267 = llvm.getelementptr %263[%266] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %268 = llvm.load %267 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %269 = llvm.getelementptr %251[%259] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %268, %269 : vector<4xf64>, !llvm.ptr
    %270 = llvm.add %259, %30  : i64
    llvm.br ^bb21(%270 : i64)
  ^bb23:  // pred: ^bb21
    %271 = llvm.load %61 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %272 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %273 = llvm.extractvalue %195[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %274 = llvm.fmul %273, %225  : vector<1xf64>
    %275 = llvm.insertvalue %274, %272[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %276 = llvm.extractvalue %195[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %277 = llvm.fmul %276, %232  : vector<1xf64>
    %278 = llvm.insertvalue %277, %275[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %279 = llvm.extractvalue %195[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %280 = llvm.fmul %279, %239  : vector<1xf64>
    %281 = llvm.insertvalue %280, %278[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %282 = llvm.extractvalue %195[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %283 = llvm.fmul %282, %246  : vector<1xf64>
    %284 = llvm.insertvalue %283, %281[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %285 = llvm.extractvalue %284[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %286 = llvm.mlir.constant(0 : i64) : i64
    %287 = llvm.extractelement %285[%286 : i64] : vector<1xf64>
    %288 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %289 = llvm.mlir.constant(0 : i64) : i64
    %290 = llvm.insertelement %287, %288[%289 : i64] : vector<4xf64>
    %291 = llvm.insertvalue %290, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %292 = llvm.extractvalue %284[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %293 = llvm.mlir.constant(0 : i64) : i64
    %294 = llvm.extractelement %292[%293 : i64] : vector<1xf64>
    %295 = llvm.mlir.constant(1 : i64) : i64
    %296 = llvm.insertelement %294, %290[%295 : i64] : vector<4xf64>
    %297 = llvm.insertvalue %296, %291[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %298 = llvm.extractvalue %284[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %299 = llvm.mlir.constant(0 : i64) : i64
    %300 = llvm.extractelement %298[%299 : i64] : vector<1xf64>
    %301 = llvm.mlir.constant(2 : i64) : i64
    %302 = llvm.insertelement %300, %296[%301 : i64] : vector<4xf64>
    %303 = llvm.insertvalue %302, %297[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %304 = llvm.extractvalue %284[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %305 = llvm.mlir.constant(0 : i64) : i64
    %306 = llvm.extractelement %304[%305 : i64] : vector<1xf64>
    %307 = llvm.mlir.constant(3 : i64) : i64
    %308 = llvm.insertelement %306, %302[%307 : i64] : vector<4xf64>
    %309 = llvm.insertvalue %308, %303[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %310 = llvm.extractvalue %271[0] : !llvm.array<1 x vector<4xf64>> 
    %311 = llvm.fadd %308, %310  : vector<4xf64>
    %312 = llvm.insertvalue %311, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %312, %68 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %313 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %314 = llvm.extractvalue %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %315 = llvm.insertvalue %314, %313[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %316 = llvm.extractvalue %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %317 = llvm.insertvalue %316, %315[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %318 = llvm.mlir.constant(0 : index) : i64
    %319 = llvm.insertvalue %318, %317[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.mlir.constant(1 : index) : i64
    %321 = llvm.insertvalue %320, %319[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.mlir.constant(1 : index) : i64
    %323 = llvm.insertvalue %322, %321[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb24(%32 : i64)
  ^bb24(%324: i64):  // 2 preds: ^bb23, ^bb25
    %325 = llvm.icmp "slt" %324, %30 : i64
    llvm.cond_br %325, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %326 = llvm.getelementptr %316[%324] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %327 = llvm.load %326 : !llvm.ptr -> vector<4xf64>
    %328 = llvm.extractvalue %163[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %329 = llvm.extractvalue %163[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %330 = llvm.getelementptr %328[%329] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %331 = llvm.mlir.constant(8 : index) : i64
    %332 = llvm.mul %324, %331  : i64
    %333 = llvm.add %332, %32  : i64
    %334 = llvm.getelementptr %330[%333] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %327, %334 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %335 = llvm.add %324, %30  : i64
    llvm.br ^bb24(%335 : i64)
  ^bb26:  // pred: ^bb24
    %336 = llvm.add %106, %30  : i64
    llvm.br ^bb13(%336 : i64)
  ^bb27:  // pred: ^bb13
    %337 = llvm.add %104, %31  : i64
    llvm.br ^bb11(%337 : i64)
  ^bb28:  // pred: ^bb11
    %338 = llvm.add %102, %30  : i64
    llvm.br ^bb9(%338 : i64)
  ^bb29:  // pred: ^bb9
    %339 = llvm.add %74, %33  : i64
    llvm.br ^bb7(%339 : i64)
  ^bb30:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
