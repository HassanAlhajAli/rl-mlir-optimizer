#map = affine_map<(d0) -> (0, d0)>
module {
  func.func @kernel(%arg0: memref<512x128xf64>, %arg1: memref<128xf64>, %arg2: memref<512xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<512xf64>)
    %c0_0 = arith.constant 0 : index
    %c512 = arith.constant 512 : index
    %c16_1 = arith.constant 16 : index
    scf.for %arg3 = %c0_0 to %c512 step %c16_1 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 128] [1, 1] : memref<512x128xf64> to memref<16x128xf64, strided<[128, 1], offset: ?>>
      %subview_2 = memref.subview %arg2[%arg3] [16] [1] : memref<512xf64> to memref<16xf64, strided<[1], offset: ?>>
      %c0_3 = arith.constant 0 : index
      %c16_4 = arith.constant 16 : index
      %c4_5 = arith.constant 4 : index
      %c0_6 = arith.constant 0 : index
      %c128 = arith.constant 128 : index
      %c1_7 = arith.constant 1 : index
      scf.for %arg4 = %c0_3 to %c16_4 step %c4_5 {
        scf.for %arg5 = %c0_6 to %c128 step %c1_7 {
          %subview_8 = memref.subview %subview[%arg4, %arg5] [4, 1] [1, 1] : memref<16x128xf64, strided<[128, 1], offset: ?>> to memref<4x1xf64, strided<[128, 1], offset: ?>>
          %subview_9 = memref.subview %arg1[%arg5] [1] [1] : memref<128xf64> to memref<1xf64, strided<[1], offset: ?>>
          %subview_10 = memref.subview %subview_2[%arg4] [4] [1] : memref<16xf64, strided<[1], offset: ?>> to memref<4xf64, strided<[1], offset: ?>>
          %c4_11 = arith.constant 4 : index
          %c1_12 = arith.constant 1 : index
          %c0_13 = arith.constant 0 : index
          %cst_14 = arith.constant 0.000000e+00 : f64
          %0 = vector.transfer_read %subview_8[%c0_13, %c0_13], %cst_14 : memref<4x1xf64, strided<[128, 1], offset: ?>>, vector<4x1xf64>
          %cst_15 = arith.constant 0.000000e+00 : f64
          %1 = vector.transfer_read %subview_9[%c0_13], %cst_15 {permutation_map = #map} : memref<1xf64, strided<[1], offset: ?>>, vector<4x1xf64>
          %cst_16 = arith.constant 0.000000e+00 : f64
          %2 = vector.transfer_read %subview_10[%c0_13], %cst_16 : memref<4xf64, strided<[1], offset: ?>>, vector<4xf64>
          %3 = arith.mulf %0, %1 : vector<4x1xf64>
          %4 = vector.multi_reduction <add>, %3, %2 [1] : vector<4x1xf64> to vector<4xf64>
          %c0_17 = arith.constant 0 : index
          vector.transfer_write %4, %subview_10[%c0_17] : vector<4xf64>, memref<4xf64, strided<[1], offset: ?>>
        }
      }
    }
    return
  }
}
