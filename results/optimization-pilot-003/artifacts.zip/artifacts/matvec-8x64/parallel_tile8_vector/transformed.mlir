#map = affine_map<(d0) -> (0, d0)>
module {
  func.func @kernel(%arg0: memref<8x64xf64>, %arg1: memref<64xf64>, %arg2: memref<8xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c8 = arith.constant 8 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<8xf64>)
    %c0_0 = arith.constant 0 : index
    %c8_1 = arith.constant 8 : index
    %c8_2 = arith.constant 8 : index
    scf.for %arg3 = %c0_0 to %c8_1 step %c8_2 {
      %subview = memref.subview %arg0[%arg3, 0] [8, 64] [1, 1] : memref<8x64xf64> to memref<8x64xf64, strided<[64, 1], offset: ?>>
      %subview_3 = memref.subview %arg2[%arg3] [8] [1] : memref<8xf64> to memref<8xf64, strided<[1], offset: ?>>
      %c0_4 = arith.constant 0 : index
      %c8_5 = arith.constant 8 : index
      %c4_6 = arith.constant 4 : index
      %c0_7 = arith.constant 0 : index
      %c64 = arith.constant 64 : index
      %c1_8 = arith.constant 1 : index
      scf.for %arg4 = %c0_4 to %c8_5 step %c4_6 {
        scf.for %arg5 = %c0_7 to %c64 step %c1_8 {
          %subview_9 = memref.subview %subview[%arg4, %arg5] [4, 1] [1, 1] : memref<8x64xf64, strided<[64, 1], offset: ?>> to memref<4x1xf64, strided<[64, 1], offset: ?>>
          %subview_10 = memref.subview %arg1[%arg5] [1] [1] : memref<64xf64> to memref<1xf64, strided<[1], offset: ?>>
          %subview_11 = memref.subview %subview_3[%arg4] [4] [1] : memref<8xf64, strided<[1], offset: ?>> to memref<4xf64, strided<[1], offset: ?>>
          %c4_12 = arith.constant 4 : index
          %c1_13 = arith.constant 1 : index
          %c0_14 = arith.constant 0 : index
          %cst_15 = arith.constant 0.000000e+00 : f64
          %0 = vector.transfer_read %subview_9[%c0_14, %c0_14], %cst_15 : memref<4x1xf64, strided<[64, 1], offset: ?>>, vector<4x1xf64>
          %cst_16 = arith.constant 0.000000e+00 : f64
          %1 = vector.transfer_read %subview_10[%c0_14], %cst_16 {permutation_map = #map} : memref<1xf64, strided<[1], offset: ?>>, vector<4x1xf64>
          %cst_17 = arith.constant 0.000000e+00 : f64
          %2 = vector.transfer_read %subview_11[%c0_14], %cst_17 : memref<4xf64, strided<[1], offset: ?>>, vector<4xf64>
          %3 = arith.mulf %0, %1 : vector<4x1xf64>
          %4 = vector.multi_reduction <add>, %3, %2 [1] : vector<4x1xf64> to vector<4xf64>
          %c0_18 = arith.constant 0 : index
          vector.transfer_write %4, %subview_11[%c0_18] : vector<4xf64>, memref<4xf64, strided<[1], offset: ?>>
        }
      }
    }
    return
  }
}
