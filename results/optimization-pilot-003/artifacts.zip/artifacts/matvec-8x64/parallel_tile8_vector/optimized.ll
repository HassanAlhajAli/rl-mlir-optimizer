; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %13, i8 0, i64 64, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader
  %18 = phi i64 [ 0, %.preheader ], [ %57, %17 ]
  %19 = phi <4 x double> [ zeroinitializer, %.preheader ], [ %56, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 64
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 128
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 192
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %8, i64 %18
  %29 = load double, ptr %28, align 8
  %30 = insertelement <4 x double> poison, double %21, i64 0
  %31 = insertelement <4 x double> %30, double %23, i64 1
  %32 = insertelement <4 x double> %31, double %25, i64 2
  %33 = insertelement <4 x double> %32, double %27, i64 3
  %34 = insertelement <4 x double> poison, double %29, i64 0
  %35 = shufflevector <4 x double> %34, <4 x double> poison, <4 x i32> zeroinitializer
  %36 = fmul <4 x double> %33, %35
  %37 = fadd <4 x double> %19, %36
  store <4 x double> %37, ptr %13, align 8
  %38 = or disjoint i64 %18, 1
  %39 = getelementptr double, ptr %1, i64 %38
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %39, i64 64
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %39, i64 128
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %39, i64 192
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %8, i64 %38
  %48 = load double, ptr %47, align 8
  %49 = insertelement <4 x double> poison, double %40, i64 0
  %50 = insertelement <4 x double> %49, double %42, i64 1
  %51 = insertelement <4 x double> %50, double %44, i64 2
  %52 = insertelement <4 x double> %51, double %46, i64 3
  %53 = insertelement <4 x double> poison, double %48, i64 0
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = fmul <4 x double> %52, %54
  %56 = fadd <4 x double> %37, %55
  store <4 x double> %56, ptr %13, align 8
  %57 = add nuw nsw i64 %18, 2
  %exitcond.not.1 = icmp eq i64 %57, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %58 = getelementptr double, ptr %13, i64 4
  br label %59

59:                                               ; preds = %59, %.preheader.1
  %60 = phi i64 [ 0, %.preheader.1 ], [ %101, %59 ]
  %61 = phi <4 x double> [ zeroinitializer, %.preheader.1 ], [ %100, %59 ]
  %62 = getelementptr double, ptr %1, i64 %60
  %63 = getelementptr double, ptr %62, i64 256
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %62, i64 320
  %66 = load double, ptr %65, align 8
  %67 = getelementptr double, ptr %62, i64 384
  %68 = load double, ptr %67, align 8
  %69 = getelementptr double, ptr %62, i64 448
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %60
  %72 = load double, ptr %71, align 8
  %73 = insertelement <4 x double> poison, double %64, i64 0
  %74 = insertelement <4 x double> %73, double %66, i64 1
  %75 = insertelement <4 x double> %74, double %68, i64 2
  %76 = insertelement <4 x double> %75, double %70, i64 3
  %77 = insertelement <4 x double> poison, double %72, i64 0
  %78 = shufflevector <4 x double> %77, <4 x double> poison, <4 x i32> zeroinitializer
  %79 = fmul <4 x double> %76, %78
  %80 = fadd <4 x double> %61, %79
  store <4 x double> %80, ptr %58, align 8
  %81 = or disjoint i64 %60, 1
  %82 = getelementptr double, ptr %1, i64 %81
  %83 = getelementptr double, ptr %82, i64 256
  %84 = load double, ptr %83, align 8
  %85 = getelementptr double, ptr %82, i64 320
  %86 = load double, ptr %85, align 8
  %87 = getelementptr double, ptr %82, i64 384
  %88 = load double, ptr %87, align 8
  %89 = getelementptr double, ptr %82, i64 448
  %90 = load double, ptr %89, align 8
  %91 = getelementptr double, ptr %8, i64 %81
  %92 = load double, ptr %91, align 8
  %93 = insertelement <4 x double> poison, double %84, i64 0
  %94 = insertelement <4 x double> %93, double %86, i64 1
  %95 = insertelement <4 x double> %94, double %88, i64 2
  %96 = insertelement <4 x double> %95, double %90, i64 3
  %97 = insertelement <4 x double> poison, double %92, i64 0
  %98 = shufflevector <4 x double> %97, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = fmul <4 x double> %96, %98
  %100 = fadd <4 x double> %80, %99
  store <4 x double> %100, ptr %58, align 8
  %101 = add nuw nsw i64 %60, 2
  %exitcond.1.not.1 = icmp eq i64 %101, 64
  br i1 %exitcond.1.not.1, label %102, label %59

102:                                              ; preds = %59
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28, i8 0, i64 64, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %44, %4 ]
  %6 = phi <4 x double> [ zeroinitializer, %3 ], [ %43, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %7, i64 64
  %10 = load double, ptr %9, align 8
  %11 = getelementptr double, ptr %7, i64 128
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %7, i64 192
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %.unpack17, i64 %5
  %16 = load double, ptr %15, align 8
  %17 = insertelement <4 x double> poison, double %8, i64 0
  %18 = insertelement <4 x double> %17, double %10, i64 1
  %19 = insertelement <4 x double> %18, double %12, i64 2
  %20 = insertelement <4 x double> %19, double %14, i64 3
  %21 = insertelement <4 x double> poison, double %16, i64 0
  %22 = shufflevector <4 x double> %21, <4 x double> poison, <4 x i32> zeroinitializer
  %23 = fmul <4 x double> %20, %22
  %24 = fadd <4 x double> %6, %23
  store <4 x double> %24, ptr %.unpack28, align 8
  %25 = or disjoint i64 %5, 1
  %26 = getelementptr double, ptr %.unpack2, i64 %25
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %26, i64 64
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %26, i64 128
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %26, i64 192
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %.unpack17, i64 %25
  %35 = load double, ptr %34, align 8
  %36 = insertelement <4 x double> poison, double %27, i64 0
  %37 = insertelement <4 x double> %36, double %29, i64 1
  %38 = insertelement <4 x double> %37, double %31, i64 2
  %39 = insertelement <4 x double> %38, double %33, i64 3
  %40 = insertelement <4 x double> poison, double %35, i64 0
  %41 = shufflevector <4 x double> %40, <4 x double> poison, <4 x i32> zeroinitializer
  %42 = fmul <4 x double> %39, %41
  %43 = fadd <4 x double> %24, %42
  store <4 x double> %43, ptr %.unpack28, align 8
  %44 = add nuw nsw i64 %5, 2
  %exitcond.not.i.1 = icmp eq i64 %44, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %45 = getelementptr double, ptr %.unpack28, i64 4
  br label %46

46:                                               ; preds = %46, %.preheader.1.i
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %88, %46 ]
  %48 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %87, %46 ]
  %49 = getelementptr double, ptr %.unpack2, i64 %47
  %50 = getelementptr double, ptr %49, i64 256
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %49, i64 320
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %49, i64 384
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %49, i64 448
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %47
  %59 = load double, ptr %58, align 8
  %60 = insertelement <4 x double> poison, double %51, i64 0
  %61 = insertelement <4 x double> %60, double %53, i64 1
  %62 = insertelement <4 x double> %61, double %55, i64 2
  %63 = insertelement <4 x double> %62, double %57, i64 3
  %64 = insertelement <4 x double> poison, double %59, i64 0
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = fmul <4 x double> %63, %65
  %67 = fadd <4 x double> %48, %66
  store <4 x double> %67, ptr %45, align 8
  %68 = or disjoint i64 %47, 1
  %69 = getelementptr double, ptr %.unpack2, i64 %68
  %70 = getelementptr double, ptr %69, i64 256
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %69, i64 320
  %73 = load double, ptr %72, align 8
  %74 = getelementptr double, ptr %69, i64 384
  %75 = load double, ptr %74, align 8
  %76 = getelementptr double, ptr %69, i64 448
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %.unpack17, i64 %68
  %79 = load double, ptr %78, align 8
  %80 = insertelement <4 x double> poison, double %71, i64 0
  %81 = insertelement <4 x double> %80, double %73, i64 1
  %82 = insertelement <4 x double> %81, double %75, i64 2
  %83 = insertelement <4 x double> %82, double %77, i64 3
  %84 = insertelement <4 x double> poison, double %79, i64 0
  %85 = shufflevector <4 x double> %84, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = fmul <4 x double> %83, %85
  %87 = fadd <4 x double> %67, %86
  store <4 x double> %87, ptr %45, align 8
  %88 = add nuw nsw i64 %47, 2
  %exitcond.1.not.i.1 = icmp eq i64 %88, 64
  br i1 %exitcond.1.not.i.1, label %kernel.exit, label %46

kernel.exit:                                      ; preds = %46
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %10, i8 0, i64 64, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %51, %11 ]
  %13 = phi <4 x double> [ zeroinitializer, %1 ], [ %50, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %14, i64 64
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %14, i64 128
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %14, i64 192
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %7, i64 %12
  %23 = load double, ptr %22, align 8
  %24 = insertelement <4 x double> poison, double %15, i64 0
  %25 = insertelement <4 x double> %24, double %17, i64 1
  %26 = insertelement <4 x double> %25, double %19, i64 2
  %27 = insertelement <4 x double> %26, double %21, i64 3
  %28 = insertelement <4 x double> poison, double %23, i64 0
  %29 = shufflevector <4 x double> %28, <4 x double> poison, <4 x i32> zeroinitializer
  %30 = fmul <4 x double> %27, %29
  %31 = fadd <4 x double> %13, %30
  store <4 x double> %31, ptr %10, align 8
  %32 = or disjoint i64 %12, 1
  %33 = getelementptr double, ptr %4, i64 %32
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %33, i64 64
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %33, i64 128
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %33, i64 192
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %7, i64 %32
  %42 = load double, ptr %41, align 8
  %43 = insertelement <4 x double> poison, double %34, i64 0
  %44 = insertelement <4 x double> %43, double %36, i64 1
  %45 = insertelement <4 x double> %44, double %38, i64 2
  %46 = insertelement <4 x double> %45, double %40, i64 3
  %47 = insertelement <4 x double> poison, double %42, i64 0
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = fmul <4 x double> %46, %48
  %50 = fadd <4 x double> %31, %49
  store <4 x double> %50, ptr %10, align 8
  %51 = add nuw nsw i64 %12, 2
  %exitcond.not.i.1 = icmp eq i64 %51, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %52 = getelementptr double, ptr %10, i64 4
  br label %53

53:                                               ; preds = %53, %.preheader.1.i
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %95, %53 ]
  %55 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %94, %53 ]
  %56 = getelementptr double, ptr %4, i64 %54
  %57 = getelementptr double, ptr %56, i64 256
  %58 = load double, ptr %57, align 8
  %59 = getelementptr double, ptr %56, i64 320
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %56, i64 384
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %56, i64 448
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %54
  %66 = load double, ptr %65, align 8
  %67 = insertelement <4 x double> poison, double %58, i64 0
  %68 = insertelement <4 x double> %67, double %60, i64 1
  %69 = insertelement <4 x double> %68, double %62, i64 2
  %70 = insertelement <4 x double> %69, double %64, i64 3
  %71 = insertelement <4 x double> poison, double %66, i64 0
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = fmul <4 x double> %70, %72
  %74 = fadd <4 x double> %55, %73
  store <4 x double> %74, ptr %52, align 8
  %75 = or disjoint i64 %54, 1
  %76 = getelementptr double, ptr %4, i64 %75
  %77 = getelementptr double, ptr %76, i64 256
  %78 = load double, ptr %77, align 8
  %79 = getelementptr double, ptr %76, i64 320
  %80 = load double, ptr %79, align 8
  %81 = getelementptr double, ptr %76, i64 384
  %82 = load double, ptr %81, align 8
  %83 = getelementptr double, ptr %76, i64 448
  %84 = load double, ptr %83, align 8
  %85 = getelementptr double, ptr %7, i64 %75
  %86 = load double, ptr %85, align 8
  %87 = insertelement <4 x double> poison, double %78, i64 0
  %88 = insertelement <4 x double> %87, double %80, i64 1
  %89 = insertelement <4 x double> %88, double %82, i64 2
  %90 = insertelement <4 x double> %89, double %84, i64 3
  %91 = insertelement <4 x double> poison, double %86, i64 0
  %92 = shufflevector <4 x double> %91, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = fmul <4 x double> %90, %92
  %94 = fadd <4 x double> %74, %93
  store <4 x double> %94, ptr %52, align 8
  %95 = add nuw nsw i64 %54, 2
  %exitcond.1.not.i.1 = icmp eq i64 %95, 64
  br i1 %exitcond.1.not.i.1, label %kernel.exit, label %53

kernel.exit:                                      ; preds = %53
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28.i, i8 0, i64 64, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi i64 [ 0, %1 ], [ %50, %10 ]
  %12 = phi <4 x double> [ zeroinitializer, %1 ], [ %49, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 64
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 128
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 192
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %.unpack17.i, i64 %11
  %22 = load double, ptr %21, align 8
  %23 = insertelement <4 x double> poison, double %14, i64 0
  %24 = insertelement <4 x double> %23, double %16, i64 1
  %25 = insertelement <4 x double> %24, double %18, i64 2
  %26 = insertelement <4 x double> %25, double %20, i64 3
  %27 = insertelement <4 x double> poison, double %22, i64 0
  %28 = shufflevector <4 x double> %27, <4 x double> poison, <4 x i32> zeroinitializer
  %29 = fmul <4 x double> %26, %28
  %30 = fadd <4 x double> %12, %29
  store <4 x double> %30, ptr %.unpack28.i, align 8
  %31 = or disjoint i64 %11, 1
  %32 = getelementptr double, ptr %.unpack2.i, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %32, i64 64
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %32, i64 128
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %32, i64 192
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %.unpack17.i, i64 %31
  %41 = load double, ptr %40, align 8
  %42 = insertelement <4 x double> poison, double %33, i64 0
  %43 = insertelement <4 x double> %42, double %35, i64 1
  %44 = insertelement <4 x double> %43, double %37, i64 2
  %45 = insertelement <4 x double> %44, double %39, i64 3
  %46 = insertelement <4 x double> poison, double %41, i64 0
  %47 = shufflevector <4 x double> %46, <4 x double> poison, <4 x i32> zeroinitializer
  %48 = fmul <4 x double> %45, %47
  %49 = fadd <4 x double> %30, %48
  store <4 x double> %49, ptr %.unpack28.i, align 8
  %50 = add nuw nsw i64 %11, 2
  %exitcond.not.i.i.1 = icmp eq i64 %50, 64
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %10

.preheader.1.i.i:                                 ; preds = %10
  %51 = getelementptr double, ptr %.unpack28.i, i64 4
  br label %52

52:                                               ; preds = %52, %.preheader.1.i.i
  %53 = phi i64 [ 0, %.preheader.1.i.i ], [ %94, %52 ]
  %54 = phi <4 x double> [ zeroinitializer, %.preheader.1.i.i ], [ %93, %52 ]
  %55 = getelementptr double, ptr %.unpack2.i, i64 %53
  %56 = getelementptr double, ptr %55, i64 256
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %55, i64 320
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %55, i64 384
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %55, i64 448
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %.unpack17.i, i64 %53
  %65 = load double, ptr %64, align 8
  %66 = insertelement <4 x double> poison, double %57, i64 0
  %67 = insertelement <4 x double> %66, double %59, i64 1
  %68 = insertelement <4 x double> %67, double %61, i64 2
  %69 = insertelement <4 x double> %68, double %63, i64 3
  %70 = insertelement <4 x double> poison, double %65, i64 0
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = fmul <4 x double> %69, %71
  %73 = fadd <4 x double> %54, %72
  store <4 x double> %73, ptr %51, align 8
  %74 = or disjoint i64 %53, 1
  %75 = getelementptr double, ptr %.unpack2.i, i64 %74
  %76 = getelementptr double, ptr %75, i64 256
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %75, i64 320
  %79 = load double, ptr %78, align 8
  %80 = getelementptr double, ptr %75, i64 384
  %81 = load double, ptr %80, align 8
  %82 = getelementptr double, ptr %75, i64 448
  %83 = load double, ptr %82, align 8
  %84 = getelementptr double, ptr %.unpack17.i, i64 %74
  %85 = load double, ptr %84, align 8
  %86 = insertelement <4 x double> poison, double %77, i64 0
  %87 = insertelement <4 x double> %86, double %79, i64 1
  %88 = insertelement <4 x double> %87, double %81, i64 2
  %89 = insertelement <4 x double> %88, double %83, i64 3
  %90 = insertelement <4 x double> poison, double %85, i64 0
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = fmul <4 x double> %89, %91
  %93 = fadd <4 x double> %73, %92
  store <4 x double> %93, ptr %51, align 8
  %94 = add nuw nsw i64 %53, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %94, 64
  br i1 %exitcond.1.not.i.i.1, label %_mlir_ciface_kernel.exit, label %52

_mlir_ciface_kernel.exit:                         ; preds = %52
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
