module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<4xf64>) : vector<4xf64>
    %22 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %23 = llvm.mlir.constant(dense<0.000000e+00> : vector<1xf64>) : vector<1xf64>
    %24 = llvm.mlir.constant(3 : index) : i64
    %25 = llvm.mlir.constant(2 : index) : i64
    %26 = llvm.mlir.constant(dense<false> : vector<4x1xi1>) : !llvm.array<4 x vector<1xi1>>
    %27 = llvm.mlir.constant(dense<false> : vector<1xi1>) : vector<1xi1>
    %28 = llvm.mlir.constant(dense<true> : vector<1xi1>) : vector<1xi1>
    %29 = llvm.mlir.constant(-1 : index) : i64
    %30 = llvm.mlir.constant(8 : index) : i64
    %31 = llvm.mlir.constant(64 : index) : i64
    %32 = llvm.mlir.constant(4 : index) : i64
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.mlir.constant(0 : index) : i64
    %35 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%34 : i64)
  ^bb1(%36: i64):  // 2 preds: ^bb0, ^bb2
    %37 = llvm.icmp "slt" %36, %30 : i64
    llvm.cond_br %37, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %38 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %39 = llvm.getelementptr %38[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %35, %39 : f64, !llvm.ptr
    %40 = llvm.add %36, %33  : i64
    llvm.br ^bb1(%40 : i64)
  ^bb3:  // pred: ^bb1
    %41 = llvm.mlir.constant(1 : index) : i64
    %42 = llvm.alloca %41 x !llvm.array<4 x vector<1xf64>> : (i64) -> !llvm.ptr
    %43 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %44 = llvm.insertvalue %42, %43[0] : !llvm.struct<(ptr, ptr, i64)> 
    %45 = llvm.insertvalue %42, %44[1] : !llvm.struct<(ptr, ptr, i64)> 
    %46 = llvm.mlir.constant(0 : index) : i64
    %47 = llvm.insertvalue %46, %45[2] : !llvm.struct<(ptr, ptr, i64)> 
    %48 = llvm.mlir.constant(1 : index) : i64
    %49 = llvm.alloca %48 x !llvm.array<4 x vector<1xi1>> : (i64) -> !llvm.ptr
    %50 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %51 = llvm.insertvalue %49, %50[0] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.insertvalue %49, %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.mlir.constant(0 : index) : i64
    %54 = llvm.insertvalue %53, %52[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%34 : i64)
  ^bb4(%55: i64):  // 2 preds: ^bb3, ^bb11
    %56 = llvm.icmp "slt" %55, %30 : i64
    llvm.cond_br %56, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    llvm.br ^bb6(%34 : i64)
  ^bb6(%57: i64):  // 2 preds: ^bb5, ^bb10
    %58 = llvm.icmp "slt" %57, %31 : i64
    llvm.cond_br %58, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %59 = llvm.mul %55, %29  : i64
    %60 = llvm.add %59, %30  : i64
    %61 = llvm.icmp "slt" %60, %32 : i64
    %62 = llvm.select %61, %60, %32 : i1, i64
    %63 = llvm.mul %55, %29  : i64
    %64 = llvm.add %63, %30  : i64
    %65 = llvm.icmp "slt" %64, %32 : i64
    %66 = llvm.select %65, %64, %32 : i1, i64
    %67 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %68 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %67, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %75 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %76 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mul %55, %31  : i64
    %80 = llvm.add %79, %57  : i64
    %81 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %82 = llvm.insertvalue %67, %81[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %83 = llvm.insertvalue %68, %82[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.insertvalue %80, %83[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.insertvalue %62, %84[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.mlir.constant(64 : index) : i64
    %87 = llvm.insertvalue %86, %85[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.mlir.constant(1 : index) : i64
    %89 = llvm.insertvalue %88, %87[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.mlir.constant(1 : index) : i64
    %91 = llvm.insertvalue %90, %89[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %92 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %93 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %94 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %95 = llvm.insertvalue %92, %94[0] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.insertvalue %93, %95[1] : !llvm.struct<(ptr, ptr, i64)> 
    %97 = llvm.mlir.constant(0 : index) : i64
    %98 = llvm.insertvalue %97, %96[2] : !llvm.struct<(ptr, ptr, i64)> 
    %99 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %103 = llvm.insertvalue %92, %102[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %104 = llvm.insertvalue %93, %103[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %105 = llvm.insertvalue %57, %104[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.mlir.constant(1 : index) : i64
    %107 = llvm.insertvalue %106, %105[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %108 = llvm.mlir.constant(1 : index) : i64
    %109 = llvm.insertvalue %108, %107[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %110 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %112 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %113 = llvm.insertvalue %110, %112[0] : !llvm.struct<(ptr, ptr, i64)> 
    %114 = llvm.insertvalue %111, %113[1] : !llvm.struct<(ptr, ptr, i64)> 
    %115 = llvm.mlir.constant(0 : index) : i64
    %116 = llvm.insertvalue %115, %114[2] : !llvm.struct<(ptr, ptr, i64)> 
    %117 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %118 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %119 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %120 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %121 = llvm.insertvalue %110, %120[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %122 = llvm.insertvalue %111, %121[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %123 = llvm.insertvalue %55, %122[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %124 = llvm.insertvalue %66, %123[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %125 = llvm.mlir.constant(1 : index) : i64
    %126 = llvm.insertvalue %125, %124[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %127 = llvm.icmp "sgt" %62, %34 : i64
    %128 = llvm.select %127, %28, %27 : i1, vector<1xi1>
    %129 = llvm.insertvalue %128, %26[0] : !llvm.array<4 x vector<1xi1>> 
    %130 = llvm.icmp "sgt" %62, %33 : i64
    %131 = llvm.select %130, %28, %27 : i1, vector<1xi1>
    %132 = llvm.insertvalue %131, %129[1] : !llvm.array<4 x vector<1xi1>> 
    %133 = llvm.icmp "sgt" %62, %25 : i64
    %134 = llvm.select %133, %28, %27 : i1, vector<1xi1>
    %135 = llvm.insertvalue %134, %132[2] : !llvm.array<4 x vector<1xi1>> 
    %136 = llvm.icmp "sgt" %62, %24 : i64
    %137 = llvm.select %136, %28, %27 : i1, vector<1xi1>
    %138 = llvm.insertvalue %137, %135[3] : !llvm.array<4 x vector<1xi1>> 
    llvm.store %138, %49 : !llvm.array<4 x vector<1xi1>>, !llvm.ptr
    %139 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %140 = llvm.extractvalue %47[0] : !llvm.struct<(ptr, ptr, i64)> 
    %141 = llvm.insertvalue %140, %139[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %142 = llvm.extractvalue %47[1] : !llvm.struct<(ptr, ptr, i64)> 
    %143 = llvm.insertvalue %142, %141[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %144 = llvm.mlir.constant(0 : index) : i64
    %145 = llvm.insertvalue %144, %143[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %146 = llvm.mlir.constant(4 : index) : i64
    %147 = llvm.insertvalue %146, %145[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %148 = llvm.mlir.constant(1 : index) : i64
    %149 = llvm.insertvalue %148, %147[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %150 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %151 = llvm.extractvalue %54[0] : !llvm.struct<(ptr, ptr, i64)> 
    %152 = llvm.insertvalue %151, %150[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %153 = llvm.extractvalue %54[1] : !llvm.struct<(ptr, ptr, i64)> 
    %154 = llvm.insertvalue %153, %152[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %155 = llvm.mlir.constant(0 : index) : i64
    %156 = llvm.insertvalue %155, %154[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.mlir.constant(4 : index) : i64
    %158 = llvm.insertvalue %157, %156[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %159 = llvm.mlir.constant(1 : index) : i64
    %160 = llvm.insertvalue %159, %158[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%34 : i64)
  ^bb8(%161: i64):  // 2 preds: ^bb7, ^bb9
    %162 = llvm.icmp "slt" %161, %32 : i64
    llvm.cond_br %162, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %163 = llvm.getelementptr %153[%161] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xi1>
    %164 = llvm.load %163 : !llvm.ptr -> vector<1xi1>
    %165 = llvm.extractvalue %91[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %166 = llvm.extractvalue %91[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %167 = llvm.getelementptr %165[%166] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %168 = llvm.mlir.constant(64 : index) : i64
    %169 = llvm.mul %161, %168  : i64
    %170 = llvm.add %169, %34  : i64
    %171 = llvm.getelementptr %167[%170] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %172 = llvm.intr.masked.load %171, %164, %23 {alignment = 8 : i32} : (!llvm.ptr, vector<1xi1>, vector<1xf64>) -> vector<1xf64>
    %173 = llvm.getelementptr %142[%161] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %172, %173 : vector<1xf64>, !llvm.ptr
    %174 = llvm.add %161, %33  : i64
    llvm.br ^bb8(%174 : i64)
  ^bb10:  // pred: ^bb8
    %175 = llvm.load %42 : !llvm.ptr -> !llvm.array<4 x vector<1xf64>>
    %176 = llvm.getelementptr %93[%57] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %177 = llvm.getelementptr %176[%34] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %178 = llvm.load %177 : !llvm.ptr -> f64
    %179 = llvm.mlir.undef : vector<1xf64>
    %180 = llvm.mlir.constant(0 : i32) : i32
    %181 = llvm.insertelement %178, %179[%180 : i32] : vector<1xf64>
    %182 = llvm.shufflevector %181, %179 [0] : vector<1xf64> 
    %183 = llvm.insertvalue %182, %22[0] : !llvm.array<4 x vector<1xf64>> 
    %184 = llvm.insertvalue %182, %183[1] : !llvm.array<4 x vector<1xf64>> 
    %185 = llvm.insertvalue %182, %184[2] : !llvm.array<4 x vector<1xf64>> 
    %186 = llvm.insertvalue %182, %185[3] : !llvm.array<4 x vector<1xf64>> 
    %187 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %188 = llvm.trunc %62 : i64 to i32
    %189 = llvm.mlir.undef : vector<4xi32>
    %190 = llvm.mlir.constant(0 : i32) : i32
    %191 = llvm.insertelement %188, %189[%190 : i32] : vector<4xi32>
    %192 = llvm.shufflevector %191, %189 [0, 0, 0, 0] : vector<4xi32> 
    %193 = llvm.icmp "sgt" %192, %187 : vector<4xi32>
    %194 = llvm.extractvalue %126[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %195 = llvm.extractvalue %126[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %196 = llvm.getelementptr %194[%195] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %197 = llvm.getelementptr %196[%34] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %198 = llvm.intr.masked.load %197, %193, %21 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %199 = llvm.mlir.undef : !llvm.array<4 x vector<1xf64>>
    %200 = llvm.extractvalue %175[0] : !llvm.array<4 x vector<1xf64>> 
    %201 = llvm.fmul %200, %182  : vector<1xf64>
    %202 = llvm.insertvalue %201, %199[0] : !llvm.array<4 x vector<1xf64>> 
    %203 = llvm.extractvalue %175[1] : !llvm.array<4 x vector<1xf64>> 
    %204 = llvm.fmul %203, %182  : vector<1xf64>
    %205 = llvm.insertvalue %204, %202[1] : !llvm.array<4 x vector<1xf64>> 
    %206 = llvm.extractvalue %175[2] : !llvm.array<4 x vector<1xf64>> 
    %207 = llvm.fmul %206, %182  : vector<1xf64>
    %208 = llvm.insertvalue %207, %205[2] : !llvm.array<4 x vector<1xf64>> 
    %209 = llvm.extractvalue %175[3] : !llvm.array<4 x vector<1xf64>> 
    %210 = llvm.fmul %209, %182  : vector<1xf64>
    %211 = llvm.insertvalue %210, %208[3] : !llvm.array<4 x vector<1xf64>> 
    %212 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %213 = llvm.trunc %62 : i64 to i32
    %214 = llvm.mlir.undef : vector<4xi32>
    %215 = llvm.mlir.constant(0 : i32) : i32
    %216 = llvm.insertelement %213, %214[%215 : i32] : vector<4xi32>
    %217 = llvm.shufflevector %216, %214 [0, 0, 0, 0] : vector<4xi32> 
    %218 = llvm.icmp "sgt" %217, %212 : vector<4xi32>
    %219 = llvm.extractvalue %211[0] : !llvm.array<4 x vector<1xf64>> 
    %220 = llvm.mlir.constant(0 : i64) : i64
    %221 = llvm.extractelement %219[%220 : i64] : vector<1xf64>
    %222 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<4xf64>> 
    %223 = llvm.mlir.constant(0 : i64) : i64
    %224 = llvm.insertelement %221, %222[%223 : i64] : vector<4xf64>
    %225 = llvm.insertvalue %224, %20[0] : !llvm.array<1 x vector<4xf64>> 
    %226 = llvm.extractvalue %211[1] : !llvm.array<4 x vector<1xf64>> 
    %227 = llvm.mlir.constant(0 : i64) : i64
    %228 = llvm.extractelement %226[%227 : i64] : vector<1xf64>
    %229 = llvm.mlir.constant(1 : i64) : i64
    %230 = llvm.insertelement %228, %224[%229 : i64] : vector<4xf64>
    %231 = llvm.insertvalue %230, %225[0] : !llvm.array<1 x vector<4xf64>> 
    %232 = llvm.extractvalue %211[2] : !llvm.array<4 x vector<1xf64>> 
    %233 = llvm.mlir.constant(0 : i64) : i64
    %234 = llvm.extractelement %232[%233 : i64] : vector<1xf64>
    %235 = llvm.mlir.constant(2 : i64) : i64
    %236 = llvm.insertelement %234, %230[%235 : i64] : vector<4xf64>
    %237 = llvm.insertvalue %236, %231[0] : !llvm.array<1 x vector<4xf64>> 
    %238 = llvm.extractvalue %211[3] : !llvm.array<4 x vector<1xf64>> 
    %239 = llvm.mlir.constant(0 : i64) : i64
    %240 = llvm.extractelement %238[%239 : i64] : vector<1xf64>
    %241 = llvm.mlir.constant(3 : i64) : i64
    %242 = llvm.insertelement %240, %236[%241 : i64] : vector<4xf64>
    %243 = llvm.insertvalue %242, %237[0] : !llvm.array<1 x vector<4xf64>> 
    %244 = llvm.fadd %198, %242  : vector<4xf64>
    %245 = llvm.select %218, %244, %242 : vector<4xi1>, vector<4xf64>
    %246 = llvm.extractvalue %126[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %247 = llvm.extractvalue %126[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %248 = llvm.getelementptr %246[%247] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %249 = llvm.getelementptr %248[%34] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.intr.masked.store %245, %249, %193 {alignment = 8 : i32} : vector<4xf64>, vector<4xi1> into !llvm.ptr
    %250 = llvm.add %57, %33  : i64
    llvm.br ^bb6(%250 : i64)
  ^bb11:  // pred: ^bb6
    %251 = llvm.add %55, %32  : i64
    llvm.br ^bb4(%251 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
