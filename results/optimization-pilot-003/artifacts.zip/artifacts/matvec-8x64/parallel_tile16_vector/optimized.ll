; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %13, i8 0, i64 64, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader
  %18 = phi <4 x double> [ zeroinitializer, %.preheader ], [ %48, %17 ]
  %19 = phi i64 [ 0, %.preheader ], [ %49, %17 ]
  %20 = getelementptr double, ptr %1, i64 %19
  %unmaskedload = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %20, i64 64
  %unmaskedload15 = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %20, i64 128
  %unmaskedload16 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %20, i64 192
  %unmaskedload17 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %8, i64 %19
  %25 = load double, ptr %24, align 8
  %26 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload15, <2 x i32> <i32 0, i32 1>
  %27 = insertelement <2 x double> poison, double %25, i64 0
  %28 = shufflevector <2 x double> %27, <2 x double> poison, <2 x i32> zeroinitializer
  %29 = fmul <2 x double> %26, %28
  %30 = shufflevector <1 x double> %unmaskedload16, <1 x double> %unmaskedload17, <2 x i32> <i32 0, i32 1>
  %31 = fmul <2 x double> %30, %28
  %32 = shufflevector <2 x double> %29, <2 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %33 = fadd <4 x double> %18, %32
  store <4 x double> %33, ptr %13, align 8
  %34 = or disjoint i64 %19, 1
  %35 = getelementptr double, ptr %1, i64 %34
  %unmaskedload.1 = load <1 x double>, ptr %35, align 8
  %36 = getelementptr double, ptr %35, i64 64
  %unmaskedload15.1 = load <1 x double>, ptr %36, align 8
  %37 = getelementptr double, ptr %35, i64 128
  %unmaskedload16.1 = load <1 x double>, ptr %37, align 8
  %38 = getelementptr double, ptr %35, i64 192
  %unmaskedload17.1 = load <1 x double>, ptr %38, align 8
  %39 = getelementptr double, ptr %8, i64 %34
  %40 = load double, ptr %39, align 8
  %41 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload15.1, <2 x i32> <i32 0, i32 1>
  %42 = insertelement <2 x double> poison, double %40, i64 0
  %43 = shufflevector <2 x double> %42, <2 x double> poison, <2 x i32> zeroinitializer
  %44 = fmul <2 x double> %41, %43
  %45 = shufflevector <1 x double> %unmaskedload16.1, <1 x double> %unmaskedload17.1, <2 x i32> <i32 0, i32 1>
  %46 = fmul <2 x double> %45, %43
  %47 = shufflevector <2 x double> %44, <2 x double> %46, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %48 = fadd <4 x double> %33, %47
  store <4 x double> %48, ptr %13, align 8
  %49 = add nuw nsw i64 %19, 2
  %exitcond.not.1 = icmp eq i64 %49, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %50 = getelementptr double, ptr %13, i64 4
  %.promoted24 = load <4 x double>, ptr %50, align 8
  br label %51

51:                                               ; preds = %51, %.preheader.1
  %52 = phi <4 x double> [ %.promoted24, %.preheader.1 ], [ %84, %51 ]
  %53 = phi i64 [ 0, %.preheader.1 ], [ %85, %51 ]
  %54 = getelementptr double, ptr %1, i64 %53
  %55 = getelementptr double, ptr %54, i64 256
  %unmaskedload19 = load <1 x double>, ptr %55, align 8
  %56 = getelementptr double, ptr %54, i64 320
  %unmaskedload20 = load <1 x double>, ptr %56, align 8
  %57 = getelementptr double, ptr %54, i64 384
  %unmaskedload21 = load <1 x double>, ptr %57, align 8
  %58 = getelementptr double, ptr %54, i64 448
  %unmaskedload22 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %8, i64 %53
  %60 = load double, ptr %59, align 8
  %61 = shufflevector <1 x double> %unmaskedload19, <1 x double> %unmaskedload20, <2 x i32> <i32 0, i32 1>
  %62 = insertelement <2 x double> poison, double %60, i64 0
  %63 = shufflevector <2 x double> %62, <2 x double> poison, <2 x i32> zeroinitializer
  %64 = fmul <2 x double> %61, %63
  %65 = shufflevector <1 x double> %unmaskedload21, <1 x double> %unmaskedload22, <2 x i32> <i32 0, i32 1>
  %66 = fmul <2 x double> %65, %63
  %67 = shufflevector <2 x double> %64, <2 x double> %66, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %68 = fadd <4 x double> %52, %67
  store <4 x double> %68, ptr %50, align 8
  %69 = or disjoint i64 %53, 1
  %70 = getelementptr double, ptr %1, i64 %69
  %71 = getelementptr double, ptr %70, i64 256
  %unmaskedload19.1 = load <1 x double>, ptr %71, align 8
  %72 = getelementptr double, ptr %70, i64 320
  %unmaskedload20.1 = load <1 x double>, ptr %72, align 8
  %73 = getelementptr double, ptr %70, i64 384
  %unmaskedload21.1 = load <1 x double>, ptr %73, align 8
  %74 = getelementptr double, ptr %70, i64 448
  %unmaskedload22.1 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %8, i64 %69
  %76 = load double, ptr %75, align 8
  %77 = shufflevector <1 x double> %unmaskedload19.1, <1 x double> %unmaskedload20.1, <2 x i32> <i32 0, i32 1>
  %78 = insertelement <2 x double> poison, double %76, i64 0
  %79 = shufflevector <2 x double> %78, <2 x double> poison, <2 x i32> zeroinitializer
  %80 = fmul <2 x double> %77, %79
  %81 = shufflevector <1 x double> %unmaskedload21.1, <1 x double> %unmaskedload22.1, <2 x i32> <i32 0, i32 1>
  %82 = fmul <2 x double> %81, %79
  %83 = shufflevector <2 x double> %80, <2 x double> %82, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %84 = fadd <4 x double> %68, %83
  store <4 x double> %84, ptr %50, align 8
  %85 = add nuw nsw i64 %53, 2
  %exitcond.1.not.1 = icmp eq i64 %85, 64
  br i1 %exitcond.1.not.1, label %86, label %51

86:                                               ; preds = %51
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28, i8 0, i64 64, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi <4 x double> [ zeroinitializer, %3 ], [ %35, %4 ]
  %6 = phi i64 [ 0, %3 ], [ %36, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %6
  %unmaskedload.i = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %7, i64 64
  %unmaskedload15.i = load <1 x double>, ptr %8, align 8
  %9 = getelementptr double, ptr %7, i64 128
  %unmaskedload16.i = load <1 x double>, ptr %9, align 8
  %10 = getelementptr double, ptr %7, i64 192
  %unmaskedload17.i = load <1 x double>, ptr %10, align 8
  %11 = getelementptr double, ptr %.unpack17, i64 %6
  %12 = load double, ptr %11, align 8
  %13 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload15.i, <2 x i32> <i32 0, i32 1>
  %14 = insertelement <2 x double> poison, double %12, i64 0
  %15 = shufflevector <2 x double> %14, <2 x double> poison, <2 x i32> zeroinitializer
  %16 = fmul <2 x double> %13, %15
  %17 = shufflevector <1 x double> %unmaskedload16.i, <1 x double> %unmaskedload17.i, <2 x i32> <i32 0, i32 1>
  %18 = fmul <2 x double> %17, %15
  %19 = shufflevector <2 x double> %16, <2 x double> %18, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %20 = fadd <4 x double> %5, %19
  store <4 x double> %20, ptr %.unpack28, align 8
  %21 = or disjoint i64 %6, 1
  %22 = getelementptr double, ptr %.unpack2, i64 %21
  %unmaskedload.i.1 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %22, i64 64
  %unmaskedload15.i.1 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %22, i64 128
  %unmaskedload16.i.1 = load <1 x double>, ptr %24, align 8
  %25 = getelementptr double, ptr %22, i64 192
  %unmaskedload17.i.1 = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %.unpack17, i64 %21
  %27 = load double, ptr %26, align 8
  %28 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload15.i.1, <2 x i32> <i32 0, i32 1>
  %29 = insertelement <2 x double> poison, double %27, i64 0
  %30 = shufflevector <2 x double> %29, <2 x double> poison, <2 x i32> zeroinitializer
  %31 = fmul <2 x double> %28, %30
  %32 = shufflevector <1 x double> %unmaskedload16.i.1, <1 x double> %unmaskedload17.i.1, <2 x i32> <i32 0, i32 1>
  %33 = fmul <2 x double> %32, %30
  %34 = shufflevector <2 x double> %31, <2 x double> %33, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %35 = fadd <4 x double> %20, %34
  store <4 x double> %35, ptr %.unpack28, align 8
  %36 = add nuw nsw i64 %6, 2
  %exitcond.not.i.1 = icmp eq i64 %36, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %37 = getelementptr double, ptr %.unpack28, i64 4
  br label %38

38:                                               ; preds = %38, %.preheader.1.i
  %39 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %71, %38 ]
  %40 = phi i64 [ 0, %.preheader.1.i ], [ %72, %38 ]
  %41 = getelementptr double, ptr %.unpack2, i64 %40
  %42 = getelementptr double, ptr %41, i64 256
  %unmaskedload19.i = load <1 x double>, ptr %42, align 8
  %43 = getelementptr double, ptr %41, i64 320
  %unmaskedload20.i = load <1 x double>, ptr %43, align 8
  %44 = getelementptr double, ptr %41, i64 384
  %unmaskedload21.i = load <1 x double>, ptr %44, align 8
  %45 = getelementptr double, ptr %41, i64 448
  %unmaskedload22.i = load <1 x double>, ptr %45, align 8
  %46 = getelementptr double, ptr %.unpack17, i64 %40
  %47 = load double, ptr %46, align 8
  %48 = shufflevector <1 x double> %unmaskedload19.i, <1 x double> %unmaskedload20.i, <2 x i32> <i32 0, i32 1>
  %49 = insertelement <2 x double> poison, double %47, i64 0
  %50 = shufflevector <2 x double> %49, <2 x double> poison, <2 x i32> zeroinitializer
  %51 = fmul <2 x double> %48, %50
  %52 = shufflevector <1 x double> %unmaskedload21.i, <1 x double> %unmaskedload22.i, <2 x i32> <i32 0, i32 1>
  %53 = fmul <2 x double> %52, %50
  %54 = shufflevector <2 x double> %51, <2 x double> %53, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %55 = fadd <4 x double> %39, %54
  store <4 x double> %55, ptr %37, align 8
  %56 = or disjoint i64 %40, 1
  %57 = getelementptr double, ptr %.unpack2, i64 %56
  %58 = getelementptr double, ptr %57, i64 256
  %unmaskedload19.i.1 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %57, i64 320
  %unmaskedload20.i.1 = load <1 x double>, ptr %59, align 8
  %60 = getelementptr double, ptr %57, i64 384
  %unmaskedload21.i.1 = load <1 x double>, ptr %60, align 8
  %61 = getelementptr double, ptr %57, i64 448
  %unmaskedload22.i.1 = load <1 x double>, ptr %61, align 8
  %62 = getelementptr double, ptr %.unpack17, i64 %56
  %63 = load double, ptr %62, align 8
  %64 = shufflevector <1 x double> %unmaskedload19.i.1, <1 x double> %unmaskedload20.i.1, <2 x i32> <i32 0, i32 1>
  %65 = insertelement <2 x double> poison, double %63, i64 0
  %66 = shufflevector <2 x double> %65, <2 x double> poison, <2 x i32> zeroinitializer
  %67 = fmul <2 x double> %64, %66
  %68 = shufflevector <1 x double> %unmaskedload21.i.1, <1 x double> %unmaskedload22.i.1, <2 x i32> <i32 0, i32 1>
  %69 = fmul <2 x double> %68, %66
  %70 = shufflevector <2 x double> %67, <2 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %71 = fadd <4 x double> %55, %70
  store <4 x double> %71, ptr %37, align 8
  %72 = add nuw nsw i64 %40, 2
  %exitcond.1.not.i.1 = icmp eq i64 %72, 64
  br i1 %exitcond.1.not.i.1, label %kernel.exit, label %38

kernel.exit:                                      ; preds = %38
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %10, i8 0, i64 64, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi <4 x double> [ zeroinitializer, %1 ], [ %42, %11 ]
  %13 = phi i64 [ 0, %1 ], [ %43, %11 ]
  %14 = getelementptr double, ptr %4, i64 %13
  %unmaskedload.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %14, i64 64
  %unmaskedload15.i = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %14, i64 128
  %unmaskedload16.i = load <1 x double>, ptr %16, align 8
  %17 = getelementptr double, ptr %14, i64 192
  %unmaskedload17.i = load <1 x double>, ptr %17, align 8
  %18 = getelementptr double, ptr %7, i64 %13
  %19 = load double, ptr %18, align 8
  %20 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload15.i, <2 x i32> <i32 0, i32 1>
  %21 = insertelement <2 x double> poison, double %19, i64 0
  %22 = shufflevector <2 x double> %21, <2 x double> poison, <2 x i32> zeroinitializer
  %23 = fmul <2 x double> %20, %22
  %24 = shufflevector <1 x double> %unmaskedload16.i, <1 x double> %unmaskedload17.i, <2 x i32> <i32 0, i32 1>
  %25 = fmul <2 x double> %24, %22
  %26 = shufflevector <2 x double> %23, <2 x double> %25, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %27 = fadd <4 x double> %12, %26
  store <4 x double> %27, ptr %10, align 8
  %28 = or disjoint i64 %13, 1
  %29 = getelementptr double, ptr %4, i64 %28
  %unmaskedload.i.1 = load <1 x double>, ptr %29, align 8
  %30 = getelementptr double, ptr %29, i64 64
  %unmaskedload15.i.1 = load <1 x double>, ptr %30, align 8
  %31 = getelementptr double, ptr %29, i64 128
  %unmaskedload16.i.1 = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %29, i64 192
  %unmaskedload17.i.1 = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %7, i64 %28
  %34 = load double, ptr %33, align 8
  %35 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload15.i.1, <2 x i32> <i32 0, i32 1>
  %36 = insertelement <2 x double> poison, double %34, i64 0
  %37 = shufflevector <2 x double> %36, <2 x double> poison, <2 x i32> zeroinitializer
  %38 = fmul <2 x double> %35, %37
  %39 = shufflevector <1 x double> %unmaskedload16.i.1, <1 x double> %unmaskedload17.i.1, <2 x i32> <i32 0, i32 1>
  %40 = fmul <2 x double> %39, %37
  %41 = shufflevector <2 x double> %38, <2 x double> %40, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %42 = fadd <4 x double> %27, %41
  store <4 x double> %42, ptr %10, align 8
  %43 = add nuw nsw i64 %13, 2
  %exitcond.not.i.1 = icmp eq i64 %43, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %44 = getelementptr double, ptr %10, i64 4
  br label %45

45:                                               ; preds = %45, %.preheader.1.i
  %46 = phi <4 x double> [ zeroinitializer, %.preheader.1.i ], [ %78, %45 ]
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %79, %45 ]
  %48 = getelementptr double, ptr %4, i64 %47
  %49 = getelementptr double, ptr %48, i64 256
  %unmaskedload19.i = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %48, i64 320
  %unmaskedload20.i = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %48, i64 384
  %unmaskedload21.i = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %48, i64 448
  %unmaskedload22.i = load <1 x double>, ptr %52, align 8
  %53 = getelementptr double, ptr %7, i64 %47
  %54 = load double, ptr %53, align 8
  %55 = shufflevector <1 x double> %unmaskedload19.i, <1 x double> %unmaskedload20.i, <2 x i32> <i32 0, i32 1>
  %56 = insertelement <2 x double> poison, double %54, i64 0
  %57 = shufflevector <2 x double> %56, <2 x double> poison, <2 x i32> zeroinitializer
  %58 = fmul <2 x double> %55, %57
  %59 = shufflevector <1 x double> %unmaskedload21.i, <1 x double> %unmaskedload22.i, <2 x i32> <i32 0, i32 1>
  %60 = fmul <2 x double> %59, %57
  %61 = shufflevector <2 x double> %58, <2 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %62 = fadd <4 x double> %46, %61
  store <4 x double> %62, ptr %44, align 8
  %63 = or disjoint i64 %47, 1
  %64 = getelementptr double, ptr %4, i64 %63
  %65 = getelementptr double, ptr %64, i64 256
  %unmaskedload19.i.1 = load <1 x double>, ptr %65, align 8
  %66 = getelementptr double, ptr %64, i64 320
  %unmaskedload20.i.1 = load <1 x double>, ptr %66, align 8
  %67 = getelementptr double, ptr %64, i64 384
  %unmaskedload21.i.1 = load <1 x double>, ptr %67, align 8
  %68 = getelementptr double, ptr %64, i64 448
  %unmaskedload22.i.1 = load <1 x double>, ptr %68, align 8
  %69 = getelementptr double, ptr %7, i64 %63
  %70 = load double, ptr %69, align 8
  %71 = shufflevector <1 x double> %unmaskedload19.i.1, <1 x double> %unmaskedload20.i.1, <2 x i32> <i32 0, i32 1>
  %72 = insertelement <2 x double> poison, double %70, i64 0
  %73 = shufflevector <2 x double> %72, <2 x double> poison, <2 x i32> zeroinitializer
  %74 = fmul <2 x double> %71, %73
  %75 = shufflevector <1 x double> %unmaskedload21.i.1, <1 x double> %unmaskedload22.i.1, <2 x i32> <i32 0, i32 1>
  %76 = fmul <2 x double> %75, %73
  %77 = shufflevector <2 x double> %74, <2 x double> %76, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %78 = fadd <4 x double> %62, %77
  store <4 x double> %78, ptr %44, align 8
  %79 = add nuw nsw i64 %47, 2
  %exitcond.1.not.i.1 = icmp eq i64 %79, 64
  br i1 %exitcond.1.not.i.1, label %kernel.exit, label %45

kernel.exit:                                      ; preds = %45
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28.i, i8 0, i64 64, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi <4 x double> [ zeroinitializer, %1 ], [ %41, %10 ]
  %12 = phi i64 [ 0, %1 ], [ %42, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %12
  %unmaskedload.i.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 64
  %unmaskedload15.i.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %unmaskedload16.i.i = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %13, i64 192
  %unmaskedload17.i.i = load <1 x double>, ptr %16, align 8
  %17 = getelementptr double, ptr %.unpack17.i, i64 %12
  %18 = load double, ptr %17, align 8
  %19 = shufflevector <1 x double> %unmaskedload.i.i, <1 x double> %unmaskedload15.i.i, <2 x i32> <i32 0, i32 1>
  %20 = insertelement <2 x double> poison, double %18, i64 0
  %21 = shufflevector <2 x double> %20, <2 x double> poison, <2 x i32> zeroinitializer
  %22 = fmul <2 x double> %19, %21
  %23 = shufflevector <1 x double> %unmaskedload16.i.i, <1 x double> %unmaskedload17.i.i, <2 x i32> <i32 0, i32 1>
  %24 = fmul <2 x double> %23, %21
  %25 = shufflevector <2 x double> %22, <2 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %26 = fadd <4 x double> %11, %25
  store <4 x double> %26, ptr %.unpack28.i, align 8
  %27 = or disjoint i64 %12, 1
  %28 = getelementptr double, ptr %.unpack2.i, i64 %27
  %unmaskedload.i.i.1 = load <1 x double>, ptr %28, align 8
  %29 = getelementptr double, ptr %28, i64 64
  %unmaskedload15.i.i.1 = load <1 x double>, ptr %29, align 8
  %30 = getelementptr double, ptr %28, i64 128
  %unmaskedload16.i.i.1 = load <1 x double>, ptr %30, align 8
  %31 = getelementptr double, ptr %28, i64 192
  %unmaskedload17.i.i.1 = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %.unpack17.i, i64 %27
  %33 = load double, ptr %32, align 8
  %34 = shufflevector <1 x double> %unmaskedload.i.i.1, <1 x double> %unmaskedload15.i.i.1, <2 x i32> <i32 0, i32 1>
  %35 = insertelement <2 x double> poison, double %33, i64 0
  %36 = shufflevector <2 x double> %35, <2 x double> poison, <2 x i32> zeroinitializer
  %37 = fmul <2 x double> %34, %36
  %38 = shufflevector <1 x double> %unmaskedload16.i.i.1, <1 x double> %unmaskedload17.i.i.1, <2 x i32> <i32 0, i32 1>
  %39 = fmul <2 x double> %38, %36
  %40 = shufflevector <2 x double> %37, <2 x double> %39, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %41 = fadd <4 x double> %26, %40
  store <4 x double> %41, ptr %.unpack28.i, align 8
  %42 = add nuw nsw i64 %12, 2
  %exitcond.not.i.i.1 = icmp eq i64 %42, 64
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %10

.preheader.1.i.i:                                 ; preds = %10
  %43 = getelementptr double, ptr %.unpack28.i, i64 4
  br label %44

44:                                               ; preds = %44, %.preheader.1.i.i
  %45 = phi <4 x double> [ zeroinitializer, %.preheader.1.i.i ], [ %77, %44 ]
  %46 = phi i64 [ 0, %.preheader.1.i.i ], [ %78, %44 ]
  %47 = getelementptr double, ptr %.unpack2.i, i64 %46
  %48 = getelementptr double, ptr %47, i64 256
  %unmaskedload19.i.i = load <1 x double>, ptr %48, align 8
  %49 = getelementptr double, ptr %47, i64 320
  %unmaskedload20.i.i = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %47, i64 384
  %unmaskedload21.i.i = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %47, i64 448
  %unmaskedload22.i.i = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %.unpack17.i, i64 %46
  %53 = load double, ptr %52, align 8
  %54 = shufflevector <1 x double> %unmaskedload19.i.i, <1 x double> %unmaskedload20.i.i, <2 x i32> <i32 0, i32 1>
  %55 = insertelement <2 x double> poison, double %53, i64 0
  %56 = shufflevector <2 x double> %55, <2 x double> poison, <2 x i32> zeroinitializer
  %57 = fmul <2 x double> %54, %56
  %58 = shufflevector <1 x double> %unmaskedload21.i.i, <1 x double> %unmaskedload22.i.i, <2 x i32> <i32 0, i32 1>
  %59 = fmul <2 x double> %58, %56
  %60 = shufflevector <2 x double> %57, <2 x double> %59, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %61 = fadd <4 x double> %45, %60
  store <4 x double> %61, ptr %43, align 8
  %62 = or disjoint i64 %46, 1
  %63 = getelementptr double, ptr %.unpack2.i, i64 %62
  %64 = getelementptr double, ptr %63, i64 256
  %unmaskedload19.i.i.1 = load <1 x double>, ptr %64, align 8
  %65 = getelementptr double, ptr %63, i64 320
  %unmaskedload20.i.i.1 = load <1 x double>, ptr %65, align 8
  %66 = getelementptr double, ptr %63, i64 384
  %unmaskedload21.i.i.1 = load <1 x double>, ptr %66, align 8
  %67 = getelementptr double, ptr %63, i64 448
  %unmaskedload22.i.i.1 = load <1 x double>, ptr %67, align 8
  %68 = getelementptr double, ptr %.unpack17.i, i64 %62
  %69 = load double, ptr %68, align 8
  %70 = shufflevector <1 x double> %unmaskedload19.i.i.1, <1 x double> %unmaskedload20.i.i.1, <2 x i32> <i32 0, i32 1>
  %71 = insertelement <2 x double> poison, double %69, i64 0
  %72 = shufflevector <2 x double> %71, <2 x double> poison, <2 x i32> zeroinitializer
  %73 = fmul <2 x double> %70, %72
  %74 = shufflevector <1 x double> %unmaskedload21.i.i.1, <1 x double> %unmaskedload22.i.i.1, <2 x i32> <i32 0, i32 1>
  %75 = fmul <2 x double> %74, %72
  %76 = shufflevector <2 x double> %73, <2 x double> %75, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %77 = fadd <4 x double> %61, %76
  store <4 x double> %77, ptr %43, align 8
  %78 = add nuw nsw i64 %46, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %78, 64
  br i1 %exitcond.1.not.i.i.1, label %_mlir_ciface_kernel.exit, label %44

_mlir_ciface_kernel.exit:                         ; preds = %44
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
