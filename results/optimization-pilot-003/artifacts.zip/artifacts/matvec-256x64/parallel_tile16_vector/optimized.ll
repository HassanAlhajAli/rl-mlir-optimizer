; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %13, i8 0, i64 2048, i1 false)
  br label %.preheader10

.preheader10:                                     ; preds = %17, %186
  %18 = phi i64 [ 0, %17 ], [ %187, %186 ]
  %19 = getelementptr double, ptr %13, i64 %18
  %20 = shl nuw nsw i64 %18, 6
  %.promoted = load <4 x double>, ptr %19, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %20
  br label %21

21:                                               ; preds = %21, %.preheader10
  %22 = phi i64 [ 0, %.preheader10 ], [ %59, %21 ]
  %23 = phi <4 x double> [ %.promoted, %.preheader10 ], [ %58, %21 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %22
  %24 = load double, ptr %gep, align 8
  %25 = getelementptr double, ptr %gep, i64 64
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep, i64 128
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep, i64 192
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %8, i64 %22
  %32 = load double, ptr %31, align 8
  %33 = insertelement <4 x double> poison, double %24, i64 0
  %34 = insertelement <4 x double> %33, double %26, i64 1
  %35 = insertelement <4 x double> %34, double %28, i64 2
  %36 = insertelement <4 x double> %35, double %30, i64 3
  %37 = insertelement <4 x double> poison, double %32, i64 0
  %38 = shufflevector <4 x double> %37, <4 x double> poison, <4 x i32> zeroinitializer
  %39 = fmul <4 x double> %36, %38
  %40 = fadd <4 x double> %23, %39
  store <4 x double> %40, ptr %19, align 8
  %41 = or disjoint i64 %22, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %41
  %42 = load double, ptr %gep.1, align 8
  %43 = getelementptr double, ptr %gep.1, i64 64
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %gep.1, i64 128
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %gep.1, i64 192
  %48 = load double, ptr %47, align 8
  %49 = getelementptr double, ptr %8, i64 %41
  %50 = load double, ptr %49, align 8
  %51 = insertelement <4 x double> poison, double %42, i64 0
  %52 = insertelement <4 x double> %51, double %44, i64 1
  %53 = insertelement <4 x double> %52, double %46, i64 2
  %54 = insertelement <4 x double> %53, double %48, i64 3
  %55 = insertelement <4 x double> poison, double %50, i64 0
  %56 = shufflevector <4 x double> %55, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = fmul <4 x double> %54, %56
  %58 = fadd <4 x double> %40, %57
  store <4 x double> %58, ptr %19, align 8
  %59 = add nuw nsw i64 %22, 2
  %exitcond.not.1 = icmp eq i64 %59, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %21

.preheader.1:                                     ; preds = %21
  %60 = shl i64 %18, 6
  %61 = or disjoint i64 %60, 256
  %62 = getelementptr double, ptr %19, i64 4
  %.promoted.1 = load <4 x double>, ptr %62, align 8
  %invariant.gep11 = getelementptr double, ptr %1, i64 %61
  br label %63

63:                                               ; preds = %63, %.preheader.1
  %64 = phi i64 [ 0, %.preheader.1 ], [ %101, %63 ]
  %65 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %100, %63 ]
  %gep12 = getelementptr double, ptr %invariant.gep11, i64 %64
  %66 = load double, ptr %gep12, align 8
  %67 = getelementptr double, ptr %gep12, i64 64
  %68 = load double, ptr %67, align 8
  %69 = getelementptr double, ptr %gep12, i64 128
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %gep12, i64 192
  %72 = load double, ptr %71, align 8
  %73 = getelementptr double, ptr %8, i64 %64
  %74 = load double, ptr %73, align 8
  %75 = insertelement <4 x double> poison, double %66, i64 0
  %76 = insertelement <4 x double> %75, double %68, i64 1
  %77 = insertelement <4 x double> %76, double %70, i64 2
  %78 = insertelement <4 x double> %77, double %72, i64 3
  %79 = insertelement <4 x double> poison, double %74, i64 0
  %80 = shufflevector <4 x double> %79, <4 x double> poison, <4 x i32> zeroinitializer
  %81 = fmul <4 x double> %78, %80
  %82 = fadd <4 x double> %65, %81
  store <4 x double> %82, ptr %62, align 8
  %83 = or disjoint i64 %64, 1
  %gep12.1 = getelementptr double, ptr %invariant.gep11, i64 %83
  %84 = load double, ptr %gep12.1, align 8
  %85 = getelementptr double, ptr %gep12.1, i64 64
  %86 = load double, ptr %85, align 8
  %87 = getelementptr double, ptr %gep12.1, i64 128
  %88 = load double, ptr %87, align 8
  %89 = getelementptr double, ptr %gep12.1, i64 192
  %90 = load double, ptr %89, align 8
  %91 = getelementptr double, ptr %8, i64 %83
  %92 = load double, ptr %91, align 8
  %93 = insertelement <4 x double> poison, double %84, i64 0
  %94 = insertelement <4 x double> %93, double %86, i64 1
  %95 = insertelement <4 x double> %94, double %88, i64 2
  %96 = insertelement <4 x double> %95, double %90, i64 3
  %97 = insertelement <4 x double> poison, double %92, i64 0
  %98 = shufflevector <4 x double> %97, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = fmul <4 x double> %96, %98
  %100 = fadd <4 x double> %82, %99
  store <4 x double> %100, ptr %62, align 8
  %101 = add nuw nsw i64 %64, 2
  %exitcond.1.not.1 = icmp eq i64 %101, 64
  br i1 %exitcond.1.not.1, label %.preheader.2, label %63

.preheader.2:                                     ; preds = %63
  %102 = shl i64 %18, 6
  %103 = or disjoint i64 %102, 512
  %104 = getelementptr double, ptr %19, i64 8
  %.promoted.2 = load <4 x double>, ptr %104, align 8
  %invariant.gep13 = getelementptr double, ptr %1, i64 %103
  br label %105

105:                                              ; preds = %105, %.preheader.2
  %106 = phi i64 [ 0, %.preheader.2 ], [ %143, %105 ]
  %107 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %142, %105 ]
  %gep14 = getelementptr double, ptr %invariant.gep13, i64 %106
  %108 = load double, ptr %gep14, align 8
  %109 = getelementptr double, ptr %gep14, i64 64
  %110 = load double, ptr %109, align 8
  %111 = getelementptr double, ptr %gep14, i64 128
  %112 = load double, ptr %111, align 8
  %113 = getelementptr double, ptr %gep14, i64 192
  %114 = load double, ptr %113, align 8
  %115 = getelementptr double, ptr %8, i64 %106
  %116 = load double, ptr %115, align 8
  %117 = insertelement <4 x double> poison, double %108, i64 0
  %118 = insertelement <4 x double> %117, double %110, i64 1
  %119 = insertelement <4 x double> %118, double %112, i64 2
  %120 = insertelement <4 x double> %119, double %114, i64 3
  %121 = insertelement <4 x double> poison, double %116, i64 0
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <4 x i32> zeroinitializer
  %123 = fmul <4 x double> %120, %122
  %124 = fadd <4 x double> %107, %123
  store <4 x double> %124, ptr %104, align 8
  %125 = or disjoint i64 %106, 1
  %gep14.1 = getelementptr double, ptr %invariant.gep13, i64 %125
  %126 = load double, ptr %gep14.1, align 8
  %127 = getelementptr double, ptr %gep14.1, i64 64
  %128 = load double, ptr %127, align 8
  %129 = getelementptr double, ptr %gep14.1, i64 128
  %130 = load double, ptr %129, align 8
  %131 = getelementptr double, ptr %gep14.1, i64 192
  %132 = load double, ptr %131, align 8
  %133 = getelementptr double, ptr %8, i64 %125
  %134 = load double, ptr %133, align 8
  %135 = insertelement <4 x double> poison, double %126, i64 0
  %136 = insertelement <4 x double> %135, double %128, i64 1
  %137 = insertelement <4 x double> %136, double %130, i64 2
  %138 = insertelement <4 x double> %137, double %132, i64 3
  %139 = insertelement <4 x double> poison, double %134, i64 0
  %140 = shufflevector <4 x double> %139, <4 x double> poison, <4 x i32> zeroinitializer
  %141 = fmul <4 x double> %138, %140
  %142 = fadd <4 x double> %124, %141
  store <4 x double> %142, ptr %104, align 8
  %143 = add nuw nsw i64 %106, 2
  %exitcond.2.not.1 = icmp eq i64 %143, 64
  br i1 %exitcond.2.not.1, label %.preheader.3, label %105

.preheader.3:                                     ; preds = %105
  %144 = shl i64 %18, 6
  %145 = or disjoint i64 %144, 768
  %146 = getelementptr double, ptr %19, i64 12
  %.promoted.3 = load <4 x double>, ptr %146, align 8
  %invariant.gep15 = getelementptr double, ptr %1, i64 %145
  br label %147

147:                                              ; preds = %147, %.preheader.3
  %148 = phi i64 [ 0, %.preheader.3 ], [ %185, %147 ]
  %149 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %184, %147 ]
  %gep16 = getelementptr double, ptr %invariant.gep15, i64 %148
  %150 = load double, ptr %gep16, align 8
  %151 = getelementptr double, ptr %gep16, i64 64
  %152 = load double, ptr %151, align 8
  %153 = getelementptr double, ptr %gep16, i64 128
  %154 = load double, ptr %153, align 8
  %155 = getelementptr double, ptr %gep16, i64 192
  %156 = load double, ptr %155, align 8
  %157 = getelementptr double, ptr %8, i64 %148
  %158 = load double, ptr %157, align 8
  %159 = insertelement <4 x double> poison, double %150, i64 0
  %160 = insertelement <4 x double> %159, double %152, i64 1
  %161 = insertelement <4 x double> %160, double %154, i64 2
  %162 = insertelement <4 x double> %161, double %156, i64 3
  %163 = insertelement <4 x double> poison, double %158, i64 0
  %164 = shufflevector <4 x double> %163, <4 x double> poison, <4 x i32> zeroinitializer
  %165 = fmul <4 x double> %162, %164
  %166 = fadd <4 x double> %149, %165
  store <4 x double> %166, ptr %146, align 8
  %167 = or disjoint i64 %148, 1
  %gep16.1 = getelementptr double, ptr %invariant.gep15, i64 %167
  %168 = load double, ptr %gep16.1, align 8
  %169 = getelementptr double, ptr %gep16.1, i64 64
  %170 = load double, ptr %169, align 8
  %171 = getelementptr double, ptr %gep16.1, i64 128
  %172 = load double, ptr %171, align 8
  %173 = getelementptr double, ptr %gep16.1, i64 192
  %174 = load double, ptr %173, align 8
  %175 = getelementptr double, ptr %8, i64 %167
  %176 = load double, ptr %175, align 8
  %177 = insertelement <4 x double> poison, double %168, i64 0
  %178 = insertelement <4 x double> %177, double %170, i64 1
  %179 = insertelement <4 x double> %178, double %172, i64 2
  %180 = insertelement <4 x double> %179, double %174, i64 3
  %181 = insertelement <4 x double> poison, double %176, i64 0
  %182 = shufflevector <4 x double> %181, <4 x double> poison, <4 x i32> zeroinitializer
  %183 = fmul <4 x double> %180, %182
  %184 = fadd <4 x double> %166, %183
  store <4 x double> %184, ptr %146, align 8
  %185 = add nuw nsw i64 %148, 2
  %exitcond.3.not.1 = icmp eq i64 %185, 64
  br i1 %exitcond.3.not.1, label %186, label %147

186:                                              ; preds = %147
  %187 = add nuw nsw i64 %18, 16
  %188 = icmp ult i64 %18, 240
  br i1 %188, label %.preheader10, label %189

189:                                              ; preds = %186
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack28, i8 0, i64 2048, i1 false)
  br label %.preheader10.i

.preheader10.i:                                   ; preds = %169, %3
  %4 = phi i64 [ 0, %3 ], [ %170, %169 ]
  %5 = getelementptr double, ptr %.unpack28, i64 %4
  %6 = shl nuw nsw i64 %4, 6
  %.promoted.i = load <4 x double>, ptr %5, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %7

7:                                                ; preds = %7, %.preheader10.i
  %8 = phi i64 [ 0, %.preheader10.i ], [ %45, %7 ]
  %9 = phi <4 x double> [ %.promoted.i, %.preheader10.i ], [ %44, %7 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %8
  %10 = load double, ptr %gep.i, align 8
  %11 = getelementptr double, ptr %gep.i, i64 64
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %gep.i, i64 128
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %gep.i, i64 192
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %.unpack17, i64 %8
  %18 = load double, ptr %17, align 8
  %19 = insertelement <4 x double> poison, double %10, i64 0
  %20 = insertelement <4 x double> %19, double %12, i64 1
  %21 = insertelement <4 x double> %20, double %14, i64 2
  %22 = insertelement <4 x double> %21, double %16, i64 3
  %23 = insertelement <4 x double> poison, double %18, i64 0
  %24 = shufflevector <4 x double> %23, <4 x double> poison, <4 x i32> zeroinitializer
  %25 = fmul <4 x double> %22, %24
  %26 = fadd <4 x double> %9, %25
  store <4 x double> %26, ptr %5, align 8
  %27 = or disjoint i64 %8, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %27
  %28 = load double, ptr %gep.i.1, align 8
  %29 = getelementptr double, ptr %gep.i.1, i64 64
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i.1, i64 128
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %gep.i.1, i64 192
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %.unpack17, i64 %27
  %36 = load double, ptr %35, align 8
  %37 = insertelement <4 x double> poison, double %28, i64 0
  %38 = insertelement <4 x double> %37, double %30, i64 1
  %39 = insertelement <4 x double> %38, double %32, i64 2
  %40 = insertelement <4 x double> %39, double %34, i64 3
  %41 = insertelement <4 x double> poison, double %36, i64 0
  %42 = shufflevector <4 x double> %41, <4 x double> poison, <4 x i32> zeroinitializer
  %43 = fmul <4 x double> %40, %42
  %44 = fadd <4 x double> %26, %43
  store <4 x double> %44, ptr %5, align 8
  %45 = add nuw nsw i64 %8, 2
  %exitcond.not.i.1 = icmp eq i64 %45, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %7

.preheader.1.i:                                   ; preds = %7
  %46 = or disjoint i64 %6, 256
  %47 = getelementptr double, ptr %5, i64 4
  %.promoted.1.i = load <4 x double>, ptr %47, align 8
  %invariant.gep11.i = getelementptr double, ptr %.unpack2, i64 %46
  br label %48

48:                                               ; preds = %48, %.preheader.1.i
  %49 = phi i64 [ 0, %.preheader.1.i ], [ %86, %48 ]
  %50 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %85, %48 ]
  %gep12.i = getelementptr double, ptr %invariant.gep11.i, i64 %49
  %51 = load double, ptr %gep12.i, align 8
  %52 = getelementptr double, ptr %gep12.i, i64 64
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %gep12.i, i64 128
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %gep12.i, i64 192
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %49
  %59 = load double, ptr %58, align 8
  %60 = insertelement <4 x double> poison, double %51, i64 0
  %61 = insertelement <4 x double> %60, double %53, i64 1
  %62 = insertelement <4 x double> %61, double %55, i64 2
  %63 = insertelement <4 x double> %62, double %57, i64 3
  %64 = insertelement <4 x double> poison, double %59, i64 0
  %65 = shufflevector <4 x double> %64, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = fmul <4 x double> %63, %65
  %67 = fadd <4 x double> %50, %66
  store <4 x double> %67, ptr %47, align 8
  %68 = or disjoint i64 %49, 1
  %gep12.i.1 = getelementptr double, ptr %invariant.gep11.i, i64 %68
  %69 = load double, ptr %gep12.i.1, align 8
  %70 = getelementptr double, ptr %gep12.i.1, i64 64
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %gep12.i.1, i64 128
  %73 = load double, ptr %72, align 8
  %74 = getelementptr double, ptr %gep12.i.1, i64 192
  %75 = load double, ptr %74, align 8
  %76 = getelementptr double, ptr %.unpack17, i64 %68
  %77 = load double, ptr %76, align 8
  %78 = insertelement <4 x double> poison, double %69, i64 0
  %79 = insertelement <4 x double> %78, double %71, i64 1
  %80 = insertelement <4 x double> %79, double %73, i64 2
  %81 = insertelement <4 x double> %80, double %75, i64 3
  %82 = insertelement <4 x double> poison, double %77, i64 0
  %83 = shufflevector <4 x double> %82, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = fmul <4 x double> %81, %83
  %85 = fadd <4 x double> %67, %84
  store <4 x double> %85, ptr %47, align 8
  %86 = add nuw nsw i64 %49, 2
  %exitcond.1.not.i.1 = icmp eq i64 %86, 64
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %48

.preheader.2.i:                                   ; preds = %48
  %87 = or disjoint i64 %6, 512
  %88 = getelementptr double, ptr %5, i64 8
  %.promoted.2.i = load <4 x double>, ptr %88, align 8
  %invariant.gep13.i = getelementptr double, ptr %.unpack2, i64 %87
  br label %89

89:                                               ; preds = %89, %.preheader.2.i
  %90 = phi i64 [ 0, %.preheader.2.i ], [ %127, %89 ]
  %91 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %126, %89 ]
  %gep14.i = getelementptr double, ptr %invariant.gep13.i, i64 %90
  %92 = load double, ptr %gep14.i, align 8
  %93 = getelementptr double, ptr %gep14.i, i64 64
  %94 = load double, ptr %93, align 8
  %95 = getelementptr double, ptr %gep14.i, i64 128
  %96 = load double, ptr %95, align 8
  %97 = getelementptr double, ptr %gep14.i, i64 192
  %98 = load double, ptr %97, align 8
  %99 = getelementptr double, ptr %.unpack17, i64 %90
  %100 = load double, ptr %99, align 8
  %101 = insertelement <4 x double> poison, double %92, i64 0
  %102 = insertelement <4 x double> %101, double %94, i64 1
  %103 = insertelement <4 x double> %102, double %96, i64 2
  %104 = insertelement <4 x double> %103, double %98, i64 3
  %105 = insertelement <4 x double> poison, double %100, i64 0
  %106 = shufflevector <4 x double> %105, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = fmul <4 x double> %104, %106
  %108 = fadd <4 x double> %91, %107
  store <4 x double> %108, ptr %88, align 8
  %109 = or disjoint i64 %90, 1
  %gep14.i.1 = getelementptr double, ptr %invariant.gep13.i, i64 %109
  %110 = load double, ptr %gep14.i.1, align 8
  %111 = getelementptr double, ptr %gep14.i.1, i64 64
  %112 = load double, ptr %111, align 8
  %113 = getelementptr double, ptr %gep14.i.1, i64 128
  %114 = load double, ptr %113, align 8
  %115 = getelementptr double, ptr %gep14.i.1, i64 192
  %116 = load double, ptr %115, align 8
  %117 = getelementptr double, ptr %.unpack17, i64 %109
  %118 = load double, ptr %117, align 8
  %119 = insertelement <4 x double> poison, double %110, i64 0
  %120 = insertelement <4 x double> %119, double %112, i64 1
  %121 = insertelement <4 x double> %120, double %114, i64 2
  %122 = insertelement <4 x double> %121, double %116, i64 3
  %123 = insertelement <4 x double> poison, double %118, i64 0
  %124 = shufflevector <4 x double> %123, <4 x double> poison, <4 x i32> zeroinitializer
  %125 = fmul <4 x double> %122, %124
  %126 = fadd <4 x double> %108, %125
  store <4 x double> %126, ptr %88, align 8
  %127 = add nuw nsw i64 %90, 2
  %exitcond.2.not.i.1 = icmp eq i64 %127, 64
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %89

.preheader.3.i:                                   ; preds = %89
  %128 = or disjoint i64 %6, 768
  %129 = getelementptr double, ptr %5, i64 12
  %.promoted.3.i = load <4 x double>, ptr %129, align 8
  %invariant.gep15.i = getelementptr double, ptr %.unpack2, i64 %128
  br label %130

130:                                              ; preds = %130, %.preheader.3.i
  %131 = phi i64 [ 0, %.preheader.3.i ], [ %168, %130 ]
  %132 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %167, %130 ]
  %gep16.i = getelementptr double, ptr %invariant.gep15.i, i64 %131
  %133 = load double, ptr %gep16.i, align 8
  %134 = getelementptr double, ptr %gep16.i, i64 64
  %135 = load double, ptr %134, align 8
  %136 = getelementptr double, ptr %gep16.i, i64 128
  %137 = load double, ptr %136, align 8
  %138 = getelementptr double, ptr %gep16.i, i64 192
  %139 = load double, ptr %138, align 8
  %140 = getelementptr double, ptr %.unpack17, i64 %131
  %141 = load double, ptr %140, align 8
  %142 = insertelement <4 x double> poison, double %133, i64 0
  %143 = insertelement <4 x double> %142, double %135, i64 1
  %144 = insertelement <4 x double> %143, double %137, i64 2
  %145 = insertelement <4 x double> %144, double %139, i64 3
  %146 = insertelement <4 x double> poison, double %141, i64 0
  %147 = shufflevector <4 x double> %146, <4 x double> poison, <4 x i32> zeroinitializer
  %148 = fmul <4 x double> %145, %147
  %149 = fadd <4 x double> %132, %148
  store <4 x double> %149, ptr %129, align 8
  %150 = or disjoint i64 %131, 1
  %gep16.i.1 = getelementptr double, ptr %invariant.gep15.i, i64 %150
  %151 = load double, ptr %gep16.i.1, align 8
  %152 = getelementptr double, ptr %gep16.i.1, i64 64
  %153 = load double, ptr %152, align 8
  %154 = getelementptr double, ptr %gep16.i.1, i64 128
  %155 = load double, ptr %154, align 8
  %156 = getelementptr double, ptr %gep16.i.1, i64 192
  %157 = load double, ptr %156, align 8
  %158 = getelementptr double, ptr %.unpack17, i64 %150
  %159 = load double, ptr %158, align 8
  %160 = insertelement <4 x double> poison, double %151, i64 0
  %161 = insertelement <4 x double> %160, double %153, i64 1
  %162 = insertelement <4 x double> %161, double %155, i64 2
  %163 = insertelement <4 x double> %162, double %157, i64 3
  %164 = insertelement <4 x double> poison, double %159, i64 0
  %165 = shufflevector <4 x double> %164, <4 x double> poison, <4 x i32> zeroinitializer
  %166 = fmul <4 x double> %163, %165
  %167 = fadd <4 x double> %149, %166
  store <4 x double> %167, ptr %129, align 8
  %168 = add nuw nsw i64 %131, 2
  %exitcond.3.not.i.1 = icmp eq i64 %168, 64
  br i1 %exitcond.3.not.i.1, label %169, label %130

169:                                              ; preds = %130
  %170 = add nuw nsw i64 %4, 16
  %171 = icmp ult i64 %4, 240
  br i1 %171, label %.preheader10.i, label %kernel.exit

kernel.exit:                                      ; preds = %169
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %10, i8 0, i64 2048, i1 false)
  br label %.preheader10.i

.preheader10.i:                                   ; preds = %176, %1
  %11 = phi i64 [ 0, %1 ], [ %177, %176 ]
  %12 = getelementptr double, ptr %10, i64 %11
  %13 = shl nuw nsw i64 %11, 6
  %.promoted.i = load <4 x double>, ptr %12, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %13
  br label %14

14:                                               ; preds = %14, %.preheader10.i
  %15 = phi i64 [ 0, %.preheader10.i ], [ %52, %14 ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader10.i ], [ %51, %14 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %17 = load double, ptr %gep.i, align 8
  %18 = getelementptr double, ptr %gep.i, i64 64
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 128
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 192
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %7, i64 %15
  %25 = load double, ptr %24, align 8
  %26 = insertelement <4 x double> poison, double %17, i64 0
  %27 = insertelement <4 x double> %26, double %19, i64 1
  %28 = insertelement <4 x double> %27, double %21, i64 2
  %29 = insertelement <4 x double> %28, double %23, i64 3
  %30 = insertelement <4 x double> poison, double %25, i64 0
  %31 = shufflevector <4 x double> %30, <4 x double> poison, <4 x i32> zeroinitializer
  %32 = fmul <4 x double> %29, %31
  %33 = fadd <4 x double> %16, %32
  store <4 x double> %33, ptr %12, align 8
  %34 = or disjoint i64 %15, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %34
  %35 = load double, ptr %gep.i.1, align 8
  %36 = getelementptr double, ptr %gep.i.1, i64 64
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep.i.1, i64 128
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep.i.1, i64 192
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %7, i64 %34
  %43 = load double, ptr %42, align 8
  %44 = insertelement <4 x double> poison, double %35, i64 0
  %45 = insertelement <4 x double> %44, double %37, i64 1
  %46 = insertelement <4 x double> %45, double %39, i64 2
  %47 = insertelement <4 x double> %46, double %41, i64 3
  %48 = insertelement <4 x double> poison, double %43, i64 0
  %49 = shufflevector <4 x double> %48, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = fmul <4 x double> %47, %49
  %51 = fadd <4 x double> %33, %50
  store <4 x double> %51, ptr %12, align 8
  %52 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %52, 64
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %14

.preheader.1.i:                                   ; preds = %14
  %53 = or disjoint i64 %13, 256
  %54 = getelementptr double, ptr %12, i64 4
  %.promoted.1.i = load <4 x double>, ptr %54, align 8
  %invariant.gep11.i = getelementptr double, ptr %4, i64 %53
  br label %55

55:                                               ; preds = %55, %.preheader.1.i
  %56 = phi i64 [ 0, %.preheader.1.i ], [ %93, %55 ]
  %57 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %92, %55 ]
  %gep12.i = getelementptr double, ptr %invariant.gep11.i, i64 %56
  %58 = load double, ptr %gep12.i, align 8
  %59 = getelementptr double, ptr %gep12.i, i64 64
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %gep12.i, i64 128
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %gep12.i, i64 192
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %56
  %66 = load double, ptr %65, align 8
  %67 = insertelement <4 x double> poison, double %58, i64 0
  %68 = insertelement <4 x double> %67, double %60, i64 1
  %69 = insertelement <4 x double> %68, double %62, i64 2
  %70 = insertelement <4 x double> %69, double %64, i64 3
  %71 = insertelement <4 x double> poison, double %66, i64 0
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = fmul <4 x double> %70, %72
  %74 = fadd <4 x double> %57, %73
  store <4 x double> %74, ptr %54, align 8
  %75 = or disjoint i64 %56, 1
  %gep12.i.1 = getelementptr double, ptr %invariant.gep11.i, i64 %75
  %76 = load double, ptr %gep12.i.1, align 8
  %77 = getelementptr double, ptr %gep12.i.1, i64 64
  %78 = load double, ptr %77, align 8
  %79 = getelementptr double, ptr %gep12.i.1, i64 128
  %80 = load double, ptr %79, align 8
  %81 = getelementptr double, ptr %gep12.i.1, i64 192
  %82 = load double, ptr %81, align 8
  %83 = getelementptr double, ptr %7, i64 %75
  %84 = load double, ptr %83, align 8
  %85 = insertelement <4 x double> poison, double %76, i64 0
  %86 = insertelement <4 x double> %85, double %78, i64 1
  %87 = insertelement <4 x double> %86, double %80, i64 2
  %88 = insertelement <4 x double> %87, double %82, i64 3
  %89 = insertelement <4 x double> poison, double %84, i64 0
  %90 = shufflevector <4 x double> %89, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = fmul <4 x double> %88, %90
  %92 = fadd <4 x double> %74, %91
  store <4 x double> %92, ptr %54, align 8
  %93 = add nuw nsw i64 %56, 2
  %exitcond.1.not.i.1 = icmp eq i64 %93, 64
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %55

.preheader.2.i:                                   ; preds = %55
  %94 = or disjoint i64 %13, 512
  %95 = getelementptr double, ptr %12, i64 8
  %.promoted.2.i = load <4 x double>, ptr %95, align 8
  %invariant.gep13.i = getelementptr double, ptr %4, i64 %94
  br label %96

96:                                               ; preds = %96, %.preheader.2.i
  %97 = phi i64 [ 0, %.preheader.2.i ], [ %134, %96 ]
  %98 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %133, %96 ]
  %gep14.i = getelementptr double, ptr %invariant.gep13.i, i64 %97
  %99 = load double, ptr %gep14.i, align 8
  %100 = getelementptr double, ptr %gep14.i, i64 64
  %101 = load double, ptr %100, align 8
  %102 = getelementptr double, ptr %gep14.i, i64 128
  %103 = load double, ptr %102, align 8
  %104 = getelementptr double, ptr %gep14.i, i64 192
  %105 = load double, ptr %104, align 8
  %106 = getelementptr double, ptr %7, i64 %97
  %107 = load double, ptr %106, align 8
  %108 = insertelement <4 x double> poison, double %99, i64 0
  %109 = insertelement <4 x double> %108, double %101, i64 1
  %110 = insertelement <4 x double> %109, double %103, i64 2
  %111 = insertelement <4 x double> %110, double %105, i64 3
  %112 = insertelement <4 x double> poison, double %107, i64 0
  %113 = shufflevector <4 x double> %112, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = fmul <4 x double> %111, %113
  %115 = fadd <4 x double> %98, %114
  store <4 x double> %115, ptr %95, align 8
  %116 = or disjoint i64 %97, 1
  %gep14.i.1 = getelementptr double, ptr %invariant.gep13.i, i64 %116
  %117 = load double, ptr %gep14.i.1, align 8
  %118 = getelementptr double, ptr %gep14.i.1, i64 64
  %119 = load double, ptr %118, align 8
  %120 = getelementptr double, ptr %gep14.i.1, i64 128
  %121 = load double, ptr %120, align 8
  %122 = getelementptr double, ptr %gep14.i.1, i64 192
  %123 = load double, ptr %122, align 8
  %124 = getelementptr double, ptr %7, i64 %116
  %125 = load double, ptr %124, align 8
  %126 = insertelement <4 x double> poison, double %117, i64 0
  %127 = insertelement <4 x double> %126, double %119, i64 1
  %128 = insertelement <4 x double> %127, double %121, i64 2
  %129 = insertelement <4 x double> %128, double %123, i64 3
  %130 = insertelement <4 x double> poison, double %125, i64 0
  %131 = shufflevector <4 x double> %130, <4 x double> poison, <4 x i32> zeroinitializer
  %132 = fmul <4 x double> %129, %131
  %133 = fadd <4 x double> %115, %132
  store <4 x double> %133, ptr %95, align 8
  %134 = add nuw nsw i64 %97, 2
  %exitcond.2.not.i.1 = icmp eq i64 %134, 64
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %96

.preheader.3.i:                                   ; preds = %96
  %135 = or disjoint i64 %13, 768
  %136 = getelementptr double, ptr %12, i64 12
  %.promoted.3.i = load <4 x double>, ptr %136, align 8
  %invariant.gep15.i = getelementptr double, ptr %4, i64 %135
  br label %137

137:                                              ; preds = %137, %.preheader.3.i
  %138 = phi i64 [ 0, %.preheader.3.i ], [ %175, %137 ]
  %139 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %174, %137 ]
  %gep16.i = getelementptr double, ptr %invariant.gep15.i, i64 %138
  %140 = load double, ptr %gep16.i, align 8
  %141 = getelementptr double, ptr %gep16.i, i64 64
  %142 = load double, ptr %141, align 8
  %143 = getelementptr double, ptr %gep16.i, i64 128
  %144 = load double, ptr %143, align 8
  %145 = getelementptr double, ptr %gep16.i, i64 192
  %146 = load double, ptr %145, align 8
  %147 = getelementptr double, ptr %7, i64 %138
  %148 = load double, ptr %147, align 8
  %149 = insertelement <4 x double> poison, double %140, i64 0
  %150 = insertelement <4 x double> %149, double %142, i64 1
  %151 = insertelement <4 x double> %150, double %144, i64 2
  %152 = insertelement <4 x double> %151, double %146, i64 3
  %153 = insertelement <4 x double> poison, double %148, i64 0
  %154 = shufflevector <4 x double> %153, <4 x double> poison, <4 x i32> zeroinitializer
  %155 = fmul <4 x double> %152, %154
  %156 = fadd <4 x double> %139, %155
  store <4 x double> %156, ptr %136, align 8
  %157 = or disjoint i64 %138, 1
  %gep16.i.1 = getelementptr double, ptr %invariant.gep15.i, i64 %157
  %158 = load double, ptr %gep16.i.1, align 8
  %159 = getelementptr double, ptr %gep16.i.1, i64 64
  %160 = load double, ptr %159, align 8
  %161 = getelementptr double, ptr %gep16.i.1, i64 128
  %162 = load double, ptr %161, align 8
  %163 = getelementptr double, ptr %gep16.i.1, i64 192
  %164 = load double, ptr %163, align 8
  %165 = getelementptr double, ptr %7, i64 %157
  %166 = load double, ptr %165, align 8
  %167 = insertelement <4 x double> poison, double %158, i64 0
  %168 = insertelement <4 x double> %167, double %160, i64 1
  %169 = insertelement <4 x double> %168, double %162, i64 2
  %170 = insertelement <4 x double> %169, double %164, i64 3
  %171 = insertelement <4 x double> poison, double %166, i64 0
  %172 = shufflevector <4 x double> %171, <4 x double> poison, <4 x i32> zeroinitializer
  %173 = fmul <4 x double> %170, %172
  %174 = fadd <4 x double> %156, %173
  store <4 x double> %174, ptr %136, align 8
  %175 = add nuw nsw i64 %138, 2
  %exitcond.3.not.i.1 = icmp eq i64 %175, 64
  br i1 %exitcond.3.not.i.1, label %176, label %137

176:                                              ; preds = %137
  %177 = add nuw nsw i64 %11, 16
  %178 = icmp ult i64 %11, 240
  br i1 %178, label %.preheader10.i, label %kernel.exit

kernel.exit:                                      ; preds = %176
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack28.i, i8 0, i64 2048, i1 false)
  br label %.preheader10.i.i

.preheader10.i.i:                                 ; preds = %175, %1
  %10 = phi i64 [ 0, %1 ], [ %176, %175 ]
  %11 = getelementptr double, ptr %.unpack28.i, i64 %10
  %12 = shl nuw nsw i64 %10, 6
  %.promoted.i.i = load <4 x double>, ptr %11, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %13

13:                                               ; preds = %13, %.preheader10.i.i
  %14 = phi i64 [ 0, %.preheader10.i.i ], [ %51, %13 ]
  %15 = phi <4 x double> [ %.promoted.i.i, %.preheader10.i.i ], [ %50, %13 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %14
  %16 = load double, ptr %gep.i.i, align 8
  %17 = getelementptr double, ptr %gep.i.i, i64 64
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %gep.i.i, i64 128
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i.i, i64 192
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17.i, i64 %14
  %24 = load double, ptr %23, align 8
  %25 = insertelement <4 x double> poison, double %16, i64 0
  %26 = insertelement <4 x double> %25, double %18, i64 1
  %27 = insertelement <4 x double> %26, double %20, i64 2
  %28 = insertelement <4 x double> %27, double %22, i64 3
  %29 = insertelement <4 x double> poison, double %24, i64 0
  %30 = shufflevector <4 x double> %29, <4 x double> poison, <4 x i32> zeroinitializer
  %31 = fmul <4 x double> %28, %30
  %32 = fadd <4 x double> %15, %31
  store <4 x double> %32, ptr %11, align 8
  %33 = or disjoint i64 %14, 1
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %33
  %34 = load double, ptr %gep.i.i.1, align 8
  %35 = getelementptr double, ptr %gep.i.i.1, i64 64
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %gep.i.i.1, i64 128
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %gep.i.i.1, i64 192
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %.unpack17.i, i64 %33
  %42 = load double, ptr %41, align 8
  %43 = insertelement <4 x double> poison, double %34, i64 0
  %44 = insertelement <4 x double> %43, double %36, i64 1
  %45 = insertelement <4 x double> %44, double %38, i64 2
  %46 = insertelement <4 x double> %45, double %40, i64 3
  %47 = insertelement <4 x double> poison, double %42, i64 0
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = fmul <4 x double> %46, %48
  %50 = fadd <4 x double> %32, %49
  store <4 x double> %50, ptr %11, align 8
  %51 = add nuw nsw i64 %14, 2
  %exitcond.not.i.i.1 = icmp eq i64 %51, 64
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %13

.preheader.1.i.i:                                 ; preds = %13
  %52 = or disjoint i64 %12, 256
  %53 = getelementptr double, ptr %11, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %53, align 8
  %invariant.gep11.i.i = getelementptr double, ptr %.unpack2.i, i64 %52
  br label %54

54:                                               ; preds = %54, %.preheader.1.i.i
  %55 = phi i64 [ 0, %.preheader.1.i.i ], [ %92, %54 ]
  %56 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %91, %54 ]
  %gep12.i.i = getelementptr double, ptr %invariant.gep11.i.i, i64 %55
  %57 = load double, ptr %gep12.i.i, align 8
  %58 = getelementptr double, ptr %gep12.i.i, i64 64
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %gep12.i.i, i64 128
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %gep12.i.i, i64 192
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %.unpack17.i, i64 %55
  %65 = load double, ptr %64, align 8
  %66 = insertelement <4 x double> poison, double %57, i64 0
  %67 = insertelement <4 x double> %66, double %59, i64 1
  %68 = insertelement <4 x double> %67, double %61, i64 2
  %69 = insertelement <4 x double> %68, double %63, i64 3
  %70 = insertelement <4 x double> poison, double %65, i64 0
  %71 = shufflevector <4 x double> %70, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = fmul <4 x double> %69, %71
  %73 = fadd <4 x double> %56, %72
  store <4 x double> %73, ptr %53, align 8
  %74 = or disjoint i64 %55, 1
  %gep12.i.i.1 = getelementptr double, ptr %invariant.gep11.i.i, i64 %74
  %75 = load double, ptr %gep12.i.i.1, align 8
  %76 = getelementptr double, ptr %gep12.i.i.1, i64 64
  %77 = load double, ptr %76, align 8
  %78 = getelementptr double, ptr %gep12.i.i.1, i64 128
  %79 = load double, ptr %78, align 8
  %80 = getelementptr double, ptr %gep12.i.i.1, i64 192
  %81 = load double, ptr %80, align 8
  %82 = getelementptr double, ptr %.unpack17.i, i64 %74
  %83 = load double, ptr %82, align 8
  %84 = insertelement <4 x double> poison, double %75, i64 0
  %85 = insertelement <4 x double> %84, double %77, i64 1
  %86 = insertelement <4 x double> %85, double %79, i64 2
  %87 = insertelement <4 x double> %86, double %81, i64 3
  %88 = insertelement <4 x double> poison, double %83, i64 0
  %89 = shufflevector <4 x double> %88, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = fmul <4 x double> %87, %89
  %91 = fadd <4 x double> %73, %90
  store <4 x double> %91, ptr %53, align 8
  %92 = add nuw nsw i64 %55, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %92, 64
  br i1 %exitcond.1.not.i.i.1, label %.preheader.2.i.i, label %54

.preheader.2.i.i:                                 ; preds = %54
  %93 = or disjoint i64 %12, 512
  %94 = getelementptr double, ptr %11, i64 8
  %.promoted.2.i.i = load <4 x double>, ptr %94, align 8
  %invariant.gep13.i.i = getelementptr double, ptr %.unpack2.i, i64 %93
  br label %95

95:                                               ; preds = %95, %.preheader.2.i.i
  %96 = phi i64 [ 0, %.preheader.2.i.i ], [ %133, %95 ]
  %97 = phi <4 x double> [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %132, %95 ]
  %gep14.i.i = getelementptr double, ptr %invariant.gep13.i.i, i64 %96
  %98 = load double, ptr %gep14.i.i, align 8
  %99 = getelementptr double, ptr %gep14.i.i, i64 64
  %100 = load double, ptr %99, align 8
  %101 = getelementptr double, ptr %gep14.i.i, i64 128
  %102 = load double, ptr %101, align 8
  %103 = getelementptr double, ptr %gep14.i.i, i64 192
  %104 = load double, ptr %103, align 8
  %105 = getelementptr double, ptr %.unpack17.i, i64 %96
  %106 = load double, ptr %105, align 8
  %107 = insertelement <4 x double> poison, double %98, i64 0
  %108 = insertelement <4 x double> %107, double %100, i64 1
  %109 = insertelement <4 x double> %108, double %102, i64 2
  %110 = insertelement <4 x double> %109, double %104, i64 3
  %111 = insertelement <4 x double> poison, double %106, i64 0
  %112 = shufflevector <4 x double> %111, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = fmul <4 x double> %110, %112
  %114 = fadd <4 x double> %97, %113
  store <4 x double> %114, ptr %94, align 8
  %115 = or disjoint i64 %96, 1
  %gep14.i.i.1 = getelementptr double, ptr %invariant.gep13.i.i, i64 %115
  %116 = load double, ptr %gep14.i.i.1, align 8
  %117 = getelementptr double, ptr %gep14.i.i.1, i64 64
  %118 = load double, ptr %117, align 8
  %119 = getelementptr double, ptr %gep14.i.i.1, i64 128
  %120 = load double, ptr %119, align 8
  %121 = getelementptr double, ptr %gep14.i.i.1, i64 192
  %122 = load double, ptr %121, align 8
  %123 = getelementptr double, ptr %.unpack17.i, i64 %115
  %124 = load double, ptr %123, align 8
  %125 = insertelement <4 x double> poison, double %116, i64 0
  %126 = insertelement <4 x double> %125, double %118, i64 1
  %127 = insertelement <4 x double> %126, double %120, i64 2
  %128 = insertelement <4 x double> %127, double %122, i64 3
  %129 = insertelement <4 x double> poison, double %124, i64 0
  %130 = shufflevector <4 x double> %129, <4 x double> poison, <4 x i32> zeroinitializer
  %131 = fmul <4 x double> %128, %130
  %132 = fadd <4 x double> %114, %131
  store <4 x double> %132, ptr %94, align 8
  %133 = add nuw nsw i64 %96, 2
  %exitcond.2.not.i.i.1 = icmp eq i64 %133, 64
  br i1 %exitcond.2.not.i.i.1, label %.preheader.3.i.i, label %95

.preheader.3.i.i:                                 ; preds = %95
  %134 = or disjoint i64 %12, 768
  %135 = getelementptr double, ptr %11, i64 12
  %.promoted.3.i.i = load <4 x double>, ptr %135, align 8
  %invariant.gep15.i.i = getelementptr double, ptr %.unpack2.i, i64 %134
  br label %136

136:                                              ; preds = %136, %.preheader.3.i.i
  %137 = phi i64 [ 0, %.preheader.3.i.i ], [ %174, %136 ]
  %138 = phi <4 x double> [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %173, %136 ]
  %gep16.i.i = getelementptr double, ptr %invariant.gep15.i.i, i64 %137
  %139 = load double, ptr %gep16.i.i, align 8
  %140 = getelementptr double, ptr %gep16.i.i, i64 64
  %141 = load double, ptr %140, align 8
  %142 = getelementptr double, ptr %gep16.i.i, i64 128
  %143 = load double, ptr %142, align 8
  %144 = getelementptr double, ptr %gep16.i.i, i64 192
  %145 = load double, ptr %144, align 8
  %146 = getelementptr double, ptr %.unpack17.i, i64 %137
  %147 = load double, ptr %146, align 8
  %148 = insertelement <4 x double> poison, double %139, i64 0
  %149 = insertelement <4 x double> %148, double %141, i64 1
  %150 = insertelement <4 x double> %149, double %143, i64 2
  %151 = insertelement <4 x double> %150, double %145, i64 3
  %152 = insertelement <4 x double> poison, double %147, i64 0
  %153 = shufflevector <4 x double> %152, <4 x double> poison, <4 x i32> zeroinitializer
  %154 = fmul <4 x double> %151, %153
  %155 = fadd <4 x double> %138, %154
  store <4 x double> %155, ptr %135, align 8
  %156 = or disjoint i64 %137, 1
  %gep16.i.i.1 = getelementptr double, ptr %invariant.gep15.i.i, i64 %156
  %157 = load double, ptr %gep16.i.i.1, align 8
  %158 = getelementptr double, ptr %gep16.i.i.1, i64 64
  %159 = load double, ptr %158, align 8
  %160 = getelementptr double, ptr %gep16.i.i.1, i64 128
  %161 = load double, ptr %160, align 8
  %162 = getelementptr double, ptr %gep16.i.i.1, i64 192
  %163 = load double, ptr %162, align 8
  %164 = getelementptr double, ptr %.unpack17.i, i64 %156
  %165 = load double, ptr %164, align 8
  %166 = insertelement <4 x double> poison, double %157, i64 0
  %167 = insertelement <4 x double> %166, double %159, i64 1
  %168 = insertelement <4 x double> %167, double %161, i64 2
  %169 = insertelement <4 x double> %168, double %163, i64 3
  %170 = insertelement <4 x double> poison, double %165, i64 0
  %171 = shufflevector <4 x double> %170, <4 x double> poison, <4 x i32> zeroinitializer
  %172 = fmul <4 x double> %169, %171
  %173 = fadd <4 x double> %155, %172
  store <4 x double> %173, ptr %135, align 8
  %174 = add nuw nsw i64 %137, 2
  %exitcond.3.not.i.i.1 = icmp eq i64 %174, 64
  br i1 %exitcond.3.not.i.i.1, label %175, label %136

175:                                              ; preds = %136
  %176 = add nuw nsw i64 %10, 16
  %177 = icmp ult i64 %10, 240
  br i1 %177, label %.preheader10.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %175
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
