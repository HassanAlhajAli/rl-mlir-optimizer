; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %21 = getelementptr double, ptr %15, i64 8
  %invariant.gep41 = getelementptr double, ptr %8, i64 8
  %22 = getelementptr double, ptr %15, i64 16
  %invariant.gep33 = getelementptr double, ptr %8, i64 16
  %23 = getelementptr double, ptr %15, i64 24
  %invariant.gep25 = getelementptr double, ptr %8, i64 24
  %invariant.gep45 = getelementptr double, ptr %8, i64 12
  %invariant.gep37 = getelementptr double, ptr %8, i64 20
  %invariant.gep29 = getelementptr double, ptr %8, i64 28
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %389
  %24 = phi i64 [ %390, %389 ], [ 0, %.preheader17.preheader ]
  %25 = shl nuw nsw i64 %24, 5
  %26 = getelementptr double, ptr %15, i64 %25
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17, %117
  %27 = phi i64 [ 0, %.preheader17 ], [ %118, %117 ]
  %28 = add nuw nsw i64 %27, %24
  %29 = shl i64 %28, 6
  %30 = shl i64 %27, 5
  %31 = getelementptr double, ptr %26, i64 %30
  %.promoted = load <4 x double>, ptr %31, align 8
  %invariant.gep49 = getelementptr double, ptr %1, i64 %29
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %32 = phi i64 [ 0, %.preheader16 ], [ %73, %.critedge ]
  %33 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %72, %.critedge ]
  %34 = shl nuw nsw i64 %32, 5
  %gep50 = getelementptr double, ptr %invariant.gep49, i64 %32
  %35 = load double, ptr %gep50, align 8
  %36 = insertelement <1 x double> poison, double %35, i64 0
  %37 = getelementptr double, ptr %8, i64 %34
  %38 = load <4 x double>, ptr %37, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %36, %39
  %44 = fmul <1 x double> %36, %40
  %45 = fmul <1 x double> %36, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %36, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %33, %51
  store <4 x double> %52, ptr %31, align 8
  %53 = or disjoint i64 %32, 1
  %54 = shl nuw nsw i64 %53, 5
  %gep50.1 = getelementptr double, ptr %invariant.gep49, i64 %53
  %55 = load double, ptr %gep50.1, align 8
  %56 = insertelement <1 x double> poison, double %55, i64 0
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load <4 x double>, ptr %57, align 8
  %59 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> zeroinitializer
  %60 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 1>
  %61 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 2>
  %62 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 3>
  %63 = fmul <1 x double> %56, %59
  %64 = fmul <1 x double> %56, %60
  %65 = fmul <1 x double> %56, %61
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = fmul <1 x double> %56, %62
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %63, <1 x double> %64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %72 = fadd <4 x double> %52, %71
  store <4 x double> %72, ptr %31, align 8
  %73 = add nuw nsw i64 %32, 2
  %exitcond.not.1 = icmp eq i64 %73, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %74 = getelementptr double, ptr %31, i64 4
  %.promoted.1 = load <4 x double>, ptr %74, align 8
  %invariant.gep47 = getelementptr double, ptr %1, i64 %29
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %75 = phi i64 [ 0, %.preheader.1 ], [ %116, %.critedge.1 ]
  %76 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %115, %.critedge.1 ]
  %77 = shl nuw nsw i64 %75, 5
  %gep48 = getelementptr double, ptr %invariant.gep47, i64 %75
  %78 = load double, ptr %gep48, align 8
  %79 = insertelement <1 x double> poison, double %78, i64 0
  %80 = getelementptr double, ptr %invariant.gep.1, i64 %77
  %81 = load <4 x double>, ptr %80, align 8
  %82 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %81, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %79, %82
  %87 = fmul <1 x double> %79, %83
  %88 = fmul <1 x double> %79, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %79, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %74, align 8
  %96 = or disjoint i64 %75, 1
  %97 = shl nuw nsw i64 %96, 5
  %gep48.1 = getelementptr double, ptr %invariant.gep47, i64 %96
  %98 = load double, ptr %gep48.1, align 8
  %99 = insertelement <1 x double> poison, double %98, i64 0
  %100 = getelementptr double, ptr %invariant.gep.1, i64 %97
  %101 = load <4 x double>, ptr %100, align 8
  %102 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> zeroinitializer
  %103 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 1>
  %104 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 2>
  %105 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 3>
  %106 = fmul <1 x double> %99, %102
  %107 = fmul <1 x double> %99, %103
  %108 = fmul <1 x double> %99, %104
  %109 = shufflevector <1 x double> %108, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %110 = fmul <1 x double> %99, %105
  %111 = shufflevector <1 x double> %110, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %112 = shufflevector <1 x double> %106, <1 x double> %107, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %109, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %111, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %115 = fadd <4 x double> %95, %114
  store <4 x double> %115, ptr %74, align 8
  %116 = add nuw nsw i64 %75, 2
  %exitcond.1.not.1 = icmp eq i64 %116, 64
  br i1 %exitcond.1.not.1, label %117, label %.critedge.1

117:                                              ; preds = %.critedge.1
  %118 = add nuw nsw i64 %27, 1
  %exitcond19.not = icmp eq i64 %118, 8
  br i1 %exitcond19.not, label %119, label %.preheader16

119:                                              ; preds = %117
  %120 = getelementptr double, ptr %21, i64 %25
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %207, %119
  %121 = phi i64 [ 0, %119 ], [ %208, %207 ]
  %122 = add nuw nsw i64 %121, %24
  %123 = shl i64 %122, 6
  %124 = shl i64 %121, 5
  %125 = getelementptr double, ptr %120, i64 %124
  %.promoted.120 = load <4 x double>, ptr %125, align 8
  %invariant.gep39 = getelementptr double, ptr %1, i64 %123
  br label %.critedge.124

.critedge.124:                                    ; preds = %.critedge.124, %.preheader16.1
  %126 = phi i64 [ 0, %.preheader16.1 ], [ %165, %.critedge.124 ]
  %127 = phi <4 x double> [ %.promoted.120, %.preheader16.1 ], [ %164, %.critedge.124 ]
  %128 = shl nuw nsw i64 %126, 5
  %gep40 = getelementptr double, ptr %invariant.gep39, i64 %126
  %129 = load double, ptr %gep40, align 8
  %130 = insertelement <1 x double> poison, double %129, i64 0
  %gep42 = getelementptr double, ptr %invariant.gep41, i64 %128
  %131 = load <4 x double>, ptr %gep42, align 8
  %132 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> zeroinitializer
  %133 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 1>
  %134 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 2>
  %135 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 3>
  %136 = fmul <1 x double> %130, %132
  %137 = fmul <1 x double> %130, %133
  %138 = fmul <1 x double> %130, %134
  %139 = shufflevector <1 x double> %138, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %140 = fmul <1 x double> %130, %135
  %141 = shufflevector <1 x double> %140, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %142 = shufflevector <1 x double> %136, <1 x double> %137, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %143 = shufflevector <4 x double> %142, <4 x double> %139, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %144 = shufflevector <4 x double> %143, <4 x double> %141, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %145 = fadd <4 x double> %127, %144
  store <4 x double> %145, ptr %125, align 8
  %146 = or disjoint i64 %126, 1
  %147 = shl nuw nsw i64 %146, 5
  %gep40.1 = getelementptr double, ptr %invariant.gep39, i64 %146
  %148 = load double, ptr %gep40.1, align 8
  %149 = insertelement <1 x double> poison, double %148, i64 0
  %gep42.1 = getelementptr double, ptr %invariant.gep41, i64 %147
  %150 = load <4 x double>, ptr %gep42.1, align 8
  %151 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> zeroinitializer
  %152 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 1>
  %153 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 2>
  %154 = shufflevector <4 x double> %150, <4 x double> poison, <1 x i32> <i32 3>
  %155 = fmul <1 x double> %149, %151
  %156 = fmul <1 x double> %149, %152
  %157 = fmul <1 x double> %149, %153
  %158 = shufflevector <1 x double> %157, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %159 = fmul <1 x double> %149, %154
  %160 = shufflevector <1 x double> %159, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %161 = shufflevector <1 x double> %155, <1 x double> %156, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %162 = shufflevector <4 x double> %161, <4 x double> %158, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %163 = shufflevector <4 x double> %162, <4 x double> %160, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %164 = fadd <4 x double> %145, %163
  store <4 x double> %164, ptr %125, align 8
  %165 = add nuw nsw i64 %126, 2
  %exitcond.123.not.1 = icmp eq i64 %165, 64
  br i1 %exitcond.123.not.1, label %.preheader.1.1, label %.critedge.124

.preheader.1.1:                                   ; preds = %.critedge.124
  %166 = getelementptr double, ptr %125, i64 4
  %.promoted.1.1 = load <4 x double>, ptr %166, align 8
  %invariant.gep43 = getelementptr double, ptr %1, i64 %123
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1, %.preheader.1.1
  %167 = phi i64 [ 0, %.preheader.1.1 ], [ %206, %.critedge.1.1 ]
  %168 = phi <4 x double> [ %.promoted.1.1, %.preheader.1.1 ], [ %205, %.critedge.1.1 ]
  %169 = shl nuw nsw i64 %167, 5
  %gep44 = getelementptr double, ptr %invariant.gep43, i64 %167
  %170 = load double, ptr %gep44, align 8
  %171 = insertelement <1 x double> poison, double %170, i64 0
  %gep46 = getelementptr double, ptr %invariant.gep45, i64 %169
  %172 = load <4 x double>, ptr %gep46, align 8
  %173 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> zeroinitializer
  %174 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 1>
  %175 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 2>
  %176 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 3>
  %177 = fmul <1 x double> %171, %173
  %178 = fmul <1 x double> %171, %174
  %179 = fmul <1 x double> %171, %175
  %180 = shufflevector <1 x double> %179, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %181 = fmul <1 x double> %171, %176
  %182 = shufflevector <1 x double> %181, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %183 = shufflevector <1 x double> %177, <1 x double> %178, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %184 = shufflevector <4 x double> %183, <4 x double> %180, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %185 = shufflevector <4 x double> %184, <4 x double> %182, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %186 = fadd <4 x double> %168, %185
  store <4 x double> %186, ptr %166, align 8
  %187 = or disjoint i64 %167, 1
  %188 = shl nuw nsw i64 %187, 5
  %gep44.1 = getelementptr double, ptr %invariant.gep43, i64 %187
  %189 = load double, ptr %gep44.1, align 8
  %190 = insertelement <1 x double> poison, double %189, i64 0
  %gep46.1 = getelementptr double, ptr %invariant.gep45, i64 %188
  %191 = load <4 x double>, ptr %gep46.1, align 8
  %192 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> zeroinitializer
  %193 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 1>
  %194 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 2>
  %195 = shufflevector <4 x double> %191, <4 x double> poison, <1 x i32> <i32 3>
  %196 = fmul <1 x double> %190, %192
  %197 = fmul <1 x double> %190, %193
  %198 = fmul <1 x double> %190, %194
  %199 = shufflevector <1 x double> %198, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %200 = fmul <1 x double> %190, %195
  %201 = shufflevector <1 x double> %200, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %202 = shufflevector <1 x double> %196, <1 x double> %197, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %203 = shufflevector <4 x double> %202, <4 x double> %199, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %204 = shufflevector <4 x double> %203, <4 x double> %201, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %205 = fadd <4 x double> %186, %204
  store <4 x double> %205, ptr %166, align 8
  %206 = add nuw nsw i64 %167, 2
  %exitcond.1.1.not.1 = icmp eq i64 %206, 64
  br i1 %exitcond.1.1.not.1, label %207, label %.critedge.1.1

207:                                              ; preds = %.critedge.1.1
  %208 = add nuw nsw i64 %121, 1
  %exitcond19.1.not = icmp eq i64 %208, 8
  br i1 %exitcond19.1.not, label %209, label %.preheader16.1

209:                                              ; preds = %207
  %210 = getelementptr double, ptr %22, i64 %25
  br label %.preheader16.2

.preheader16.2:                                   ; preds = %297, %209
  %211 = phi i64 [ 0, %209 ], [ %298, %297 ]
  %212 = add nuw nsw i64 %211, %24
  %213 = shl i64 %212, 6
  %214 = shl i64 %211, 5
  %215 = getelementptr double, ptr %210, i64 %214
  %.promoted.2 = load <4 x double>, ptr %215, align 8
  %invariant.gep31 = getelementptr double, ptr %1, i64 %213
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader16.2
  %216 = phi i64 [ 0, %.preheader16.2 ], [ %255, %.critedge.2 ]
  %217 = phi <4 x double> [ %.promoted.2, %.preheader16.2 ], [ %254, %.critedge.2 ]
  %218 = shl nuw nsw i64 %216, 5
  %gep32 = getelementptr double, ptr %invariant.gep31, i64 %216
  %219 = load double, ptr %gep32, align 8
  %220 = insertelement <1 x double> poison, double %219, i64 0
  %gep34 = getelementptr double, ptr %invariant.gep33, i64 %218
  %221 = load <4 x double>, ptr %gep34, align 8
  %222 = shufflevector <4 x double> %221, <4 x double> poison, <1 x i32> zeroinitializer
  %223 = shufflevector <4 x double> %221, <4 x double> poison, <1 x i32> <i32 1>
  %224 = shufflevector <4 x double> %221, <4 x double> poison, <1 x i32> <i32 2>
  %225 = shufflevector <4 x double> %221, <4 x double> poison, <1 x i32> <i32 3>
  %226 = fmul <1 x double> %220, %222
  %227 = fmul <1 x double> %220, %223
  %228 = fmul <1 x double> %220, %224
  %229 = shufflevector <1 x double> %228, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %230 = fmul <1 x double> %220, %225
  %231 = shufflevector <1 x double> %230, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %232 = shufflevector <1 x double> %226, <1 x double> %227, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %233 = shufflevector <4 x double> %232, <4 x double> %229, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %234 = shufflevector <4 x double> %233, <4 x double> %231, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %235 = fadd <4 x double> %217, %234
  store <4 x double> %235, ptr %215, align 8
  %236 = or disjoint i64 %216, 1
  %237 = shl nuw nsw i64 %236, 5
  %gep32.1 = getelementptr double, ptr %invariant.gep31, i64 %236
  %238 = load double, ptr %gep32.1, align 8
  %239 = insertelement <1 x double> poison, double %238, i64 0
  %gep34.1 = getelementptr double, ptr %invariant.gep33, i64 %237
  %240 = load <4 x double>, ptr %gep34.1, align 8
  %241 = shufflevector <4 x double> %240, <4 x double> poison, <1 x i32> zeroinitializer
  %242 = shufflevector <4 x double> %240, <4 x double> poison, <1 x i32> <i32 1>
  %243 = shufflevector <4 x double> %240, <4 x double> poison, <1 x i32> <i32 2>
  %244 = shufflevector <4 x double> %240, <4 x double> poison, <1 x i32> <i32 3>
  %245 = fmul <1 x double> %239, %241
  %246 = fmul <1 x double> %239, %242
  %247 = fmul <1 x double> %239, %243
  %248 = shufflevector <1 x double> %247, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %249 = fmul <1 x double> %239, %244
  %250 = shufflevector <1 x double> %249, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %251 = shufflevector <1 x double> %245, <1 x double> %246, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %252 = shufflevector <4 x double> %251, <4 x double> %248, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %253 = shufflevector <4 x double> %252, <4 x double> %250, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %254 = fadd <4 x double> %235, %253
  store <4 x double> %254, ptr %215, align 8
  %255 = add nuw nsw i64 %216, 2
  %exitcond.2.not.1 = icmp eq i64 %255, 64
  br i1 %exitcond.2.not.1, label %.preheader.1.2, label %.critedge.2

.preheader.1.2:                                   ; preds = %.critedge.2
  %256 = getelementptr double, ptr %215, i64 4
  %.promoted.1.2 = load <4 x double>, ptr %256, align 8
  %invariant.gep35 = getelementptr double, ptr %1, i64 %213
  br label %.critedge.1.2

.critedge.1.2:                                    ; preds = %.critedge.1.2, %.preheader.1.2
  %257 = phi i64 [ 0, %.preheader.1.2 ], [ %296, %.critedge.1.2 ]
  %258 = phi <4 x double> [ %.promoted.1.2, %.preheader.1.2 ], [ %295, %.critedge.1.2 ]
  %259 = shl nuw nsw i64 %257, 5
  %gep36 = getelementptr double, ptr %invariant.gep35, i64 %257
  %260 = load double, ptr %gep36, align 8
  %261 = insertelement <1 x double> poison, double %260, i64 0
  %gep38 = getelementptr double, ptr %invariant.gep37, i64 %259
  %262 = load <4 x double>, ptr %gep38, align 8
  %263 = shufflevector <4 x double> %262, <4 x double> poison, <1 x i32> zeroinitializer
  %264 = shufflevector <4 x double> %262, <4 x double> poison, <1 x i32> <i32 1>
  %265 = shufflevector <4 x double> %262, <4 x double> poison, <1 x i32> <i32 2>
  %266 = shufflevector <4 x double> %262, <4 x double> poison, <1 x i32> <i32 3>
  %267 = fmul <1 x double> %261, %263
  %268 = fmul <1 x double> %261, %264
  %269 = fmul <1 x double> %261, %265
  %270 = shufflevector <1 x double> %269, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %271 = fmul <1 x double> %261, %266
  %272 = shufflevector <1 x double> %271, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %273 = shufflevector <1 x double> %267, <1 x double> %268, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %274 = shufflevector <4 x double> %273, <4 x double> %270, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %275 = shufflevector <4 x double> %274, <4 x double> %272, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %276 = fadd <4 x double> %258, %275
  store <4 x double> %276, ptr %256, align 8
  %277 = or disjoint i64 %257, 1
  %278 = shl nuw nsw i64 %277, 5
  %gep36.1 = getelementptr double, ptr %invariant.gep35, i64 %277
  %279 = load double, ptr %gep36.1, align 8
  %280 = insertelement <1 x double> poison, double %279, i64 0
  %gep38.1 = getelementptr double, ptr %invariant.gep37, i64 %278
  %281 = load <4 x double>, ptr %gep38.1, align 8
  %282 = shufflevector <4 x double> %281, <4 x double> poison, <1 x i32> zeroinitializer
  %283 = shufflevector <4 x double> %281, <4 x double> poison, <1 x i32> <i32 1>
  %284 = shufflevector <4 x double> %281, <4 x double> poison, <1 x i32> <i32 2>
  %285 = shufflevector <4 x double> %281, <4 x double> poison, <1 x i32> <i32 3>
  %286 = fmul <1 x double> %280, %282
  %287 = fmul <1 x double> %280, %283
  %288 = fmul <1 x double> %280, %284
  %289 = shufflevector <1 x double> %288, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %290 = fmul <1 x double> %280, %285
  %291 = shufflevector <1 x double> %290, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %292 = shufflevector <1 x double> %286, <1 x double> %287, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %293 = shufflevector <4 x double> %292, <4 x double> %289, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %294 = shufflevector <4 x double> %293, <4 x double> %291, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %295 = fadd <4 x double> %276, %294
  store <4 x double> %295, ptr %256, align 8
  %296 = add nuw nsw i64 %257, 2
  %exitcond.1.2.not.1 = icmp eq i64 %296, 64
  br i1 %exitcond.1.2.not.1, label %297, label %.critedge.1.2

297:                                              ; preds = %.critedge.1.2
  %298 = add nuw nsw i64 %211, 1
  %exitcond19.2.not = icmp eq i64 %298, 8
  br i1 %exitcond19.2.not, label %299, label %.preheader16.2

299:                                              ; preds = %297
  %300 = getelementptr double, ptr %23, i64 %25
  br label %.preheader16.3

.preheader16.3:                                   ; preds = %387, %299
  %301 = phi i64 [ 0, %299 ], [ %388, %387 ]
  %302 = add nuw nsw i64 %301, %24
  %303 = shl i64 %302, 6
  %304 = shl i64 %301, 5
  %305 = getelementptr double, ptr %300, i64 %304
  %.promoted.3 = load <4 x double>, ptr %305, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %303
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader16.3
  %306 = phi i64 [ 0, %.preheader16.3 ], [ %345, %.critedge.3 ]
  %307 = phi <4 x double> [ %.promoted.3, %.preheader16.3 ], [ %344, %.critedge.3 ]
  %308 = shl nuw nsw i64 %306, 5
  %gep = getelementptr double, ptr %invariant.gep, i64 %306
  %309 = load double, ptr %gep, align 8
  %310 = insertelement <1 x double> poison, double %309, i64 0
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %308
  %311 = load <4 x double>, ptr %gep26, align 8
  %312 = shufflevector <4 x double> %311, <4 x double> poison, <1 x i32> zeroinitializer
  %313 = shufflevector <4 x double> %311, <4 x double> poison, <1 x i32> <i32 1>
  %314 = shufflevector <4 x double> %311, <4 x double> poison, <1 x i32> <i32 2>
  %315 = shufflevector <4 x double> %311, <4 x double> poison, <1 x i32> <i32 3>
  %316 = fmul <1 x double> %310, %312
  %317 = fmul <1 x double> %310, %313
  %318 = fmul <1 x double> %310, %314
  %319 = shufflevector <1 x double> %318, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %320 = fmul <1 x double> %310, %315
  %321 = shufflevector <1 x double> %320, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %322 = shufflevector <1 x double> %316, <1 x double> %317, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %323 = shufflevector <4 x double> %322, <4 x double> %319, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %324 = shufflevector <4 x double> %323, <4 x double> %321, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %325 = fadd <4 x double> %307, %324
  store <4 x double> %325, ptr %305, align 8
  %326 = or disjoint i64 %306, 1
  %327 = shl nuw nsw i64 %326, 5
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %326
  %328 = load double, ptr %gep.1, align 8
  %329 = insertelement <1 x double> poison, double %328, i64 0
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %327
  %330 = load <4 x double>, ptr %gep26.1, align 8
  %331 = shufflevector <4 x double> %330, <4 x double> poison, <1 x i32> zeroinitializer
  %332 = shufflevector <4 x double> %330, <4 x double> poison, <1 x i32> <i32 1>
  %333 = shufflevector <4 x double> %330, <4 x double> poison, <1 x i32> <i32 2>
  %334 = shufflevector <4 x double> %330, <4 x double> poison, <1 x i32> <i32 3>
  %335 = fmul <1 x double> %329, %331
  %336 = fmul <1 x double> %329, %332
  %337 = fmul <1 x double> %329, %333
  %338 = shufflevector <1 x double> %337, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %339 = fmul <1 x double> %329, %334
  %340 = shufflevector <1 x double> %339, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %341 = shufflevector <1 x double> %335, <1 x double> %336, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %342 = shufflevector <4 x double> %341, <4 x double> %338, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %343 = shufflevector <4 x double> %342, <4 x double> %340, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %344 = fadd <4 x double> %325, %343
  store <4 x double> %344, ptr %305, align 8
  %345 = add nuw nsw i64 %306, 2
  %exitcond.3.not.1 = icmp eq i64 %345, 64
  br i1 %exitcond.3.not.1, label %.preheader.1.3, label %.critedge.3

.preheader.1.3:                                   ; preds = %.critedge.3
  %346 = getelementptr double, ptr %305, i64 4
  %.promoted.1.3 = load <4 x double>, ptr %346, align 8
  %invariant.gep27 = getelementptr double, ptr %1, i64 %303
  br label %.critedge.1.3

.critedge.1.3:                                    ; preds = %.critedge.1.3, %.preheader.1.3
  %347 = phi i64 [ 0, %.preheader.1.3 ], [ %386, %.critedge.1.3 ]
  %348 = phi <4 x double> [ %.promoted.1.3, %.preheader.1.3 ], [ %385, %.critedge.1.3 ]
  %349 = shl nuw nsw i64 %347, 5
  %gep28 = getelementptr double, ptr %invariant.gep27, i64 %347
  %350 = load double, ptr %gep28, align 8
  %351 = insertelement <1 x double> poison, double %350, i64 0
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %349
  %352 = load <4 x double>, ptr %gep30, align 8
  %353 = shufflevector <4 x double> %352, <4 x double> poison, <1 x i32> zeroinitializer
  %354 = shufflevector <4 x double> %352, <4 x double> poison, <1 x i32> <i32 1>
  %355 = shufflevector <4 x double> %352, <4 x double> poison, <1 x i32> <i32 2>
  %356 = shufflevector <4 x double> %352, <4 x double> poison, <1 x i32> <i32 3>
  %357 = fmul <1 x double> %351, %353
  %358 = fmul <1 x double> %351, %354
  %359 = fmul <1 x double> %351, %355
  %360 = shufflevector <1 x double> %359, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %361 = fmul <1 x double> %351, %356
  %362 = shufflevector <1 x double> %361, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %363 = shufflevector <1 x double> %357, <1 x double> %358, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %364 = shufflevector <4 x double> %363, <4 x double> %360, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %365 = shufflevector <4 x double> %364, <4 x double> %362, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %366 = fadd <4 x double> %348, %365
  store <4 x double> %366, ptr %346, align 8
  %367 = or disjoint i64 %347, 1
  %368 = shl nuw nsw i64 %367, 5
  %gep28.1 = getelementptr double, ptr %invariant.gep27, i64 %367
  %369 = load double, ptr %gep28.1, align 8
  %370 = insertelement <1 x double> poison, double %369, i64 0
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %368
  %371 = load <4 x double>, ptr %gep30.1, align 8
  %372 = shufflevector <4 x double> %371, <4 x double> poison, <1 x i32> zeroinitializer
  %373 = shufflevector <4 x double> %371, <4 x double> poison, <1 x i32> <i32 1>
  %374 = shufflevector <4 x double> %371, <4 x double> poison, <1 x i32> <i32 2>
  %375 = shufflevector <4 x double> %371, <4 x double> poison, <1 x i32> <i32 3>
  %376 = fmul <1 x double> %370, %372
  %377 = fmul <1 x double> %370, %373
  %378 = fmul <1 x double> %370, %374
  %379 = shufflevector <1 x double> %378, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %380 = fmul <1 x double> %370, %375
  %381 = shufflevector <1 x double> %380, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %382 = shufflevector <1 x double> %376, <1 x double> %377, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %383 = shufflevector <4 x double> %382, <4 x double> %379, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %384 = shufflevector <4 x double> %383, <4 x double> %381, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %385 = fadd <4 x double> %366, %384
  store <4 x double> %385, ptr %346, align 8
  %386 = add nuw nsw i64 %347, 2
  %exitcond.1.3.not.1 = icmp eq i64 %386, 64
  br i1 %exitcond.1.3.not.1, label %387, label %.critedge.1.3

387:                                              ; preds = %.critedge.1.3
  %388 = add nuw nsw i64 %301, 1
  %exitcond19.3.not = icmp eq i64 %388, 8
  br i1 %exitcond19.3.not, label %389, label %.preheader16.3

389:                                              ; preds = %387
  %390 = add nuw nsw i64 %24, 8
  %391 = icmp ult i64 %24, 120
  br i1 %391, label %.preheader17, label %392

392:                                              ; preds = %389
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
