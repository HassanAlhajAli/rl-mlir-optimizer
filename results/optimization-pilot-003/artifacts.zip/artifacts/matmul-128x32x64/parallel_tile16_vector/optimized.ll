; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  %21 = getelementptr double, ptr %15, i64 16
  %invariant.gep25 = getelementptr double, ptr %8, i64 16
  %invariant.gep29 = getelementptr double, ptr %8, i64 20
  %invariant.gep33 = getelementptr double, ptr %8, i64 24
  %invariant.gep37 = getelementptr double, ptr %8, i64 28
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %375
  %22 = phi i64 [ %376, %375 ], [ 0, %.preheader17.preheader ]
  %23 = shl nuw nsw i64 %22, 5
  %24 = getelementptr double, ptr %15, i64 %23
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17, %201
  %25 = phi i64 [ 0, %.preheader17 ], [ %202, %201 ]
  %26 = add nuw nsw i64 %25, %22
  %27 = shl i64 %26, 6
  %28 = shl i64 %25, 5
  %29 = getelementptr double, ptr %24, i64 %28
  %.promoted = load <4 x double>, ptr %29, align 8
  %invariant.gep45 = getelementptr double, ptr %1, i64 %27
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader16
  %30 = phi i64 [ 0, %.preheader16 ], [ %71, %.critedge ]
  %31 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %70, %.critedge ]
  %32 = shl nuw nsw i64 %30, 5
  %gep46 = getelementptr double, ptr %invariant.gep45, i64 %30
  %33 = load double, ptr %gep46, align 8
  %34 = insertelement <1 x double> poison, double %33, i64 0
  %35 = getelementptr double, ptr %8, i64 %32
  %36 = load <4 x double>, ptr %35, align 8
  %37 = shufflevector <4 x double> %36, <4 x double> poison, <1 x i32> zeroinitializer
  %38 = shufflevector <4 x double> %36, <4 x double> poison, <1 x i32> <i32 1>
  %39 = shufflevector <4 x double> %36, <4 x double> poison, <1 x i32> <i32 2>
  %40 = shufflevector <4 x double> %36, <4 x double> poison, <1 x i32> <i32 3>
  %41 = fmul <1 x double> %34, %37
  %42 = fmul <1 x double> %34, %38
  %43 = fmul <1 x double> %34, %39
  %44 = shufflevector <1 x double> %43, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %45 = fmul <1 x double> %34, %40
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = shufflevector <1 x double> %41, <1 x double> %42, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %44, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %50 = fadd <4 x double> %31, %49
  store <4 x double> %50, ptr %29, align 8
  %51 = or disjoint i64 %30, 1
  %52 = shl nuw nsw i64 %51, 5
  %gep46.1 = getelementptr double, ptr %invariant.gep45, i64 %51
  %53 = load double, ptr %gep46.1, align 8
  %54 = insertelement <1 x double> poison, double %53, i64 0
  %55 = getelementptr double, ptr %8, i64 %52
  %56 = load <4 x double>, ptr %55, align 8
  %57 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> zeroinitializer
  %58 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 1>
  %59 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 2>
  %60 = shufflevector <4 x double> %56, <4 x double> poison, <1 x i32> <i32 3>
  %61 = fmul <1 x double> %54, %57
  %62 = fmul <1 x double> %54, %58
  %63 = fmul <1 x double> %54, %59
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = fmul <1 x double> %54, %60
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = shufflevector <1 x double> %61, <1 x double> %62, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %68 = shufflevector <4 x double> %67, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %69 = shufflevector <4 x double> %68, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %70 = fadd <4 x double> %50, %69
  store <4 x double> %70, ptr %29, align 8
  %71 = add nuw nsw i64 %30, 2
  %exitcond.not.1 = icmp eq i64 %71, 64
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %72 = getelementptr double, ptr %29, i64 4
  %.promoted.1 = load <4 x double>, ptr %72, align 8
  %invariant.gep43 = getelementptr double, ptr %1, i64 %27
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %73 = phi i64 [ 0, %.preheader.1 ], [ %114, %.critedge.1 ]
  %74 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %113, %.critedge.1 ]
  %75 = shl nuw nsw i64 %73, 5
  %gep44 = getelementptr double, ptr %invariant.gep43, i64 %73
  %76 = load double, ptr %gep44, align 8
  %77 = insertelement <1 x double> poison, double %76, i64 0
  %78 = getelementptr double, ptr %invariant.gep.1, i64 %75
  %79 = load <4 x double>, ptr %78, align 8
  %80 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> zeroinitializer
  %81 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 1>
  %82 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 2>
  %83 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 3>
  %84 = fmul <1 x double> %77, %80
  %85 = fmul <1 x double> %77, %81
  %86 = fmul <1 x double> %77, %82
  %87 = shufflevector <1 x double> %86, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %88 = fmul <1 x double> %77, %83
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = shufflevector <1 x double> %84, <1 x double> %85, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %91 = shufflevector <4 x double> %90, <4 x double> %87, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %93 = fadd <4 x double> %74, %92
  store <4 x double> %93, ptr %72, align 8
  %94 = or disjoint i64 %73, 1
  %95 = shl nuw nsw i64 %94, 5
  %gep44.1 = getelementptr double, ptr %invariant.gep43, i64 %94
  %96 = load double, ptr %gep44.1, align 8
  %97 = insertelement <1 x double> poison, double %96, i64 0
  %98 = getelementptr double, ptr %invariant.gep.1, i64 %95
  %99 = load <4 x double>, ptr %98, align 8
  %100 = shufflevector <4 x double> %99, <4 x double> poison, <1 x i32> zeroinitializer
  %101 = shufflevector <4 x double> %99, <4 x double> poison, <1 x i32> <i32 1>
  %102 = shufflevector <4 x double> %99, <4 x double> poison, <1 x i32> <i32 2>
  %103 = shufflevector <4 x double> %99, <4 x double> poison, <1 x i32> <i32 3>
  %104 = fmul <1 x double> %97, %100
  %105 = fmul <1 x double> %97, %101
  %106 = fmul <1 x double> %97, %102
  %107 = shufflevector <1 x double> %106, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %108 = fmul <1 x double> %97, %103
  %109 = shufflevector <1 x double> %108, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %110 = shufflevector <1 x double> %104, <1 x double> %105, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %111 = shufflevector <4 x double> %110, <4 x double> %107, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %112 = shufflevector <4 x double> %111, <4 x double> %109, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %113 = fadd <4 x double> %93, %112
  store <4 x double> %113, ptr %72, align 8
  %114 = add nuw nsw i64 %73, 2
  %exitcond.1.not.1 = icmp eq i64 %114, 64
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %115 = getelementptr double, ptr %29, i64 8
  %.promoted.2 = load <4 x double>, ptr %115, align 8
  %invariant.gep41 = getelementptr double, ptr %1, i64 %27
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %116 = phi i64 [ 0, %.preheader.2 ], [ %157, %.critedge.2 ]
  %117 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %156, %.critedge.2 ]
  %118 = shl nuw nsw i64 %116, 5
  %gep42 = getelementptr double, ptr %invariant.gep41, i64 %116
  %119 = load double, ptr %gep42, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %121 = getelementptr double, ptr %invariant.gep.2, i64 %118
  %122 = load <4 x double>, ptr %121, align 8
  %123 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> zeroinitializer
  %124 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 1>
  %125 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 2>
  %126 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 3>
  %127 = fmul <1 x double> %120, %123
  %128 = fmul <1 x double> %120, %124
  %129 = fmul <1 x double> %120, %125
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = fmul <1 x double> %120, %126
  %132 = shufflevector <1 x double> %131, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %133 = shufflevector <1 x double> %127, <1 x double> %128, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %135 = shufflevector <4 x double> %134, <4 x double> %132, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %136 = fadd <4 x double> %117, %135
  store <4 x double> %136, ptr %115, align 8
  %137 = or disjoint i64 %116, 1
  %138 = shl nuw nsw i64 %137, 5
  %gep42.1 = getelementptr double, ptr %invariant.gep41, i64 %137
  %139 = load double, ptr %gep42.1, align 8
  %140 = insertelement <1 x double> poison, double %139, i64 0
  %141 = getelementptr double, ptr %invariant.gep.2, i64 %138
  %142 = load <4 x double>, ptr %141, align 8
  %143 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> zeroinitializer
  %144 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 1>
  %145 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 2>
  %146 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 3>
  %147 = fmul <1 x double> %140, %143
  %148 = fmul <1 x double> %140, %144
  %149 = fmul <1 x double> %140, %145
  %150 = shufflevector <1 x double> %149, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %151 = fmul <1 x double> %140, %146
  %152 = shufflevector <1 x double> %151, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %153 = shufflevector <1 x double> %147, <1 x double> %148, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %150, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %155 = shufflevector <4 x double> %154, <4 x double> %152, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %156 = fadd <4 x double> %136, %155
  store <4 x double> %156, ptr %115, align 8
  %157 = add nuw nsw i64 %116, 2
  %exitcond.2.not.1 = icmp eq i64 %157, 64
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %158 = getelementptr double, ptr %29, i64 12
  %.promoted.3 = load <4 x double>, ptr %158, align 8
  %invariant.gep39 = getelementptr double, ptr %1, i64 %27
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %159 = phi i64 [ 0, %.preheader.3 ], [ %200, %.critedge.3 ]
  %160 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %199, %.critedge.3 ]
  %161 = shl nuw nsw i64 %159, 5
  %gep40 = getelementptr double, ptr %invariant.gep39, i64 %159
  %162 = load double, ptr %gep40, align 8
  %163 = insertelement <1 x double> poison, double %162, i64 0
  %164 = getelementptr double, ptr %invariant.gep.3, i64 %161
  %165 = load <4 x double>, ptr %164, align 8
  %166 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> zeroinitializer
  %167 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 1>
  %168 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 2>
  %169 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 3>
  %170 = fmul <1 x double> %163, %166
  %171 = fmul <1 x double> %163, %167
  %172 = fmul <1 x double> %163, %168
  %173 = shufflevector <1 x double> %172, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %174 = fmul <1 x double> %163, %169
  %175 = shufflevector <1 x double> %174, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %176 = shufflevector <1 x double> %170, <1 x double> %171, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %177 = shufflevector <4 x double> %176, <4 x double> %173, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %175, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %179 = fadd <4 x double> %160, %178
  store <4 x double> %179, ptr %158, align 8
  %180 = or disjoint i64 %159, 1
  %181 = shl nuw nsw i64 %180, 5
  %gep40.1 = getelementptr double, ptr %invariant.gep39, i64 %180
  %182 = load double, ptr %gep40.1, align 8
  %183 = insertelement <1 x double> poison, double %182, i64 0
  %184 = getelementptr double, ptr %invariant.gep.3, i64 %181
  %185 = load <4 x double>, ptr %184, align 8
  %186 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> zeroinitializer
  %187 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 1>
  %188 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 2>
  %189 = shufflevector <4 x double> %185, <4 x double> poison, <1 x i32> <i32 3>
  %190 = fmul <1 x double> %183, %186
  %191 = fmul <1 x double> %183, %187
  %192 = fmul <1 x double> %183, %188
  %193 = shufflevector <1 x double> %192, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %194 = fmul <1 x double> %183, %189
  %195 = shufflevector <1 x double> %194, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %196 = shufflevector <1 x double> %190, <1 x double> %191, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %197 = shufflevector <4 x double> %196, <4 x double> %193, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %198 = shufflevector <4 x double> %197, <4 x double> %195, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %199 = fadd <4 x double> %179, %198
  store <4 x double> %199, ptr %158, align 8
  %200 = add nuw nsw i64 %159, 2
  %exitcond.3.not.1 = icmp eq i64 %200, 64
  br i1 %exitcond.3.not.1, label %201, label %.critedge.3

201:                                              ; preds = %.critedge.3
  %202 = add nuw nsw i64 %25, 1
  %exitcond19.not = icmp eq i64 %202, 16
  br i1 %exitcond19.not, label %203, label %.preheader16

203:                                              ; preds = %201
  %204 = getelementptr double, ptr %21, i64 %23
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %373, %203
  %205 = phi i64 [ 0, %203 ], [ %374, %373 ]
  %206 = add nuw nsw i64 %205, %22
  %207 = shl i64 %206, 6
  %208 = shl i64 %205, 5
  %209 = getelementptr double, ptr %204, i64 %208
  %.promoted.120 = load <4 x double>, ptr %209, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %207
  br label %.critedge.124

.critedge.124:                                    ; preds = %.critedge.124, %.preheader16.1
  %210 = phi i64 [ 0, %.preheader16.1 ], [ %249, %.critedge.124 ]
  %211 = phi <4 x double> [ %.promoted.120, %.preheader16.1 ], [ %248, %.critedge.124 ]
  %212 = shl nuw nsw i64 %210, 5
  %gep = getelementptr double, ptr %invariant.gep, i64 %210
  %213 = load double, ptr %gep, align 8
  %214 = insertelement <1 x double> poison, double %213, i64 0
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %212
  %215 = load <4 x double>, ptr %gep26, align 8
  %216 = shufflevector <4 x double> %215, <4 x double> poison, <1 x i32> zeroinitializer
  %217 = shufflevector <4 x double> %215, <4 x double> poison, <1 x i32> <i32 1>
  %218 = shufflevector <4 x double> %215, <4 x double> poison, <1 x i32> <i32 2>
  %219 = shufflevector <4 x double> %215, <4 x double> poison, <1 x i32> <i32 3>
  %220 = fmul <1 x double> %214, %216
  %221 = fmul <1 x double> %214, %217
  %222 = fmul <1 x double> %214, %218
  %223 = shufflevector <1 x double> %222, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %224 = fmul <1 x double> %214, %219
  %225 = shufflevector <1 x double> %224, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %226 = shufflevector <1 x double> %220, <1 x double> %221, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %227 = shufflevector <4 x double> %226, <4 x double> %223, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %228 = shufflevector <4 x double> %227, <4 x double> %225, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %229 = fadd <4 x double> %211, %228
  store <4 x double> %229, ptr %209, align 8
  %230 = or disjoint i64 %210, 1
  %231 = shl nuw nsw i64 %230, 5
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %230
  %232 = load double, ptr %gep.1, align 8
  %233 = insertelement <1 x double> poison, double %232, i64 0
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %231
  %234 = load <4 x double>, ptr %gep26.1, align 8
  %235 = shufflevector <4 x double> %234, <4 x double> poison, <1 x i32> zeroinitializer
  %236 = shufflevector <4 x double> %234, <4 x double> poison, <1 x i32> <i32 1>
  %237 = shufflevector <4 x double> %234, <4 x double> poison, <1 x i32> <i32 2>
  %238 = shufflevector <4 x double> %234, <4 x double> poison, <1 x i32> <i32 3>
  %239 = fmul <1 x double> %233, %235
  %240 = fmul <1 x double> %233, %236
  %241 = fmul <1 x double> %233, %237
  %242 = shufflevector <1 x double> %241, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %243 = fmul <1 x double> %233, %238
  %244 = shufflevector <1 x double> %243, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %245 = shufflevector <1 x double> %239, <1 x double> %240, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %246 = shufflevector <4 x double> %245, <4 x double> %242, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %247 = shufflevector <4 x double> %246, <4 x double> %244, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %248 = fadd <4 x double> %229, %247
  store <4 x double> %248, ptr %209, align 8
  %249 = add nuw nsw i64 %210, 2
  %exitcond.123.not.1 = icmp eq i64 %249, 64
  br i1 %exitcond.123.not.1, label %.preheader.1.1, label %.critedge.124

.preheader.1.1:                                   ; preds = %.critedge.124
  %250 = getelementptr double, ptr %209, i64 4
  %.promoted.1.1 = load <4 x double>, ptr %250, align 8
  %invariant.gep27 = getelementptr double, ptr %1, i64 %207
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1, %.preheader.1.1
  %251 = phi i64 [ 0, %.preheader.1.1 ], [ %290, %.critedge.1.1 ]
  %252 = phi <4 x double> [ %.promoted.1.1, %.preheader.1.1 ], [ %289, %.critedge.1.1 ]
  %253 = shl nuw nsw i64 %251, 5
  %gep28 = getelementptr double, ptr %invariant.gep27, i64 %251
  %254 = load double, ptr %gep28, align 8
  %255 = insertelement <1 x double> poison, double %254, i64 0
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %253
  %256 = load <4 x double>, ptr %gep30, align 8
  %257 = shufflevector <4 x double> %256, <4 x double> poison, <1 x i32> zeroinitializer
  %258 = shufflevector <4 x double> %256, <4 x double> poison, <1 x i32> <i32 1>
  %259 = shufflevector <4 x double> %256, <4 x double> poison, <1 x i32> <i32 2>
  %260 = shufflevector <4 x double> %256, <4 x double> poison, <1 x i32> <i32 3>
  %261 = fmul <1 x double> %255, %257
  %262 = fmul <1 x double> %255, %258
  %263 = fmul <1 x double> %255, %259
  %264 = shufflevector <1 x double> %263, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %265 = fmul <1 x double> %255, %260
  %266 = shufflevector <1 x double> %265, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %267 = shufflevector <1 x double> %261, <1 x double> %262, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %268 = shufflevector <4 x double> %267, <4 x double> %264, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %269 = shufflevector <4 x double> %268, <4 x double> %266, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %270 = fadd <4 x double> %252, %269
  store <4 x double> %270, ptr %250, align 8
  %271 = or disjoint i64 %251, 1
  %272 = shl nuw nsw i64 %271, 5
  %gep28.1 = getelementptr double, ptr %invariant.gep27, i64 %271
  %273 = load double, ptr %gep28.1, align 8
  %274 = insertelement <1 x double> poison, double %273, i64 0
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %272
  %275 = load <4 x double>, ptr %gep30.1, align 8
  %276 = shufflevector <4 x double> %275, <4 x double> poison, <1 x i32> zeroinitializer
  %277 = shufflevector <4 x double> %275, <4 x double> poison, <1 x i32> <i32 1>
  %278 = shufflevector <4 x double> %275, <4 x double> poison, <1 x i32> <i32 2>
  %279 = shufflevector <4 x double> %275, <4 x double> poison, <1 x i32> <i32 3>
  %280 = fmul <1 x double> %274, %276
  %281 = fmul <1 x double> %274, %277
  %282 = fmul <1 x double> %274, %278
  %283 = shufflevector <1 x double> %282, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %284 = fmul <1 x double> %274, %279
  %285 = shufflevector <1 x double> %284, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %286 = shufflevector <1 x double> %280, <1 x double> %281, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %287 = shufflevector <4 x double> %286, <4 x double> %283, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %288 = shufflevector <4 x double> %287, <4 x double> %285, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %289 = fadd <4 x double> %270, %288
  store <4 x double> %289, ptr %250, align 8
  %290 = add nuw nsw i64 %251, 2
  %exitcond.1.1.not.1 = icmp eq i64 %290, 64
  br i1 %exitcond.1.1.not.1, label %.preheader.2.1, label %.critedge.1.1

.preheader.2.1:                                   ; preds = %.critedge.1.1
  %291 = getelementptr double, ptr %209, i64 8
  %.promoted.2.1 = load <4 x double>, ptr %291, align 8
  %invariant.gep31 = getelementptr double, ptr %1, i64 %207
  br label %.critedge.2.1

.critedge.2.1:                                    ; preds = %.critedge.2.1, %.preheader.2.1
  %292 = phi i64 [ 0, %.preheader.2.1 ], [ %331, %.critedge.2.1 ]
  %293 = phi <4 x double> [ %.promoted.2.1, %.preheader.2.1 ], [ %330, %.critedge.2.1 ]
  %294 = shl nuw nsw i64 %292, 5
  %gep32 = getelementptr double, ptr %invariant.gep31, i64 %292
  %295 = load double, ptr %gep32, align 8
  %296 = insertelement <1 x double> poison, double %295, i64 0
  %gep34 = getelementptr double, ptr %invariant.gep33, i64 %294
  %297 = load <4 x double>, ptr %gep34, align 8
  %298 = shufflevector <4 x double> %297, <4 x double> poison, <1 x i32> zeroinitializer
  %299 = shufflevector <4 x double> %297, <4 x double> poison, <1 x i32> <i32 1>
  %300 = shufflevector <4 x double> %297, <4 x double> poison, <1 x i32> <i32 2>
  %301 = shufflevector <4 x double> %297, <4 x double> poison, <1 x i32> <i32 3>
  %302 = fmul <1 x double> %296, %298
  %303 = fmul <1 x double> %296, %299
  %304 = fmul <1 x double> %296, %300
  %305 = shufflevector <1 x double> %304, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %306 = fmul <1 x double> %296, %301
  %307 = shufflevector <1 x double> %306, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %308 = shufflevector <1 x double> %302, <1 x double> %303, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %309 = shufflevector <4 x double> %308, <4 x double> %305, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %310 = shufflevector <4 x double> %309, <4 x double> %307, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %311 = fadd <4 x double> %293, %310
  store <4 x double> %311, ptr %291, align 8
  %312 = or disjoint i64 %292, 1
  %313 = shl nuw nsw i64 %312, 5
  %gep32.1 = getelementptr double, ptr %invariant.gep31, i64 %312
  %314 = load double, ptr %gep32.1, align 8
  %315 = insertelement <1 x double> poison, double %314, i64 0
  %gep34.1 = getelementptr double, ptr %invariant.gep33, i64 %313
  %316 = load <4 x double>, ptr %gep34.1, align 8
  %317 = shufflevector <4 x double> %316, <4 x double> poison, <1 x i32> zeroinitializer
  %318 = shufflevector <4 x double> %316, <4 x double> poison, <1 x i32> <i32 1>
  %319 = shufflevector <4 x double> %316, <4 x double> poison, <1 x i32> <i32 2>
  %320 = shufflevector <4 x double> %316, <4 x double> poison, <1 x i32> <i32 3>
  %321 = fmul <1 x double> %315, %317
  %322 = fmul <1 x double> %315, %318
  %323 = fmul <1 x double> %315, %319
  %324 = shufflevector <1 x double> %323, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %325 = fmul <1 x double> %315, %320
  %326 = shufflevector <1 x double> %325, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %327 = shufflevector <1 x double> %321, <1 x double> %322, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %328 = shufflevector <4 x double> %327, <4 x double> %324, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %329 = shufflevector <4 x double> %328, <4 x double> %326, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %330 = fadd <4 x double> %311, %329
  store <4 x double> %330, ptr %291, align 8
  %331 = add nuw nsw i64 %292, 2
  %exitcond.2.1.not.1 = icmp eq i64 %331, 64
  br i1 %exitcond.2.1.not.1, label %.preheader.3.1, label %.critedge.2.1

.preheader.3.1:                                   ; preds = %.critedge.2.1
  %332 = getelementptr double, ptr %209, i64 12
  %.promoted.3.1 = load <4 x double>, ptr %332, align 8
  %invariant.gep35 = getelementptr double, ptr %1, i64 %207
  br label %.critedge.3.1

.critedge.3.1:                                    ; preds = %.critedge.3.1, %.preheader.3.1
  %333 = phi i64 [ 0, %.preheader.3.1 ], [ %372, %.critedge.3.1 ]
  %334 = phi <4 x double> [ %.promoted.3.1, %.preheader.3.1 ], [ %371, %.critedge.3.1 ]
  %335 = shl nuw nsw i64 %333, 5
  %gep36 = getelementptr double, ptr %invariant.gep35, i64 %333
  %336 = load double, ptr %gep36, align 8
  %337 = insertelement <1 x double> poison, double %336, i64 0
  %gep38 = getelementptr double, ptr %invariant.gep37, i64 %335
  %338 = load <4 x double>, ptr %gep38, align 8
  %339 = shufflevector <4 x double> %338, <4 x double> poison, <1 x i32> zeroinitializer
  %340 = shufflevector <4 x double> %338, <4 x double> poison, <1 x i32> <i32 1>
  %341 = shufflevector <4 x double> %338, <4 x double> poison, <1 x i32> <i32 2>
  %342 = shufflevector <4 x double> %338, <4 x double> poison, <1 x i32> <i32 3>
  %343 = fmul <1 x double> %337, %339
  %344 = fmul <1 x double> %337, %340
  %345 = fmul <1 x double> %337, %341
  %346 = shufflevector <1 x double> %345, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %347 = fmul <1 x double> %337, %342
  %348 = shufflevector <1 x double> %347, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %349 = shufflevector <1 x double> %343, <1 x double> %344, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %350 = shufflevector <4 x double> %349, <4 x double> %346, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %351 = shufflevector <4 x double> %350, <4 x double> %348, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %352 = fadd <4 x double> %334, %351
  store <4 x double> %352, ptr %332, align 8
  %353 = or disjoint i64 %333, 1
  %354 = shl nuw nsw i64 %353, 5
  %gep36.1 = getelementptr double, ptr %invariant.gep35, i64 %353
  %355 = load double, ptr %gep36.1, align 8
  %356 = insertelement <1 x double> poison, double %355, i64 0
  %gep38.1 = getelementptr double, ptr %invariant.gep37, i64 %354
  %357 = load <4 x double>, ptr %gep38.1, align 8
  %358 = shufflevector <4 x double> %357, <4 x double> poison, <1 x i32> zeroinitializer
  %359 = shufflevector <4 x double> %357, <4 x double> poison, <1 x i32> <i32 1>
  %360 = shufflevector <4 x double> %357, <4 x double> poison, <1 x i32> <i32 2>
  %361 = shufflevector <4 x double> %357, <4 x double> poison, <1 x i32> <i32 3>
  %362 = fmul <1 x double> %356, %358
  %363 = fmul <1 x double> %356, %359
  %364 = fmul <1 x double> %356, %360
  %365 = shufflevector <1 x double> %364, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %366 = fmul <1 x double> %356, %361
  %367 = shufflevector <1 x double> %366, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %368 = shufflevector <1 x double> %362, <1 x double> %363, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %369 = shufflevector <4 x double> %368, <4 x double> %365, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %370 = shufflevector <4 x double> %369, <4 x double> %367, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %371 = fadd <4 x double> %352, %370
  store <4 x double> %371, ptr %332, align 8
  %372 = add nuw nsw i64 %333, 2
  %exitcond.3.1.not.1 = icmp eq i64 %372, 64
  br i1 %exitcond.3.1.not.1, label %373, label %.critedge.3.1

373:                                              ; preds = %.critedge.3.1
  %374 = add nuw nsw i64 %205, 1
  %exitcond19.1.not = icmp eq i64 %374, 16
  br i1 %exitcond19.1.not, label %375, label %.preheader16.1

375:                                              ; preds = %373
  %376 = add nuw nsw i64 %22, 16
  %377 = icmp ult i64 %22, 112
  br i1 %377, label %.preheader17, label %378

378:                                              ; preds = %375
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
