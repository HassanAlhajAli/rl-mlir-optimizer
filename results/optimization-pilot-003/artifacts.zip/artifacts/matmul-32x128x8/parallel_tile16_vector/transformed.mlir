#map = affine_map<(d0, d1) -> (d0, 0, d1)>
#map1 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<32x8xf64>, %arg1: memref<8x128xf64>, %arg2: memref<32x128xf64>) attributes {llvm.emit_c_interface} {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c1_0 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_1 = arith.constant 0 : index
    %c16_2 = arith.constant 16 : index
    %c0_3 = arith.constant 0 : index
    %c0_4 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<32x128xf64>)
    %c0_5 = arith.constant 0 : index
    %c32 = arith.constant 32 : index
    %c16_6 = arith.constant 16 : index
    scf.for %arg3 = %c0_5 to %c32 step %c16_6 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 8] [1, 1] : memref<32x8xf64> to memref<16x8xf64, strided<[8, 1], offset: ?>>
      %subview_7 = memref.subview %arg2[%arg3, 0] [16, 128] [1, 1] : memref<32x128xf64> to memref<16x128xf64, strided<[128, 1], offset: ?>>
      %c0_8 = arith.constant 0 : index
      %c128 = arith.constant 128 : index
      %c16_9 = arith.constant 16 : index
      scf.for %arg4 = %c0_8 to %c128 step %c16_9 {
        %subview_10 = memref.subview %arg1[0, %arg4] [8, 16] [1, 1] : memref<8x128xf64> to memref<8x16xf64, strided<[128, 1], offset: ?>>
        %subview_11 = memref.subview %subview_7[0, %arg4] [16, 16] [1, 1] : memref<16x128xf64, strided<[128, 1], offset: ?>> to memref<16x16xf64, strided<[128, 1], offset: ?>>
        %c0_12 = arith.constant 0 : index
        %c16_13 = arith.constant 16 : index
        %c1_14 = arith.constant 1 : index
        %c0_15 = arith.constant 0 : index
        %c16_16 = arith.constant 16 : index
        %c4_17 = arith.constant 4 : index
        %c0_18 = arith.constant 0 : index
        %c8 = arith.constant 8 : index
        %c1_19 = arith.constant 1 : index
        scf.for %arg5 = %c0_12 to %c16_13 step %c1_14 {
          scf.for %arg6 = %c0_15 to %c16_16 step %c4_17 {
            scf.for %arg7 = %c0_18 to %c8 step %c1_19 {
              %subview_20 = memref.subview %subview[%arg5, %arg7] [1, 1] [1, 1] : memref<16x8xf64, strided<[8, 1], offset: ?>> to memref<1x1xf64, strided<[8, 1], offset: ?>>
              %subview_21 = memref.subview %subview_10[%arg7, %arg6] [1, 4] [1, 1] : memref<8x16xf64, strided<[128, 1], offset: ?>> to memref<1x4xf64, strided<[128, 1], offset: ?>>
              %subview_22 = memref.subview %subview_11[%arg5, %arg6] [1, 4] [1, 1] : memref<16x16xf64, strided<[128, 1], offset: ?>> to memref<1x4xf64, strided<[128, 1], offset: ?>>
              %c1_23 = arith.constant 1 : index
              %c4_24 = arith.constant 4 : index
              %c1_25 = arith.constant 1 : index
              %c0_26 = arith.constant 0 : index
              %cst_27 = arith.constant 0.000000e+00 : f64
              %0 = vector.transfer_read %subview_20[%c0_26, %c0_26], %cst_27 {permutation_map = #map} : memref<1x1xf64, strided<[8, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_28 = arith.constant 0.000000e+00 : f64
              %1 = vector.transfer_read %subview_21[%c0_26, %c0_26], %cst_28 {permutation_map = #map1} : memref<1x4xf64, strided<[128, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_29 = arith.constant 0.000000e+00 : f64
              %2 = vector.transfer_read %subview_22[%c0_26, %c0_26], %cst_29 : memref<1x4xf64, strided<[128, 1], offset: ?>>, vector<1x4xf64>
              %3 = arith.mulf %0, %1 : vector<1x4x1xf64>
              %4 = vector.multi_reduction <add>, %3, %2 [2] : vector<1x4x1xf64> to vector<1x4xf64>
              %c0_30 = arith.constant 0 : index
              vector.transfer_write %4, %subview_22[%c0_30, %c0_30] : vector<1x4xf64>, memref<1x4xf64, strided<[128, 1], offset: ?>>
            }
          }
        }
      }
    }
    return
  }
}
