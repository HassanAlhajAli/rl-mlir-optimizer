; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %21 = getelementptr double, ptr %1, i64 1
  %22 = getelementptr double, ptr %1, i64 2
  %23 = getelementptr double, ptr %1, i64 3
  %24 = getelementptr double, ptr %1, i64 4
  %25 = getelementptr double, ptr %1, i64 5
  %26 = getelementptr double, ptr %1, i64 6
  %27 = getelementptr double, ptr %1, i64 7
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %198
  %28 = phi i1 [ false, %198 ], [ true, %.preheader17.preheader ]
  %29 = phi i64 [ 16, %198 ], [ 0, %.preheader17.preheader ]
  %30 = shl nuw nsw i64 %29, 7
  %invariant.gep19 = getelementptr double, ptr %15, i64 %30
  br label %31

31:                                               ; preds = %.preheader17, %195
  %32 = phi i64 [ 0, %.preheader17 ], [ %196, %195 ]
  %gep20 = getelementptr double, ptr %invariant.gep19, i64 %32
  br label %.preheader16

.preheader16:                                     ; preds = %31, %193
  %33 = phi i64 [ 0, %31 ], [ %194, %193 ]
  %34 = add nuw nsw i64 %33, %29
  %35 = shl i64 %34, 3
  %36 = shl i64 %33, 7
  %37 = getelementptr double, ptr %gep20, i64 %36
  %38 = getelementptr double, ptr %1, i64 %35
  %39 = getelementptr double, ptr %21, i64 %35
  %40 = getelementptr double, ptr %22, i64 %35
  %41 = getelementptr double, ptr %23, i64 %35
  %42 = getelementptr double, ptr %24, i64 %35
  %43 = getelementptr double, ptr %25, i64 %35
  %44 = getelementptr double, ptr %26, i64 %35
  %45 = getelementptr double, ptr %27, i64 %35
  br label %.preheader

.preheader:                                       ; preds = %.preheader16, %.preheader
  %46 = phi i64 [ 0, %.preheader16 ], [ %191, %.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %46
  %47 = getelementptr double, ptr %37, i64 %46
  %.promoted = load <4 x double>, ptr %47, align 8
  %48 = load double, ptr %38, align 8
  %49 = insertelement <1 x double> poison, double %48, i64 0
  %gep = getelementptr double, ptr %invariant.gep, i64 %32
  %50 = load <4 x double>, ptr %gep, align 8
  %51 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> zeroinitializer
  %52 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 1>
  %53 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 2>
  %54 = shufflevector <4 x double> %50, <4 x double> poison, <1 x i32> <i32 3>
  %55 = fmul <1 x double> %49, %51
  %56 = fmul <1 x double> %49, %52
  %57 = fmul <1 x double> %49, %53
  %58 = shufflevector <1 x double> %57, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %59 = fmul <1 x double> %49, %54
  %60 = shufflevector <1 x double> %59, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <1 x double> %55, <1 x double> %56, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %58, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %64 = fadd <4 x double> %.promoted, %63
  store <4 x double> %64, ptr %47, align 8
  %65 = load double, ptr %39, align 8
  %66 = insertelement <1 x double> poison, double %65, i64 0
  %67 = getelementptr double, ptr %invariant.gep, i64 128
  %gep.1 = getelementptr double, ptr %67, i64 %32
  %68 = load <4 x double>, ptr %gep.1, align 8
  %69 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> zeroinitializer
  %70 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 1>
  %71 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 2>
  %72 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 3>
  %73 = fmul <1 x double> %66, %69
  %74 = fmul <1 x double> %66, %70
  %75 = fmul <1 x double> %66, %71
  %76 = shufflevector <1 x double> %75, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %77 = fmul <1 x double> %66, %72
  %78 = shufflevector <1 x double> %77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = shufflevector <1 x double> %73, <1 x double> %74, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %80 = shufflevector <4 x double> %79, <4 x double> %76, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %81 = shufflevector <4 x double> %80, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %82 = fadd <4 x double> %64, %81
  store <4 x double> %82, ptr %47, align 8
  %83 = load double, ptr %40, align 8
  %84 = insertelement <1 x double> poison, double %83, i64 0
  %85 = getelementptr double, ptr %invariant.gep, i64 256
  %gep.2 = getelementptr double, ptr %85, i64 %32
  %86 = load <4 x double>, ptr %gep.2, align 8
  %87 = shufflevector <4 x double> %86, <4 x double> poison, <1 x i32> zeroinitializer
  %88 = shufflevector <4 x double> %86, <4 x double> poison, <1 x i32> <i32 1>
  %89 = shufflevector <4 x double> %86, <4 x double> poison, <1 x i32> <i32 2>
  %90 = shufflevector <4 x double> %86, <4 x double> poison, <1 x i32> <i32 3>
  %91 = fmul <1 x double> %84, %87
  %92 = fmul <1 x double> %84, %88
  %93 = fmul <1 x double> %84, %89
  %94 = shufflevector <1 x double> %93, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = fmul <1 x double> %84, %90
  %96 = shufflevector <1 x double> %95, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %97 = shufflevector <1 x double> %91, <1 x double> %92, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %98 = shufflevector <4 x double> %97, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %99 = shufflevector <4 x double> %98, <4 x double> %96, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %100 = fadd <4 x double> %82, %99
  store <4 x double> %100, ptr %47, align 8
  %101 = load double, ptr %41, align 8
  %102 = insertelement <1 x double> poison, double %101, i64 0
  %103 = getelementptr double, ptr %invariant.gep, i64 384
  %gep.3 = getelementptr double, ptr %103, i64 %32
  %104 = load <4 x double>, ptr %gep.3, align 8
  %105 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> zeroinitializer
  %106 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 1>
  %107 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 2>
  %108 = shufflevector <4 x double> %104, <4 x double> poison, <1 x i32> <i32 3>
  %109 = fmul <1 x double> %102, %105
  %110 = fmul <1 x double> %102, %106
  %111 = fmul <1 x double> %102, %107
  %112 = shufflevector <1 x double> %111, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %113 = fmul <1 x double> %102, %108
  %114 = shufflevector <1 x double> %113, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %115 = shufflevector <1 x double> %109, <1 x double> %110, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %116 = shufflevector <4 x double> %115, <4 x double> %112, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %117 = shufflevector <4 x double> %116, <4 x double> %114, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %118 = fadd <4 x double> %100, %117
  store <4 x double> %118, ptr %47, align 8
  %119 = load double, ptr %42, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %121 = getelementptr double, ptr %invariant.gep, i64 512
  %gep.4 = getelementptr double, ptr %121, i64 %32
  %122 = load <4 x double>, ptr %gep.4, align 8
  %123 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> zeroinitializer
  %124 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 1>
  %125 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 2>
  %126 = shufflevector <4 x double> %122, <4 x double> poison, <1 x i32> <i32 3>
  %127 = fmul <1 x double> %120, %123
  %128 = fmul <1 x double> %120, %124
  %129 = fmul <1 x double> %120, %125
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = fmul <1 x double> %120, %126
  %132 = shufflevector <1 x double> %131, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %133 = shufflevector <1 x double> %127, <1 x double> %128, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %135 = shufflevector <4 x double> %134, <4 x double> %132, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %136 = fadd <4 x double> %118, %135
  store <4 x double> %136, ptr %47, align 8
  %137 = load double, ptr %43, align 8
  %138 = insertelement <1 x double> poison, double %137, i64 0
  %139 = getelementptr double, ptr %invariant.gep, i64 640
  %gep.5 = getelementptr double, ptr %139, i64 %32
  %140 = load <4 x double>, ptr %gep.5, align 8
  %141 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> zeroinitializer
  %142 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 1>
  %143 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 2>
  %144 = shufflevector <4 x double> %140, <4 x double> poison, <1 x i32> <i32 3>
  %145 = fmul <1 x double> %138, %141
  %146 = fmul <1 x double> %138, %142
  %147 = fmul <1 x double> %138, %143
  %148 = shufflevector <1 x double> %147, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %149 = fmul <1 x double> %138, %144
  %150 = shufflevector <1 x double> %149, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %151 = shufflevector <1 x double> %145, <1 x double> %146, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %152 = shufflevector <4 x double> %151, <4 x double> %148, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %150, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %154 = fadd <4 x double> %136, %153
  store <4 x double> %154, ptr %47, align 8
  %155 = load double, ptr %44, align 8
  %156 = insertelement <1 x double> poison, double %155, i64 0
  %157 = getelementptr double, ptr %invariant.gep, i64 768
  %gep.6 = getelementptr double, ptr %157, i64 %32
  %158 = load <4 x double>, ptr %gep.6, align 8
  %159 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> zeroinitializer
  %160 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 1>
  %161 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 2>
  %162 = shufflevector <4 x double> %158, <4 x double> poison, <1 x i32> <i32 3>
  %163 = fmul <1 x double> %156, %159
  %164 = fmul <1 x double> %156, %160
  %165 = fmul <1 x double> %156, %161
  %166 = shufflevector <1 x double> %165, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %167 = fmul <1 x double> %156, %162
  %168 = shufflevector <1 x double> %167, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %169 = shufflevector <1 x double> %163, <1 x double> %164, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %170 = shufflevector <4 x double> %169, <4 x double> %166, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %171 = shufflevector <4 x double> %170, <4 x double> %168, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %172 = fadd <4 x double> %154, %171
  store <4 x double> %172, ptr %47, align 8
  %173 = load double, ptr %45, align 8
  %174 = insertelement <1 x double> poison, double %173, i64 0
  %175 = getelementptr double, ptr %invariant.gep, i64 896
  %gep.7 = getelementptr double, ptr %175, i64 %32
  %176 = load <4 x double>, ptr %gep.7, align 8
  %177 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> zeroinitializer
  %178 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 1>
  %179 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 2>
  %180 = shufflevector <4 x double> %176, <4 x double> poison, <1 x i32> <i32 3>
  %181 = fmul <1 x double> %174, %177
  %182 = fmul <1 x double> %174, %178
  %183 = fmul <1 x double> %174, %179
  %184 = shufflevector <1 x double> %183, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %185 = fmul <1 x double> %174, %180
  %186 = shufflevector <1 x double> %185, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %187 = shufflevector <1 x double> %181, <1 x double> %182, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %188 = shufflevector <4 x double> %187, <4 x double> %184, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %189 = shufflevector <4 x double> %188, <4 x double> %186, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %190 = fadd <4 x double> %172, %189
  store <4 x double> %190, ptr %47, align 8
  %191 = add nuw nsw i64 %46, 4
  %192 = icmp ult i64 %46, 12
  br i1 %192, label %.preheader, label %193

193:                                              ; preds = %.preheader
  %194 = add nuw nsw i64 %33, 1
  %exitcond.not = icmp eq i64 %194, 16
  br i1 %exitcond.not, label %195, label %.preheader16

195:                                              ; preds = %193
  %196 = add nuw nsw i64 %32, 16
  %197 = icmp ult i64 %32, 112
  br i1 %197, label %31, label %198

198:                                              ; preds = %195
  br i1 %28, label %.preheader17, label %199

199:                                              ; preds = %198
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  %4 = getelementptr double, ptr %.unpack2, i64 1
  %5 = getelementptr double, ptr %.unpack2, i64 2
  %6 = getelementptr double, ptr %.unpack2, i64 3
  %7 = getelementptr double, ptr %.unpack2, i64 4
  %8 = getelementptr double, ptr %.unpack2, i64 5
  %9 = getelementptr double, ptr %.unpack2, i64 6
  %10 = getelementptr double, ptr %.unpack2, i64 7
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %181, %3
  %11 = phi i1 [ false, %181 ], [ true, %3 ]
  %12 = phi i64 [ 16, %181 ], [ 0, %3 ]
  %13 = shl nuw nsw i64 %12, 7
  %invariant.gep19.i = getelementptr double, ptr %.unpack32, i64 %13
  br label %14

14:                                               ; preds = %178, %.preheader17.i
  %15 = phi i64 [ 0, %.preheader17.i ], [ %179, %178 ]
  %gep20.i = getelementptr double, ptr %invariant.gep19.i, i64 %15
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %176, %14
  %16 = phi i64 [ 0, %14 ], [ %177, %176 ]
  %17 = add nuw nsw i64 %16, %12
  %18 = shl i64 %17, 3
  %19 = shl i64 %16, 7
  %20 = getelementptr double, ptr %gep20.i, i64 %19
  %21 = getelementptr double, ptr %.unpack2, i64 %18
  %22 = getelementptr double, ptr %4, i64 %18
  %23 = getelementptr double, ptr %5, i64 %18
  %24 = getelementptr double, ptr %6, i64 %18
  %25 = getelementptr double, ptr %7, i64 %18
  %26 = getelementptr double, ptr %8, i64 %18
  %27 = getelementptr double, ptr %9, i64 %18
  %28 = getelementptr double, ptr %10, i64 %18
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %.preheader16.i
  %29 = phi i64 [ 0, %.preheader16.i ], [ %174, %.preheader.i ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %29
  %30 = getelementptr double, ptr %20, i64 %29
  %.promoted.i = load <4 x double>, ptr %30, align 8
  %31 = load double, ptr %21, align 8
  %32 = insertelement <1 x double> poison, double %31, i64 0
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %33 = load <4 x double>, ptr %gep.i, align 8
  %34 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> zeroinitializer
  %35 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 1>
  %36 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 2>
  %37 = shufflevector <4 x double> %33, <4 x double> poison, <1 x i32> <i32 3>
  %38 = fmul <1 x double> %32, %34
  %39 = fmul <1 x double> %32, %35
  %40 = fmul <1 x double> %32, %36
  %41 = shufflevector <1 x double> %40, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %42 = fmul <1 x double> %32, %37
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <1 x double> %38, <1 x double> %39, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %41, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %47 = fadd <4 x double> %.promoted.i, %46
  store <4 x double> %47, ptr %30, align 8
  %48 = load double, ptr %22, align 8
  %49 = insertelement <1 x double> poison, double %48, i64 0
  %50 = getelementptr double, ptr %invariant.gep.i, i64 128
  %gep.1.i = getelementptr double, ptr %50, i64 %15
  %51 = load <4 x double>, ptr %gep.1.i, align 8
  %52 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> zeroinitializer
  %53 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 1>
  %54 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 2>
  %55 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 3>
  %56 = fmul <1 x double> %49, %52
  %57 = fmul <1 x double> %49, %53
  %58 = fmul <1 x double> %49, %54
  %59 = shufflevector <1 x double> %58, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %60 = fmul <1 x double> %49, %55
  %61 = shufflevector <1 x double> %60, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <1 x double> %56, <1 x double> %57, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %63 = shufflevector <4 x double> %62, <4 x double> %59, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %64 = shufflevector <4 x double> %63, <4 x double> %61, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %65 = fadd <4 x double> %47, %64
  store <4 x double> %65, ptr %30, align 8
  %66 = load double, ptr %23, align 8
  %67 = insertelement <1 x double> poison, double %66, i64 0
  %68 = getelementptr double, ptr %invariant.gep.i, i64 256
  %gep.2.i = getelementptr double, ptr %68, i64 %15
  %69 = load <4 x double>, ptr %gep.2.i, align 8
  %70 = shufflevector <4 x double> %69, <4 x double> poison, <1 x i32> zeroinitializer
  %71 = shufflevector <4 x double> %69, <4 x double> poison, <1 x i32> <i32 1>
  %72 = shufflevector <4 x double> %69, <4 x double> poison, <1 x i32> <i32 2>
  %73 = shufflevector <4 x double> %69, <4 x double> poison, <1 x i32> <i32 3>
  %74 = fmul <1 x double> %67, %70
  %75 = fmul <1 x double> %67, %71
  %76 = fmul <1 x double> %67, %72
  %77 = shufflevector <1 x double> %76, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %78 = fmul <1 x double> %67, %73
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = shufflevector <1 x double> %74, <1 x double> %75, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %81 = shufflevector <4 x double> %80, <4 x double> %77, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %82 = shufflevector <4 x double> %81, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %83 = fadd <4 x double> %65, %82
  store <4 x double> %83, ptr %30, align 8
  %84 = load double, ptr %24, align 8
  %85 = insertelement <1 x double> poison, double %84, i64 0
  %86 = getelementptr double, ptr %invariant.gep.i, i64 384
  %gep.3.i = getelementptr double, ptr %86, i64 %15
  %87 = load <4 x double>, ptr %gep.3.i, align 8
  %88 = shufflevector <4 x double> %87, <4 x double> poison, <1 x i32> zeroinitializer
  %89 = shufflevector <4 x double> %87, <4 x double> poison, <1 x i32> <i32 1>
  %90 = shufflevector <4 x double> %87, <4 x double> poison, <1 x i32> <i32 2>
  %91 = shufflevector <4 x double> %87, <4 x double> poison, <1 x i32> <i32 3>
  %92 = fmul <1 x double> %85, %88
  %93 = fmul <1 x double> %85, %89
  %94 = fmul <1 x double> %85, %90
  %95 = shufflevector <1 x double> %94, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %96 = fmul <1 x double> %85, %91
  %97 = shufflevector <1 x double> %96, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %98 = shufflevector <1 x double> %92, <1 x double> %93, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %99 = shufflevector <4 x double> %98, <4 x double> %95, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %97, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %101 = fadd <4 x double> %83, %100
  store <4 x double> %101, ptr %30, align 8
  %102 = load double, ptr %25, align 8
  %103 = insertelement <1 x double> poison, double %102, i64 0
  %104 = getelementptr double, ptr %invariant.gep.i, i64 512
  %gep.4.i = getelementptr double, ptr %104, i64 %15
  %105 = load <4 x double>, ptr %gep.4.i, align 8
  %106 = shufflevector <4 x double> %105, <4 x double> poison, <1 x i32> zeroinitializer
  %107 = shufflevector <4 x double> %105, <4 x double> poison, <1 x i32> <i32 1>
  %108 = shufflevector <4 x double> %105, <4 x double> poison, <1 x i32> <i32 2>
  %109 = shufflevector <4 x double> %105, <4 x double> poison, <1 x i32> <i32 3>
  %110 = fmul <1 x double> %103, %106
  %111 = fmul <1 x double> %103, %107
  %112 = fmul <1 x double> %103, %108
  %113 = shufflevector <1 x double> %112, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %114 = fmul <1 x double> %103, %109
  %115 = shufflevector <1 x double> %114, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %116 = shufflevector <1 x double> %110, <1 x double> %111, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %117 = shufflevector <4 x double> %116, <4 x double> %113, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %118 = shufflevector <4 x double> %117, <4 x double> %115, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %119 = fadd <4 x double> %101, %118
  store <4 x double> %119, ptr %30, align 8
  %120 = load double, ptr %26, align 8
  %121 = insertelement <1 x double> poison, double %120, i64 0
  %122 = getelementptr double, ptr %invariant.gep.i, i64 640
  %gep.5.i = getelementptr double, ptr %122, i64 %15
  %123 = load <4 x double>, ptr %gep.5.i, align 8
  %124 = shufflevector <4 x double> %123, <4 x double> poison, <1 x i32> zeroinitializer
  %125 = shufflevector <4 x double> %123, <4 x double> poison, <1 x i32> <i32 1>
  %126 = shufflevector <4 x double> %123, <4 x double> poison, <1 x i32> <i32 2>
  %127 = shufflevector <4 x double> %123, <4 x double> poison, <1 x i32> <i32 3>
  %128 = fmul <1 x double> %121, %124
  %129 = fmul <1 x double> %121, %125
  %130 = fmul <1 x double> %121, %126
  %131 = shufflevector <1 x double> %130, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %132 = fmul <1 x double> %121, %127
  %133 = shufflevector <1 x double> %132, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %134 = shufflevector <1 x double> %128, <1 x double> %129, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %135 = shufflevector <4 x double> %134, <4 x double> %131, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %136 = shufflevector <4 x double> %135, <4 x double> %133, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %137 = fadd <4 x double> %119, %136
  store <4 x double> %137, ptr %30, align 8
  %138 = load double, ptr %27, align 8
  %139 = insertelement <1 x double> poison, double %138, i64 0
  %140 = getelementptr double, ptr %invariant.gep.i, i64 768
  %gep.6.i = getelementptr double, ptr %140, i64 %15
  %141 = load <4 x double>, ptr %gep.6.i, align 8
  %142 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> zeroinitializer
  %143 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 1>
  %144 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 2>
  %145 = shufflevector <4 x double> %141, <4 x double> poison, <1 x i32> <i32 3>
  %146 = fmul <1 x double> %139, %142
  %147 = fmul <1 x double> %139, %143
  %148 = fmul <1 x double> %139, %144
  %149 = shufflevector <1 x double> %148, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %150 = fmul <1 x double> %139, %145
  %151 = shufflevector <1 x double> %150, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %152 = shufflevector <1 x double> %146, <1 x double> %147, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %149, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %151, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %155 = fadd <4 x double> %137, %154
  store <4 x double> %155, ptr %30, align 8
  %156 = load double, ptr %28, align 8
  %157 = insertelement <1 x double> poison, double %156, i64 0
  %158 = getelementptr double, ptr %invariant.gep.i, i64 896
  %gep.7.i = getelementptr double, ptr %158, i64 %15
  %159 = load <4 x double>, ptr %gep.7.i, align 8
  %160 = shufflevector <4 x double> %159, <4 x double> poison, <1 x i32> zeroinitializer
  %161 = shufflevector <4 x double> %159, <4 x double> poison, <1 x i32> <i32 1>
  %162 = shufflevector <4 x double> %159, <4 x double> poison, <1 x i32> <i32 2>
  %163 = shufflevector <4 x double> %159, <4 x double> poison, <1 x i32> <i32 3>
  %164 = fmul <1 x double> %157, %160
  %165 = fmul <1 x double> %157, %161
  %166 = fmul <1 x double> %157, %162
  %167 = shufflevector <1 x double> %166, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %168 = fmul <1 x double> %157, %163
  %169 = shufflevector <1 x double> %168, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %170 = shufflevector <1 x double> %164, <1 x double> %165, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %171 = shufflevector <4 x double> %170, <4 x double> %167, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %172 = shufflevector <4 x double> %171, <4 x double> %169, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %173 = fadd <4 x double> %155, %172
  store <4 x double> %173, ptr %30, align 8
  %174 = add nuw nsw i64 %29, 4
  %175 = icmp ult i64 %29, 12
  br i1 %175, label %.preheader.i, label %176

176:                                              ; preds = %.preheader.i
  %177 = add nuw nsw i64 %16, 1
  %exitcond.not.i = icmp eq i64 %177, 16
  br i1 %exitcond.not.i, label %178, label %.preheader16.i

178:                                              ; preds = %176
  %179 = add nuw nsw i64 %15, 16
  %180 = icmp ult i64 %15, 112
  br i1 %180, label %14, label %181

181:                                              ; preds = %178
  br i1 %11, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %181
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  %11 = getelementptr double, ptr %4, i64 1
  %12 = getelementptr double, ptr %4, i64 2
  %13 = getelementptr double, ptr %4, i64 3
  %14 = getelementptr double, ptr %4, i64 4
  %15 = getelementptr double, ptr %4, i64 5
  %16 = getelementptr double, ptr %4, i64 6
  %17 = getelementptr double, ptr %4, i64 7
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %188, %1
  %18 = phi i1 [ false, %188 ], [ true, %1 ]
  %19 = phi i64 [ 16, %188 ], [ 0, %1 ]
  %20 = shl nuw nsw i64 %19, 7
  %invariant.gep19.i = getelementptr double, ptr %10, i64 %20
  br label %21

21:                                               ; preds = %185, %.preheader17.i
  %22 = phi i64 [ 0, %.preheader17.i ], [ %186, %185 ]
  %gep20.i = getelementptr double, ptr %invariant.gep19.i, i64 %22
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %183, %21
  %23 = phi i64 [ 0, %21 ], [ %184, %183 ]
  %24 = add nuw nsw i64 %23, %19
  %25 = shl i64 %24, 3
  %26 = shl i64 %23, 7
  %27 = getelementptr double, ptr %gep20.i, i64 %26
  %28 = getelementptr double, ptr %4, i64 %25
  %29 = getelementptr double, ptr %11, i64 %25
  %30 = getelementptr double, ptr %12, i64 %25
  %31 = getelementptr double, ptr %13, i64 %25
  %32 = getelementptr double, ptr %14, i64 %25
  %33 = getelementptr double, ptr %15, i64 %25
  %34 = getelementptr double, ptr %16, i64 %25
  %35 = getelementptr double, ptr %17, i64 %25
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %.preheader16.i
  %36 = phi i64 [ 0, %.preheader16.i ], [ %181, %.preheader.i ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %36
  %37 = getelementptr double, ptr %27, i64 %36
  %.promoted.i = load <4 x double>, ptr %37, align 8
  %38 = load double, ptr %28, align 8
  %39 = insertelement <1 x double> poison, double %38, i64 0
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %22
  %40 = load <4 x double>, ptr %gep.i, align 8
  %41 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> zeroinitializer
  %42 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 1>
  %43 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 2>
  %44 = shufflevector <4 x double> %40, <4 x double> poison, <1 x i32> <i32 3>
  %45 = fmul <1 x double> %39, %41
  %46 = fmul <1 x double> %39, %42
  %47 = fmul <1 x double> %39, %43
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = fmul <1 x double> %39, %44
  %50 = shufflevector <1 x double> %49, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %51 = shufflevector <1 x double> %45, <1 x double> %46, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %50, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %54 = fadd <4 x double> %.promoted.i, %53
  store <4 x double> %54, ptr %37, align 8
  %55 = load double, ptr %29, align 8
  %56 = insertelement <1 x double> poison, double %55, i64 0
  %57 = getelementptr double, ptr %invariant.gep.i, i64 128
  %gep.1.i = getelementptr double, ptr %57, i64 %22
  %58 = load <4 x double>, ptr %gep.1.i, align 8
  %59 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> zeroinitializer
  %60 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 1>
  %61 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 2>
  %62 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 3>
  %63 = fmul <1 x double> %56, %59
  %64 = fmul <1 x double> %56, %60
  %65 = fmul <1 x double> %56, %61
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = fmul <1 x double> %56, %62
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %63, <1 x double> %64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %72 = fadd <4 x double> %54, %71
  store <4 x double> %72, ptr %37, align 8
  %73 = load double, ptr %30, align 8
  %74 = insertelement <1 x double> poison, double %73, i64 0
  %75 = getelementptr double, ptr %invariant.gep.i, i64 256
  %gep.2.i = getelementptr double, ptr %75, i64 %22
  %76 = load <4 x double>, ptr %gep.2.i, align 8
  %77 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> zeroinitializer
  %78 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 1>
  %79 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 2>
  %80 = shufflevector <4 x double> %76, <4 x double> poison, <1 x i32> <i32 3>
  %81 = fmul <1 x double> %74, %77
  %82 = fmul <1 x double> %74, %78
  %83 = fmul <1 x double> %74, %79
  %84 = shufflevector <1 x double> %83, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = fmul <1 x double> %74, %80
  %86 = shufflevector <1 x double> %85, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = shufflevector <1 x double> %81, <1 x double> %82, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = fadd <4 x double> %72, %89
  store <4 x double> %90, ptr %37, align 8
  %91 = load double, ptr %31, align 8
  %92 = insertelement <1 x double> poison, double %91, i64 0
  %93 = getelementptr double, ptr %invariant.gep.i, i64 384
  %gep.3.i = getelementptr double, ptr %93, i64 %22
  %94 = load <4 x double>, ptr %gep.3.i, align 8
  %95 = shufflevector <4 x double> %94, <4 x double> poison, <1 x i32> zeroinitializer
  %96 = shufflevector <4 x double> %94, <4 x double> poison, <1 x i32> <i32 1>
  %97 = shufflevector <4 x double> %94, <4 x double> poison, <1 x i32> <i32 2>
  %98 = shufflevector <4 x double> %94, <4 x double> poison, <1 x i32> <i32 3>
  %99 = fmul <1 x double> %92, %95
  %100 = fmul <1 x double> %92, %96
  %101 = fmul <1 x double> %92, %97
  %102 = shufflevector <1 x double> %101, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %103 = fmul <1 x double> %92, %98
  %104 = shufflevector <1 x double> %103, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %105 = shufflevector <1 x double> %99, <1 x double> %100, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %106 = shufflevector <4 x double> %105, <4 x double> %102, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %104, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %108 = fadd <4 x double> %90, %107
  store <4 x double> %108, ptr %37, align 8
  %109 = load double, ptr %32, align 8
  %110 = insertelement <1 x double> poison, double %109, i64 0
  %111 = getelementptr double, ptr %invariant.gep.i, i64 512
  %gep.4.i = getelementptr double, ptr %111, i64 %22
  %112 = load <4 x double>, ptr %gep.4.i, align 8
  %113 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> zeroinitializer
  %114 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 1>
  %115 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 2>
  %116 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 3>
  %117 = fmul <1 x double> %110, %113
  %118 = fmul <1 x double> %110, %114
  %119 = fmul <1 x double> %110, %115
  %120 = shufflevector <1 x double> %119, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %121 = fmul <1 x double> %110, %116
  %122 = shufflevector <1 x double> %121, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %123 = shufflevector <1 x double> %117, <1 x double> %118, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %124 = shufflevector <4 x double> %123, <4 x double> %120, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %125 = shufflevector <4 x double> %124, <4 x double> %122, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %126 = fadd <4 x double> %108, %125
  store <4 x double> %126, ptr %37, align 8
  %127 = load double, ptr %33, align 8
  %128 = insertelement <1 x double> poison, double %127, i64 0
  %129 = getelementptr double, ptr %invariant.gep.i, i64 640
  %gep.5.i = getelementptr double, ptr %129, i64 %22
  %130 = load <4 x double>, ptr %gep.5.i, align 8
  %131 = shufflevector <4 x double> %130, <4 x double> poison, <1 x i32> zeroinitializer
  %132 = shufflevector <4 x double> %130, <4 x double> poison, <1 x i32> <i32 1>
  %133 = shufflevector <4 x double> %130, <4 x double> poison, <1 x i32> <i32 2>
  %134 = shufflevector <4 x double> %130, <4 x double> poison, <1 x i32> <i32 3>
  %135 = fmul <1 x double> %128, %131
  %136 = fmul <1 x double> %128, %132
  %137 = fmul <1 x double> %128, %133
  %138 = shufflevector <1 x double> %137, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %139 = fmul <1 x double> %128, %134
  %140 = shufflevector <1 x double> %139, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %141 = shufflevector <1 x double> %135, <1 x double> %136, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %142 = shufflevector <4 x double> %141, <4 x double> %138, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %143 = shufflevector <4 x double> %142, <4 x double> %140, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %144 = fadd <4 x double> %126, %143
  store <4 x double> %144, ptr %37, align 8
  %145 = load double, ptr %34, align 8
  %146 = insertelement <1 x double> poison, double %145, i64 0
  %147 = getelementptr double, ptr %invariant.gep.i, i64 768
  %gep.6.i = getelementptr double, ptr %147, i64 %22
  %148 = load <4 x double>, ptr %gep.6.i, align 8
  %149 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> zeroinitializer
  %150 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 1>
  %151 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 2>
  %152 = shufflevector <4 x double> %148, <4 x double> poison, <1 x i32> <i32 3>
  %153 = fmul <1 x double> %146, %149
  %154 = fmul <1 x double> %146, %150
  %155 = fmul <1 x double> %146, %151
  %156 = shufflevector <1 x double> %155, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %157 = fmul <1 x double> %146, %152
  %158 = shufflevector <1 x double> %157, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %159 = shufflevector <1 x double> %153, <1 x double> %154, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %160 = shufflevector <4 x double> %159, <4 x double> %156, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %161 = shufflevector <4 x double> %160, <4 x double> %158, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %162 = fadd <4 x double> %144, %161
  store <4 x double> %162, ptr %37, align 8
  %163 = load double, ptr %35, align 8
  %164 = insertelement <1 x double> poison, double %163, i64 0
  %165 = getelementptr double, ptr %invariant.gep.i, i64 896
  %gep.7.i = getelementptr double, ptr %165, i64 %22
  %166 = load <4 x double>, ptr %gep.7.i, align 8
  %167 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> zeroinitializer
  %168 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 1>
  %169 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 2>
  %170 = shufflevector <4 x double> %166, <4 x double> poison, <1 x i32> <i32 3>
  %171 = fmul <1 x double> %164, %167
  %172 = fmul <1 x double> %164, %168
  %173 = fmul <1 x double> %164, %169
  %174 = shufflevector <1 x double> %173, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %175 = fmul <1 x double> %164, %170
  %176 = shufflevector <1 x double> %175, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %177 = shufflevector <1 x double> %171, <1 x double> %172, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %174, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %179 = shufflevector <4 x double> %178, <4 x double> %176, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %180 = fadd <4 x double> %162, %179
  store <4 x double> %180, ptr %37, align 8
  %181 = add nuw nsw i64 %36, 4
  %182 = icmp ult i64 %36, 12
  br i1 %182, label %.preheader.i, label %183

183:                                              ; preds = %.preheader.i
  %184 = add nuw nsw i64 %23, 1
  %exitcond.not.i = icmp eq i64 %184, 16
  br i1 %exitcond.not.i, label %185, label %.preheader16.i

185:                                              ; preds = %183
  %186 = add nuw nsw i64 %22, 16
  %187 = icmp ult i64 %22, 112
  br i1 %187, label %21, label %188

188:                                              ; preds = %185
  br i1 %18, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %188
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32.i, i8 0, i64 32768, i1 false)
  %10 = getelementptr double, ptr %.unpack2.i, i64 1
  %11 = getelementptr double, ptr %.unpack2.i, i64 2
  %12 = getelementptr double, ptr %.unpack2.i, i64 3
  %13 = getelementptr double, ptr %.unpack2.i, i64 4
  %14 = getelementptr double, ptr %.unpack2.i, i64 5
  %15 = getelementptr double, ptr %.unpack2.i, i64 6
  %16 = getelementptr double, ptr %.unpack2.i, i64 7
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %187, %1
  %17 = phi i1 [ false, %187 ], [ true, %1 ]
  %18 = phi i64 [ 16, %187 ], [ 0, %1 ]
  %19 = shl nuw nsw i64 %18, 7
  %invariant.gep19.i.i = getelementptr double, ptr %.unpack32.i, i64 %19
  br label %20

20:                                               ; preds = %184, %.preheader17.i.i
  %21 = phi i64 [ 0, %.preheader17.i.i ], [ %185, %184 ]
  %gep20.i.i = getelementptr double, ptr %invariant.gep19.i.i, i64 %21
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %182, %20
  %22 = phi i64 [ 0, %20 ], [ %183, %182 ]
  %23 = add nuw nsw i64 %22, %18
  %24 = shl i64 %23, 3
  %25 = shl i64 %22, 7
  %26 = getelementptr double, ptr %gep20.i.i, i64 %25
  %27 = getelementptr double, ptr %.unpack2.i, i64 %24
  %28 = getelementptr double, ptr %10, i64 %24
  %29 = getelementptr double, ptr %11, i64 %24
  %30 = getelementptr double, ptr %12, i64 %24
  %31 = getelementptr double, ptr %13, i64 %24
  %32 = getelementptr double, ptr %14, i64 %24
  %33 = getelementptr double, ptr %15, i64 %24
  %34 = getelementptr double, ptr %16, i64 %24
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %.preheader.i.i, %.preheader16.i.i
  %35 = phi i64 [ 0, %.preheader16.i.i ], [ %180, %.preheader.i.i ]
  %invariant.gep.i.i = getelementptr double, ptr %.unpack17.i, i64 %35
  %36 = getelementptr double, ptr %26, i64 %35
  %.promoted.i.i = load <4 x double>, ptr %36, align 8
  %37 = load double, ptr %27, align 8
  %38 = insertelement <1 x double> poison, double %37, i64 0
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %21
  %39 = load <4 x double>, ptr %gep.i.i, align 8
  %40 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> zeroinitializer
  %41 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 1>
  %42 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 2>
  %43 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 3>
  %44 = fmul <1 x double> %38, %40
  %45 = fmul <1 x double> %38, %41
  %46 = fmul <1 x double> %38, %42
  %47 = shufflevector <1 x double> %46, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %48 = fmul <1 x double> %38, %43
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %44, <1 x double> %45, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %47, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fadd <4 x double> %.promoted.i.i, %52
  store <4 x double> %53, ptr %36, align 8
  %54 = load double, ptr %28, align 8
  %55 = insertelement <1 x double> poison, double %54, i64 0
  %56 = getelementptr double, ptr %invariant.gep.i.i, i64 128
  %gep.1.i.i = getelementptr double, ptr %56, i64 %21
  %57 = load <4 x double>, ptr %gep.1.i.i, align 8
  %58 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> zeroinitializer
  %59 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 1>
  %60 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 2>
  %61 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 3>
  %62 = fmul <1 x double> %55, %58
  %63 = fmul <1 x double> %55, %59
  %64 = fmul <1 x double> %55, %60
  %65 = shufflevector <1 x double> %64, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %66 = fmul <1 x double> %55, %61
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = shufflevector <1 x double> %62, <1 x double> %63, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %69 = shufflevector <4 x double> %68, <4 x double> %65, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %71 = fadd <4 x double> %53, %70
  store <4 x double> %71, ptr %36, align 8
  %72 = load double, ptr %29, align 8
  %73 = insertelement <1 x double> poison, double %72, i64 0
  %74 = getelementptr double, ptr %invariant.gep.i.i, i64 256
  %gep.2.i.i = getelementptr double, ptr %74, i64 %21
  %75 = load <4 x double>, ptr %gep.2.i.i, align 8
  %76 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> zeroinitializer
  %77 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 1>
  %78 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 2>
  %79 = shufflevector <4 x double> %75, <4 x double> poison, <1 x i32> <i32 3>
  %80 = fmul <1 x double> %73, %76
  %81 = fmul <1 x double> %73, %77
  %82 = fmul <1 x double> %73, %78
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = fmul <1 x double> %73, %79
  %85 = shufflevector <1 x double> %84, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = shufflevector <1 x double> %80, <1 x double> %81, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %87 = shufflevector <4 x double> %86, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %89 = fadd <4 x double> %71, %88
  store <4 x double> %89, ptr %36, align 8
  %90 = load double, ptr %30, align 8
  %91 = insertelement <1 x double> poison, double %90, i64 0
  %92 = getelementptr double, ptr %invariant.gep.i.i, i64 384
  %gep.3.i.i = getelementptr double, ptr %92, i64 %21
  %93 = load <4 x double>, ptr %gep.3.i.i, align 8
  %94 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> zeroinitializer
  %95 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 1>
  %96 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 2>
  %97 = shufflevector <4 x double> %93, <4 x double> poison, <1 x i32> <i32 3>
  %98 = fmul <1 x double> %91, %94
  %99 = fmul <1 x double> %91, %95
  %100 = fmul <1 x double> %91, %96
  %101 = shufflevector <1 x double> %100, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %102 = fmul <1 x double> %91, %97
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <1 x double> %98, <1 x double> %99, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %101, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %106 = shufflevector <4 x double> %105, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %107 = fadd <4 x double> %89, %106
  store <4 x double> %107, ptr %36, align 8
  %108 = load double, ptr %31, align 8
  %109 = insertelement <1 x double> poison, double %108, i64 0
  %110 = getelementptr double, ptr %invariant.gep.i.i, i64 512
  %gep.4.i.i = getelementptr double, ptr %110, i64 %21
  %111 = load <4 x double>, ptr %gep.4.i.i, align 8
  %112 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> zeroinitializer
  %113 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 1>
  %114 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 2>
  %115 = shufflevector <4 x double> %111, <4 x double> poison, <1 x i32> <i32 3>
  %116 = fmul <1 x double> %109, %112
  %117 = fmul <1 x double> %109, %113
  %118 = fmul <1 x double> %109, %114
  %119 = shufflevector <1 x double> %118, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %120 = fmul <1 x double> %109, %115
  %121 = shufflevector <1 x double> %120, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %122 = shufflevector <1 x double> %116, <1 x double> %117, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %123 = shufflevector <4 x double> %122, <4 x double> %119, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %124 = shufflevector <4 x double> %123, <4 x double> %121, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %125 = fadd <4 x double> %107, %124
  store <4 x double> %125, ptr %36, align 8
  %126 = load double, ptr %32, align 8
  %127 = insertelement <1 x double> poison, double %126, i64 0
  %128 = getelementptr double, ptr %invariant.gep.i.i, i64 640
  %gep.5.i.i = getelementptr double, ptr %128, i64 %21
  %129 = load <4 x double>, ptr %gep.5.i.i, align 8
  %130 = shufflevector <4 x double> %129, <4 x double> poison, <1 x i32> zeroinitializer
  %131 = shufflevector <4 x double> %129, <4 x double> poison, <1 x i32> <i32 1>
  %132 = shufflevector <4 x double> %129, <4 x double> poison, <1 x i32> <i32 2>
  %133 = shufflevector <4 x double> %129, <4 x double> poison, <1 x i32> <i32 3>
  %134 = fmul <1 x double> %127, %130
  %135 = fmul <1 x double> %127, %131
  %136 = fmul <1 x double> %127, %132
  %137 = shufflevector <1 x double> %136, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %138 = fmul <1 x double> %127, %133
  %139 = shufflevector <1 x double> %138, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %140 = shufflevector <1 x double> %134, <1 x double> %135, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %141 = shufflevector <4 x double> %140, <4 x double> %137, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %142 = shufflevector <4 x double> %141, <4 x double> %139, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %143 = fadd <4 x double> %125, %142
  store <4 x double> %143, ptr %36, align 8
  %144 = load double, ptr %33, align 8
  %145 = insertelement <1 x double> poison, double %144, i64 0
  %146 = getelementptr double, ptr %invariant.gep.i.i, i64 768
  %gep.6.i.i = getelementptr double, ptr %146, i64 %21
  %147 = load <4 x double>, ptr %gep.6.i.i, align 8
  %148 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> zeroinitializer
  %149 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 1>
  %150 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 2>
  %151 = shufflevector <4 x double> %147, <4 x double> poison, <1 x i32> <i32 3>
  %152 = fmul <1 x double> %145, %148
  %153 = fmul <1 x double> %145, %149
  %154 = fmul <1 x double> %145, %150
  %155 = shufflevector <1 x double> %154, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %156 = fmul <1 x double> %145, %151
  %157 = shufflevector <1 x double> %156, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %158 = shufflevector <1 x double> %152, <1 x double> %153, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %159 = shufflevector <4 x double> %158, <4 x double> %155, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %160 = shufflevector <4 x double> %159, <4 x double> %157, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %161 = fadd <4 x double> %143, %160
  store <4 x double> %161, ptr %36, align 8
  %162 = load double, ptr %34, align 8
  %163 = insertelement <1 x double> poison, double %162, i64 0
  %164 = getelementptr double, ptr %invariant.gep.i.i, i64 896
  %gep.7.i.i = getelementptr double, ptr %164, i64 %21
  %165 = load <4 x double>, ptr %gep.7.i.i, align 8
  %166 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> zeroinitializer
  %167 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 1>
  %168 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 2>
  %169 = shufflevector <4 x double> %165, <4 x double> poison, <1 x i32> <i32 3>
  %170 = fmul <1 x double> %163, %166
  %171 = fmul <1 x double> %163, %167
  %172 = fmul <1 x double> %163, %168
  %173 = shufflevector <1 x double> %172, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %174 = fmul <1 x double> %163, %169
  %175 = shufflevector <1 x double> %174, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %176 = shufflevector <1 x double> %170, <1 x double> %171, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %177 = shufflevector <4 x double> %176, <4 x double> %173, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %178 = shufflevector <4 x double> %177, <4 x double> %175, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %179 = fadd <4 x double> %161, %178
  store <4 x double> %179, ptr %36, align 8
  %180 = add nuw nsw i64 %35, 4
  %181 = icmp ult i64 %35, 12
  br i1 %181, label %.preheader.i.i, label %182

182:                                              ; preds = %.preheader.i.i
  %183 = add nuw nsw i64 %22, 1
  %exitcond.not.i.i = icmp eq i64 %183, 16
  br i1 %exitcond.not.i.i, label %184, label %.preheader16.i.i

184:                                              ; preds = %182
  %185 = add nuw nsw i64 %21, 16
  %186 = icmp ult i64 %21, 112
  br i1 %186, label %20, label %187

187:                                              ; preds = %184
  br i1 %17, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %187
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
