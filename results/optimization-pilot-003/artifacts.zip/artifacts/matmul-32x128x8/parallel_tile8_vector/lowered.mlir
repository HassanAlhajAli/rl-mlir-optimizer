module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(128 : index) : i64
    %29 = llvm.mlir.constant(32 : index) : i64
    %30 = llvm.mlir.constant(1 : index) : i64
    %31 = llvm.mlir.constant(4 : index) : i64
    %32 = llvm.mlir.constant(0 : index) : i64
    %33 = llvm.mlir.constant(8 : index) : i64
    %34 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%32 : i64)
  ^bb1(%35: i64):  // 2 preds: ^bb0, ^bb5
    %36 = llvm.icmp "slt" %35, %29 : i64
    llvm.cond_br %36, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%32 : i64)
  ^bb3(%37: i64):  // 2 preds: ^bb2, ^bb4
    %38 = llvm.icmp "slt" %37, %28 : i64
    llvm.cond_br %38, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %39 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %40 = llvm.mlir.constant(128 : index) : i64
    %41 = llvm.mul %35, %40  : i64
    %42 = llvm.add %41, %37  : i64
    %43 = llvm.getelementptr %39[%42] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %34, %43 : f64, !llvm.ptr
    %44 = llvm.add %37, %30  : i64
    llvm.br ^bb3(%44 : i64)
  ^bb5:  // pred: ^bb3
    %45 = llvm.add %35, %30  : i64
    llvm.br ^bb1(%45 : i64)
  ^bb6:  // pred: ^bb1
    %46 = llvm.mlir.constant(1 : index) : i64
    %47 = llvm.alloca %46 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %48 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %49 = llvm.insertvalue %47, %48[0] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.insertvalue %47, %49[1] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.mlir.constant(0 : index) : i64
    %52 = llvm.insertvalue %51, %50[2] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.mlir.constant(1 : index) : i64
    %54 = llvm.alloca %53 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %55 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %56 = llvm.insertvalue %54, %55[0] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.insertvalue %54, %56[1] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.mlir.constant(0 : index) : i64
    %59 = llvm.insertvalue %58, %57[2] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.mlir.constant(1 : index) : i64
    %61 = llvm.alloca %60 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %62 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %63 = llvm.insertvalue %61, %62[0] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.insertvalue %61, %63[1] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.mlir.constant(0 : index) : i64
    %66 = llvm.insertvalue %65, %64[2] : !llvm.struct<(ptr, ptr, i64)> 
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.alloca %67 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %68, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%32 : i64)
  ^bb7(%74: i64):  // 2 preds: ^bb6, ^bb32
    %75 = llvm.icmp "slt" %74, %29 : i64
    llvm.cond_br %75, ^bb8, ^bb33
  ^bb8:  // pred: ^bb7
    %76 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %79 = llvm.insertvalue %76, %78[0] : !llvm.struct<(ptr, ptr, i64)> 
    %80 = llvm.insertvalue %77, %79[1] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.mlir.constant(0 : index) : i64
    %82 = llvm.insertvalue %81, %80[2] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.mul %74, %33  : i64
    %89 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %92 = llvm.insertvalue %89, %91[0] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.insertvalue %90, %92[1] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.mlir.constant(0 : index) : i64
    %95 = llvm.insertvalue %94, %93[2] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %101 = llvm.mul %74, %28  : i64
    llvm.br ^bb9(%32 : i64)
  ^bb9(%102: i64):  // 2 preds: ^bb8, ^bb31
    %103 = llvm.icmp "slt" %102, %28 : i64
    llvm.cond_br %103, ^bb10, ^bb32
  ^bb10:  // pred: ^bb9
    %104 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %107 = llvm.insertvalue %104, %106[0] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.insertvalue %105, %107[1] : !llvm.struct<(ptr, ptr, i64)> 
    %109 = llvm.mlir.constant(0 : index) : i64
    %110 = llvm.insertvalue %109, %108[2] : !llvm.struct<(ptr, ptr, i64)> 
    %111 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %112 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.add %101, %102  : i64
    llvm.br ^bb11(%32 : i64)
  ^bb11(%117: i64):  // 2 preds: ^bb10, ^bb30
    %118 = llvm.icmp "slt" %117, %33 : i64
    llvm.cond_br %118, ^bb12, ^bb31
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%32 : i64)
  ^bb13(%119: i64):  // 2 preds: ^bb12, ^bb29
    %120 = llvm.icmp "slt" %119, %33 : i64
    llvm.cond_br %120, ^bb14, ^bb30
  ^bb14:  // pred: ^bb13
    llvm.br ^bb15(%32 : i64)
  ^bb15(%121: i64):  // 2 preds: ^bb14, ^bb28
    %122 = llvm.icmp "slt" %121, %33 : i64
    llvm.cond_br %122, ^bb16, ^bb29
  ^bb16:  // pred: ^bb15
    %123 = llvm.mul %117, %33  : i64
    %124 = llvm.add %88, %123  : i64
    %125 = llvm.add %124, %121  : i64
    %126 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %127 = llvm.insertvalue %76, %126[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.insertvalue %77, %127[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.insertvalue %125, %128[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.mlir.constant(1 : index) : i64
    %131 = llvm.insertvalue %130, %129[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.mlir.constant(8 : index) : i64
    %133 = llvm.insertvalue %132, %131[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %134 = llvm.mlir.constant(1 : index) : i64
    %135 = llvm.insertvalue %134, %133[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %136 = llvm.mlir.constant(1 : index) : i64
    %137 = llvm.insertvalue %136, %135[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.mul %121, %28  : i64
    %139 = llvm.add %102, %138  : i64
    %140 = llvm.add %139, %119  : i64
    %141 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %142 = llvm.insertvalue %104, %141[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %143 = llvm.insertvalue %105, %142[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.insertvalue %140, %143[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.mlir.constant(1 : index) : i64
    %146 = llvm.insertvalue %145, %144[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.mlir.constant(128 : index) : i64
    %148 = llvm.insertvalue %147, %146[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %149 = llvm.mlir.constant(4 : index) : i64
    %150 = llvm.insertvalue %149, %148[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %151 = llvm.mlir.constant(1 : index) : i64
    %152 = llvm.insertvalue %151, %150[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %153 = llvm.mul %117, %28  : i64
    %154 = llvm.add %116, %153  : i64
    %155 = llvm.add %154, %119  : i64
    %156 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %157 = llvm.insertvalue %89, %156[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %158 = llvm.insertvalue %90, %157[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %159 = llvm.insertvalue %155, %158[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %160 = llvm.mlir.constant(1 : index) : i64
    %161 = llvm.insertvalue %160, %159[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %162 = llvm.mlir.constant(128 : index) : i64
    %163 = llvm.insertvalue %162, %161[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %164 = llvm.mlir.constant(4 : index) : i64
    %165 = llvm.insertvalue %164, %163[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %166 = llvm.mlir.constant(1 : index) : i64
    %167 = llvm.insertvalue %166, %165[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %168 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %169 = llvm.extractvalue %52[0] : !llvm.struct<(ptr, ptr, i64)> 
    %170 = llvm.insertvalue %169, %168[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.extractvalue %52[1] : !llvm.struct<(ptr, ptr, i64)> 
    %172 = llvm.insertvalue %171, %170[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %173 = llvm.mlir.constant(0 : index) : i64
    %174 = llvm.insertvalue %173, %172[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %175 = llvm.mlir.constant(1 : index) : i64
    %176 = llvm.insertvalue %175, %174[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %177 = llvm.mlir.constant(1 : index) : i64
    %178 = llvm.insertvalue %177, %176[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb17(%32 : i64)
  ^bb17(%179: i64):  // 2 preds: ^bb16, ^bb18
    %180 = llvm.icmp "slt" %179, %30 : i64
    llvm.cond_br %180, ^bb18, ^bb19
  ^bb18:  // pred: ^bb17
    %181 = llvm.getelementptr %77[%125] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %182 = llvm.mlir.constant(8 : index) : i64
    %183 = llvm.mul %179, %182  : i64
    %184 = llvm.add %183, %32  : i64
    %185 = llvm.getelementptr %181[%184] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %186 = llvm.load %185 : !llvm.ptr -> f64
    %187 = llvm.mlir.undef : vector<1xf64>
    %188 = llvm.mlir.constant(0 : i32) : i32
    %189 = llvm.insertelement %186, %187[%188 : i32] : vector<1xf64>
    %190 = llvm.shufflevector %189, %187 [0] : vector<1xf64> 
    %191 = llvm.getelementptr %171[%179] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %190, %191 : vector<1xf64>, !llvm.ptr
    %192 = llvm.add %179, %30  : i64
    llvm.br ^bb17(%192 : i64)
  ^bb19:  // pred: ^bb17
    %193 = llvm.load %47 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %194 = llvm.extractvalue %193[0] : !llvm.array<1 x vector<1xf64>> 
    %195 = llvm.insertvalue %194, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %196 = llvm.insertvalue %194, %195[1] : !llvm.array<4 x vector<1xf64>> 
    %197 = llvm.insertvalue %194, %196[2] : !llvm.array<4 x vector<1xf64>> 
    %198 = llvm.insertvalue %194, %197[3] : !llvm.array<4 x vector<1xf64>> 
    %199 = llvm.insertvalue %198, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %200 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %201 = llvm.extractvalue %59[0] : !llvm.struct<(ptr, ptr, i64)> 
    %202 = llvm.insertvalue %201, %200[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.extractvalue %59[1] : !llvm.struct<(ptr, ptr, i64)> 
    %204 = llvm.insertvalue %203, %202[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.mlir.constant(0 : index) : i64
    %206 = llvm.insertvalue %205, %204[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %207 = llvm.mlir.constant(1 : index) : i64
    %208 = llvm.insertvalue %207, %206[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %209 = llvm.mlir.constant(1 : index) : i64
    %210 = llvm.insertvalue %209, %208[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb20(%32 : i64)
  ^bb20(%211: i64):  // 2 preds: ^bb19, ^bb21
    %212 = llvm.icmp "slt" %211, %30 : i64
    llvm.cond_br %212, ^bb21, ^bb22
  ^bb21:  // pred: ^bb20
    %213 = llvm.extractvalue %152[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %214 = llvm.extractvalue %152[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %215 = llvm.getelementptr %213[%214] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %216 = llvm.mlir.constant(128 : index) : i64
    %217 = llvm.mul %211, %216  : i64
    %218 = llvm.add %217, %32  : i64
    %219 = llvm.getelementptr %215[%218] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %220 = llvm.load %219 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %221 = llvm.getelementptr %203[%211] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %220, %221 : vector<4xf64>, !llvm.ptr
    %222 = llvm.add %211, %30  : i64
    llvm.br ^bb20(%222 : i64)
  ^bb22:  // pred: ^bb20
    %223 = llvm.load %54 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %224 = llvm.extractvalue %223[0] : !llvm.array<1 x vector<4xf64>> 
    %225 = llvm.mlir.constant(0 : i64) : i64
    %226 = llvm.extractelement %224[%225 : i64] : vector<4xf64>
    %227 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %228 = llvm.mlir.constant(0 : i64) : i64
    %229 = llvm.insertelement %226, %227[%228 : i64] : vector<1xf64>
    %230 = llvm.insertvalue %229, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %231 = llvm.extractvalue %223[0] : !llvm.array<1 x vector<4xf64>> 
    %232 = llvm.mlir.constant(1 : i64) : i64
    %233 = llvm.extractelement %231[%232 : i64] : vector<4xf64>
    %234 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %235 = llvm.mlir.constant(0 : i64) : i64
    %236 = llvm.insertelement %233, %234[%235 : i64] : vector<1xf64>
    %237 = llvm.insertvalue %236, %230[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %238 = llvm.extractvalue %223[0] : !llvm.array<1 x vector<4xf64>> 
    %239 = llvm.mlir.constant(2 : i64) : i64
    %240 = llvm.extractelement %238[%239 : i64] : vector<4xf64>
    %241 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %242 = llvm.mlir.constant(0 : i64) : i64
    %243 = llvm.insertelement %240, %241[%242 : i64] : vector<1xf64>
    %244 = llvm.insertvalue %243, %237[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %245 = llvm.extractvalue %223[0] : !llvm.array<1 x vector<4xf64>> 
    %246 = llvm.mlir.constant(3 : i64) : i64
    %247 = llvm.extractelement %245[%246 : i64] : vector<4xf64>
    %248 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %249 = llvm.mlir.constant(0 : i64) : i64
    %250 = llvm.insertelement %247, %248[%249 : i64] : vector<1xf64>
    %251 = llvm.insertvalue %250, %244[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %252 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %253 = llvm.extractvalue %66[0] : !llvm.struct<(ptr, ptr, i64)> 
    %254 = llvm.insertvalue %253, %252[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %255 = llvm.extractvalue %66[1] : !llvm.struct<(ptr, ptr, i64)> 
    %256 = llvm.insertvalue %255, %254[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %257 = llvm.mlir.constant(0 : index) : i64
    %258 = llvm.insertvalue %257, %256[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %259 = llvm.mlir.constant(1 : index) : i64
    %260 = llvm.insertvalue %259, %258[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %261 = llvm.mlir.constant(1 : index) : i64
    %262 = llvm.insertvalue %261, %260[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb23(%32 : i64)
  ^bb23(%263: i64):  // 2 preds: ^bb22, ^bb24
    %264 = llvm.icmp "slt" %263, %30 : i64
    llvm.cond_br %264, ^bb24, ^bb25
  ^bb24:  // pred: ^bb23
    %265 = llvm.extractvalue %167[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %266 = llvm.extractvalue %167[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %267 = llvm.getelementptr %265[%266] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %268 = llvm.mlir.constant(128 : index) : i64
    %269 = llvm.mul %263, %268  : i64
    %270 = llvm.add %269, %32  : i64
    %271 = llvm.getelementptr %267[%270] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %272 = llvm.load %271 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %273 = llvm.getelementptr %255[%263] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %272, %273 : vector<4xf64>, !llvm.ptr
    %274 = llvm.add %263, %30  : i64
    llvm.br ^bb23(%274 : i64)
  ^bb25:  // pred: ^bb23
    %275 = llvm.load %61 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %276 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %277 = llvm.extractvalue %199[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %278 = llvm.fmul %277, %229  : vector<1xf64>
    %279 = llvm.insertvalue %278, %276[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %280 = llvm.extractvalue %199[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %281 = llvm.fmul %280, %236  : vector<1xf64>
    %282 = llvm.insertvalue %281, %279[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %283 = llvm.extractvalue %199[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %284 = llvm.fmul %283, %243  : vector<1xf64>
    %285 = llvm.insertvalue %284, %282[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %286 = llvm.extractvalue %199[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %287 = llvm.fmul %286, %250  : vector<1xf64>
    %288 = llvm.insertvalue %287, %285[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %289 = llvm.extractvalue %288[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %290 = llvm.mlir.constant(0 : i64) : i64
    %291 = llvm.extractelement %289[%290 : i64] : vector<1xf64>
    %292 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %293 = llvm.mlir.constant(0 : i64) : i64
    %294 = llvm.insertelement %291, %292[%293 : i64] : vector<4xf64>
    %295 = llvm.insertvalue %294, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %296 = llvm.extractvalue %288[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %297 = llvm.mlir.constant(0 : i64) : i64
    %298 = llvm.extractelement %296[%297 : i64] : vector<1xf64>
    %299 = llvm.mlir.constant(1 : i64) : i64
    %300 = llvm.insertelement %298, %294[%299 : i64] : vector<4xf64>
    %301 = llvm.insertvalue %300, %295[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %302 = llvm.extractvalue %288[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %303 = llvm.mlir.constant(0 : i64) : i64
    %304 = llvm.extractelement %302[%303 : i64] : vector<1xf64>
    %305 = llvm.mlir.constant(2 : i64) : i64
    %306 = llvm.insertelement %304, %300[%305 : i64] : vector<4xf64>
    %307 = llvm.insertvalue %306, %301[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %308 = llvm.extractvalue %288[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %309 = llvm.mlir.constant(0 : i64) : i64
    %310 = llvm.extractelement %308[%309 : i64] : vector<1xf64>
    %311 = llvm.mlir.constant(3 : i64) : i64
    %312 = llvm.insertelement %310, %306[%311 : i64] : vector<4xf64>
    %313 = llvm.insertvalue %312, %307[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %314 = llvm.extractvalue %275[0] : !llvm.array<1 x vector<4xf64>> 
    %315 = llvm.fadd %312, %314  : vector<4xf64>
    %316 = llvm.insertvalue %315, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %316, %68 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %317 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %318 = llvm.extractvalue %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %319 = llvm.insertvalue %318, %317[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.extractvalue %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %321 = llvm.insertvalue %320, %319[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %322 = llvm.mlir.constant(0 : index) : i64
    %323 = llvm.insertvalue %322, %321[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %324 = llvm.mlir.constant(1 : index) : i64
    %325 = llvm.insertvalue %324, %323[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %326 = llvm.mlir.constant(1 : index) : i64
    %327 = llvm.insertvalue %326, %325[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb26(%32 : i64)
  ^bb26(%328: i64):  // 2 preds: ^bb25, ^bb27
    %329 = llvm.icmp "slt" %328, %30 : i64
    llvm.cond_br %329, ^bb27, ^bb28
  ^bb27:  // pred: ^bb26
    %330 = llvm.getelementptr %320[%328] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %331 = llvm.load %330 : !llvm.ptr -> vector<4xf64>
    %332 = llvm.extractvalue %167[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %333 = llvm.extractvalue %167[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %334 = llvm.getelementptr %332[%333] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %335 = llvm.mlir.constant(128 : index) : i64
    %336 = llvm.mul %328, %335  : i64
    %337 = llvm.add %336, %32  : i64
    %338 = llvm.getelementptr %334[%337] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %331, %338 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %339 = llvm.add %328, %30  : i64
    llvm.br ^bb26(%339 : i64)
  ^bb28:  // pred: ^bb26
    %340 = llvm.add %121, %30  : i64
    llvm.br ^bb15(%340 : i64)
  ^bb29:  // pred: ^bb15
    %341 = llvm.add %119, %31  : i64
    llvm.br ^bb13(%341 : i64)
  ^bb30:  // pred: ^bb13
    %342 = llvm.add %117, %30  : i64
    llvm.br ^bb11(%342 : i64)
  ^bb31:  // pred: ^bb11
    %343 = llvm.add %102, %33  : i64
    llvm.br ^bb9(%343 : i64)
  ^bb32:  // pred: ^bb9
    %344 = llvm.add %74, %33  : i64
    llvm.br ^bb7(%344 : i64)
  ^bb33:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
