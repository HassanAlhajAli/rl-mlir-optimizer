; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  br label %17

17:                                               ; preds = %35, %.preheader
  %18 = phi <4 x double> [ zeroinitializer, %.preheader ], [ %49, %35 ]
  %19 = phi i64 [ 0, %.preheader ], [ %50, %35 ]
  %20 = getelementptr double, ptr %1, i64 %19
  %unmaskedload = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %20, i64 65
  %unmaskedload22 = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %20, i64 130
  %unmaskedload23 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %20, i64 195
  %unmaskedload24 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %8, i64 %19
  %25 = load double, ptr %24, align 8
  %26 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload22, <2 x i32> <i32 0, i32 1>
  %27 = insertelement <2 x double> poison, double %25, i64 0
  %28 = shufflevector <2 x double> %27, <2 x double> poison, <2 x i32> zeroinitializer
  %29 = fmul <2 x double> %26, %28
  %30 = shufflevector <1 x double> %unmaskedload23, <1 x double> %unmaskedload24, <2 x i32> <i32 0, i32 1>
  %31 = fmul <2 x double> %30, %28
  %32 = shufflevector <2 x double> %29, <2 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %33 = fadd <4 x double> %18, %32
  store <4 x double> %33, ptr %13, align 8
  %34 = or disjoint i64 %19, 1
  %exitcond.not = icmp eq i64 %34, 65
  br i1 %exitcond.not, label %.preheader.116, label %35

35:                                               ; preds = %17
  %36 = getelementptr double, ptr %1, i64 %34
  %unmaskedload.1 = load <1 x double>, ptr %36, align 8
  %37 = getelementptr double, ptr %36, i64 65
  %unmaskedload22.1 = load <1 x double>, ptr %37, align 8
  %38 = getelementptr double, ptr %36, i64 130
  %unmaskedload23.1 = load <1 x double>, ptr %38, align 8
  %39 = getelementptr double, ptr %36, i64 195
  %unmaskedload24.1 = load <1 x double>, ptr %39, align 8
  %40 = getelementptr double, ptr %8, i64 %34
  %41 = load double, ptr %40, align 8
  %42 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload22.1, <2 x i32> <i32 0, i32 1>
  %43 = insertelement <2 x double> poison, double %41, i64 0
  %44 = shufflevector <2 x double> %43, <2 x double> poison, <2 x i32> zeroinitializer
  %45 = fmul <2 x double> %42, %44
  %46 = shufflevector <1 x double> %unmaskedload23.1, <1 x double> %unmaskedload24.1, <2 x i32> <i32 0, i32 1>
  %47 = fmul <2 x double> %46, %44
  %48 = shufflevector <2 x double> %45, <2 x double> %47, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %49 = fadd <4 x double> %33, %48
  store <4 x double> %49, ptr %13, align 8
  %50 = add nuw nsw i64 %19, 2
  br label %17

.preheader.116:                                   ; preds = %17
  %51 = getelementptr double, ptr %1, i64 260
  %52 = getelementptr double, ptr %13, i64 4
  %.promoted59 = load <4 x double>, ptr %52, align 8
  br label %53

53:                                               ; preds = %71, %.preheader.116
  %54 = phi <4 x double> [ %.promoted59, %.preheader.116 ], [ %85, %71 ]
  %55 = phi i64 [ 0, %.preheader.116 ], [ %86, %71 ]
  %56 = getelementptr double, ptr %51, i64 %55
  %unmaskedload26 = load <1 x double>, ptr %56, align 8
  %57 = getelementptr double, ptr %56, i64 65
  %unmaskedload27 = load <1 x double>, ptr %57, align 8
  %58 = getelementptr double, ptr %56, i64 130
  %unmaskedload28 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %56, i64 195
  %unmaskedload29 = load <1 x double>, ptr %59, align 8
  %60 = getelementptr double, ptr %8, i64 %55
  %61 = load double, ptr %60, align 8
  %62 = shufflevector <1 x double> %unmaskedload26, <1 x double> %unmaskedload27, <2 x i32> <i32 0, i32 1>
  %63 = insertelement <2 x double> poison, double %61, i64 0
  %64 = shufflevector <2 x double> %63, <2 x double> poison, <2 x i32> zeroinitializer
  %65 = fmul <2 x double> %62, %64
  %66 = shufflevector <1 x double> %unmaskedload28, <1 x double> %unmaskedload29, <2 x i32> <i32 0, i32 1>
  %67 = fmul <2 x double> %66, %64
  %68 = shufflevector <2 x double> %65, <2 x double> %67, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %69 = fadd <4 x double> %54, %68
  store <4 x double> %69, ptr %52, align 8
  %70 = or disjoint i64 %55, 1
  %exitcond.121.not = icmp eq i64 %70, 65
  br i1 %exitcond.121.not, label %.preheader.2, label %71

71:                                               ; preds = %53
  %72 = getelementptr double, ptr %51, i64 %70
  %unmaskedload26.1 = load <1 x double>, ptr %72, align 8
  %73 = getelementptr double, ptr %72, i64 65
  %unmaskedload27.1 = load <1 x double>, ptr %73, align 8
  %74 = getelementptr double, ptr %72, i64 130
  %unmaskedload28.1 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %72, i64 195
  %unmaskedload29.1 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %8, i64 %70
  %77 = load double, ptr %76, align 8
  %78 = shufflevector <1 x double> %unmaskedload26.1, <1 x double> %unmaskedload27.1, <2 x i32> <i32 0, i32 1>
  %79 = insertelement <2 x double> poison, double %77, i64 0
  %80 = shufflevector <2 x double> %79, <2 x double> poison, <2 x i32> zeroinitializer
  %81 = fmul <2 x double> %78, %80
  %82 = shufflevector <1 x double> %unmaskedload28.1, <1 x double> %unmaskedload29.1, <2 x i32> <i32 0, i32 1>
  %83 = fmul <2 x double> %82, %80
  %84 = shufflevector <2 x double> %81, <2 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %85 = fadd <4 x double> %69, %84
  store <4 x double> %85, ptr %52, align 8
  %86 = add nuw nsw i64 %55, 2
  br label %53

.preheader.2:                                     ; preds = %53
  %87 = getelementptr double, ptr %1, i64 520
  %88 = getelementptr double, ptr %13, i64 8
  %.promoted60 = load <4 x double>, ptr %88, align 8
  br label %89

89:                                               ; preds = %107, %.preheader.2
  %90 = phi <4 x double> [ %.promoted60, %.preheader.2 ], [ %121, %107 ]
  %91 = phi i64 [ 0, %.preheader.2 ], [ %122, %107 ]
  %92 = getelementptr double, ptr %87, i64 %91
  %unmaskedload31 = load <1 x double>, ptr %92, align 8
  %93 = getelementptr double, ptr %92, i64 65
  %unmaskedload32 = load <1 x double>, ptr %93, align 8
  %94 = getelementptr double, ptr %92, i64 130
  %unmaskedload33 = load <1 x double>, ptr %94, align 8
  %95 = getelementptr double, ptr %92, i64 195
  %unmaskedload34 = load <1 x double>, ptr %95, align 8
  %96 = getelementptr double, ptr %8, i64 %91
  %97 = load double, ptr %96, align 8
  %98 = shufflevector <1 x double> %unmaskedload31, <1 x double> %unmaskedload32, <2 x i32> <i32 0, i32 1>
  %99 = insertelement <2 x double> poison, double %97, i64 0
  %100 = shufflevector <2 x double> %99, <2 x double> poison, <2 x i32> zeroinitializer
  %101 = fmul <2 x double> %98, %100
  %102 = shufflevector <1 x double> %unmaskedload33, <1 x double> %unmaskedload34, <2 x i32> <i32 0, i32 1>
  %103 = fmul <2 x double> %102, %100
  %104 = shufflevector <2 x double> %101, <2 x double> %103, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %105 = fadd <4 x double> %90, %104
  store <4 x double> %105, ptr %88, align 8
  %106 = or disjoint i64 %91, 1
  %exitcond.2.not = icmp eq i64 %106, 65
  br i1 %exitcond.2.not, label %.preheader.3, label %107

107:                                              ; preds = %89
  %108 = getelementptr double, ptr %87, i64 %106
  %unmaskedload31.1 = load <1 x double>, ptr %108, align 8
  %109 = getelementptr double, ptr %108, i64 65
  %unmaskedload32.1 = load <1 x double>, ptr %109, align 8
  %110 = getelementptr double, ptr %108, i64 130
  %unmaskedload33.1 = load <1 x double>, ptr %110, align 8
  %111 = getelementptr double, ptr %108, i64 195
  %unmaskedload34.1 = load <1 x double>, ptr %111, align 8
  %112 = getelementptr double, ptr %8, i64 %106
  %113 = load double, ptr %112, align 8
  %114 = shufflevector <1 x double> %unmaskedload31.1, <1 x double> %unmaskedload32.1, <2 x i32> <i32 0, i32 1>
  %115 = insertelement <2 x double> poison, double %113, i64 0
  %116 = shufflevector <2 x double> %115, <2 x double> poison, <2 x i32> zeroinitializer
  %117 = fmul <2 x double> %114, %116
  %118 = shufflevector <1 x double> %unmaskedload33.1, <1 x double> %unmaskedload34.1, <2 x i32> <i32 0, i32 1>
  %119 = fmul <2 x double> %118, %116
  %120 = shufflevector <2 x double> %117, <2 x double> %119, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %121 = fadd <4 x double> %105, %120
  store <4 x double> %121, ptr %88, align 8
  %122 = add nuw nsw i64 %91, 2
  br label %89

.preheader.3:                                     ; preds = %89
  %123 = getelementptr double, ptr %1, i64 780
  %124 = getelementptr double, ptr %13, i64 12
  %.promoted61 = load <4 x double>, ptr %124, align 8
  br label %125

125:                                              ; preds = %143, %.preheader.3
  %126 = phi <4 x double> [ %.promoted61, %.preheader.3 ], [ %157, %143 ]
  %127 = phi i64 [ 0, %.preheader.3 ], [ %158, %143 ]
  %128 = getelementptr double, ptr %123, i64 %127
  %unmaskedload36 = load <1 x double>, ptr %128, align 8
  %129 = getelementptr double, ptr %128, i64 65
  %unmaskedload37 = load <1 x double>, ptr %129, align 8
  %130 = getelementptr double, ptr %128, i64 130
  %unmaskedload38 = load <1 x double>, ptr %130, align 8
  %131 = getelementptr double, ptr %128, i64 195
  %unmaskedload39 = load <1 x double>, ptr %131, align 8
  %132 = getelementptr double, ptr %8, i64 %127
  %133 = load double, ptr %132, align 8
  %134 = shufflevector <1 x double> %unmaskedload36, <1 x double> %unmaskedload37, <2 x i32> <i32 0, i32 1>
  %135 = insertelement <2 x double> poison, double %133, i64 0
  %136 = shufflevector <2 x double> %135, <2 x double> poison, <2 x i32> zeroinitializer
  %137 = fmul <2 x double> %134, %136
  %138 = shufflevector <1 x double> %unmaskedload38, <1 x double> %unmaskedload39, <2 x i32> <i32 0, i32 1>
  %139 = fmul <2 x double> %138, %136
  %140 = shufflevector <2 x double> %137, <2 x double> %139, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %141 = fadd <4 x double> %126, %140
  store <4 x double> %141, ptr %124, align 8
  %142 = or disjoint i64 %127, 1
  %exitcond.3.not = icmp eq i64 %142, 65
  br i1 %exitcond.3.not, label %.preheader.1, label %143

143:                                              ; preds = %125
  %144 = getelementptr double, ptr %123, i64 %142
  %unmaskedload36.1 = load <1 x double>, ptr %144, align 8
  %145 = getelementptr double, ptr %144, i64 65
  %unmaskedload37.1 = load <1 x double>, ptr %145, align 8
  %146 = getelementptr double, ptr %144, i64 130
  %unmaskedload38.1 = load <1 x double>, ptr %146, align 8
  %147 = getelementptr double, ptr %144, i64 195
  %unmaskedload39.1 = load <1 x double>, ptr %147, align 8
  %148 = getelementptr double, ptr %8, i64 %142
  %149 = load double, ptr %148, align 8
  %150 = shufflevector <1 x double> %unmaskedload36.1, <1 x double> %unmaskedload37.1, <2 x i32> <i32 0, i32 1>
  %151 = insertelement <2 x double> poison, double %149, i64 0
  %152 = shufflevector <2 x double> %151, <2 x double> poison, <2 x i32> zeroinitializer
  %153 = fmul <2 x double> %150, %152
  %154 = shufflevector <1 x double> %unmaskedload38.1, <1 x double> %unmaskedload39.1, <2 x i32> <i32 0, i32 1>
  %155 = fmul <2 x double> %154, %152
  %156 = shufflevector <2 x double> %153, <2 x double> %155, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %157 = fadd <4 x double> %141, %156
  store <4 x double> %157, ptr %124, align 8
  %158 = add nuw nsw i64 %127, 2
  br label %125

.preheader.1:                                     ; preds = %125
  %159 = getelementptr double, ptr %13, i64 16
  %160 = getelementptr double, ptr %1, i64 1040
  %.promoted62 = load <4 x double>, ptr %159, align 8
  br label %161

161:                                              ; preds = %179, %.preheader.1
  %162 = phi <4 x double> [ %.promoted62, %.preheader.1 ], [ %193, %179 ]
  %163 = phi i64 [ 0, %.preheader.1 ], [ %194, %179 ]
  %164 = getelementptr double, ptr %160, i64 %163
  %unmaskedload41 = load <1 x double>, ptr %164, align 8
  %165 = getelementptr double, ptr %164, i64 65
  %unmaskedload42 = load <1 x double>, ptr %165, align 8
  %166 = getelementptr double, ptr %164, i64 130
  %unmaskedload43 = load <1 x double>, ptr %166, align 8
  %167 = getelementptr double, ptr %164, i64 195
  %unmaskedload44 = load <1 x double>, ptr %167, align 8
  %168 = getelementptr double, ptr %8, i64 %163
  %169 = load double, ptr %168, align 8
  %170 = shufflevector <1 x double> %unmaskedload41, <1 x double> %unmaskedload42, <2 x i32> <i32 0, i32 1>
  %171 = insertelement <2 x double> poison, double %169, i64 0
  %172 = shufflevector <2 x double> %171, <2 x double> poison, <2 x i32> zeroinitializer
  %173 = fmul <2 x double> %170, %172
  %174 = shufflevector <1 x double> %unmaskedload43, <1 x double> %unmaskedload44, <2 x i32> <i32 0, i32 1>
  %175 = fmul <2 x double> %174, %172
  %176 = shufflevector <2 x double> %173, <2 x double> %175, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %177 = fadd <4 x double> %162, %176
  store <4 x double> %177, ptr %159, align 8
  %178 = or disjoint i64 %163, 1
  %exitcond.1.not = icmp eq i64 %178, 65
  br i1 %exitcond.1.not, label %.preheader.1.1, label %179

179:                                              ; preds = %161
  %180 = getelementptr double, ptr %160, i64 %178
  %unmaskedload41.1 = load <1 x double>, ptr %180, align 8
  %181 = getelementptr double, ptr %180, i64 65
  %unmaskedload42.1 = load <1 x double>, ptr %181, align 8
  %182 = getelementptr double, ptr %180, i64 130
  %unmaskedload43.1 = load <1 x double>, ptr %182, align 8
  %183 = getelementptr double, ptr %180, i64 195
  %unmaskedload44.1 = load <1 x double>, ptr %183, align 8
  %184 = getelementptr double, ptr %8, i64 %178
  %185 = load double, ptr %184, align 8
  %186 = shufflevector <1 x double> %unmaskedload41.1, <1 x double> %unmaskedload42.1, <2 x i32> <i32 0, i32 1>
  %187 = insertelement <2 x double> poison, double %185, i64 0
  %188 = shufflevector <2 x double> %187, <2 x double> poison, <2 x i32> zeroinitializer
  %189 = fmul <2 x double> %186, %188
  %190 = shufflevector <1 x double> %unmaskedload43.1, <1 x double> %unmaskedload44.1, <2 x i32> <i32 0, i32 1>
  %191 = fmul <2 x double> %190, %188
  %192 = shufflevector <2 x double> %189, <2 x double> %191, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %193 = fadd <4 x double> %177, %192
  store <4 x double> %193, ptr %159, align 8
  %194 = add nuw nsw i64 %163, 2
  br label %161

.preheader.1.1:                                   ; preds = %161
  %195 = getelementptr double, ptr %1, i64 1300
  %196 = getelementptr double, ptr %13, i64 20
  %.promoted63 = load <4 x double>, ptr %196, align 8
  br label %197

197:                                              ; preds = %215, %.preheader.1.1
  %198 = phi <4 x double> [ %.promoted63, %.preheader.1.1 ], [ %229, %215 ]
  %199 = phi i64 [ 0, %.preheader.1.1 ], [ %230, %215 ]
  %200 = getelementptr double, ptr %195, i64 %199
  %unmaskedload46 = load <1 x double>, ptr %200, align 8
  %201 = getelementptr double, ptr %200, i64 65
  %unmaskedload47 = load <1 x double>, ptr %201, align 8
  %202 = getelementptr double, ptr %200, i64 130
  %unmaskedload48 = load <1 x double>, ptr %202, align 8
  %203 = getelementptr double, ptr %200, i64 195
  %unmaskedload49 = load <1 x double>, ptr %203, align 8
  %204 = getelementptr double, ptr %8, i64 %199
  %205 = load double, ptr %204, align 8
  %206 = shufflevector <1 x double> %unmaskedload46, <1 x double> %unmaskedload47, <2 x i32> <i32 0, i32 1>
  %207 = insertelement <2 x double> poison, double %205, i64 0
  %208 = shufflevector <2 x double> %207, <2 x double> poison, <2 x i32> zeroinitializer
  %209 = fmul <2 x double> %206, %208
  %210 = shufflevector <1 x double> %unmaskedload48, <1 x double> %unmaskedload49, <2 x i32> <i32 0, i32 1>
  %211 = fmul <2 x double> %210, %208
  %212 = shufflevector <2 x double> %209, <2 x double> %211, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %213 = fadd <4 x double> %198, %212
  store <4 x double> %213, ptr %196, align 8
  %214 = or disjoint i64 %199, 1
  %exitcond.1.1.not = icmp eq i64 %214, 65
  br i1 %exitcond.1.1.not, label %.preheader.1.2, label %215

215:                                              ; preds = %197
  %216 = getelementptr double, ptr %195, i64 %214
  %unmaskedload46.1 = load <1 x double>, ptr %216, align 8
  %217 = getelementptr double, ptr %216, i64 65
  %unmaskedload47.1 = load <1 x double>, ptr %217, align 8
  %218 = getelementptr double, ptr %216, i64 130
  %unmaskedload48.1 = load <1 x double>, ptr %218, align 8
  %219 = getelementptr double, ptr %216, i64 195
  %unmaskedload49.1 = load <1 x double>, ptr %219, align 8
  %220 = getelementptr double, ptr %8, i64 %214
  %221 = load double, ptr %220, align 8
  %222 = shufflevector <1 x double> %unmaskedload46.1, <1 x double> %unmaskedload47.1, <2 x i32> <i32 0, i32 1>
  %223 = insertelement <2 x double> poison, double %221, i64 0
  %224 = shufflevector <2 x double> %223, <2 x double> poison, <2 x i32> zeroinitializer
  %225 = fmul <2 x double> %222, %224
  %226 = shufflevector <1 x double> %unmaskedload48.1, <1 x double> %unmaskedload49.1, <2 x i32> <i32 0, i32 1>
  %227 = fmul <2 x double> %226, %224
  %228 = shufflevector <2 x double> %225, <2 x double> %227, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %229 = fadd <4 x double> %213, %228
  store <4 x double> %229, ptr %196, align 8
  %230 = add nuw nsw i64 %199, 2
  br label %197

.preheader.1.2:                                   ; preds = %197
  %231 = getelementptr double, ptr %1, i64 1560
  %232 = getelementptr double, ptr %13, i64 24
  %.promoted64 = load <4 x double>, ptr %232, align 8
  br label %233

233:                                              ; preds = %251, %.preheader.1.2
  %234 = phi <4 x double> [ %.promoted64, %.preheader.1.2 ], [ %265, %251 ]
  %235 = phi i64 [ 0, %.preheader.1.2 ], [ %266, %251 ]
  %236 = getelementptr double, ptr %231, i64 %235
  %unmaskedload51 = load <1 x double>, ptr %236, align 8
  %237 = getelementptr double, ptr %236, i64 65
  %unmaskedload52 = load <1 x double>, ptr %237, align 8
  %238 = getelementptr double, ptr %236, i64 130
  %unmaskedload53 = load <1 x double>, ptr %238, align 8
  %239 = getelementptr double, ptr %236, i64 195
  %unmaskedload54 = load <1 x double>, ptr %239, align 8
  %240 = getelementptr double, ptr %8, i64 %235
  %241 = load double, ptr %240, align 8
  %242 = shufflevector <1 x double> %unmaskedload51, <1 x double> %unmaskedload52, <2 x i32> <i32 0, i32 1>
  %243 = insertelement <2 x double> poison, double %241, i64 0
  %244 = shufflevector <2 x double> %243, <2 x double> poison, <2 x i32> zeroinitializer
  %245 = fmul <2 x double> %242, %244
  %246 = shufflevector <1 x double> %unmaskedload53, <1 x double> %unmaskedload54, <2 x i32> <i32 0, i32 1>
  %247 = fmul <2 x double> %246, %244
  %248 = shufflevector <2 x double> %245, <2 x double> %247, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %249 = fadd <4 x double> %234, %248
  store <4 x double> %249, ptr %232, align 8
  %250 = or disjoint i64 %235, 1
  %exitcond.1.2.not = icmp eq i64 %250, 65
  br i1 %exitcond.1.2.not, label %.preheader.1.3, label %251

251:                                              ; preds = %233
  %252 = getelementptr double, ptr %231, i64 %250
  %unmaskedload51.1 = load <1 x double>, ptr %252, align 8
  %253 = getelementptr double, ptr %252, i64 65
  %unmaskedload52.1 = load <1 x double>, ptr %253, align 8
  %254 = getelementptr double, ptr %252, i64 130
  %unmaskedload53.1 = load <1 x double>, ptr %254, align 8
  %255 = getelementptr double, ptr %252, i64 195
  %unmaskedload54.1 = load <1 x double>, ptr %255, align 8
  %256 = getelementptr double, ptr %8, i64 %250
  %257 = load double, ptr %256, align 8
  %258 = shufflevector <1 x double> %unmaskedload51.1, <1 x double> %unmaskedload52.1, <2 x i32> <i32 0, i32 1>
  %259 = insertelement <2 x double> poison, double %257, i64 0
  %260 = shufflevector <2 x double> %259, <2 x double> poison, <2 x i32> zeroinitializer
  %261 = fmul <2 x double> %258, %260
  %262 = shufflevector <1 x double> %unmaskedload53.1, <1 x double> %unmaskedload54.1, <2 x i32> <i32 0, i32 1>
  %263 = fmul <2 x double> %262, %260
  %264 = shufflevector <2 x double> %261, <2 x double> %263, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %265 = fadd <4 x double> %249, %264
  store <4 x double> %265, ptr %232, align 8
  %266 = add nuw nsw i64 %235, 2
  br label %233

.preheader.1.3:                                   ; preds = %233
  %267 = getelementptr double, ptr %1, i64 1820
  %268 = getelementptr double, ptr %13, i64 28
  br label %269

269:                                              ; preds = %287, %.preheader.1.3
  %270 = phi i64 [ 0, %.preheader.1.3 ], [ %303, %287 ]
  %271 = getelementptr double, ptr %267, i64 %270
  %unmaskedload56 = load <1 x double>, ptr %271, align 8
  %272 = getelementptr double, ptr %271, i64 65
  %unmaskedload57 = load <1 x double>, ptr %272, align 8
  %273 = getelementptr double, ptr %271, i64 130
  %unmaskedload58 = load <1 x double>, ptr %273, align 8
  %274 = getelementptr double, ptr %8, i64 %270
  %275 = load double, ptr %274, align 8
  %276 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %268, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %277 = shufflevector <1 x double> %unmaskedload56, <1 x double> %unmaskedload57, <2 x i32> <i32 0, i32 1>
  %278 = insertelement <2 x double> poison, double %275, i64 0
  %279 = shufflevector <2 x double> %278, <2 x double> poison, <2 x i32> zeroinitializer
  %280 = fmul <2 x double> %277, %279
  %281 = shufflevector <2 x double> %280, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %282 = extractelement <1 x double> %unmaskedload58, i64 0
  %283 = fmul double %282, %275
  %284 = insertelement <4 x double> %281, double %283, i64 2
  %285 = fadd <4 x double> %276, %284
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %285, ptr %268, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %286 = or disjoint i64 %270, 1
  %exitcond.1.3.not = icmp eq i64 %286, 65
  br i1 %exitcond.1.3.not, label %304, label %287

287:                                              ; preds = %269
  %288 = getelementptr double, ptr %267, i64 %286
  %unmaskedload56.1 = load <1 x double>, ptr %288, align 8
  %289 = getelementptr double, ptr %288, i64 65
  %unmaskedload57.1 = load <1 x double>, ptr %289, align 8
  %290 = getelementptr double, ptr %288, i64 130
  %unmaskedload58.1 = load <1 x double>, ptr %290, align 8
  %291 = getelementptr double, ptr %8, i64 %286
  %292 = load double, ptr %291, align 8
  %293 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %268, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %294 = shufflevector <1 x double> %unmaskedload56.1, <1 x double> %unmaskedload57.1, <2 x i32> <i32 0, i32 1>
  %295 = insertelement <2 x double> poison, double %292, i64 0
  %296 = shufflevector <2 x double> %295, <2 x double> poison, <2 x i32> zeroinitializer
  %297 = fmul <2 x double> %294, %296
  %298 = shufflevector <2 x double> %297, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %299 = extractelement <1 x double> %unmaskedload58.1, i64 0
  %300 = fmul double %299, %292
  %301 = insertelement <4 x double> %298, double %300, i64 2
  %302 = fadd <4 x double> %293, %301
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %302, ptr %268, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %303 = add nuw nsw i64 %270, 2
  br label %269

304:                                              ; preds = %269
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
