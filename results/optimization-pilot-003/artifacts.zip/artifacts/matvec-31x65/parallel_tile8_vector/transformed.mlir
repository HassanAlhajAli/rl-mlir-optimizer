#map = affine_map<(d0) -> (-d0 + 31, 8)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0, d1) -> (d0 - d1, 4)>
#map3 = affine_map<(d0) -> (0, d0)>
module {
  func.func @kernel(%arg0: memref<31x65xf64>, %arg1: memref<65xf64>, %arg2: memref<31xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c1 = arith.constant 1 : index
    %c8 = arith.constant 8 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<31xf64>)
    %c0_0 = arith.constant 0 : index
    %c31 = arith.constant 31 : index
    %c8_1 = arith.constant 8 : index
    scf.for %arg3 = %c0_0 to %c31 step %c8_1 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 65] [1, 1] : memref<31x65xf64> to memref<?x65xf64, strided<[65, 1], offset: ?>>
      %subview_2 = memref.subview %arg2[%arg3] [%1] [1] : memref<31xf64> to memref<?xf64, strided<[1], offset: ?>>
      %c0_3 = arith.constant 0 : index
      %c0_4 = arith.constant 0 : index
      %c0_5 = arith.constant 0 : index
      %c4_6 = arith.constant 4 : index
      %c0_7 = arith.constant 0 : index
      %c65 = arith.constant 65 : index
      %c1_8 = arith.constant 1 : index
      scf.for %arg4 = %c0_5 to %0 step %c4_6 {
        scf.for %arg5 = %c0_7 to %c65 step %c1_8 {
          %2 = affine.apply #map1(%0)
          %3 = affine.apply #map1(%0)
          %4 = affine.min #map2(%0, %arg4)
          %5 = affine.apply #map1(%0)
          %6 = affine.apply #map1(%0)
          %7 = affine.min #map2(%0, %arg4)
          %subview_9 = memref.subview %subview[%arg4, %arg5] [%4, 1] [1, 1] : memref<?x65xf64, strided<[65, 1], offset: ?>> to memref<?x1xf64, strided<[65, 1], offset: ?>>
          %subview_10 = memref.subview %arg1[%arg5] [1] [1] : memref<65xf64> to memref<1xf64, strided<[1], offset: ?>>
          %subview_11 = memref.subview %subview_2[%arg4] [%7] [1] : memref<?xf64, strided<[1], offset: ?>> to memref<?xf64, strided<[1], offset: ?>>
          %c0_12 = arith.constant 0 : index
          %dim = memref.dim %subview_9, %c0_12 : memref<?x1xf64, strided<[65, 1], offset: ?>>
          %c1_13 = arith.constant 1 : index
          %c0_14 = arith.constant 0 : index
          %cst_15 = arith.constant 0.000000e+00 : f64
          %8 = vector.create_mask %dim, %c1_13 : vector<4x1xi1>
          %9 = vector.mask %8 { vector.transfer_read %subview_9[%c0_14, %c0_14], %cst_15 {in_bounds = [true, true]} : memref<?x1xf64, strided<[65, 1], offset: ?>>, vector<4x1xf64> } : vector<4x1xi1> -> vector<4x1xf64>
          %cst_16 = arith.constant 0.000000e+00 : f64
          %10 = vector.transfer_read %subview_10[%c0_14], %cst_16 {permutation_map = #map3} : memref<1xf64, strided<[1], offset: ?>>, vector<4x1xf64>
          %cst_17 = arith.constant 0.000000e+00 : f64
          %11 = vector.create_mask %dim : vector<4xi1>
          %12 = vector.mask %11 { vector.transfer_read %subview_11[%c0_14], %cst_17 {in_bounds = [true]} : memref<?xf64, strided<[1], offset: ?>>, vector<4xf64> } : vector<4xi1> -> vector<4xf64>
          %13 = arith.mulf %9, %10 : vector<4x1xf64>
          %14 = vector.mask %8 { vector.multi_reduction <add>, %13, %12 [1] : vector<4x1xf64> to vector<4xf64> } : vector<4x1xi1> -> vector<4xf64>
          %c0_18 = arith.constant 0 : index
          vector.mask %11 { vector.transfer_write %14, %subview_11[%c0_18] {in_bounds = [true]} : vector<4xf64>, memref<?xf64, strided<[1], offset: ?>> } : vector<4xi1>
        }
      }
    }
    return
  }
}
