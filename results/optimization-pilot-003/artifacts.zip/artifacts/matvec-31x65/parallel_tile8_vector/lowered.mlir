module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<4xf64>) : vector<4xf64>
    %22 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %23 = llvm.mlir.constant(dense<0.000000e+00> : vector<1xf64>) : vector<1xf64>
    %24 = llvm.mlir.constant(3 : index) : i64
    %25 = llvm.mlir.constant(2 : index) : i64
    %26 = llvm.mlir.constant(dense<false> : vector<4x1xi1>) : !llvm.array<4 x vector<1xi1>>
    %27 = llvm.mlir.constant(dense<false> : vector<1xi1>) : vector<1xi1>
    %28 = llvm.mlir.constant(dense<true> : vector<1xi1>) : vector<1xi1>
    %29 = llvm.mlir.constant(-1 : index) : i64
    %30 = llvm.mlir.constant(65 : index) : i64
    %31 = llvm.mlir.constant(31 : index) : i64
    %32 = llvm.mlir.constant(4 : index) : i64
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.mlir.constant(8 : index) : i64
    %35 = llvm.mlir.constant(0 : index) : i64
    %36 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%35 : i64)
  ^bb1(%37: i64):  // 2 preds: ^bb0, ^bb2
    %38 = llvm.icmp "slt" %37, %31 : i64
    llvm.cond_br %38, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %39 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %40 = llvm.getelementptr %39[%37] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %36, %40 : f64, !llvm.ptr
    %41 = llvm.add %37, %33  : i64
    llvm.br ^bb1(%41 : i64)
  ^bb3:  // pred: ^bb1
    %42 = llvm.mlir.constant(1 : index) : i64
    %43 = llvm.alloca %42 x !llvm.array<4 x vector<1xf64>> : (i64) -> !llvm.ptr
    %44 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %45 = llvm.insertvalue %43, %44[0] : !llvm.struct<(ptr, ptr, i64)> 
    %46 = llvm.insertvalue %43, %45[1] : !llvm.struct<(ptr, ptr, i64)> 
    %47 = llvm.mlir.constant(0 : index) : i64
    %48 = llvm.insertvalue %47, %46[2] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.mlir.constant(1 : index) : i64
    %50 = llvm.alloca %49 x !llvm.array<4 x vector<1xi1>> : (i64) -> !llvm.ptr
    %51 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %52 = llvm.insertvalue %50, %51[0] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.insertvalue %50, %52[1] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.mlir.constant(0 : index) : i64
    %55 = llvm.insertvalue %54, %53[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%35 : i64)
  ^bb4(%56: i64):  // 2 preds: ^bb3, ^bb14
    %57 = llvm.icmp "slt" %56, %31 : i64
    llvm.cond_br %57, ^bb5, ^bb15
  ^bb5:  // pred: ^bb4
    %58 = llvm.mul %56, %29  : i64
    %59 = llvm.add %58, %31  : i64
    %60 = llvm.icmp "slt" %59, %34 : i64
    %61 = llvm.select %60, %59, %34 : i1, i64
    %62 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %63 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %64 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %65 = llvm.insertvalue %62, %64[0] : !llvm.struct<(ptr, ptr, i64)> 
    %66 = llvm.insertvalue %63, %65[1] : !llvm.struct<(ptr, ptr, i64)> 
    %67 = llvm.mlir.constant(0 : index) : i64
    %68 = llvm.insertvalue %67, %66[2] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %70 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %71 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %72 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %73 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %74 = llvm.mul %56, %30  : i64
    %75 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %76 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %77 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %78 = llvm.insertvalue %75, %77[0] : !llvm.struct<(ptr, ptr, i64)> 
    %79 = llvm.insertvalue %76, %78[1] : !llvm.struct<(ptr, ptr, i64)> 
    %80 = llvm.mlir.constant(0 : index) : i64
    %81 = llvm.insertvalue %80, %79[2] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %83 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %84 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%35 : i64)
  ^bb6(%85: i64):  // 2 preds: ^bb5, ^bb13
    %86 = llvm.icmp "slt" %85, %61 : i64
    llvm.cond_br %86, ^bb7, ^bb14
  ^bb7:  // pred: ^bb6
    llvm.br ^bb8(%35 : i64)
  ^bb8(%87: i64):  // 2 preds: ^bb7, ^bb12
    %88 = llvm.icmp "slt" %87, %30 : i64
    llvm.cond_br %88, ^bb9, ^bb13
  ^bb9:  // pred: ^bb8
    %89 = llvm.mul %85, %29  : i64
    %90 = llvm.add %61, %89  : i64
    %91 = llvm.icmp "sgt" %90, %32 : i64
    %92 = llvm.select %91, %32, %90 : i1, i64
    %93 = llvm.mul %85, %29  : i64
    %94 = llvm.add %61, %93  : i64
    %95 = llvm.icmp "sgt" %94, %32 : i64
    %96 = llvm.select %95, %32, %94 : i1, i64
    %97 = llvm.mul %85, %30  : i64
    %98 = llvm.add %74, %97  : i64
    %99 = llvm.add %98, %87  : i64
    %100 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %101 = llvm.insertvalue %62, %100[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %102 = llvm.insertvalue %63, %101[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %103 = llvm.insertvalue %99, %102[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.insertvalue %92, %103[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.mlir.constant(65 : index) : i64
    %106 = llvm.insertvalue %105, %104[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.mlir.constant(1 : index) : i64
    %108 = llvm.insertvalue %107, %106[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.mlir.constant(1 : index) : i64
    %110 = llvm.insertvalue %109, %108[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %112 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %113 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %114 = llvm.insertvalue %111, %113[0] : !llvm.struct<(ptr, ptr, i64)> 
    %115 = llvm.insertvalue %112, %114[1] : !llvm.struct<(ptr, ptr, i64)> 
    %116 = llvm.mlir.constant(0 : index) : i64
    %117 = llvm.insertvalue %116, %115[2] : !llvm.struct<(ptr, ptr, i64)> 
    %118 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %119 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %120 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %121 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %122 = llvm.insertvalue %111, %121[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %123 = llvm.insertvalue %112, %122[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %124 = llvm.insertvalue %87, %123[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %125 = llvm.mlir.constant(1 : index) : i64
    %126 = llvm.insertvalue %125, %124[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %127 = llvm.mlir.constant(1 : index) : i64
    %128 = llvm.insertvalue %127, %126[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %129 = llvm.add %56, %85  : i64
    %130 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %131 = llvm.insertvalue %75, %130[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %132 = llvm.insertvalue %76, %131[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %133 = llvm.insertvalue %129, %132[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %134 = llvm.insertvalue %96, %133[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %135 = llvm.mlir.constant(1 : index) : i64
    %136 = llvm.insertvalue %135, %134[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %137 = llvm.icmp "sgt" %92, %35 : i64
    %138 = llvm.select %137, %28, %27 : i1, vector<1xi1>
    %139 = llvm.insertvalue %138, %26[0] : !llvm.array<4 x vector<1xi1>> 
    %140 = llvm.icmp "sgt" %92, %33 : i64
    %141 = llvm.select %140, %28, %27 : i1, vector<1xi1>
    %142 = llvm.insertvalue %141, %139[1] : !llvm.array<4 x vector<1xi1>> 
    %143 = llvm.icmp "sgt" %92, %25 : i64
    %144 = llvm.select %143, %28, %27 : i1, vector<1xi1>
    %145 = llvm.insertvalue %144, %142[2] : !llvm.array<4 x vector<1xi1>> 
    %146 = llvm.icmp "sgt" %92, %24 : i64
    %147 = llvm.select %146, %28, %27 : i1, vector<1xi1>
    %148 = llvm.insertvalue %147, %145[3] : !llvm.array<4 x vector<1xi1>> 
    llvm.store %148, %50 : !llvm.array<4 x vector<1xi1>>, !llvm.ptr
    %149 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %150 = llvm.extractvalue %48[0] : !llvm.struct<(ptr, ptr, i64)> 
    %151 = llvm.insertvalue %150, %149[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %152 = llvm.extractvalue %48[1] : !llvm.struct<(ptr, ptr, i64)> 
    %153 = llvm.insertvalue %152, %151[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %154 = llvm.mlir.constant(0 : index) : i64
    %155 = llvm.insertvalue %154, %153[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.mlir.constant(4 : index) : i64
    %157 = llvm.insertvalue %156, %155[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.mlir.constant(1 : index) : i64
    %159 = llvm.insertvalue %158, %157[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %161 = llvm.extractvalue %55[0] : !llvm.struct<(ptr, ptr, i64)> 
    %162 = llvm.insertvalue %161, %160[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %163 = llvm.extractvalue %55[1] : !llvm.struct<(ptr, ptr, i64)> 
    %164 = llvm.insertvalue %163, %162[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.mlir.constant(0 : index) : i64
    %166 = llvm.insertvalue %165, %164[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.mlir.constant(4 : index) : i64
    %168 = llvm.insertvalue %167, %166[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.mlir.constant(1 : index) : i64
    %170 = llvm.insertvalue %169, %168[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb10(%35 : i64)
  ^bb10(%171: i64):  // 2 preds: ^bb9, ^bb11
    %172 = llvm.icmp "slt" %171, %32 : i64
    llvm.cond_br %172, ^bb11, ^bb12
  ^bb11:  // pred: ^bb10
    %173 = llvm.getelementptr %163[%171] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xi1>
    %174 = llvm.load %173 : !llvm.ptr -> vector<1xi1>
    %175 = llvm.extractvalue %110[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %176 = llvm.extractvalue %110[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %177 = llvm.getelementptr %175[%176] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %178 = llvm.mlir.constant(65 : index) : i64
    %179 = llvm.mul %171, %178  : i64
    %180 = llvm.add %179, %35  : i64
    %181 = llvm.getelementptr %177[%180] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %182 = llvm.intr.masked.load %181, %174, %23 {alignment = 8 : i32} : (!llvm.ptr, vector<1xi1>, vector<1xf64>) -> vector<1xf64>
    %183 = llvm.getelementptr %152[%171] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %182, %183 : vector<1xf64>, !llvm.ptr
    %184 = llvm.add %171, %33  : i64
    llvm.br ^bb10(%184 : i64)
  ^bb12:  // pred: ^bb10
    %185 = llvm.load %43 : !llvm.ptr -> !llvm.array<4 x vector<1xf64>>
    %186 = llvm.getelementptr %112[%87] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %187 = llvm.getelementptr %186[%35] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %188 = llvm.load %187 : !llvm.ptr -> f64
    %189 = llvm.mlir.undef : vector<1xf64>
    %190 = llvm.mlir.constant(0 : i32) : i32
    %191 = llvm.insertelement %188, %189[%190 : i32] : vector<1xf64>
    %192 = llvm.shufflevector %191, %189 [0] : vector<1xf64> 
    %193 = llvm.insertvalue %192, %22[0] : !llvm.array<4 x vector<1xf64>> 
    %194 = llvm.insertvalue %192, %193[1] : !llvm.array<4 x vector<1xf64>> 
    %195 = llvm.insertvalue %192, %194[2] : !llvm.array<4 x vector<1xf64>> 
    %196 = llvm.insertvalue %192, %195[3] : !llvm.array<4 x vector<1xf64>> 
    %197 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %198 = llvm.trunc %92 : i64 to i32
    %199 = llvm.mlir.undef : vector<4xi32>
    %200 = llvm.mlir.constant(0 : i32) : i32
    %201 = llvm.insertelement %198, %199[%200 : i32] : vector<4xi32>
    %202 = llvm.shufflevector %201, %199 [0, 0, 0, 0] : vector<4xi32> 
    %203 = llvm.icmp "sgt" %202, %197 : vector<4xi32>
    %204 = llvm.extractvalue %136[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %205 = llvm.extractvalue %136[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %206 = llvm.getelementptr %204[%205] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %207 = llvm.getelementptr %206[%35] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %208 = llvm.intr.masked.load %207, %203, %21 {alignment = 8 : i32} : (!llvm.ptr, vector<4xi1>, vector<4xf64>) -> vector<4xf64>
    %209 = llvm.mlir.undef : !llvm.array<4 x vector<1xf64>>
    %210 = llvm.extractvalue %185[0] : !llvm.array<4 x vector<1xf64>> 
    %211 = llvm.fmul %210, %192  : vector<1xf64>
    %212 = llvm.insertvalue %211, %209[0] : !llvm.array<4 x vector<1xf64>> 
    %213 = llvm.extractvalue %185[1] : !llvm.array<4 x vector<1xf64>> 
    %214 = llvm.fmul %213, %192  : vector<1xf64>
    %215 = llvm.insertvalue %214, %212[1] : !llvm.array<4 x vector<1xf64>> 
    %216 = llvm.extractvalue %185[2] : !llvm.array<4 x vector<1xf64>> 
    %217 = llvm.fmul %216, %192  : vector<1xf64>
    %218 = llvm.insertvalue %217, %215[2] : !llvm.array<4 x vector<1xf64>> 
    %219 = llvm.extractvalue %185[3] : !llvm.array<4 x vector<1xf64>> 
    %220 = llvm.fmul %219, %192  : vector<1xf64>
    %221 = llvm.insertvalue %220, %218[3] : !llvm.array<4 x vector<1xf64>> 
    %222 = llvm.mlir.constant(dense<[0, 1, 2, 3]> : vector<4xi32>) : vector<4xi32>
    %223 = llvm.trunc %92 : i64 to i32
    %224 = llvm.mlir.undef : vector<4xi32>
    %225 = llvm.mlir.constant(0 : i32) : i32
    %226 = llvm.insertelement %223, %224[%225 : i32] : vector<4xi32>
    %227 = llvm.shufflevector %226, %224 [0, 0, 0, 0] : vector<4xi32> 
    %228 = llvm.icmp "sgt" %227, %222 : vector<4xi32>
    %229 = llvm.extractvalue %221[0] : !llvm.array<4 x vector<1xf64>> 
    %230 = llvm.mlir.constant(0 : i64) : i64
    %231 = llvm.extractelement %229[%230 : i64] : vector<1xf64>
    %232 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<4xf64>> 
    %233 = llvm.mlir.constant(0 : i64) : i64
    %234 = llvm.insertelement %231, %232[%233 : i64] : vector<4xf64>
    %235 = llvm.insertvalue %234, %20[0] : !llvm.array<1 x vector<4xf64>> 
    %236 = llvm.extractvalue %221[1] : !llvm.array<4 x vector<1xf64>> 
    %237 = llvm.mlir.constant(0 : i64) : i64
    %238 = llvm.extractelement %236[%237 : i64] : vector<1xf64>
    %239 = llvm.mlir.constant(1 : i64) : i64
    %240 = llvm.insertelement %238, %234[%239 : i64] : vector<4xf64>
    %241 = llvm.insertvalue %240, %235[0] : !llvm.array<1 x vector<4xf64>> 
    %242 = llvm.extractvalue %221[2] : !llvm.array<4 x vector<1xf64>> 
    %243 = llvm.mlir.constant(0 : i64) : i64
    %244 = llvm.extractelement %242[%243 : i64] : vector<1xf64>
    %245 = llvm.mlir.constant(2 : i64) : i64
    %246 = llvm.insertelement %244, %240[%245 : i64] : vector<4xf64>
    %247 = llvm.insertvalue %246, %241[0] : !llvm.array<1 x vector<4xf64>> 
    %248 = llvm.extractvalue %221[3] : !llvm.array<4 x vector<1xf64>> 
    %249 = llvm.mlir.constant(0 : i64) : i64
    %250 = llvm.extractelement %248[%249 : i64] : vector<1xf64>
    %251 = llvm.mlir.constant(3 : i64) : i64
    %252 = llvm.insertelement %250, %246[%251 : i64] : vector<4xf64>
    %253 = llvm.insertvalue %252, %247[0] : !llvm.array<1 x vector<4xf64>> 
    %254 = llvm.fadd %208, %252  : vector<4xf64>
    %255 = llvm.select %228, %254, %252 : vector<4xi1>, vector<4xf64>
    %256 = llvm.extractvalue %136[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %257 = llvm.extractvalue %136[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %258 = llvm.getelementptr %256[%257] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %259 = llvm.getelementptr %258[%35] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.intr.masked.store %255, %259, %203 {alignment = 8 : i32} : vector<4xf64>, vector<4xi1> into !llvm.ptr
    %260 = llvm.add %87, %33  : i64
    llvm.br ^bb8(%260 : i64)
  ^bb13:  // pred: ^bb8
    %261 = llvm.add %85, %32  : i64
    llvm.br ^bb6(%261 : i64)
  ^bb14:  // pred: ^bb6
    %262 = llvm.add %56, %34  : i64
    llvm.br ^bb4(%262 : i64)
  ^bb15:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
