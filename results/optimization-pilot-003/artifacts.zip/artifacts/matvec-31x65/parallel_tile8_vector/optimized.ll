; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  %invariant.gep = getelementptr double, ptr %1, i64 260
  br label %.preheader

.preheader:                                       ; preds = %17, %67
  %18 = phi i64 [ 0, %17 ], [ %68, %67 ]
  %.not = icmp eq i64 %18, 24
  %19 = getelementptr double, ptr %13, i64 %18
  %20 = mul nuw nsw i64 %18, 65
  %21 = getelementptr double, ptr %1, i64 %20
  %.promoted = load <4 x double>, ptr %19, align 8
  br label %22

22:                                               ; preds = %.preheader, %22
  %23 = phi <4 x double> [ %.promoted, %.preheader ], [ %38, %22 ]
  %24 = phi i64 [ 0, %.preheader ], [ %39, %22 ]
  %25 = getelementptr double, ptr %21, i64 %24
  %unmaskedload = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %25, i64 65
  %unmaskedload16 = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %25, i64 130
  %unmaskedload17 = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %25, i64 195
  %unmaskedload18 = load <1 x double>, ptr %28, align 8
  %29 = getelementptr double, ptr %8, i64 %24
  %30 = load double, ptr %29, align 8
  %31 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload16, <2 x i32> <i32 0, i32 1>
  %32 = insertelement <2 x double> poison, double %30, i64 0
  %33 = shufflevector <2 x double> %32, <2 x double> poison, <2 x i32> zeroinitializer
  %34 = fmul <2 x double> %31, %33
  %35 = shufflevector <1 x double> %unmaskedload17, <1 x double> %unmaskedload18, <2 x i32> <i32 0, i32 1>
  %36 = fmul <2 x double> %35, %33
  %37 = shufflevector <2 x double> %34, <2 x double> %36, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %38 = fadd <4 x double> %23, %37
  store <4 x double> %38, ptr %19, align 8
  %39 = add nuw nsw i64 %24, 1
  %exitcond.not = icmp eq i64 %39, 65
  br i1 %exitcond.not, label %.preheader.1, label %22

.preheader.1:                                     ; preds = %22
  %40 = mul nuw i64 %18, 65
  %41 = select i1 %.not, <1 x i1> zeroinitializer, <1 x i1> <i1 true>
  %gep = getelementptr double, ptr %invariant.gep, i64 %40
  %42 = select i1 %.not, i32 3, i32 4
  %43 = insertelement <4 x i32> poison, i32 %42, i64 0
  %44 = shufflevector <4 x i32> %43, <4 x i32> poison, <4 x i32> zeroinitializer
  %45 = icmp ugt <4 x i32> %44, <i32 0, i32 1, i32 2, i32 3>
  %46 = getelementptr double, ptr %19, i64 4
  br label %47

47:                                               ; preds = %47, %.preheader.1
  %48 = phi i64 [ 0, %.preheader.1 ], [ %66, %47 ]
  %49 = getelementptr double, ptr %gep, i64 %48
  %unmaskedload20 = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %49, i64 65
  %unmaskedload21 = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %49, i64 130
  %unmaskedload22 = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %49, i64 195
  %53 = tail call <1 x double> @llvm.masked.load.v1f64.p0(ptr %52, i32 8, <1 x i1> %41, <1 x double> zeroinitializer)
  %54 = getelementptr double, ptr %8, i64 %48
  %55 = load double, ptr %54, align 8
  %56 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %46, i32 8, <4 x i1> %45, <4 x double> zeroinitializer)
  %57 = shufflevector <1 x double> %unmaskedload20, <1 x double> %unmaskedload21, <2 x i32> <i32 0, i32 1>
  %58 = insertelement <2 x double> poison, double %55, i64 0
  %59 = shufflevector <2 x double> %58, <2 x double> poison, <2 x i32> zeroinitializer
  %60 = fmul <2 x double> %57, %59
  %61 = shufflevector <1 x double> %unmaskedload22, <1 x double> %53, <2 x i32> <i32 0, i32 1>
  %62 = fmul <2 x double> %61, %59
  %63 = shufflevector <2 x double> %60, <2 x double> %62, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %64 = select <4 x i1> %45, <4 x double> %56, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %65 = fadd <4 x double> %64, %63
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %65, ptr %46, i32 8, <4 x i1> %45)
  %66 = add nuw nsw i64 %48, 1
  %exitcond.not.1 = icmp eq i64 %66, 65
  br i1 %exitcond.not.1, label %67, label %47

67:                                               ; preds = %47
  %68 = add nuw nsw i64 %18, 8
  %69 = icmp ult i64 %18, 23
  br i1 %69, label %.preheader, label %70

70:                                               ; preds = %67
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
.preheader.i:
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %3

3:                                                ; preds = %21, %.preheader.i
  %4 = phi <4 x double> [ zeroinitializer, %.preheader.i ], [ %35, %21 ]
  %5 = phi i64 [ 0, %.preheader.i ], [ %36, %21 ]
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %unmaskedload = load <1 x double>, ptr %6, align 8
  %7 = getelementptr double, ptr %6, i64 65
  %unmaskedload39 = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %6, i64 130
  %unmaskedload40 = load <1 x double>, ptr %8, align 8
  %9 = getelementptr double, ptr %6, i64 195
  %unmaskedload41 = load <1 x double>, ptr %9, align 8
  %10 = getelementptr double, ptr %.unpack17, i64 %5
  %11 = load double, ptr %10, align 8
  %12 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload39, <2 x i32> <i32 0, i32 1>
  %13 = insertelement <2 x double> poison, double %11, i64 0
  %14 = shufflevector <2 x double> %13, <2 x double> poison, <2 x i32> zeroinitializer
  %15 = fmul <2 x double> %12, %14
  %16 = shufflevector <1 x double> %unmaskedload40, <1 x double> %unmaskedload41, <2 x i32> <i32 0, i32 1>
  %17 = fmul <2 x double> %16, %14
  %18 = shufflevector <2 x double> %15, <2 x double> %17, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %19 = fadd <4 x double> %4, %18
  store <4 x double> %19, ptr %.unpack28, align 8
  %20 = or disjoint i64 %5, 1
  %exitcond.not.i = icmp eq i64 %20, 65
  br i1 %exitcond.not.i, label %.preheader.i.137, label %21

21:                                               ; preds = %3
  %22 = getelementptr double, ptr %.unpack2, i64 %20
  %unmaskedload.1 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %22, i64 65
  %unmaskedload39.1 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %22, i64 130
  %unmaskedload40.1 = load <1 x double>, ptr %24, align 8
  %25 = getelementptr double, ptr %22, i64 195
  %unmaskedload41.1 = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %.unpack17, i64 %20
  %27 = load double, ptr %26, align 8
  %28 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload39.1, <2 x i32> <i32 0, i32 1>
  %29 = insertelement <2 x double> poison, double %27, i64 0
  %30 = shufflevector <2 x double> %29, <2 x double> poison, <2 x i32> zeroinitializer
  %31 = fmul <2 x double> %28, %30
  %32 = shufflevector <1 x double> %unmaskedload40.1, <1 x double> %unmaskedload41.1, <2 x i32> <i32 0, i32 1>
  %33 = fmul <2 x double> %32, %30
  %34 = shufflevector <2 x double> %31, <2 x double> %33, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %35 = fadd <4 x double> %19, %34
  store <4 x double> %35, ptr %.unpack28, align 8
  %36 = add nuw nsw i64 %5, 2
  br label %3

.preheader.i.137:                                 ; preds = %3
  %37 = getelementptr double, ptr %.unpack2, i64 260
  %38 = getelementptr double, ptr %.unpack28, i64 4
  %.promoted = load <4 x double>, ptr %38, align 8
  br label %39

39:                                               ; preds = %57, %.preheader.i.137
  %40 = phi <4 x double> [ %.promoted, %.preheader.i.137 ], [ %71, %57 ]
  %41 = phi i64 [ 0, %.preheader.i.137 ], [ %72, %57 ]
  %42 = getelementptr double, ptr %37, i64 %41
  %unmaskedload43 = load <1 x double>, ptr %42, align 8
  %43 = getelementptr double, ptr %42, i64 65
  %unmaskedload44 = load <1 x double>, ptr %43, align 8
  %44 = getelementptr double, ptr %42, i64 130
  %unmaskedload45 = load <1 x double>, ptr %44, align 8
  %45 = getelementptr double, ptr %42, i64 195
  %unmaskedload46 = load <1 x double>, ptr %45, align 8
  %46 = getelementptr double, ptr %.unpack17, i64 %41
  %47 = load double, ptr %46, align 8
  %48 = shufflevector <1 x double> %unmaskedload43, <1 x double> %unmaskedload44, <2 x i32> <i32 0, i32 1>
  %49 = insertelement <2 x double> poison, double %47, i64 0
  %50 = shufflevector <2 x double> %49, <2 x double> poison, <2 x i32> zeroinitializer
  %51 = fmul <2 x double> %48, %50
  %52 = shufflevector <1 x double> %unmaskedload45, <1 x double> %unmaskedload46, <2 x i32> <i32 0, i32 1>
  %53 = fmul <2 x double> %52, %50
  %54 = shufflevector <2 x double> %51, <2 x double> %53, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %55 = fadd <4 x double> %40, %54
  store <4 x double> %55, ptr %38, align 8
  %56 = or disjoint i64 %41, 1
  %exitcond.not.i.138 = icmp eq i64 %56, 65
  br i1 %exitcond.not.i.138, label %.preheader.i.1, label %57

57:                                               ; preds = %39
  %58 = getelementptr double, ptr %37, i64 %56
  %unmaskedload43.1 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %58, i64 65
  %unmaskedload44.1 = load <1 x double>, ptr %59, align 8
  %60 = getelementptr double, ptr %58, i64 130
  %unmaskedload45.1 = load <1 x double>, ptr %60, align 8
  %61 = getelementptr double, ptr %58, i64 195
  %unmaskedload46.1 = load <1 x double>, ptr %61, align 8
  %62 = getelementptr double, ptr %.unpack17, i64 %56
  %63 = load double, ptr %62, align 8
  %64 = shufflevector <1 x double> %unmaskedload43.1, <1 x double> %unmaskedload44.1, <2 x i32> <i32 0, i32 1>
  %65 = insertelement <2 x double> poison, double %63, i64 0
  %66 = shufflevector <2 x double> %65, <2 x double> poison, <2 x i32> zeroinitializer
  %67 = fmul <2 x double> %64, %66
  %68 = shufflevector <1 x double> %unmaskedload45.1, <1 x double> %unmaskedload46.1, <2 x i32> <i32 0, i32 1>
  %69 = fmul <2 x double> %68, %66
  %70 = shufflevector <2 x double> %67, <2 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %71 = fadd <4 x double> %55, %70
  store <4 x double> %71, ptr %38, align 8
  %72 = add nuw nsw i64 %41, 2
  br label %39

.preheader.i.1:                                   ; preds = %39
  %73 = getelementptr double, ptr %.unpack28, i64 8
  %74 = getelementptr double, ptr %.unpack2, i64 520
  %.promoted76 = load <4 x double>, ptr %73, align 8
  br label %75

75:                                               ; preds = %93, %.preheader.i.1
  %76 = phi <4 x double> [ %.promoted76, %.preheader.i.1 ], [ %107, %93 ]
  %77 = phi i64 [ 0, %.preheader.i.1 ], [ %108, %93 ]
  %78 = getelementptr double, ptr %74, i64 %77
  %unmaskedload48 = load <1 x double>, ptr %78, align 8
  %79 = getelementptr double, ptr %78, i64 65
  %unmaskedload49 = load <1 x double>, ptr %79, align 8
  %80 = getelementptr double, ptr %78, i64 130
  %unmaskedload50 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %78, i64 195
  %unmaskedload51 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %.unpack17, i64 %77
  %83 = load double, ptr %82, align 8
  %84 = shufflevector <1 x double> %unmaskedload48, <1 x double> %unmaskedload49, <2 x i32> <i32 0, i32 1>
  %85 = insertelement <2 x double> poison, double %83, i64 0
  %86 = shufflevector <2 x double> %85, <2 x double> poison, <2 x i32> zeroinitializer
  %87 = fmul <2 x double> %84, %86
  %88 = shufflevector <1 x double> %unmaskedload50, <1 x double> %unmaskedload51, <2 x i32> <i32 0, i32 1>
  %89 = fmul <2 x double> %88, %86
  %90 = shufflevector <2 x double> %87, <2 x double> %89, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %91 = fadd <4 x double> %76, %90
  store <4 x double> %91, ptr %73, align 8
  %92 = or disjoint i64 %77, 1
  %exitcond.not.i.1 = icmp eq i64 %92, 65
  br i1 %exitcond.not.i.1, label %.preheader.i.1.1, label %93

93:                                               ; preds = %75
  %94 = getelementptr double, ptr %74, i64 %92
  %unmaskedload48.1 = load <1 x double>, ptr %94, align 8
  %95 = getelementptr double, ptr %94, i64 65
  %unmaskedload49.1 = load <1 x double>, ptr %95, align 8
  %96 = getelementptr double, ptr %94, i64 130
  %unmaskedload50.1 = load <1 x double>, ptr %96, align 8
  %97 = getelementptr double, ptr %94, i64 195
  %unmaskedload51.1 = load <1 x double>, ptr %97, align 8
  %98 = getelementptr double, ptr %.unpack17, i64 %92
  %99 = load double, ptr %98, align 8
  %100 = shufflevector <1 x double> %unmaskedload48.1, <1 x double> %unmaskedload49.1, <2 x i32> <i32 0, i32 1>
  %101 = insertelement <2 x double> poison, double %99, i64 0
  %102 = shufflevector <2 x double> %101, <2 x double> poison, <2 x i32> zeroinitializer
  %103 = fmul <2 x double> %100, %102
  %104 = shufflevector <1 x double> %unmaskedload50.1, <1 x double> %unmaskedload51.1, <2 x i32> <i32 0, i32 1>
  %105 = fmul <2 x double> %104, %102
  %106 = shufflevector <2 x double> %103, <2 x double> %105, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %107 = fadd <4 x double> %91, %106
  store <4 x double> %107, ptr %73, align 8
  %108 = add nuw nsw i64 %77, 2
  br label %75

.preheader.i.1.1:                                 ; preds = %75
  %109 = getelementptr double, ptr %.unpack2, i64 780
  %110 = getelementptr double, ptr %.unpack28, i64 12
  %.promoted77 = load <4 x double>, ptr %110, align 8
  br label %111

111:                                              ; preds = %129, %.preheader.i.1.1
  %112 = phi <4 x double> [ %.promoted77, %.preheader.i.1.1 ], [ %143, %129 ]
  %113 = phi i64 [ 0, %.preheader.i.1.1 ], [ %144, %129 ]
  %114 = getelementptr double, ptr %109, i64 %113
  %unmaskedload53 = load <1 x double>, ptr %114, align 8
  %115 = getelementptr double, ptr %114, i64 65
  %unmaskedload54 = load <1 x double>, ptr %115, align 8
  %116 = getelementptr double, ptr %114, i64 130
  %unmaskedload55 = load <1 x double>, ptr %116, align 8
  %117 = getelementptr double, ptr %114, i64 195
  %unmaskedload56 = load <1 x double>, ptr %117, align 8
  %118 = getelementptr double, ptr %.unpack17, i64 %113
  %119 = load double, ptr %118, align 8
  %120 = shufflevector <1 x double> %unmaskedload53, <1 x double> %unmaskedload54, <2 x i32> <i32 0, i32 1>
  %121 = insertelement <2 x double> poison, double %119, i64 0
  %122 = shufflevector <2 x double> %121, <2 x double> poison, <2 x i32> zeroinitializer
  %123 = fmul <2 x double> %120, %122
  %124 = shufflevector <1 x double> %unmaskedload55, <1 x double> %unmaskedload56, <2 x i32> <i32 0, i32 1>
  %125 = fmul <2 x double> %124, %122
  %126 = shufflevector <2 x double> %123, <2 x double> %125, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %127 = fadd <4 x double> %112, %126
  store <4 x double> %127, ptr %110, align 8
  %128 = or disjoint i64 %113, 1
  %exitcond.not.i.1.1 = icmp eq i64 %128, 65
  br i1 %exitcond.not.i.1.1, label %.preheader.i.2, label %129

129:                                              ; preds = %111
  %130 = getelementptr double, ptr %109, i64 %128
  %unmaskedload53.1 = load <1 x double>, ptr %130, align 8
  %131 = getelementptr double, ptr %130, i64 65
  %unmaskedload54.1 = load <1 x double>, ptr %131, align 8
  %132 = getelementptr double, ptr %130, i64 130
  %unmaskedload55.1 = load <1 x double>, ptr %132, align 8
  %133 = getelementptr double, ptr %130, i64 195
  %unmaskedload56.1 = load <1 x double>, ptr %133, align 8
  %134 = getelementptr double, ptr %.unpack17, i64 %128
  %135 = load double, ptr %134, align 8
  %136 = shufflevector <1 x double> %unmaskedload53.1, <1 x double> %unmaskedload54.1, <2 x i32> <i32 0, i32 1>
  %137 = insertelement <2 x double> poison, double %135, i64 0
  %138 = shufflevector <2 x double> %137, <2 x double> poison, <2 x i32> zeroinitializer
  %139 = fmul <2 x double> %136, %138
  %140 = shufflevector <1 x double> %unmaskedload55.1, <1 x double> %unmaskedload56.1, <2 x i32> <i32 0, i32 1>
  %141 = fmul <2 x double> %140, %138
  %142 = shufflevector <2 x double> %139, <2 x double> %141, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %143 = fadd <4 x double> %127, %142
  store <4 x double> %143, ptr %110, align 8
  %144 = add nuw nsw i64 %113, 2
  br label %111

.preheader.i.2:                                   ; preds = %111
  %145 = getelementptr double, ptr %.unpack28, i64 16
  %146 = getelementptr double, ptr %.unpack2, i64 1040
  %.promoted78 = load <4 x double>, ptr %145, align 8
  br label %147

147:                                              ; preds = %165, %.preheader.i.2
  %148 = phi <4 x double> [ %.promoted78, %.preheader.i.2 ], [ %179, %165 ]
  %149 = phi i64 [ 0, %.preheader.i.2 ], [ %180, %165 ]
  %150 = getelementptr double, ptr %146, i64 %149
  %unmaskedload58 = load <1 x double>, ptr %150, align 8
  %151 = getelementptr double, ptr %150, i64 65
  %unmaskedload59 = load <1 x double>, ptr %151, align 8
  %152 = getelementptr double, ptr %150, i64 130
  %unmaskedload60 = load <1 x double>, ptr %152, align 8
  %153 = getelementptr double, ptr %150, i64 195
  %unmaskedload61 = load <1 x double>, ptr %153, align 8
  %154 = getelementptr double, ptr %.unpack17, i64 %149
  %155 = load double, ptr %154, align 8
  %156 = shufflevector <1 x double> %unmaskedload58, <1 x double> %unmaskedload59, <2 x i32> <i32 0, i32 1>
  %157 = insertelement <2 x double> poison, double %155, i64 0
  %158 = shufflevector <2 x double> %157, <2 x double> poison, <2 x i32> zeroinitializer
  %159 = fmul <2 x double> %156, %158
  %160 = shufflevector <1 x double> %unmaskedload60, <1 x double> %unmaskedload61, <2 x i32> <i32 0, i32 1>
  %161 = fmul <2 x double> %160, %158
  %162 = shufflevector <2 x double> %159, <2 x double> %161, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %163 = fadd <4 x double> %148, %162
  store <4 x double> %163, ptr %145, align 8
  %164 = or disjoint i64 %149, 1
  %exitcond.not.i.2 = icmp eq i64 %164, 65
  br i1 %exitcond.not.i.2, label %.preheader.i.2.1, label %165

165:                                              ; preds = %147
  %166 = getelementptr double, ptr %146, i64 %164
  %unmaskedload58.1 = load <1 x double>, ptr %166, align 8
  %167 = getelementptr double, ptr %166, i64 65
  %unmaskedload59.1 = load <1 x double>, ptr %167, align 8
  %168 = getelementptr double, ptr %166, i64 130
  %unmaskedload60.1 = load <1 x double>, ptr %168, align 8
  %169 = getelementptr double, ptr %166, i64 195
  %unmaskedload61.1 = load <1 x double>, ptr %169, align 8
  %170 = getelementptr double, ptr %.unpack17, i64 %164
  %171 = load double, ptr %170, align 8
  %172 = shufflevector <1 x double> %unmaskedload58.1, <1 x double> %unmaskedload59.1, <2 x i32> <i32 0, i32 1>
  %173 = insertelement <2 x double> poison, double %171, i64 0
  %174 = shufflevector <2 x double> %173, <2 x double> poison, <2 x i32> zeroinitializer
  %175 = fmul <2 x double> %172, %174
  %176 = shufflevector <1 x double> %unmaskedload60.1, <1 x double> %unmaskedload61.1, <2 x i32> <i32 0, i32 1>
  %177 = fmul <2 x double> %176, %174
  %178 = shufflevector <2 x double> %175, <2 x double> %177, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %179 = fadd <4 x double> %163, %178
  store <4 x double> %179, ptr %145, align 8
  %180 = add nuw nsw i64 %149, 2
  br label %147

.preheader.i.2.1:                                 ; preds = %147
  %181 = getelementptr double, ptr %.unpack2, i64 1300
  %182 = getelementptr double, ptr %.unpack28, i64 20
  %.promoted79 = load <4 x double>, ptr %182, align 8
  br label %183

183:                                              ; preds = %201, %.preheader.i.2.1
  %184 = phi <4 x double> [ %.promoted79, %.preheader.i.2.1 ], [ %215, %201 ]
  %185 = phi i64 [ 0, %.preheader.i.2.1 ], [ %216, %201 ]
  %186 = getelementptr double, ptr %181, i64 %185
  %unmaskedload63 = load <1 x double>, ptr %186, align 8
  %187 = getelementptr double, ptr %186, i64 65
  %unmaskedload64 = load <1 x double>, ptr %187, align 8
  %188 = getelementptr double, ptr %186, i64 130
  %unmaskedload65 = load <1 x double>, ptr %188, align 8
  %189 = getelementptr double, ptr %186, i64 195
  %unmaskedload66 = load <1 x double>, ptr %189, align 8
  %190 = getelementptr double, ptr %.unpack17, i64 %185
  %191 = load double, ptr %190, align 8
  %192 = shufflevector <1 x double> %unmaskedload63, <1 x double> %unmaskedload64, <2 x i32> <i32 0, i32 1>
  %193 = insertelement <2 x double> poison, double %191, i64 0
  %194 = shufflevector <2 x double> %193, <2 x double> poison, <2 x i32> zeroinitializer
  %195 = fmul <2 x double> %192, %194
  %196 = shufflevector <1 x double> %unmaskedload65, <1 x double> %unmaskedload66, <2 x i32> <i32 0, i32 1>
  %197 = fmul <2 x double> %196, %194
  %198 = shufflevector <2 x double> %195, <2 x double> %197, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %199 = fadd <4 x double> %184, %198
  store <4 x double> %199, ptr %182, align 8
  %200 = or disjoint i64 %185, 1
  %exitcond.not.i.2.1 = icmp eq i64 %200, 65
  br i1 %exitcond.not.i.2.1, label %.preheader.i.3, label %201

201:                                              ; preds = %183
  %202 = getelementptr double, ptr %181, i64 %200
  %unmaskedload63.1 = load <1 x double>, ptr %202, align 8
  %203 = getelementptr double, ptr %202, i64 65
  %unmaskedload64.1 = load <1 x double>, ptr %203, align 8
  %204 = getelementptr double, ptr %202, i64 130
  %unmaskedload65.1 = load <1 x double>, ptr %204, align 8
  %205 = getelementptr double, ptr %202, i64 195
  %unmaskedload66.1 = load <1 x double>, ptr %205, align 8
  %206 = getelementptr double, ptr %.unpack17, i64 %200
  %207 = load double, ptr %206, align 8
  %208 = shufflevector <1 x double> %unmaskedload63.1, <1 x double> %unmaskedload64.1, <2 x i32> <i32 0, i32 1>
  %209 = insertelement <2 x double> poison, double %207, i64 0
  %210 = shufflevector <2 x double> %209, <2 x double> poison, <2 x i32> zeroinitializer
  %211 = fmul <2 x double> %208, %210
  %212 = shufflevector <1 x double> %unmaskedload65.1, <1 x double> %unmaskedload66.1, <2 x i32> <i32 0, i32 1>
  %213 = fmul <2 x double> %212, %210
  %214 = shufflevector <2 x double> %211, <2 x double> %213, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %215 = fadd <4 x double> %199, %214
  store <4 x double> %215, ptr %182, align 8
  %216 = add nuw nsw i64 %185, 2
  br label %183

.preheader.i.3:                                   ; preds = %183
  %217 = getelementptr double, ptr %.unpack28, i64 24
  %218 = getelementptr double, ptr %.unpack2, i64 1560
  %.promoted80 = load <4 x double>, ptr %217, align 8
  br label %219

219:                                              ; preds = %237, %.preheader.i.3
  %220 = phi <4 x double> [ %.promoted80, %.preheader.i.3 ], [ %251, %237 ]
  %221 = phi i64 [ 0, %.preheader.i.3 ], [ %252, %237 ]
  %222 = getelementptr double, ptr %218, i64 %221
  %unmaskedload68 = load <1 x double>, ptr %222, align 8
  %223 = getelementptr double, ptr %222, i64 65
  %unmaskedload69 = load <1 x double>, ptr %223, align 8
  %224 = getelementptr double, ptr %222, i64 130
  %unmaskedload70 = load <1 x double>, ptr %224, align 8
  %225 = getelementptr double, ptr %222, i64 195
  %unmaskedload71 = load <1 x double>, ptr %225, align 8
  %226 = getelementptr double, ptr %.unpack17, i64 %221
  %227 = load double, ptr %226, align 8
  %228 = shufflevector <1 x double> %unmaskedload68, <1 x double> %unmaskedload69, <2 x i32> <i32 0, i32 1>
  %229 = insertelement <2 x double> poison, double %227, i64 0
  %230 = shufflevector <2 x double> %229, <2 x double> poison, <2 x i32> zeroinitializer
  %231 = fmul <2 x double> %228, %230
  %232 = shufflevector <1 x double> %unmaskedload70, <1 x double> %unmaskedload71, <2 x i32> <i32 0, i32 1>
  %233 = fmul <2 x double> %232, %230
  %234 = shufflevector <2 x double> %231, <2 x double> %233, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %235 = fadd <4 x double> %220, %234
  store <4 x double> %235, ptr %217, align 8
  %236 = or disjoint i64 %221, 1
  %exitcond.not.i.3 = icmp eq i64 %236, 65
  br i1 %exitcond.not.i.3, label %.preheader.i.3.1, label %237

237:                                              ; preds = %219
  %238 = getelementptr double, ptr %218, i64 %236
  %unmaskedload68.1 = load <1 x double>, ptr %238, align 8
  %239 = getelementptr double, ptr %238, i64 65
  %unmaskedload69.1 = load <1 x double>, ptr %239, align 8
  %240 = getelementptr double, ptr %238, i64 130
  %unmaskedload70.1 = load <1 x double>, ptr %240, align 8
  %241 = getelementptr double, ptr %238, i64 195
  %unmaskedload71.1 = load <1 x double>, ptr %241, align 8
  %242 = getelementptr double, ptr %.unpack17, i64 %236
  %243 = load double, ptr %242, align 8
  %244 = shufflevector <1 x double> %unmaskedload68.1, <1 x double> %unmaskedload69.1, <2 x i32> <i32 0, i32 1>
  %245 = insertelement <2 x double> poison, double %243, i64 0
  %246 = shufflevector <2 x double> %245, <2 x double> poison, <2 x i32> zeroinitializer
  %247 = fmul <2 x double> %244, %246
  %248 = shufflevector <1 x double> %unmaskedload70.1, <1 x double> %unmaskedload71.1, <2 x i32> <i32 0, i32 1>
  %249 = fmul <2 x double> %248, %246
  %250 = shufflevector <2 x double> %247, <2 x double> %249, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %251 = fadd <4 x double> %235, %250
  store <4 x double> %251, ptr %217, align 8
  %252 = add nuw nsw i64 %221, 2
  br label %219

.preheader.i.3.1:                                 ; preds = %219
  %253 = getelementptr double, ptr %.unpack2, i64 1820
  %254 = getelementptr double, ptr %.unpack28, i64 28
  br label %255

255:                                              ; preds = %273, %.preheader.i.3.1
  %256 = phi i64 [ 0, %.preheader.i.3.1 ], [ %289, %273 ]
  %257 = getelementptr double, ptr %253, i64 %256
  %unmaskedload73 = load <1 x double>, ptr %257, align 8
  %258 = getelementptr double, ptr %257, i64 65
  %unmaskedload74 = load <1 x double>, ptr %258, align 8
  %259 = getelementptr double, ptr %257, i64 130
  %unmaskedload75 = load <1 x double>, ptr %259, align 8
  %260 = getelementptr double, ptr %.unpack17, i64 %256
  %261 = load double, ptr %260, align 8
  %262 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %254, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %263 = shufflevector <1 x double> %unmaskedload73, <1 x double> %unmaskedload74, <2 x i32> <i32 0, i32 1>
  %264 = insertelement <2 x double> poison, double %261, i64 0
  %265 = shufflevector <2 x double> %264, <2 x double> poison, <2 x i32> zeroinitializer
  %266 = fmul <2 x double> %263, %265
  %267 = shufflevector <2 x double> %266, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %268 = extractelement <1 x double> %unmaskedload75, i64 0
  %269 = fmul double %268, %261
  %270 = insertelement <4 x double> %267, double %269, i64 2
  %271 = fadd <4 x double> %262, %270
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %271, ptr %254, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %272 = or disjoint i64 %256, 1
  %exitcond.not.i.3.1 = icmp eq i64 %272, 65
  br i1 %exitcond.not.i.3.1, label %kernel.exit, label %273

273:                                              ; preds = %255
  %274 = getelementptr double, ptr %253, i64 %272
  %unmaskedload73.1 = load <1 x double>, ptr %274, align 8
  %275 = getelementptr double, ptr %274, i64 65
  %unmaskedload74.1 = load <1 x double>, ptr %275, align 8
  %276 = getelementptr double, ptr %274, i64 130
  %unmaskedload75.1 = load <1 x double>, ptr %276, align 8
  %277 = getelementptr double, ptr %.unpack17, i64 %272
  %278 = load double, ptr %277, align 8
  %279 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %254, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %280 = shufflevector <1 x double> %unmaskedload73.1, <1 x double> %unmaskedload74.1, <2 x i32> <i32 0, i32 1>
  %281 = insertelement <2 x double> poison, double %278, i64 0
  %282 = shufflevector <2 x double> %281, <2 x double> poison, <2 x i32> zeroinitializer
  %283 = fmul <2 x double> %280, %282
  %284 = shufflevector <2 x double> %283, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %285 = extractelement <1 x double> %unmaskedload75.1, i64 0
  %286 = fmul double %285, %278
  %287 = insertelement <4 x double> %284, double %286, i64 2
  %288 = fadd <4 x double> %279, %287
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %288, ptr %254, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %289 = add nuw nsw i64 %256, 2
  br label %255

kernel.exit:                                      ; preds = %255
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <1 x double> @llvm.masked.load.v1f64.p0(ptr nocapture, i32 immarg, <1 x i1>, <1 x double>) #2

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
.preheader.i:
  %1 = getelementptr ptr, ptr %0, i64 1
  %2 = load ptr, ptr %1, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 8
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 13
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %9, i8 0, i64 248, i1 false)
  br label %10

10:                                               ; preds = %28, %.preheader.i
  %11 = phi <4 x double> [ zeroinitializer, %.preheader.i ], [ %42, %28 ]
  %12 = phi i64 [ 0, %.preheader.i ], [ %43, %28 ]
  %13 = getelementptr double, ptr %3, i64 %12
  %unmaskedload = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 65
  %unmaskedload3 = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 130
  %unmaskedload4 = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %13, i64 195
  %unmaskedload5 = load <1 x double>, ptr %16, align 8
  %17 = getelementptr double, ptr %6, i64 %12
  %18 = load double, ptr %17, align 8
  %19 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload3, <2 x i32> <i32 0, i32 1>
  %20 = insertelement <2 x double> poison, double %18, i64 0
  %21 = shufflevector <2 x double> %20, <2 x double> poison, <2 x i32> zeroinitializer
  %22 = fmul <2 x double> %19, %21
  %23 = shufflevector <1 x double> %unmaskedload4, <1 x double> %unmaskedload5, <2 x i32> <i32 0, i32 1>
  %24 = fmul <2 x double> %23, %21
  %25 = shufflevector <2 x double> %22, <2 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %26 = fadd <4 x double> %11, %25
  store <4 x double> %26, ptr %9, align 8
  %27 = or disjoint i64 %12, 1
  %exitcond.not.i = icmp eq i64 %27, 65
  br i1 %exitcond.not.i, label %.preheader.i.11, label %28

28:                                               ; preds = %10
  %29 = getelementptr double, ptr %3, i64 %27
  %unmaskedload.1 = load <1 x double>, ptr %29, align 8
  %30 = getelementptr double, ptr %29, i64 65
  %unmaskedload3.1 = load <1 x double>, ptr %30, align 8
  %31 = getelementptr double, ptr %29, i64 130
  %unmaskedload4.1 = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %29, i64 195
  %unmaskedload5.1 = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %6, i64 %27
  %34 = load double, ptr %33, align 8
  %35 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload3.1, <2 x i32> <i32 0, i32 1>
  %36 = insertelement <2 x double> poison, double %34, i64 0
  %37 = shufflevector <2 x double> %36, <2 x double> poison, <2 x i32> zeroinitializer
  %38 = fmul <2 x double> %35, %37
  %39 = shufflevector <1 x double> %unmaskedload4.1, <1 x double> %unmaskedload5.1, <2 x i32> <i32 0, i32 1>
  %40 = fmul <2 x double> %39, %37
  %41 = shufflevector <2 x double> %38, <2 x double> %40, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %42 = fadd <4 x double> %26, %41
  store <4 x double> %42, ptr %9, align 8
  %43 = add nuw nsw i64 %12, 2
  br label %10

.preheader.i.11:                                  ; preds = %10
  %44 = getelementptr double, ptr %3, i64 260
  %45 = getelementptr double, ptr %9, i64 4
  %.promoted40 = load <4 x double>, ptr %45, align 8
  br label %46

46:                                               ; preds = %64, %.preheader.i.11
  %47 = phi <4 x double> [ %.promoted40, %.preheader.i.11 ], [ %78, %64 ]
  %48 = phi i64 [ 0, %.preheader.i.11 ], [ %79, %64 ]
  %49 = getelementptr double, ptr %44, i64 %48
  %unmaskedload7 = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %49, i64 65
  %unmaskedload8 = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %49, i64 130
  %unmaskedload9 = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %49, i64 195
  %unmaskedload10 = load <1 x double>, ptr %52, align 8
  %53 = getelementptr double, ptr %6, i64 %48
  %54 = load double, ptr %53, align 8
  %55 = shufflevector <1 x double> %unmaskedload7, <1 x double> %unmaskedload8, <2 x i32> <i32 0, i32 1>
  %56 = insertelement <2 x double> poison, double %54, i64 0
  %57 = shufflevector <2 x double> %56, <2 x double> poison, <2 x i32> zeroinitializer
  %58 = fmul <2 x double> %55, %57
  %59 = shufflevector <1 x double> %unmaskedload9, <1 x double> %unmaskedload10, <2 x i32> <i32 0, i32 1>
  %60 = fmul <2 x double> %59, %57
  %61 = shufflevector <2 x double> %58, <2 x double> %60, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %62 = fadd <4 x double> %47, %61
  store <4 x double> %62, ptr %45, align 8
  %63 = or disjoint i64 %48, 1
  %exitcond.not.i.12 = icmp eq i64 %63, 65
  br i1 %exitcond.not.i.12, label %.preheader.i.1, label %64

64:                                               ; preds = %46
  %65 = getelementptr double, ptr %44, i64 %63
  %unmaskedload7.1 = load <1 x double>, ptr %65, align 8
  %66 = getelementptr double, ptr %65, i64 65
  %unmaskedload8.1 = load <1 x double>, ptr %66, align 8
  %67 = getelementptr double, ptr %65, i64 130
  %unmaskedload9.1 = load <1 x double>, ptr %67, align 8
  %68 = getelementptr double, ptr %65, i64 195
  %unmaskedload10.1 = load <1 x double>, ptr %68, align 8
  %69 = getelementptr double, ptr %6, i64 %63
  %70 = load double, ptr %69, align 8
  %71 = shufflevector <1 x double> %unmaskedload7.1, <1 x double> %unmaskedload8.1, <2 x i32> <i32 0, i32 1>
  %72 = insertelement <2 x double> poison, double %70, i64 0
  %73 = shufflevector <2 x double> %72, <2 x double> poison, <2 x i32> zeroinitializer
  %74 = fmul <2 x double> %71, %73
  %75 = shufflevector <1 x double> %unmaskedload9.1, <1 x double> %unmaskedload10.1, <2 x i32> <i32 0, i32 1>
  %76 = fmul <2 x double> %75, %73
  %77 = shufflevector <2 x double> %74, <2 x double> %76, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %78 = fadd <4 x double> %62, %77
  store <4 x double> %78, ptr %45, align 8
  %79 = add nuw nsw i64 %48, 2
  br label %46

.preheader.i.1:                                   ; preds = %46
  %80 = getelementptr double, ptr %9, i64 8
  %81 = getelementptr double, ptr %3, i64 520
  %.promoted41 = load <4 x double>, ptr %80, align 8
  br label %82

82:                                               ; preds = %100, %.preheader.i.1
  %83 = phi <4 x double> [ %.promoted41, %.preheader.i.1 ], [ %114, %100 ]
  %84 = phi i64 [ 0, %.preheader.i.1 ], [ %115, %100 ]
  %85 = getelementptr double, ptr %81, i64 %84
  %unmaskedload12 = load <1 x double>, ptr %85, align 8
  %86 = getelementptr double, ptr %85, i64 65
  %unmaskedload13 = load <1 x double>, ptr %86, align 8
  %87 = getelementptr double, ptr %85, i64 130
  %unmaskedload14 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %85, i64 195
  %unmaskedload15 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %6, i64 %84
  %90 = load double, ptr %89, align 8
  %91 = shufflevector <1 x double> %unmaskedload12, <1 x double> %unmaskedload13, <2 x i32> <i32 0, i32 1>
  %92 = insertelement <2 x double> poison, double %90, i64 0
  %93 = shufflevector <2 x double> %92, <2 x double> poison, <2 x i32> zeroinitializer
  %94 = fmul <2 x double> %91, %93
  %95 = shufflevector <1 x double> %unmaskedload14, <1 x double> %unmaskedload15, <2 x i32> <i32 0, i32 1>
  %96 = fmul <2 x double> %95, %93
  %97 = shufflevector <2 x double> %94, <2 x double> %96, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %98 = fadd <4 x double> %83, %97
  store <4 x double> %98, ptr %80, align 8
  %99 = or disjoint i64 %84, 1
  %exitcond.not.i.1 = icmp eq i64 %99, 65
  br i1 %exitcond.not.i.1, label %.preheader.i.1.1, label %100

100:                                              ; preds = %82
  %101 = getelementptr double, ptr %81, i64 %99
  %unmaskedload12.1 = load <1 x double>, ptr %101, align 8
  %102 = getelementptr double, ptr %101, i64 65
  %unmaskedload13.1 = load <1 x double>, ptr %102, align 8
  %103 = getelementptr double, ptr %101, i64 130
  %unmaskedload14.1 = load <1 x double>, ptr %103, align 8
  %104 = getelementptr double, ptr %101, i64 195
  %unmaskedload15.1 = load <1 x double>, ptr %104, align 8
  %105 = getelementptr double, ptr %6, i64 %99
  %106 = load double, ptr %105, align 8
  %107 = shufflevector <1 x double> %unmaskedload12.1, <1 x double> %unmaskedload13.1, <2 x i32> <i32 0, i32 1>
  %108 = insertelement <2 x double> poison, double %106, i64 0
  %109 = shufflevector <2 x double> %108, <2 x double> poison, <2 x i32> zeroinitializer
  %110 = fmul <2 x double> %107, %109
  %111 = shufflevector <1 x double> %unmaskedload14.1, <1 x double> %unmaskedload15.1, <2 x i32> <i32 0, i32 1>
  %112 = fmul <2 x double> %111, %109
  %113 = shufflevector <2 x double> %110, <2 x double> %112, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %114 = fadd <4 x double> %98, %113
  store <4 x double> %114, ptr %80, align 8
  %115 = add nuw nsw i64 %84, 2
  br label %82

.preheader.i.1.1:                                 ; preds = %82
  %116 = getelementptr double, ptr %3, i64 780
  %117 = getelementptr double, ptr %9, i64 12
  %.promoted42 = load <4 x double>, ptr %117, align 8
  br label %118

118:                                              ; preds = %136, %.preheader.i.1.1
  %119 = phi <4 x double> [ %.promoted42, %.preheader.i.1.1 ], [ %150, %136 ]
  %120 = phi i64 [ 0, %.preheader.i.1.1 ], [ %151, %136 ]
  %121 = getelementptr double, ptr %116, i64 %120
  %unmaskedload17 = load <1 x double>, ptr %121, align 8
  %122 = getelementptr double, ptr %121, i64 65
  %unmaskedload18 = load <1 x double>, ptr %122, align 8
  %123 = getelementptr double, ptr %121, i64 130
  %unmaskedload19 = load <1 x double>, ptr %123, align 8
  %124 = getelementptr double, ptr %121, i64 195
  %unmaskedload20 = load <1 x double>, ptr %124, align 8
  %125 = getelementptr double, ptr %6, i64 %120
  %126 = load double, ptr %125, align 8
  %127 = shufflevector <1 x double> %unmaskedload17, <1 x double> %unmaskedload18, <2 x i32> <i32 0, i32 1>
  %128 = insertelement <2 x double> poison, double %126, i64 0
  %129 = shufflevector <2 x double> %128, <2 x double> poison, <2 x i32> zeroinitializer
  %130 = fmul <2 x double> %127, %129
  %131 = shufflevector <1 x double> %unmaskedload19, <1 x double> %unmaskedload20, <2 x i32> <i32 0, i32 1>
  %132 = fmul <2 x double> %131, %129
  %133 = shufflevector <2 x double> %130, <2 x double> %132, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %134 = fadd <4 x double> %119, %133
  store <4 x double> %134, ptr %117, align 8
  %135 = or disjoint i64 %120, 1
  %exitcond.not.i.1.1 = icmp eq i64 %135, 65
  br i1 %exitcond.not.i.1.1, label %.preheader.i.2, label %136

136:                                              ; preds = %118
  %137 = getelementptr double, ptr %116, i64 %135
  %unmaskedload17.1 = load <1 x double>, ptr %137, align 8
  %138 = getelementptr double, ptr %137, i64 65
  %unmaskedload18.1 = load <1 x double>, ptr %138, align 8
  %139 = getelementptr double, ptr %137, i64 130
  %unmaskedload19.1 = load <1 x double>, ptr %139, align 8
  %140 = getelementptr double, ptr %137, i64 195
  %unmaskedload20.1 = load <1 x double>, ptr %140, align 8
  %141 = getelementptr double, ptr %6, i64 %135
  %142 = load double, ptr %141, align 8
  %143 = shufflevector <1 x double> %unmaskedload17.1, <1 x double> %unmaskedload18.1, <2 x i32> <i32 0, i32 1>
  %144 = insertelement <2 x double> poison, double %142, i64 0
  %145 = shufflevector <2 x double> %144, <2 x double> poison, <2 x i32> zeroinitializer
  %146 = fmul <2 x double> %143, %145
  %147 = shufflevector <1 x double> %unmaskedload19.1, <1 x double> %unmaskedload20.1, <2 x i32> <i32 0, i32 1>
  %148 = fmul <2 x double> %147, %145
  %149 = shufflevector <2 x double> %146, <2 x double> %148, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %150 = fadd <4 x double> %134, %149
  store <4 x double> %150, ptr %117, align 8
  %151 = add nuw nsw i64 %120, 2
  br label %118

.preheader.i.2:                                   ; preds = %118
  %152 = getelementptr double, ptr %9, i64 16
  %153 = getelementptr double, ptr %3, i64 1040
  %.promoted43 = load <4 x double>, ptr %152, align 8
  br label %154

154:                                              ; preds = %172, %.preheader.i.2
  %155 = phi <4 x double> [ %.promoted43, %.preheader.i.2 ], [ %186, %172 ]
  %156 = phi i64 [ 0, %.preheader.i.2 ], [ %187, %172 ]
  %157 = getelementptr double, ptr %153, i64 %156
  %unmaskedload22 = load <1 x double>, ptr %157, align 8
  %158 = getelementptr double, ptr %157, i64 65
  %unmaskedload23 = load <1 x double>, ptr %158, align 8
  %159 = getelementptr double, ptr %157, i64 130
  %unmaskedload24 = load <1 x double>, ptr %159, align 8
  %160 = getelementptr double, ptr %157, i64 195
  %unmaskedload25 = load <1 x double>, ptr %160, align 8
  %161 = getelementptr double, ptr %6, i64 %156
  %162 = load double, ptr %161, align 8
  %163 = shufflevector <1 x double> %unmaskedload22, <1 x double> %unmaskedload23, <2 x i32> <i32 0, i32 1>
  %164 = insertelement <2 x double> poison, double %162, i64 0
  %165 = shufflevector <2 x double> %164, <2 x double> poison, <2 x i32> zeroinitializer
  %166 = fmul <2 x double> %163, %165
  %167 = shufflevector <1 x double> %unmaskedload24, <1 x double> %unmaskedload25, <2 x i32> <i32 0, i32 1>
  %168 = fmul <2 x double> %167, %165
  %169 = shufflevector <2 x double> %166, <2 x double> %168, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %170 = fadd <4 x double> %155, %169
  store <4 x double> %170, ptr %152, align 8
  %171 = or disjoint i64 %156, 1
  %exitcond.not.i.2 = icmp eq i64 %171, 65
  br i1 %exitcond.not.i.2, label %.preheader.i.2.1, label %172

172:                                              ; preds = %154
  %173 = getelementptr double, ptr %153, i64 %171
  %unmaskedload22.1 = load <1 x double>, ptr %173, align 8
  %174 = getelementptr double, ptr %173, i64 65
  %unmaskedload23.1 = load <1 x double>, ptr %174, align 8
  %175 = getelementptr double, ptr %173, i64 130
  %unmaskedload24.1 = load <1 x double>, ptr %175, align 8
  %176 = getelementptr double, ptr %173, i64 195
  %unmaskedload25.1 = load <1 x double>, ptr %176, align 8
  %177 = getelementptr double, ptr %6, i64 %171
  %178 = load double, ptr %177, align 8
  %179 = shufflevector <1 x double> %unmaskedload22.1, <1 x double> %unmaskedload23.1, <2 x i32> <i32 0, i32 1>
  %180 = insertelement <2 x double> poison, double %178, i64 0
  %181 = shufflevector <2 x double> %180, <2 x double> poison, <2 x i32> zeroinitializer
  %182 = fmul <2 x double> %179, %181
  %183 = shufflevector <1 x double> %unmaskedload24.1, <1 x double> %unmaskedload25.1, <2 x i32> <i32 0, i32 1>
  %184 = fmul <2 x double> %183, %181
  %185 = shufflevector <2 x double> %182, <2 x double> %184, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %186 = fadd <4 x double> %170, %185
  store <4 x double> %186, ptr %152, align 8
  %187 = add nuw nsw i64 %156, 2
  br label %154

.preheader.i.2.1:                                 ; preds = %154
  %188 = getelementptr double, ptr %3, i64 1300
  %189 = getelementptr double, ptr %9, i64 20
  %.promoted44 = load <4 x double>, ptr %189, align 8
  br label %190

190:                                              ; preds = %208, %.preheader.i.2.1
  %191 = phi <4 x double> [ %.promoted44, %.preheader.i.2.1 ], [ %222, %208 ]
  %192 = phi i64 [ 0, %.preheader.i.2.1 ], [ %223, %208 ]
  %193 = getelementptr double, ptr %188, i64 %192
  %unmaskedload27 = load <1 x double>, ptr %193, align 8
  %194 = getelementptr double, ptr %193, i64 65
  %unmaskedload28 = load <1 x double>, ptr %194, align 8
  %195 = getelementptr double, ptr %193, i64 130
  %unmaskedload29 = load <1 x double>, ptr %195, align 8
  %196 = getelementptr double, ptr %193, i64 195
  %unmaskedload30 = load <1 x double>, ptr %196, align 8
  %197 = getelementptr double, ptr %6, i64 %192
  %198 = load double, ptr %197, align 8
  %199 = shufflevector <1 x double> %unmaskedload27, <1 x double> %unmaskedload28, <2 x i32> <i32 0, i32 1>
  %200 = insertelement <2 x double> poison, double %198, i64 0
  %201 = shufflevector <2 x double> %200, <2 x double> poison, <2 x i32> zeroinitializer
  %202 = fmul <2 x double> %199, %201
  %203 = shufflevector <1 x double> %unmaskedload29, <1 x double> %unmaskedload30, <2 x i32> <i32 0, i32 1>
  %204 = fmul <2 x double> %203, %201
  %205 = shufflevector <2 x double> %202, <2 x double> %204, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %206 = fadd <4 x double> %191, %205
  store <4 x double> %206, ptr %189, align 8
  %207 = or disjoint i64 %192, 1
  %exitcond.not.i.2.1 = icmp eq i64 %207, 65
  br i1 %exitcond.not.i.2.1, label %.preheader.i.3, label %208

208:                                              ; preds = %190
  %209 = getelementptr double, ptr %188, i64 %207
  %unmaskedload27.1 = load <1 x double>, ptr %209, align 8
  %210 = getelementptr double, ptr %209, i64 65
  %unmaskedload28.1 = load <1 x double>, ptr %210, align 8
  %211 = getelementptr double, ptr %209, i64 130
  %unmaskedload29.1 = load <1 x double>, ptr %211, align 8
  %212 = getelementptr double, ptr %209, i64 195
  %unmaskedload30.1 = load <1 x double>, ptr %212, align 8
  %213 = getelementptr double, ptr %6, i64 %207
  %214 = load double, ptr %213, align 8
  %215 = shufflevector <1 x double> %unmaskedload27.1, <1 x double> %unmaskedload28.1, <2 x i32> <i32 0, i32 1>
  %216 = insertelement <2 x double> poison, double %214, i64 0
  %217 = shufflevector <2 x double> %216, <2 x double> poison, <2 x i32> zeroinitializer
  %218 = fmul <2 x double> %215, %217
  %219 = shufflevector <1 x double> %unmaskedload29.1, <1 x double> %unmaskedload30.1, <2 x i32> <i32 0, i32 1>
  %220 = fmul <2 x double> %219, %217
  %221 = shufflevector <2 x double> %218, <2 x double> %220, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %222 = fadd <4 x double> %206, %221
  store <4 x double> %222, ptr %189, align 8
  %223 = add nuw nsw i64 %192, 2
  br label %190

.preheader.i.3:                                   ; preds = %190
  %224 = getelementptr double, ptr %9, i64 24
  %225 = getelementptr double, ptr %3, i64 1560
  %.promoted45 = load <4 x double>, ptr %224, align 8
  br label %226

226:                                              ; preds = %244, %.preheader.i.3
  %227 = phi <4 x double> [ %.promoted45, %.preheader.i.3 ], [ %258, %244 ]
  %228 = phi i64 [ 0, %.preheader.i.3 ], [ %259, %244 ]
  %229 = getelementptr double, ptr %225, i64 %228
  %unmaskedload32 = load <1 x double>, ptr %229, align 8
  %230 = getelementptr double, ptr %229, i64 65
  %unmaskedload33 = load <1 x double>, ptr %230, align 8
  %231 = getelementptr double, ptr %229, i64 130
  %unmaskedload34 = load <1 x double>, ptr %231, align 8
  %232 = getelementptr double, ptr %229, i64 195
  %unmaskedload35 = load <1 x double>, ptr %232, align 8
  %233 = getelementptr double, ptr %6, i64 %228
  %234 = load double, ptr %233, align 8
  %235 = shufflevector <1 x double> %unmaskedload32, <1 x double> %unmaskedload33, <2 x i32> <i32 0, i32 1>
  %236 = insertelement <2 x double> poison, double %234, i64 0
  %237 = shufflevector <2 x double> %236, <2 x double> poison, <2 x i32> zeroinitializer
  %238 = fmul <2 x double> %235, %237
  %239 = shufflevector <1 x double> %unmaskedload34, <1 x double> %unmaskedload35, <2 x i32> <i32 0, i32 1>
  %240 = fmul <2 x double> %239, %237
  %241 = shufflevector <2 x double> %238, <2 x double> %240, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %242 = fadd <4 x double> %227, %241
  store <4 x double> %242, ptr %224, align 8
  %243 = or disjoint i64 %228, 1
  %exitcond.not.i.3 = icmp eq i64 %243, 65
  br i1 %exitcond.not.i.3, label %.preheader.i.3.1, label %244

244:                                              ; preds = %226
  %245 = getelementptr double, ptr %225, i64 %243
  %unmaskedload32.1 = load <1 x double>, ptr %245, align 8
  %246 = getelementptr double, ptr %245, i64 65
  %unmaskedload33.1 = load <1 x double>, ptr %246, align 8
  %247 = getelementptr double, ptr %245, i64 130
  %unmaskedload34.1 = load <1 x double>, ptr %247, align 8
  %248 = getelementptr double, ptr %245, i64 195
  %unmaskedload35.1 = load <1 x double>, ptr %248, align 8
  %249 = getelementptr double, ptr %6, i64 %243
  %250 = load double, ptr %249, align 8
  %251 = shufflevector <1 x double> %unmaskedload32.1, <1 x double> %unmaskedload33.1, <2 x i32> <i32 0, i32 1>
  %252 = insertelement <2 x double> poison, double %250, i64 0
  %253 = shufflevector <2 x double> %252, <2 x double> poison, <2 x i32> zeroinitializer
  %254 = fmul <2 x double> %251, %253
  %255 = shufflevector <1 x double> %unmaskedload34.1, <1 x double> %unmaskedload35.1, <2 x i32> <i32 0, i32 1>
  %256 = fmul <2 x double> %255, %253
  %257 = shufflevector <2 x double> %254, <2 x double> %256, <4 x i32> <i32 0, i32 1, i32 2, i32 3>
  %258 = fadd <4 x double> %242, %257
  store <4 x double> %258, ptr %224, align 8
  %259 = add nuw nsw i64 %228, 2
  br label %226

.preheader.i.3.1:                                 ; preds = %226
  %260 = getelementptr double, ptr %3, i64 1820
  %261 = getelementptr double, ptr %9, i64 28
  br label %262

262:                                              ; preds = %280, %.preheader.i.3.1
  %263 = phi i64 [ 0, %.preheader.i.3.1 ], [ %296, %280 ]
  %264 = getelementptr double, ptr %260, i64 %263
  %unmaskedload37 = load <1 x double>, ptr %264, align 8
  %265 = getelementptr double, ptr %264, i64 65
  %unmaskedload38 = load <1 x double>, ptr %265, align 8
  %266 = getelementptr double, ptr %264, i64 130
  %unmaskedload39 = load <1 x double>, ptr %266, align 8
  %267 = getelementptr double, ptr %6, i64 %263
  %268 = load double, ptr %267, align 8
  %269 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %261, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %270 = shufflevector <1 x double> %unmaskedload37, <1 x double> %unmaskedload38, <2 x i32> <i32 0, i32 1>
  %271 = insertelement <2 x double> poison, double %268, i64 0
  %272 = shufflevector <2 x double> %271, <2 x double> poison, <2 x i32> zeroinitializer
  %273 = fmul <2 x double> %270, %272
  %274 = shufflevector <2 x double> %273, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %275 = extractelement <1 x double> %unmaskedload39, i64 0
  %276 = fmul double %275, %268
  %277 = insertelement <4 x double> %274, double %276, i64 2
  %278 = fadd <4 x double> %269, %277
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %278, ptr %261, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %279 = or disjoint i64 %263, 1
  %exitcond.not.i.3.1 = icmp eq i64 %279, 65
  br i1 %exitcond.not.i.3.1, label %kernel.exit, label %280

280:                                              ; preds = %262
  %281 = getelementptr double, ptr %260, i64 %279
  %unmaskedload37.1 = load <1 x double>, ptr %281, align 8
  %282 = getelementptr double, ptr %281, i64 65
  %unmaskedload38.1 = load <1 x double>, ptr %282, align 8
  %283 = getelementptr double, ptr %281, i64 130
  %unmaskedload39.1 = load <1 x double>, ptr %283, align 8
  %284 = getelementptr double, ptr %6, i64 %279
  %285 = load double, ptr %284, align 8
  %286 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %261, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %287 = shufflevector <1 x double> %unmaskedload37.1, <1 x double> %unmaskedload38.1, <2 x i32> <i32 0, i32 1>
  %288 = insertelement <2 x double> poison, double %285, i64 0
  %289 = shufflevector <2 x double> %288, <2 x double> poison, <2 x i32> zeroinitializer
  %290 = fmul <2 x double> %287, %289
  %291 = shufflevector <2 x double> %290, <2 x double> poison, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %292 = extractelement <1 x double> %unmaskedload39.1, i64 0
  %293 = fmul double %292, %285
  %294 = insertelement <4 x double> %291, double %293, i64 2
  %295 = fadd <4 x double> %286, %294
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %295, ptr %261, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %296 = add nuw nsw i64 %263, 2
  br label %262

kernel.exit:                                      ; preds = %262
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
