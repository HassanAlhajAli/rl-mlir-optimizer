; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %15, i8 0, i64 64008, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  %21 = getelementptr double, ptr %8, i64 16
  %invariant.gep.1.1 = getelementptr double, ptr %8, i64 20
  %invariant.gep.1.2 = getelementptr double, ptr %8, i64 24
  %invariant.gep.1.3 = getelementptr double, ptr %8, i64 28
  %22 = getelementptr double, ptr %8, i64 32
  %invariant.gep.2.1 = getelementptr double, ptr %8, i64 36
  %invariant.gep.2.2 = getelementptr double, ptr %8, i64 40
  %invariant.gep.2.3 = getelementptr double, ptr %8, i64 44
  %23 = getelementptr double, ptr %8, i64 48
  %invariant.gep.3.1 = getelementptr double, ptr %8, i64 52
  %invariant.gep.3.2 = getelementptr double, ptr %8, i64 56
  %invariant.gep.3.3 = getelementptr double, ptr %8, i64 60
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %697
  %24 = phi i64 [ %698, %697 ], [ 0, %.preheader17.preheader ]
  %25 = icmp eq i64 %24, 112
  %26 = select i1 %25, i64 15, i64 16
  %27 = mul nuw nsw i64 %24, 63
  %28 = getelementptr double, ptr %15, i64 %27
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader17, %198
  %29 = phi i64 [ 0, %.preheader17 ], [ %199, %198 ]
  %30 = add nuw nsw i64 %29, %24
  %31 = mul nuw nsw i64 %30, 33
  %32 = mul nuw nsw i64 %29, 63
  %33 = getelementptr double, ptr %1, i64 %31
  %34 = getelementptr double, ptr %28, i64 %32
  %.promoted74 = load <4 x double>, ptr %34, align 8
  br label %.critedge

.critedge:                                        ; preds = %.critedge.176, %.preheader16
  %35 = phi <4 x double> [ %.promoted74, %.preheader16 ], [ %73, %.critedge.176 ]
  %36 = phi i64 [ 0, %.preheader16 ], [ %74, %.critedge.176 ]
  %37 = mul nuw nsw i64 %36, 63
  %38 = getelementptr double, ptr %33, i64 %36
  %39 = load double, ptr %38, align 8
  %40 = insertelement <1 x double> poison, double %39, i64 0
  %gep = getelementptr double, ptr %8, i64 %37
  %unmaskedload = load <4 x double>, ptr %gep, align 8
  %41 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %42 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %43 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %44 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %45 = fmul <1 x double> %40, %41
  %46 = fmul <1 x double> %40, %42
  %47 = fmul <1 x double> %40, %43
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = fmul <1 x double> %40, %44
  %50 = shufflevector <1 x double> %49, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %51 = shufflevector <1 x double> %45, <1 x double> %46, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %50, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %54 = fadd <4 x double> %35, %53
  store <4 x double> %54, ptr %34, align 8
  %55 = or disjoint i64 %36, 1
  %exitcond.not = icmp eq i64 %55, 33
  br i1 %exitcond.not, label %.preheader.120, label %.critedge.176

.critedge.176:                                    ; preds = %.critedge
  %56 = mul nuw nsw i64 %55, 63
  %57 = getelementptr double, ptr %33, i64 %55
  %58 = load double, ptr %57, align 8
  %59 = insertelement <1 x double> poison, double %58, i64 0
  %gep.175 = getelementptr double, ptr %8, i64 %56
  %unmaskedload.1 = load <4 x double>, ptr %gep.175, align 8
  %60 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> zeroinitializer
  %61 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 1>
  %62 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 2>
  %63 = shufflevector <4 x double> %unmaskedload.1, <4 x double> poison, <1 x i32> <i32 3>
  %64 = fmul <1 x double> %59, %60
  %65 = fmul <1 x double> %59, %61
  %66 = fmul <1 x double> %59, %62
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = fmul <1 x double> %59, %63
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = shufflevector <1 x double> %64, <1 x double> %65, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %73 = fadd <4 x double> %54, %72
  store <4 x double> %73, ptr %34, align 8
  %74 = add nuw nsw i64 %36, 2
  br label %.critedge

.preheader.120:                                   ; preds = %.critedge
  %75 = getelementptr double, ptr %34, i64 4
  %.promoted73 = load <4 x double>, ptr %75, align 8
  br label %.critedge.123

.critedge.123:                                    ; preds = %.critedge.123.1, %.preheader.120
  %76 = phi <4 x double> [ %.promoted73, %.preheader.120 ], [ %114, %.critedge.123.1 ]
  %77 = phi i64 [ 0, %.preheader.120 ], [ %115, %.critedge.123.1 ]
  %78 = mul nuw nsw i64 %77, 63
  %79 = getelementptr double, ptr %33, i64 %77
  %80 = load double, ptr %79, align 8
  %81 = insertelement <1 x double> poison, double %80, i64 0
  %gep.121 = getelementptr double, ptr %invariant.gep.1, i64 %78
  %unmaskedload33 = load <4 x double>, ptr %gep.121, align 8
  %82 = shufflevector <4 x double> %unmaskedload33, <4 x double> poison, <1 x i32> zeroinitializer
  %83 = shufflevector <4 x double> %unmaskedload33, <4 x double> poison, <1 x i32> <i32 1>
  %84 = shufflevector <4 x double> %unmaskedload33, <4 x double> poison, <1 x i32> <i32 2>
  %85 = shufflevector <4 x double> %unmaskedload33, <4 x double> poison, <1 x i32> <i32 3>
  %86 = fmul <1 x double> %81, %82
  %87 = fmul <1 x double> %81, %83
  %88 = fmul <1 x double> %81, %84
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = fmul <1 x double> %81, %85
  %91 = shufflevector <1 x double> %90, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %92 = shufflevector <1 x double> %86, <1 x double> %87, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %91, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %95 = fadd <4 x double> %76, %94
  store <4 x double> %95, ptr %75, align 8
  %96 = or disjoint i64 %77, 1
  %exitcond.122.not = icmp eq i64 %96, 33
  br i1 %exitcond.122.not, label %.preheader.224, label %.critedge.123.1

.critedge.123.1:                                  ; preds = %.critedge.123
  %97 = mul nuw nsw i64 %96, 63
  %98 = getelementptr double, ptr %33, i64 %96
  %99 = load double, ptr %98, align 8
  %100 = insertelement <1 x double> poison, double %99, i64 0
  %gep.121.1 = getelementptr double, ptr %invariant.gep.1, i64 %97
  %unmaskedload33.1 = load <4 x double>, ptr %gep.121.1, align 8
  %101 = shufflevector <4 x double> %unmaskedload33.1, <4 x double> poison, <1 x i32> zeroinitializer
  %102 = shufflevector <4 x double> %unmaskedload33.1, <4 x double> poison, <1 x i32> <i32 1>
  %103 = shufflevector <4 x double> %unmaskedload33.1, <4 x double> poison, <1 x i32> <i32 2>
  %104 = shufflevector <4 x double> %unmaskedload33.1, <4 x double> poison, <1 x i32> <i32 3>
  %105 = fmul <1 x double> %100, %101
  %106 = fmul <1 x double> %100, %102
  %107 = fmul <1 x double> %100, %103
  %108 = shufflevector <1 x double> %107, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %109 = fmul <1 x double> %100, %104
  %110 = shufflevector <1 x double> %109, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <1 x double> %105, <1 x double> %106, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %112 = shufflevector <4 x double> %111, <4 x double> %108, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %110, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %114 = fadd <4 x double> %95, %113
  store <4 x double> %114, ptr %75, align 8
  %115 = add nuw nsw i64 %77, 2
  br label %.critedge.123

.preheader.224:                                   ; preds = %.critedge.123
  %116 = getelementptr double, ptr %34, i64 8
  %.promoted72 = load <4 x double>, ptr %116, align 8
  br label %.critedge.227

.critedge.227:                                    ; preds = %.critedge.227.1, %.preheader.224
  %117 = phi <4 x double> [ %.promoted72, %.preheader.224 ], [ %155, %.critedge.227.1 ]
  %118 = phi i64 [ 0, %.preheader.224 ], [ %156, %.critedge.227.1 ]
  %119 = mul nuw nsw i64 %118, 63
  %120 = getelementptr double, ptr %33, i64 %118
  %121 = load double, ptr %120, align 8
  %122 = insertelement <1 x double> poison, double %121, i64 0
  %gep.225 = getelementptr double, ptr %invariant.gep.2, i64 %119
  %unmaskedload35 = load <4 x double>, ptr %gep.225, align 8
  %123 = shufflevector <4 x double> %unmaskedload35, <4 x double> poison, <1 x i32> zeroinitializer
  %124 = shufflevector <4 x double> %unmaskedload35, <4 x double> poison, <1 x i32> <i32 1>
  %125 = shufflevector <4 x double> %unmaskedload35, <4 x double> poison, <1 x i32> <i32 2>
  %126 = shufflevector <4 x double> %unmaskedload35, <4 x double> poison, <1 x i32> <i32 3>
  %127 = fmul <1 x double> %122, %123
  %128 = fmul <1 x double> %122, %124
  %129 = fmul <1 x double> %122, %125
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = fmul <1 x double> %122, %126
  %132 = shufflevector <1 x double> %131, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %133 = shufflevector <1 x double> %127, <1 x double> %128, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %135 = shufflevector <4 x double> %134, <4 x double> %132, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %136 = fadd <4 x double> %117, %135
  store <4 x double> %136, ptr %116, align 8
  %137 = or disjoint i64 %118, 1
  %exitcond.226.not = icmp eq i64 %137, 33
  br i1 %exitcond.226.not, label %.preheader.328, label %.critedge.227.1

.critedge.227.1:                                  ; preds = %.critedge.227
  %138 = mul nuw nsw i64 %137, 63
  %139 = getelementptr double, ptr %33, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = insertelement <1 x double> poison, double %140, i64 0
  %gep.225.1 = getelementptr double, ptr %invariant.gep.2, i64 %138
  %unmaskedload35.1 = load <4 x double>, ptr %gep.225.1, align 8
  %142 = shufflevector <4 x double> %unmaskedload35.1, <4 x double> poison, <1 x i32> zeroinitializer
  %143 = shufflevector <4 x double> %unmaskedload35.1, <4 x double> poison, <1 x i32> <i32 1>
  %144 = shufflevector <4 x double> %unmaskedload35.1, <4 x double> poison, <1 x i32> <i32 2>
  %145 = shufflevector <4 x double> %unmaskedload35.1, <4 x double> poison, <1 x i32> <i32 3>
  %146 = fmul <1 x double> %141, %142
  %147 = fmul <1 x double> %141, %143
  %148 = fmul <1 x double> %141, %144
  %149 = shufflevector <1 x double> %148, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %150 = fmul <1 x double> %141, %145
  %151 = shufflevector <1 x double> %150, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %152 = shufflevector <1 x double> %146, <1 x double> %147, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %153 = shufflevector <4 x double> %152, <4 x double> %149, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %151, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %155 = fadd <4 x double> %136, %154
  store <4 x double> %155, ptr %116, align 8
  %156 = add nuw nsw i64 %118, 2
  br label %.critedge.227

.preheader.328:                                   ; preds = %.critedge.227
  %157 = getelementptr double, ptr %34, i64 12
  %.promoted71 = load <4 x double>, ptr %157, align 8
  br label %.critedge.331

.critedge.331:                                    ; preds = %.critedge.331.1, %.preheader.328
  %158 = phi <4 x double> [ %.promoted71, %.preheader.328 ], [ %196, %.critedge.331.1 ]
  %159 = phi i64 [ 0, %.preheader.328 ], [ %197, %.critedge.331.1 ]
  %160 = mul nuw nsw i64 %159, 63
  %161 = getelementptr double, ptr %33, i64 %159
  %162 = load double, ptr %161, align 8
  %163 = insertelement <1 x double> poison, double %162, i64 0
  %gep.329 = getelementptr double, ptr %invariant.gep.3, i64 %160
  %unmaskedload37 = load <4 x double>, ptr %gep.329, align 8
  %164 = shufflevector <4 x double> %unmaskedload37, <4 x double> poison, <1 x i32> zeroinitializer
  %165 = shufflevector <4 x double> %unmaskedload37, <4 x double> poison, <1 x i32> <i32 1>
  %166 = shufflevector <4 x double> %unmaskedload37, <4 x double> poison, <1 x i32> <i32 2>
  %167 = shufflevector <4 x double> %unmaskedload37, <4 x double> poison, <1 x i32> <i32 3>
  %168 = fmul <1 x double> %163, %164
  %169 = fmul <1 x double> %163, %165
  %170 = fmul <1 x double> %163, %166
  %171 = shufflevector <1 x double> %170, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %172 = fmul <1 x double> %163, %167
  %173 = shufflevector <1 x double> %172, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %174 = shufflevector <1 x double> %168, <1 x double> %169, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %175 = shufflevector <4 x double> %174, <4 x double> %171, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %176 = shufflevector <4 x double> %175, <4 x double> %173, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %177 = fadd <4 x double> %158, %176
  store <4 x double> %177, ptr %157, align 8
  %178 = or disjoint i64 %159, 1
  %exitcond.330.not = icmp eq i64 %178, 33
  br i1 %exitcond.330.not, label %198, label %.critedge.331.1

.critedge.331.1:                                  ; preds = %.critedge.331
  %179 = mul nuw nsw i64 %178, 63
  %180 = getelementptr double, ptr %33, i64 %178
  %181 = load double, ptr %180, align 8
  %182 = insertelement <1 x double> poison, double %181, i64 0
  %gep.329.1 = getelementptr double, ptr %invariant.gep.3, i64 %179
  %unmaskedload37.1 = load <4 x double>, ptr %gep.329.1, align 8
  %183 = shufflevector <4 x double> %unmaskedload37.1, <4 x double> poison, <1 x i32> zeroinitializer
  %184 = shufflevector <4 x double> %unmaskedload37.1, <4 x double> poison, <1 x i32> <i32 1>
  %185 = shufflevector <4 x double> %unmaskedload37.1, <4 x double> poison, <1 x i32> <i32 2>
  %186 = shufflevector <4 x double> %unmaskedload37.1, <4 x double> poison, <1 x i32> <i32 3>
  %187 = fmul <1 x double> %182, %183
  %188 = fmul <1 x double> %182, %184
  %189 = fmul <1 x double> %182, %185
  %190 = shufflevector <1 x double> %189, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %191 = fmul <1 x double> %182, %186
  %192 = shufflevector <1 x double> %191, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %193 = shufflevector <1 x double> %187, <1 x double> %188, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %194 = shufflevector <4 x double> %193, <4 x double> %190, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %195 = shufflevector <4 x double> %194, <4 x double> %192, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %196 = fadd <4 x double> %177, %195
  store <4 x double> %196, ptr %157, align 8
  %197 = add nuw nsw i64 %159, 2
  br label %.critedge.331

198:                                              ; preds = %.critedge.331
  %199 = add nuw nsw i64 %29, 1
  %exitcond19.not = icmp eq i64 %199, %26
  br i1 %exitcond19.not, label %200, label %.preheader16

200:                                              ; preds = %198
  %201 = getelementptr double, ptr %28, i64 16
  br label %.preheader16.1

.preheader16.1:                                   ; preds = %371, %200
  %202 = phi i64 [ 0, %200 ], [ %372, %371 ]
  %203 = add nuw nsw i64 %202, %24
  %204 = mul nuw nsw i64 %203, 33
  %205 = mul nuw nsw i64 %202, 63
  %206 = getelementptr double, ptr %1, i64 %204
  %207 = getelementptr double, ptr %201, i64 %205
  %.promoted70 = load <4 x double>, ptr %207, align 8
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1.178, %.preheader16.1
  %208 = phi <4 x double> [ %.promoted70, %.preheader16.1 ], [ %246, %.critedge.1.178 ]
  %209 = phi i64 [ 0, %.preheader16.1 ], [ %247, %.critedge.1.178 ]
  %210 = mul nuw nsw i64 %209, 63
  %211 = getelementptr double, ptr %206, i64 %209
  %212 = load double, ptr %211, align 8
  %213 = insertelement <1 x double> poison, double %212, i64 0
  %gep.1 = getelementptr double, ptr %21, i64 %210
  %unmaskedload39 = load <4 x double>, ptr %gep.1, align 8
  %214 = shufflevector <4 x double> %unmaskedload39, <4 x double> poison, <1 x i32> zeroinitializer
  %215 = shufflevector <4 x double> %unmaskedload39, <4 x double> poison, <1 x i32> <i32 1>
  %216 = shufflevector <4 x double> %unmaskedload39, <4 x double> poison, <1 x i32> <i32 2>
  %217 = shufflevector <4 x double> %unmaskedload39, <4 x double> poison, <1 x i32> <i32 3>
  %218 = fmul <1 x double> %213, %214
  %219 = fmul <1 x double> %213, %215
  %220 = fmul <1 x double> %213, %216
  %221 = shufflevector <1 x double> %220, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %222 = fmul <1 x double> %213, %217
  %223 = shufflevector <1 x double> %222, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %224 = shufflevector <1 x double> %218, <1 x double> %219, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %225 = shufflevector <4 x double> %224, <4 x double> %221, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %226 = shufflevector <4 x double> %225, <4 x double> %223, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %227 = fadd <4 x double> %208, %226
  store <4 x double> %227, ptr %207, align 8
  %228 = or disjoint i64 %209, 1
  %exitcond.1.not = icmp eq i64 %228, 33
  br i1 %exitcond.1.not, label %.preheader.1.1, label %.critedge.1.178

.critedge.1.178:                                  ; preds = %.critedge.1
  %229 = mul nuw nsw i64 %228, 63
  %230 = getelementptr double, ptr %206, i64 %228
  %231 = load double, ptr %230, align 8
  %232 = insertelement <1 x double> poison, double %231, i64 0
  %gep.1.177 = getelementptr double, ptr %21, i64 %229
  %unmaskedload39.1 = load <4 x double>, ptr %gep.1.177, align 8
  %233 = shufflevector <4 x double> %unmaskedload39.1, <4 x double> poison, <1 x i32> zeroinitializer
  %234 = shufflevector <4 x double> %unmaskedload39.1, <4 x double> poison, <1 x i32> <i32 1>
  %235 = shufflevector <4 x double> %unmaskedload39.1, <4 x double> poison, <1 x i32> <i32 2>
  %236 = shufflevector <4 x double> %unmaskedload39.1, <4 x double> poison, <1 x i32> <i32 3>
  %237 = fmul <1 x double> %232, %233
  %238 = fmul <1 x double> %232, %234
  %239 = fmul <1 x double> %232, %235
  %240 = shufflevector <1 x double> %239, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %241 = fmul <1 x double> %232, %236
  %242 = shufflevector <1 x double> %241, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %243 = shufflevector <1 x double> %237, <1 x double> %238, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %244 = shufflevector <4 x double> %243, <4 x double> %240, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %245 = shufflevector <4 x double> %244, <4 x double> %242, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %246 = fadd <4 x double> %227, %245
  store <4 x double> %246, ptr %207, align 8
  %247 = add nuw nsw i64 %209, 2
  br label %.critedge.1

.preheader.1.1:                                   ; preds = %.critedge.1
  %248 = getelementptr double, ptr %207, i64 4
  %.promoted69 = load <4 x double>, ptr %248, align 8
  br label %.critedge.1.1

.critedge.1.1:                                    ; preds = %.critedge.1.1.1, %.preheader.1.1
  %249 = phi <4 x double> [ %.promoted69, %.preheader.1.1 ], [ %287, %.critedge.1.1.1 ]
  %250 = phi i64 [ 0, %.preheader.1.1 ], [ %288, %.critedge.1.1.1 ]
  %251 = mul nuw nsw i64 %250, 63
  %252 = getelementptr double, ptr %206, i64 %250
  %253 = load double, ptr %252, align 8
  %254 = insertelement <1 x double> poison, double %253, i64 0
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1.1, i64 %251
  %unmaskedload41 = load <4 x double>, ptr %gep.1.1, align 8
  %255 = shufflevector <4 x double> %unmaskedload41, <4 x double> poison, <1 x i32> zeroinitializer
  %256 = shufflevector <4 x double> %unmaskedload41, <4 x double> poison, <1 x i32> <i32 1>
  %257 = shufflevector <4 x double> %unmaskedload41, <4 x double> poison, <1 x i32> <i32 2>
  %258 = shufflevector <4 x double> %unmaskedload41, <4 x double> poison, <1 x i32> <i32 3>
  %259 = fmul <1 x double> %254, %255
  %260 = fmul <1 x double> %254, %256
  %261 = fmul <1 x double> %254, %257
  %262 = shufflevector <1 x double> %261, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %263 = fmul <1 x double> %254, %258
  %264 = shufflevector <1 x double> %263, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %265 = shufflevector <1 x double> %259, <1 x double> %260, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %266 = shufflevector <4 x double> %265, <4 x double> %262, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %267 = shufflevector <4 x double> %266, <4 x double> %264, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %268 = fadd <4 x double> %249, %267
  store <4 x double> %268, ptr %248, align 8
  %269 = or disjoint i64 %250, 1
  %exitcond.1.1.not = icmp eq i64 %269, 33
  br i1 %exitcond.1.1.not, label %.preheader.1.2, label %.critedge.1.1.1

.critedge.1.1.1:                                  ; preds = %.critedge.1.1
  %270 = mul nuw nsw i64 %269, 63
  %271 = getelementptr double, ptr %206, i64 %269
  %272 = load double, ptr %271, align 8
  %273 = insertelement <1 x double> poison, double %272, i64 0
  %gep.1.1.1 = getelementptr double, ptr %invariant.gep.1.1, i64 %270
  %unmaskedload41.1 = load <4 x double>, ptr %gep.1.1.1, align 8
  %274 = shufflevector <4 x double> %unmaskedload41.1, <4 x double> poison, <1 x i32> zeroinitializer
  %275 = shufflevector <4 x double> %unmaskedload41.1, <4 x double> poison, <1 x i32> <i32 1>
  %276 = shufflevector <4 x double> %unmaskedload41.1, <4 x double> poison, <1 x i32> <i32 2>
  %277 = shufflevector <4 x double> %unmaskedload41.1, <4 x double> poison, <1 x i32> <i32 3>
  %278 = fmul <1 x double> %273, %274
  %279 = fmul <1 x double> %273, %275
  %280 = fmul <1 x double> %273, %276
  %281 = shufflevector <1 x double> %280, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %282 = fmul <1 x double> %273, %277
  %283 = shufflevector <1 x double> %282, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %284 = shufflevector <1 x double> %278, <1 x double> %279, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %285 = shufflevector <4 x double> %284, <4 x double> %281, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %286 = shufflevector <4 x double> %285, <4 x double> %283, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %287 = fadd <4 x double> %268, %286
  store <4 x double> %287, ptr %248, align 8
  %288 = add nuw nsw i64 %250, 2
  br label %.critedge.1.1

.preheader.1.2:                                   ; preds = %.critedge.1.1
  %289 = getelementptr double, ptr %207, i64 8
  %.promoted68 = load <4 x double>, ptr %289, align 8
  br label %.critedge.1.2

.critedge.1.2:                                    ; preds = %.critedge.1.2.1, %.preheader.1.2
  %290 = phi <4 x double> [ %.promoted68, %.preheader.1.2 ], [ %328, %.critedge.1.2.1 ]
  %291 = phi i64 [ 0, %.preheader.1.2 ], [ %329, %.critedge.1.2.1 ]
  %292 = mul nuw nsw i64 %291, 63
  %293 = getelementptr double, ptr %206, i64 %291
  %294 = load double, ptr %293, align 8
  %295 = insertelement <1 x double> poison, double %294, i64 0
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1.2, i64 %292
  %unmaskedload43 = load <4 x double>, ptr %gep.1.2, align 8
  %296 = shufflevector <4 x double> %unmaskedload43, <4 x double> poison, <1 x i32> zeroinitializer
  %297 = shufflevector <4 x double> %unmaskedload43, <4 x double> poison, <1 x i32> <i32 1>
  %298 = shufflevector <4 x double> %unmaskedload43, <4 x double> poison, <1 x i32> <i32 2>
  %299 = shufflevector <4 x double> %unmaskedload43, <4 x double> poison, <1 x i32> <i32 3>
  %300 = fmul <1 x double> %295, %296
  %301 = fmul <1 x double> %295, %297
  %302 = fmul <1 x double> %295, %298
  %303 = shufflevector <1 x double> %302, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %304 = fmul <1 x double> %295, %299
  %305 = shufflevector <1 x double> %304, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %306 = shufflevector <1 x double> %300, <1 x double> %301, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %307 = shufflevector <4 x double> %306, <4 x double> %303, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %308 = shufflevector <4 x double> %307, <4 x double> %305, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %309 = fadd <4 x double> %290, %308
  store <4 x double> %309, ptr %289, align 8
  %310 = or disjoint i64 %291, 1
  %exitcond.1.2.not = icmp eq i64 %310, 33
  br i1 %exitcond.1.2.not, label %.preheader.1.3, label %.critedge.1.2.1

.critedge.1.2.1:                                  ; preds = %.critedge.1.2
  %311 = mul nuw nsw i64 %310, 63
  %312 = getelementptr double, ptr %206, i64 %310
  %313 = load double, ptr %312, align 8
  %314 = insertelement <1 x double> poison, double %313, i64 0
  %gep.1.2.1 = getelementptr double, ptr %invariant.gep.1.2, i64 %311
  %unmaskedload43.1 = load <4 x double>, ptr %gep.1.2.1, align 8
  %315 = shufflevector <4 x double> %unmaskedload43.1, <4 x double> poison, <1 x i32> zeroinitializer
  %316 = shufflevector <4 x double> %unmaskedload43.1, <4 x double> poison, <1 x i32> <i32 1>
  %317 = shufflevector <4 x double> %unmaskedload43.1, <4 x double> poison, <1 x i32> <i32 2>
  %318 = shufflevector <4 x double> %unmaskedload43.1, <4 x double> poison, <1 x i32> <i32 3>
  %319 = fmul <1 x double> %314, %315
  %320 = fmul <1 x double> %314, %316
  %321 = fmul <1 x double> %314, %317
  %322 = shufflevector <1 x double> %321, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %323 = fmul <1 x double> %314, %318
  %324 = shufflevector <1 x double> %323, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %325 = shufflevector <1 x double> %319, <1 x double> %320, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %326 = shufflevector <4 x double> %325, <4 x double> %322, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %327 = shufflevector <4 x double> %326, <4 x double> %324, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %328 = fadd <4 x double> %309, %327
  store <4 x double> %328, ptr %289, align 8
  %329 = add nuw nsw i64 %291, 2
  br label %.critedge.1.2

.preheader.1.3:                                   ; preds = %.critedge.1.2
  %330 = getelementptr double, ptr %207, i64 12
  %.promoted67 = load <4 x double>, ptr %330, align 8
  br label %.critedge.1.3

.critedge.1.3:                                    ; preds = %.critedge.1.3.1, %.preheader.1.3
  %331 = phi <4 x double> [ %.promoted67, %.preheader.1.3 ], [ %369, %.critedge.1.3.1 ]
  %332 = phi i64 [ 0, %.preheader.1.3 ], [ %370, %.critedge.1.3.1 ]
  %333 = mul nuw nsw i64 %332, 63
  %334 = getelementptr double, ptr %206, i64 %332
  %335 = load double, ptr %334, align 8
  %336 = insertelement <1 x double> poison, double %335, i64 0
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1.3, i64 %333
  %unmaskedload45 = load <4 x double>, ptr %gep.1.3, align 8
  %337 = shufflevector <4 x double> %unmaskedload45, <4 x double> poison, <1 x i32> zeroinitializer
  %338 = shufflevector <4 x double> %unmaskedload45, <4 x double> poison, <1 x i32> <i32 1>
  %339 = shufflevector <4 x double> %unmaskedload45, <4 x double> poison, <1 x i32> <i32 2>
  %340 = shufflevector <4 x double> %unmaskedload45, <4 x double> poison, <1 x i32> <i32 3>
  %341 = fmul <1 x double> %336, %337
  %342 = fmul <1 x double> %336, %338
  %343 = fmul <1 x double> %336, %339
  %344 = shufflevector <1 x double> %343, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %345 = fmul <1 x double> %336, %340
  %346 = shufflevector <1 x double> %345, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %347 = shufflevector <1 x double> %341, <1 x double> %342, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %348 = shufflevector <4 x double> %347, <4 x double> %344, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %349 = shufflevector <4 x double> %348, <4 x double> %346, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %350 = fadd <4 x double> %331, %349
  store <4 x double> %350, ptr %330, align 8
  %351 = or disjoint i64 %332, 1
  %exitcond.1.3.not = icmp eq i64 %351, 33
  br i1 %exitcond.1.3.not, label %371, label %.critedge.1.3.1

.critedge.1.3.1:                                  ; preds = %.critedge.1.3
  %352 = mul nuw nsw i64 %351, 63
  %353 = getelementptr double, ptr %206, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = insertelement <1 x double> poison, double %354, i64 0
  %gep.1.3.1 = getelementptr double, ptr %invariant.gep.1.3, i64 %352
  %unmaskedload45.1 = load <4 x double>, ptr %gep.1.3.1, align 8
  %356 = shufflevector <4 x double> %unmaskedload45.1, <4 x double> poison, <1 x i32> zeroinitializer
  %357 = shufflevector <4 x double> %unmaskedload45.1, <4 x double> poison, <1 x i32> <i32 1>
  %358 = shufflevector <4 x double> %unmaskedload45.1, <4 x double> poison, <1 x i32> <i32 2>
  %359 = shufflevector <4 x double> %unmaskedload45.1, <4 x double> poison, <1 x i32> <i32 3>
  %360 = fmul <1 x double> %355, %356
  %361 = fmul <1 x double> %355, %357
  %362 = fmul <1 x double> %355, %358
  %363 = shufflevector <1 x double> %362, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %364 = fmul <1 x double> %355, %359
  %365 = shufflevector <1 x double> %364, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %366 = shufflevector <1 x double> %360, <1 x double> %361, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %367 = shufflevector <4 x double> %366, <4 x double> %363, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %368 = shufflevector <4 x double> %367, <4 x double> %365, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %369 = fadd <4 x double> %350, %368
  store <4 x double> %369, ptr %330, align 8
  %370 = add nuw nsw i64 %332, 2
  br label %.critedge.1.3

371:                                              ; preds = %.critedge.1.3
  %372 = add nuw nsw i64 %202, 1
  %exitcond19.1.not = icmp eq i64 %372, %26
  br i1 %exitcond19.1.not, label %373, label %.preheader16.1

373:                                              ; preds = %371
  %374 = getelementptr double, ptr %28, i64 32
  br label %.preheader16.2

.preheader16.2:                                   ; preds = %544, %373
  %375 = phi i64 [ 0, %373 ], [ %545, %544 ]
  %376 = add nuw nsw i64 %375, %24
  %377 = mul nuw nsw i64 %376, 33
  %378 = mul nuw nsw i64 %375, 63
  %379 = getelementptr double, ptr %1, i64 %377
  %380 = getelementptr double, ptr %374, i64 %378
  %.promoted66 = load <4 x double>, ptr %380, align 8
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2.180, %.preheader16.2
  %381 = phi <4 x double> [ %.promoted66, %.preheader16.2 ], [ %419, %.critedge.2.180 ]
  %382 = phi i64 [ 0, %.preheader16.2 ], [ %420, %.critedge.2.180 ]
  %383 = mul nuw nsw i64 %382, 63
  %384 = getelementptr double, ptr %379, i64 %382
  %385 = load double, ptr %384, align 8
  %386 = insertelement <1 x double> poison, double %385, i64 0
  %gep.2 = getelementptr double, ptr %22, i64 %383
  %unmaskedload47 = load <4 x double>, ptr %gep.2, align 8
  %387 = shufflevector <4 x double> %unmaskedload47, <4 x double> poison, <1 x i32> zeroinitializer
  %388 = shufflevector <4 x double> %unmaskedload47, <4 x double> poison, <1 x i32> <i32 1>
  %389 = shufflevector <4 x double> %unmaskedload47, <4 x double> poison, <1 x i32> <i32 2>
  %390 = shufflevector <4 x double> %unmaskedload47, <4 x double> poison, <1 x i32> <i32 3>
  %391 = fmul <1 x double> %386, %387
  %392 = fmul <1 x double> %386, %388
  %393 = fmul <1 x double> %386, %389
  %394 = shufflevector <1 x double> %393, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %395 = fmul <1 x double> %386, %390
  %396 = shufflevector <1 x double> %395, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %397 = shufflevector <1 x double> %391, <1 x double> %392, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %398 = shufflevector <4 x double> %397, <4 x double> %394, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %399 = shufflevector <4 x double> %398, <4 x double> %396, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %400 = fadd <4 x double> %381, %399
  store <4 x double> %400, ptr %380, align 8
  %401 = or disjoint i64 %382, 1
  %exitcond.2.not = icmp eq i64 %401, 33
  br i1 %exitcond.2.not, label %.preheader.2.1, label %.critedge.2.180

.critedge.2.180:                                  ; preds = %.critedge.2
  %402 = mul nuw nsw i64 %401, 63
  %403 = getelementptr double, ptr %379, i64 %401
  %404 = load double, ptr %403, align 8
  %405 = insertelement <1 x double> poison, double %404, i64 0
  %gep.2.179 = getelementptr double, ptr %22, i64 %402
  %unmaskedload47.1 = load <4 x double>, ptr %gep.2.179, align 8
  %406 = shufflevector <4 x double> %unmaskedload47.1, <4 x double> poison, <1 x i32> zeroinitializer
  %407 = shufflevector <4 x double> %unmaskedload47.1, <4 x double> poison, <1 x i32> <i32 1>
  %408 = shufflevector <4 x double> %unmaskedload47.1, <4 x double> poison, <1 x i32> <i32 2>
  %409 = shufflevector <4 x double> %unmaskedload47.1, <4 x double> poison, <1 x i32> <i32 3>
  %410 = fmul <1 x double> %405, %406
  %411 = fmul <1 x double> %405, %407
  %412 = fmul <1 x double> %405, %408
  %413 = shufflevector <1 x double> %412, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %414 = fmul <1 x double> %405, %409
  %415 = shufflevector <1 x double> %414, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %416 = shufflevector <1 x double> %410, <1 x double> %411, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %417 = shufflevector <4 x double> %416, <4 x double> %413, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %418 = shufflevector <4 x double> %417, <4 x double> %415, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %419 = fadd <4 x double> %400, %418
  store <4 x double> %419, ptr %380, align 8
  %420 = add nuw nsw i64 %382, 2
  br label %.critedge.2

.preheader.2.1:                                   ; preds = %.critedge.2
  %421 = getelementptr double, ptr %380, i64 4
  %.promoted65 = load <4 x double>, ptr %421, align 8
  br label %.critedge.2.1

.critedge.2.1:                                    ; preds = %.critedge.2.1.1, %.preheader.2.1
  %422 = phi <4 x double> [ %.promoted65, %.preheader.2.1 ], [ %460, %.critedge.2.1.1 ]
  %423 = phi i64 [ 0, %.preheader.2.1 ], [ %461, %.critedge.2.1.1 ]
  %424 = mul nuw nsw i64 %423, 63
  %425 = getelementptr double, ptr %379, i64 %423
  %426 = load double, ptr %425, align 8
  %427 = insertelement <1 x double> poison, double %426, i64 0
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2.1, i64 %424
  %unmaskedload49 = load <4 x double>, ptr %gep.2.1, align 8
  %428 = shufflevector <4 x double> %unmaskedload49, <4 x double> poison, <1 x i32> zeroinitializer
  %429 = shufflevector <4 x double> %unmaskedload49, <4 x double> poison, <1 x i32> <i32 1>
  %430 = shufflevector <4 x double> %unmaskedload49, <4 x double> poison, <1 x i32> <i32 2>
  %431 = shufflevector <4 x double> %unmaskedload49, <4 x double> poison, <1 x i32> <i32 3>
  %432 = fmul <1 x double> %427, %428
  %433 = fmul <1 x double> %427, %429
  %434 = fmul <1 x double> %427, %430
  %435 = shufflevector <1 x double> %434, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %436 = fmul <1 x double> %427, %431
  %437 = shufflevector <1 x double> %436, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %438 = shufflevector <1 x double> %432, <1 x double> %433, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %439 = shufflevector <4 x double> %438, <4 x double> %435, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %440 = shufflevector <4 x double> %439, <4 x double> %437, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %441 = fadd <4 x double> %422, %440
  store <4 x double> %441, ptr %421, align 8
  %442 = or disjoint i64 %423, 1
  %exitcond.2.1.not = icmp eq i64 %442, 33
  br i1 %exitcond.2.1.not, label %.preheader.2.2, label %.critedge.2.1.1

.critedge.2.1.1:                                  ; preds = %.critedge.2.1
  %443 = mul nuw nsw i64 %442, 63
  %444 = getelementptr double, ptr %379, i64 %442
  %445 = load double, ptr %444, align 8
  %446 = insertelement <1 x double> poison, double %445, i64 0
  %gep.2.1.1 = getelementptr double, ptr %invariant.gep.2.1, i64 %443
  %unmaskedload49.1 = load <4 x double>, ptr %gep.2.1.1, align 8
  %447 = shufflevector <4 x double> %unmaskedload49.1, <4 x double> poison, <1 x i32> zeroinitializer
  %448 = shufflevector <4 x double> %unmaskedload49.1, <4 x double> poison, <1 x i32> <i32 1>
  %449 = shufflevector <4 x double> %unmaskedload49.1, <4 x double> poison, <1 x i32> <i32 2>
  %450 = shufflevector <4 x double> %unmaskedload49.1, <4 x double> poison, <1 x i32> <i32 3>
  %451 = fmul <1 x double> %446, %447
  %452 = fmul <1 x double> %446, %448
  %453 = fmul <1 x double> %446, %449
  %454 = shufflevector <1 x double> %453, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %455 = fmul <1 x double> %446, %450
  %456 = shufflevector <1 x double> %455, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %457 = shufflevector <1 x double> %451, <1 x double> %452, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %458 = shufflevector <4 x double> %457, <4 x double> %454, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %459 = shufflevector <4 x double> %458, <4 x double> %456, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %460 = fadd <4 x double> %441, %459
  store <4 x double> %460, ptr %421, align 8
  %461 = add nuw nsw i64 %423, 2
  br label %.critedge.2.1

.preheader.2.2:                                   ; preds = %.critedge.2.1
  %462 = getelementptr double, ptr %380, i64 8
  %.promoted64 = load <4 x double>, ptr %462, align 8
  br label %.critedge.2.2

.critedge.2.2:                                    ; preds = %.critedge.2.2.1, %.preheader.2.2
  %463 = phi <4 x double> [ %.promoted64, %.preheader.2.2 ], [ %501, %.critedge.2.2.1 ]
  %464 = phi i64 [ 0, %.preheader.2.2 ], [ %502, %.critedge.2.2.1 ]
  %465 = mul nuw nsw i64 %464, 63
  %466 = getelementptr double, ptr %379, i64 %464
  %467 = load double, ptr %466, align 8
  %468 = insertelement <1 x double> poison, double %467, i64 0
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2.2, i64 %465
  %unmaskedload51 = load <4 x double>, ptr %gep.2.2, align 8
  %469 = shufflevector <4 x double> %unmaskedload51, <4 x double> poison, <1 x i32> zeroinitializer
  %470 = shufflevector <4 x double> %unmaskedload51, <4 x double> poison, <1 x i32> <i32 1>
  %471 = shufflevector <4 x double> %unmaskedload51, <4 x double> poison, <1 x i32> <i32 2>
  %472 = shufflevector <4 x double> %unmaskedload51, <4 x double> poison, <1 x i32> <i32 3>
  %473 = fmul <1 x double> %468, %469
  %474 = fmul <1 x double> %468, %470
  %475 = fmul <1 x double> %468, %471
  %476 = shufflevector <1 x double> %475, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %477 = fmul <1 x double> %468, %472
  %478 = shufflevector <1 x double> %477, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %479 = shufflevector <1 x double> %473, <1 x double> %474, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %480 = shufflevector <4 x double> %479, <4 x double> %476, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %481 = shufflevector <4 x double> %480, <4 x double> %478, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %482 = fadd <4 x double> %463, %481
  store <4 x double> %482, ptr %462, align 8
  %483 = or disjoint i64 %464, 1
  %exitcond.2.2.not = icmp eq i64 %483, 33
  br i1 %exitcond.2.2.not, label %.preheader.2.3, label %.critedge.2.2.1

.critedge.2.2.1:                                  ; preds = %.critedge.2.2
  %484 = mul nuw nsw i64 %483, 63
  %485 = getelementptr double, ptr %379, i64 %483
  %486 = load double, ptr %485, align 8
  %487 = insertelement <1 x double> poison, double %486, i64 0
  %gep.2.2.1 = getelementptr double, ptr %invariant.gep.2.2, i64 %484
  %unmaskedload51.1 = load <4 x double>, ptr %gep.2.2.1, align 8
  %488 = shufflevector <4 x double> %unmaskedload51.1, <4 x double> poison, <1 x i32> zeroinitializer
  %489 = shufflevector <4 x double> %unmaskedload51.1, <4 x double> poison, <1 x i32> <i32 1>
  %490 = shufflevector <4 x double> %unmaskedload51.1, <4 x double> poison, <1 x i32> <i32 2>
  %491 = shufflevector <4 x double> %unmaskedload51.1, <4 x double> poison, <1 x i32> <i32 3>
  %492 = fmul <1 x double> %487, %488
  %493 = fmul <1 x double> %487, %489
  %494 = fmul <1 x double> %487, %490
  %495 = shufflevector <1 x double> %494, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %496 = fmul <1 x double> %487, %491
  %497 = shufflevector <1 x double> %496, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %498 = shufflevector <1 x double> %492, <1 x double> %493, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %499 = shufflevector <4 x double> %498, <4 x double> %495, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %500 = shufflevector <4 x double> %499, <4 x double> %497, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %501 = fadd <4 x double> %482, %500
  store <4 x double> %501, ptr %462, align 8
  %502 = add nuw nsw i64 %464, 2
  br label %.critedge.2.2

.preheader.2.3:                                   ; preds = %.critedge.2.2
  %503 = getelementptr double, ptr %380, i64 12
  %.promoted63 = load <4 x double>, ptr %503, align 8
  br label %.critedge.2.3

.critedge.2.3:                                    ; preds = %.critedge.2.3.1, %.preheader.2.3
  %504 = phi <4 x double> [ %.promoted63, %.preheader.2.3 ], [ %542, %.critedge.2.3.1 ]
  %505 = phi i64 [ 0, %.preheader.2.3 ], [ %543, %.critedge.2.3.1 ]
  %506 = mul nuw nsw i64 %505, 63
  %507 = getelementptr double, ptr %379, i64 %505
  %508 = load double, ptr %507, align 8
  %509 = insertelement <1 x double> poison, double %508, i64 0
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2.3, i64 %506
  %unmaskedload53 = load <4 x double>, ptr %gep.2.3, align 8
  %510 = shufflevector <4 x double> %unmaskedload53, <4 x double> poison, <1 x i32> zeroinitializer
  %511 = shufflevector <4 x double> %unmaskedload53, <4 x double> poison, <1 x i32> <i32 1>
  %512 = shufflevector <4 x double> %unmaskedload53, <4 x double> poison, <1 x i32> <i32 2>
  %513 = shufflevector <4 x double> %unmaskedload53, <4 x double> poison, <1 x i32> <i32 3>
  %514 = fmul <1 x double> %509, %510
  %515 = fmul <1 x double> %509, %511
  %516 = fmul <1 x double> %509, %512
  %517 = shufflevector <1 x double> %516, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %518 = fmul <1 x double> %509, %513
  %519 = shufflevector <1 x double> %518, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %520 = shufflevector <1 x double> %514, <1 x double> %515, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %521 = shufflevector <4 x double> %520, <4 x double> %517, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %522 = shufflevector <4 x double> %521, <4 x double> %519, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %523 = fadd <4 x double> %504, %522
  store <4 x double> %523, ptr %503, align 8
  %524 = or disjoint i64 %505, 1
  %exitcond.2.3.not = icmp eq i64 %524, 33
  br i1 %exitcond.2.3.not, label %544, label %.critedge.2.3.1

.critedge.2.3.1:                                  ; preds = %.critedge.2.3
  %525 = mul nuw nsw i64 %524, 63
  %526 = getelementptr double, ptr %379, i64 %524
  %527 = load double, ptr %526, align 8
  %528 = insertelement <1 x double> poison, double %527, i64 0
  %gep.2.3.1 = getelementptr double, ptr %invariant.gep.2.3, i64 %525
  %unmaskedload53.1 = load <4 x double>, ptr %gep.2.3.1, align 8
  %529 = shufflevector <4 x double> %unmaskedload53.1, <4 x double> poison, <1 x i32> zeroinitializer
  %530 = shufflevector <4 x double> %unmaskedload53.1, <4 x double> poison, <1 x i32> <i32 1>
  %531 = shufflevector <4 x double> %unmaskedload53.1, <4 x double> poison, <1 x i32> <i32 2>
  %532 = shufflevector <4 x double> %unmaskedload53.1, <4 x double> poison, <1 x i32> <i32 3>
  %533 = fmul <1 x double> %528, %529
  %534 = fmul <1 x double> %528, %530
  %535 = fmul <1 x double> %528, %531
  %536 = shufflevector <1 x double> %535, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %537 = fmul <1 x double> %528, %532
  %538 = shufflevector <1 x double> %537, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %539 = shufflevector <1 x double> %533, <1 x double> %534, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %540 = shufflevector <4 x double> %539, <4 x double> %536, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %541 = shufflevector <4 x double> %540, <4 x double> %538, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %542 = fadd <4 x double> %523, %541
  store <4 x double> %542, ptr %503, align 8
  %543 = add nuw nsw i64 %505, 2
  br label %.critedge.2.3

544:                                              ; preds = %.critedge.2.3
  %545 = add nuw nsw i64 %375, 1
  %exitcond19.2.not = icmp eq i64 %545, %26
  br i1 %exitcond19.2.not, label %546, label %.preheader16.2

546:                                              ; preds = %544
  %547 = getelementptr double, ptr %28, i64 48
  br label %.preheader16.3

.preheader16.3:                                   ; preds = %695, %546
  %548 = phi i64 [ 0, %546 ], [ %696, %695 ]
  %549 = add nuw nsw i64 %548, %24
  %550 = mul nuw nsw i64 %549, 33
  %551 = mul nuw nsw i64 %548, 63
  %552 = getelementptr double, ptr %1, i64 %550
  %553 = getelementptr double, ptr %547, i64 %551
  %.promoted62 = load <4 x double>, ptr %553, align 8
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3.182, %.preheader16.3
  %554 = phi <4 x double> [ %.promoted62, %.preheader16.3 ], [ %592, %.critedge.3.182 ]
  %555 = phi i64 [ 0, %.preheader16.3 ], [ %593, %.critedge.3.182 ]
  %556 = mul nuw nsw i64 %555, 63
  %557 = getelementptr double, ptr %552, i64 %555
  %558 = load double, ptr %557, align 8
  %559 = insertelement <1 x double> poison, double %558, i64 0
  %gep.3 = getelementptr double, ptr %23, i64 %556
  %unmaskedload55 = load <4 x double>, ptr %gep.3, align 8
  %560 = shufflevector <4 x double> %unmaskedload55, <4 x double> poison, <1 x i32> zeroinitializer
  %561 = shufflevector <4 x double> %unmaskedload55, <4 x double> poison, <1 x i32> <i32 1>
  %562 = shufflevector <4 x double> %unmaskedload55, <4 x double> poison, <1 x i32> <i32 2>
  %563 = shufflevector <4 x double> %unmaskedload55, <4 x double> poison, <1 x i32> <i32 3>
  %564 = fmul <1 x double> %559, %560
  %565 = fmul <1 x double> %559, %561
  %566 = fmul <1 x double> %559, %562
  %567 = shufflevector <1 x double> %566, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %568 = fmul <1 x double> %559, %563
  %569 = shufflevector <1 x double> %568, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %570 = shufflevector <1 x double> %564, <1 x double> %565, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %571 = shufflevector <4 x double> %570, <4 x double> %567, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %572 = shufflevector <4 x double> %571, <4 x double> %569, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %573 = fadd <4 x double> %554, %572
  store <4 x double> %573, ptr %553, align 8
  %574 = or disjoint i64 %555, 1
  %exitcond.3.not = icmp eq i64 %574, 33
  br i1 %exitcond.3.not, label %.preheader.3.1, label %.critedge.3.182

.critedge.3.182:                                  ; preds = %.critedge.3
  %575 = mul nuw nsw i64 %574, 63
  %576 = getelementptr double, ptr %552, i64 %574
  %577 = load double, ptr %576, align 8
  %578 = insertelement <1 x double> poison, double %577, i64 0
  %gep.3.181 = getelementptr double, ptr %23, i64 %575
  %unmaskedload55.1 = load <4 x double>, ptr %gep.3.181, align 8
  %579 = shufflevector <4 x double> %unmaskedload55.1, <4 x double> poison, <1 x i32> zeroinitializer
  %580 = shufflevector <4 x double> %unmaskedload55.1, <4 x double> poison, <1 x i32> <i32 1>
  %581 = shufflevector <4 x double> %unmaskedload55.1, <4 x double> poison, <1 x i32> <i32 2>
  %582 = shufflevector <4 x double> %unmaskedload55.1, <4 x double> poison, <1 x i32> <i32 3>
  %583 = fmul <1 x double> %578, %579
  %584 = fmul <1 x double> %578, %580
  %585 = fmul <1 x double> %578, %581
  %586 = shufflevector <1 x double> %585, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %587 = fmul <1 x double> %578, %582
  %588 = shufflevector <1 x double> %587, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %589 = shufflevector <1 x double> %583, <1 x double> %584, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %590 = shufflevector <4 x double> %589, <4 x double> %586, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %591 = shufflevector <4 x double> %590, <4 x double> %588, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %592 = fadd <4 x double> %573, %591
  store <4 x double> %592, ptr %553, align 8
  %593 = add nuw nsw i64 %555, 2
  br label %.critedge.3

.preheader.3.1:                                   ; preds = %.critedge.3
  %594 = getelementptr double, ptr %553, i64 4
  %.promoted61 = load <4 x double>, ptr %594, align 8
  br label %.critedge.3.1

.critedge.3.1:                                    ; preds = %.critedge.3.1.1, %.preheader.3.1
  %595 = phi <4 x double> [ %.promoted61, %.preheader.3.1 ], [ %633, %.critedge.3.1.1 ]
  %596 = phi i64 [ 0, %.preheader.3.1 ], [ %634, %.critedge.3.1.1 ]
  %597 = mul nuw nsw i64 %596, 63
  %598 = getelementptr double, ptr %552, i64 %596
  %599 = load double, ptr %598, align 8
  %600 = insertelement <1 x double> poison, double %599, i64 0
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3.1, i64 %597
  %unmaskedload57 = load <4 x double>, ptr %gep.3.1, align 8
  %601 = shufflevector <4 x double> %unmaskedload57, <4 x double> poison, <1 x i32> zeroinitializer
  %602 = shufflevector <4 x double> %unmaskedload57, <4 x double> poison, <1 x i32> <i32 1>
  %603 = shufflevector <4 x double> %unmaskedload57, <4 x double> poison, <1 x i32> <i32 2>
  %604 = shufflevector <4 x double> %unmaskedload57, <4 x double> poison, <1 x i32> <i32 3>
  %605 = fmul <1 x double> %600, %601
  %606 = fmul <1 x double> %600, %602
  %607 = fmul <1 x double> %600, %603
  %608 = shufflevector <1 x double> %607, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %609 = fmul <1 x double> %600, %604
  %610 = shufflevector <1 x double> %609, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %611 = shufflevector <1 x double> %605, <1 x double> %606, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %612 = shufflevector <4 x double> %611, <4 x double> %608, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %613 = shufflevector <4 x double> %612, <4 x double> %610, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %614 = fadd <4 x double> %595, %613
  store <4 x double> %614, ptr %594, align 8
  %615 = or disjoint i64 %596, 1
  %exitcond.3.1.not = icmp eq i64 %615, 33
  br i1 %exitcond.3.1.not, label %.preheader.3.2, label %.critedge.3.1.1

.critedge.3.1.1:                                  ; preds = %.critedge.3.1
  %616 = mul nuw nsw i64 %615, 63
  %617 = getelementptr double, ptr %552, i64 %615
  %618 = load double, ptr %617, align 8
  %619 = insertelement <1 x double> poison, double %618, i64 0
  %gep.3.1.1 = getelementptr double, ptr %invariant.gep.3.1, i64 %616
  %unmaskedload57.1 = load <4 x double>, ptr %gep.3.1.1, align 8
  %620 = shufflevector <4 x double> %unmaskedload57.1, <4 x double> poison, <1 x i32> zeroinitializer
  %621 = shufflevector <4 x double> %unmaskedload57.1, <4 x double> poison, <1 x i32> <i32 1>
  %622 = shufflevector <4 x double> %unmaskedload57.1, <4 x double> poison, <1 x i32> <i32 2>
  %623 = shufflevector <4 x double> %unmaskedload57.1, <4 x double> poison, <1 x i32> <i32 3>
  %624 = fmul <1 x double> %619, %620
  %625 = fmul <1 x double> %619, %621
  %626 = fmul <1 x double> %619, %622
  %627 = shufflevector <1 x double> %626, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %628 = fmul <1 x double> %619, %623
  %629 = shufflevector <1 x double> %628, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %630 = shufflevector <1 x double> %624, <1 x double> %625, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %631 = shufflevector <4 x double> %630, <4 x double> %627, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %632 = shufflevector <4 x double> %631, <4 x double> %629, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %633 = fadd <4 x double> %614, %632
  store <4 x double> %633, ptr %594, align 8
  %634 = add nuw nsw i64 %596, 2
  br label %.critedge.3.1

.preheader.3.2:                                   ; preds = %.critedge.3.1
  %635 = getelementptr double, ptr %553, i64 8
  %.promoted = load <4 x double>, ptr %635, align 8
  br label %.critedge.3.2

.critedge.3.2:                                    ; preds = %.critedge.3.2.1, %.preheader.3.2
  %636 = phi <4 x double> [ %.promoted, %.preheader.3.2 ], [ %674, %.critedge.3.2.1 ]
  %637 = phi i64 [ 0, %.preheader.3.2 ], [ %675, %.critedge.3.2.1 ]
  %638 = mul nuw nsw i64 %637, 63
  %639 = getelementptr double, ptr %552, i64 %637
  %640 = load double, ptr %639, align 8
  %641 = insertelement <1 x double> poison, double %640, i64 0
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3.2, i64 %638
  %unmaskedload59 = load <4 x double>, ptr %gep.3.2, align 8
  %642 = shufflevector <4 x double> %unmaskedload59, <4 x double> poison, <1 x i32> zeroinitializer
  %643 = shufflevector <4 x double> %unmaskedload59, <4 x double> poison, <1 x i32> <i32 1>
  %644 = shufflevector <4 x double> %unmaskedload59, <4 x double> poison, <1 x i32> <i32 2>
  %645 = shufflevector <4 x double> %unmaskedload59, <4 x double> poison, <1 x i32> <i32 3>
  %646 = fmul <1 x double> %641, %642
  %647 = fmul <1 x double> %641, %643
  %648 = fmul <1 x double> %641, %644
  %649 = shufflevector <1 x double> %648, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %650 = fmul <1 x double> %641, %645
  %651 = shufflevector <1 x double> %650, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %652 = shufflevector <1 x double> %646, <1 x double> %647, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %653 = shufflevector <4 x double> %652, <4 x double> %649, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %654 = shufflevector <4 x double> %653, <4 x double> %651, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %655 = fadd <4 x double> %636, %654
  store <4 x double> %655, ptr %635, align 8
  %656 = or disjoint i64 %637, 1
  %exitcond.3.2.not = icmp eq i64 %656, 33
  br i1 %exitcond.3.2.not, label %.preheader.3.3, label %.critedge.3.2.1

.critedge.3.2.1:                                  ; preds = %.critedge.3.2
  %657 = mul nuw nsw i64 %656, 63
  %658 = getelementptr double, ptr %552, i64 %656
  %659 = load double, ptr %658, align 8
  %660 = insertelement <1 x double> poison, double %659, i64 0
  %gep.3.2.1 = getelementptr double, ptr %invariant.gep.3.2, i64 %657
  %unmaskedload59.1 = load <4 x double>, ptr %gep.3.2.1, align 8
  %661 = shufflevector <4 x double> %unmaskedload59.1, <4 x double> poison, <1 x i32> zeroinitializer
  %662 = shufflevector <4 x double> %unmaskedload59.1, <4 x double> poison, <1 x i32> <i32 1>
  %663 = shufflevector <4 x double> %unmaskedload59.1, <4 x double> poison, <1 x i32> <i32 2>
  %664 = shufflevector <4 x double> %unmaskedload59.1, <4 x double> poison, <1 x i32> <i32 3>
  %665 = fmul <1 x double> %660, %661
  %666 = fmul <1 x double> %660, %662
  %667 = fmul <1 x double> %660, %663
  %668 = shufflevector <1 x double> %667, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %669 = fmul <1 x double> %660, %664
  %670 = shufflevector <1 x double> %669, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %671 = shufflevector <1 x double> %665, <1 x double> %666, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %672 = shufflevector <4 x double> %671, <4 x double> %668, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %673 = shufflevector <4 x double> %672, <4 x double> %670, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %674 = fadd <4 x double> %655, %673
  store <4 x double> %674, ptr %635, align 8
  %675 = add nuw nsw i64 %637, 2
  br label %.critedge.3.2

.preheader.3.3:                                   ; preds = %.critedge.3.2
  %676 = getelementptr double, ptr %553, i64 12
  br label %.critedge.3.3

.critedge.3.3:                                    ; preds = %.critedge.3.3, %.preheader.3.3
  %677 = phi i64 [ 0, %.preheader.3.3 ], [ %694, %.critedge.3.3 ]
  %678 = mul nuw nsw i64 %677, 63
  %679 = getelementptr double, ptr %552, i64 %677
  %680 = load double, ptr %679, align 8
  %681 = insertelement <1 x double> poison, double %680, i64 0
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3.3, i64 %678
  %682 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.3.3, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> <double poison, double poison, double poison, double 0.000000e+00>)
  %683 = shufflevector <4 x double> %682, <4 x double> poison, <1 x i32> zeroinitializer
  %684 = shufflevector <4 x double> %682, <4 x double> poison, <1 x i32> <i32 1>
  %685 = shufflevector <4 x double> %682, <4 x double> poison, <1 x i32> <i32 2>
  %686 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %676, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>, <4 x double> poison)
  %687 = fmul <1 x double> %681, %683
  %688 = fmul <1 x double> %681, %684
  %689 = fmul <1 x double> %681, %685
  %690 = shufflevector <1 x double> %689, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %691 = shufflevector <1 x double> %687, <1 x double> %688, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %692 = shufflevector <4 x double> %691, <4 x double> %690, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %693 = fadd <4 x double> %686, %692
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %693, ptr %676, i32 8, <4 x i1> <i1 true, i1 true, i1 true, i1 false>)
  %694 = add nuw nsw i64 %677, 1
  %exitcond.3.3.not = icmp eq i64 %694, 33
  br i1 %exitcond.3.3.not, label %695, label %.critedge.3.3

695:                                              ; preds = %.critedge.3.3
  %696 = add nuw nsw i64 %548, 1
  %exitcond19.3.not = icmp eq i64 %696, %26
  br i1 %exitcond19.3.not, label %697, label %.preheader16.3

697:                                              ; preds = %695
  %698 = add nuw nsw i64 %24, 16
  %699 = icmp ult i64 %24, 111
  br i1 %699, label %.preheader17, label %700

700:                                              ; preds = %697
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
