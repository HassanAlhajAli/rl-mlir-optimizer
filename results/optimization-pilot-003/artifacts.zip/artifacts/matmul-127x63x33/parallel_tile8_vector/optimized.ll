; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader17.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %15, i8 0, i64 64008, i1 false)
  br label %.preheader17

.preheader17:                                     ; preds = %.preheader17.preheader, %91
  %21 = phi i64 [ %92, %91 ], [ 0, %.preheader17.preheader ]
  %22 = icmp eq i64 %21, 120
  %23 = select i1 %22, i64 7, i64 8
  %24 = mul nuw nsw i64 %21, 63
  %25 = getelementptr double, ptr %15, i64 %24
  br label %26

26:                                               ; preds = %.preheader17, %88
  %27 = phi i64 [ 0, %.preheader17 ], [ %89, %88 ]
  %28 = icmp eq i64 %27, 56
  %29 = getelementptr double, ptr %8, i64 %27
  %30 = getelementptr double, ptr %25, i64 %27
  %31 = select i1 %28, i32 3, i32 4
  %32 = insertelement <4 x i32> poison, i32 %31, i64 0
  %33 = shufflevector <4 x i32> %32, <4 x i32> poison, <4 x i32> zeroinitializer
  %34 = icmp ugt <4 x i32> %33, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.1 = getelementptr double, ptr %29, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %26, %86
  %35 = phi i64 [ 0, %26 ], [ %87, %86 ]
  %36 = add nuw nsw i64 %35, %21
  %37 = mul nuw nsw i64 %36, 33
  %38 = mul nuw nsw i64 %35, 63
  %39 = getelementptr double, ptr %1, i64 %37
  %40 = getelementptr double, ptr %30, i64 %38
  %.promoted = load <4 x double>, ptr %40, align 8
  br label %.critedge

.critedge:                                        ; preds = %.preheader16, %.critedge
  %41 = phi <4 x double> [ %.promoted, %.preheader16 ], [ %60, %.critedge ]
  %42 = phi i64 [ 0, %.preheader16 ], [ %61, %.critedge ]
  %43 = mul nuw nsw i64 %42, 63
  %44 = getelementptr double, ptr %39, i64 %42
  %45 = load double, ptr %44, align 8
  %46 = insertelement <1 x double> poison, double %45, i64 0
  %gep = getelementptr double, ptr %29, i64 %43
  %unmaskedload = load <4 x double>, ptr %gep, align 8
  %47 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %48 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %49 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %50 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %51 = fmul <1 x double> %46, %47
  %52 = fmul <1 x double> %46, %48
  %53 = fmul <1 x double> %46, %49
  %54 = shufflevector <1 x double> %53, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %55 = fmul <1 x double> %46, %50
  %56 = shufflevector <1 x double> %55, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %57 = shufflevector <1 x double> %51, <1 x double> %52, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %54, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %56, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %60 = fadd <4 x double> %41, %59
  store <4 x double> %60, ptr %40, align 8
  %61 = add nuw nsw i64 %42, 1
  %exitcond.not = icmp eq i64 %61, 33
  br i1 %exitcond.not, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %62 = getelementptr double, ptr %40, i64 4
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %63 = phi i64 [ 0, %.preheader.1 ], [ %85, %.critedge.1 ]
  %64 = mul nuw nsw i64 %63, 63
  %65 = getelementptr double, ptr %39, i64 %63
  %66 = load double, ptr %65, align 8
  %67 = insertelement <1 x double> poison, double %66, i64 0
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %64
  %68 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.1, i32 8, <4 x i1> %34, <4 x double> zeroinitializer)
  %69 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> zeroinitializer
  %70 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 1>
  %71 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 2>
  %72 = shufflevector <4 x double> %68, <4 x double> poison, <1 x i32> <i32 3>
  %73 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %62, i32 8, <4 x i1> %34, <4 x double> zeroinitializer)
  %74 = fmul <1 x double> %67, %69
  %75 = fmul <1 x double> %67, %70
  %76 = fmul <1 x double> %67, %71
  %77 = shufflevector <1 x double> %76, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %78 = fmul <1 x double> %67, %72
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = shufflevector <1 x double> %74, <1 x double> %75, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %81 = shufflevector <4 x double> %80, <4 x double> %77, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %82 = shufflevector <4 x double> %81, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %83 = select <4 x i1> %34, <4 x double> %73, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %84 = fadd <4 x double> %83, %82
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %84, ptr %62, i32 8, <4 x i1> %34)
  %85 = add nuw nsw i64 %63, 1
  %exitcond.not.1 = icmp eq i64 %85, 33
  br i1 %exitcond.not.1, label %86, label %.critedge.1

86:                                               ; preds = %.critedge.1
  %87 = add nuw nsw i64 %35, 1
  %exitcond19.not = icmp eq i64 %87, %23
  br i1 %exitcond19.not, label %88, label %.preheader16

88:                                               ; preds = %86
  %89 = add nuw nsw i64 %27, 8
  %90 = icmp ult i64 %27, 55
  br i1 %90, label %26, label %91

91:                                               ; preds = %88
  %92 = add nuw nsw i64 %21, 8
  %93 = icmp ult i64 %21, 119
  br i1 %93, label %.preheader17, label %94

94:                                               ; preds = %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %.unpack32, i8 0, i64 64008, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %74, %3
  %4 = phi i64 [ %75, %74 ], [ 0, %3 ]
  %5 = icmp eq i64 %4, 120
  %6 = select i1 %5, i64 7, i64 8
  %7 = mul nuw nsw i64 %4, 63
  %8 = getelementptr double, ptr %.unpack32, i64 %7
  br label %9

9:                                                ; preds = %71, %.preheader17.i
  %10 = phi i64 [ 0, %.preheader17.i ], [ %72, %71 ]
  %11 = icmp eq i64 %10, 56
  %12 = getelementptr double, ptr %.unpack17, i64 %10
  %13 = getelementptr double, ptr %8, i64 %10
  %14 = select i1 %11, i32 3, i32 4
  %15 = insertelement <4 x i32> poison, i32 %14, i64 0
  %16 = shufflevector <4 x i32> %15, <4 x i32> poison, <4 x i32> zeroinitializer
  %17 = icmp ugt <4 x i32> %16, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.i.1 = getelementptr double, ptr %12, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %69, %9
  %18 = phi i64 [ 0, %9 ], [ %70, %69 ]
  %19 = add nuw nsw i64 %18, %4
  %20 = mul nuw nsw i64 %19, 33
  %21 = mul nuw nsw i64 %18, 63
  %22 = getelementptr double, ptr %.unpack2, i64 %20
  %23 = getelementptr double, ptr %13, i64 %21
  %.promoted = load <4 x double>, ptr %23, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %24 = phi <4 x double> [ %.promoted, %.preheader16.i ], [ %43, %.critedge.i ]
  %25 = phi i64 [ 0, %.preheader16.i ], [ %44, %.critedge.i ]
  %26 = mul nuw nsw i64 %25, 63
  %27 = getelementptr double, ptr %22, i64 %25
  %28 = load double, ptr %27, align 8
  %29 = insertelement <1 x double> poison, double %28, i64 0
  %gep.i = getelementptr double, ptr %12, i64 %26
  %unmaskedload = load <4 x double>, ptr %gep.i, align 8
  %30 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %31 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %32 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %33 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %34 = fmul <1 x double> %29, %30
  %35 = fmul <1 x double> %29, %31
  %36 = fmul <1 x double> %29, %32
  %37 = shufflevector <1 x double> %36, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = fmul <1 x double> %29, %33
  %39 = shufflevector <1 x double> %38, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %40 = shufflevector <1 x double> %34, <1 x double> %35, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %39, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %43 = fadd <4 x double> %24, %42
  store <4 x double> %43, ptr %23, align 8
  %44 = add nuw nsw i64 %25, 1
  %exitcond.not.i = icmp eq i64 %44, 33
  br i1 %exitcond.not.i, label %.preheader.i.1, label %.critedge.i

.preheader.i.1:                                   ; preds = %.critedge.i
  %45 = getelementptr double, ptr %23, i64 4
  br label %.critedge.i.1

.critedge.i.1:                                    ; preds = %.critedge.i.1, %.preheader.i.1
  %46 = phi i64 [ 0, %.preheader.i.1 ], [ %68, %.critedge.i.1 ]
  %47 = mul nuw nsw i64 %46, 63
  %48 = getelementptr double, ptr %22, i64 %46
  %49 = load double, ptr %48, align 8
  %50 = insertelement <1 x double> poison, double %49, i64 0
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i.1, i64 %47
  %51 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.i.1, i32 8, <4 x i1> %17, <4 x double> zeroinitializer)
  %52 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> zeroinitializer
  %53 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 1>
  %54 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 2>
  %55 = shufflevector <4 x double> %51, <4 x double> poison, <1 x i32> <i32 3>
  %56 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %45, i32 8, <4 x i1> %17, <4 x double> zeroinitializer)
  %57 = fmul <1 x double> %50, %52
  %58 = fmul <1 x double> %50, %53
  %59 = fmul <1 x double> %50, %54
  %60 = shufflevector <1 x double> %59, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %61 = fmul <1 x double> %50, %55
  %62 = shufflevector <1 x double> %61, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %63 = shufflevector <1 x double> %57, <1 x double> %58, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %64 = shufflevector <4 x double> %63, <4 x double> %60, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %65 = shufflevector <4 x double> %64, <4 x double> %62, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %66 = select <4 x i1> %17, <4 x double> %56, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %67 = fadd <4 x double> %66, %65
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %67, ptr %45, i32 8, <4 x i1> %17)
  %68 = add nuw nsw i64 %46, 1
  %exitcond.not.i.1 = icmp eq i64 %68, 33
  br i1 %exitcond.not.i.1, label %69, label %.critedge.i.1

69:                                               ; preds = %.critedge.i.1
  %70 = add nuw nsw i64 %18, 1
  %exitcond19.not.i = icmp eq i64 %70, %6
  br i1 %exitcond19.not.i, label %71, label %.preheader16.i

71:                                               ; preds = %69
  %72 = add nuw nsw i64 %10, 8
  %73 = icmp ult i64 %10, 55
  br i1 %73, label %9, label %74

74:                                               ; preds = %71
  %75 = add nuw nsw i64 %4, 8
  %76 = icmp ult i64 %4, 119
  br i1 %76, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %74
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v4f64.p0(<4 x double>, ptr nocapture, i32 immarg, <4 x i1>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <4 x double> @llvm.masked.load.v4f64.p0(ptr nocapture, i32 immarg, <4 x i1>, <4 x double>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %10, i8 0, i64 64008, i1 false)
  br label %.preheader17.i

.preheader17.i:                                   ; preds = %81, %1
  %11 = phi i64 [ %82, %81 ], [ 0, %1 ]
  %12 = icmp eq i64 %11, 120
  %13 = select i1 %12, i64 7, i64 8
  %14 = mul nuw nsw i64 %11, 63
  %15 = getelementptr double, ptr %10, i64 %14
  br label %16

16:                                               ; preds = %78, %.preheader17.i
  %17 = phi i64 [ 0, %.preheader17.i ], [ %79, %78 ]
  %18 = icmp eq i64 %17, 56
  %19 = getelementptr double, ptr %7, i64 %17
  %20 = getelementptr double, ptr %15, i64 %17
  %21 = select i1 %18, i32 3, i32 4
  %22 = insertelement <4 x i32> poison, i32 %21, i64 0
  %23 = shufflevector <4 x i32> %22, <4 x i32> poison, <4 x i32> zeroinitializer
  %24 = icmp ugt <4 x i32> %23, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.i.1 = getelementptr double, ptr %19, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %76, %16
  %25 = phi i64 [ 0, %16 ], [ %77, %76 ]
  %26 = add nuw nsw i64 %25, %11
  %27 = mul nuw nsw i64 %26, 33
  %28 = mul nuw nsw i64 %25, 63
  %29 = getelementptr double, ptr %4, i64 %27
  %30 = getelementptr double, ptr %20, i64 %28
  %.promoted = load <4 x double>, ptr %30, align 8
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader16.i
  %31 = phi <4 x double> [ %.promoted, %.preheader16.i ], [ %50, %.critedge.i ]
  %32 = phi i64 [ 0, %.preheader16.i ], [ %51, %.critedge.i ]
  %33 = mul nuw nsw i64 %32, 63
  %34 = getelementptr double, ptr %29, i64 %32
  %35 = load double, ptr %34, align 8
  %36 = insertelement <1 x double> poison, double %35, i64 0
  %gep.i = getelementptr double, ptr %19, i64 %33
  %unmaskedload = load <4 x double>, ptr %gep.i, align 8
  %37 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %38 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %39 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %40 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %41 = fmul <1 x double> %36, %37
  %42 = fmul <1 x double> %36, %38
  %43 = fmul <1 x double> %36, %39
  %44 = shufflevector <1 x double> %43, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %45 = fmul <1 x double> %36, %40
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = shufflevector <1 x double> %41, <1 x double> %42, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %44, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %50 = fadd <4 x double> %31, %49
  store <4 x double> %50, ptr %30, align 8
  %51 = add nuw nsw i64 %32, 1
  %exitcond.not.i = icmp eq i64 %51, 33
  br i1 %exitcond.not.i, label %.preheader.i.1, label %.critedge.i

.preheader.i.1:                                   ; preds = %.critedge.i
  %52 = getelementptr double, ptr %30, i64 4
  br label %.critedge.i.1

.critedge.i.1:                                    ; preds = %.critedge.i.1, %.preheader.i.1
  %53 = phi i64 [ 0, %.preheader.i.1 ], [ %75, %.critedge.i.1 ]
  %54 = mul nuw nsw i64 %53, 63
  %55 = getelementptr double, ptr %29, i64 %53
  %56 = load double, ptr %55, align 8
  %57 = insertelement <1 x double> poison, double %56, i64 0
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i.1, i64 %54
  %58 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.i.1, i32 8, <4 x i1> %24, <4 x double> zeroinitializer)
  %59 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> zeroinitializer
  %60 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 1>
  %61 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 2>
  %62 = shufflevector <4 x double> %58, <4 x double> poison, <1 x i32> <i32 3>
  %63 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %52, i32 8, <4 x i1> %24, <4 x double> zeroinitializer)
  %64 = fmul <1 x double> %57, %59
  %65 = fmul <1 x double> %57, %60
  %66 = fmul <1 x double> %57, %61
  %67 = shufflevector <1 x double> %66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %68 = fmul <1 x double> %57, %62
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = shufflevector <1 x double> %64, <1 x double> %65, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %67, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %73 = select <4 x i1> %24, <4 x double> %63, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %74 = fadd <4 x double> %73, %72
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %74, ptr %52, i32 8, <4 x i1> %24)
  %75 = add nuw nsw i64 %53, 1
  %exitcond.not.i.1 = icmp eq i64 %75, 33
  br i1 %exitcond.not.i.1, label %76, label %.critedge.i.1

76:                                               ; preds = %.critedge.i.1
  %77 = add nuw nsw i64 %25, 1
  %exitcond19.not.i = icmp eq i64 %77, %13
  br i1 %exitcond19.not.i, label %78, label %.preheader16.i

78:                                               ; preds = %76
  %79 = add nuw nsw i64 %17, 8
  %80 = icmp ult i64 %17, 55
  br i1 %80, label %16, label %81

81:                                               ; preds = %78
  %82 = add nuw nsw i64 %11, 8
  %83 = icmp ult i64 %11, 119
  br i1 %83, label %.preheader17.i, label %kernel.exit

kernel.exit:                                      ; preds = %81
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %.unpack32.i, i8 0, i64 64008, i1 false)
  br label %.preheader17.i.i

.preheader17.i.i:                                 ; preds = %80, %1
  %10 = phi i64 [ %81, %80 ], [ 0, %1 ]
  %11 = icmp eq i64 %10, 120
  %12 = select i1 %11, i64 7, i64 8
  %13 = mul nuw nsw i64 %10, 63
  %14 = getelementptr double, ptr %.unpack32.i, i64 %13
  br label %15

15:                                               ; preds = %77, %.preheader17.i.i
  %16 = phi i64 [ 0, %.preheader17.i.i ], [ %78, %77 ]
  %17 = icmp eq i64 %16, 56
  %18 = getelementptr double, ptr %.unpack17.i, i64 %16
  %19 = getelementptr double, ptr %14, i64 %16
  %20 = select i1 %17, i32 3, i32 4
  %21 = insertelement <4 x i32> poison, i32 %20, i64 0
  %22 = shufflevector <4 x i32> %21, <4 x i32> poison, <4 x i32> zeroinitializer
  %23 = icmp ugt <4 x i32> %22, <i32 0, i32 1, i32 2, i32 3>
  %invariant.gep.i.i.1 = getelementptr double, ptr %18, i64 4
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %75, %15
  %24 = phi i64 [ 0, %15 ], [ %76, %75 ]
  %25 = add nuw nsw i64 %24, %10
  %26 = mul nuw nsw i64 %25, 33
  %27 = mul nuw nsw i64 %24, 63
  %28 = getelementptr double, ptr %.unpack2.i, i64 %26
  %29 = getelementptr double, ptr %19, i64 %27
  %.promoted = load <4 x double>, ptr %29, align 8
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader16.i.i
  %30 = phi <4 x double> [ %.promoted, %.preheader16.i.i ], [ %49, %.critedge.i.i ]
  %31 = phi i64 [ 0, %.preheader16.i.i ], [ %50, %.critedge.i.i ]
  %32 = mul nuw nsw i64 %31, 63
  %33 = getelementptr double, ptr %28, i64 %31
  %34 = load double, ptr %33, align 8
  %35 = insertelement <1 x double> poison, double %34, i64 0
  %gep.i.i = getelementptr double, ptr %18, i64 %32
  %unmaskedload = load <4 x double>, ptr %gep.i.i, align 8
  %36 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> zeroinitializer
  %37 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 1>
  %38 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 2>
  %39 = shufflevector <4 x double> %unmaskedload, <4 x double> poison, <1 x i32> <i32 3>
  %40 = fmul <1 x double> %35, %36
  %41 = fmul <1 x double> %35, %37
  %42 = fmul <1 x double> %35, %38
  %43 = shufflevector <1 x double> %42, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %44 = fmul <1 x double> %35, %39
  %45 = shufflevector <1 x double> %44, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %46 = shufflevector <1 x double> %40, <1 x double> %41, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %43, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %45, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %49 = fadd <4 x double> %30, %48
  store <4 x double> %49, ptr %29, align 8
  %50 = add nuw nsw i64 %31, 1
  %exitcond.not.i.i = icmp eq i64 %50, 33
  br i1 %exitcond.not.i.i, label %.preheader.i.i.1, label %.critedge.i.i

.preheader.i.i.1:                                 ; preds = %.critedge.i.i
  %51 = getelementptr double, ptr %29, i64 4
  br label %.critedge.i.i.1

.critedge.i.i.1:                                  ; preds = %.critedge.i.i.1, %.preheader.i.i.1
  %52 = phi i64 [ 0, %.preheader.i.i.1 ], [ %74, %.critedge.i.i.1 ]
  %53 = mul nuw nsw i64 %52, 63
  %54 = getelementptr double, ptr %28, i64 %52
  %55 = load double, ptr %54, align 8
  %56 = insertelement <1 x double> poison, double %55, i64 0
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i.1, i64 %53
  %57 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %gep.i.i.1, i32 8, <4 x i1> %23, <4 x double> zeroinitializer)
  %58 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> zeroinitializer
  %59 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 1>
  %60 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 2>
  %61 = shufflevector <4 x double> %57, <4 x double> poison, <1 x i32> <i32 3>
  %62 = tail call <4 x double> @llvm.masked.load.v4f64.p0(ptr %51, i32 8, <4 x i1> %23, <4 x double> zeroinitializer)
  %63 = fmul <1 x double> %56, %58
  %64 = fmul <1 x double> %56, %59
  %65 = fmul <1 x double> %56, %60
  %66 = shufflevector <1 x double> %65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = fmul <1 x double> %56, %61
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <1 x double> %63, <1 x double> %64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %70 = shufflevector <4 x double> %69, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %71 = shufflevector <4 x double> %70, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %72 = select <4 x i1> %23, <4 x double> %62, <4 x double> <double -0.000000e+00, double -0.000000e+00, double -0.000000e+00, double -0.000000e+00>
  %73 = fadd <4 x double> %72, %71
  tail call void @llvm.masked.store.v4f64.p0(<4 x double> %73, ptr %51, i32 8, <4 x i1> %23)
  %74 = add nuw nsw i64 %52, 1
  %exitcond.not.i.i.1 = icmp eq i64 %74, 33
  br i1 %exitcond.not.i.i.1, label %75, label %.critedge.i.i.1

75:                                               ; preds = %.critedge.i.i.1
  %76 = add nuw nsw i64 %24, 1
  %exitcond19.not.i.i = icmp eq i64 %76, %12
  br i1 %exitcond19.not.i.i, label %77, label %.preheader16.i.i

77:                                               ; preds = %75
  %78 = add nuw nsw i64 %16, 8
  %79 = icmp ult i64 %16, 55
  br i1 %79, label %15, label %80

80:                                               ; preds = %77
  %81 = add nuw nsw i64 %10, 8
  %82 = icmp ult i64 %10, 119
  br i1 %82, label %.preheader17.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %80
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
