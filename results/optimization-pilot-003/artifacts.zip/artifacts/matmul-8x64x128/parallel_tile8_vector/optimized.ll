; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader16.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader16.preheader, %108
  %21 = phi i64 [ %109, %108 ], [ 0, %.preheader16.preheader ]
  %invariant.gep27 = getelementptr double, ptr %15, i64 %21
  %invariant.gep25 = getelementptr double, ptr %8, i64 %21
  %invariant.gep21 = getelementptr double, ptr %invariant.gep.1, i64 %21
  br label %.preheader15

.preheader15:                                     ; preds = %.preheader16, %106
  %22 = phi i64 [ 0, %.preheader16 ], [ %107, %106 ]
  %23 = shl i64 %22, 7
  %24 = shl i64 %22, 6
  %gep = getelementptr double, ptr %invariant.gep27, i64 %24
  %.promoted = load <4 x double>, ptr %gep, align 8
  %invariant.gep23 = getelementptr double, ptr %1, i64 %23
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader15
  %25 = phi i64 [ 0, %.preheader15 ], [ %64, %.critedge ]
  %26 = phi <4 x double> [ %.promoted, %.preheader15 ], [ %63, %.critedge ]
  %27 = shl nuw nsw i64 %25, 6
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %25
  %28 = load double, ptr %gep24, align 8
  %29 = insertelement <1 x double> poison, double %28, i64 0
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %27
  %30 = load <4 x double>, ptr %gep26, align 8
  %31 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> zeroinitializer
  %32 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 1>
  %33 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 2>
  %34 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 3>
  %35 = fmul <1 x double> %29, %31
  %36 = fmul <1 x double> %29, %32
  %37 = fmul <1 x double> %29, %33
  %38 = shufflevector <1 x double> %37, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = fmul <1 x double> %29, %34
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = shufflevector <1 x double> %35, <1 x double> %36, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %43 = shufflevector <4 x double> %42, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %44 = fadd <4 x double> %26, %43
  store <4 x double> %44, ptr %gep, align 8
  %45 = or disjoint i64 %25, 1
  %46 = shl nuw nsw i64 %45, 6
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %45
  %47 = load double, ptr %gep24.1, align 8
  %48 = insertelement <1 x double> poison, double %47, i64 0
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %46
  %49 = load <4 x double>, ptr %gep26.1, align 8
  %50 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> zeroinitializer
  %51 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 1>
  %52 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 2>
  %53 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 3>
  %54 = fmul <1 x double> %48, %50
  %55 = fmul <1 x double> %48, %51
  %56 = fmul <1 x double> %48, %52
  %57 = shufflevector <1 x double> %56, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %58 = fmul <1 x double> %48, %53
  %59 = shufflevector <1 x double> %58, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %60 = shufflevector <1 x double> %54, <1 x double> %55, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %61 = shufflevector <4 x double> %60, <4 x double> %57, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %59, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %63 = fadd <4 x double> %44, %62
  store <4 x double> %63, ptr %gep, align 8
  %64 = add nuw nsw i64 %25, 2
  %exitcond.not.1 = icmp eq i64 %64, 128
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %65 = getelementptr double, ptr %gep, i64 4
  %.promoted.1 = load <4 x double>, ptr %65, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %23
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %66 = phi i64 [ 0, %.preheader.1 ], [ %105, %.critedge.1 ]
  %67 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %104, %.critedge.1 ]
  %68 = shl nuw nsw i64 %66, 6
  %gep20 = getelementptr double, ptr %invariant.gep, i64 %66
  %69 = load double, ptr %gep20, align 8
  %70 = insertelement <1 x double> poison, double %69, i64 0
  %gep22 = getelementptr double, ptr %invariant.gep21, i64 %68
  %71 = load <4 x double>, ptr %gep22, align 8
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> zeroinitializer
  %73 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 1>
  %74 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 2>
  %75 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 3>
  %76 = fmul <1 x double> %70, %72
  %77 = fmul <1 x double> %70, %73
  %78 = fmul <1 x double> %70, %74
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = fmul <1 x double> %70, %75
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = shufflevector <1 x double> %76, <1 x double> %77, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %84 = shufflevector <4 x double> %83, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %85 = fadd <4 x double> %67, %84
  store <4 x double> %85, ptr %65, align 8
  %86 = or disjoint i64 %66, 1
  %87 = shl nuw nsw i64 %86, 6
  %gep20.1 = getelementptr double, ptr %invariant.gep, i64 %86
  %88 = load double, ptr %gep20.1, align 8
  %89 = insertelement <1 x double> poison, double %88, i64 0
  %gep22.1 = getelementptr double, ptr %invariant.gep21, i64 %87
  %90 = load <4 x double>, ptr %gep22.1, align 8
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> zeroinitializer
  %92 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 1>
  %93 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 2>
  %94 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 3>
  %95 = fmul <1 x double> %89, %91
  %96 = fmul <1 x double> %89, %92
  %97 = fmul <1 x double> %89, %93
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = fmul <1 x double> %89, %94
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %95, <1 x double> %96, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %104 = fadd <4 x double> %85, %103
  store <4 x double> %104, ptr %65, align 8
  %105 = add nuw nsw i64 %66, 2
  %exitcond.1.not.1 = icmp eq i64 %105, 128
  br i1 %exitcond.1.not.1, label %106, label %.critedge.1

106:                                              ; preds = %.critedge.1
  %107 = add nuw nsw i64 %22, 1
  %exitcond19.not = icmp eq i64 %107, 8
  br i1 %exitcond19.not, label %108, label %.preheader15

108:                                              ; preds = %106
  %109 = add nuw nsw i64 %21, 8
  %110 = icmp ult i64 %21, 56
  br i1 %110, label %.preheader16, label %111

111:                                              ; preds = %108
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %91, %3
  %4 = phi i64 [ %92, %91 ], [ 0, %3 ]
  %invariant.gep27.i = getelementptr double, ptr %.unpack32, i64 %4
  %invariant.gep25.i = getelementptr double, ptr %.unpack17, i64 %4
  %invariant.gep21.i = getelementptr double, ptr %invariant.gep.1.i, i64 %4
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %89, %.preheader16.i
  %5 = phi i64 [ 0, %.preheader16.i ], [ %90, %89 ]
  %6 = shl i64 %5, 7
  %7 = shl i64 %5, 6
  %gep.i = getelementptr double, ptr %invariant.gep27.i, i64 %7
  %.promoted.i = load <4 x double>, ptr %gep.i, align 8
  %invariant.gep23.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %8 = phi i64 [ 0, %.preheader15.i ], [ %47, %.critedge.i ]
  %9 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %46, %.critedge.i ]
  %10 = shl nuw nsw i64 %8, 6
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %8
  %11 = load double, ptr %gep24.i, align 8
  %12 = insertelement <1 x double> poison, double %11, i64 0
  %gep26.i = getelementptr double, ptr %invariant.gep25.i, i64 %10
  %13 = load <4 x double>, ptr %gep26.i, align 8
  %14 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> zeroinitializer
  %15 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 1>
  %16 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 2>
  %17 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 3>
  %18 = fmul <1 x double> %12, %14
  %19 = fmul <1 x double> %12, %15
  %20 = fmul <1 x double> %12, %16
  %21 = shufflevector <1 x double> %20, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %22 = fmul <1 x double> %12, %17
  %23 = shufflevector <1 x double> %22, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = shufflevector <1 x double> %18, <1 x double> %19, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %25 = shufflevector <4 x double> %24, <4 x double> %21, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %26 = shufflevector <4 x double> %25, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %27 = fadd <4 x double> %9, %26
  store <4 x double> %27, ptr %gep.i, align 8
  %28 = or disjoint i64 %8, 1
  %29 = shl nuw nsw i64 %28, 6
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %28
  %30 = load double, ptr %gep24.i.1, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %gep26.i.1 = getelementptr double, ptr %invariant.gep25.i, i64 %29
  %32 = load <4 x double>, ptr %gep26.i.1, align 8
  %33 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> zeroinitializer
  %34 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 1>
  %35 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 2>
  %36 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 3>
  %37 = fmul <1 x double> %31, %33
  %38 = fmul <1 x double> %31, %34
  %39 = fmul <1 x double> %31, %35
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = fmul <1 x double> %31, %36
  %42 = shufflevector <1 x double> %41, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %43 = shufflevector <1 x double> %37, <1 x double> %38, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %42, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %46 = fadd <4 x double> %27, %45
  store <4 x double> %46, ptr %gep.i, align 8
  %47 = add nuw nsw i64 %8, 2
  %exitcond.not.i.1 = icmp eq i64 %47, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %48 = getelementptr double, ptr %gep.i, i64 4
  %.promoted.1.i = load <4 x double>, ptr %48, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %49 = phi i64 [ 0, %.preheader.1.i ], [ %88, %.critedge.1.i ]
  %50 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %87, %.critedge.1.i ]
  %51 = shl nuw nsw i64 %49, 6
  %gep20.i = getelementptr double, ptr %invariant.gep23.i, i64 %49
  %52 = load double, ptr %gep20.i, align 8
  %53 = insertelement <1 x double> poison, double %52, i64 0
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %51
  %54 = load <4 x double>, ptr %gep22.i, align 8
  %55 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> zeroinitializer
  %56 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 1>
  %57 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 2>
  %58 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 3>
  %59 = fmul <1 x double> %53, %55
  %60 = fmul <1 x double> %53, %56
  %61 = fmul <1 x double> %53, %57
  %62 = shufflevector <1 x double> %61, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %63 = fmul <1 x double> %53, %58
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = shufflevector <1 x double> %59, <1 x double> %60, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %62, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %68 = fadd <4 x double> %50, %67
  store <4 x double> %68, ptr %48, align 8
  %69 = or disjoint i64 %49, 1
  %70 = shl nuw nsw i64 %69, 6
  %gep20.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %69
  %71 = load double, ptr %gep20.i.1, align 8
  %72 = insertelement <1 x double> poison, double %71, i64 0
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %70
  %73 = load <4 x double>, ptr %gep22.i.1, align 8
  %74 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> zeroinitializer
  %75 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 1>
  %76 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 2>
  %77 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 3>
  %78 = fmul <1 x double> %72, %74
  %79 = fmul <1 x double> %72, %75
  %80 = fmul <1 x double> %72, %76
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = fmul <1 x double> %72, %77
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = shufflevector <1 x double> %78, <1 x double> %79, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %85 = shufflevector <4 x double> %84, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %87 = fadd <4 x double> %68, %86
  store <4 x double> %87, ptr %48, align 8
  %88 = add nuw nsw i64 %49, 2
  %exitcond.1.not.i.1 = icmp eq i64 %88, 128
  br i1 %exitcond.1.not.i.1, label %89, label %.critedge.1.i

89:                                               ; preds = %.critedge.1.i
  %90 = add nuw nsw i64 %5, 1
  %exitcond19.not.i = icmp eq i64 %90, 8
  br i1 %exitcond19.not.i, label %91, label %.preheader15.i

91:                                               ; preds = %89
  %92 = add nuw nsw i64 %4, 8
  %93 = icmp ult i64 %4, 56
  br i1 %93, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %91
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %10, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %98, %1
  %11 = phi i64 [ %99, %98 ], [ 0, %1 ]
  %invariant.gep27.i = getelementptr double, ptr %10, i64 %11
  %invariant.gep25.i = getelementptr double, ptr %7, i64 %11
  %invariant.gep21.i = getelementptr double, ptr %invariant.gep.1.i, i64 %11
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %96, %.preheader16.i
  %12 = phi i64 [ 0, %.preheader16.i ], [ %97, %96 ]
  %13 = shl i64 %12, 7
  %14 = shl i64 %12, 6
  %gep.i = getelementptr double, ptr %invariant.gep27.i, i64 %14
  %.promoted.i = load <4 x double>, ptr %gep.i, align 8
  %invariant.gep23.i = getelementptr double, ptr %4, i64 %13
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %15 = phi i64 [ 0, %.preheader15.i ], [ %54, %.critedge.i ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %53, %.critedge.i ]
  %17 = shl nuw nsw i64 %15, 6
  %gep24.i = getelementptr double, ptr %invariant.gep23.i, i64 %15
  %18 = load double, ptr %gep24.i, align 8
  %19 = insertelement <1 x double> poison, double %18, i64 0
  %gep26.i = getelementptr double, ptr %invariant.gep25.i, i64 %17
  %20 = load <4 x double>, ptr %gep26.i, align 8
  %21 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> zeroinitializer
  %22 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 1>
  %23 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 2>
  %24 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 3>
  %25 = fmul <1 x double> %19, %21
  %26 = fmul <1 x double> %19, %22
  %27 = fmul <1 x double> %19, %23
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = fmul <1 x double> %19, %24
  %30 = shufflevector <1 x double> %29, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = shufflevector <1 x double> %25, <1 x double> %26, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %32 = shufflevector <4 x double> %31, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %34 = fadd <4 x double> %16, %33
  store <4 x double> %34, ptr %gep.i, align 8
  %35 = or disjoint i64 %15, 1
  %36 = shl nuw nsw i64 %35, 6
  %gep24.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %35
  %37 = load double, ptr %gep24.i.1, align 8
  %38 = insertelement <1 x double> poison, double %37, i64 0
  %gep26.i.1 = getelementptr double, ptr %invariant.gep25.i, i64 %36
  %39 = load <4 x double>, ptr %gep26.i.1, align 8
  %40 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> zeroinitializer
  %41 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 1>
  %42 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 2>
  %43 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 3>
  %44 = fmul <1 x double> %38, %40
  %45 = fmul <1 x double> %38, %41
  %46 = fmul <1 x double> %38, %42
  %47 = shufflevector <1 x double> %46, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %48 = fmul <1 x double> %38, %43
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %44, <1 x double> %45, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %47, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fadd <4 x double> %34, %52
  store <4 x double> %53, ptr %gep.i, align 8
  %54 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %54, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %55 = getelementptr double, ptr %gep.i, i64 4
  %.promoted.1.i = load <4 x double>, ptr %55, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %56 = phi i64 [ 0, %.preheader.1.i ], [ %95, %.critedge.1.i ]
  %57 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %94, %.critedge.1.i ]
  %58 = shl nuw nsw i64 %56, 6
  %gep20.i = getelementptr double, ptr %invariant.gep23.i, i64 %56
  %59 = load double, ptr %gep20.i, align 8
  %60 = insertelement <1 x double> poison, double %59, i64 0
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %58
  %61 = load <4 x double>, ptr %gep22.i, align 8
  %62 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> zeroinitializer
  %63 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 1>
  %64 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 2>
  %65 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 3>
  %66 = fmul <1 x double> %60, %62
  %67 = fmul <1 x double> %60, %63
  %68 = fmul <1 x double> %60, %64
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = fmul <1 x double> %60, %65
  %71 = shufflevector <1 x double> %70, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %72 = shufflevector <1 x double> %66, <1 x double> %67, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %73 = shufflevector <4 x double> %72, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %74 = shufflevector <4 x double> %73, <4 x double> %71, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %75 = fadd <4 x double> %57, %74
  store <4 x double> %75, ptr %55, align 8
  %76 = or disjoint i64 %56, 1
  %77 = shl nuw nsw i64 %76, 6
  %gep20.i.1 = getelementptr double, ptr %invariant.gep23.i, i64 %76
  %78 = load double, ptr %gep20.i.1, align 8
  %79 = insertelement <1 x double> poison, double %78, i64 0
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %77
  %80 = load <4 x double>, ptr %gep22.i.1, align 8
  %81 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> zeroinitializer
  %82 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 1>
  %83 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 2>
  %84 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 3>
  %85 = fmul <1 x double> %79, %81
  %86 = fmul <1 x double> %79, %82
  %87 = fmul <1 x double> %79, %83
  %88 = shufflevector <1 x double> %87, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %89 = fmul <1 x double> %79, %84
  %90 = shufflevector <1 x double> %89, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %91 = shufflevector <1 x double> %85, <1 x double> %86, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %88, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %90, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %94 = fadd <4 x double> %75, %93
  store <4 x double> %94, ptr %55, align 8
  %95 = add nuw nsw i64 %56, 2
  %exitcond.1.not.i.1 = icmp eq i64 %95, 128
  br i1 %exitcond.1.not.i.1, label %96, label %.critedge.1.i

96:                                               ; preds = %.critedge.1.i
  %97 = add nuw nsw i64 %12, 1
  %exitcond19.not.i = icmp eq i64 %97, 8
  br i1 %exitcond19.not.i, label %98, label %.preheader15.i

98:                                               ; preds = %96
  %99 = add nuw nsw i64 %11, 8
  %100 = icmp ult i64 %11, 56
  br i1 %100, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %98
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32.i, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %97, %1
  %10 = phi i64 [ %98, %97 ], [ 0, %1 ]
  %invariant.gep27.i.i = getelementptr double, ptr %.unpack32.i, i64 %10
  %invariant.gep25.i.i = getelementptr double, ptr %.unpack17.i, i64 %10
  %invariant.gep21.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %10
  br label %.preheader15.i.i

.preheader15.i.i:                                 ; preds = %95, %.preheader16.i.i
  %11 = phi i64 [ 0, %.preheader16.i.i ], [ %96, %95 ]
  %12 = shl i64 %11, 7
  %13 = shl i64 %11, 6
  %gep.i.i = getelementptr double, ptr %invariant.gep27.i.i, i64 %13
  %.promoted.i.i = load <4 x double>, ptr %gep.i.i, align 8
  %invariant.gep23.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader15.i.i
  %14 = phi i64 [ 0, %.preheader15.i.i ], [ %53, %.critedge.i.i ]
  %15 = phi <4 x double> [ %.promoted.i.i, %.preheader15.i.i ], [ %52, %.critedge.i.i ]
  %16 = shl nuw nsw i64 %14, 6
  %gep24.i.i = getelementptr double, ptr %invariant.gep23.i.i, i64 %14
  %17 = load double, ptr %gep24.i.i, align 8
  %18 = insertelement <1 x double> poison, double %17, i64 0
  %gep26.i.i = getelementptr double, ptr %invariant.gep25.i.i, i64 %16
  %19 = load <4 x double>, ptr %gep26.i.i, align 8
  %20 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> zeroinitializer
  %21 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 1>
  %22 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 2>
  %23 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 3>
  %24 = fmul <1 x double> %18, %20
  %25 = fmul <1 x double> %18, %21
  %26 = fmul <1 x double> %18, %22
  %27 = shufflevector <1 x double> %26, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %28 = fmul <1 x double> %18, %23
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = shufflevector <1 x double> %24, <1 x double> %25, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %31 = shufflevector <4 x double> %30, <4 x double> %27, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %32 = shufflevector <4 x double> %31, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %33 = fadd <4 x double> %15, %32
  store <4 x double> %33, ptr %gep.i.i, align 8
  %34 = or disjoint i64 %14, 1
  %35 = shl nuw nsw i64 %34, 6
  %gep24.i.i.1 = getelementptr double, ptr %invariant.gep23.i.i, i64 %34
  %36 = load double, ptr %gep24.i.i.1, align 8
  %37 = insertelement <1 x double> poison, double %36, i64 0
  %gep26.i.i.1 = getelementptr double, ptr %invariant.gep25.i.i, i64 %35
  %38 = load <4 x double>, ptr %gep26.i.i.1, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %37, %39
  %44 = fmul <1 x double> %37, %40
  %45 = fmul <1 x double> %37, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %37, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %33, %51
  store <4 x double> %52, ptr %gep.i.i, align 8
  %53 = add nuw nsw i64 %14, 2
  %exitcond.not.i.i.1 = icmp eq i64 %53, 128
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %54 = getelementptr double, ptr %gep.i.i, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %54, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %55 = phi i64 [ 0, %.preheader.1.i.i ], [ %94, %.critedge.1.i.i ]
  %56 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %93, %.critedge.1.i.i ]
  %57 = shl nuw nsw i64 %55, 6
  %gep20.i.i = getelementptr double, ptr %invariant.gep23.i.i, i64 %55
  %58 = load double, ptr %gep20.i.i, align 8
  %59 = insertelement <1 x double> poison, double %58, i64 0
  %gep22.i.i = getelementptr double, ptr %invariant.gep21.i.i, i64 %57
  %60 = load <4 x double>, ptr %gep22.i.i, align 8
  %61 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> zeroinitializer
  %62 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 1>
  %63 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 2>
  %64 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 3>
  %65 = fmul <1 x double> %59, %61
  %66 = fmul <1 x double> %59, %62
  %67 = fmul <1 x double> %59, %63
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = fmul <1 x double> %59, %64
  %70 = shufflevector <1 x double> %69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %71 = shufflevector <1 x double> %65, <1 x double> %66, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %73 = shufflevector <4 x double> %72, <4 x double> %70, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %74 = fadd <4 x double> %56, %73
  store <4 x double> %74, ptr %54, align 8
  %75 = or disjoint i64 %55, 1
  %76 = shl nuw nsw i64 %75, 6
  %gep20.i.i.1 = getelementptr double, ptr %invariant.gep23.i.i, i64 %75
  %77 = load double, ptr %gep20.i.i.1, align 8
  %78 = insertelement <1 x double> poison, double %77, i64 0
  %gep22.i.i.1 = getelementptr double, ptr %invariant.gep21.i.i, i64 %76
  %79 = load <4 x double>, ptr %gep22.i.i.1, align 8
  %80 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> zeroinitializer
  %81 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 1>
  %82 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 2>
  %83 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 3>
  %84 = fmul <1 x double> %78, %80
  %85 = fmul <1 x double> %78, %81
  %86 = fmul <1 x double> %78, %82
  %87 = shufflevector <1 x double> %86, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %88 = fmul <1 x double> %78, %83
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = shufflevector <1 x double> %84, <1 x double> %85, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %91 = shufflevector <4 x double> %90, <4 x double> %87, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %93 = fadd <4 x double> %74, %92
  store <4 x double> %93, ptr %54, align 8
  %94 = add nuw nsw i64 %55, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %94, 128
  br i1 %exitcond.1.not.i.i.1, label %95, label %.critedge.1.i.i

95:                                               ; preds = %.critedge.1.i.i
  %96 = add nuw nsw i64 %11, 1
  %exitcond19.not.i.i = icmp eq i64 %96, 8
  br i1 %exitcond19.not.i.i, label %97, label %.preheader15.i.i

97:                                               ; preds = %95
  %98 = add nuw nsw i64 %10, 8
  %99 = icmp ult i64 %10, 56
  br i1 %99, label %.preheader16.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %97
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
