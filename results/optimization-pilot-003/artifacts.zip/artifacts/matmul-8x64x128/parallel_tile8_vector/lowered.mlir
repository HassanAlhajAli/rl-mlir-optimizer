module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(128 : index) : i64
    %29 = llvm.mlir.constant(64 : index) : i64
    %30 = llvm.mlir.constant(1 : index) : i64
    %31 = llvm.mlir.constant(4 : index) : i64
    %32 = llvm.mlir.constant(0 : index) : i64
    %33 = llvm.mlir.constant(8 : index) : i64
    %34 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%32 : i64)
  ^bb1(%35: i64):  // 2 preds: ^bb0, ^bb5
    %36 = llvm.icmp "slt" %35, %33 : i64
    llvm.cond_br %36, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%32 : i64)
  ^bb3(%37: i64):  // 2 preds: ^bb2, ^bb4
    %38 = llvm.icmp "slt" %37, %29 : i64
    llvm.cond_br %38, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %39 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %40 = llvm.mlir.constant(64 : index) : i64
    %41 = llvm.mul %35, %40  : i64
    %42 = llvm.add %41, %37  : i64
    %43 = llvm.getelementptr %39[%42] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %34, %43 : f64, !llvm.ptr
    %44 = llvm.add %37, %30  : i64
    llvm.br ^bb3(%44 : i64)
  ^bb5:  // pred: ^bb3
    %45 = llvm.add %35, %30  : i64
    llvm.br ^bb1(%45 : i64)
  ^bb6:  // pred: ^bb1
    %46 = llvm.mlir.constant(1 : index) : i64
    %47 = llvm.alloca %46 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %48 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %49 = llvm.insertvalue %47, %48[0] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.insertvalue %47, %49[1] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.mlir.constant(0 : index) : i64
    %52 = llvm.insertvalue %51, %50[2] : !llvm.struct<(ptr, ptr, i64)> 
    %53 = llvm.mlir.constant(1 : index) : i64
    %54 = llvm.alloca %53 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %55 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %56 = llvm.insertvalue %54, %55[0] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.insertvalue %54, %56[1] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.mlir.constant(0 : index) : i64
    %59 = llvm.insertvalue %58, %57[2] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.mlir.constant(1 : index) : i64
    %61 = llvm.alloca %60 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %62 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %63 = llvm.insertvalue %61, %62[0] : !llvm.struct<(ptr, ptr, i64)> 
    %64 = llvm.insertvalue %61, %63[1] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.mlir.constant(0 : index) : i64
    %66 = llvm.insertvalue %65, %64[2] : !llvm.struct<(ptr, ptr, i64)> 
    %67 = llvm.mlir.constant(1 : index) : i64
    %68 = llvm.alloca %67 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %69 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %70 = llvm.insertvalue %68, %69[0] : !llvm.struct<(ptr, ptr, i64)> 
    %71 = llvm.insertvalue %68, %70[1] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.mlir.constant(0 : index) : i64
    %73 = llvm.insertvalue %72, %71[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%32 : i64)
  ^bb7(%74: i64):  // 2 preds: ^bb6, ^bb29
    %75 = llvm.icmp "slt" %74, %29 : i64
    llvm.cond_br %75, ^bb8, ^bb30
  ^bb8:  // pred: ^bb7
    %76 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %79 = llvm.insertvalue %76, %78[0] : !llvm.struct<(ptr, ptr, i64)> 
    %80 = llvm.insertvalue %77, %79[1] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.mlir.constant(0 : index) : i64
    %82 = llvm.insertvalue %81, %80[2] : !llvm.struct<(ptr, ptr, i64)> 
    %83 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %91 = llvm.insertvalue %88, %90[0] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.insertvalue %89, %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.mlir.constant(0 : index) : i64
    %94 = llvm.insertvalue %93, %92[2] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %96 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.br ^bb9(%32 : i64)
  ^bb9(%100: i64):  // 2 preds: ^bb8, ^bb28
    %101 = llvm.icmp "slt" %100, %33 : i64
    llvm.cond_br %101, ^bb10, ^bb29
  ^bb10:  // pred: ^bb9
    llvm.br ^bb11(%32 : i64)
  ^bb11(%102: i64):  // 2 preds: ^bb10, ^bb27
    %103 = llvm.icmp "slt" %102, %33 : i64
    llvm.cond_br %103, ^bb12, ^bb28
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%32 : i64)
  ^bb13(%104: i64):  // 2 preds: ^bb12, ^bb26
    %105 = llvm.icmp "slt" %104, %28 : i64
    llvm.cond_br %105, ^bb14, ^bb27
  ^bb14:  // pred: ^bb13
    %106 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %108 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %109 = llvm.insertvalue %106, %108[0] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.insertvalue %107, %109[1] : !llvm.struct<(ptr, ptr, i64)> 
    %111 = llvm.mlir.constant(0 : index) : i64
    %112 = llvm.insertvalue %111, %110[2] : !llvm.struct<(ptr, ptr, i64)> 
    %113 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %114 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %118 = llvm.mul %100, %28  : i64
    %119 = llvm.add %118, %104  : i64
    %120 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %121 = llvm.insertvalue %106, %120[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %122 = llvm.insertvalue %107, %121[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.insertvalue %119, %122[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.mlir.constant(1 : index) : i64
    %125 = llvm.insertvalue %124, %123[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %126 = llvm.mlir.constant(128 : index) : i64
    %127 = llvm.insertvalue %126, %125[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %128 = llvm.mlir.constant(1 : index) : i64
    %129 = llvm.insertvalue %128, %127[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %130 = llvm.mlir.constant(1 : index) : i64
    %131 = llvm.insertvalue %130, %129[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %132 = llvm.mul %104, %29  : i64
    %133 = llvm.add %74, %132  : i64
    %134 = llvm.add %133, %102  : i64
    %135 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %136 = llvm.insertvalue %76, %135[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %137 = llvm.insertvalue %77, %136[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.insertvalue %134, %137[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.mlir.constant(1 : index) : i64
    %140 = llvm.insertvalue %139, %138[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %141 = llvm.mlir.constant(64 : index) : i64
    %142 = llvm.insertvalue %141, %140[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %143 = llvm.mlir.constant(4 : index) : i64
    %144 = llvm.insertvalue %143, %142[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %145 = llvm.mlir.constant(1 : index) : i64
    %146 = llvm.insertvalue %145, %144[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %147 = llvm.mul %100, %29  : i64
    %148 = llvm.add %74, %147  : i64
    %149 = llvm.add %148, %102  : i64
    %150 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %151 = llvm.insertvalue %88, %150[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %152 = llvm.insertvalue %89, %151[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %153 = llvm.insertvalue %149, %152[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.mlir.constant(1 : index) : i64
    %155 = llvm.insertvalue %154, %153[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %156 = llvm.mlir.constant(64 : index) : i64
    %157 = llvm.insertvalue %156, %155[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %158 = llvm.mlir.constant(4 : index) : i64
    %159 = llvm.insertvalue %158, %157[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %160 = llvm.mlir.constant(1 : index) : i64
    %161 = llvm.insertvalue %160, %159[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %162 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %163 = llvm.extractvalue %52[0] : !llvm.struct<(ptr, ptr, i64)> 
    %164 = llvm.insertvalue %163, %162[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %165 = llvm.extractvalue %52[1] : !llvm.struct<(ptr, ptr, i64)> 
    %166 = llvm.insertvalue %165, %164[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %167 = llvm.mlir.constant(0 : index) : i64
    %168 = llvm.insertvalue %167, %166[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.mlir.constant(1 : index) : i64
    %170 = llvm.insertvalue %169, %168[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.mlir.constant(1 : index) : i64
    %172 = llvm.insertvalue %171, %170[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb15(%32 : i64)
  ^bb15(%173: i64):  // 2 preds: ^bb14, ^bb16
    %174 = llvm.icmp "slt" %173, %30 : i64
    llvm.cond_br %174, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %175 = llvm.getelementptr %107[%119] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %176 = llvm.mlir.constant(128 : index) : i64
    %177 = llvm.mul %173, %176  : i64
    %178 = llvm.add %177, %32  : i64
    %179 = llvm.getelementptr %175[%178] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %180 = llvm.load %179 : !llvm.ptr -> f64
    %181 = llvm.mlir.undef : vector<1xf64>
    %182 = llvm.mlir.constant(0 : i32) : i32
    %183 = llvm.insertelement %180, %181[%182 : i32] : vector<1xf64>
    %184 = llvm.shufflevector %183, %181 [0] : vector<1xf64> 
    %185 = llvm.getelementptr %165[%173] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %184, %185 : vector<1xf64>, !llvm.ptr
    %186 = llvm.add %173, %30  : i64
    llvm.br ^bb15(%186 : i64)
  ^bb17:  // pred: ^bb15
    %187 = llvm.load %47 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %188 = llvm.extractvalue %187[0] : !llvm.array<1 x vector<1xf64>> 
    %189 = llvm.insertvalue %188, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %190 = llvm.insertvalue %188, %189[1] : !llvm.array<4 x vector<1xf64>> 
    %191 = llvm.insertvalue %188, %190[2] : !llvm.array<4 x vector<1xf64>> 
    %192 = llvm.insertvalue %188, %191[3] : !llvm.array<4 x vector<1xf64>> 
    %193 = llvm.insertvalue %192, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %194 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %195 = llvm.extractvalue %59[0] : !llvm.struct<(ptr, ptr, i64)> 
    %196 = llvm.insertvalue %195, %194[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %197 = llvm.extractvalue %59[1] : !llvm.struct<(ptr, ptr, i64)> 
    %198 = llvm.insertvalue %197, %196[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %199 = llvm.mlir.constant(0 : index) : i64
    %200 = llvm.insertvalue %199, %198[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %201 = llvm.mlir.constant(1 : index) : i64
    %202 = llvm.insertvalue %201, %200[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.mlir.constant(1 : index) : i64
    %204 = llvm.insertvalue %203, %202[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb18(%32 : i64)
  ^bb18(%205: i64):  // 2 preds: ^bb17, ^bb19
    %206 = llvm.icmp "slt" %205, %30 : i64
    llvm.cond_br %206, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %207 = llvm.extractvalue %146[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %208 = llvm.extractvalue %146[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %209 = llvm.getelementptr %207[%208] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %210 = llvm.mlir.constant(64 : index) : i64
    %211 = llvm.mul %205, %210  : i64
    %212 = llvm.add %211, %32  : i64
    %213 = llvm.getelementptr %209[%212] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %214 = llvm.load %213 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %215 = llvm.getelementptr %197[%205] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %214, %215 : vector<4xf64>, !llvm.ptr
    %216 = llvm.add %205, %30  : i64
    llvm.br ^bb18(%216 : i64)
  ^bb20:  // pred: ^bb18
    %217 = llvm.load %54 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %218 = llvm.extractvalue %217[0] : !llvm.array<1 x vector<4xf64>> 
    %219 = llvm.mlir.constant(0 : i64) : i64
    %220 = llvm.extractelement %218[%219 : i64] : vector<4xf64>
    %221 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %222 = llvm.mlir.constant(0 : i64) : i64
    %223 = llvm.insertelement %220, %221[%222 : i64] : vector<1xf64>
    %224 = llvm.insertvalue %223, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %225 = llvm.extractvalue %217[0] : !llvm.array<1 x vector<4xf64>> 
    %226 = llvm.mlir.constant(1 : i64) : i64
    %227 = llvm.extractelement %225[%226 : i64] : vector<4xf64>
    %228 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %229 = llvm.mlir.constant(0 : i64) : i64
    %230 = llvm.insertelement %227, %228[%229 : i64] : vector<1xf64>
    %231 = llvm.insertvalue %230, %224[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %232 = llvm.extractvalue %217[0] : !llvm.array<1 x vector<4xf64>> 
    %233 = llvm.mlir.constant(2 : i64) : i64
    %234 = llvm.extractelement %232[%233 : i64] : vector<4xf64>
    %235 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %236 = llvm.mlir.constant(0 : i64) : i64
    %237 = llvm.insertelement %234, %235[%236 : i64] : vector<1xf64>
    %238 = llvm.insertvalue %237, %231[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %239 = llvm.extractvalue %217[0] : !llvm.array<1 x vector<4xf64>> 
    %240 = llvm.mlir.constant(3 : i64) : i64
    %241 = llvm.extractelement %239[%240 : i64] : vector<4xf64>
    %242 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %243 = llvm.mlir.constant(0 : i64) : i64
    %244 = llvm.insertelement %241, %242[%243 : i64] : vector<1xf64>
    %245 = llvm.insertvalue %244, %238[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %246 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %247 = llvm.extractvalue %66[0] : !llvm.struct<(ptr, ptr, i64)> 
    %248 = llvm.insertvalue %247, %246[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %249 = llvm.extractvalue %66[1] : !llvm.struct<(ptr, ptr, i64)> 
    %250 = llvm.insertvalue %249, %248[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %251 = llvm.mlir.constant(0 : index) : i64
    %252 = llvm.insertvalue %251, %250[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %253 = llvm.mlir.constant(1 : index) : i64
    %254 = llvm.insertvalue %253, %252[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %255 = llvm.mlir.constant(1 : index) : i64
    %256 = llvm.insertvalue %255, %254[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb21(%32 : i64)
  ^bb21(%257: i64):  // 2 preds: ^bb20, ^bb22
    %258 = llvm.icmp "slt" %257, %30 : i64
    llvm.cond_br %258, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    %259 = llvm.extractvalue %161[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %260 = llvm.extractvalue %161[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %261 = llvm.getelementptr %259[%260] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %262 = llvm.mlir.constant(64 : index) : i64
    %263 = llvm.mul %257, %262  : i64
    %264 = llvm.add %263, %32  : i64
    %265 = llvm.getelementptr %261[%264] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %266 = llvm.load %265 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %267 = llvm.getelementptr %249[%257] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %266, %267 : vector<4xf64>, !llvm.ptr
    %268 = llvm.add %257, %30  : i64
    llvm.br ^bb21(%268 : i64)
  ^bb23:  // pred: ^bb21
    %269 = llvm.load %61 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %270 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %271 = llvm.extractvalue %193[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %272 = llvm.fmul %271, %223  : vector<1xf64>
    %273 = llvm.insertvalue %272, %270[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %274 = llvm.extractvalue %193[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %275 = llvm.fmul %274, %230  : vector<1xf64>
    %276 = llvm.insertvalue %275, %273[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %277 = llvm.extractvalue %193[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %278 = llvm.fmul %277, %237  : vector<1xf64>
    %279 = llvm.insertvalue %278, %276[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %280 = llvm.extractvalue %193[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %281 = llvm.fmul %280, %244  : vector<1xf64>
    %282 = llvm.insertvalue %281, %279[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %283 = llvm.extractvalue %282[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %284 = llvm.mlir.constant(0 : i64) : i64
    %285 = llvm.extractelement %283[%284 : i64] : vector<1xf64>
    %286 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %287 = llvm.mlir.constant(0 : i64) : i64
    %288 = llvm.insertelement %285, %286[%287 : i64] : vector<4xf64>
    %289 = llvm.insertvalue %288, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %290 = llvm.extractvalue %282[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %291 = llvm.mlir.constant(0 : i64) : i64
    %292 = llvm.extractelement %290[%291 : i64] : vector<1xf64>
    %293 = llvm.mlir.constant(1 : i64) : i64
    %294 = llvm.insertelement %292, %288[%293 : i64] : vector<4xf64>
    %295 = llvm.insertvalue %294, %289[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %296 = llvm.extractvalue %282[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %297 = llvm.mlir.constant(0 : i64) : i64
    %298 = llvm.extractelement %296[%297 : i64] : vector<1xf64>
    %299 = llvm.mlir.constant(2 : i64) : i64
    %300 = llvm.insertelement %298, %294[%299 : i64] : vector<4xf64>
    %301 = llvm.insertvalue %300, %295[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %302 = llvm.extractvalue %282[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %303 = llvm.mlir.constant(0 : i64) : i64
    %304 = llvm.extractelement %302[%303 : i64] : vector<1xf64>
    %305 = llvm.mlir.constant(3 : i64) : i64
    %306 = llvm.insertelement %304, %300[%305 : i64] : vector<4xf64>
    %307 = llvm.insertvalue %306, %301[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %308 = llvm.extractvalue %269[0] : !llvm.array<1 x vector<4xf64>> 
    %309 = llvm.fadd %306, %308  : vector<4xf64>
    %310 = llvm.insertvalue %309, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %310, %68 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %311 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %312 = llvm.extractvalue %73[0] : !llvm.struct<(ptr, ptr, i64)> 
    %313 = llvm.insertvalue %312, %311[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %314 = llvm.extractvalue %73[1] : !llvm.struct<(ptr, ptr, i64)> 
    %315 = llvm.insertvalue %314, %313[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %316 = llvm.mlir.constant(0 : index) : i64
    %317 = llvm.insertvalue %316, %315[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %318 = llvm.mlir.constant(1 : index) : i64
    %319 = llvm.insertvalue %318, %317[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %320 = llvm.mlir.constant(1 : index) : i64
    %321 = llvm.insertvalue %320, %319[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb24(%32 : i64)
  ^bb24(%322: i64):  // 2 preds: ^bb23, ^bb25
    %323 = llvm.icmp "slt" %322, %30 : i64
    llvm.cond_br %323, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %324 = llvm.getelementptr %314[%322] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %325 = llvm.load %324 : !llvm.ptr -> vector<4xf64>
    %326 = llvm.extractvalue %161[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %327 = llvm.extractvalue %161[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %328 = llvm.getelementptr %326[%327] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %329 = llvm.mlir.constant(64 : index) : i64
    %330 = llvm.mul %322, %329  : i64
    %331 = llvm.add %330, %32  : i64
    %332 = llvm.getelementptr %328[%331] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %325, %332 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %333 = llvm.add %322, %30  : i64
    llvm.br ^bb24(%333 : i64)
  ^bb26:  // pred: ^bb24
    %334 = llvm.add %104, %30  : i64
    llvm.br ^bb13(%334 : i64)
  ^bb27:  // pred: ^bb13
    %335 = llvm.add %102, %31  : i64
    llvm.br ^bb11(%335 : i64)
  ^bb28:  // pred: ^bb11
    %336 = llvm.add %100, %30  : i64
    llvm.br ^bb9(%336 : i64)
  ^bb29:  // pred: ^bb9
    %337 = llvm.add %74, %33  : i64
    llvm.br ^bb7(%337 : i64)
  ^bb30:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
