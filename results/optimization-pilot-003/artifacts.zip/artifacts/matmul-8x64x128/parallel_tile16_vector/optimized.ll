; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader16.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  %invariant.gep.1 = getelementptr double, ptr %8, i64 4
  %invariant.gep.2 = getelementptr double, ptr %8, i64 8
  %invariant.gep.3 = getelementptr double, ptr %8, i64 12
  br label %.preheader16

.preheader16:                                     ; preds = %.preheader16.preheader, %190
  %21 = phi i64 [ %191, %190 ], [ 0, %.preheader16.preheader ]
  %invariant.gep35 = getelementptr double, ptr %15, i64 %21
  %invariant.gep33 = getelementptr double, ptr %8, i64 %21
  %invariant.gep29 = getelementptr double, ptr %invariant.gep.1, i64 %21
  %invariant.gep25 = getelementptr double, ptr %invariant.gep.2, i64 %21
  %invariant.gep21 = getelementptr double, ptr %invariant.gep.3, i64 %21
  br label %.preheader15

.preheader15:                                     ; preds = %.preheader16, %188
  %22 = phi i64 [ 0, %.preheader16 ], [ %189, %188 ]
  %23 = shl i64 %22, 7
  %24 = shl i64 %22, 6
  %gep = getelementptr double, ptr %invariant.gep35, i64 %24
  %.promoted = load <4 x double>, ptr %gep, align 8
  %invariant.gep31 = getelementptr double, ptr %1, i64 %23
  br label %.critedge

.critedge:                                        ; preds = %.critedge, %.preheader15
  %25 = phi i64 [ 0, %.preheader15 ], [ %64, %.critedge ]
  %26 = phi <4 x double> [ %.promoted, %.preheader15 ], [ %63, %.critedge ]
  %27 = shl nuw nsw i64 %25, 6
  %gep32 = getelementptr double, ptr %invariant.gep31, i64 %25
  %28 = load double, ptr %gep32, align 8
  %29 = insertelement <1 x double> poison, double %28, i64 0
  %gep34 = getelementptr double, ptr %invariant.gep33, i64 %27
  %30 = load <4 x double>, ptr %gep34, align 8
  %31 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> zeroinitializer
  %32 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 1>
  %33 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 2>
  %34 = shufflevector <4 x double> %30, <4 x double> poison, <1 x i32> <i32 3>
  %35 = fmul <1 x double> %29, %31
  %36 = fmul <1 x double> %29, %32
  %37 = fmul <1 x double> %29, %33
  %38 = shufflevector <1 x double> %37, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = fmul <1 x double> %29, %34
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = shufflevector <1 x double> %35, <1 x double> %36, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %43 = shufflevector <4 x double> %42, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %44 = fadd <4 x double> %26, %43
  store <4 x double> %44, ptr %gep, align 8
  %45 = or disjoint i64 %25, 1
  %46 = shl nuw nsw i64 %45, 6
  %gep32.1 = getelementptr double, ptr %invariant.gep31, i64 %45
  %47 = load double, ptr %gep32.1, align 8
  %48 = insertelement <1 x double> poison, double %47, i64 0
  %gep34.1 = getelementptr double, ptr %invariant.gep33, i64 %46
  %49 = load <4 x double>, ptr %gep34.1, align 8
  %50 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> zeroinitializer
  %51 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 1>
  %52 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 2>
  %53 = shufflevector <4 x double> %49, <4 x double> poison, <1 x i32> <i32 3>
  %54 = fmul <1 x double> %48, %50
  %55 = fmul <1 x double> %48, %51
  %56 = fmul <1 x double> %48, %52
  %57 = shufflevector <1 x double> %56, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %58 = fmul <1 x double> %48, %53
  %59 = shufflevector <1 x double> %58, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %60 = shufflevector <1 x double> %54, <1 x double> %55, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %61 = shufflevector <4 x double> %60, <4 x double> %57, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %62 = shufflevector <4 x double> %61, <4 x double> %59, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %63 = fadd <4 x double> %44, %62
  store <4 x double> %63, ptr %gep, align 8
  %64 = add nuw nsw i64 %25, 2
  %exitcond.not.1 = icmp eq i64 %64, 128
  br i1 %exitcond.not.1, label %.preheader.1, label %.critedge

.preheader.1:                                     ; preds = %.critedge
  %65 = getelementptr double, ptr %gep, i64 4
  %.promoted.1 = load <4 x double>, ptr %65, align 8
  %invariant.gep27 = getelementptr double, ptr %1, i64 %23
  br label %.critedge.1

.critedge.1:                                      ; preds = %.critedge.1, %.preheader.1
  %66 = phi i64 [ 0, %.preheader.1 ], [ %105, %.critedge.1 ]
  %67 = phi <4 x double> [ %.promoted.1, %.preheader.1 ], [ %104, %.critedge.1 ]
  %68 = shl nuw nsw i64 %66, 6
  %gep28 = getelementptr double, ptr %invariant.gep27, i64 %66
  %69 = load double, ptr %gep28, align 8
  %70 = insertelement <1 x double> poison, double %69, i64 0
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %68
  %71 = load <4 x double>, ptr %gep30, align 8
  %72 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> zeroinitializer
  %73 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 1>
  %74 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 2>
  %75 = shufflevector <4 x double> %71, <4 x double> poison, <1 x i32> <i32 3>
  %76 = fmul <1 x double> %70, %72
  %77 = fmul <1 x double> %70, %73
  %78 = fmul <1 x double> %70, %74
  %79 = shufflevector <1 x double> %78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = fmul <1 x double> %70, %75
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = shufflevector <1 x double> %76, <1 x double> %77, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %83 = shufflevector <4 x double> %82, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %84 = shufflevector <4 x double> %83, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %85 = fadd <4 x double> %67, %84
  store <4 x double> %85, ptr %65, align 8
  %86 = or disjoint i64 %66, 1
  %87 = shl nuw nsw i64 %86, 6
  %gep28.1 = getelementptr double, ptr %invariant.gep27, i64 %86
  %88 = load double, ptr %gep28.1, align 8
  %89 = insertelement <1 x double> poison, double %88, i64 0
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %87
  %90 = load <4 x double>, ptr %gep30.1, align 8
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> zeroinitializer
  %92 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 1>
  %93 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 2>
  %94 = shufflevector <4 x double> %90, <4 x double> poison, <1 x i32> <i32 3>
  %95 = fmul <1 x double> %89, %91
  %96 = fmul <1 x double> %89, %92
  %97 = fmul <1 x double> %89, %93
  %98 = shufflevector <1 x double> %97, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = fmul <1 x double> %89, %94
  %100 = shufflevector <1 x double> %99, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %95, <1 x double> %96, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %100, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %104 = fadd <4 x double> %85, %103
  store <4 x double> %104, ptr %65, align 8
  %105 = add nuw nsw i64 %66, 2
  %exitcond.1.not.1 = icmp eq i64 %105, 128
  br i1 %exitcond.1.not.1, label %.preheader.2, label %.critedge.1

.preheader.2:                                     ; preds = %.critedge.1
  %106 = getelementptr double, ptr %gep, i64 8
  %.promoted.2 = load <4 x double>, ptr %106, align 8
  %invariant.gep23 = getelementptr double, ptr %1, i64 %23
  br label %.critedge.2

.critedge.2:                                      ; preds = %.critedge.2, %.preheader.2
  %107 = phi i64 [ 0, %.preheader.2 ], [ %146, %.critedge.2 ]
  %108 = phi <4 x double> [ %.promoted.2, %.preheader.2 ], [ %145, %.critedge.2 ]
  %109 = shl nuw nsw i64 %107, 6
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %107
  %110 = load double, ptr %gep24, align 8
  %111 = insertelement <1 x double> poison, double %110, i64 0
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %109
  %112 = load <4 x double>, ptr %gep26, align 8
  %113 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> zeroinitializer
  %114 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 1>
  %115 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 2>
  %116 = shufflevector <4 x double> %112, <4 x double> poison, <1 x i32> <i32 3>
  %117 = fmul <1 x double> %111, %113
  %118 = fmul <1 x double> %111, %114
  %119 = fmul <1 x double> %111, %115
  %120 = shufflevector <1 x double> %119, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %121 = fmul <1 x double> %111, %116
  %122 = shufflevector <1 x double> %121, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %123 = shufflevector <1 x double> %117, <1 x double> %118, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %124 = shufflevector <4 x double> %123, <4 x double> %120, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %125 = shufflevector <4 x double> %124, <4 x double> %122, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %126 = fadd <4 x double> %108, %125
  store <4 x double> %126, ptr %106, align 8
  %127 = or disjoint i64 %107, 1
  %128 = shl nuw nsw i64 %127, 6
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %127
  %129 = load double, ptr %gep24.1, align 8
  %130 = insertelement <1 x double> poison, double %129, i64 0
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %128
  %131 = load <4 x double>, ptr %gep26.1, align 8
  %132 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> zeroinitializer
  %133 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 1>
  %134 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 2>
  %135 = shufflevector <4 x double> %131, <4 x double> poison, <1 x i32> <i32 3>
  %136 = fmul <1 x double> %130, %132
  %137 = fmul <1 x double> %130, %133
  %138 = fmul <1 x double> %130, %134
  %139 = shufflevector <1 x double> %138, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %140 = fmul <1 x double> %130, %135
  %141 = shufflevector <1 x double> %140, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %142 = shufflevector <1 x double> %136, <1 x double> %137, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %143 = shufflevector <4 x double> %142, <4 x double> %139, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %144 = shufflevector <4 x double> %143, <4 x double> %141, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %145 = fadd <4 x double> %126, %144
  store <4 x double> %145, ptr %106, align 8
  %146 = add nuw nsw i64 %107, 2
  %exitcond.2.not.1 = icmp eq i64 %146, 128
  br i1 %exitcond.2.not.1, label %.preheader.3, label %.critedge.2

.preheader.3:                                     ; preds = %.critedge.2
  %147 = getelementptr double, ptr %gep, i64 12
  %.promoted.3 = load <4 x double>, ptr %147, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %23
  br label %.critedge.3

.critedge.3:                                      ; preds = %.critedge.3, %.preheader.3
  %148 = phi i64 [ 0, %.preheader.3 ], [ %187, %.critedge.3 ]
  %149 = phi <4 x double> [ %.promoted.3, %.preheader.3 ], [ %186, %.critedge.3 ]
  %150 = shl nuw nsw i64 %148, 6
  %gep20 = getelementptr double, ptr %invariant.gep, i64 %148
  %151 = load double, ptr %gep20, align 8
  %152 = insertelement <1 x double> poison, double %151, i64 0
  %gep22 = getelementptr double, ptr %invariant.gep21, i64 %150
  %153 = load <4 x double>, ptr %gep22, align 8
  %154 = shufflevector <4 x double> %153, <4 x double> poison, <1 x i32> zeroinitializer
  %155 = shufflevector <4 x double> %153, <4 x double> poison, <1 x i32> <i32 1>
  %156 = shufflevector <4 x double> %153, <4 x double> poison, <1 x i32> <i32 2>
  %157 = shufflevector <4 x double> %153, <4 x double> poison, <1 x i32> <i32 3>
  %158 = fmul <1 x double> %152, %154
  %159 = fmul <1 x double> %152, %155
  %160 = fmul <1 x double> %152, %156
  %161 = shufflevector <1 x double> %160, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %162 = fmul <1 x double> %152, %157
  %163 = shufflevector <1 x double> %162, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %164 = shufflevector <1 x double> %158, <1 x double> %159, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %165 = shufflevector <4 x double> %164, <4 x double> %161, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %166 = shufflevector <4 x double> %165, <4 x double> %163, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %167 = fadd <4 x double> %149, %166
  store <4 x double> %167, ptr %147, align 8
  %168 = or disjoint i64 %148, 1
  %169 = shl nuw nsw i64 %168, 6
  %gep20.1 = getelementptr double, ptr %invariant.gep, i64 %168
  %170 = load double, ptr %gep20.1, align 8
  %171 = insertelement <1 x double> poison, double %170, i64 0
  %gep22.1 = getelementptr double, ptr %invariant.gep21, i64 %169
  %172 = load <4 x double>, ptr %gep22.1, align 8
  %173 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> zeroinitializer
  %174 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 1>
  %175 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 2>
  %176 = shufflevector <4 x double> %172, <4 x double> poison, <1 x i32> <i32 3>
  %177 = fmul <1 x double> %171, %173
  %178 = fmul <1 x double> %171, %174
  %179 = fmul <1 x double> %171, %175
  %180 = shufflevector <1 x double> %179, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %181 = fmul <1 x double> %171, %176
  %182 = shufflevector <1 x double> %181, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %183 = shufflevector <1 x double> %177, <1 x double> %178, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %184 = shufflevector <4 x double> %183, <4 x double> %180, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %185 = shufflevector <4 x double> %184, <4 x double> %182, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %186 = fadd <4 x double> %167, %185
  store <4 x double> %186, ptr %147, align 8
  %187 = add nuw nsw i64 %148, 2
  %exitcond.3.not.1 = icmp eq i64 %187, 128
  br i1 %exitcond.3.not.1, label %188, label %.critedge.3

188:                                              ; preds = %.critedge.3
  %189 = add nuw nsw i64 %22, 1
  %exitcond19.not = icmp eq i64 %189, 8
  br i1 %exitcond19.not, label %190, label %.preheader15

190:                                              ; preds = %188
  %191 = add nuw nsw i64 %21, 16
  %192 = icmp ult i64 %21, 48
  br i1 %192, label %.preheader16, label %193

193:                                              ; preds = %190
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 12
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %173, %3
  %4 = phi i64 [ %174, %173 ], [ 0, %3 ]
  %invariant.gep35.i = getelementptr double, ptr %.unpack32, i64 %4
  %invariant.gep33.i = getelementptr double, ptr %.unpack17, i64 %4
  %invariant.gep29.i = getelementptr double, ptr %invariant.gep.1.i, i64 %4
  %invariant.gep25.i = getelementptr double, ptr %invariant.gep.2.i, i64 %4
  %invariant.gep21.i = getelementptr double, ptr %invariant.gep.3.i, i64 %4
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %171, %.preheader16.i
  %5 = phi i64 [ 0, %.preheader16.i ], [ %172, %171 ]
  %6 = shl i64 %5, 7
  %7 = shl i64 %5, 6
  %gep.i = getelementptr double, ptr %invariant.gep35.i, i64 %7
  %.promoted.i = load <4 x double>, ptr %gep.i, align 8
  %invariant.gep31.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %8 = phi i64 [ 0, %.preheader15.i ], [ %47, %.critedge.i ]
  %9 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %46, %.critedge.i ]
  %10 = shl nuw nsw i64 %8, 6
  %gep32.i = getelementptr double, ptr %invariant.gep31.i, i64 %8
  %11 = load double, ptr %gep32.i, align 8
  %12 = insertelement <1 x double> poison, double %11, i64 0
  %gep34.i = getelementptr double, ptr %invariant.gep33.i, i64 %10
  %13 = load <4 x double>, ptr %gep34.i, align 8
  %14 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> zeroinitializer
  %15 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 1>
  %16 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 2>
  %17 = shufflevector <4 x double> %13, <4 x double> poison, <1 x i32> <i32 3>
  %18 = fmul <1 x double> %12, %14
  %19 = fmul <1 x double> %12, %15
  %20 = fmul <1 x double> %12, %16
  %21 = shufflevector <1 x double> %20, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %22 = fmul <1 x double> %12, %17
  %23 = shufflevector <1 x double> %22, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = shufflevector <1 x double> %18, <1 x double> %19, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %25 = shufflevector <4 x double> %24, <4 x double> %21, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %26 = shufflevector <4 x double> %25, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %27 = fadd <4 x double> %9, %26
  store <4 x double> %27, ptr %gep.i, align 8
  %28 = or disjoint i64 %8, 1
  %29 = shl nuw nsw i64 %28, 6
  %gep32.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %28
  %30 = load double, ptr %gep32.i.1, align 8
  %31 = insertelement <1 x double> poison, double %30, i64 0
  %gep34.i.1 = getelementptr double, ptr %invariant.gep33.i, i64 %29
  %32 = load <4 x double>, ptr %gep34.i.1, align 8
  %33 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> zeroinitializer
  %34 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 1>
  %35 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 2>
  %36 = shufflevector <4 x double> %32, <4 x double> poison, <1 x i32> <i32 3>
  %37 = fmul <1 x double> %31, %33
  %38 = fmul <1 x double> %31, %34
  %39 = fmul <1 x double> %31, %35
  %40 = shufflevector <1 x double> %39, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %41 = fmul <1 x double> %31, %36
  %42 = shufflevector <1 x double> %41, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %43 = shufflevector <1 x double> %37, <1 x double> %38, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %44 = shufflevector <4 x double> %43, <4 x double> %40, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %42, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %46 = fadd <4 x double> %27, %45
  store <4 x double> %46, ptr %gep.i, align 8
  %47 = add nuw nsw i64 %8, 2
  %exitcond.not.i.1 = icmp eq i64 %47, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %48 = getelementptr double, ptr %gep.i, i64 4
  %.promoted.1.i = load <4 x double>, ptr %48, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %49 = phi i64 [ 0, %.preheader.1.i ], [ %88, %.critedge.1.i ]
  %50 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %87, %.critedge.1.i ]
  %51 = shl nuw nsw i64 %49, 6
  %gep28.i = getelementptr double, ptr %invariant.gep31.i, i64 %49
  %52 = load double, ptr %gep28.i, align 8
  %53 = insertelement <1 x double> poison, double %52, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %51
  %54 = load <4 x double>, ptr %gep30.i, align 8
  %55 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> zeroinitializer
  %56 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 1>
  %57 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 2>
  %58 = shufflevector <4 x double> %54, <4 x double> poison, <1 x i32> <i32 3>
  %59 = fmul <1 x double> %53, %55
  %60 = fmul <1 x double> %53, %56
  %61 = fmul <1 x double> %53, %57
  %62 = shufflevector <1 x double> %61, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %63 = fmul <1 x double> %53, %58
  %64 = shufflevector <1 x double> %63, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %65 = shufflevector <1 x double> %59, <1 x double> %60, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %62, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %67 = shufflevector <4 x double> %66, <4 x double> %64, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %68 = fadd <4 x double> %50, %67
  store <4 x double> %68, ptr %48, align 8
  %69 = or disjoint i64 %49, 1
  %70 = shl nuw nsw i64 %69, 6
  %gep28.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %69
  %71 = load double, ptr %gep28.i.1, align 8
  %72 = insertelement <1 x double> poison, double %71, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %70
  %73 = load <4 x double>, ptr %gep30.i.1, align 8
  %74 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> zeroinitializer
  %75 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 1>
  %76 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 2>
  %77 = shufflevector <4 x double> %73, <4 x double> poison, <1 x i32> <i32 3>
  %78 = fmul <1 x double> %72, %74
  %79 = fmul <1 x double> %72, %75
  %80 = fmul <1 x double> %72, %76
  %81 = shufflevector <1 x double> %80, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = fmul <1 x double> %72, %77
  %83 = shufflevector <1 x double> %82, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %84 = shufflevector <1 x double> %78, <1 x double> %79, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %85 = shufflevector <4 x double> %84, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %86 = shufflevector <4 x double> %85, <4 x double> %83, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %87 = fadd <4 x double> %68, %86
  store <4 x double> %87, ptr %48, align 8
  %88 = add nuw nsw i64 %49, 2
  %exitcond.1.not.i.1 = icmp eq i64 %88, 128
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %89 = getelementptr double, ptr %gep.i, i64 8
  %.promoted.2.i = load <4 x double>, ptr %89, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %90 = phi i64 [ 0, %.preheader.2.i ], [ %129, %.critedge.2.i ]
  %91 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %128, %.critedge.2.i ]
  %92 = shl nuw nsw i64 %90, 6
  %gep24.i = getelementptr double, ptr %invariant.gep31.i, i64 %90
  %93 = load double, ptr %gep24.i, align 8
  %94 = insertelement <1 x double> poison, double %93, i64 0
  %gep26.i = getelementptr double, ptr %invariant.gep25.i, i64 %92
  %95 = load <4 x double>, ptr %gep26.i, align 8
  %96 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> zeroinitializer
  %97 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 1>
  %98 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 2>
  %99 = shufflevector <4 x double> %95, <4 x double> poison, <1 x i32> <i32 3>
  %100 = fmul <1 x double> %94, %96
  %101 = fmul <1 x double> %94, %97
  %102 = fmul <1 x double> %94, %98
  %103 = shufflevector <1 x double> %102, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %104 = fmul <1 x double> %94, %99
  %105 = shufflevector <1 x double> %104, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %106 = shufflevector <1 x double> %100, <1 x double> %101, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %103, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %108 = shufflevector <4 x double> %107, <4 x double> %105, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %109 = fadd <4 x double> %91, %108
  store <4 x double> %109, ptr %89, align 8
  %110 = or disjoint i64 %90, 1
  %111 = shl nuw nsw i64 %110, 6
  %gep24.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %110
  %112 = load double, ptr %gep24.i.1, align 8
  %113 = insertelement <1 x double> poison, double %112, i64 0
  %gep26.i.1 = getelementptr double, ptr %invariant.gep25.i, i64 %111
  %114 = load <4 x double>, ptr %gep26.i.1, align 8
  %115 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> zeroinitializer
  %116 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 1>
  %117 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 2>
  %118 = shufflevector <4 x double> %114, <4 x double> poison, <1 x i32> <i32 3>
  %119 = fmul <1 x double> %113, %115
  %120 = fmul <1 x double> %113, %116
  %121 = fmul <1 x double> %113, %117
  %122 = shufflevector <1 x double> %121, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %123 = fmul <1 x double> %113, %118
  %124 = shufflevector <1 x double> %123, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %125 = shufflevector <1 x double> %119, <1 x double> %120, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %126 = shufflevector <4 x double> %125, <4 x double> %122, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %127 = shufflevector <4 x double> %126, <4 x double> %124, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %128 = fadd <4 x double> %109, %127
  store <4 x double> %128, ptr %89, align 8
  %129 = add nuw nsw i64 %90, 2
  %exitcond.2.not.i.1 = icmp eq i64 %129, 128
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %130 = getelementptr double, ptr %gep.i, i64 12
  %.promoted.3.i = load <4 x double>, ptr %130, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %131 = phi i64 [ 0, %.preheader.3.i ], [ %170, %.critedge.3.i ]
  %132 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %169, %.critedge.3.i ]
  %133 = shl nuw nsw i64 %131, 6
  %gep20.i = getelementptr double, ptr %invariant.gep31.i, i64 %131
  %134 = load double, ptr %gep20.i, align 8
  %135 = insertelement <1 x double> poison, double %134, i64 0
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %133
  %136 = load <4 x double>, ptr %gep22.i, align 8
  %137 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> zeroinitializer
  %138 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 1>
  %139 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 2>
  %140 = shufflevector <4 x double> %136, <4 x double> poison, <1 x i32> <i32 3>
  %141 = fmul <1 x double> %135, %137
  %142 = fmul <1 x double> %135, %138
  %143 = fmul <1 x double> %135, %139
  %144 = shufflevector <1 x double> %143, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %145 = fmul <1 x double> %135, %140
  %146 = shufflevector <1 x double> %145, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %147 = shufflevector <1 x double> %141, <1 x double> %142, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %148 = shufflevector <4 x double> %147, <4 x double> %144, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %149 = shufflevector <4 x double> %148, <4 x double> %146, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %150 = fadd <4 x double> %132, %149
  store <4 x double> %150, ptr %130, align 8
  %151 = or disjoint i64 %131, 1
  %152 = shl nuw nsw i64 %151, 6
  %gep20.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %151
  %153 = load double, ptr %gep20.i.1, align 8
  %154 = insertelement <1 x double> poison, double %153, i64 0
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %152
  %155 = load <4 x double>, ptr %gep22.i.1, align 8
  %156 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> zeroinitializer
  %157 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 1>
  %158 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 2>
  %159 = shufflevector <4 x double> %155, <4 x double> poison, <1 x i32> <i32 3>
  %160 = fmul <1 x double> %154, %156
  %161 = fmul <1 x double> %154, %157
  %162 = fmul <1 x double> %154, %158
  %163 = shufflevector <1 x double> %162, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %164 = fmul <1 x double> %154, %159
  %165 = shufflevector <1 x double> %164, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %166 = shufflevector <1 x double> %160, <1 x double> %161, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %167 = shufflevector <4 x double> %166, <4 x double> %163, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %168 = shufflevector <4 x double> %167, <4 x double> %165, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %169 = fadd <4 x double> %150, %168
  store <4 x double> %169, ptr %130, align 8
  %170 = add nuw nsw i64 %131, 2
  %exitcond.3.not.i.1 = icmp eq i64 %170, 128
  br i1 %exitcond.3.not.i.1, label %171, label %.critedge.3.i

171:                                              ; preds = %.critedge.3.i
  %172 = add nuw nsw i64 %5, 1
  %exitcond19.not.i = icmp eq i64 %172, 8
  br i1 %exitcond19.not.i, label %173, label %.preheader15.i

173:                                              ; preds = %171
  %174 = add nuw nsw i64 %4, 16
  %175 = icmp ult i64 %4, 48
  br i1 %175, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %173
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %10, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 4
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 8
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 12
  br label %.preheader16.i

.preheader16.i:                                   ; preds = %180, %1
  %11 = phi i64 [ %181, %180 ], [ 0, %1 ]
  %invariant.gep35.i = getelementptr double, ptr %10, i64 %11
  %invariant.gep33.i = getelementptr double, ptr %7, i64 %11
  %invariant.gep29.i = getelementptr double, ptr %invariant.gep.1.i, i64 %11
  %invariant.gep25.i = getelementptr double, ptr %invariant.gep.2.i, i64 %11
  %invariant.gep21.i = getelementptr double, ptr %invariant.gep.3.i, i64 %11
  br label %.preheader15.i

.preheader15.i:                                   ; preds = %178, %.preheader16.i
  %12 = phi i64 [ 0, %.preheader16.i ], [ %179, %178 ]
  %13 = shl i64 %12, 7
  %14 = shl i64 %12, 6
  %gep.i = getelementptr double, ptr %invariant.gep35.i, i64 %14
  %.promoted.i = load <4 x double>, ptr %gep.i, align 8
  %invariant.gep31.i = getelementptr double, ptr %4, i64 %13
  br label %.critedge.i

.critedge.i:                                      ; preds = %.critedge.i, %.preheader15.i
  %15 = phi i64 [ 0, %.preheader15.i ], [ %54, %.critedge.i ]
  %16 = phi <4 x double> [ %.promoted.i, %.preheader15.i ], [ %53, %.critedge.i ]
  %17 = shl nuw nsw i64 %15, 6
  %gep32.i = getelementptr double, ptr %invariant.gep31.i, i64 %15
  %18 = load double, ptr %gep32.i, align 8
  %19 = insertelement <1 x double> poison, double %18, i64 0
  %gep34.i = getelementptr double, ptr %invariant.gep33.i, i64 %17
  %20 = load <4 x double>, ptr %gep34.i, align 8
  %21 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> zeroinitializer
  %22 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 1>
  %23 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 2>
  %24 = shufflevector <4 x double> %20, <4 x double> poison, <1 x i32> <i32 3>
  %25 = fmul <1 x double> %19, %21
  %26 = fmul <1 x double> %19, %22
  %27 = fmul <1 x double> %19, %23
  %28 = shufflevector <1 x double> %27, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = fmul <1 x double> %19, %24
  %30 = shufflevector <1 x double> %29, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = shufflevector <1 x double> %25, <1 x double> %26, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %32 = shufflevector <4 x double> %31, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %33 = shufflevector <4 x double> %32, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %34 = fadd <4 x double> %16, %33
  store <4 x double> %34, ptr %gep.i, align 8
  %35 = or disjoint i64 %15, 1
  %36 = shl nuw nsw i64 %35, 6
  %gep32.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %35
  %37 = load double, ptr %gep32.i.1, align 8
  %38 = insertelement <1 x double> poison, double %37, i64 0
  %gep34.i.1 = getelementptr double, ptr %invariant.gep33.i, i64 %36
  %39 = load <4 x double>, ptr %gep34.i.1, align 8
  %40 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> zeroinitializer
  %41 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 1>
  %42 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 2>
  %43 = shufflevector <4 x double> %39, <4 x double> poison, <1 x i32> <i32 3>
  %44 = fmul <1 x double> %38, %40
  %45 = fmul <1 x double> %38, %41
  %46 = fmul <1 x double> %38, %42
  %47 = shufflevector <1 x double> %46, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %48 = fmul <1 x double> %38, %43
  %49 = shufflevector <1 x double> %48, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %44, <1 x double> %45, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %47, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %49, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fadd <4 x double> %34, %52
  store <4 x double> %53, ptr %gep.i, align 8
  %54 = add nuw nsw i64 %15, 2
  %exitcond.not.i.1 = icmp eq i64 %54, 128
  br i1 %exitcond.not.i.1, label %.preheader.1.i, label %.critedge.i

.preheader.1.i:                                   ; preds = %.critedge.i
  %55 = getelementptr double, ptr %gep.i, i64 4
  %.promoted.1.i = load <4 x double>, ptr %55, align 8
  br label %.critedge.1.i

.critedge.1.i:                                    ; preds = %.critedge.1.i, %.preheader.1.i
  %56 = phi i64 [ 0, %.preheader.1.i ], [ %95, %.critedge.1.i ]
  %57 = phi <4 x double> [ %.promoted.1.i, %.preheader.1.i ], [ %94, %.critedge.1.i ]
  %58 = shl nuw nsw i64 %56, 6
  %gep28.i = getelementptr double, ptr %invariant.gep31.i, i64 %56
  %59 = load double, ptr %gep28.i, align 8
  %60 = insertelement <1 x double> poison, double %59, i64 0
  %gep30.i = getelementptr double, ptr %invariant.gep29.i, i64 %58
  %61 = load <4 x double>, ptr %gep30.i, align 8
  %62 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> zeroinitializer
  %63 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 1>
  %64 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 2>
  %65 = shufflevector <4 x double> %61, <4 x double> poison, <1 x i32> <i32 3>
  %66 = fmul <1 x double> %60, %62
  %67 = fmul <1 x double> %60, %63
  %68 = fmul <1 x double> %60, %64
  %69 = shufflevector <1 x double> %68, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %70 = fmul <1 x double> %60, %65
  %71 = shufflevector <1 x double> %70, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %72 = shufflevector <1 x double> %66, <1 x double> %67, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %73 = shufflevector <4 x double> %72, <4 x double> %69, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %74 = shufflevector <4 x double> %73, <4 x double> %71, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %75 = fadd <4 x double> %57, %74
  store <4 x double> %75, ptr %55, align 8
  %76 = or disjoint i64 %56, 1
  %77 = shl nuw nsw i64 %76, 6
  %gep28.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %76
  %78 = load double, ptr %gep28.i.1, align 8
  %79 = insertelement <1 x double> poison, double %78, i64 0
  %gep30.i.1 = getelementptr double, ptr %invariant.gep29.i, i64 %77
  %80 = load <4 x double>, ptr %gep30.i.1, align 8
  %81 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> zeroinitializer
  %82 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 1>
  %83 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 2>
  %84 = shufflevector <4 x double> %80, <4 x double> poison, <1 x i32> <i32 3>
  %85 = fmul <1 x double> %79, %81
  %86 = fmul <1 x double> %79, %82
  %87 = fmul <1 x double> %79, %83
  %88 = shufflevector <1 x double> %87, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %89 = fmul <1 x double> %79, %84
  %90 = shufflevector <1 x double> %89, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %91 = shufflevector <1 x double> %85, <1 x double> %86, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %88, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %93 = shufflevector <4 x double> %92, <4 x double> %90, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %94 = fadd <4 x double> %75, %93
  store <4 x double> %94, ptr %55, align 8
  %95 = add nuw nsw i64 %56, 2
  %exitcond.1.not.i.1 = icmp eq i64 %95, 128
  br i1 %exitcond.1.not.i.1, label %.preheader.2.i, label %.critedge.1.i

.preheader.2.i:                                   ; preds = %.critedge.1.i
  %96 = getelementptr double, ptr %gep.i, i64 8
  %.promoted.2.i = load <4 x double>, ptr %96, align 8
  br label %.critedge.2.i

.critedge.2.i:                                    ; preds = %.critedge.2.i, %.preheader.2.i
  %97 = phi i64 [ 0, %.preheader.2.i ], [ %136, %.critedge.2.i ]
  %98 = phi <4 x double> [ %.promoted.2.i, %.preheader.2.i ], [ %135, %.critedge.2.i ]
  %99 = shl nuw nsw i64 %97, 6
  %gep24.i = getelementptr double, ptr %invariant.gep31.i, i64 %97
  %100 = load double, ptr %gep24.i, align 8
  %101 = insertelement <1 x double> poison, double %100, i64 0
  %gep26.i = getelementptr double, ptr %invariant.gep25.i, i64 %99
  %102 = load <4 x double>, ptr %gep26.i, align 8
  %103 = shufflevector <4 x double> %102, <4 x double> poison, <1 x i32> zeroinitializer
  %104 = shufflevector <4 x double> %102, <4 x double> poison, <1 x i32> <i32 1>
  %105 = shufflevector <4 x double> %102, <4 x double> poison, <1 x i32> <i32 2>
  %106 = shufflevector <4 x double> %102, <4 x double> poison, <1 x i32> <i32 3>
  %107 = fmul <1 x double> %101, %103
  %108 = fmul <1 x double> %101, %104
  %109 = fmul <1 x double> %101, %105
  %110 = shufflevector <1 x double> %109, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %111 = fmul <1 x double> %101, %106
  %112 = shufflevector <1 x double> %111, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %113 = shufflevector <1 x double> %107, <1 x double> %108, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %110, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %115 = shufflevector <4 x double> %114, <4 x double> %112, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %116 = fadd <4 x double> %98, %115
  store <4 x double> %116, ptr %96, align 8
  %117 = or disjoint i64 %97, 1
  %118 = shl nuw nsw i64 %117, 6
  %gep24.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %117
  %119 = load double, ptr %gep24.i.1, align 8
  %120 = insertelement <1 x double> poison, double %119, i64 0
  %gep26.i.1 = getelementptr double, ptr %invariant.gep25.i, i64 %118
  %121 = load <4 x double>, ptr %gep26.i.1, align 8
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> zeroinitializer
  %123 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 1>
  %124 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 2>
  %125 = shufflevector <4 x double> %121, <4 x double> poison, <1 x i32> <i32 3>
  %126 = fmul <1 x double> %120, %122
  %127 = fmul <1 x double> %120, %123
  %128 = fmul <1 x double> %120, %124
  %129 = shufflevector <1 x double> %128, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %130 = fmul <1 x double> %120, %125
  %131 = shufflevector <1 x double> %130, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %132 = shufflevector <1 x double> %126, <1 x double> %127, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %129, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %134 = shufflevector <4 x double> %133, <4 x double> %131, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %135 = fadd <4 x double> %116, %134
  store <4 x double> %135, ptr %96, align 8
  %136 = add nuw nsw i64 %97, 2
  %exitcond.2.not.i.1 = icmp eq i64 %136, 128
  br i1 %exitcond.2.not.i.1, label %.preheader.3.i, label %.critedge.2.i

.preheader.3.i:                                   ; preds = %.critedge.2.i
  %137 = getelementptr double, ptr %gep.i, i64 12
  %.promoted.3.i = load <4 x double>, ptr %137, align 8
  br label %.critedge.3.i

.critedge.3.i:                                    ; preds = %.critedge.3.i, %.preheader.3.i
  %138 = phi i64 [ 0, %.preheader.3.i ], [ %177, %.critedge.3.i ]
  %139 = phi <4 x double> [ %.promoted.3.i, %.preheader.3.i ], [ %176, %.critedge.3.i ]
  %140 = shl nuw nsw i64 %138, 6
  %gep20.i = getelementptr double, ptr %invariant.gep31.i, i64 %138
  %141 = load double, ptr %gep20.i, align 8
  %142 = insertelement <1 x double> poison, double %141, i64 0
  %gep22.i = getelementptr double, ptr %invariant.gep21.i, i64 %140
  %143 = load <4 x double>, ptr %gep22.i, align 8
  %144 = shufflevector <4 x double> %143, <4 x double> poison, <1 x i32> zeroinitializer
  %145 = shufflevector <4 x double> %143, <4 x double> poison, <1 x i32> <i32 1>
  %146 = shufflevector <4 x double> %143, <4 x double> poison, <1 x i32> <i32 2>
  %147 = shufflevector <4 x double> %143, <4 x double> poison, <1 x i32> <i32 3>
  %148 = fmul <1 x double> %142, %144
  %149 = fmul <1 x double> %142, %145
  %150 = fmul <1 x double> %142, %146
  %151 = shufflevector <1 x double> %150, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %152 = fmul <1 x double> %142, %147
  %153 = shufflevector <1 x double> %152, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %154 = shufflevector <1 x double> %148, <1 x double> %149, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %155 = shufflevector <4 x double> %154, <4 x double> %151, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %156 = shufflevector <4 x double> %155, <4 x double> %153, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %157 = fadd <4 x double> %139, %156
  store <4 x double> %157, ptr %137, align 8
  %158 = or disjoint i64 %138, 1
  %159 = shl nuw nsw i64 %158, 6
  %gep20.i.1 = getelementptr double, ptr %invariant.gep31.i, i64 %158
  %160 = load double, ptr %gep20.i.1, align 8
  %161 = insertelement <1 x double> poison, double %160, i64 0
  %gep22.i.1 = getelementptr double, ptr %invariant.gep21.i, i64 %159
  %162 = load <4 x double>, ptr %gep22.i.1, align 8
  %163 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> zeroinitializer
  %164 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 1>
  %165 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 2>
  %166 = shufflevector <4 x double> %162, <4 x double> poison, <1 x i32> <i32 3>
  %167 = fmul <1 x double> %161, %163
  %168 = fmul <1 x double> %161, %164
  %169 = fmul <1 x double> %161, %165
  %170 = shufflevector <1 x double> %169, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %171 = fmul <1 x double> %161, %166
  %172 = shufflevector <1 x double> %171, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %173 = shufflevector <1 x double> %167, <1 x double> %168, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %174 = shufflevector <4 x double> %173, <4 x double> %170, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %175 = shufflevector <4 x double> %174, <4 x double> %172, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %176 = fadd <4 x double> %157, %175
  store <4 x double> %176, ptr %137, align 8
  %177 = add nuw nsw i64 %138, 2
  %exitcond.3.not.i.1 = icmp eq i64 %177, 128
  br i1 %exitcond.3.not.i.1, label %178, label %.critedge.3.i

178:                                              ; preds = %.critedge.3.i
  %179 = add nuw nsw i64 %12, 1
  %exitcond19.not.i = icmp eq i64 %179, 8
  br i1 %exitcond19.not.i, label %180, label %.preheader15.i

180:                                              ; preds = %178
  %181 = add nuw nsw i64 %11, 16
  %182 = icmp ult i64 %11, 48
  br i1 %182, label %.preheader16.i, label %kernel.exit

kernel.exit:                                      ; preds = %180
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack32.i, i8 0, i64 4096, i1 false)
  %invariant.gep.1.i.i = getelementptr double, ptr %.unpack17.i, i64 4
  %invariant.gep.2.i.i = getelementptr double, ptr %.unpack17.i, i64 8
  %invariant.gep.3.i.i = getelementptr double, ptr %.unpack17.i, i64 12
  br label %.preheader16.i.i

.preheader16.i.i:                                 ; preds = %179, %1
  %10 = phi i64 [ %180, %179 ], [ 0, %1 ]
  %invariant.gep35.i.i = getelementptr double, ptr %.unpack32.i, i64 %10
  %invariant.gep33.i.i = getelementptr double, ptr %.unpack17.i, i64 %10
  %invariant.gep29.i.i = getelementptr double, ptr %invariant.gep.1.i.i, i64 %10
  %invariant.gep25.i.i = getelementptr double, ptr %invariant.gep.2.i.i, i64 %10
  %invariant.gep21.i.i = getelementptr double, ptr %invariant.gep.3.i.i, i64 %10
  br label %.preheader15.i.i

.preheader15.i.i:                                 ; preds = %177, %.preheader16.i.i
  %11 = phi i64 [ 0, %.preheader16.i.i ], [ %178, %177 ]
  %12 = shl i64 %11, 7
  %13 = shl i64 %11, 6
  %gep.i.i = getelementptr double, ptr %invariant.gep35.i.i, i64 %13
  %.promoted.i.i = load <4 x double>, ptr %gep.i.i, align 8
  %invariant.gep31.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %.critedge.i.i

.critedge.i.i:                                    ; preds = %.critedge.i.i, %.preheader15.i.i
  %14 = phi i64 [ 0, %.preheader15.i.i ], [ %53, %.critedge.i.i ]
  %15 = phi <4 x double> [ %.promoted.i.i, %.preheader15.i.i ], [ %52, %.critedge.i.i ]
  %16 = shl nuw nsw i64 %14, 6
  %gep32.i.i = getelementptr double, ptr %invariant.gep31.i.i, i64 %14
  %17 = load double, ptr %gep32.i.i, align 8
  %18 = insertelement <1 x double> poison, double %17, i64 0
  %gep34.i.i = getelementptr double, ptr %invariant.gep33.i.i, i64 %16
  %19 = load <4 x double>, ptr %gep34.i.i, align 8
  %20 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> zeroinitializer
  %21 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 1>
  %22 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 2>
  %23 = shufflevector <4 x double> %19, <4 x double> poison, <1 x i32> <i32 3>
  %24 = fmul <1 x double> %18, %20
  %25 = fmul <1 x double> %18, %21
  %26 = fmul <1 x double> %18, %22
  %27 = shufflevector <1 x double> %26, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %28 = fmul <1 x double> %18, %23
  %29 = shufflevector <1 x double> %28, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = shufflevector <1 x double> %24, <1 x double> %25, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %31 = shufflevector <4 x double> %30, <4 x double> %27, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %32 = shufflevector <4 x double> %31, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %33 = fadd <4 x double> %15, %32
  store <4 x double> %33, ptr %gep.i.i, align 8
  %34 = or disjoint i64 %14, 1
  %35 = shl nuw nsw i64 %34, 6
  %gep32.i.i.1 = getelementptr double, ptr %invariant.gep31.i.i, i64 %34
  %36 = load double, ptr %gep32.i.i.1, align 8
  %37 = insertelement <1 x double> poison, double %36, i64 0
  %gep34.i.i.1 = getelementptr double, ptr %invariant.gep33.i.i, i64 %35
  %38 = load <4 x double>, ptr %gep34.i.i.1, align 8
  %39 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> zeroinitializer
  %40 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 1>
  %41 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 2>
  %42 = shufflevector <4 x double> %38, <4 x double> poison, <1 x i32> <i32 3>
  %43 = fmul <1 x double> %37, %39
  %44 = fmul <1 x double> %37, %40
  %45 = fmul <1 x double> %37, %41
  %46 = shufflevector <1 x double> %45, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %47 = fmul <1 x double> %37, %42
  %48 = shufflevector <1 x double> %47, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <1 x double> %43, <1 x double> %44, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %50 = shufflevector <4 x double> %49, <4 x double> %46, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %48, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %52 = fadd <4 x double> %33, %51
  store <4 x double> %52, ptr %gep.i.i, align 8
  %53 = add nuw nsw i64 %14, 2
  %exitcond.not.i.i.1 = icmp eq i64 %53, 128
  br i1 %exitcond.not.i.i.1, label %.preheader.1.i.i, label %.critedge.i.i

.preheader.1.i.i:                                 ; preds = %.critedge.i.i
  %54 = getelementptr double, ptr %gep.i.i, i64 4
  %.promoted.1.i.i = load <4 x double>, ptr %54, align 8
  br label %.critedge.1.i.i

.critedge.1.i.i:                                  ; preds = %.critedge.1.i.i, %.preheader.1.i.i
  %55 = phi i64 [ 0, %.preheader.1.i.i ], [ %94, %.critedge.1.i.i ]
  %56 = phi <4 x double> [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %93, %.critedge.1.i.i ]
  %57 = shl nuw nsw i64 %55, 6
  %gep28.i.i = getelementptr double, ptr %invariant.gep31.i.i, i64 %55
  %58 = load double, ptr %gep28.i.i, align 8
  %59 = insertelement <1 x double> poison, double %58, i64 0
  %gep30.i.i = getelementptr double, ptr %invariant.gep29.i.i, i64 %57
  %60 = load <4 x double>, ptr %gep30.i.i, align 8
  %61 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> zeroinitializer
  %62 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 1>
  %63 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 2>
  %64 = shufflevector <4 x double> %60, <4 x double> poison, <1 x i32> <i32 3>
  %65 = fmul <1 x double> %59, %61
  %66 = fmul <1 x double> %59, %62
  %67 = fmul <1 x double> %59, %63
  %68 = shufflevector <1 x double> %67, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = fmul <1 x double> %59, %64
  %70 = shufflevector <1 x double> %69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %71 = shufflevector <1 x double> %65, <1 x double> %66, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %72 = shufflevector <4 x double> %71, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %73 = shufflevector <4 x double> %72, <4 x double> %70, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %74 = fadd <4 x double> %56, %73
  store <4 x double> %74, ptr %54, align 8
  %75 = or disjoint i64 %55, 1
  %76 = shl nuw nsw i64 %75, 6
  %gep28.i.i.1 = getelementptr double, ptr %invariant.gep31.i.i, i64 %75
  %77 = load double, ptr %gep28.i.i.1, align 8
  %78 = insertelement <1 x double> poison, double %77, i64 0
  %gep30.i.i.1 = getelementptr double, ptr %invariant.gep29.i.i, i64 %76
  %79 = load <4 x double>, ptr %gep30.i.i.1, align 8
  %80 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> zeroinitializer
  %81 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 1>
  %82 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 2>
  %83 = shufflevector <4 x double> %79, <4 x double> poison, <1 x i32> <i32 3>
  %84 = fmul <1 x double> %78, %80
  %85 = fmul <1 x double> %78, %81
  %86 = fmul <1 x double> %78, %82
  %87 = shufflevector <1 x double> %86, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %88 = fmul <1 x double> %78, %83
  %89 = shufflevector <1 x double> %88, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %90 = shufflevector <1 x double> %84, <1 x double> %85, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %91 = shufflevector <4 x double> %90, <4 x double> %87, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %92 = shufflevector <4 x double> %91, <4 x double> %89, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %93 = fadd <4 x double> %74, %92
  store <4 x double> %93, ptr %54, align 8
  %94 = add nuw nsw i64 %55, 2
  %exitcond.1.not.i.i.1 = icmp eq i64 %94, 128
  br i1 %exitcond.1.not.i.i.1, label %.preheader.2.i.i, label %.critedge.1.i.i

.preheader.2.i.i:                                 ; preds = %.critedge.1.i.i
  %95 = getelementptr double, ptr %gep.i.i, i64 8
  %.promoted.2.i.i = load <4 x double>, ptr %95, align 8
  br label %.critedge.2.i.i

.critedge.2.i.i:                                  ; preds = %.critedge.2.i.i, %.preheader.2.i.i
  %96 = phi i64 [ 0, %.preheader.2.i.i ], [ %135, %.critedge.2.i.i ]
  %97 = phi <4 x double> [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %134, %.critedge.2.i.i ]
  %98 = shl nuw nsw i64 %96, 6
  %gep24.i.i = getelementptr double, ptr %invariant.gep31.i.i, i64 %96
  %99 = load double, ptr %gep24.i.i, align 8
  %100 = insertelement <1 x double> poison, double %99, i64 0
  %gep26.i.i = getelementptr double, ptr %invariant.gep25.i.i, i64 %98
  %101 = load <4 x double>, ptr %gep26.i.i, align 8
  %102 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> zeroinitializer
  %103 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 1>
  %104 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 2>
  %105 = shufflevector <4 x double> %101, <4 x double> poison, <1 x i32> <i32 3>
  %106 = fmul <1 x double> %100, %102
  %107 = fmul <1 x double> %100, %103
  %108 = fmul <1 x double> %100, %104
  %109 = shufflevector <1 x double> %108, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %110 = fmul <1 x double> %100, %105
  %111 = shufflevector <1 x double> %110, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %112 = shufflevector <1 x double> %106, <1 x double> %107, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %113 = shufflevector <4 x double> %112, <4 x double> %109, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %111, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %115 = fadd <4 x double> %97, %114
  store <4 x double> %115, ptr %95, align 8
  %116 = or disjoint i64 %96, 1
  %117 = shl nuw nsw i64 %116, 6
  %gep24.i.i.1 = getelementptr double, ptr %invariant.gep31.i.i, i64 %116
  %118 = load double, ptr %gep24.i.i.1, align 8
  %119 = insertelement <1 x double> poison, double %118, i64 0
  %gep26.i.i.1 = getelementptr double, ptr %invariant.gep25.i.i, i64 %117
  %120 = load <4 x double>, ptr %gep26.i.i.1, align 8
  %121 = shufflevector <4 x double> %120, <4 x double> poison, <1 x i32> zeroinitializer
  %122 = shufflevector <4 x double> %120, <4 x double> poison, <1 x i32> <i32 1>
  %123 = shufflevector <4 x double> %120, <4 x double> poison, <1 x i32> <i32 2>
  %124 = shufflevector <4 x double> %120, <4 x double> poison, <1 x i32> <i32 3>
  %125 = fmul <1 x double> %119, %121
  %126 = fmul <1 x double> %119, %122
  %127 = fmul <1 x double> %119, %123
  %128 = shufflevector <1 x double> %127, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %129 = fmul <1 x double> %119, %124
  %130 = shufflevector <1 x double> %129, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %131 = shufflevector <1 x double> %125, <1 x double> %126, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %132 = shufflevector <4 x double> %131, <4 x double> %128, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %133 = shufflevector <4 x double> %132, <4 x double> %130, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %134 = fadd <4 x double> %115, %133
  store <4 x double> %134, ptr %95, align 8
  %135 = add nuw nsw i64 %96, 2
  %exitcond.2.not.i.i.1 = icmp eq i64 %135, 128
  br i1 %exitcond.2.not.i.i.1, label %.preheader.3.i.i, label %.critedge.2.i.i

.preheader.3.i.i:                                 ; preds = %.critedge.2.i.i
  %136 = getelementptr double, ptr %gep.i.i, i64 12
  %.promoted.3.i.i = load <4 x double>, ptr %136, align 8
  br label %.critedge.3.i.i

.critedge.3.i.i:                                  ; preds = %.critedge.3.i.i, %.preheader.3.i.i
  %137 = phi i64 [ 0, %.preheader.3.i.i ], [ %176, %.critedge.3.i.i ]
  %138 = phi <4 x double> [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %175, %.critedge.3.i.i ]
  %139 = shl nuw nsw i64 %137, 6
  %gep20.i.i = getelementptr double, ptr %invariant.gep31.i.i, i64 %137
  %140 = load double, ptr %gep20.i.i, align 8
  %141 = insertelement <1 x double> poison, double %140, i64 0
  %gep22.i.i = getelementptr double, ptr %invariant.gep21.i.i, i64 %139
  %142 = load <4 x double>, ptr %gep22.i.i, align 8
  %143 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> zeroinitializer
  %144 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 1>
  %145 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 2>
  %146 = shufflevector <4 x double> %142, <4 x double> poison, <1 x i32> <i32 3>
  %147 = fmul <1 x double> %141, %143
  %148 = fmul <1 x double> %141, %144
  %149 = fmul <1 x double> %141, %145
  %150 = shufflevector <1 x double> %149, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %151 = fmul <1 x double> %141, %146
  %152 = shufflevector <1 x double> %151, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %153 = shufflevector <1 x double> %147, <1 x double> %148, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %154 = shufflevector <4 x double> %153, <4 x double> %150, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %155 = shufflevector <4 x double> %154, <4 x double> %152, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %156 = fadd <4 x double> %138, %155
  store <4 x double> %156, ptr %136, align 8
  %157 = or disjoint i64 %137, 1
  %158 = shl nuw nsw i64 %157, 6
  %gep20.i.i.1 = getelementptr double, ptr %invariant.gep31.i.i, i64 %157
  %159 = load double, ptr %gep20.i.i.1, align 8
  %160 = insertelement <1 x double> poison, double %159, i64 0
  %gep22.i.i.1 = getelementptr double, ptr %invariant.gep21.i.i, i64 %158
  %161 = load <4 x double>, ptr %gep22.i.i.1, align 8
  %162 = shufflevector <4 x double> %161, <4 x double> poison, <1 x i32> zeroinitializer
  %163 = shufflevector <4 x double> %161, <4 x double> poison, <1 x i32> <i32 1>
  %164 = shufflevector <4 x double> %161, <4 x double> poison, <1 x i32> <i32 2>
  %165 = shufflevector <4 x double> %161, <4 x double> poison, <1 x i32> <i32 3>
  %166 = fmul <1 x double> %160, %162
  %167 = fmul <1 x double> %160, %163
  %168 = fmul <1 x double> %160, %164
  %169 = shufflevector <1 x double> %168, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %170 = fmul <1 x double> %160, %165
  %171 = shufflevector <1 x double> %170, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %172 = shufflevector <1 x double> %166, <1 x double> %167, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %173 = shufflevector <4 x double> %172, <4 x double> %169, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %174 = shufflevector <4 x double> %173, <4 x double> %171, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %175 = fadd <4 x double> %156, %174
  store <4 x double> %175, ptr %136, align 8
  %176 = add nuw nsw i64 %137, 2
  %exitcond.3.not.i.i.1 = icmp eq i64 %176, 128
  br i1 %exitcond.3.not.i.i.1, label %177, label %.critedge.3.i.i

177:                                              ; preds = %.critedge.3.i.i
  %178 = add nuw nsw i64 %11, 1
  %exitcond19.not.i.i = icmp eq i64 %178, 8
  br i1 %exitcond19.not.i.i, label %179, label %.preheader15.i.i

179:                                              ; preds = %177
  %180 = add nuw nsw i64 %10, 16
  %181 = icmp ult i64 %10, 48
  br i1 %181, label %.preheader16.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %179
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
