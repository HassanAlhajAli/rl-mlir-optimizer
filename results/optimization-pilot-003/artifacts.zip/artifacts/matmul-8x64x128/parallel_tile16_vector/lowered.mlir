module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: i64, %arg13: i64, %arg14: !llvm.ptr, %arg15: !llvm.ptr, %arg16: i64, %arg17: i64, %arg18: i64, %arg19: i64, %arg20: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.insertvalue %arg12, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.insertvalue %arg11, %13[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.insertvalue %arg13, %14[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.insertvalue %arg14, %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.insertvalue %arg17, %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.insertvalue %arg19, %20[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.insertvalue %arg18, %21[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.insertvalue %arg20, %22[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %24 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4xf64>) : !llvm.array<1 x vector<4xf64>>
    %25 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x1x4xf64>) : !llvm.array<1 x array<1 x vector<4xf64>>>
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x4x1xf64>) : !llvm.array<1 x array<4 x vector<1xf64>>>
    %27 = llvm.mlir.constant(dense<0.000000e+00> : vector<4x1xf64>) : !llvm.array<4 x vector<1xf64>>
    %28 = llvm.mlir.constant(8 : index) : i64
    %29 = llvm.mlir.constant(128 : index) : i64
    %30 = llvm.mlir.constant(64 : index) : i64
    %31 = llvm.mlir.constant(1 : index) : i64
    %32 = llvm.mlir.constant(4 : index) : i64
    %33 = llvm.mlir.constant(0 : index) : i64
    %34 = llvm.mlir.constant(16 : index) : i64
    %35 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%33 : i64)
  ^bb1(%36: i64):  // 2 preds: ^bb0, ^bb5
    %37 = llvm.icmp "slt" %36, %28 : i64
    llvm.cond_br %37, ^bb2, ^bb6
  ^bb2:  // pred: ^bb1
    llvm.br ^bb3(%33 : i64)
  ^bb3(%38: i64):  // 2 preds: ^bb2, ^bb4
    %39 = llvm.icmp "slt" %38, %30 : i64
    llvm.cond_br %39, ^bb4, ^bb5
  ^bb4:  // pred: ^bb3
    %40 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %41 = llvm.mlir.constant(64 : index) : i64
    %42 = llvm.mul %36, %41  : i64
    %43 = llvm.add %42, %38  : i64
    %44 = llvm.getelementptr %40[%43] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %35, %44 : f64, !llvm.ptr
    %45 = llvm.add %38, %31  : i64
    llvm.br ^bb3(%45 : i64)
  ^bb5:  // pred: ^bb3
    %46 = llvm.add %36, %31  : i64
    llvm.br ^bb1(%46 : i64)
  ^bb6:  // pred: ^bb1
    %47 = llvm.mlir.constant(1 : index) : i64
    %48 = llvm.alloca %47 x !llvm.array<1 x vector<1xf64>> : (i64) -> !llvm.ptr
    %49 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %50 = llvm.insertvalue %48, %49[0] : !llvm.struct<(ptr, ptr, i64)> 
    %51 = llvm.insertvalue %48, %50[1] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(0 : index) : i64
    %53 = llvm.insertvalue %52, %51[2] : !llvm.struct<(ptr, ptr, i64)> 
    %54 = llvm.mlir.constant(1 : index) : i64
    %55 = llvm.alloca %54 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %56 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %57 = llvm.insertvalue %55, %56[0] : !llvm.struct<(ptr, ptr, i64)> 
    %58 = llvm.insertvalue %55, %57[1] : !llvm.struct<(ptr, ptr, i64)> 
    %59 = llvm.mlir.constant(0 : index) : i64
    %60 = llvm.insertvalue %59, %58[2] : !llvm.struct<(ptr, ptr, i64)> 
    %61 = llvm.mlir.constant(1 : index) : i64
    %62 = llvm.alloca %61 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %63 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %64 = llvm.insertvalue %62, %63[0] : !llvm.struct<(ptr, ptr, i64)> 
    %65 = llvm.insertvalue %62, %64[1] : !llvm.struct<(ptr, ptr, i64)> 
    %66 = llvm.mlir.constant(0 : index) : i64
    %67 = llvm.insertvalue %66, %65[2] : !llvm.struct<(ptr, ptr, i64)> 
    %68 = llvm.mlir.constant(1 : index) : i64
    %69 = llvm.alloca %68 x !llvm.array<1 x vector<4xf64>> : (i64) -> !llvm.ptr
    %70 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %71 = llvm.insertvalue %69, %70[0] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.insertvalue %69, %71[1] : !llvm.struct<(ptr, ptr, i64)> 
    %73 = llvm.mlir.constant(0 : index) : i64
    %74 = llvm.insertvalue %73, %72[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb7(%33 : i64)
  ^bb7(%75: i64):  // 2 preds: ^bb6, ^bb29
    %76 = llvm.icmp "slt" %75, %30 : i64
    llvm.cond_br %76, ^bb8, ^bb30
  ^bb8:  // pred: ^bb7
    %77 = llvm.extractvalue %15[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.extractvalue %15[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %80 = llvm.insertvalue %77, %79[0] : !llvm.struct<(ptr, ptr, i64)> 
    %81 = llvm.insertvalue %78, %80[1] : !llvm.struct<(ptr, ptr, i64)> 
    %82 = llvm.mlir.constant(0 : index) : i64
    %83 = llvm.insertvalue %82, %81[2] : !llvm.struct<(ptr, ptr, i64)> 
    %84 = llvm.extractvalue %15[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %85 = llvm.extractvalue %15[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.extractvalue %15[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %87 = llvm.extractvalue %15[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %15[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %89 = llvm.extractvalue %23[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %90 = llvm.extractvalue %23[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %91 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %92 = llvm.insertvalue %89, %91[0] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.insertvalue %90, %92[1] : !llvm.struct<(ptr, ptr, i64)> 
    %94 = llvm.mlir.constant(0 : index) : i64
    %95 = llvm.insertvalue %94, %93[2] : !llvm.struct<(ptr, ptr, i64)> 
    %96 = llvm.extractvalue %23[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %97 = llvm.extractvalue %23[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %98 = llvm.extractvalue %23[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %99 = llvm.extractvalue %23[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %100 = llvm.extractvalue %23[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.br ^bb9(%33 : i64)
  ^bb9(%101: i64):  // 2 preds: ^bb8, ^bb28
    %102 = llvm.icmp "slt" %101, %28 : i64
    llvm.cond_br %102, ^bb10, ^bb29
  ^bb10:  // pred: ^bb9
    llvm.br ^bb11(%33 : i64)
  ^bb11(%103: i64):  // 2 preds: ^bb10, ^bb27
    %104 = llvm.icmp "slt" %103, %34 : i64
    llvm.cond_br %104, ^bb12, ^bb28
  ^bb12:  // pred: ^bb11
    llvm.br ^bb13(%33 : i64)
  ^bb13(%105: i64):  // 2 preds: ^bb12, ^bb26
    %106 = llvm.icmp "slt" %105, %29 : i64
    llvm.cond_br %106, ^bb14, ^bb27
  ^bb14:  // pred: ^bb13
    %107 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %108 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %110 = llvm.insertvalue %107, %109[0] : !llvm.struct<(ptr, ptr, i64)> 
    %111 = llvm.insertvalue %108, %110[1] : !llvm.struct<(ptr, ptr, i64)> 
    %112 = llvm.mlir.constant(0 : index) : i64
    %113 = llvm.insertvalue %112, %111[2] : !llvm.struct<(ptr, ptr, i64)> 
    %114 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %115 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %116 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %117 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %118 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %119 = llvm.mul %101, %29  : i64
    %120 = llvm.add %119, %105  : i64
    %121 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %122 = llvm.insertvalue %107, %121[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %123 = llvm.insertvalue %108, %122[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %124 = llvm.insertvalue %120, %123[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %125 = llvm.mlir.constant(1 : index) : i64
    %126 = llvm.insertvalue %125, %124[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %127 = llvm.mlir.constant(128 : index) : i64
    %128 = llvm.insertvalue %127, %126[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %129 = llvm.mlir.constant(1 : index) : i64
    %130 = llvm.insertvalue %129, %128[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %131 = llvm.mlir.constant(1 : index) : i64
    %132 = llvm.insertvalue %131, %130[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %133 = llvm.mul %105, %30  : i64
    %134 = llvm.add %75, %133  : i64
    %135 = llvm.add %134, %103  : i64
    %136 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %137 = llvm.insertvalue %77, %136[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %138 = llvm.insertvalue %78, %137[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %139 = llvm.insertvalue %135, %138[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %140 = llvm.mlir.constant(1 : index) : i64
    %141 = llvm.insertvalue %140, %139[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %142 = llvm.mlir.constant(64 : index) : i64
    %143 = llvm.insertvalue %142, %141[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %144 = llvm.mlir.constant(4 : index) : i64
    %145 = llvm.insertvalue %144, %143[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %146 = llvm.mlir.constant(1 : index) : i64
    %147 = llvm.insertvalue %146, %145[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %148 = llvm.mul %101, %30  : i64
    %149 = llvm.add %75, %148  : i64
    %150 = llvm.add %149, %103  : i64
    %151 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %152 = llvm.insertvalue %89, %151[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %153 = llvm.insertvalue %90, %152[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %154 = llvm.insertvalue %150, %153[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %155 = llvm.mlir.constant(1 : index) : i64
    %156 = llvm.insertvalue %155, %154[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %157 = llvm.mlir.constant(64 : index) : i64
    %158 = llvm.insertvalue %157, %156[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %159 = llvm.mlir.constant(4 : index) : i64
    %160 = llvm.insertvalue %159, %158[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %161 = llvm.mlir.constant(1 : index) : i64
    %162 = llvm.insertvalue %161, %160[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %163 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %164 = llvm.extractvalue %53[0] : !llvm.struct<(ptr, ptr, i64)> 
    %165 = llvm.insertvalue %164, %163[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %166 = llvm.extractvalue %53[1] : !llvm.struct<(ptr, ptr, i64)> 
    %167 = llvm.insertvalue %166, %165[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %168 = llvm.mlir.constant(0 : index) : i64
    %169 = llvm.insertvalue %168, %167[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %170 = llvm.mlir.constant(1 : index) : i64
    %171 = llvm.insertvalue %170, %169[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %172 = llvm.mlir.constant(1 : index) : i64
    %173 = llvm.insertvalue %172, %171[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb15(%33 : i64)
  ^bb15(%174: i64):  // 2 preds: ^bb14, ^bb16
    %175 = llvm.icmp "slt" %174, %31 : i64
    llvm.cond_br %175, ^bb16, ^bb17
  ^bb16:  // pred: ^bb15
    %176 = llvm.getelementptr %108[%120] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %177 = llvm.mlir.constant(128 : index) : i64
    %178 = llvm.mul %174, %177  : i64
    %179 = llvm.add %178, %33  : i64
    %180 = llvm.getelementptr %176[%179] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %181 = llvm.load %180 : !llvm.ptr -> f64
    %182 = llvm.mlir.undef : vector<1xf64>
    %183 = llvm.mlir.constant(0 : i32) : i32
    %184 = llvm.insertelement %181, %182[%183 : i32] : vector<1xf64>
    %185 = llvm.shufflevector %184, %182 [0] : vector<1xf64> 
    %186 = llvm.getelementptr %166[%174] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %185, %186 : vector<1xf64>, !llvm.ptr
    %187 = llvm.add %174, %31  : i64
    llvm.br ^bb15(%187 : i64)
  ^bb17:  // pred: ^bb15
    %188 = llvm.load %48 : !llvm.ptr -> !llvm.array<1 x vector<1xf64>>
    %189 = llvm.extractvalue %188[0] : !llvm.array<1 x vector<1xf64>> 
    %190 = llvm.insertvalue %189, %27[0] : !llvm.array<4 x vector<1xf64>> 
    %191 = llvm.insertvalue %189, %190[1] : !llvm.array<4 x vector<1xf64>> 
    %192 = llvm.insertvalue %189, %191[2] : !llvm.array<4 x vector<1xf64>> 
    %193 = llvm.insertvalue %189, %192[3] : !llvm.array<4 x vector<1xf64>> 
    %194 = llvm.insertvalue %193, %26[0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %195 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %196 = llvm.extractvalue %60[0] : !llvm.struct<(ptr, ptr, i64)> 
    %197 = llvm.insertvalue %196, %195[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %198 = llvm.extractvalue %60[1] : !llvm.struct<(ptr, ptr, i64)> 
    %199 = llvm.insertvalue %198, %197[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %200 = llvm.mlir.constant(0 : index) : i64
    %201 = llvm.insertvalue %200, %199[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %202 = llvm.mlir.constant(1 : index) : i64
    %203 = llvm.insertvalue %202, %201[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %204 = llvm.mlir.constant(1 : index) : i64
    %205 = llvm.insertvalue %204, %203[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb18(%33 : i64)
  ^bb18(%206: i64):  // 2 preds: ^bb17, ^bb19
    %207 = llvm.icmp "slt" %206, %31 : i64
    llvm.cond_br %207, ^bb19, ^bb20
  ^bb19:  // pred: ^bb18
    %208 = llvm.extractvalue %147[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %209 = llvm.extractvalue %147[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %210 = llvm.getelementptr %208[%209] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %211 = llvm.mlir.constant(64 : index) : i64
    %212 = llvm.mul %206, %211  : i64
    %213 = llvm.add %212, %33  : i64
    %214 = llvm.getelementptr %210[%213] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %215 = llvm.load %214 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %216 = llvm.getelementptr %198[%206] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %215, %216 : vector<4xf64>, !llvm.ptr
    %217 = llvm.add %206, %31  : i64
    llvm.br ^bb18(%217 : i64)
  ^bb20:  // pred: ^bb18
    %218 = llvm.load %55 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %219 = llvm.extractvalue %218[0] : !llvm.array<1 x vector<4xf64>> 
    %220 = llvm.mlir.constant(0 : i64) : i64
    %221 = llvm.extractelement %219[%220 : i64] : vector<4xf64>
    %222 = llvm.extractvalue %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %223 = llvm.mlir.constant(0 : i64) : i64
    %224 = llvm.insertelement %221, %222[%223 : i64] : vector<1xf64>
    %225 = llvm.insertvalue %224, %26[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %226 = llvm.extractvalue %218[0] : !llvm.array<1 x vector<4xf64>> 
    %227 = llvm.mlir.constant(1 : i64) : i64
    %228 = llvm.extractelement %226[%227 : i64] : vector<4xf64>
    %229 = llvm.extractvalue %26[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %230 = llvm.mlir.constant(0 : i64) : i64
    %231 = llvm.insertelement %228, %229[%230 : i64] : vector<1xf64>
    %232 = llvm.insertvalue %231, %225[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %233 = llvm.extractvalue %218[0] : !llvm.array<1 x vector<4xf64>> 
    %234 = llvm.mlir.constant(2 : i64) : i64
    %235 = llvm.extractelement %233[%234 : i64] : vector<4xf64>
    %236 = llvm.extractvalue %26[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %237 = llvm.mlir.constant(0 : i64) : i64
    %238 = llvm.insertelement %235, %236[%237 : i64] : vector<1xf64>
    %239 = llvm.insertvalue %238, %232[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %240 = llvm.extractvalue %218[0] : !llvm.array<1 x vector<4xf64>> 
    %241 = llvm.mlir.constant(3 : i64) : i64
    %242 = llvm.extractelement %240[%241 : i64] : vector<4xf64>
    %243 = llvm.extractvalue %26[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %244 = llvm.mlir.constant(0 : i64) : i64
    %245 = llvm.insertelement %242, %243[%244 : i64] : vector<1xf64>
    %246 = llvm.insertvalue %245, %239[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %247 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %248 = llvm.extractvalue %67[0] : !llvm.struct<(ptr, ptr, i64)> 
    %249 = llvm.insertvalue %248, %247[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %250 = llvm.extractvalue %67[1] : !llvm.struct<(ptr, ptr, i64)> 
    %251 = llvm.insertvalue %250, %249[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %252 = llvm.mlir.constant(0 : index) : i64
    %253 = llvm.insertvalue %252, %251[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %254 = llvm.mlir.constant(1 : index) : i64
    %255 = llvm.insertvalue %254, %253[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %256 = llvm.mlir.constant(1 : index) : i64
    %257 = llvm.insertvalue %256, %255[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb21(%33 : i64)
  ^bb21(%258: i64):  // 2 preds: ^bb20, ^bb22
    %259 = llvm.icmp "slt" %258, %31 : i64
    llvm.cond_br %259, ^bb22, ^bb23
  ^bb22:  // pred: ^bb21
    %260 = llvm.extractvalue %162[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %261 = llvm.extractvalue %162[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %262 = llvm.getelementptr %260[%261] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %263 = llvm.mlir.constant(64 : index) : i64
    %264 = llvm.mul %258, %263  : i64
    %265 = llvm.add %264, %33  : i64
    %266 = llvm.getelementptr %262[%265] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %267 = llvm.load %266 {alignment = 8 : i64} : !llvm.ptr -> vector<4xf64>
    %268 = llvm.getelementptr %250[%258] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    llvm.store %267, %268 : vector<4xf64>, !llvm.ptr
    %269 = llvm.add %258, %31  : i64
    llvm.br ^bb21(%269 : i64)
  ^bb23:  // pred: ^bb21
    %270 = llvm.load %62 : !llvm.ptr -> !llvm.array<1 x vector<4xf64>>
    %271 = llvm.mlir.undef : !llvm.array<1 x array<4 x vector<1xf64>>>
    %272 = llvm.extractvalue %194[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %273 = llvm.fmul %272, %224  : vector<1xf64>
    %274 = llvm.insertvalue %273, %271[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %275 = llvm.extractvalue %194[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %276 = llvm.fmul %275, %231  : vector<1xf64>
    %277 = llvm.insertvalue %276, %274[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %278 = llvm.extractvalue %194[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %279 = llvm.fmul %278, %238  : vector<1xf64>
    %280 = llvm.insertvalue %279, %277[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %281 = llvm.extractvalue %194[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %282 = llvm.fmul %281, %245  : vector<1xf64>
    %283 = llvm.insertvalue %282, %280[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %284 = llvm.extractvalue %283[0, 0] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %285 = llvm.mlir.constant(0 : i64) : i64
    %286 = llvm.extractelement %284[%285 : i64] : vector<1xf64>
    %287 = llvm.extractvalue %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %288 = llvm.mlir.constant(0 : i64) : i64
    %289 = llvm.insertelement %286, %287[%288 : i64] : vector<4xf64>
    %290 = llvm.insertvalue %289, %25[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %291 = llvm.extractvalue %283[0, 1] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %292 = llvm.mlir.constant(0 : i64) : i64
    %293 = llvm.extractelement %291[%292 : i64] : vector<1xf64>
    %294 = llvm.mlir.constant(1 : i64) : i64
    %295 = llvm.insertelement %293, %289[%294 : i64] : vector<4xf64>
    %296 = llvm.insertvalue %295, %290[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %297 = llvm.extractvalue %283[0, 2] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %298 = llvm.mlir.constant(0 : i64) : i64
    %299 = llvm.extractelement %297[%298 : i64] : vector<1xf64>
    %300 = llvm.mlir.constant(2 : i64) : i64
    %301 = llvm.insertelement %299, %295[%300 : i64] : vector<4xf64>
    %302 = llvm.insertvalue %301, %296[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %303 = llvm.extractvalue %283[0, 3] : !llvm.array<1 x array<4 x vector<1xf64>>> 
    %304 = llvm.mlir.constant(0 : i64) : i64
    %305 = llvm.extractelement %303[%304 : i64] : vector<1xf64>
    %306 = llvm.mlir.constant(3 : i64) : i64
    %307 = llvm.insertelement %305, %301[%306 : i64] : vector<4xf64>
    %308 = llvm.insertvalue %307, %302[0, 0] : !llvm.array<1 x array<1 x vector<4xf64>>> 
    %309 = llvm.extractvalue %270[0] : !llvm.array<1 x vector<4xf64>> 
    %310 = llvm.fadd %307, %309  : vector<4xf64>
    %311 = llvm.insertvalue %310, %24[0] : !llvm.array<1 x vector<4xf64>> 
    llvm.store %311, %69 : !llvm.array<1 x vector<4xf64>>, !llvm.ptr
    %312 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %313 = llvm.extractvalue %74[0] : !llvm.struct<(ptr, ptr, i64)> 
    %314 = llvm.insertvalue %313, %312[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %315 = llvm.extractvalue %74[1] : !llvm.struct<(ptr, ptr, i64)> 
    %316 = llvm.insertvalue %315, %314[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %317 = llvm.mlir.constant(0 : index) : i64
    %318 = llvm.insertvalue %317, %316[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %319 = llvm.mlir.constant(1 : index) : i64
    %320 = llvm.insertvalue %319, %318[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %321 = llvm.mlir.constant(1 : index) : i64
    %322 = llvm.insertvalue %321, %320[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb24(%33 : i64)
  ^bb24(%323: i64):  // 2 preds: ^bb23, ^bb25
    %324 = llvm.icmp "slt" %323, %31 : i64
    llvm.cond_br %324, ^bb25, ^bb26
  ^bb25:  // pred: ^bb24
    %325 = llvm.getelementptr %315[%323] : (!llvm.ptr, i64) -> !llvm.ptr, vector<4xf64>
    %326 = llvm.load %325 : !llvm.ptr -> vector<4xf64>
    %327 = llvm.extractvalue %162[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %328 = llvm.extractvalue %162[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %329 = llvm.getelementptr %327[%328] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %330 = llvm.mlir.constant(64 : index) : i64
    %331 = llvm.mul %323, %330  : i64
    %332 = llvm.add %331, %33  : i64
    %333 = llvm.getelementptr %329[%332] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %326, %333 {alignment = 8 : i64} : vector<4xf64>, !llvm.ptr
    %334 = llvm.add %323, %31  : i64
    llvm.br ^bb24(%334 : i64)
  ^bb26:  // pred: ^bb24
    %335 = llvm.add %105, %31  : i64
    llvm.br ^bb13(%335 : i64)
  ^bb27:  // pred: ^bb13
    %336 = llvm.add %103, %32  : i64
    llvm.br ^bb11(%336 : i64)
  ^bb28:  // pred: ^bb11
    %337 = llvm.add %101, %31  : i64
    llvm.br ^bb9(%337 : i64)
  ^bb29:  // pred: ^bb9
    %338 = llvm.add %75, %34  : i64
    llvm.br ^bb7(%338 : i64)
  ^bb30:  // pred: ^bb7
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %13 = llvm.extractvalue %8[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %14 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %15 = llvm.extractvalue %8[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %16 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %17 = llvm.extractvalue %16[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %18 = llvm.extractvalue %16[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %19 = llvm.extractvalue %16[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %20 = llvm.extractvalue %16[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %21 = llvm.extractvalue %16[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %22 = llvm.extractvalue %16[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %23 = llvm.extractvalue %16[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %14, %15, %17, %18, %19, %20, %21, %22, %23) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64) -> ()
    llvm.return
  }
}
