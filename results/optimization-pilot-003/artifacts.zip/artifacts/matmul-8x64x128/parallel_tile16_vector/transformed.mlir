#map = affine_map<(d0) -> (-d0 + 8, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map3 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<8x128xf64>, %arg1: memref<128x64xf64>, %arg2: memref<8x64xf64>) attributes {llvm.emit_c_interface} {
    %c1 = arith.constant 1 : index
    %c4 = arith.constant 4 : index
    %c1_0 = arith.constant 1 : index
    %c0 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_1 = arith.constant 0 : index
    %c16_2 = arith.constant 16 : index
    %c0_3 = arith.constant 0 : index
    %c0_4 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<8x64xf64>)
    %c0_5 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c16_6 = arith.constant 16 : index
    scf.for %arg3 = %c0_5 to %c8 step %c16_6 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 128] [1, 1] : memref<8x128xf64> to memref<?x128xf64, strided<[128, 1], offset: ?>>
      %subview_7 = memref.subview %arg2[%arg3, 0] [%1, 64] [1, 1] : memref<8x64xf64> to memref<?x64xf64, strided<[64, 1], offset: ?>>
      %c0_8 = arith.constant 0 : index
      %c0_9 = arith.constant 0 : index
      %c0_10 = arith.constant 0 : index
      %c64 = arith.constant 64 : index
      %c16_11 = arith.constant 16 : index
      scf.for %arg4 = %c0_10 to %c64 step %c16_11 {
        %2 = affine.apply #map1(%0)
        %c0_12 = arith.constant 0 : index
        %subview_13 = memref.subview %arg1[0, %arg4] [128, 16] [1, 1] : memref<128x64xf64> to memref<128x16xf64, strided<[64, 1], offset: ?>>
        %subview_14 = memref.subview %subview_7[0, %arg4] [%1, 16] [1, 1] : memref<?x64xf64, strided<[64, 1], offset: ?>> to memref<?x16xf64, strided<[64, 1], offset: ?>>
        %c0_15 = arith.constant 0 : index
        %c0_16 = arith.constant 0 : index
        %c0_17 = arith.constant 0 : index
        %c1_18 = arith.constant 1 : index
        %c0_19 = arith.constant 0 : index
        %c16_20 = arith.constant 16 : index
        %c4_21 = arith.constant 4 : index
        %c0_22 = arith.constant 0 : index
        %c128 = arith.constant 128 : index
        %c1_23 = arith.constant 1 : index
        scf.for %arg5 = %c0_17 to %0 step %c1_18 {
          scf.for %arg6 = %c0_19 to %c16_20 step %c4_21 {
            scf.for %arg7 = %c0_22 to %c128 step %c1_23 {
              %subview_24 = memref.subview %subview[%arg5, %arg7] [1, 1] [1, 1] : memref<?x128xf64, strided<[128, 1], offset: ?>> to memref<1x1xf64, strided<[128, 1], offset: ?>>
              %subview_25 = memref.subview %subview_13[%arg7, %arg6] [1, 4] [1, 1] : memref<128x16xf64, strided<[64, 1], offset: ?>> to memref<1x4xf64, strided<[64, 1], offset: ?>>
              %subview_26 = memref.subview %subview_14[%arg5, %arg6] [1, 4] [1, 1] : memref<?x16xf64, strided<[64, 1], offset: ?>> to memref<1x4xf64, strided<[64, 1], offset: ?>>
              %c1_27 = arith.constant 1 : index
              %c4_28 = arith.constant 4 : index
              %c1_29 = arith.constant 1 : index
              %c0_30 = arith.constant 0 : index
              %cst_31 = arith.constant 0.000000e+00 : f64
              %3 = vector.transfer_read %subview_24[%c0_30, %c0_30], %cst_31 {permutation_map = #map2} : memref<1x1xf64, strided<[128, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_32 = arith.constant 0.000000e+00 : f64
              %4 = vector.transfer_read %subview_25[%c0_30, %c0_30], %cst_32 {permutation_map = #map3} : memref<1x4xf64, strided<[64, 1], offset: ?>>, vector<1x4x1xf64>
              %cst_33 = arith.constant 0.000000e+00 : f64
              %5 = vector.transfer_read %subview_26[%c0_30, %c0_30], %cst_33 : memref<1x4xf64, strided<[64, 1], offset: ?>>, vector<1x4xf64>
              %6 = arith.mulf %3, %4 : vector<1x4x1xf64>
              %7 = vector.multi_reduction <add>, %6, %5 [2] : vector<1x4x1xf64> to vector<1x4xf64>
              %c0_34 = arith.constant 0 : index
              vector.transfer_write %7, %subview_26[%c0_34, %c0_34] : vector<1x4xf64>, memref<1x4xf64, strided<[64, 1], offset: ?>>
            }
          }
        }
      }
    }
    return
  }
}
