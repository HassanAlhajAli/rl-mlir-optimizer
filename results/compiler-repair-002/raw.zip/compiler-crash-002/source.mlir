module {
  func.func @kernel(%a: memref<336x205xf64>, %b: memref<205xf64>, %c: memref<336xf64>) {
    %zero = arith.constant 0.0 : f64
    linalg.fill ins(%zero : f64) outs(%c : memref<336xf64>)
    linalg.generic {indexing_maps = [affine_map<(i,k)->(i,k)>, affine_map<(i,k)->(k)>, affine_map<(i,k)->(i)>],
      iterator_types = ["parallel", "reduction"]}
      ins(%a, %b : memref<336x205xf64>, memref<205xf64>) outs(%c : memref<336xf64>) {
      ^bb0(%x: f64, %y: f64, %sum: f64):
        %s = arith.addf %sum, %x : f64
        linalg.yield %s : f64
    }
    return
  }
}