; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader2.preheader, %54
  %21 = phi i64 [ 0, %.preheader2.preheader ], [ %55, %54 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %21
  %22 = getelementptr double, ptr %15, i64 %21
  %.promoted = load double, ptr %22, align 8
  br label %23

23:                                               ; preds = %23, %.preheader
  %24 = phi i64 [ 0, %.preheader ], [ %53, %23 ]
  %25 = phi double [ %.promoted, %.preheader ], [ %52, %23 ]
  %26 = getelementptr double, ptr %1, i64 %24
  %27 = load double, ptr %26, align 8
  %28 = shl nuw nsw i64 %24, 6
  %gep = getelementptr double, ptr %invariant.gep, i64 %28
  %29 = load double, ptr %gep, align 8
  %30 = fmul double %27, %29
  %31 = fadd double %25, %30
  store double %31, ptr %22, align 8
  %32 = or disjoint i64 %24, 1
  %33 = getelementptr double, ptr %1, i64 %32
  %34 = load double, ptr %33, align 8
  %35 = shl nuw nsw i64 %32, 6
  %gep.121 = getelementptr double, ptr %invariant.gep, i64 %35
  %36 = load double, ptr %gep.121, align 8
  %37 = fmul double %34, %36
  %38 = fadd double %31, %37
  store double %38, ptr %22, align 8
  %39 = or disjoint i64 %24, 2
  %40 = getelementptr double, ptr %1, i64 %39
  %41 = load double, ptr %40, align 8
  %42 = shl nuw nsw i64 %39, 6
  %gep.222 = getelementptr double, ptr %invariant.gep, i64 %42
  %43 = load double, ptr %gep.222, align 8
  %44 = fmul double %41, %43
  %45 = fadd double %38, %44
  store double %45, ptr %22, align 8
  %46 = or disjoint i64 %24, 3
  %47 = getelementptr double, ptr %1, i64 %46
  %48 = load double, ptr %47, align 8
  %49 = shl nuw nsw i64 %46, 6
  %gep.323 = getelementptr double, ptr %invariant.gep, i64 %49
  %50 = load double, ptr %gep.323, align 8
  %51 = fmul double %48, %50
  %52 = fadd double %45, %51
  store double %52, ptr %22, align 8
  %53 = add nuw nsw i64 %24, 4
  %exitcond.not.3 = icmp eq i64 %53, 128
  br i1 %exitcond.not.3, label %54, label %23

54:                                               ; preds = %23
  %55 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %55, 64
  br i1 %exitcond5.not, label %.preheader2.1, label %.preheader

.preheader2.1:                                    ; preds = %54
  %56 = getelementptr double, ptr %15, i64 64
  %invariant.gep7 = getelementptr double, ptr %1, i64 128
  br label %.preheader.1

.preheader.1:                                     ; preds = %86, %.preheader2.1
  %57 = phi i64 [ 0, %.preheader2.1 ], [ %87, %86 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %57
  %58 = getelementptr double, ptr %56, i64 %57
  %.promoted.1 = load double, ptr %58, align 8
  br label %59

59:                                               ; preds = %59, %.preheader.1
  %60 = phi i64 [ 0, %.preheader.1 ], [ %85, %59 ]
  %61 = phi double [ %.promoted.1, %.preheader.1 ], [ %84, %59 ]
  %gep8 = getelementptr double, ptr %invariant.gep7, i64 %60
  %62 = load double, ptr %gep8, align 8
  %63 = shl nuw nsw i64 %60, 6
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %63
  %64 = load double, ptr %gep.1, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %61, %65
  store double %66, ptr %58, align 8
  %67 = or disjoint i64 %60, 1
  %gep8.1 = getelementptr double, ptr %invariant.gep7, i64 %67
  %68 = load double, ptr %gep8.1, align 8
  %69 = shl nuw nsw i64 %67, 6
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %69
  %70 = load double, ptr %gep.1.1, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %58, align 8
  %73 = or disjoint i64 %60, 2
  %gep8.2 = getelementptr double, ptr %invariant.gep7, i64 %73
  %74 = load double, ptr %gep8.2, align 8
  %75 = shl nuw nsw i64 %73, 6
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %75
  %76 = load double, ptr %gep.1.2, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %72, %77
  store double %78, ptr %58, align 8
  %79 = or disjoint i64 %60, 3
  %gep8.3 = getelementptr double, ptr %invariant.gep7, i64 %79
  %80 = load double, ptr %gep8.3, align 8
  %81 = shl nuw nsw i64 %79, 6
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %81
  %82 = load double, ptr %gep.1.3, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %58, align 8
  %85 = add nuw nsw i64 %60, 4
  %exitcond.1.not.3 = icmp eq i64 %85, 128
  br i1 %exitcond.1.not.3, label %86, label %59

86:                                               ; preds = %59
  %87 = add nuw nsw i64 %57, 1
  %exitcond5.1.not = icmp eq i64 %87, 64
  br i1 %exitcond5.1.not, label %.preheader2.2, label %.preheader.1

.preheader2.2:                                    ; preds = %86
  %88 = getelementptr double, ptr %15, i64 128
  %invariant.gep9 = getelementptr double, ptr %1, i64 256
  br label %.preheader.2

.preheader.2:                                     ; preds = %118, %.preheader2.2
  %89 = phi i64 [ 0, %.preheader2.2 ], [ %119, %118 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %89
  %90 = getelementptr double, ptr %88, i64 %89
  %.promoted.2 = load double, ptr %90, align 8
  br label %91

91:                                               ; preds = %91, %.preheader.2
  %92 = phi i64 [ 0, %.preheader.2 ], [ %117, %91 ]
  %93 = phi double [ %.promoted.2, %.preheader.2 ], [ %116, %91 ]
  %gep10 = getelementptr double, ptr %invariant.gep9, i64 %92
  %94 = load double, ptr %gep10, align 8
  %95 = shl nuw nsw i64 %92, 6
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %95
  %96 = load double, ptr %gep.2, align 8
  %97 = fmul double %94, %96
  %98 = fadd double %93, %97
  store double %98, ptr %90, align 8
  %99 = or disjoint i64 %92, 1
  %gep10.1 = getelementptr double, ptr %invariant.gep9, i64 %99
  %100 = load double, ptr %gep10.1, align 8
  %101 = shl nuw nsw i64 %99, 6
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %101
  %102 = load double, ptr %gep.2.1, align 8
  %103 = fmul double %100, %102
  %104 = fadd double %98, %103
  store double %104, ptr %90, align 8
  %105 = or disjoint i64 %92, 2
  %gep10.2 = getelementptr double, ptr %invariant.gep9, i64 %105
  %106 = load double, ptr %gep10.2, align 8
  %107 = shl nuw nsw i64 %105, 6
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %107
  %108 = load double, ptr %gep.2.2, align 8
  %109 = fmul double %106, %108
  %110 = fadd double %104, %109
  store double %110, ptr %90, align 8
  %111 = or disjoint i64 %92, 3
  %gep10.3 = getelementptr double, ptr %invariant.gep9, i64 %111
  %112 = load double, ptr %gep10.3, align 8
  %113 = shl nuw nsw i64 %111, 6
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %113
  %114 = load double, ptr %gep.2.3, align 8
  %115 = fmul double %112, %114
  %116 = fadd double %110, %115
  store double %116, ptr %90, align 8
  %117 = add nuw nsw i64 %92, 4
  %exitcond.2.not.3 = icmp eq i64 %117, 128
  br i1 %exitcond.2.not.3, label %118, label %91

118:                                              ; preds = %91
  %119 = add nuw nsw i64 %89, 1
  %exitcond5.2.not = icmp eq i64 %119, 64
  br i1 %exitcond5.2.not, label %.preheader2.3, label %.preheader.2

.preheader2.3:                                    ; preds = %118
  %120 = getelementptr double, ptr %15, i64 192
  %invariant.gep11 = getelementptr double, ptr %1, i64 384
  br label %.preheader.3

.preheader.3:                                     ; preds = %150, %.preheader2.3
  %121 = phi i64 [ 0, %.preheader2.3 ], [ %151, %150 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %121
  %122 = getelementptr double, ptr %120, i64 %121
  %.promoted.3 = load double, ptr %122, align 8
  br label %123

123:                                              ; preds = %123, %.preheader.3
  %124 = phi i64 [ 0, %.preheader.3 ], [ %149, %123 ]
  %125 = phi double [ %.promoted.3, %.preheader.3 ], [ %148, %123 ]
  %gep12 = getelementptr double, ptr %invariant.gep11, i64 %124
  %126 = load double, ptr %gep12, align 8
  %127 = shl nuw nsw i64 %124, 6
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %127
  %128 = load double, ptr %gep.3, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %125, %129
  store double %130, ptr %122, align 8
  %131 = or disjoint i64 %124, 1
  %gep12.1 = getelementptr double, ptr %invariant.gep11, i64 %131
  %132 = load double, ptr %gep12.1, align 8
  %133 = shl nuw nsw i64 %131, 6
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %133
  %134 = load double, ptr %gep.3.1, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %122, align 8
  %137 = or disjoint i64 %124, 2
  %gep12.2 = getelementptr double, ptr %invariant.gep11, i64 %137
  %138 = load double, ptr %gep12.2, align 8
  %139 = shl nuw nsw i64 %137, 6
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %139
  %140 = load double, ptr %gep.3.2, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %122, align 8
  %143 = or disjoint i64 %124, 3
  %gep12.3 = getelementptr double, ptr %invariant.gep11, i64 %143
  %144 = load double, ptr %gep12.3, align 8
  %145 = shl nuw nsw i64 %143, 6
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %145
  %146 = load double, ptr %gep.3.3, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %122, align 8
  %149 = add nuw nsw i64 %124, 4
  %exitcond.3.not.3 = icmp eq i64 %149, 128
  br i1 %exitcond.3.not.3, label %150, label %123

150:                                              ; preds = %123
  %151 = add nuw nsw i64 %121, 1
  %exitcond5.3.not = icmp eq i64 %151, 64
  br i1 %exitcond5.3.not, label %.preheader2.4, label %.preheader.3

.preheader2.4:                                    ; preds = %150
  %152 = getelementptr double, ptr %15, i64 256
  %invariant.gep13 = getelementptr double, ptr %1, i64 512
  br label %.preheader.4

.preheader.4:                                     ; preds = %182, %.preheader2.4
  %153 = phi i64 [ 0, %.preheader2.4 ], [ %183, %182 ]
  %invariant.gep.4 = getelementptr double, ptr %8, i64 %153
  %154 = getelementptr double, ptr %152, i64 %153
  %.promoted.4 = load double, ptr %154, align 8
  br label %155

155:                                              ; preds = %155, %.preheader.4
  %156 = phi i64 [ 0, %.preheader.4 ], [ %181, %155 ]
  %157 = phi double [ %.promoted.4, %.preheader.4 ], [ %180, %155 ]
  %gep14 = getelementptr double, ptr %invariant.gep13, i64 %156
  %158 = load double, ptr %gep14, align 8
  %159 = shl nuw nsw i64 %156, 6
  %gep.4 = getelementptr double, ptr %invariant.gep.4, i64 %159
  %160 = load double, ptr %gep.4, align 8
  %161 = fmul double %158, %160
  %162 = fadd double %157, %161
  store double %162, ptr %154, align 8
  %163 = or disjoint i64 %156, 1
  %gep14.1 = getelementptr double, ptr %invariant.gep13, i64 %163
  %164 = load double, ptr %gep14.1, align 8
  %165 = shl nuw nsw i64 %163, 6
  %gep.4.1 = getelementptr double, ptr %invariant.gep.4, i64 %165
  %166 = load double, ptr %gep.4.1, align 8
  %167 = fmul double %164, %166
  %168 = fadd double %162, %167
  store double %168, ptr %154, align 8
  %169 = or disjoint i64 %156, 2
  %gep14.2 = getelementptr double, ptr %invariant.gep13, i64 %169
  %170 = load double, ptr %gep14.2, align 8
  %171 = shl nuw nsw i64 %169, 6
  %gep.4.2 = getelementptr double, ptr %invariant.gep.4, i64 %171
  %172 = load double, ptr %gep.4.2, align 8
  %173 = fmul double %170, %172
  %174 = fadd double %168, %173
  store double %174, ptr %154, align 8
  %175 = or disjoint i64 %156, 3
  %gep14.3 = getelementptr double, ptr %invariant.gep13, i64 %175
  %176 = load double, ptr %gep14.3, align 8
  %177 = shl nuw nsw i64 %175, 6
  %gep.4.3 = getelementptr double, ptr %invariant.gep.4, i64 %177
  %178 = load double, ptr %gep.4.3, align 8
  %179 = fmul double %176, %178
  %180 = fadd double %174, %179
  store double %180, ptr %154, align 8
  %181 = add nuw nsw i64 %156, 4
  %exitcond.4.not.3 = icmp eq i64 %181, 128
  br i1 %exitcond.4.not.3, label %182, label %155

182:                                              ; preds = %155
  %183 = add nuw nsw i64 %153, 1
  %exitcond5.4.not = icmp eq i64 %183, 64
  br i1 %exitcond5.4.not, label %.preheader2.5, label %.preheader.4

.preheader2.5:                                    ; preds = %182
  %184 = getelementptr double, ptr %15, i64 320
  %invariant.gep15 = getelementptr double, ptr %1, i64 640
  br label %.preheader.5

.preheader.5:                                     ; preds = %214, %.preheader2.5
  %185 = phi i64 [ 0, %.preheader2.5 ], [ %215, %214 ]
  %invariant.gep.5 = getelementptr double, ptr %8, i64 %185
  %186 = getelementptr double, ptr %184, i64 %185
  %.promoted.5 = load double, ptr %186, align 8
  br label %187

187:                                              ; preds = %187, %.preheader.5
  %188 = phi i64 [ 0, %.preheader.5 ], [ %213, %187 ]
  %189 = phi double [ %.promoted.5, %.preheader.5 ], [ %212, %187 ]
  %gep16 = getelementptr double, ptr %invariant.gep15, i64 %188
  %190 = load double, ptr %gep16, align 8
  %191 = shl nuw nsw i64 %188, 6
  %gep.5 = getelementptr double, ptr %invariant.gep.5, i64 %191
  %192 = load double, ptr %gep.5, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %189, %193
  store double %194, ptr %186, align 8
  %195 = or disjoint i64 %188, 1
  %gep16.1 = getelementptr double, ptr %invariant.gep15, i64 %195
  %196 = load double, ptr %gep16.1, align 8
  %197 = shl nuw nsw i64 %195, 6
  %gep.5.1 = getelementptr double, ptr %invariant.gep.5, i64 %197
  %198 = load double, ptr %gep.5.1, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %186, align 8
  %201 = or disjoint i64 %188, 2
  %gep16.2 = getelementptr double, ptr %invariant.gep15, i64 %201
  %202 = load double, ptr %gep16.2, align 8
  %203 = shl nuw nsw i64 %201, 6
  %gep.5.2 = getelementptr double, ptr %invariant.gep.5, i64 %203
  %204 = load double, ptr %gep.5.2, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %186, align 8
  %207 = or disjoint i64 %188, 3
  %gep16.3 = getelementptr double, ptr %invariant.gep15, i64 %207
  %208 = load double, ptr %gep16.3, align 8
  %209 = shl nuw nsw i64 %207, 6
  %gep.5.3 = getelementptr double, ptr %invariant.gep.5, i64 %209
  %210 = load double, ptr %gep.5.3, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %186, align 8
  %213 = add nuw nsw i64 %188, 4
  %exitcond.5.not.3 = icmp eq i64 %213, 128
  br i1 %exitcond.5.not.3, label %214, label %187

214:                                              ; preds = %187
  %215 = add nuw nsw i64 %185, 1
  %exitcond5.5.not = icmp eq i64 %215, 64
  br i1 %exitcond5.5.not, label %.preheader2.6, label %.preheader.5

.preheader2.6:                                    ; preds = %214
  %216 = getelementptr double, ptr %15, i64 384
  %invariant.gep17 = getelementptr double, ptr %1, i64 768
  br label %.preheader.6

.preheader.6:                                     ; preds = %246, %.preheader2.6
  %217 = phi i64 [ 0, %.preheader2.6 ], [ %247, %246 ]
  %invariant.gep.6 = getelementptr double, ptr %8, i64 %217
  %218 = getelementptr double, ptr %216, i64 %217
  %.promoted.6 = load double, ptr %218, align 8
  br label %219

219:                                              ; preds = %219, %.preheader.6
  %220 = phi i64 [ 0, %.preheader.6 ], [ %245, %219 ]
  %221 = phi double [ %.promoted.6, %.preheader.6 ], [ %244, %219 ]
  %gep18 = getelementptr double, ptr %invariant.gep17, i64 %220
  %222 = load double, ptr %gep18, align 8
  %223 = shl nuw nsw i64 %220, 6
  %gep.6 = getelementptr double, ptr %invariant.gep.6, i64 %223
  %224 = load double, ptr %gep.6, align 8
  %225 = fmul double %222, %224
  %226 = fadd double %221, %225
  store double %226, ptr %218, align 8
  %227 = or disjoint i64 %220, 1
  %gep18.1 = getelementptr double, ptr %invariant.gep17, i64 %227
  %228 = load double, ptr %gep18.1, align 8
  %229 = shl nuw nsw i64 %227, 6
  %gep.6.1 = getelementptr double, ptr %invariant.gep.6, i64 %229
  %230 = load double, ptr %gep.6.1, align 8
  %231 = fmul double %228, %230
  %232 = fadd double %226, %231
  store double %232, ptr %218, align 8
  %233 = or disjoint i64 %220, 2
  %gep18.2 = getelementptr double, ptr %invariant.gep17, i64 %233
  %234 = load double, ptr %gep18.2, align 8
  %235 = shl nuw nsw i64 %233, 6
  %gep.6.2 = getelementptr double, ptr %invariant.gep.6, i64 %235
  %236 = load double, ptr %gep.6.2, align 8
  %237 = fmul double %234, %236
  %238 = fadd double %232, %237
  store double %238, ptr %218, align 8
  %239 = or disjoint i64 %220, 3
  %gep18.3 = getelementptr double, ptr %invariant.gep17, i64 %239
  %240 = load double, ptr %gep18.3, align 8
  %241 = shl nuw nsw i64 %239, 6
  %gep.6.3 = getelementptr double, ptr %invariant.gep.6, i64 %241
  %242 = load double, ptr %gep.6.3, align 8
  %243 = fmul double %240, %242
  %244 = fadd double %238, %243
  store double %244, ptr %218, align 8
  %245 = add nuw nsw i64 %220, 4
  %exitcond.6.not.3 = icmp eq i64 %245, 128
  br i1 %exitcond.6.not.3, label %246, label %219

246:                                              ; preds = %219
  %247 = add nuw nsw i64 %217, 1
  %exitcond5.6.not = icmp eq i64 %247, 64
  br i1 %exitcond5.6.not, label %.preheader2.7, label %.preheader.6

.preheader2.7:                                    ; preds = %246
  %248 = getelementptr double, ptr %15, i64 448
  %invariant.gep19 = getelementptr double, ptr %1, i64 896
  br label %.preheader.7

.preheader.7:                                     ; preds = %278, %.preheader2.7
  %249 = phi i64 [ 0, %.preheader2.7 ], [ %279, %278 ]
  %invariant.gep.7 = getelementptr double, ptr %8, i64 %249
  %250 = getelementptr double, ptr %248, i64 %249
  %.promoted.7 = load double, ptr %250, align 8
  br label %251

251:                                              ; preds = %251, %.preheader.7
  %252 = phi i64 [ 0, %.preheader.7 ], [ %277, %251 ]
  %253 = phi double [ %.promoted.7, %.preheader.7 ], [ %276, %251 ]
  %gep20 = getelementptr double, ptr %invariant.gep19, i64 %252
  %254 = load double, ptr %gep20, align 8
  %255 = shl nuw nsw i64 %252, 6
  %gep.7 = getelementptr double, ptr %invariant.gep.7, i64 %255
  %256 = load double, ptr %gep.7, align 8
  %257 = fmul double %254, %256
  %258 = fadd double %253, %257
  store double %258, ptr %250, align 8
  %259 = or disjoint i64 %252, 1
  %gep20.1 = getelementptr double, ptr %invariant.gep19, i64 %259
  %260 = load double, ptr %gep20.1, align 8
  %261 = shl nuw nsw i64 %259, 6
  %gep.7.1 = getelementptr double, ptr %invariant.gep.7, i64 %261
  %262 = load double, ptr %gep.7.1, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %258, %263
  store double %264, ptr %250, align 8
  %265 = or disjoint i64 %252, 2
  %gep20.2 = getelementptr double, ptr %invariant.gep19, i64 %265
  %266 = load double, ptr %gep20.2, align 8
  %267 = shl nuw nsw i64 %265, 6
  %gep.7.2 = getelementptr double, ptr %invariant.gep.7, i64 %267
  %268 = load double, ptr %gep.7.2, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %264, %269
  store double %270, ptr %250, align 8
  %271 = or disjoint i64 %252, 3
  %gep20.3 = getelementptr double, ptr %invariant.gep19, i64 %271
  %272 = load double, ptr %gep20.3, align 8
  %273 = shl nuw nsw i64 %271, 6
  %gep.7.3 = getelementptr double, ptr %invariant.gep.7, i64 %273
  %274 = load double, ptr %gep.7.3, align 8
  %275 = fmul double %272, %274
  %276 = fadd double %270, %275
  store double %276, ptr %250, align 8
  %277 = add nuw nsw i64 %252, 4
  %exitcond.7.not.3 = icmp eq i64 %277, 128
  br i1 %exitcond.7.not.3, label %278, label %251

278:                                              ; preds = %251
  %279 = add nuw nsw i64 %249, 1
  %exitcond5.7.not = icmp eq i64 %279, 64
  br i1 %exitcond5.7.not, label %280, label %.preheader.7

280:                                              ; preds = %278
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
