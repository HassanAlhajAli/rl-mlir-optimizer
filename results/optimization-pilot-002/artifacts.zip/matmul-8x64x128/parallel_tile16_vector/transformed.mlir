#map = affine_map<(d0) -> (-d0 + 8, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map3 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<8x128xf64>, %arg1: memref<128x64xf64>, %arg2: memref<8x64xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_2 = arith.constant 0 : index
    %c16_3 = arith.constant 16 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<8x64xf64>)
    %c0_6 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_6 to %c8 step %c16_7 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 128] [1, 1] : memref<8x128xf64> to memref<?x128xf64, strided<[128, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [%1, 64] [1, 1] : memref<8x64xf64> to memref<?x64xf64, strided<[64, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c0_10 = arith.constant 0 : index
      %c0_11 = arith.constant 0 : index
      %c64 = arith.constant 64 : index
      %c16_12 = arith.constant 16 : index
      scf.for %arg4 = %c0_11 to %c64 step %c16_12 {
        %2 = affine.apply #map1(%0)
        %c0_13 = arith.constant 0 : index
        %subview_14 = memref.subview %arg1[0, %arg4] [128, 16] [1, 1] : memref<128x64xf64> to memref<128x16xf64, strided<[64, 1], offset: ?>>
        %subview_15 = memref.subview %subview_8[0, %arg4] [%1, 16] [1, 1] : memref<?x64xf64, strided<[64, 1], offset: ?>> to memref<?x16xf64, strided<[64, 1], offset: ?>>
        %c0_16 = arith.constant 0 : index
        %c0_17 = arith.constant 0 : index
        %c0_18 = arith.constant 0 : index
        %c128 = arith.constant 128 : index
        %c1_19 = arith.constant 1 : index
        scf.for %arg5 = %c0_18 to %c128 step %c1_19 {
          %3 = affine.apply #map1(%0)
          %c0_20 = arith.constant 0 : index
          %subview_21 = memref.subview %subview[0, %arg5] [%0, 1] [1, 1] : memref<?x128xf64, strided<[128, 1], offset: ?>> to memref<?x1xf64, strided<[128, 1], offset: ?>>
          %subview_22 = memref.subview %subview_14[%arg5, 0] [1, 16] [1, 1] : memref<128x16xf64, strided<[64, 1], offset: ?>> to memref<1x16xf64, strided<[64, 1], offset: ?>>
          %c0_23 = arith.constant 0 : index
          %dim = memref.dim %subview_21, %c0_23 : memref<?x1xf64, strided<[128, 1], offset: ?>>
          %c16_24 = arith.constant 16 : index
          %c1_25 = arith.constant 1 : index
          %c0_26 = arith.constant 0 : index
          %cst_27 = arith.constant 0.000000e+00 : f64
          %4 = vector.create_mask %dim, %c1_25 : vector<8x1xi1>
          %5 = vector.mask %4 { vector.transfer_read %subview_21[%c0_26, %c0_26], %cst_27 {in_bounds = [true, true, true], permutation_map = #map2} : memref<?x1xf64, strided<[128, 1], offset: ?>>, vector<8x16x1xf64> } : vector<8x1xi1> -> vector<8x16x1xf64>
          %cst_28 = arith.constant 0.000000e+00 : f64
          %6 = vector.transfer_read %subview_22[%c0_26, %c0_26], %cst_28 {permutation_map = #map3} : memref<1x16xf64, strided<[64, 1], offset: ?>>, vector<8x16x1xf64>
          %cst_29 = arith.constant 0.000000e+00 : f64
          %7 = vector.create_mask %dim, %c16_24 : vector<8x16xi1>
          %8 = vector.mask %7 { vector.transfer_read %subview_15[%c0_26, %c0_26], %cst_29 {in_bounds = [true, true]} : memref<?x16xf64, strided<[64, 1], offset: ?>>, vector<8x16xf64> } : vector<8x16xi1> -> vector<8x16xf64>
          %9 = arith.mulf %5, %6 : vector<8x16x1xf64>
          %10 = vector.create_mask %dim, %c16_24, %c1_25 : vector<8x16x1xi1>
          %11 = vector.mask %10 { vector.multi_reduction <add>, %9, %8 [2] : vector<8x16x1xf64> to vector<8x16xf64> } : vector<8x16x1xi1> -> vector<8x16xf64>
          %c0_30 = arith.constant 0 : index
          vector.mask %7 { vector.transfer_write %11, %subview_15[%c0_30, %c0_30] {in_bounds = [true, true]} : vector<8x16xf64>, memref<?x16xf64, strided<[64, 1], offset: ?>> } : vector<8x16xi1>
        }
      }
    }
    return
  }
}
