; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader4.preheader, %54
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %55, %54 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %21
  %22 = getelementptr double, ptr %15, i64 %21
  %.promoted = load double, ptr %22, align 8
  br label %23

23:                                               ; preds = %23, %.preheader
  %24 = phi i64 [ 0, %.preheader ], [ %53, %23 ]
  %25 = phi double [ %.promoted, %.preheader ], [ %52, %23 ]
  %26 = getelementptr double, ptr %1, i64 %24
  %27 = load double, ptr %26, align 8
  %28 = shl nuw nsw i64 %24, 6
  %gep = getelementptr double, ptr %invariant.gep, i64 %28
  %29 = load double, ptr %gep, align 8
  %30 = fmul double %27, %29
  %31 = fadd double %25, %30
  store double %31, ptr %22, align 8
  %32 = or disjoint i64 %24, 1
  %33 = getelementptr double, ptr %1, i64 %32
  %34 = load double, ptr %33, align 8
  %35 = shl nuw nsw i64 %32, 6
  %gep.127 = getelementptr double, ptr %invariant.gep, i64 %35
  %36 = load double, ptr %gep.127, align 8
  %37 = fmul double %34, %36
  %38 = fadd double %31, %37
  store double %38, ptr %22, align 8
  %39 = or disjoint i64 %24, 2
  %40 = getelementptr double, ptr %1, i64 %39
  %41 = load double, ptr %40, align 8
  %42 = shl nuw nsw i64 %39, 6
  %gep.228 = getelementptr double, ptr %invariant.gep, i64 %42
  %43 = load double, ptr %gep.228, align 8
  %44 = fmul double %41, %43
  %45 = fadd double %38, %44
  store double %45, ptr %22, align 8
  %46 = or disjoint i64 %24, 3
  %47 = getelementptr double, ptr %1, i64 %46
  %48 = load double, ptr %47, align 8
  %49 = shl nuw nsw i64 %46, 6
  %gep.329 = getelementptr double, ptr %invariant.gep, i64 %49
  %50 = load double, ptr %gep.329, align 8
  %51 = fmul double %48, %50
  %52 = fadd double %45, %51
  store double %52, ptr %22, align 8
  %53 = add nuw nsw i64 %24, 4
  %exitcond.not.3 = icmp eq i64 %53, 128
  br i1 %exitcond.not.3, label %54, label %23

54:                                               ; preds = %23
  %55 = add nuw nsw i64 %21, 1
  %exitcond6.not = icmp eq i64 %55, 64
  br i1 %exitcond6.not, label %.preheader3.1, label %.preheader

.preheader3.1:                                    ; preds = %54
  %56 = getelementptr double, ptr %15, i64 64
  %invariant.gep19 = getelementptr double, ptr %1, i64 128
  br label %.preheader.1

.preheader.1:                                     ; preds = %86, %.preheader3.1
  %57 = phi i64 [ 0, %.preheader3.1 ], [ %87, %86 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %57
  %58 = getelementptr double, ptr %56, i64 %57
  %.promoted.1 = load double, ptr %58, align 8
  br label %59

59:                                               ; preds = %59, %.preheader.1
  %60 = phi i64 [ 0, %.preheader.1 ], [ %85, %59 ]
  %61 = phi double [ %.promoted.1, %.preheader.1 ], [ %84, %59 ]
  %gep20 = getelementptr double, ptr %invariant.gep19, i64 %60
  %62 = load double, ptr %gep20, align 8
  %63 = shl nuw nsw i64 %60, 6
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %63
  %64 = load double, ptr %gep.1, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %61, %65
  store double %66, ptr %58, align 8
  %67 = or disjoint i64 %60, 1
  %gep20.1 = getelementptr double, ptr %invariant.gep19, i64 %67
  %68 = load double, ptr %gep20.1, align 8
  %69 = shl nuw nsw i64 %67, 6
  %gep.1.130 = getelementptr double, ptr %invariant.gep.1, i64 %69
  %70 = load double, ptr %gep.1.130, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %58, align 8
  %73 = or disjoint i64 %60, 2
  %gep20.2 = getelementptr double, ptr %invariant.gep19, i64 %73
  %74 = load double, ptr %gep20.2, align 8
  %75 = shl nuw nsw i64 %73, 6
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %75
  %76 = load double, ptr %gep.1.2, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %72, %77
  store double %78, ptr %58, align 8
  %79 = or disjoint i64 %60, 3
  %gep20.3 = getelementptr double, ptr %invariant.gep19, i64 %79
  %80 = load double, ptr %gep20.3, align 8
  %81 = shl nuw nsw i64 %79, 6
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %81
  %82 = load double, ptr %gep.1.3, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %58, align 8
  %85 = add nuw nsw i64 %60, 4
  %exitcond.1.not.3 = icmp eq i64 %85, 128
  br i1 %exitcond.1.not.3, label %86, label %59

86:                                               ; preds = %59
  %87 = add nuw nsw i64 %57, 1
  %exitcond6.1.not = icmp eq i64 %87, 64
  br i1 %exitcond6.1.not, label %.preheader3.2, label %.preheader.1

.preheader3.2:                                    ; preds = %86
  %88 = getelementptr double, ptr %15, i64 128
  %invariant.gep17 = getelementptr double, ptr %1, i64 256
  br label %.preheader.2

.preheader.2:                                     ; preds = %118, %.preheader3.2
  %89 = phi i64 [ 0, %.preheader3.2 ], [ %119, %118 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %89
  %90 = getelementptr double, ptr %88, i64 %89
  %.promoted.2 = load double, ptr %90, align 8
  br label %91

91:                                               ; preds = %91, %.preheader.2
  %92 = phi i64 [ 0, %.preheader.2 ], [ %117, %91 ]
  %93 = phi double [ %.promoted.2, %.preheader.2 ], [ %116, %91 ]
  %gep18 = getelementptr double, ptr %invariant.gep17, i64 %92
  %94 = load double, ptr %gep18, align 8
  %95 = shl nuw nsw i64 %92, 6
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %95
  %96 = load double, ptr %gep.2, align 8
  %97 = fmul double %94, %96
  %98 = fadd double %93, %97
  store double %98, ptr %90, align 8
  %99 = or disjoint i64 %92, 1
  %gep18.1 = getelementptr double, ptr %invariant.gep17, i64 %99
  %100 = load double, ptr %gep18.1, align 8
  %101 = shl nuw nsw i64 %99, 6
  %gep.2.131 = getelementptr double, ptr %invariant.gep.2, i64 %101
  %102 = load double, ptr %gep.2.131, align 8
  %103 = fmul double %100, %102
  %104 = fadd double %98, %103
  store double %104, ptr %90, align 8
  %105 = or disjoint i64 %92, 2
  %gep18.2 = getelementptr double, ptr %invariant.gep17, i64 %105
  %106 = load double, ptr %gep18.2, align 8
  %107 = shl nuw nsw i64 %105, 6
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %107
  %108 = load double, ptr %gep.2.2, align 8
  %109 = fmul double %106, %108
  %110 = fadd double %104, %109
  store double %110, ptr %90, align 8
  %111 = or disjoint i64 %92, 3
  %gep18.3 = getelementptr double, ptr %invariant.gep17, i64 %111
  %112 = load double, ptr %gep18.3, align 8
  %113 = shl nuw nsw i64 %111, 6
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %113
  %114 = load double, ptr %gep.2.3, align 8
  %115 = fmul double %112, %114
  %116 = fadd double %110, %115
  store double %116, ptr %90, align 8
  %117 = add nuw nsw i64 %92, 4
  %exitcond.2.not.3 = icmp eq i64 %117, 128
  br i1 %exitcond.2.not.3, label %118, label %91

118:                                              ; preds = %91
  %119 = add nuw nsw i64 %89, 1
  %exitcond6.2.not = icmp eq i64 %119, 64
  br i1 %exitcond6.2.not, label %.preheader3.3, label %.preheader.2

.preheader3.3:                                    ; preds = %118
  %120 = getelementptr double, ptr %15, i64 192
  %invariant.gep15 = getelementptr double, ptr %1, i64 384
  br label %.preheader.3

.preheader.3:                                     ; preds = %150, %.preheader3.3
  %121 = phi i64 [ 0, %.preheader3.3 ], [ %151, %150 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %121
  %122 = getelementptr double, ptr %120, i64 %121
  %.promoted.3 = load double, ptr %122, align 8
  br label %123

123:                                              ; preds = %123, %.preheader.3
  %124 = phi i64 [ 0, %.preheader.3 ], [ %149, %123 ]
  %125 = phi double [ %.promoted.3, %.preheader.3 ], [ %148, %123 ]
  %gep16 = getelementptr double, ptr %invariant.gep15, i64 %124
  %126 = load double, ptr %gep16, align 8
  %127 = shl nuw nsw i64 %124, 6
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %127
  %128 = load double, ptr %gep.3, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %125, %129
  store double %130, ptr %122, align 8
  %131 = or disjoint i64 %124, 1
  %gep16.1 = getelementptr double, ptr %invariant.gep15, i64 %131
  %132 = load double, ptr %gep16.1, align 8
  %133 = shl nuw nsw i64 %131, 6
  %gep.3.132 = getelementptr double, ptr %invariant.gep.3, i64 %133
  %134 = load double, ptr %gep.3.132, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %122, align 8
  %137 = or disjoint i64 %124, 2
  %gep16.2 = getelementptr double, ptr %invariant.gep15, i64 %137
  %138 = load double, ptr %gep16.2, align 8
  %139 = shl nuw nsw i64 %137, 6
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %139
  %140 = load double, ptr %gep.3.2, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %122, align 8
  %143 = or disjoint i64 %124, 3
  %gep16.3 = getelementptr double, ptr %invariant.gep15, i64 %143
  %144 = load double, ptr %gep16.3, align 8
  %145 = shl nuw nsw i64 %143, 6
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %145
  %146 = load double, ptr %gep.3.3, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %122, align 8
  %149 = add nuw nsw i64 %124, 4
  %exitcond.3.not.3 = icmp eq i64 %149, 128
  br i1 %exitcond.3.not.3, label %150, label %123

150:                                              ; preds = %123
  %151 = add nuw nsw i64 %121, 1
  %exitcond6.3.not = icmp eq i64 %151, 64
  br i1 %exitcond6.3.not, label %.preheader4.1, label %.preheader.3

.preheader4.1:                                    ; preds = %150
  %152 = getelementptr double, ptr %1, i64 512
  %153 = getelementptr double, ptr %15, i64 256
  br label %.preheader.111

.preheader.111:                                   ; preds = %187, %.preheader4.1
  %154 = phi i64 [ 0, %.preheader4.1 ], [ %188, %187 ]
  %invariant.gep.19 = getelementptr double, ptr %8, i64 %154
  %155 = getelementptr double, ptr %153, i64 %154
  %.promoted.110 = load double, ptr %155, align 8
  br label %156

156:                                              ; preds = %156, %.preheader.111
  %157 = phi i64 [ 0, %.preheader.111 ], [ %186, %156 ]
  %158 = phi double [ %.promoted.110, %.preheader.111 ], [ %185, %156 ]
  %159 = getelementptr double, ptr %152, i64 %157
  %160 = load double, ptr %159, align 8
  %161 = shl nuw nsw i64 %157, 6
  %gep.112 = getelementptr double, ptr %invariant.gep.19, i64 %161
  %162 = load double, ptr %gep.112, align 8
  %163 = fmul double %160, %162
  %164 = fadd double %158, %163
  store double %164, ptr %155, align 8
  %165 = or disjoint i64 %157, 1
  %166 = getelementptr double, ptr %152, i64 %165
  %167 = load double, ptr %166, align 8
  %168 = shl nuw nsw i64 %165, 6
  %gep.112.1 = getelementptr double, ptr %invariant.gep.19, i64 %168
  %169 = load double, ptr %gep.112.1, align 8
  %170 = fmul double %167, %169
  %171 = fadd double %164, %170
  store double %171, ptr %155, align 8
  %172 = or disjoint i64 %157, 2
  %173 = getelementptr double, ptr %152, i64 %172
  %174 = load double, ptr %173, align 8
  %175 = shl nuw nsw i64 %172, 6
  %gep.112.2 = getelementptr double, ptr %invariant.gep.19, i64 %175
  %176 = load double, ptr %gep.112.2, align 8
  %177 = fmul double %174, %176
  %178 = fadd double %171, %177
  store double %178, ptr %155, align 8
  %179 = or disjoint i64 %157, 3
  %180 = getelementptr double, ptr %152, i64 %179
  %181 = load double, ptr %180, align 8
  %182 = shl nuw nsw i64 %179, 6
  %gep.112.3 = getelementptr double, ptr %invariant.gep.19, i64 %182
  %183 = load double, ptr %gep.112.3, align 8
  %184 = fmul double %181, %183
  %185 = fadd double %178, %184
  store double %185, ptr %155, align 8
  %186 = add nuw nsw i64 %157, 4
  %exitcond.113.not.3 = icmp eq i64 %186, 128
  br i1 %exitcond.113.not.3, label %187, label %156

187:                                              ; preds = %156
  %188 = add nuw nsw i64 %154, 1
  %exitcond6.114.not = icmp eq i64 %188, 64
  br i1 %exitcond6.114.not, label %.preheader3.1.1, label %.preheader.111

.preheader3.1.1:                                  ; preds = %187
  %189 = getelementptr double, ptr %15, i64 320
  %invariant.gep21 = getelementptr double, ptr %1, i64 640
  br label %.preheader.1.1

.preheader.1.1:                                   ; preds = %219, %.preheader3.1.1
  %190 = phi i64 [ 0, %.preheader3.1.1 ], [ %220, %219 ]
  %invariant.gep.1.1 = getelementptr double, ptr %8, i64 %190
  %191 = getelementptr double, ptr %189, i64 %190
  %.promoted.1.1 = load double, ptr %191, align 8
  br label %192

192:                                              ; preds = %192, %.preheader.1.1
  %193 = phi i64 [ 0, %.preheader.1.1 ], [ %218, %192 ]
  %194 = phi double [ %.promoted.1.1, %.preheader.1.1 ], [ %217, %192 ]
  %gep22 = getelementptr double, ptr %invariant.gep21, i64 %193
  %195 = load double, ptr %gep22, align 8
  %196 = shl nuw nsw i64 %193, 6
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1.1, i64 %196
  %197 = load double, ptr %gep.1.1, align 8
  %198 = fmul double %195, %197
  %199 = fadd double %194, %198
  store double %199, ptr %191, align 8
  %200 = or disjoint i64 %193, 1
  %gep22.1 = getelementptr double, ptr %invariant.gep21, i64 %200
  %201 = load double, ptr %gep22.1, align 8
  %202 = shl nuw nsw i64 %200, 6
  %gep.1.1.1 = getelementptr double, ptr %invariant.gep.1.1, i64 %202
  %203 = load double, ptr %gep.1.1.1, align 8
  %204 = fmul double %201, %203
  %205 = fadd double %199, %204
  store double %205, ptr %191, align 8
  %206 = or disjoint i64 %193, 2
  %gep22.2 = getelementptr double, ptr %invariant.gep21, i64 %206
  %207 = load double, ptr %gep22.2, align 8
  %208 = shl nuw nsw i64 %206, 6
  %gep.1.1.2 = getelementptr double, ptr %invariant.gep.1.1, i64 %208
  %209 = load double, ptr %gep.1.1.2, align 8
  %210 = fmul double %207, %209
  %211 = fadd double %205, %210
  store double %211, ptr %191, align 8
  %212 = or disjoint i64 %193, 3
  %gep22.3 = getelementptr double, ptr %invariant.gep21, i64 %212
  %213 = load double, ptr %gep22.3, align 8
  %214 = shl nuw nsw i64 %212, 6
  %gep.1.1.3 = getelementptr double, ptr %invariant.gep.1.1, i64 %214
  %215 = load double, ptr %gep.1.1.3, align 8
  %216 = fmul double %213, %215
  %217 = fadd double %211, %216
  store double %217, ptr %191, align 8
  %218 = add nuw nsw i64 %193, 4
  %exitcond.1.1.not.3 = icmp eq i64 %218, 128
  br i1 %exitcond.1.1.not.3, label %219, label %192

219:                                              ; preds = %192
  %220 = add nuw nsw i64 %190, 1
  %exitcond6.1.1.not = icmp eq i64 %220, 64
  br i1 %exitcond6.1.1.not, label %.preheader3.2.1, label %.preheader.1.1

.preheader3.2.1:                                  ; preds = %219
  %221 = getelementptr double, ptr %15, i64 384
  %invariant.gep23 = getelementptr double, ptr %1, i64 768
  br label %.preheader.2.1

.preheader.2.1:                                   ; preds = %251, %.preheader3.2.1
  %222 = phi i64 [ 0, %.preheader3.2.1 ], [ %252, %251 ]
  %invariant.gep.2.1 = getelementptr double, ptr %8, i64 %222
  %223 = getelementptr double, ptr %221, i64 %222
  %.promoted.2.1 = load double, ptr %223, align 8
  br label %224

224:                                              ; preds = %224, %.preheader.2.1
  %225 = phi i64 [ 0, %.preheader.2.1 ], [ %250, %224 ]
  %226 = phi double [ %.promoted.2.1, %.preheader.2.1 ], [ %249, %224 ]
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %225
  %227 = load double, ptr %gep24, align 8
  %228 = shl nuw nsw i64 %225, 6
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2.1, i64 %228
  %229 = load double, ptr %gep.2.1, align 8
  %230 = fmul double %227, %229
  %231 = fadd double %226, %230
  store double %231, ptr %223, align 8
  %232 = or disjoint i64 %225, 1
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %232
  %233 = load double, ptr %gep24.1, align 8
  %234 = shl nuw nsw i64 %232, 6
  %gep.2.1.1 = getelementptr double, ptr %invariant.gep.2.1, i64 %234
  %235 = load double, ptr %gep.2.1.1, align 8
  %236 = fmul double %233, %235
  %237 = fadd double %231, %236
  store double %237, ptr %223, align 8
  %238 = or disjoint i64 %225, 2
  %gep24.2 = getelementptr double, ptr %invariant.gep23, i64 %238
  %239 = load double, ptr %gep24.2, align 8
  %240 = shl nuw nsw i64 %238, 6
  %gep.2.1.2 = getelementptr double, ptr %invariant.gep.2.1, i64 %240
  %241 = load double, ptr %gep.2.1.2, align 8
  %242 = fmul double %239, %241
  %243 = fadd double %237, %242
  store double %243, ptr %223, align 8
  %244 = or disjoint i64 %225, 3
  %gep24.3 = getelementptr double, ptr %invariant.gep23, i64 %244
  %245 = load double, ptr %gep24.3, align 8
  %246 = shl nuw nsw i64 %244, 6
  %gep.2.1.3 = getelementptr double, ptr %invariant.gep.2.1, i64 %246
  %247 = load double, ptr %gep.2.1.3, align 8
  %248 = fmul double %245, %247
  %249 = fadd double %243, %248
  store double %249, ptr %223, align 8
  %250 = add nuw nsw i64 %225, 4
  %exitcond.2.1.not.3 = icmp eq i64 %250, 128
  br i1 %exitcond.2.1.not.3, label %251, label %224

251:                                              ; preds = %224
  %252 = add nuw nsw i64 %222, 1
  %exitcond6.2.1.not = icmp eq i64 %252, 64
  br i1 %exitcond6.2.1.not, label %.preheader3.3.1, label %.preheader.2.1

.preheader3.3.1:                                  ; preds = %251
  %253 = getelementptr double, ptr %15, i64 448
  %invariant.gep25 = getelementptr double, ptr %1, i64 896
  br label %.preheader.3.1

.preheader.3.1:                                   ; preds = %283, %.preheader3.3.1
  %254 = phi i64 [ 0, %.preheader3.3.1 ], [ %284, %283 ]
  %invariant.gep.3.1 = getelementptr double, ptr %8, i64 %254
  %255 = getelementptr double, ptr %253, i64 %254
  %.promoted.3.1 = load double, ptr %255, align 8
  br label %256

256:                                              ; preds = %256, %.preheader.3.1
  %257 = phi i64 [ 0, %.preheader.3.1 ], [ %282, %256 ]
  %258 = phi double [ %.promoted.3.1, %.preheader.3.1 ], [ %281, %256 ]
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %257
  %259 = load double, ptr %gep26, align 8
  %260 = shl nuw nsw i64 %257, 6
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3.1, i64 %260
  %261 = load double, ptr %gep.3.1, align 8
  %262 = fmul double %259, %261
  %263 = fadd double %258, %262
  store double %263, ptr %255, align 8
  %264 = or disjoint i64 %257, 1
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %264
  %265 = load double, ptr %gep26.1, align 8
  %266 = shl nuw nsw i64 %264, 6
  %gep.3.1.1 = getelementptr double, ptr %invariant.gep.3.1, i64 %266
  %267 = load double, ptr %gep.3.1.1, align 8
  %268 = fmul double %265, %267
  %269 = fadd double %263, %268
  store double %269, ptr %255, align 8
  %270 = or disjoint i64 %257, 2
  %gep26.2 = getelementptr double, ptr %invariant.gep25, i64 %270
  %271 = load double, ptr %gep26.2, align 8
  %272 = shl nuw nsw i64 %270, 6
  %gep.3.1.2 = getelementptr double, ptr %invariant.gep.3.1, i64 %272
  %273 = load double, ptr %gep.3.1.2, align 8
  %274 = fmul double %271, %273
  %275 = fadd double %269, %274
  store double %275, ptr %255, align 8
  %276 = or disjoint i64 %257, 3
  %gep26.3 = getelementptr double, ptr %invariant.gep25, i64 %276
  %277 = load double, ptr %gep26.3, align 8
  %278 = shl nuw nsw i64 %276, 6
  %gep.3.1.3 = getelementptr double, ptr %invariant.gep.3.1, i64 %278
  %279 = load double, ptr %gep.3.1.3, align 8
  %280 = fmul double %277, %279
  %281 = fadd double %275, %280
  store double %281, ptr %255, align 8
  %282 = add nuw nsw i64 %257, 4
  %exitcond.3.1.not.3 = icmp eq i64 %282, 128
  br i1 %exitcond.3.1.not.3, label %283, label %256

283:                                              ; preds = %256
  %284 = add nuw nsw i64 %254, 1
  %exitcond6.3.1.not = icmp eq i64 %284, 64
  br i1 %exitcond6.3.1.not, label %285, label %.preheader.3.1

285:                                              ; preds = %283
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
