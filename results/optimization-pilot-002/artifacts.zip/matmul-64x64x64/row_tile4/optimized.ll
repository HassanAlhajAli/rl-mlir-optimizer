; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %180
  %21 = phi i64 [ %181, %180 ], [ 0, %.preheader4.preheader ]
  %22 = shl nuw nsw i64 %21, 6
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = getelementptr double, ptr %15, i64 %22
  br label %.preheader

.preheader:                                       ; preds = %.preheader4, %58
  %25 = phi i64 [ 0, %.preheader4 ], [ %59, %58 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %25
  %26 = getelementptr double, ptr %24, i64 %25
  %.promoted = load double, ptr %26, align 8
  br label %27

27:                                               ; preds = %27, %.preheader
  %28 = phi i64 [ 0, %.preheader ], [ %57, %27 ]
  %29 = phi double [ %.promoted, %.preheader ], [ %56, %27 ]
  %30 = getelementptr double, ptr %23, i64 %28
  %31 = load double, ptr %30, align 8
  %32 = shl nuw nsw i64 %28, 6
  %gep = getelementptr double, ptr %invariant.gep, i64 %32
  %33 = load double, ptr %gep, align 8
  %34 = fmul double %31, %33
  %35 = fadd double %29, %34
  store double %35, ptr %26, align 8
  %36 = or disjoint i64 %28, 1
  %37 = getelementptr double, ptr %23, i64 %36
  %38 = load double, ptr %37, align 8
  %39 = shl nuw nsw i64 %36, 6
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 %39
  %40 = load double, ptr %gep.18, align 8
  %41 = fmul double %38, %40
  %42 = fadd double %35, %41
  store double %42, ptr %26, align 8
  %43 = or disjoint i64 %28, 2
  %44 = getelementptr double, ptr %23, i64 %43
  %45 = load double, ptr %44, align 8
  %46 = shl nuw nsw i64 %43, 6
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 %46
  %47 = load double, ptr %gep.29, align 8
  %48 = fmul double %45, %47
  %49 = fadd double %42, %48
  store double %49, ptr %26, align 8
  %50 = or disjoint i64 %28, 3
  %51 = getelementptr double, ptr %23, i64 %50
  %52 = load double, ptr %51, align 8
  %53 = shl nuw nsw i64 %50, 6
  %gep.310 = getelementptr double, ptr %invariant.gep, i64 %53
  %54 = load double, ptr %gep.310, align 8
  %55 = fmul double %52, %54
  %56 = fadd double %49, %55
  store double %56, ptr %26, align 8
  %57 = add nuw nsw i64 %28, 4
  %exitcond.not.3 = icmp eq i64 %57, 64
  br i1 %exitcond.not.3, label %58, label %27

58:                                               ; preds = %27
  %59 = add nuw nsw i64 %25, 1
  %exitcond6.not = icmp eq i64 %59, 64
  br i1 %exitcond6.not, label %.preheader3.1, label %.preheader

.preheader3.1:                                    ; preds = %58
  %60 = getelementptr double, ptr %24, i64 64
  br label %.preheader.1

.preheader.1:                                     ; preds = %98, %.preheader3.1
  %61 = phi i64 [ 0, %.preheader3.1 ], [ %99, %98 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %61
  %62 = getelementptr double, ptr %60, i64 %61
  %.promoted.1 = load double, ptr %62, align 8
  br label %63

63:                                               ; preds = %63, %.preheader.1
  %64 = phi i64 [ 0, %.preheader.1 ], [ %97, %63 ]
  %65 = phi double [ %.promoted.1, %.preheader.1 ], [ %96, %63 ]
  %66 = or disjoint i64 %64, 64
  %67 = getelementptr double, ptr %23, i64 %66
  %68 = load double, ptr %67, align 8
  %69 = shl nuw nsw i64 %64, 6
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %69
  %70 = load double, ptr %gep.1, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %65, %71
  store double %72, ptr %62, align 8
  %73 = or i64 %64, 65
  %74 = getelementptr double, ptr %23, i64 %73
  %75 = load double, ptr %74, align 8
  %76 = shl i64 %64, 6
  %77 = or disjoint i64 %76, 64
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %77
  %78 = load double, ptr %gep.1.1, align 8
  %79 = fmul double %75, %78
  %80 = fadd double %72, %79
  store double %80, ptr %62, align 8
  %81 = or i64 %64, 66
  %82 = getelementptr double, ptr %23, i64 %81
  %83 = load double, ptr %82, align 8
  %84 = shl i64 %64, 6
  %85 = or disjoint i64 %84, 128
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %85
  %86 = load double, ptr %gep.1.2, align 8
  %87 = fmul double %83, %86
  %88 = fadd double %80, %87
  store double %88, ptr %62, align 8
  %89 = or i64 %64, 67
  %90 = getelementptr double, ptr %23, i64 %89
  %91 = load double, ptr %90, align 8
  %92 = shl i64 %64, 6
  %93 = or disjoint i64 %92, 192
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %93
  %94 = load double, ptr %gep.1.3, align 8
  %95 = fmul double %91, %94
  %96 = fadd double %88, %95
  store double %96, ptr %62, align 8
  %97 = add nuw nsw i64 %64, 4
  %exitcond.1.not.3 = icmp eq i64 %97, 64
  br i1 %exitcond.1.not.3, label %98, label %63

98:                                               ; preds = %63
  %99 = add nuw nsw i64 %61, 1
  %exitcond6.1.not = icmp eq i64 %99, 64
  br i1 %exitcond6.1.not, label %.preheader3.2, label %.preheader.1

.preheader3.2:                                    ; preds = %98
  %100 = getelementptr double, ptr %24, i64 128
  br label %.preheader.2

.preheader.2:                                     ; preds = %138, %.preheader3.2
  %101 = phi i64 [ 0, %.preheader3.2 ], [ %139, %138 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %101
  %102 = getelementptr double, ptr %100, i64 %101
  %.promoted.2 = load double, ptr %102, align 8
  br label %103

103:                                              ; preds = %103, %.preheader.2
  %104 = phi i64 [ 0, %.preheader.2 ], [ %137, %103 ]
  %105 = phi double [ %.promoted.2, %.preheader.2 ], [ %136, %103 ]
  %106 = or disjoint i64 %104, 128
  %107 = getelementptr double, ptr %23, i64 %106
  %108 = load double, ptr %107, align 8
  %109 = shl nuw nsw i64 %104, 6
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %109
  %110 = load double, ptr %gep.2, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %105, %111
  store double %112, ptr %102, align 8
  %113 = or i64 %104, 129
  %114 = getelementptr double, ptr %23, i64 %113
  %115 = load double, ptr %114, align 8
  %116 = shl i64 %104, 6
  %117 = or disjoint i64 %116, 64
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %117
  %118 = load double, ptr %gep.2.1, align 8
  %119 = fmul double %115, %118
  %120 = fadd double %112, %119
  store double %120, ptr %102, align 8
  %121 = or i64 %104, 130
  %122 = getelementptr double, ptr %23, i64 %121
  %123 = load double, ptr %122, align 8
  %124 = shl i64 %104, 6
  %125 = or disjoint i64 %124, 128
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %125
  %126 = load double, ptr %gep.2.2, align 8
  %127 = fmul double %123, %126
  %128 = fadd double %120, %127
  store double %128, ptr %102, align 8
  %129 = or i64 %104, 131
  %130 = getelementptr double, ptr %23, i64 %129
  %131 = load double, ptr %130, align 8
  %132 = shl i64 %104, 6
  %133 = or disjoint i64 %132, 192
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %133
  %134 = load double, ptr %gep.2.3, align 8
  %135 = fmul double %131, %134
  %136 = fadd double %128, %135
  store double %136, ptr %102, align 8
  %137 = add nuw nsw i64 %104, 4
  %exitcond.2.not.3 = icmp eq i64 %137, 64
  br i1 %exitcond.2.not.3, label %138, label %103

138:                                              ; preds = %103
  %139 = add nuw nsw i64 %101, 1
  %exitcond6.2.not = icmp eq i64 %139, 64
  br i1 %exitcond6.2.not, label %.preheader3.3, label %.preheader.2

.preheader3.3:                                    ; preds = %138
  %140 = getelementptr double, ptr %24, i64 192
  br label %.preheader.3

.preheader.3:                                     ; preds = %178, %.preheader3.3
  %141 = phi i64 [ 0, %.preheader3.3 ], [ %179, %178 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %141
  %142 = getelementptr double, ptr %140, i64 %141
  %.promoted.3 = load double, ptr %142, align 8
  br label %143

143:                                              ; preds = %143, %.preheader.3
  %144 = phi i64 [ 0, %.preheader.3 ], [ %177, %143 ]
  %145 = phi double [ %.promoted.3, %.preheader.3 ], [ %176, %143 ]
  %146 = or disjoint i64 %144, 192
  %147 = getelementptr double, ptr %23, i64 %146
  %148 = load double, ptr %147, align 8
  %149 = shl nuw nsw i64 %144, 6
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %149
  %150 = load double, ptr %gep.3, align 8
  %151 = fmul double %148, %150
  %152 = fadd double %145, %151
  store double %152, ptr %142, align 8
  %153 = or i64 %144, 193
  %154 = getelementptr double, ptr %23, i64 %153
  %155 = load double, ptr %154, align 8
  %156 = shl i64 %144, 6
  %157 = or disjoint i64 %156, 64
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %157
  %158 = load double, ptr %gep.3.1, align 8
  %159 = fmul double %155, %158
  %160 = fadd double %152, %159
  store double %160, ptr %142, align 8
  %161 = or i64 %144, 194
  %162 = getelementptr double, ptr %23, i64 %161
  %163 = load double, ptr %162, align 8
  %164 = shl i64 %144, 6
  %165 = or disjoint i64 %164, 128
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %165
  %166 = load double, ptr %gep.3.2, align 8
  %167 = fmul double %163, %166
  %168 = fadd double %160, %167
  store double %168, ptr %142, align 8
  %169 = or i64 %144, 195
  %170 = getelementptr double, ptr %23, i64 %169
  %171 = load double, ptr %170, align 8
  %172 = shl i64 %144, 6
  %173 = or disjoint i64 %172, 192
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %173
  %174 = load double, ptr %gep.3.3, align 8
  %175 = fmul double %171, %174
  %176 = fadd double %168, %175
  store double %176, ptr %142, align 8
  %177 = add nuw nsw i64 %144, 4
  %exitcond.3.not.3 = icmp eq i64 %177, 64
  br i1 %exitcond.3.not.3, label %178, label %143

178:                                              ; preds = %143
  %179 = add nuw nsw i64 %141, 1
  %exitcond6.3.not = icmp eq i64 %179, 64
  br i1 %exitcond6.3.not, label %180, label %.preheader.3

180:                                              ; preds = %178
  %181 = add nuw nsw i64 %21, 4
  %182 = icmp ult i64 %21, 60
  br i1 %182, label %.preheader4, label %183

183:                                              ; preds = %180
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  br label %.preheader4.i

.preheader4.i:                                    ; preds = %163, %3
  %4 = phi i64 [ %164, %163 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 6
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %7 = getelementptr double, ptr %.unpack32, i64 %5
  br label %.preheader.i

.preheader.i:                                     ; preds = %41, %.preheader4.i
  %8 = phi i64 [ 0, %.preheader4.i ], [ %42, %41 ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %8
  %9 = getelementptr double, ptr %7, i64 %8
  %.promoted.i = load double, ptr %9, align 8
  br label %10

10:                                               ; preds = %10, %.preheader.i
  %11 = phi i64 [ 0, %.preheader.i ], [ %40, %10 ]
  %12 = phi double [ %.promoted.i, %.preheader.i ], [ %39, %10 ]
  %13 = getelementptr double, ptr %6, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = shl nuw nsw i64 %11, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %16 = load double, ptr %gep.i, align 8
  %17 = fmul double %14, %16
  %18 = fadd double %12, %17
  store double %18, ptr %9, align 8
  %19 = or disjoint i64 %11, 1
  %20 = getelementptr double, ptr %6, i64 %19
  %21 = load double, ptr %20, align 8
  %22 = shl nuw nsw i64 %19, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %22
  %23 = load double, ptr %gep.i.1, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %18, %24
  store double %25, ptr %9, align 8
  %26 = or disjoint i64 %11, 2
  %27 = getelementptr double, ptr %6, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = shl nuw nsw i64 %26, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %29
  %30 = load double, ptr %gep.i.2, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %9, align 8
  %33 = or disjoint i64 %11, 3
  %34 = getelementptr double, ptr %6, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = shl nuw nsw i64 %33, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %36
  %37 = load double, ptr %gep.i.3, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %9, align 8
  %40 = add nuw nsw i64 %11, 4
  %exitcond.not.i.3 = icmp eq i64 %40, 64
  br i1 %exitcond.not.i.3, label %41, label %10

41:                                               ; preds = %10
  %42 = add nuw nsw i64 %8, 1
  %exitcond6.not.i = icmp eq i64 %42, 64
  br i1 %exitcond6.not.i, label %.preheader3.1.i, label %.preheader.i

.preheader3.1.i:                                  ; preds = %41
  %43 = getelementptr double, ptr %7, i64 64
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %81, %.preheader3.1.i
  %44 = phi i64 [ 0, %.preheader3.1.i ], [ %82, %81 ]
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 %44
  %45 = getelementptr double, ptr %43, i64 %44
  %.promoted.1.i = load double, ptr %45, align 8
  br label %46

46:                                               ; preds = %46, %.preheader.1.i
  %47 = phi i64 [ 0, %.preheader.1.i ], [ %80, %46 ]
  %48 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %79, %46 ]
  %49 = or disjoint i64 %47, 64
  %50 = getelementptr double, ptr %6, i64 %49
  %51 = load double, ptr %50, align 8
  %52 = shl nuw nsw i64 %47, 6
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %52
  %53 = load double, ptr %gep.1.i, align 8
  %54 = fmul double %51, %53
  %55 = fadd double %48, %54
  store double %55, ptr %45, align 8
  %56 = or i64 %47, 65
  %57 = getelementptr double, ptr %6, i64 %56
  %58 = load double, ptr %57, align 8
  %59 = shl i64 %47, 6
  %60 = or disjoint i64 %59, 64
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %60
  %61 = load double, ptr %gep.1.i.1, align 8
  %62 = fmul double %58, %61
  %63 = fadd double %55, %62
  store double %63, ptr %45, align 8
  %64 = or i64 %47, 66
  %65 = getelementptr double, ptr %6, i64 %64
  %66 = load double, ptr %65, align 8
  %67 = shl i64 %47, 6
  %68 = or disjoint i64 %67, 128
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %68
  %69 = load double, ptr %gep.1.i.2, align 8
  %70 = fmul double %66, %69
  %71 = fadd double %63, %70
  store double %71, ptr %45, align 8
  %72 = or i64 %47, 67
  %73 = getelementptr double, ptr %6, i64 %72
  %74 = load double, ptr %73, align 8
  %75 = shl i64 %47, 6
  %76 = or disjoint i64 %75, 192
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %76
  %77 = load double, ptr %gep.1.i.3, align 8
  %78 = fmul double %74, %77
  %79 = fadd double %71, %78
  store double %79, ptr %45, align 8
  %80 = add nuw nsw i64 %47, 4
  %exitcond.1.not.i.3 = icmp eq i64 %80, 64
  br i1 %exitcond.1.not.i.3, label %81, label %46

81:                                               ; preds = %46
  %82 = add nuw nsw i64 %44, 1
  %exitcond6.1.not.i = icmp eq i64 %82, 64
  br i1 %exitcond6.1.not.i, label %.preheader3.2.i, label %.preheader.1.i

.preheader3.2.i:                                  ; preds = %81
  %83 = getelementptr double, ptr %7, i64 128
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %121, %.preheader3.2.i
  %84 = phi i64 [ 0, %.preheader3.2.i ], [ %122, %121 ]
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 %84
  %85 = getelementptr double, ptr %83, i64 %84
  %.promoted.2.i = load double, ptr %85, align 8
  br label %86

86:                                               ; preds = %86, %.preheader.2.i
  %87 = phi i64 [ 0, %.preheader.2.i ], [ %120, %86 ]
  %88 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %119, %86 ]
  %89 = or disjoint i64 %87, 128
  %90 = getelementptr double, ptr %6, i64 %89
  %91 = load double, ptr %90, align 8
  %92 = shl nuw nsw i64 %87, 6
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %92
  %93 = load double, ptr %gep.2.i, align 8
  %94 = fmul double %91, %93
  %95 = fadd double %88, %94
  store double %95, ptr %85, align 8
  %96 = or i64 %87, 129
  %97 = getelementptr double, ptr %6, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = shl i64 %87, 6
  %100 = or disjoint i64 %99, 64
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %100
  %101 = load double, ptr %gep.2.i.1, align 8
  %102 = fmul double %98, %101
  %103 = fadd double %95, %102
  store double %103, ptr %85, align 8
  %104 = or i64 %87, 130
  %105 = getelementptr double, ptr %6, i64 %104
  %106 = load double, ptr %105, align 8
  %107 = shl i64 %87, 6
  %108 = or disjoint i64 %107, 128
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %108
  %109 = load double, ptr %gep.2.i.2, align 8
  %110 = fmul double %106, %109
  %111 = fadd double %103, %110
  store double %111, ptr %85, align 8
  %112 = or i64 %87, 131
  %113 = getelementptr double, ptr %6, i64 %112
  %114 = load double, ptr %113, align 8
  %115 = shl i64 %87, 6
  %116 = or disjoint i64 %115, 192
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %116
  %117 = load double, ptr %gep.2.i.3, align 8
  %118 = fmul double %114, %117
  %119 = fadd double %111, %118
  store double %119, ptr %85, align 8
  %120 = add nuw nsw i64 %87, 4
  %exitcond.2.not.i.3 = icmp eq i64 %120, 64
  br i1 %exitcond.2.not.i.3, label %121, label %86

121:                                              ; preds = %86
  %122 = add nuw nsw i64 %84, 1
  %exitcond6.2.not.i = icmp eq i64 %122, 64
  br i1 %exitcond6.2.not.i, label %.preheader3.3.i, label %.preheader.2.i

.preheader3.3.i:                                  ; preds = %121
  %123 = getelementptr double, ptr %7, i64 192
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %161, %.preheader3.3.i
  %124 = phi i64 [ 0, %.preheader3.3.i ], [ %162, %161 ]
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 %124
  %125 = getelementptr double, ptr %123, i64 %124
  %.promoted.3.i = load double, ptr %125, align 8
  br label %126

126:                                              ; preds = %126, %.preheader.3.i
  %127 = phi i64 [ 0, %.preheader.3.i ], [ %160, %126 ]
  %128 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %159, %126 ]
  %129 = or disjoint i64 %127, 192
  %130 = getelementptr double, ptr %6, i64 %129
  %131 = load double, ptr %130, align 8
  %132 = shl nuw nsw i64 %127, 6
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %132
  %133 = load double, ptr %gep.3.i, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %128, %134
  store double %135, ptr %125, align 8
  %136 = or i64 %127, 193
  %137 = getelementptr double, ptr %6, i64 %136
  %138 = load double, ptr %137, align 8
  %139 = shl i64 %127, 6
  %140 = or disjoint i64 %139, 64
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %140
  %141 = load double, ptr %gep.3.i.1, align 8
  %142 = fmul double %138, %141
  %143 = fadd double %135, %142
  store double %143, ptr %125, align 8
  %144 = or i64 %127, 194
  %145 = getelementptr double, ptr %6, i64 %144
  %146 = load double, ptr %145, align 8
  %147 = shl i64 %127, 6
  %148 = or disjoint i64 %147, 128
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %148
  %149 = load double, ptr %gep.3.i.2, align 8
  %150 = fmul double %146, %149
  %151 = fadd double %143, %150
  store double %151, ptr %125, align 8
  %152 = or i64 %127, 195
  %153 = getelementptr double, ptr %6, i64 %152
  %154 = load double, ptr %153, align 8
  %155 = shl i64 %127, 6
  %156 = or disjoint i64 %155, 192
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %156
  %157 = load double, ptr %gep.3.i.3, align 8
  %158 = fmul double %154, %157
  %159 = fadd double %151, %158
  store double %159, ptr %125, align 8
  %160 = add nuw nsw i64 %127, 4
  %exitcond.3.not.i.3 = icmp eq i64 %160, 64
  br i1 %exitcond.3.not.i.3, label %161, label %126

161:                                              ; preds = %126
  %162 = add nuw nsw i64 %124, 1
  %exitcond6.3.not.i = icmp eq i64 %162, 64
  br i1 %exitcond6.3.not.i, label %163, label %.preheader.3.i

163:                                              ; preds = %161
  %164 = add nuw nsw i64 %4, 4
  %165 = icmp ult i64 %4, 60
  br i1 %165, label %.preheader4.i, label %kernel.exit

kernel.exit:                                      ; preds = %163
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  br label %.preheader4.i

.preheader4.i:                                    ; preds = %170, %1
  %11 = phi i64 [ %171, %170 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 6
  %13 = getelementptr double, ptr %4, i64 %12
  %14 = getelementptr double, ptr %10, i64 %12
  br label %.preheader.i

.preheader.i:                                     ; preds = %48, %.preheader4.i
  %15 = phi i64 [ 0, %.preheader4.i ], [ %49, %48 ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %15
  %16 = getelementptr double, ptr %14, i64 %15
  %.promoted.i = load double, ptr %16, align 8
  br label %17

17:                                               ; preds = %17, %.preheader.i
  %18 = phi i64 [ 0, %.preheader.i ], [ %47, %17 ]
  %19 = phi double [ %.promoted.i, %.preheader.i ], [ %46, %17 ]
  %20 = getelementptr double, ptr %13, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = shl nuw nsw i64 %18, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %22
  %23 = load double, ptr %gep.i, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %16, align 8
  %26 = or disjoint i64 %18, 1
  %27 = getelementptr double, ptr %13, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = shl nuw nsw i64 %26, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %29
  %30 = load double, ptr %gep.i.1, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %16, align 8
  %33 = or disjoint i64 %18, 2
  %34 = getelementptr double, ptr %13, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = shl nuw nsw i64 %33, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %36
  %37 = load double, ptr %gep.i.2, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %16, align 8
  %40 = or disjoint i64 %18, 3
  %41 = getelementptr double, ptr %13, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = shl nuw nsw i64 %40, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %43
  %44 = load double, ptr %gep.i.3, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %16, align 8
  %47 = add nuw nsw i64 %18, 4
  %exitcond.not.i.3 = icmp eq i64 %47, 64
  br i1 %exitcond.not.i.3, label %48, label %17

48:                                               ; preds = %17
  %49 = add nuw nsw i64 %15, 1
  %exitcond6.not.i = icmp eq i64 %49, 64
  br i1 %exitcond6.not.i, label %.preheader3.1.i, label %.preheader.i

.preheader3.1.i:                                  ; preds = %48
  %50 = getelementptr double, ptr %14, i64 64
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %88, %.preheader3.1.i
  %51 = phi i64 [ 0, %.preheader3.1.i ], [ %89, %88 ]
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 %51
  %52 = getelementptr double, ptr %50, i64 %51
  %.promoted.1.i = load double, ptr %52, align 8
  br label %53

53:                                               ; preds = %53, %.preheader.1.i
  %54 = phi i64 [ 0, %.preheader.1.i ], [ %87, %53 ]
  %55 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %86, %53 ]
  %56 = or disjoint i64 %54, 64
  %57 = getelementptr double, ptr %13, i64 %56
  %58 = load double, ptr %57, align 8
  %59 = shl nuw nsw i64 %54, 6
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %59
  %60 = load double, ptr %gep.1.i, align 8
  %61 = fmul double %58, %60
  %62 = fadd double %55, %61
  store double %62, ptr %52, align 8
  %63 = or i64 %54, 65
  %64 = getelementptr double, ptr %13, i64 %63
  %65 = load double, ptr %64, align 8
  %66 = shl i64 %54, 6
  %67 = or disjoint i64 %66, 64
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %67
  %68 = load double, ptr %gep.1.i.1, align 8
  %69 = fmul double %65, %68
  %70 = fadd double %62, %69
  store double %70, ptr %52, align 8
  %71 = or i64 %54, 66
  %72 = getelementptr double, ptr %13, i64 %71
  %73 = load double, ptr %72, align 8
  %74 = shl i64 %54, 6
  %75 = or disjoint i64 %74, 128
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %75
  %76 = load double, ptr %gep.1.i.2, align 8
  %77 = fmul double %73, %76
  %78 = fadd double %70, %77
  store double %78, ptr %52, align 8
  %79 = or i64 %54, 67
  %80 = getelementptr double, ptr %13, i64 %79
  %81 = load double, ptr %80, align 8
  %82 = shl i64 %54, 6
  %83 = or disjoint i64 %82, 192
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %83
  %84 = load double, ptr %gep.1.i.3, align 8
  %85 = fmul double %81, %84
  %86 = fadd double %78, %85
  store double %86, ptr %52, align 8
  %87 = add nuw nsw i64 %54, 4
  %exitcond.1.not.i.3 = icmp eq i64 %87, 64
  br i1 %exitcond.1.not.i.3, label %88, label %53

88:                                               ; preds = %53
  %89 = add nuw nsw i64 %51, 1
  %exitcond6.1.not.i = icmp eq i64 %89, 64
  br i1 %exitcond6.1.not.i, label %.preheader3.2.i, label %.preheader.1.i

.preheader3.2.i:                                  ; preds = %88
  %90 = getelementptr double, ptr %14, i64 128
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %128, %.preheader3.2.i
  %91 = phi i64 [ 0, %.preheader3.2.i ], [ %129, %128 ]
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 %91
  %92 = getelementptr double, ptr %90, i64 %91
  %.promoted.2.i = load double, ptr %92, align 8
  br label %93

93:                                               ; preds = %93, %.preheader.2.i
  %94 = phi i64 [ 0, %.preheader.2.i ], [ %127, %93 ]
  %95 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %126, %93 ]
  %96 = or disjoint i64 %94, 128
  %97 = getelementptr double, ptr %13, i64 %96
  %98 = load double, ptr %97, align 8
  %99 = shl nuw nsw i64 %94, 6
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %99
  %100 = load double, ptr %gep.2.i, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %95, %101
  store double %102, ptr %92, align 8
  %103 = or i64 %94, 129
  %104 = getelementptr double, ptr %13, i64 %103
  %105 = load double, ptr %104, align 8
  %106 = shl i64 %94, 6
  %107 = or disjoint i64 %106, 64
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %107
  %108 = load double, ptr %gep.2.i.1, align 8
  %109 = fmul double %105, %108
  %110 = fadd double %102, %109
  store double %110, ptr %92, align 8
  %111 = or i64 %94, 130
  %112 = getelementptr double, ptr %13, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = shl i64 %94, 6
  %115 = or disjoint i64 %114, 128
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %115
  %116 = load double, ptr %gep.2.i.2, align 8
  %117 = fmul double %113, %116
  %118 = fadd double %110, %117
  store double %118, ptr %92, align 8
  %119 = or i64 %94, 131
  %120 = getelementptr double, ptr %13, i64 %119
  %121 = load double, ptr %120, align 8
  %122 = shl i64 %94, 6
  %123 = or disjoint i64 %122, 192
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %123
  %124 = load double, ptr %gep.2.i.3, align 8
  %125 = fmul double %121, %124
  %126 = fadd double %118, %125
  store double %126, ptr %92, align 8
  %127 = add nuw nsw i64 %94, 4
  %exitcond.2.not.i.3 = icmp eq i64 %127, 64
  br i1 %exitcond.2.not.i.3, label %128, label %93

128:                                              ; preds = %93
  %129 = add nuw nsw i64 %91, 1
  %exitcond6.2.not.i = icmp eq i64 %129, 64
  br i1 %exitcond6.2.not.i, label %.preheader3.3.i, label %.preheader.2.i

.preheader3.3.i:                                  ; preds = %128
  %130 = getelementptr double, ptr %14, i64 192
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %168, %.preheader3.3.i
  %131 = phi i64 [ 0, %.preheader3.3.i ], [ %169, %168 ]
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 %131
  %132 = getelementptr double, ptr %130, i64 %131
  %.promoted.3.i = load double, ptr %132, align 8
  br label %133

133:                                              ; preds = %133, %.preheader.3.i
  %134 = phi i64 [ 0, %.preheader.3.i ], [ %167, %133 ]
  %135 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %166, %133 ]
  %136 = or disjoint i64 %134, 192
  %137 = getelementptr double, ptr %13, i64 %136
  %138 = load double, ptr %137, align 8
  %139 = shl nuw nsw i64 %134, 6
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %139
  %140 = load double, ptr %gep.3.i, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %135, %141
  store double %142, ptr %132, align 8
  %143 = or i64 %134, 193
  %144 = getelementptr double, ptr %13, i64 %143
  %145 = load double, ptr %144, align 8
  %146 = shl i64 %134, 6
  %147 = or disjoint i64 %146, 64
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %147
  %148 = load double, ptr %gep.3.i.1, align 8
  %149 = fmul double %145, %148
  %150 = fadd double %142, %149
  store double %150, ptr %132, align 8
  %151 = or i64 %134, 194
  %152 = getelementptr double, ptr %13, i64 %151
  %153 = load double, ptr %152, align 8
  %154 = shl i64 %134, 6
  %155 = or disjoint i64 %154, 128
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %155
  %156 = load double, ptr %gep.3.i.2, align 8
  %157 = fmul double %153, %156
  %158 = fadd double %150, %157
  store double %158, ptr %132, align 8
  %159 = or i64 %134, 195
  %160 = getelementptr double, ptr %13, i64 %159
  %161 = load double, ptr %160, align 8
  %162 = shl i64 %134, 6
  %163 = or disjoint i64 %162, 192
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %163
  %164 = load double, ptr %gep.3.i.3, align 8
  %165 = fmul double %161, %164
  %166 = fadd double %158, %165
  store double %166, ptr %132, align 8
  %167 = add nuw nsw i64 %134, 4
  %exitcond.3.not.i.3 = icmp eq i64 %167, 64
  br i1 %exitcond.3.not.i.3, label %168, label %133

168:                                              ; preds = %133
  %169 = add nuw nsw i64 %131, 1
  %exitcond6.3.not.i = icmp eq i64 %169, 64
  br i1 %exitcond6.3.not.i, label %170, label %.preheader.3.i

170:                                              ; preds = %168
  %171 = add nuw nsw i64 %11, 4
  %172 = icmp ult i64 %11, 60
  br i1 %172, label %.preheader4.i, label %kernel.exit

kernel.exit:                                      ; preds = %170
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
