; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %63
  %21 = phi i64 [ %64, %63 ], [ 0, %.preheader2.preheader ]
  %22 = shl i64 %21, 6
  %23 = getelementptr double, ptr %15, i64 %22
  br label %.preheader

.preheader:                                       ; preds = %.preheader2, %61
  %24 = phi i64 [ 0, %.preheader2 ], [ %62, %61 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %24
  %25 = getelementptr double, ptr %23, i64 %24
  %.promoted = load double, ptr %25, align 8
  br label %26

26:                                               ; preds = %26, %.preheader
  %27 = phi i64 [ 0, %.preheader ], [ %60, %26 ]
  %28 = phi double [ %.promoted, %.preheader ], [ %59, %26 ]
  %29 = or disjoint i64 %27, %22
  %30 = getelementptr double, ptr %1, i64 %29
  %31 = load double, ptr %30, align 8
  %32 = shl nuw nsw i64 %27, 6
  %gep = getelementptr double, ptr %invariant.gep, i64 %32
  %33 = load double, ptr %gep, align 8
  %34 = fmul double %31, %33
  %35 = fadd double %28, %34
  store double %35, ptr %25, align 8
  %36 = or disjoint i64 %27, 1
  %37 = or disjoint i64 %36, %22
  %38 = getelementptr double, ptr %1, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = shl nuw nsw i64 %36, 6
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %40
  %41 = load double, ptr %gep.1, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %35, %42
  store double %43, ptr %25, align 8
  %44 = or disjoint i64 %27, 2
  %45 = or disjoint i64 %44, %22
  %46 = getelementptr double, ptr %1, i64 %45
  %47 = load double, ptr %46, align 8
  %48 = shl nuw nsw i64 %44, 6
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %48
  %49 = load double, ptr %gep.2, align 8
  %50 = fmul double %47, %49
  %51 = fadd double %43, %50
  store double %51, ptr %25, align 8
  %52 = or disjoint i64 %27, 3
  %53 = or disjoint i64 %52, %22
  %54 = getelementptr double, ptr %1, i64 %53
  %55 = load double, ptr %54, align 8
  %56 = shl nuw nsw i64 %52, 6
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %56
  %57 = load double, ptr %gep.3, align 8
  %58 = fmul double %55, %57
  %59 = fadd double %51, %58
  store double %59, ptr %25, align 8
  %60 = add nuw nsw i64 %27, 4
  %exitcond.not.3 = icmp eq i64 %60, 64
  br i1 %exitcond.not.3, label %61, label %26

61:                                               ; preds = %26
  %62 = add nuw nsw i64 %24, 1
  %exitcond5.not = icmp eq i64 %62, 64
  br i1 %exitcond5.not, label %63, label %.preheader

63:                                               ; preds = %61
  %64 = add nuw nsw i64 %21, 1
  %exitcond6.not = icmp eq i64 %64, 64
  br i1 %exitcond6.not, label %65, label %.preheader2

65:                                               ; preds = %63
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  br label %.preheader2.i

.preheader2.i:                                    ; preds = %46, %3
  %4 = phi i64 [ %47, %46 ], [ 0, %3 ]
  %5 = shl i64 %4, 6
  %6 = getelementptr double, ptr %.unpack32, i64 %5
  br label %.preheader.i

.preheader.i:                                     ; preds = %44, %.preheader2.i
  %7 = phi i64 [ 0, %.preheader2.i ], [ %45, %44 ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %7
  %8 = getelementptr double, ptr %6, i64 %7
  %.promoted.i = load double, ptr %8, align 8
  br label %9

9:                                                ; preds = %9, %.preheader.i
  %10 = phi i64 [ 0, %.preheader.i ], [ %43, %9 ]
  %11 = phi double [ %.promoted.i, %.preheader.i ], [ %42, %9 ]
  %12 = or disjoint i64 %10, %5
  %13 = getelementptr double, ptr %.unpack2, i64 %12
  %14 = load double, ptr %13, align 8
  %15 = shl nuw nsw i64 %10, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %16 = load double, ptr %gep.i, align 8
  %17 = fmul double %14, %16
  %18 = fadd double %11, %17
  store double %18, ptr %8, align 8
  %19 = or disjoint i64 %10, 1
  %20 = or disjoint i64 %19, %5
  %21 = getelementptr double, ptr %.unpack2, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = shl nuw nsw i64 %19, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %23
  %24 = load double, ptr %gep.i.1, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %18, %25
  store double %26, ptr %8, align 8
  %27 = or disjoint i64 %10, 2
  %28 = or disjoint i64 %27, %5
  %29 = getelementptr double, ptr %.unpack2, i64 %28
  %30 = load double, ptr %29, align 8
  %31 = shl nuw nsw i64 %27, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %31
  %32 = load double, ptr %gep.i.2, align 8
  %33 = fmul double %30, %32
  %34 = fadd double %26, %33
  store double %34, ptr %8, align 8
  %35 = or disjoint i64 %10, 3
  %36 = or disjoint i64 %35, %5
  %37 = getelementptr double, ptr %.unpack2, i64 %36
  %38 = load double, ptr %37, align 8
  %39 = shl nuw nsw i64 %35, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %39
  %40 = load double, ptr %gep.i.3, align 8
  %41 = fmul double %38, %40
  %42 = fadd double %34, %41
  store double %42, ptr %8, align 8
  %43 = add nuw nsw i64 %10, 4
  %exitcond.not.i.3 = icmp eq i64 %43, 64
  br i1 %exitcond.not.i.3, label %44, label %9

44:                                               ; preds = %9
  %45 = add nuw nsw i64 %7, 1
  %exitcond5.not.i = icmp eq i64 %45, 64
  br i1 %exitcond5.not.i, label %46, label %.preheader.i

46:                                               ; preds = %44
  %47 = add nuw nsw i64 %4, 1
  %exitcond6.not.i = icmp eq i64 %47, 64
  br i1 %exitcond6.not.i, label %kernel.exit, label %.preheader2.i

kernel.exit:                                      ; preds = %46
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  br label %.preheader2.i

.preheader2.i:                                    ; preds = %53, %1
  %11 = phi i64 [ %54, %53 ], [ 0, %1 ]
  %12 = shl i64 %11, 6
  %13 = getelementptr double, ptr %10, i64 %12
  br label %.preheader.i

.preheader.i:                                     ; preds = %51, %.preheader2.i
  %14 = phi i64 [ 0, %.preheader2.i ], [ %52, %51 ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %14
  %15 = getelementptr double, ptr %13, i64 %14
  %.promoted.i = load double, ptr %15, align 8
  br label %16

16:                                               ; preds = %16, %.preheader.i
  %17 = phi i64 [ 0, %.preheader.i ], [ %50, %16 ]
  %18 = phi double [ %.promoted.i, %.preheader.i ], [ %49, %16 ]
  %19 = or disjoint i64 %17, %12
  %20 = getelementptr double, ptr %4, i64 %19
  %21 = load double, ptr %20, align 8
  %22 = shl nuw nsw i64 %17, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %22
  %23 = load double, ptr %gep.i, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %18, %24
  store double %25, ptr %15, align 8
  %26 = or disjoint i64 %17, 1
  %27 = or disjoint i64 %26, %12
  %28 = getelementptr double, ptr %4, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = shl nuw nsw i64 %26, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %30
  %31 = load double, ptr %gep.i.1, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %25, %32
  store double %33, ptr %15, align 8
  %34 = or disjoint i64 %17, 2
  %35 = or disjoint i64 %34, %12
  %36 = getelementptr double, ptr %4, i64 %35
  %37 = load double, ptr %36, align 8
  %38 = shl nuw nsw i64 %34, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %38
  %39 = load double, ptr %gep.i.2, align 8
  %40 = fmul double %37, %39
  %41 = fadd double %33, %40
  store double %41, ptr %15, align 8
  %42 = or disjoint i64 %17, 3
  %43 = or disjoint i64 %42, %12
  %44 = getelementptr double, ptr %4, i64 %43
  %45 = load double, ptr %44, align 8
  %46 = shl nuw nsw i64 %42, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %46
  %47 = load double, ptr %gep.i.3, align 8
  %48 = fmul double %45, %47
  %49 = fadd double %41, %48
  store double %49, ptr %15, align 8
  %50 = add nuw nsw i64 %17, 4
  %exitcond.not.i.3 = icmp eq i64 %50, 64
  br i1 %exitcond.not.i.3, label %51, label %16

51:                                               ; preds = %16
  %52 = add nuw nsw i64 %14, 1
  %exitcond5.not.i = icmp eq i64 %52, 64
  br i1 %exitcond5.not.i, label %53, label %.preheader.i

53:                                               ; preds = %51
  %54 = add nuw nsw i64 %11, 1
  %exitcond6.not.i = icmp eq i64 %54, 64
  br i1 %exitcond6.not.i, label %kernel.exit, label %.preheader2.i

kernel.exit:                                      ; preds = %53
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32.i, i8 0, i64 32768, i1 false)
  br label %.preheader2.i.i

.preheader2.i.i:                                  ; preds = %52, %1
  %10 = phi i64 [ %53, %52 ], [ 0, %1 ]
  %11 = shl i64 %10, 6
  %12 = getelementptr double, ptr %.unpack32.i, i64 %11
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %50, %.preheader2.i.i
  %13 = phi i64 [ 0, %.preheader2.i.i ], [ %51, %50 ]
  %invariant.gep.i.i = getelementptr double, ptr %.unpack17.i, i64 %13
  %14 = getelementptr double, ptr %12, i64 %13
  %.promoted.i.i = load double, ptr %14, align 8
  br label %15

15:                                               ; preds = %15, %.preheader.i.i
  %16 = phi i64 [ 0, %.preheader.i.i ], [ %49, %15 ]
  %17 = phi double [ %.promoted.i.i, %.preheader.i.i ], [ %48, %15 ]
  %18 = or disjoint i64 %16, %11
  %19 = getelementptr double, ptr %.unpack2.i, i64 %18
  %20 = load double, ptr %19, align 8
  %21 = shl nuw nsw i64 %16, 6
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %21
  %22 = load double, ptr %gep.i.i, align 8
  %23 = fmul double %20, %22
  %24 = fadd double %17, %23
  store double %24, ptr %14, align 8
  %25 = or disjoint i64 %16, 1
  %26 = or disjoint i64 %25, %11
  %27 = getelementptr double, ptr %.unpack2.i, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = shl nuw nsw i64 %25, 6
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %29
  %30 = load double, ptr %gep.i.i.1, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %24, %31
  store double %32, ptr %14, align 8
  %33 = or disjoint i64 %16, 2
  %34 = or disjoint i64 %33, %11
  %35 = getelementptr double, ptr %.unpack2.i, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = shl nuw nsw i64 %33, 6
  %gep.i.i.2 = getelementptr double, ptr %invariant.gep.i.i, i64 %37
  %38 = load double, ptr %gep.i.i.2, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %32, %39
  store double %40, ptr %14, align 8
  %41 = or disjoint i64 %16, 3
  %42 = or disjoint i64 %41, %11
  %43 = getelementptr double, ptr %.unpack2.i, i64 %42
  %44 = load double, ptr %43, align 8
  %45 = shl nuw nsw i64 %41, 6
  %gep.i.i.3 = getelementptr double, ptr %invariant.gep.i.i, i64 %45
  %46 = load double, ptr %gep.i.i.3, align 8
  %47 = fmul double %44, %46
  %48 = fadd double %40, %47
  store double %48, ptr %14, align 8
  %49 = add nuw nsw i64 %16, 4
  %exitcond.not.i.i.3 = icmp eq i64 %49, 64
  br i1 %exitcond.not.i.i.3, label %50, label %15

50:                                               ; preds = %15
  %51 = add nuw nsw i64 %13, 1
  %exitcond5.not.i.i = icmp eq i64 %51, 64
  br i1 %exitcond5.not.i.i, label %52, label %.preheader.i.i

52:                                               ; preds = %50
  %53 = add nuw nsw i64 %10, 1
  %exitcond6.not.i.i = icmp eq i64 %53, 64
  br i1 %exitcond6.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader2.i.i

_mlir_ciface_kernel.exit:                         ; preds = %52
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
