; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4.preheader, %63
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %64, %63 ]
  %22 = shl i64 %21, 6
  %23 = getelementptr double, ptr %15, i64 %22
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %61
  %24 = phi i64 [ 0, %.preheader3 ], [ %62, %61 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %24
  %25 = getelementptr double, ptr %23, i64 %24
  %.promoted = load double, ptr %25, align 8
  br label %26

26:                                               ; preds = %26, %.preheader
  %27 = phi i64 [ 0, %.preheader ], [ %60, %26 ]
  %28 = phi double [ %.promoted, %.preheader ], [ %59, %26 ]
  %29 = or disjoint i64 %27, %22
  %30 = getelementptr double, ptr %1, i64 %29
  %31 = load double, ptr %30, align 8
  %32 = shl nuw nsw i64 %27, 6
  %gep = getelementptr double, ptr %invariant.gep, i64 %32
  %33 = load double, ptr %gep, align 8
  %34 = fmul double %31, %33
  %35 = fadd double %28, %34
  store double %35, ptr %25, align 8
  %36 = or disjoint i64 %27, 1
  %37 = or disjoint i64 %36, %22
  %38 = getelementptr double, ptr %1, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = shl nuw nsw i64 %36, 6
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 %40
  %41 = load double, ptr %gep.18, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %35, %42
  store double %43, ptr %25, align 8
  %44 = or disjoint i64 %27, 2
  %45 = or disjoint i64 %44, %22
  %46 = getelementptr double, ptr %1, i64 %45
  %47 = load double, ptr %46, align 8
  %48 = shl nuw nsw i64 %44, 6
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 %48
  %49 = load double, ptr %gep.29, align 8
  %50 = fmul double %47, %49
  %51 = fadd double %43, %50
  store double %51, ptr %25, align 8
  %52 = or disjoint i64 %27, 3
  %53 = or disjoint i64 %52, %22
  %54 = getelementptr double, ptr %1, i64 %53
  %55 = load double, ptr %54, align 8
  %56 = shl nuw nsw i64 %52, 6
  %gep.310 = getelementptr double, ptr %invariant.gep, i64 %56
  %57 = load double, ptr %gep.310, align 8
  %58 = fmul double %55, %57
  %59 = fadd double %51, %58
  store double %59, ptr %25, align 8
  %60 = add nuw nsw i64 %27, 4
  %exitcond.not.3 = icmp eq i64 %60, 64
  br i1 %exitcond.not.3, label %61, label %26

61:                                               ; preds = %26
  %62 = add nuw nsw i64 %24, 1
  %exitcond6.not = icmp eq i64 %62, 64
  br i1 %exitcond6.not, label %63, label %.preheader

63:                                               ; preds = %61
  %64 = add nuw nsw i64 %21, 1
  %exitcond7.not = icmp eq i64 %64, 16
  br i1 %exitcond7.not, label %.preheader4.1, label %.preheader3

.preheader4.1:                                    ; preds = %63
  %65 = getelementptr double, ptr %1, i64 1024
  %66 = getelementptr double, ptr %15, i64 1024
  br label %.preheader3.1

.preheader3.1:                                    ; preds = %109, %.preheader4.1
  %67 = phi i64 [ 0, %.preheader4.1 ], [ %110, %109 ]
  %68 = shl i64 %67, 6
  %69 = getelementptr double, ptr %66, i64 %68
  br label %.preheader.1

.preheader.1:                                     ; preds = %107, %.preheader3.1
  %70 = phi i64 [ 0, %.preheader3.1 ], [ %108, %107 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %70
  %71 = getelementptr double, ptr %69, i64 %70
  %.promoted.1 = load double, ptr %71, align 8
  br label %72

72:                                               ; preds = %72, %.preheader.1
  %73 = phi i64 [ 0, %.preheader.1 ], [ %106, %72 ]
  %74 = phi double [ %.promoted.1, %.preheader.1 ], [ %105, %72 ]
  %75 = or disjoint i64 %73, %68
  %76 = getelementptr double, ptr %65, i64 %75
  %77 = load double, ptr %76, align 8
  %78 = shl nuw nsw i64 %73, 6
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %78
  %79 = load double, ptr %gep.1, align 8
  %80 = fmul double %77, %79
  %81 = fadd double %74, %80
  store double %81, ptr %71, align 8
  %82 = or disjoint i64 %73, 1
  %83 = or disjoint i64 %82, %68
  %84 = getelementptr double, ptr %65, i64 %83
  %85 = load double, ptr %84, align 8
  %86 = shl nuw nsw i64 %82, 6
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %86
  %87 = load double, ptr %gep.1.1, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %81, %88
  store double %89, ptr %71, align 8
  %90 = or disjoint i64 %73, 2
  %91 = or disjoint i64 %90, %68
  %92 = getelementptr double, ptr %65, i64 %91
  %93 = load double, ptr %92, align 8
  %94 = shl nuw nsw i64 %90, 6
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %94
  %95 = load double, ptr %gep.1.2, align 8
  %96 = fmul double %93, %95
  %97 = fadd double %89, %96
  store double %97, ptr %71, align 8
  %98 = or disjoint i64 %73, 3
  %99 = or disjoint i64 %98, %68
  %100 = getelementptr double, ptr %65, i64 %99
  %101 = load double, ptr %100, align 8
  %102 = shl nuw nsw i64 %98, 6
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %102
  %103 = load double, ptr %gep.1.3, align 8
  %104 = fmul double %101, %103
  %105 = fadd double %97, %104
  store double %105, ptr %71, align 8
  %106 = add nuw nsw i64 %73, 4
  %exitcond.1.not.3 = icmp eq i64 %106, 64
  br i1 %exitcond.1.not.3, label %107, label %72

107:                                              ; preds = %72
  %108 = add nuw nsw i64 %70, 1
  %exitcond6.1.not = icmp eq i64 %108, 64
  br i1 %exitcond6.1.not, label %109, label %.preheader.1

109:                                              ; preds = %107
  %110 = add nuw nsw i64 %67, 1
  %exitcond7.1.not = icmp eq i64 %110, 16
  br i1 %exitcond7.1.not, label %.preheader4.2, label %.preheader3.1

.preheader4.2:                                    ; preds = %109
  %111 = getelementptr double, ptr %1, i64 2048
  %112 = getelementptr double, ptr %15, i64 2048
  br label %.preheader3.2

.preheader3.2:                                    ; preds = %155, %.preheader4.2
  %113 = phi i64 [ 0, %.preheader4.2 ], [ %156, %155 ]
  %114 = shl i64 %113, 6
  %115 = getelementptr double, ptr %112, i64 %114
  br label %.preheader.2

.preheader.2:                                     ; preds = %153, %.preheader3.2
  %116 = phi i64 [ 0, %.preheader3.2 ], [ %154, %153 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %116
  %117 = getelementptr double, ptr %115, i64 %116
  %.promoted.2 = load double, ptr %117, align 8
  br label %118

118:                                              ; preds = %118, %.preheader.2
  %119 = phi i64 [ 0, %.preheader.2 ], [ %152, %118 ]
  %120 = phi double [ %.promoted.2, %.preheader.2 ], [ %151, %118 ]
  %121 = or disjoint i64 %119, %114
  %122 = getelementptr double, ptr %111, i64 %121
  %123 = load double, ptr %122, align 8
  %124 = shl nuw nsw i64 %119, 6
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %124
  %125 = load double, ptr %gep.2, align 8
  %126 = fmul double %123, %125
  %127 = fadd double %120, %126
  store double %127, ptr %117, align 8
  %128 = or disjoint i64 %119, 1
  %129 = or disjoint i64 %128, %114
  %130 = getelementptr double, ptr %111, i64 %129
  %131 = load double, ptr %130, align 8
  %132 = shl nuw nsw i64 %128, 6
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %132
  %133 = load double, ptr %gep.2.1, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %127, %134
  store double %135, ptr %117, align 8
  %136 = or disjoint i64 %119, 2
  %137 = or disjoint i64 %136, %114
  %138 = getelementptr double, ptr %111, i64 %137
  %139 = load double, ptr %138, align 8
  %140 = shl nuw nsw i64 %136, 6
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %140
  %141 = load double, ptr %gep.2.2, align 8
  %142 = fmul double %139, %141
  %143 = fadd double %135, %142
  store double %143, ptr %117, align 8
  %144 = or disjoint i64 %119, 3
  %145 = or disjoint i64 %144, %114
  %146 = getelementptr double, ptr %111, i64 %145
  %147 = load double, ptr %146, align 8
  %148 = shl nuw nsw i64 %144, 6
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %148
  %149 = load double, ptr %gep.2.3, align 8
  %150 = fmul double %147, %149
  %151 = fadd double %143, %150
  store double %151, ptr %117, align 8
  %152 = add nuw nsw i64 %119, 4
  %exitcond.2.not.3 = icmp eq i64 %152, 64
  br i1 %exitcond.2.not.3, label %153, label %118

153:                                              ; preds = %118
  %154 = add nuw nsw i64 %116, 1
  %exitcond6.2.not = icmp eq i64 %154, 64
  br i1 %exitcond6.2.not, label %155, label %.preheader.2

155:                                              ; preds = %153
  %156 = add nuw nsw i64 %113, 1
  %exitcond7.2.not = icmp eq i64 %156, 16
  br i1 %exitcond7.2.not, label %.preheader4.3, label %.preheader3.2

.preheader4.3:                                    ; preds = %155
  %157 = getelementptr double, ptr %1, i64 3072
  %158 = getelementptr double, ptr %15, i64 3072
  br label %.preheader3.3

.preheader3.3:                                    ; preds = %201, %.preheader4.3
  %159 = phi i64 [ 0, %.preheader4.3 ], [ %202, %201 ]
  %160 = shl i64 %159, 6
  %161 = getelementptr double, ptr %158, i64 %160
  br label %.preheader.3

.preheader.3:                                     ; preds = %199, %.preheader3.3
  %162 = phi i64 [ 0, %.preheader3.3 ], [ %200, %199 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %162
  %163 = getelementptr double, ptr %161, i64 %162
  %.promoted.3 = load double, ptr %163, align 8
  br label %164

164:                                              ; preds = %164, %.preheader.3
  %165 = phi i64 [ 0, %.preheader.3 ], [ %198, %164 ]
  %166 = phi double [ %.promoted.3, %.preheader.3 ], [ %197, %164 ]
  %167 = or disjoint i64 %165, %160
  %168 = getelementptr double, ptr %157, i64 %167
  %169 = load double, ptr %168, align 8
  %170 = shl nuw nsw i64 %165, 6
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %170
  %171 = load double, ptr %gep.3, align 8
  %172 = fmul double %169, %171
  %173 = fadd double %166, %172
  store double %173, ptr %163, align 8
  %174 = or disjoint i64 %165, 1
  %175 = or disjoint i64 %174, %160
  %176 = getelementptr double, ptr %157, i64 %175
  %177 = load double, ptr %176, align 8
  %178 = shl nuw nsw i64 %174, 6
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %178
  %179 = load double, ptr %gep.3.1, align 8
  %180 = fmul double %177, %179
  %181 = fadd double %173, %180
  store double %181, ptr %163, align 8
  %182 = or disjoint i64 %165, 2
  %183 = or disjoint i64 %182, %160
  %184 = getelementptr double, ptr %157, i64 %183
  %185 = load double, ptr %184, align 8
  %186 = shl nuw nsw i64 %182, 6
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %186
  %187 = load double, ptr %gep.3.2, align 8
  %188 = fmul double %185, %187
  %189 = fadd double %181, %188
  store double %189, ptr %163, align 8
  %190 = or disjoint i64 %165, 3
  %191 = or disjoint i64 %190, %160
  %192 = getelementptr double, ptr %157, i64 %191
  %193 = load double, ptr %192, align 8
  %194 = shl nuw nsw i64 %190, 6
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %194
  %195 = load double, ptr %gep.3.3, align 8
  %196 = fmul double %193, %195
  %197 = fadd double %189, %196
  store double %197, ptr %163, align 8
  %198 = add nuw nsw i64 %165, 4
  %exitcond.3.not.3 = icmp eq i64 %198, 64
  br i1 %exitcond.3.not.3, label %199, label %164

199:                                              ; preds = %164
  %200 = add nuw nsw i64 %162, 1
  %exitcond6.3.not = icmp eq i64 %200, 64
  br i1 %exitcond6.3.not, label %201, label %.preheader.3

201:                                              ; preds = %199
  %202 = add nuw nsw i64 %159, 1
  %exitcond7.3.not = icmp eq i64 %202, 16
  br i1 %exitcond7.3.not, label %203, label %.preheader3.3

203:                                              ; preds = %201
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  br label %.preheader3.i

.preheader3.i:                                    ; preds = %46, %3
  %4 = phi i64 [ 0, %3 ], [ %47, %46 ]
  %5 = shl i64 %4, 6
  %6 = getelementptr double, ptr %.unpack32, i64 %5
  br label %.preheader.i

.preheader.i:                                     ; preds = %44, %.preheader3.i
  %7 = phi i64 [ 0, %.preheader3.i ], [ %45, %44 ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %7
  %8 = getelementptr double, ptr %6, i64 %7
  %.promoted.i = load double, ptr %8, align 8
  br label %9

9:                                                ; preds = %9, %.preheader.i
  %10 = phi i64 [ 0, %.preheader.i ], [ %43, %9 ]
  %11 = phi double [ %.promoted.i, %.preheader.i ], [ %42, %9 ]
  %12 = or disjoint i64 %10, %5
  %13 = getelementptr double, ptr %.unpack2, i64 %12
  %14 = load double, ptr %13, align 8
  %15 = shl nuw nsw i64 %10, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %16 = load double, ptr %gep.i, align 8
  %17 = fmul double %14, %16
  %18 = fadd double %11, %17
  store double %18, ptr %8, align 8
  %19 = or disjoint i64 %10, 1
  %20 = or disjoint i64 %19, %5
  %21 = getelementptr double, ptr %.unpack2, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = shl nuw nsw i64 %19, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %23
  %24 = load double, ptr %gep.i.1, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %18, %25
  store double %26, ptr %8, align 8
  %27 = or disjoint i64 %10, 2
  %28 = or disjoint i64 %27, %5
  %29 = getelementptr double, ptr %.unpack2, i64 %28
  %30 = load double, ptr %29, align 8
  %31 = shl nuw nsw i64 %27, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %31
  %32 = load double, ptr %gep.i.2, align 8
  %33 = fmul double %30, %32
  %34 = fadd double %26, %33
  store double %34, ptr %8, align 8
  %35 = or disjoint i64 %10, 3
  %36 = or disjoint i64 %35, %5
  %37 = getelementptr double, ptr %.unpack2, i64 %36
  %38 = load double, ptr %37, align 8
  %39 = shl nuw nsw i64 %35, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %39
  %40 = load double, ptr %gep.i.3, align 8
  %41 = fmul double %38, %40
  %42 = fadd double %34, %41
  store double %42, ptr %8, align 8
  %43 = add nuw nsw i64 %10, 4
  %exitcond.not.i.3 = icmp eq i64 %43, 64
  br i1 %exitcond.not.i.3, label %44, label %9

44:                                               ; preds = %9
  %45 = add nuw nsw i64 %7, 1
  %exitcond6.not.i = icmp eq i64 %45, 64
  br i1 %exitcond6.not.i, label %46, label %.preheader.i

46:                                               ; preds = %44
  %47 = add nuw nsw i64 %4, 1
  %exitcond7.not.i = icmp eq i64 %47, 16
  br i1 %exitcond7.not.i, label %.preheader4.1.i, label %.preheader3.i

.preheader4.1.i:                                  ; preds = %46
  %48 = getelementptr double, ptr %.unpack2, i64 1024
  %49 = getelementptr double, ptr %.unpack32, i64 1024
  br label %.preheader3.1.i

.preheader3.1.i:                                  ; preds = %92, %.preheader4.1.i
  %50 = phi i64 [ 0, %.preheader4.1.i ], [ %93, %92 ]
  %51 = shl i64 %50, 6
  %52 = getelementptr double, ptr %49, i64 %51
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %90, %.preheader3.1.i
  %53 = phi i64 [ 0, %.preheader3.1.i ], [ %91, %90 ]
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 %53
  %54 = getelementptr double, ptr %52, i64 %53
  %.promoted.1.i = load double, ptr %54, align 8
  br label %55

55:                                               ; preds = %55, %.preheader.1.i
  %56 = phi i64 [ 0, %.preheader.1.i ], [ %89, %55 ]
  %57 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %88, %55 ]
  %58 = or disjoint i64 %56, %51
  %59 = getelementptr double, ptr %48, i64 %58
  %60 = load double, ptr %59, align 8
  %61 = shl nuw nsw i64 %56, 6
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %61
  %62 = load double, ptr %gep.1.i, align 8
  %63 = fmul double %60, %62
  %64 = fadd double %57, %63
  store double %64, ptr %54, align 8
  %65 = or disjoint i64 %56, 1
  %66 = or disjoint i64 %65, %51
  %67 = getelementptr double, ptr %48, i64 %66
  %68 = load double, ptr %67, align 8
  %69 = shl nuw nsw i64 %65, 6
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %69
  %70 = load double, ptr %gep.1.i.1, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %64, %71
  store double %72, ptr %54, align 8
  %73 = or disjoint i64 %56, 2
  %74 = or disjoint i64 %73, %51
  %75 = getelementptr double, ptr %48, i64 %74
  %76 = load double, ptr %75, align 8
  %77 = shl nuw nsw i64 %73, 6
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %77
  %78 = load double, ptr %gep.1.i.2, align 8
  %79 = fmul double %76, %78
  %80 = fadd double %72, %79
  store double %80, ptr %54, align 8
  %81 = or disjoint i64 %56, 3
  %82 = or disjoint i64 %81, %51
  %83 = getelementptr double, ptr %48, i64 %82
  %84 = load double, ptr %83, align 8
  %85 = shl nuw nsw i64 %81, 6
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %85
  %86 = load double, ptr %gep.1.i.3, align 8
  %87 = fmul double %84, %86
  %88 = fadd double %80, %87
  store double %88, ptr %54, align 8
  %89 = add nuw nsw i64 %56, 4
  %exitcond.1.not.i.3 = icmp eq i64 %89, 64
  br i1 %exitcond.1.not.i.3, label %90, label %55

90:                                               ; preds = %55
  %91 = add nuw nsw i64 %53, 1
  %exitcond6.1.not.i = icmp eq i64 %91, 64
  br i1 %exitcond6.1.not.i, label %92, label %.preheader.1.i

92:                                               ; preds = %90
  %93 = add nuw nsw i64 %50, 1
  %exitcond7.1.not.i = icmp eq i64 %93, 16
  br i1 %exitcond7.1.not.i, label %.preheader4.2.i, label %.preheader3.1.i

.preheader4.2.i:                                  ; preds = %92
  %94 = getelementptr double, ptr %.unpack2, i64 2048
  %95 = getelementptr double, ptr %.unpack32, i64 2048
  br label %.preheader3.2.i

.preheader3.2.i:                                  ; preds = %138, %.preheader4.2.i
  %96 = phi i64 [ 0, %.preheader4.2.i ], [ %139, %138 ]
  %97 = shl i64 %96, 6
  %98 = getelementptr double, ptr %95, i64 %97
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %136, %.preheader3.2.i
  %99 = phi i64 [ 0, %.preheader3.2.i ], [ %137, %136 ]
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 %99
  %100 = getelementptr double, ptr %98, i64 %99
  %.promoted.2.i = load double, ptr %100, align 8
  br label %101

101:                                              ; preds = %101, %.preheader.2.i
  %102 = phi i64 [ 0, %.preheader.2.i ], [ %135, %101 ]
  %103 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %134, %101 ]
  %104 = or disjoint i64 %102, %97
  %105 = getelementptr double, ptr %94, i64 %104
  %106 = load double, ptr %105, align 8
  %107 = shl nuw nsw i64 %102, 6
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %107
  %108 = load double, ptr %gep.2.i, align 8
  %109 = fmul double %106, %108
  %110 = fadd double %103, %109
  store double %110, ptr %100, align 8
  %111 = or disjoint i64 %102, 1
  %112 = or disjoint i64 %111, %97
  %113 = getelementptr double, ptr %94, i64 %112
  %114 = load double, ptr %113, align 8
  %115 = shl nuw nsw i64 %111, 6
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %115
  %116 = load double, ptr %gep.2.i.1, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %110, %117
  store double %118, ptr %100, align 8
  %119 = or disjoint i64 %102, 2
  %120 = or disjoint i64 %119, %97
  %121 = getelementptr double, ptr %94, i64 %120
  %122 = load double, ptr %121, align 8
  %123 = shl nuw nsw i64 %119, 6
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %123
  %124 = load double, ptr %gep.2.i.2, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %118, %125
  store double %126, ptr %100, align 8
  %127 = or disjoint i64 %102, 3
  %128 = or disjoint i64 %127, %97
  %129 = getelementptr double, ptr %94, i64 %128
  %130 = load double, ptr %129, align 8
  %131 = shl nuw nsw i64 %127, 6
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %131
  %132 = load double, ptr %gep.2.i.3, align 8
  %133 = fmul double %130, %132
  %134 = fadd double %126, %133
  store double %134, ptr %100, align 8
  %135 = add nuw nsw i64 %102, 4
  %exitcond.2.not.i.3 = icmp eq i64 %135, 64
  br i1 %exitcond.2.not.i.3, label %136, label %101

136:                                              ; preds = %101
  %137 = add nuw nsw i64 %99, 1
  %exitcond6.2.not.i = icmp eq i64 %137, 64
  br i1 %exitcond6.2.not.i, label %138, label %.preheader.2.i

138:                                              ; preds = %136
  %139 = add nuw nsw i64 %96, 1
  %exitcond7.2.not.i = icmp eq i64 %139, 16
  br i1 %exitcond7.2.not.i, label %.preheader4.3.i, label %.preheader3.2.i

.preheader4.3.i:                                  ; preds = %138
  %140 = getelementptr double, ptr %.unpack2, i64 3072
  %141 = getelementptr double, ptr %.unpack32, i64 3072
  br label %.preheader3.3.i

.preheader3.3.i:                                  ; preds = %184, %.preheader4.3.i
  %142 = phi i64 [ 0, %.preheader4.3.i ], [ %185, %184 ]
  %143 = shl i64 %142, 6
  %144 = getelementptr double, ptr %141, i64 %143
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %182, %.preheader3.3.i
  %145 = phi i64 [ 0, %.preheader3.3.i ], [ %183, %182 ]
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 %145
  %146 = getelementptr double, ptr %144, i64 %145
  %.promoted.3.i = load double, ptr %146, align 8
  br label %147

147:                                              ; preds = %147, %.preheader.3.i
  %148 = phi i64 [ 0, %.preheader.3.i ], [ %181, %147 ]
  %149 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %180, %147 ]
  %150 = or disjoint i64 %148, %143
  %151 = getelementptr double, ptr %140, i64 %150
  %152 = load double, ptr %151, align 8
  %153 = shl nuw nsw i64 %148, 6
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %153
  %154 = load double, ptr %gep.3.i, align 8
  %155 = fmul double %152, %154
  %156 = fadd double %149, %155
  store double %156, ptr %146, align 8
  %157 = or disjoint i64 %148, 1
  %158 = or disjoint i64 %157, %143
  %159 = getelementptr double, ptr %140, i64 %158
  %160 = load double, ptr %159, align 8
  %161 = shl nuw nsw i64 %157, 6
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %161
  %162 = load double, ptr %gep.3.i.1, align 8
  %163 = fmul double %160, %162
  %164 = fadd double %156, %163
  store double %164, ptr %146, align 8
  %165 = or disjoint i64 %148, 2
  %166 = or disjoint i64 %165, %143
  %167 = getelementptr double, ptr %140, i64 %166
  %168 = load double, ptr %167, align 8
  %169 = shl nuw nsw i64 %165, 6
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %169
  %170 = load double, ptr %gep.3.i.2, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %164, %171
  store double %172, ptr %146, align 8
  %173 = or disjoint i64 %148, 3
  %174 = or disjoint i64 %173, %143
  %175 = getelementptr double, ptr %140, i64 %174
  %176 = load double, ptr %175, align 8
  %177 = shl nuw nsw i64 %173, 6
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %177
  %178 = load double, ptr %gep.3.i.3, align 8
  %179 = fmul double %176, %178
  %180 = fadd double %172, %179
  store double %180, ptr %146, align 8
  %181 = add nuw nsw i64 %148, 4
  %exitcond.3.not.i.3 = icmp eq i64 %181, 64
  br i1 %exitcond.3.not.i.3, label %182, label %147

182:                                              ; preds = %147
  %183 = add nuw nsw i64 %145, 1
  %exitcond6.3.not.i = icmp eq i64 %183, 64
  br i1 %exitcond6.3.not.i, label %184, label %.preheader.3.i

184:                                              ; preds = %182
  %185 = add nuw nsw i64 %142, 1
  %exitcond7.3.not.i = icmp eq i64 %185, 16
  br i1 %exitcond7.3.not.i, label %kernel.exit, label %.preheader3.3.i

kernel.exit:                                      ; preds = %184
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  br label %.preheader3.i

.preheader3.i:                                    ; preds = %53, %1
  %11 = phi i64 [ 0, %1 ], [ %54, %53 ]
  %12 = shl i64 %11, 6
  %13 = getelementptr double, ptr %10, i64 %12
  br label %.preheader.i

.preheader.i:                                     ; preds = %51, %.preheader3.i
  %14 = phi i64 [ 0, %.preheader3.i ], [ %52, %51 ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %14
  %15 = getelementptr double, ptr %13, i64 %14
  %.promoted.i = load double, ptr %15, align 8
  br label %16

16:                                               ; preds = %16, %.preheader.i
  %17 = phi i64 [ 0, %.preheader.i ], [ %50, %16 ]
  %18 = phi double [ %.promoted.i, %.preheader.i ], [ %49, %16 ]
  %19 = or disjoint i64 %17, %12
  %20 = getelementptr double, ptr %4, i64 %19
  %21 = load double, ptr %20, align 8
  %22 = shl nuw nsw i64 %17, 6
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %22
  %23 = load double, ptr %gep.i, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %18, %24
  store double %25, ptr %15, align 8
  %26 = or disjoint i64 %17, 1
  %27 = or disjoint i64 %26, %12
  %28 = getelementptr double, ptr %4, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = shl nuw nsw i64 %26, 6
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %30
  %31 = load double, ptr %gep.i.1, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %25, %32
  store double %33, ptr %15, align 8
  %34 = or disjoint i64 %17, 2
  %35 = or disjoint i64 %34, %12
  %36 = getelementptr double, ptr %4, i64 %35
  %37 = load double, ptr %36, align 8
  %38 = shl nuw nsw i64 %34, 6
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %38
  %39 = load double, ptr %gep.i.2, align 8
  %40 = fmul double %37, %39
  %41 = fadd double %33, %40
  store double %41, ptr %15, align 8
  %42 = or disjoint i64 %17, 3
  %43 = or disjoint i64 %42, %12
  %44 = getelementptr double, ptr %4, i64 %43
  %45 = load double, ptr %44, align 8
  %46 = shl nuw nsw i64 %42, 6
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %46
  %47 = load double, ptr %gep.i.3, align 8
  %48 = fmul double %45, %47
  %49 = fadd double %41, %48
  store double %49, ptr %15, align 8
  %50 = add nuw nsw i64 %17, 4
  %exitcond.not.i.3 = icmp eq i64 %50, 64
  br i1 %exitcond.not.i.3, label %51, label %16

51:                                               ; preds = %16
  %52 = add nuw nsw i64 %14, 1
  %exitcond6.not.i = icmp eq i64 %52, 64
  br i1 %exitcond6.not.i, label %53, label %.preheader.i

53:                                               ; preds = %51
  %54 = add nuw nsw i64 %11, 1
  %exitcond7.not.i = icmp eq i64 %54, 16
  br i1 %exitcond7.not.i, label %.preheader4.1.i, label %.preheader3.i

.preheader4.1.i:                                  ; preds = %53
  %55 = getelementptr double, ptr %4, i64 1024
  %56 = getelementptr double, ptr %10, i64 1024
  br label %.preheader3.1.i

.preheader3.1.i:                                  ; preds = %99, %.preheader4.1.i
  %57 = phi i64 [ 0, %.preheader4.1.i ], [ %100, %99 ]
  %58 = shl i64 %57, 6
  %59 = getelementptr double, ptr %56, i64 %58
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %97, %.preheader3.1.i
  %60 = phi i64 [ 0, %.preheader3.1.i ], [ %98, %97 ]
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 %60
  %61 = getelementptr double, ptr %59, i64 %60
  %.promoted.1.i = load double, ptr %61, align 8
  br label %62

62:                                               ; preds = %62, %.preheader.1.i
  %63 = phi i64 [ 0, %.preheader.1.i ], [ %96, %62 ]
  %64 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %95, %62 ]
  %65 = or disjoint i64 %63, %58
  %66 = getelementptr double, ptr %55, i64 %65
  %67 = load double, ptr %66, align 8
  %68 = shl nuw nsw i64 %63, 6
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %68
  %69 = load double, ptr %gep.1.i, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %64, %70
  store double %71, ptr %61, align 8
  %72 = or disjoint i64 %63, 1
  %73 = or disjoint i64 %72, %58
  %74 = getelementptr double, ptr %55, i64 %73
  %75 = load double, ptr %74, align 8
  %76 = shl nuw nsw i64 %72, 6
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %76
  %77 = load double, ptr %gep.1.i.1, align 8
  %78 = fmul double %75, %77
  %79 = fadd double %71, %78
  store double %79, ptr %61, align 8
  %80 = or disjoint i64 %63, 2
  %81 = or disjoint i64 %80, %58
  %82 = getelementptr double, ptr %55, i64 %81
  %83 = load double, ptr %82, align 8
  %84 = shl nuw nsw i64 %80, 6
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %84
  %85 = load double, ptr %gep.1.i.2, align 8
  %86 = fmul double %83, %85
  %87 = fadd double %79, %86
  store double %87, ptr %61, align 8
  %88 = or disjoint i64 %63, 3
  %89 = or disjoint i64 %88, %58
  %90 = getelementptr double, ptr %55, i64 %89
  %91 = load double, ptr %90, align 8
  %92 = shl nuw nsw i64 %88, 6
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %92
  %93 = load double, ptr %gep.1.i.3, align 8
  %94 = fmul double %91, %93
  %95 = fadd double %87, %94
  store double %95, ptr %61, align 8
  %96 = add nuw nsw i64 %63, 4
  %exitcond.1.not.i.3 = icmp eq i64 %96, 64
  br i1 %exitcond.1.not.i.3, label %97, label %62

97:                                               ; preds = %62
  %98 = add nuw nsw i64 %60, 1
  %exitcond6.1.not.i = icmp eq i64 %98, 64
  br i1 %exitcond6.1.not.i, label %99, label %.preheader.1.i

99:                                               ; preds = %97
  %100 = add nuw nsw i64 %57, 1
  %exitcond7.1.not.i = icmp eq i64 %100, 16
  br i1 %exitcond7.1.not.i, label %.preheader4.2.i, label %.preheader3.1.i

.preheader4.2.i:                                  ; preds = %99
  %101 = getelementptr double, ptr %4, i64 2048
  %102 = getelementptr double, ptr %10, i64 2048
  br label %.preheader3.2.i

.preheader3.2.i:                                  ; preds = %145, %.preheader4.2.i
  %103 = phi i64 [ 0, %.preheader4.2.i ], [ %146, %145 ]
  %104 = shl i64 %103, 6
  %105 = getelementptr double, ptr %102, i64 %104
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %143, %.preheader3.2.i
  %106 = phi i64 [ 0, %.preheader3.2.i ], [ %144, %143 ]
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 %106
  %107 = getelementptr double, ptr %105, i64 %106
  %.promoted.2.i = load double, ptr %107, align 8
  br label %108

108:                                              ; preds = %108, %.preheader.2.i
  %109 = phi i64 [ 0, %.preheader.2.i ], [ %142, %108 ]
  %110 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %141, %108 ]
  %111 = or disjoint i64 %109, %104
  %112 = getelementptr double, ptr %101, i64 %111
  %113 = load double, ptr %112, align 8
  %114 = shl nuw nsw i64 %109, 6
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %114
  %115 = load double, ptr %gep.2.i, align 8
  %116 = fmul double %113, %115
  %117 = fadd double %110, %116
  store double %117, ptr %107, align 8
  %118 = or disjoint i64 %109, 1
  %119 = or disjoint i64 %118, %104
  %120 = getelementptr double, ptr %101, i64 %119
  %121 = load double, ptr %120, align 8
  %122 = shl nuw nsw i64 %118, 6
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %122
  %123 = load double, ptr %gep.2.i.1, align 8
  %124 = fmul double %121, %123
  %125 = fadd double %117, %124
  store double %125, ptr %107, align 8
  %126 = or disjoint i64 %109, 2
  %127 = or disjoint i64 %126, %104
  %128 = getelementptr double, ptr %101, i64 %127
  %129 = load double, ptr %128, align 8
  %130 = shl nuw nsw i64 %126, 6
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %130
  %131 = load double, ptr %gep.2.i.2, align 8
  %132 = fmul double %129, %131
  %133 = fadd double %125, %132
  store double %133, ptr %107, align 8
  %134 = or disjoint i64 %109, 3
  %135 = or disjoint i64 %134, %104
  %136 = getelementptr double, ptr %101, i64 %135
  %137 = load double, ptr %136, align 8
  %138 = shl nuw nsw i64 %134, 6
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %138
  %139 = load double, ptr %gep.2.i.3, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %133, %140
  store double %141, ptr %107, align 8
  %142 = add nuw nsw i64 %109, 4
  %exitcond.2.not.i.3 = icmp eq i64 %142, 64
  br i1 %exitcond.2.not.i.3, label %143, label %108

143:                                              ; preds = %108
  %144 = add nuw nsw i64 %106, 1
  %exitcond6.2.not.i = icmp eq i64 %144, 64
  br i1 %exitcond6.2.not.i, label %145, label %.preheader.2.i

145:                                              ; preds = %143
  %146 = add nuw nsw i64 %103, 1
  %exitcond7.2.not.i = icmp eq i64 %146, 16
  br i1 %exitcond7.2.not.i, label %.preheader4.3.i, label %.preheader3.2.i

.preheader4.3.i:                                  ; preds = %145
  %147 = getelementptr double, ptr %4, i64 3072
  %148 = getelementptr double, ptr %10, i64 3072
  br label %.preheader3.3.i

.preheader3.3.i:                                  ; preds = %191, %.preheader4.3.i
  %149 = phi i64 [ 0, %.preheader4.3.i ], [ %192, %191 ]
  %150 = shl i64 %149, 6
  %151 = getelementptr double, ptr %148, i64 %150
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %189, %.preheader3.3.i
  %152 = phi i64 [ 0, %.preheader3.3.i ], [ %190, %189 ]
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 %152
  %153 = getelementptr double, ptr %151, i64 %152
  %.promoted.3.i = load double, ptr %153, align 8
  br label %154

154:                                              ; preds = %154, %.preheader.3.i
  %155 = phi i64 [ 0, %.preheader.3.i ], [ %188, %154 ]
  %156 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %187, %154 ]
  %157 = or disjoint i64 %155, %150
  %158 = getelementptr double, ptr %147, i64 %157
  %159 = load double, ptr %158, align 8
  %160 = shl nuw nsw i64 %155, 6
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %160
  %161 = load double, ptr %gep.3.i, align 8
  %162 = fmul double %159, %161
  %163 = fadd double %156, %162
  store double %163, ptr %153, align 8
  %164 = or disjoint i64 %155, 1
  %165 = or disjoint i64 %164, %150
  %166 = getelementptr double, ptr %147, i64 %165
  %167 = load double, ptr %166, align 8
  %168 = shl nuw nsw i64 %164, 6
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %168
  %169 = load double, ptr %gep.3.i.1, align 8
  %170 = fmul double %167, %169
  %171 = fadd double %163, %170
  store double %171, ptr %153, align 8
  %172 = or disjoint i64 %155, 2
  %173 = or disjoint i64 %172, %150
  %174 = getelementptr double, ptr %147, i64 %173
  %175 = load double, ptr %174, align 8
  %176 = shl nuw nsw i64 %172, 6
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %176
  %177 = load double, ptr %gep.3.i.2, align 8
  %178 = fmul double %175, %177
  %179 = fadd double %171, %178
  store double %179, ptr %153, align 8
  %180 = or disjoint i64 %155, 3
  %181 = or disjoint i64 %180, %150
  %182 = getelementptr double, ptr %147, i64 %181
  %183 = load double, ptr %182, align 8
  %184 = shl nuw nsw i64 %180, 6
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %184
  %185 = load double, ptr %gep.3.i.3, align 8
  %186 = fmul double %183, %185
  %187 = fadd double %179, %186
  store double %187, ptr %153, align 8
  %188 = add nuw nsw i64 %155, 4
  %exitcond.3.not.i.3 = icmp eq i64 %188, 64
  br i1 %exitcond.3.not.i.3, label %189, label %154

189:                                              ; preds = %154
  %190 = add nuw nsw i64 %152, 1
  %exitcond6.3.not.i = icmp eq i64 %190, 64
  br i1 %exitcond6.3.not.i, label %191, label %.preheader.3.i

191:                                              ; preds = %189
  %192 = add nuw nsw i64 %149, 1
  %exitcond7.3.not.i = icmp eq i64 %192, 16
  br i1 %exitcond7.3.not.i, label %kernel.exit, label %.preheader3.3.i

kernel.exit:                                      ; preds = %191
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
