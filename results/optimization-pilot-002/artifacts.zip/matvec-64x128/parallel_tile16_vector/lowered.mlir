module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x16xf64>) : !llvm.array<1 x vector<16xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<16x1xf64>) : !llvm.array<16 x vector<1xf64>>
    %22 = llvm.mlir.constant(128 : index) : i64
    %23 = llvm.mlir.constant(64 : index) : i64
    %24 = llvm.mlir.constant(0 : index) : i64
    %25 = llvm.mlir.constant(1 : index) : i64
    %26 = llvm.mlir.constant(16 : index) : i64
    %27 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%24 : i64)
  ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb2
    %29 = llvm.icmp "slt" %28, %23 : i64
    llvm.cond_br %29, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %30 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %31 = llvm.getelementptr %30[%28] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %27, %31 : f64, !llvm.ptr
    %32 = llvm.add %28, %25  : i64
    llvm.br ^bb1(%32 : i64)
  ^bb3:  // pred: ^bb1
    %33 = llvm.mlir.constant(1 : index) : i64
    %34 = llvm.alloca %33 x !llvm.array<16 x vector<1xf64>> : (i64) -> !llvm.ptr
    %35 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %36 = llvm.insertvalue %34, %35[0] : !llvm.struct<(ptr, ptr, i64)> 
    %37 = llvm.insertvalue %34, %36[1] : !llvm.struct<(ptr, ptr, i64)> 
    %38 = llvm.mlir.constant(0 : index) : i64
    %39 = llvm.insertvalue %38, %37[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%24 : i64)
  ^bb4(%40: i64):  // 2 preds: ^bb3, ^bb11
    %41 = llvm.icmp "slt" %40, %23 : i64
    llvm.cond_br %41, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    %42 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %44 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %45 = llvm.insertvalue %42, %44[0] : !llvm.struct<(ptr, ptr, i64)> 
    %46 = llvm.insertvalue %43, %45[1] : !llvm.struct<(ptr, ptr, i64)> 
    %47 = llvm.mlir.constant(0 : index) : i64
    %48 = llvm.insertvalue %47, %46[2] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %50 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %51 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %52 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %54 = llvm.mul %40, %22  : i64
    %55 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %56 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %57 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %58 = llvm.insertvalue %55, %57[0] : !llvm.struct<(ptr, ptr, i64)> 
    %59 = llvm.insertvalue %56, %58[1] : !llvm.struct<(ptr, ptr, i64)> 
    %60 = llvm.mlir.constant(0 : index) : i64
    %61 = llvm.insertvalue %60, %59[2] : !llvm.struct<(ptr, ptr, i64)> 
    %62 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %63 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %64 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %65 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %66 = llvm.insertvalue %55, %65[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %67 = llvm.insertvalue %56, %66[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %68 = llvm.insertvalue %40, %67[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %69 = llvm.mlir.constant(16 : index) : i64
    %70 = llvm.insertvalue %69, %68[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %71 = llvm.mlir.constant(1 : index) : i64
    %72 = llvm.insertvalue %71, %70[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%24 : i64)
  ^bb6(%73: i64):  // 2 preds: ^bb5, ^bb10
    %74 = llvm.icmp "slt" %73, %22 : i64
    llvm.cond_br %74, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %75 = llvm.add %54, %73  : i64
    %76 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %77 = llvm.insertvalue %42, %76[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.insertvalue %43, %77[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.insertvalue %75, %78[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.mlir.constant(16 : index) : i64
    %81 = llvm.insertvalue %80, %79[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %82 = llvm.mlir.constant(128 : index) : i64
    %83 = llvm.insertvalue %82, %81[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %84 = llvm.mlir.constant(1 : index) : i64
    %85 = llvm.insertvalue %84, %83[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %86 = llvm.mlir.constant(1 : index) : i64
    %87 = llvm.insertvalue %86, %85[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %88 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %89 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %91 = llvm.insertvalue %88, %90[0] : !llvm.struct<(ptr, ptr, i64)> 
    %92 = llvm.insertvalue %89, %91[1] : !llvm.struct<(ptr, ptr, i64)> 
    %93 = llvm.mlir.constant(0 : index) : i64
    %94 = llvm.insertvalue %93, %92[2] : !llvm.struct<(ptr, ptr, i64)> 
    %95 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %98 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %99 = llvm.insertvalue %88, %98[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %100 = llvm.insertvalue %89, %99[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %101 = llvm.insertvalue %73, %100[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %102 = llvm.mlir.constant(1 : index) : i64
    %103 = llvm.insertvalue %102, %101[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %104 = llvm.mlir.constant(1 : index) : i64
    %105 = llvm.insertvalue %104, %103[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %106 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %107 = llvm.extractvalue %39[0] : !llvm.struct<(ptr, ptr, i64)> 
    %108 = llvm.insertvalue %107, %106[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %109 = llvm.extractvalue %39[1] : !llvm.struct<(ptr, ptr, i64)> 
    %110 = llvm.insertvalue %109, %108[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %111 = llvm.mlir.constant(0 : index) : i64
    %112 = llvm.insertvalue %111, %110[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %113 = llvm.mlir.constant(16 : index) : i64
    %114 = llvm.insertvalue %113, %112[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.mlir.constant(1 : index) : i64
    %116 = llvm.insertvalue %115, %114[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%24 : i64)
  ^bb8(%117: i64):  // 2 preds: ^bb7, ^bb9
    %118 = llvm.icmp "slt" %117, %26 : i64
    llvm.cond_br %118, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %119 = llvm.getelementptr %43[%75] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %120 = llvm.mlir.constant(128 : index) : i64
    %121 = llvm.mul %117, %120  : i64
    %122 = llvm.add %121, %24  : i64
    %123 = llvm.getelementptr %119[%122] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %124 = llvm.load %123 : !llvm.ptr -> f64
    %125 = llvm.mlir.undef : vector<1xf64>
    %126 = llvm.mlir.constant(0 : i32) : i32
    %127 = llvm.insertelement %124, %125[%126 : i32] : vector<1xf64>
    %128 = llvm.shufflevector %127, %125 [0] : vector<1xf64> 
    %129 = llvm.getelementptr %109[%117] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %128, %129 : vector<1xf64>, !llvm.ptr
    %130 = llvm.add %117, %25  : i64
    llvm.br ^bb8(%130 : i64)
  ^bb10:  // pred: ^bb8
    %131 = llvm.load %34 : !llvm.ptr -> !llvm.array<16 x vector<1xf64>>
    %132 = llvm.getelementptr %89[%73] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %133 = llvm.getelementptr %132[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %134 = llvm.load %133 : !llvm.ptr -> f64
    %135 = llvm.mlir.undef : vector<1xf64>
    %136 = llvm.mlir.constant(0 : i32) : i32
    %137 = llvm.insertelement %134, %135[%136 : i32] : vector<1xf64>
    %138 = llvm.shufflevector %137, %135 [0] : vector<1xf64> 
    %139 = llvm.insertvalue %138, %21[0] : !llvm.array<16 x vector<1xf64>> 
    %140 = llvm.insertvalue %138, %139[1] : !llvm.array<16 x vector<1xf64>> 
    %141 = llvm.insertvalue %138, %140[2] : !llvm.array<16 x vector<1xf64>> 
    %142 = llvm.insertvalue %138, %141[3] : !llvm.array<16 x vector<1xf64>> 
    %143 = llvm.insertvalue %138, %142[4] : !llvm.array<16 x vector<1xf64>> 
    %144 = llvm.insertvalue %138, %143[5] : !llvm.array<16 x vector<1xf64>> 
    %145 = llvm.insertvalue %138, %144[6] : !llvm.array<16 x vector<1xf64>> 
    %146 = llvm.insertvalue %138, %145[7] : !llvm.array<16 x vector<1xf64>> 
    %147 = llvm.insertvalue %138, %146[8] : !llvm.array<16 x vector<1xf64>> 
    %148 = llvm.insertvalue %138, %147[9] : !llvm.array<16 x vector<1xf64>> 
    %149 = llvm.insertvalue %138, %148[10] : !llvm.array<16 x vector<1xf64>> 
    %150 = llvm.insertvalue %138, %149[11] : !llvm.array<16 x vector<1xf64>> 
    %151 = llvm.insertvalue %138, %150[12] : !llvm.array<16 x vector<1xf64>> 
    %152 = llvm.insertvalue %138, %151[13] : !llvm.array<16 x vector<1xf64>> 
    %153 = llvm.insertvalue %138, %152[14] : !llvm.array<16 x vector<1xf64>> 
    %154 = llvm.insertvalue %138, %153[15] : !llvm.array<16 x vector<1xf64>> 
    %155 = llvm.extractvalue %72[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %156 = llvm.extractvalue %72[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %157 = llvm.getelementptr %155[%156] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %158 = llvm.getelementptr %157[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %159 = llvm.load %158 {alignment = 8 : i64} : !llvm.ptr -> vector<16xf64>
    %160 = llvm.mlir.undef : !llvm.array<16 x vector<1xf64>>
    %161 = llvm.extractvalue %131[0] : !llvm.array<16 x vector<1xf64>> 
    %162 = llvm.fmul %161, %138  : vector<1xf64>
    %163 = llvm.insertvalue %162, %160[0] : !llvm.array<16 x vector<1xf64>> 
    %164 = llvm.extractvalue %131[1] : !llvm.array<16 x vector<1xf64>> 
    %165 = llvm.fmul %164, %138  : vector<1xf64>
    %166 = llvm.insertvalue %165, %163[1] : !llvm.array<16 x vector<1xf64>> 
    %167 = llvm.extractvalue %131[2] : !llvm.array<16 x vector<1xf64>> 
    %168 = llvm.fmul %167, %138  : vector<1xf64>
    %169 = llvm.insertvalue %168, %166[2] : !llvm.array<16 x vector<1xf64>> 
    %170 = llvm.extractvalue %131[3] : !llvm.array<16 x vector<1xf64>> 
    %171 = llvm.fmul %170, %138  : vector<1xf64>
    %172 = llvm.insertvalue %171, %169[3] : !llvm.array<16 x vector<1xf64>> 
    %173 = llvm.extractvalue %131[4] : !llvm.array<16 x vector<1xf64>> 
    %174 = llvm.fmul %173, %138  : vector<1xf64>
    %175 = llvm.insertvalue %174, %172[4] : !llvm.array<16 x vector<1xf64>> 
    %176 = llvm.extractvalue %131[5] : !llvm.array<16 x vector<1xf64>> 
    %177 = llvm.fmul %176, %138  : vector<1xf64>
    %178 = llvm.insertvalue %177, %175[5] : !llvm.array<16 x vector<1xf64>> 
    %179 = llvm.extractvalue %131[6] : !llvm.array<16 x vector<1xf64>> 
    %180 = llvm.fmul %179, %138  : vector<1xf64>
    %181 = llvm.insertvalue %180, %178[6] : !llvm.array<16 x vector<1xf64>> 
    %182 = llvm.extractvalue %131[7] : !llvm.array<16 x vector<1xf64>> 
    %183 = llvm.fmul %182, %138  : vector<1xf64>
    %184 = llvm.insertvalue %183, %181[7] : !llvm.array<16 x vector<1xf64>> 
    %185 = llvm.extractvalue %131[8] : !llvm.array<16 x vector<1xf64>> 
    %186 = llvm.fmul %185, %138  : vector<1xf64>
    %187 = llvm.insertvalue %186, %184[8] : !llvm.array<16 x vector<1xf64>> 
    %188 = llvm.extractvalue %131[9] : !llvm.array<16 x vector<1xf64>> 
    %189 = llvm.fmul %188, %138  : vector<1xf64>
    %190 = llvm.insertvalue %189, %187[9] : !llvm.array<16 x vector<1xf64>> 
    %191 = llvm.extractvalue %131[10] : !llvm.array<16 x vector<1xf64>> 
    %192 = llvm.fmul %191, %138  : vector<1xf64>
    %193 = llvm.insertvalue %192, %190[10] : !llvm.array<16 x vector<1xf64>> 
    %194 = llvm.extractvalue %131[11] : !llvm.array<16 x vector<1xf64>> 
    %195 = llvm.fmul %194, %138  : vector<1xf64>
    %196 = llvm.insertvalue %195, %193[11] : !llvm.array<16 x vector<1xf64>> 
    %197 = llvm.extractvalue %131[12] : !llvm.array<16 x vector<1xf64>> 
    %198 = llvm.fmul %197, %138  : vector<1xf64>
    %199 = llvm.insertvalue %198, %196[12] : !llvm.array<16 x vector<1xf64>> 
    %200 = llvm.extractvalue %131[13] : !llvm.array<16 x vector<1xf64>> 
    %201 = llvm.fmul %200, %138  : vector<1xf64>
    %202 = llvm.insertvalue %201, %199[13] : !llvm.array<16 x vector<1xf64>> 
    %203 = llvm.extractvalue %131[14] : !llvm.array<16 x vector<1xf64>> 
    %204 = llvm.fmul %203, %138  : vector<1xf64>
    %205 = llvm.insertvalue %204, %202[14] : !llvm.array<16 x vector<1xf64>> 
    %206 = llvm.extractvalue %131[15] : !llvm.array<16 x vector<1xf64>> 
    %207 = llvm.fmul %206, %138  : vector<1xf64>
    %208 = llvm.insertvalue %207, %205[15] : !llvm.array<16 x vector<1xf64>> 
    %209 = llvm.extractvalue %208[0] : !llvm.array<16 x vector<1xf64>> 
    %210 = llvm.mlir.constant(0 : i64) : i64
    %211 = llvm.extractelement %209[%210 : i64] : vector<1xf64>
    %212 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<16xf64>> 
    %213 = llvm.mlir.constant(0 : i64) : i64
    %214 = llvm.insertelement %211, %212[%213 : i64] : vector<16xf64>
    %215 = llvm.insertvalue %214, %20[0] : !llvm.array<1 x vector<16xf64>> 
    %216 = llvm.extractvalue %208[1] : !llvm.array<16 x vector<1xf64>> 
    %217 = llvm.mlir.constant(0 : i64) : i64
    %218 = llvm.extractelement %216[%217 : i64] : vector<1xf64>
    %219 = llvm.mlir.constant(1 : i64) : i64
    %220 = llvm.insertelement %218, %214[%219 : i64] : vector<16xf64>
    %221 = llvm.insertvalue %220, %215[0] : !llvm.array<1 x vector<16xf64>> 
    %222 = llvm.extractvalue %208[2] : !llvm.array<16 x vector<1xf64>> 
    %223 = llvm.mlir.constant(0 : i64) : i64
    %224 = llvm.extractelement %222[%223 : i64] : vector<1xf64>
    %225 = llvm.mlir.constant(2 : i64) : i64
    %226 = llvm.insertelement %224, %220[%225 : i64] : vector<16xf64>
    %227 = llvm.insertvalue %226, %221[0] : !llvm.array<1 x vector<16xf64>> 
    %228 = llvm.extractvalue %208[3] : !llvm.array<16 x vector<1xf64>> 
    %229 = llvm.mlir.constant(0 : i64) : i64
    %230 = llvm.extractelement %228[%229 : i64] : vector<1xf64>
    %231 = llvm.mlir.constant(3 : i64) : i64
    %232 = llvm.insertelement %230, %226[%231 : i64] : vector<16xf64>
    %233 = llvm.insertvalue %232, %227[0] : !llvm.array<1 x vector<16xf64>> 
    %234 = llvm.extractvalue %208[4] : !llvm.array<16 x vector<1xf64>> 
    %235 = llvm.mlir.constant(0 : i64) : i64
    %236 = llvm.extractelement %234[%235 : i64] : vector<1xf64>
    %237 = llvm.mlir.constant(4 : i64) : i64
    %238 = llvm.insertelement %236, %232[%237 : i64] : vector<16xf64>
    %239 = llvm.insertvalue %238, %233[0] : !llvm.array<1 x vector<16xf64>> 
    %240 = llvm.extractvalue %208[5] : !llvm.array<16 x vector<1xf64>> 
    %241 = llvm.mlir.constant(0 : i64) : i64
    %242 = llvm.extractelement %240[%241 : i64] : vector<1xf64>
    %243 = llvm.mlir.constant(5 : i64) : i64
    %244 = llvm.insertelement %242, %238[%243 : i64] : vector<16xf64>
    %245 = llvm.insertvalue %244, %239[0] : !llvm.array<1 x vector<16xf64>> 
    %246 = llvm.extractvalue %208[6] : !llvm.array<16 x vector<1xf64>> 
    %247 = llvm.mlir.constant(0 : i64) : i64
    %248 = llvm.extractelement %246[%247 : i64] : vector<1xf64>
    %249 = llvm.mlir.constant(6 : i64) : i64
    %250 = llvm.insertelement %248, %244[%249 : i64] : vector<16xf64>
    %251 = llvm.insertvalue %250, %245[0] : !llvm.array<1 x vector<16xf64>> 
    %252 = llvm.extractvalue %208[7] : !llvm.array<16 x vector<1xf64>> 
    %253 = llvm.mlir.constant(0 : i64) : i64
    %254 = llvm.extractelement %252[%253 : i64] : vector<1xf64>
    %255 = llvm.mlir.constant(7 : i64) : i64
    %256 = llvm.insertelement %254, %250[%255 : i64] : vector<16xf64>
    %257 = llvm.insertvalue %256, %251[0] : !llvm.array<1 x vector<16xf64>> 
    %258 = llvm.extractvalue %208[8] : !llvm.array<16 x vector<1xf64>> 
    %259 = llvm.mlir.constant(0 : i64) : i64
    %260 = llvm.extractelement %258[%259 : i64] : vector<1xf64>
    %261 = llvm.mlir.constant(8 : i64) : i64
    %262 = llvm.insertelement %260, %256[%261 : i64] : vector<16xf64>
    %263 = llvm.insertvalue %262, %257[0] : !llvm.array<1 x vector<16xf64>> 
    %264 = llvm.extractvalue %208[9] : !llvm.array<16 x vector<1xf64>> 
    %265 = llvm.mlir.constant(0 : i64) : i64
    %266 = llvm.extractelement %264[%265 : i64] : vector<1xf64>
    %267 = llvm.mlir.constant(9 : i64) : i64
    %268 = llvm.insertelement %266, %262[%267 : i64] : vector<16xf64>
    %269 = llvm.insertvalue %268, %263[0] : !llvm.array<1 x vector<16xf64>> 
    %270 = llvm.extractvalue %208[10] : !llvm.array<16 x vector<1xf64>> 
    %271 = llvm.mlir.constant(0 : i64) : i64
    %272 = llvm.extractelement %270[%271 : i64] : vector<1xf64>
    %273 = llvm.mlir.constant(10 : i64) : i64
    %274 = llvm.insertelement %272, %268[%273 : i64] : vector<16xf64>
    %275 = llvm.insertvalue %274, %269[0] : !llvm.array<1 x vector<16xf64>> 
    %276 = llvm.extractvalue %208[11] : !llvm.array<16 x vector<1xf64>> 
    %277 = llvm.mlir.constant(0 : i64) : i64
    %278 = llvm.extractelement %276[%277 : i64] : vector<1xf64>
    %279 = llvm.mlir.constant(11 : i64) : i64
    %280 = llvm.insertelement %278, %274[%279 : i64] : vector<16xf64>
    %281 = llvm.insertvalue %280, %275[0] : !llvm.array<1 x vector<16xf64>> 
    %282 = llvm.extractvalue %208[12] : !llvm.array<16 x vector<1xf64>> 
    %283 = llvm.mlir.constant(0 : i64) : i64
    %284 = llvm.extractelement %282[%283 : i64] : vector<1xf64>
    %285 = llvm.mlir.constant(12 : i64) : i64
    %286 = llvm.insertelement %284, %280[%285 : i64] : vector<16xf64>
    %287 = llvm.insertvalue %286, %281[0] : !llvm.array<1 x vector<16xf64>> 
    %288 = llvm.extractvalue %208[13] : !llvm.array<16 x vector<1xf64>> 
    %289 = llvm.mlir.constant(0 : i64) : i64
    %290 = llvm.extractelement %288[%289 : i64] : vector<1xf64>
    %291 = llvm.mlir.constant(13 : i64) : i64
    %292 = llvm.insertelement %290, %286[%291 : i64] : vector<16xf64>
    %293 = llvm.insertvalue %292, %287[0] : !llvm.array<1 x vector<16xf64>> 
    %294 = llvm.extractvalue %208[14] : !llvm.array<16 x vector<1xf64>> 
    %295 = llvm.mlir.constant(0 : i64) : i64
    %296 = llvm.extractelement %294[%295 : i64] : vector<1xf64>
    %297 = llvm.mlir.constant(14 : i64) : i64
    %298 = llvm.insertelement %296, %292[%297 : i64] : vector<16xf64>
    %299 = llvm.insertvalue %298, %293[0] : !llvm.array<1 x vector<16xf64>> 
    %300 = llvm.extractvalue %208[15] : !llvm.array<16 x vector<1xf64>> 
    %301 = llvm.mlir.constant(0 : i64) : i64
    %302 = llvm.extractelement %300[%301 : i64] : vector<1xf64>
    %303 = llvm.mlir.constant(15 : i64) : i64
    %304 = llvm.insertelement %302, %298[%303 : i64] : vector<16xf64>
    %305 = llvm.insertvalue %304, %299[0] : !llvm.array<1 x vector<16xf64>> 
    %306 = llvm.fadd %304, %159  : vector<16xf64>
    %307 = llvm.extractvalue %72[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %308 = llvm.extractvalue %72[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %309 = llvm.getelementptr %307[%308] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %310 = llvm.getelementptr %309[%24] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %306, %310 {alignment = 8 : i64} : vector<16xf64>, !llvm.ptr
    %311 = llvm.add %73, %25  : i64
    llvm.br ^bb6(%311 : i64)
  ^bb11:  // pred: ^bb6
    %312 = llvm.add %40, %26  : i64
    llvm.br ^bb4(%312 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
