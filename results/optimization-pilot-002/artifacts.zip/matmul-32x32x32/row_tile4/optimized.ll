; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(8192) %15, i8 0, i64 8192, i1 false)
  %scevgep10 = getelementptr i8, ptr %8, i64 8192
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %355
  %indvar = phi i64 [ 0, %.preheader4.preheader ], [ %indvar.next, %355 ]
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %356, %355 ]
  %22 = shl nuw nsw i64 %indvar, 10
  %scevgep = getelementptr i8, ptr %15, i64 %22
  %23 = add nuw i64 %22, 1024
  %scevgep7 = getelementptr i8, ptr %15, i64 %23
  %scevgep8 = getelementptr i8, ptr %1, i64 %22
  %scevgep9 = getelementptr i8, ptr %1, i64 %23
  %24 = shl nuw nsw i64 %21, 5
  %25 = getelementptr double, ptr %1, i64 %24
  %26 = getelementptr double, ptr %15, i64 %24
  %bound0 = icmp ult ptr %scevgep, %scevgep9
  %bound1 = icmp ult ptr %scevgep8, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %middle.block
  %27 = phi i64 [ 0, %.preheader4 ], [ %354, %middle.block ]
  %28 = shl i64 %27, 5
  %29 = getelementptr double, ptr %26, i64 %28
  %30 = getelementptr double, ptr %25, i64 %28
  %31 = or disjoint i64 %28, 1
  %32 = getelementptr double, ptr %25, i64 %31
  %33 = or disjoint i64 %28, 2
  %34 = getelementptr double, ptr %25, i64 %33
  %35 = or disjoint i64 %28, 3
  %36 = getelementptr double, ptr %25, i64 %35
  %37 = or disjoint i64 %28, 4
  %38 = getelementptr double, ptr %25, i64 %37
  %39 = or disjoint i64 %28, 5
  %40 = getelementptr double, ptr %25, i64 %39
  %41 = or disjoint i64 %28, 6
  %42 = getelementptr double, ptr %25, i64 %41
  %43 = or disjoint i64 %28, 7
  %44 = getelementptr double, ptr %25, i64 %43
  %45 = or disjoint i64 %28, 8
  %46 = getelementptr double, ptr %25, i64 %45
  %47 = or disjoint i64 %28, 9
  %48 = getelementptr double, ptr %25, i64 %47
  %49 = or disjoint i64 %28, 10
  %50 = getelementptr double, ptr %25, i64 %49
  %51 = or disjoint i64 %28, 11
  %52 = getelementptr double, ptr %25, i64 %51
  %53 = or disjoint i64 %28, 12
  %54 = getelementptr double, ptr %25, i64 %53
  %55 = or disjoint i64 %28, 13
  %56 = getelementptr double, ptr %25, i64 %55
  %57 = or disjoint i64 %28, 14
  %58 = getelementptr double, ptr %25, i64 %57
  %59 = or disjoint i64 %28, 15
  %60 = getelementptr double, ptr %25, i64 %59
  %61 = or disjoint i64 %28, 16
  %62 = getelementptr double, ptr %25, i64 %61
  %63 = or disjoint i64 %28, 17
  %64 = getelementptr double, ptr %25, i64 %63
  %65 = or disjoint i64 %28, 18
  %66 = getelementptr double, ptr %25, i64 %65
  %67 = or disjoint i64 %28, 19
  %68 = getelementptr double, ptr %25, i64 %67
  %69 = or disjoint i64 %28, 20
  %70 = getelementptr double, ptr %25, i64 %69
  %71 = or disjoint i64 %28, 21
  %72 = getelementptr double, ptr %25, i64 %71
  %73 = or disjoint i64 %28, 22
  %74 = getelementptr double, ptr %25, i64 %73
  %75 = or disjoint i64 %28, 23
  %76 = getelementptr double, ptr %25, i64 %75
  %77 = or disjoint i64 %28, 24
  %78 = getelementptr double, ptr %25, i64 %77
  %79 = or disjoint i64 %28, 25
  %80 = getelementptr double, ptr %25, i64 %79
  %81 = or disjoint i64 %28, 26
  %82 = getelementptr double, ptr %25, i64 %81
  %83 = or disjoint i64 %28, 27
  %84 = getelementptr double, ptr %25, i64 %83
  %85 = or disjoint i64 %28, 28
  %86 = getelementptr double, ptr %25, i64 %85
  %87 = or disjoint i64 %28, 29
  %88 = getelementptr double, ptr %25, i64 %87
  %89 = or disjoint i64 %28, 30
  %90 = getelementptr double, ptr %25, i64 %89
  %91 = or disjoint i64 %28, 31
  %92 = getelementptr double, ptr %25, i64 %91
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %93 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %102 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %102, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %103 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %103, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %104 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %104, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %105, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %106 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %106, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = load double, ptr %58, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %107, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %108 = load double, ptr %60, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %108, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %109 = load double, ptr %62, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %109, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = load double, ptr %64, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %110, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %111 = load double, ptr %66, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %111, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %112 = load double, ptr %68, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %112, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = load double, ptr %70, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %113, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = load double, ptr %72, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %114, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %115 = load double, ptr %74, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %115, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %116 = load double, ptr %76, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %116, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  %117 = load double, ptr %78, align 8, !alias.scope !1
  %broadcast.splatinsert85 = insertelement <4 x double> poison, double %117, i64 0
  %broadcast.splat86 = shufflevector <4 x double> %broadcast.splatinsert85, <4 x double> poison, <4 x i32> zeroinitializer
  %118 = load double, ptr %80, align 8, !alias.scope !1
  %broadcast.splatinsert88 = insertelement <4 x double> poison, double %118, i64 0
  %broadcast.splat89 = shufflevector <4 x double> %broadcast.splatinsert88, <4 x double> poison, <4 x i32> zeroinitializer
  %119 = load double, ptr %82, align 8, !alias.scope !1
  %broadcast.splatinsert91 = insertelement <4 x double> poison, double %119, i64 0
  %broadcast.splat92 = shufflevector <4 x double> %broadcast.splatinsert91, <4 x double> poison, <4 x i32> zeroinitializer
  %120 = load double, ptr %84, align 8, !alias.scope !1
  %broadcast.splatinsert94 = insertelement <4 x double> poison, double %120, i64 0
  %broadcast.splat95 = shufflevector <4 x double> %broadcast.splatinsert94, <4 x double> poison, <4 x i32> zeroinitializer
  %121 = load double, ptr %86, align 8, !alias.scope !1
  %broadcast.splatinsert97 = insertelement <4 x double> poison, double %121, i64 0
  %broadcast.splat98 = shufflevector <4 x double> %broadcast.splatinsert97, <4 x double> poison, <4 x i32> zeroinitializer
  %122 = load double, ptr %88, align 8, !alias.scope !1
  %broadcast.splatinsert100 = insertelement <4 x double> poison, double %122, i64 0
  %broadcast.splat101 = shufflevector <4 x double> %broadcast.splatinsert100, <4 x double> poison, <4 x i32> zeroinitializer
  %123 = load double, ptr %90, align 8, !alias.scope !1
  %broadcast.splatinsert103 = insertelement <4 x double> poison, double %123, i64 0
  %broadcast.splat104 = shufflevector <4 x double> %broadcast.splatinsert103, <4 x double> poison, <4 x i32> zeroinitializer
  %124 = load double, ptr %92, align 8, !alias.scope !1
  %broadcast.splatinsert106 = insertelement <4 x double> poison, double %124, i64 0
  %broadcast.splat107 = shufflevector <4 x double> %broadcast.splatinsert106, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %125 = getelementptr double, ptr %8, i64 %index
  %126 = getelementptr double, ptr %29, i64 %index
  %wide.load = load <4 x double>, ptr %126, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %125, align 8, !alias.scope !8
  %127 = fmul <4 x double> %broadcast.splat, %wide.load14
  %128 = fadd <4 x double> %wide.load, %127
  store <4 x double> %128, ptr %126, align 8, !alias.scope !4, !noalias !6
  %129 = getelementptr double, ptr %125, i64 32
  %wide.load15 = load <4 x double>, ptr %129, align 8, !alias.scope !8
  %130 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %131 = fadd <4 x double> %128, %130
  store <4 x double> %131, ptr %126, align 8, !alias.scope !4, !noalias !6
  %132 = getelementptr double, ptr %125, i64 64
  %wide.load18 = load <4 x double>, ptr %132, align 8, !alias.scope !8
  %133 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %134 = fadd <4 x double> %131, %133
  store <4 x double> %134, ptr %126, align 8, !alias.scope !4, !noalias !6
  %135 = getelementptr double, ptr %125, i64 96
  %wide.load21 = load <4 x double>, ptr %135, align 8, !alias.scope !8
  %136 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %137 = fadd <4 x double> %134, %136
  store <4 x double> %137, ptr %126, align 8, !alias.scope !4, !noalias !6
  %138 = getelementptr double, ptr %125, i64 128
  %wide.load24 = load <4 x double>, ptr %138, align 8, !alias.scope !8
  %139 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %140 = fadd <4 x double> %137, %139
  store <4 x double> %140, ptr %126, align 8, !alias.scope !4, !noalias !6
  %141 = getelementptr double, ptr %125, i64 160
  %wide.load27 = load <4 x double>, ptr %141, align 8, !alias.scope !8
  %142 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %143 = fadd <4 x double> %140, %142
  store <4 x double> %143, ptr %126, align 8, !alias.scope !4, !noalias !6
  %144 = getelementptr double, ptr %125, i64 192
  %wide.load30 = load <4 x double>, ptr %144, align 8, !alias.scope !8
  %145 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %146 = fadd <4 x double> %143, %145
  store <4 x double> %146, ptr %126, align 8, !alias.scope !4, !noalias !6
  %147 = getelementptr double, ptr %125, i64 224
  %wide.load33 = load <4 x double>, ptr %147, align 8, !alias.scope !8
  %148 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %149 = fadd <4 x double> %146, %148
  store <4 x double> %149, ptr %126, align 8, !alias.scope !4, !noalias !6
  %150 = getelementptr double, ptr %125, i64 256
  %wide.load36 = load <4 x double>, ptr %150, align 8, !alias.scope !8
  %151 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %152 = fadd <4 x double> %149, %151
  store <4 x double> %152, ptr %126, align 8, !alias.scope !4, !noalias !6
  %153 = getelementptr double, ptr %125, i64 288
  %wide.load39 = load <4 x double>, ptr %153, align 8, !alias.scope !8
  %154 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %155 = fadd <4 x double> %152, %154
  store <4 x double> %155, ptr %126, align 8, !alias.scope !4, !noalias !6
  %156 = getelementptr double, ptr %125, i64 320
  %wide.load42 = load <4 x double>, ptr %156, align 8, !alias.scope !8
  %157 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %158 = fadd <4 x double> %155, %157
  store <4 x double> %158, ptr %126, align 8, !alias.scope !4, !noalias !6
  %159 = getelementptr double, ptr %125, i64 352
  %wide.load45 = load <4 x double>, ptr %159, align 8, !alias.scope !8
  %160 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %161 = fadd <4 x double> %158, %160
  store <4 x double> %161, ptr %126, align 8, !alias.scope !4, !noalias !6
  %162 = getelementptr double, ptr %125, i64 384
  %wide.load48 = load <4 x double>, ptr %162, align 8, !alias.scope !8
  %163 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %164 = fadd <4 x double> %161, %163
  store <4 x double> %164, ptr %126, align 8, !alias.scope !4, !noalias !6
  %165 = getelementptr double, ptr %125, i64 416
  %wide.load51 = load <4 x double>, ptr %165, align 8, !alias.scope !8
  %166 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %167 = fadd <4 x double> %164, %166
  store <4 x double> %167, ptr %126, align 8, !alias.scope !4, !noalias !6
  %168 = getelementptr double, ptr %125, i64 448
  %wide.load54 = load <4 x double>, ptr %168, align 8, !alias.scope !8
  %169 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %170 = fadd <4 x double> %167, %169
  store <4 x double> %170, ptr %126, align 8, !alias.scope !4, !noalias !6
  %171 = getelementptr double, ptr %125, i64 480
  %wide.load57 = load <4 x double>, ptr %171, align 8, !alias.scope !8
  %172 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %173 = fadd <4 x double> %170, %172
  store <4 x double> %173, ptr %126, align 8, !alias.scope !4, !noalias !6
  %174 = getelementptr double, ptr %125, i64 512
  %wide.load60 = load <4 x double>, ptr %174, align 8, !alias.scope !8
  %175 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %176 = fadd <4 x double> %173, %175
  store <4 x double> %176, ptr %126, align 8, !alias.scope !4, !noalias !6
  %177 = getelementptr double, ptr %125, i64 544
  %wide.load63 = load <4 x double>, ptr %177, align 8, !alias.scope !8
  %178 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %179 = fadd <4 x double> %176, %178
  store <4 x double> %179, ptr %126, align 8, !alias.scope !4, !noalias !6
  %180 = getelementptr double, ptr %125, i64 576
  %wide.load66 = load <4 x double>, ptr %180, align 8, !alias.scope !8
  %181 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %182 = fadd <4 x double> %179, %181
  store <4 x double> %182, ptr %126, align 8, !alias.scope !4, !noalias !6
  %183 = getelementptr double, ptr %125, i64 608
  %wide.load69 = load <4 x double>, ptr %183, align 8, !alias.scope !8
  %184 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %185 = fadd <4 x double> %182, %184
  store <4 x double> %185, ptr %126, align 8, !alias.scope !4, !noalias !6
  %186 = getelementptr double, ptr %125, i64 640
  %wide.load72 = load <4 x double>, ptr %186, align 8, !alias.scope !8
  %187 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %188 = fadd <4 x double> %185, %187
  store <4 x double> %188, ptr %126, align 8, !alias.scope !4, !noalias !6
  %189 = getelementptr double, ptr %125, i64 672
  %wide.load75 = load <4 x double>, ptr %189, align 8, !alias.scope !8
  %190 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %191 = fadd <4 x double> %188, %190
  store <4 x double> %191, ptr %126, align 8, !alias.scope !4, !noalias !6
  %192 = getelementptr double, ptr %125, i64 704
  %wide.load78 = load <4 x double>, ptr %192, align 8, !alias.scope !8
  %193 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %194 = fadd <4 x double> %191, %193
  store <4 x double> %194, ptr %126, align 8, !alias.scope !4, !noalias !6
  %195 = getelementptr double, ptr %125, i64 736
  %wide.load81 = load <4 x double>, ptr %195, align 8, !alias.scope !8
  %196 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %197 = fadd <4 x double> %194, %196
  store <4 x double> %197, ptr %126, align 8, !alias.scope !4, !noalias !6
  %198 = getelementptr double, ptr %125, i64 768
  %wide.load84 = load <4 x double>, ptr %198, align 8, !alias.scope !8
  %199 = fmul <4 x double> %broadcast.splat86, %wide.load84
  %200 = fadd <4 x double> %197, %199
  store <4 x double> %200, ptr %126, align 8, !alias.scope !4, !noalias !6
  %201 = getelementptr double, ptr %125, i64 800
  %wide.load87 = load <4 x double>, ptr %201, align 8, !alias.scope !8
  %202 = fmul <4 x double> %broadcast.splat89, %wide.load87
  %203 = fadd <4 x double> %200, %202
  store <4 x double> %203, ptr %126, align 8, !alias.scope !4, !noalias !6
  %204 = getelementptr double, ptr %125, i64 832
  %wide.load90 = load <4 x double>, ptr %204, align 8, !alias.scope !8
  %205 = fmul <4 x double> %broadcast.splat92, %wide.load90
  %206 = fadd <4 x double> %203, %205
  store <4 x double> %206, ptr %126, align 8, !alias.scope !4, !noalias !6
  %207 = getelementptr double, ptr %125, i64 864
  %wide.load93 = load <4 x double>, ptr %207, align 8, !alias.scope !8
  %208 = fmul <4 x double> %broadcast.splat95, %wide.load93
  %209 = fadd <4 x double> %206, %208
  store <4 x double> %209, ptr %126, align 8, !alias.scope !4, !noalias !6
  %210 = getelementptr double, ptr %125, i64 896
  %wide.load96 = load <4 x double>, ptr %210, align 8, !alias.scope !8
  %211 = fmul <4 x double> %broadcast.splat98, %wide.load96
  %212 = fadd <4 x double> %209, %211
  store <4 x double> %212, ptr %126, align 8, !alias.scope !4, !noalias !6
  %213 = getelementptr double, ptr %125, i64 928
  %wide.load99 = load <4 x double>, ptr %213, align 8, !alias.scope !8
  %214 = fmul <4 x double> %broadcast.splat101, %wide.load99
  %215 = fadd <4 x double> %212, %214
  store <4 x double> %215, ptr %126, align 8, !alias.scope !4, !noalias !6
  %216 = getelementptr double, ptr %125, i64 960
  %wide.load102 = load <4 x double>, ptr %216, align 8, !alias.scope !8
  %217 = fmul <4 x double> %broadcast.splat104, %wide.load102
  %218 = fadd <4 x double> %215, %217
  store <4 x double> %218, ptr %126, align 8, !alias.scope !4, !noalias !6
  %219 = getelementptr double, ptr %125, i64 992
  %wide.load105 = load <4 x double>, ptr %219, align 8, !alias.scope !8
  %220 = fmul <4 x double> %broadcast.splat107, %wide.load105
  %221 = fadd <4 x double> %218, %220
  store <4 x double> %221, ptr %126, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %222 = icmp eq i64 %index.next, 32
  br i1 %222, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %223 = phi i64 [ %353, %.preheader ], [ 0, %.preheader3 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %223
  %224 = getelementptr double, ptr %29, i64 %223
  %.promoted = load double, ptr %224, align 8
  %225 = load double, ptr %30, align 8
  %226 = load double, ptr %invariant.gep, align 8
  %227 = fmul double %225, %226
  %228 = fadd double %.promoted, %227
  store double %228, ptr %224, align 8
  %229 = load double, ptr %32, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 32
  %230 = load double, ptr %gep.1, align 8
  %231 = fmul double %229, %230
  %232 = fadd double %228, %231
  store double %232, ptr %224, align 8
  %233 = load double, ptr %34, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 64
  %234 = load double, ptr %gep.2, align 8
  %235 = fmul double %233, %234
  %236 = fadd double %232, %235
  store double %236, ptr %224, align 8
  %237 = load double, ptr %36, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 96
  %238 = load double, ptr %gep.3, align 8
  %239 = fmul double %237, %238
  %240 = fadd double %236, %239
  store double %240, ptr %224, align 8
  %241 = load double, ptr %38, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 128
  %242 = load double, ptr %gep.4, align 8
  %243 = fmul double %241, %242
  %244 = fadd double %240, %243
  store double %244, ptr %224, align 8
  %245 = load double, ptr %40, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 160
  %246 = load double, ptr %gep.5, align 8
  %247 = fmul double %245, %246
  %248 = fadd double %244, %247
  store double %248, ptr %224, align 8
  %249 = load double, ptr %42, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 192
  %250 = load double, ptr %gep.6, align 8
  %251 = fmul double %249, %250
  %252 = fadd double %248, %251
  store double %252, ptr %224, align 8
  %253 = load double, ptr %44, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 224
  %254 = load double, ptr %gep.7, align 8
  %255 = fmul double %253, %254
  %256 = fadd double %252, %255
  store double %256, ptr %224, align 8
  %257 = load double, ptr %46, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 256
  %258 = load double, ptr %gep.8, align 8
  %259 = fmul double %257, %258
  %260 = fadd double %256, %259
  store double %260, ptr %224, align 8
  %261 = load double, ptr %48, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 288
  %262 = load double, ptr %gep.9, align 8
  %263 = fmul double %261, %262
  %264 = fadd double %260, %263
  store double %264, ptr %224, align 8
  %265 = load double, ptr %50, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 320
  %266 = load double, ptr %gep.10, align 8
  %267 = fmul double %265, %266
  %268 = fadd double %264, %267
  store double %268, ptr %224, align 8
  %269 = load double, ptr %52, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 352
  %270 = load double, ptr %gep.11, align 8
  %271 = fmul double %269, %270
  %272 = fadd double %268, %271
  store double %272, ptr %224, align 8
  %273 = load double, ptr %54, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 384
  %274 = load double, ptr %gep.12, align 8
  %275 = fmul double %273, %274
  %276 = fadd double %272, %275
  store double %276, ptr %224, align 8
  %277 = load double, ptr %56, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 416
  %278 = load double, ptr %gep.13, align 8
  %279 = fmul double %277, %278
  %280 = fadd double %276, %279
  store double %280, ptr %224, align 8
  %281 = load double, ptr %58, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 448
  %282 = load double, ptr %gep.14, align 8
  %283 = fmul double %281, %282
  %284 = fadd double %280, %283
  store double %284, ptr %224, align 8
  %285 = load double, ptr %60, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 480
  %286 = load double, ptr %gep.15, align 8
  %287 = fmul double %285, %286
  %288 = fadd double %284, %287
  store double %288, ptr %224, align 8
  %289 = load double, ptr %62, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 512
  %290 = load double, ptr %gep.16, align 8
  %291 = fmul double %289, %290
  %292 = fadd double %288, %291
  store double %292, ptr %224, align 8
  %293 = load double, ptr %64, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 544
  %294 = load double, ptr %gep.17, align 8
  %295 = fmul double %293, %294
  %296 = fadd double %292, %295
  store double %296, ptr %224, align 8
  %297 = load double, ptr %66, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 576
  %298 = load double, ptr %gep.18, align 8
  %299 = fmul double %297, %298
  %300 = fadd double %296, %299
  store double %300, ptr %224, align 8
  %301 = load double, ptr %68, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 608
  %302 = load double, ptr %gep.19, align 8
  %303 = fmul double %301, %302
  %304 = fadd double %300, %303
  store double %304, ptr %224, align 8
  %305 = load double, ptr %70, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 640
  %306 = load double, ptr %gep.20, align 8
  %307 = fmul double %305, %306
  %308 = fadd double %304, %307
  store double %308, ptr %224, align 8
  %309 = load double, ptr %72, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 672
  %310 = load double, ptr %gep.21, align 8
  %311 = fmul double %309, %310
  %312 = fadd double %308, %311
  store double %312, ptr %224, align 8
  %313 = load double, ptr %74, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 704
  %314 = load double, ptr %gep.22, align 8
  %315 = fmul double %313, %314
  %316 = fadd double %312, %315
  store double %316, ptr %224, align 8
  %317 = load double, ptr %76, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 736
  %318 = load double, ptr %gep.23, align 8
  %319 = fmul double %317, %318
  %320 = fadd double %316, %319
  store double %320, ptr %224, align 8
  %321 = load double, ptr %78, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 768
  %322 = load double, ptr %gep.24, align 8
  %323 = fmul double %321, %322
  %324 = fadd double %320, %323
  store double %324, ptr %224, align 8
  %325 = load double, ptr %80, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 800
  %326 = load double, ptr %gep.25, align 8
  %327 = fmul double %325, %326
  %328 = fadd double %324, %327
  store double %328, ptr %224, align 8
  %329 = load double, ptr %82, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 832
  %330 = load double, ptr %gep.26, align 8
  %331 = fmul double %329, %330
  %332 = fadd double %328, %331
  store double %332, ptr %224, align 8
  %333 = load double, ptr %84, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 864
  %334 = load double, ptr %gep.27, align 8
  %335 = fmul double %333, %334
  %336 = fadd double %332, %335
  store double %336, ptr %224, align 8
  %337 = load double, ptr %86, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 896
  %338 = load double, ptr %gep.28, align 8
  %339 = fmul double %337, %338
  %340 = fadd double %336, %339
  store double %340, ptr %224, align 8
  %341 = load double, ptr %88, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 928
  %342 = load double, ptr %gep.29, align 8
  %343 = fmul double %341, %342
  %344 = fadd double %340, %343
  store double %344, ptr %224, align 8
  %345 = load double, ptr %90, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 960
  %346 = load double, ptr %gep.30, align 8
  %347 = fmul double %345, %346
  %348 = fadd double %344, %347
  store double %348, ptr %224, align 8
  %349 = load double, ptr %92, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 992
  %350 = load double, ptr %gep.31, align 8
  %351 = fmul double %349, %350
  %352 = fadd double %348, %351
  store double %352, ptr %224, align 8
  %353 = add nuw nsw i64 %223, 1
  %exitcond.not = icmp eq i64 %353, 32
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %354 = add nuw nsw i64 %27, 1
  %exitcond6.not = icmp eq i64 %354, 4
  br i1 %exitcond6.not, label %355, label %.preheader3

355:                                              ; preds = %middle.block
  %356 = add nuw nsw i64 %21, 4
  %357 = icmp ult i64 %21, 28
  %indvar.next = add i64 %indvar, 1
  br i1 %357, label %.preheader4, label %358

358:                                              ; preds = %355
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
