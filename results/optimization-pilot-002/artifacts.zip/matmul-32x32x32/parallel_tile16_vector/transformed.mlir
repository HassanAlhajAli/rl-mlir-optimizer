#map = affine_map<(d0, d1) -> (d0, 0, d1)>
#map1 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<32x32xf64>, %arg1: memref<32x32xf64>, %arg2: memref<32x32xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_2 = arith.constant 0 : index
    %c16_3 = arith.constant 16 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<32x32xf64>)
    %c0_6 = arith.constant 0 : index
    %c32 = arith.constant 32 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_6 to %c32 step %c16_7 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 32] [1, 1] : memref<32x32xf64> to memref<16x32xf64, strided<[32, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [16, 32] [1, 1] : memref<32x32xf64> to memref<16x32xf64, strided<[32, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c32_10 = arith.constant 32 : index
      %c16_11 = arith.constant 16 : index
      scf.for %arg4 = %c0_9 to %c32_10 step %c16_11 {
        %subview_12 = memref.subview %arg1[0, %arg4] [32, 16] [1, 1] : memref<32x32xf64> to memref<32x16xf64, strided<[32, 1], offset: ?>>
        %subview_13 = memref.subview %subview_8[0, %arg4] [16, 16] [1, 1] : memref<16x32xf64, strided<[32, 1], offset: ?>> to memref<16x16xf64, strided<[32, 1], offset: ?>>
        %c0_14 = arith.constant 0 : index
        %c32_15 = arith.constant 32 : index
        %c1_16 = arith.constant 1 : index
        scf.for %arg5 = %c0_14 to %c32_15 step %c1_16 {
          %subview_17 = memref.subview %subview[0, %arg5] [16, 1] [1, 1] : memref<16x32xf64, strided<[32, 1], offset: ?>> to memref<16x1xf64, strided<[32, 1], offset: ?>>
          %subview_18 = memref.subview %subview_12[%arg5, 0] [1, 16] [1, 1] : memref<32x16xf64, strided<[32, 1], offset: ?>> to memref<1x16xf64, strided<[32, 1], offset: ?>>
          %c16_19 = arith.constant 16 : index
          %c16_20 = arith.constant 16 : index
          %c1_21 = arith.constant 1 : index
          %c0_22 = arith.constant 0 : index
          %cst_23 = arith.constant 0.000000e+00 : f64
          %0 = vector.transfer_read %subview_17[%c0_22, %c0_22], %cst_23 {permutation_map = #map} : memref<16x1xf64, strided<[32, 1], offset: ?>>, vector<16x16x1xf64>
          %cst_24 = arith.constant 0.000000e+00 : f64
          %1 = vector.transfer_read %subview_18[%c0_22, %c0_22], %cst_24 {permutation_map = #map1} : memref<1x16xf64, strided<[32, 1], offset: ?>>, vector<16x16x1xf64>
          %cst_25 = arith.constant 0.000000e+00 : f64
          %2 = vector.transfer_read %subview_13[%c0_22, %c0_22], %cst_25 : memref<16x16xf64, strided<[32, 1], offset: ?>>, vector<16x16xf64>
          %3 = arith.mulf %0, %1 : vector<16x16x1xf64>
          %4 = vector.multi_reduction <add>, %3, %2 [2] : vector<16x16x1xf64> to vector<16x16xf64>
          %c0_26 = arith.constant 0 : index
          vector.transfer_write %4, %subview_13[%c0_26, %c0_26] : vector<16x16xf64>, memref<16x16xf64, strided<[32, 1], offset: ?>>
        }
      }
    }
    return
  }
}
