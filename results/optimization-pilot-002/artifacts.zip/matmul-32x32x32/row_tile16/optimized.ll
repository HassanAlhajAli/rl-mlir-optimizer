; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(8192) %15, i8 0, i64 8192, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 4096
  %scevgep8 = getelementptr i8, ptr %1, i64 4096
  %scevgep10 = getelementptr i8, ptr %8, i64 8192
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %354
  %21 = phi i1 [ false, %354 ], [ true, %.preheader4.preheader ]
  %22 = phi i64 [ 512, %354 ], [ 0, %.preheader4.preheader ]
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = getelementptr double, ptr %15, i64 %22
  %25 = shl nuw nsw i64 %22, 3
  %scevgep7 = getelementptr i8, ptr %scevgep, i64 %25
  %scevgep9 = getelementptr i8, ptr %scevgep8, i64 %25
  %bound0 = icmp ult ptr %24, %scevgep9
  %bound1 = icmp ult ptr %23, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %24, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %middle.block
  %26 = phi i64 [ 0, %.preheader4 ], [ %353, %middle.block ]
  %27 = shl i64 %26, 5
  %28 = getelementptr double, ptr %24, i64 %27
  %29 = getelementptr double, ptr %23, i64 %27
  %30 = or disjoint i64 %27, 1
  %31 = getelementptr double, ptr %23, i64 %30
  %32 = or disjoint i64 %27, 2
  %33 = getelementptr double, ptr %23, i64 %32
  %34 = or disjoint i64 %27, 3
  %35 = getelementptr double, ptr %23, i64 %34
  %36 = or disjoint i64 %27, 4
  %37 = getelementptr double, ptr %23, i64 %36
  %38 = or disjoint i64 %27, 5
  %39 = getelementptr double, ptr %23, i64 %38
  %40 = or disjoint i64 %27, 6
  %41 = getelementptr double, ptr %23, i64 %40
  %42 = or disjoint i64 %27, 7
  %43 = getelementptr double, ptr %23, i64 %42
  %44 = or disjoint i64 %27, 8
  %45 = getelementptr double, ptr %23, i64 %44
  %46 = or disjoint i64 %27, 9
  %47 = getelementptr double, ptr %23, i64 %46
  %48 = or disjoint i64 %27, 10
  %49 = getelementptr double, ptr %23, i64 %48
  %50 = or disjoint i64 %27, 11
  %51 = getelementptr double, ptr %23, i64 %50
  %52 = or disjoint i64 %27, 12
  %53 = getelementptr double, ptr %23, i64 %52
  %54 = or disjoint i64 %27, 13
  %55 = getelementptr double, ptr %23, i64 %54
  %56 = or disjoint i64 %27, 14
  %57 = getelementptr double, ptr %23, i64 %56
  %58 = or disjoint i64 %27, 15
  %59 = getelementptr double, ptr %23, i64 %58
  %60 = or disjoint i64 %27, 16
  %61 = getelementptr double, ptr %23, i64 %60
  %62 = or disjoint i64 %27, 17
  %63 = getelementptr double, ptr %23, i64 %62
  %64 = or disjoint i64 %27, 18
  %65 = getelementptr double, ptr %23, i64 %64
  %66 = or disjoint i64 %27, 19
  %67 = getelementptr double, ptr %23, i64 %66
  %68 = or disjoint i64 %27, 20
  %69 = getelementptr double, ptr %23, i64 %68
  %70 = or disjoint i64 %27, 21
  %71 = getelementptr double, ptr %23, i64 %70
  %72 = or disjoint i64 %27, 22
  %73 = getelementptr double, ptr %23, i64 %72
  %74 = or disjoint i64 %27, 23
  %75 = getelementptr double, ptr %23, i64 %74
  %76 = or disjoint i64 %27, 24
  %77 = getelementptr double, ptr %23, i64 %76
  %78 = or disjoint i64 %27, 25
  %79 = getelementptr double, ptr %23, i64 %78
  %80 = or disjoint i64 %27, 26
  %81 = getelementptr double, ptr %23, i64 %80
  %82 = or disjoint i64 %27, 27
  %83 = getelementptr double, ptr %23, i64 %82
  %84 = or disjoint i64 %27, 28
  %85 = getelementptr double, ptr %23, i64 %84
  %86 = or disjoint i64 %27, 29
  %87 = getelementptr double, ptr %23, i64 %86
  %88 = or disjoint i64 %27, 30
  %89 = getelementptr double, ptr %23, i64 %88
  %90 = or disjoint i64 %27, 31
  %91 = getelementptr double, ptr %23, i64 %90
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %92 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %92, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %102 = load double, ptr %49, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %102, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %103 = load double, ptr %51, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %103, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %104 = load double, ptr %53, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %104, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = load double, ptr %55, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %105, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %106 = load double, ptr %57, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %106, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = load double, ptr %59, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %107, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %108 = load double, ptr %61, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %108, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %109 = load double, ptr %63, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %109, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = load double, ptr %65, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %110, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %111 = load double, ptr %67, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %111, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %112 = load double, ptr %69, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %112, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = load double, ptr %71, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %113, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = load double, ptr %73, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %114, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %115 = load double, ptr %75, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %115, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  %116 = load double, ptr %77, align 8, !alias.scope !1
  %broadcast.splatinsert85 = insertelement <4 x double> poison, double %116, i64 0
  %broadcast.splat86 = shufflevector <4 x double> %broadcast.splatinsert85, <4 x double> poison, <4 x i32> zeroinitializer
  %117 = load double, ptr %79, align 8, !alias.scope !1
  %broadcast.splatinsert88 = insertelement <4 x double> poison, double %117, i64 0
  %broadcast.splat89 = shufflevector <4 x double> %broadcast.splatinsert88, <4 x double> poison, <4 x i32> zeroinitializer
  %118 = load double, ptr %81, align 8, !alias.scope !1
  %broadcast.splatinsert91 = insertelement <4 x double> poison, double %118, i64 0
  %broadcast.splat92 = shufflevector <4 x double> %broadcast.splatinsert91, <4 x double> poison, <4 x i32> zeroinitializer
  %119 = load double, ptr %83, align 8, !alias.scope !1
  %broadcast.splatinsert94 = insertelement <4 x double> poison, double %119, i64 0
  %broadcast.splat95 = shufflevector <4 x double> %broadcast.splatinsert94, <4 x double> poison, <4 x i32> zeroinitializer
  %120 = load double, ptr %85, align 8, !alias.scope !1
  %broadcast.splatinsert97 = insertelement <4 x double> poison, double %120, i64 0
  %broadcast.splat98 = shufflevector <4 x double> %broadcast.splatinsert97, <4 x double> poison, <4 x i32> zeroinitializer
  %121 = load double, ptr %87, align 8, !alias.scope !1
  %broadcast.splatinsert100 = insertelement <4 x double> poison, double %121, i64 0
  %broadcast.splat101 = shufflevector <4 x double> %broadcast.splatinsert100, <4 x double> poison, <4 x i32> zeroinitializer
  %122 = load double, ptr %89, align 8, !alias.scope !1
  %broadcast.splatinsert103 = insertelement <4 x double> poison, double %122, i64 0
  %broadcast.splat104 = shufflevector <4 x double> %broadcast.splatinsert103, <4 x double> poison, <4 x i32> zeroinitializer
  %123 = load double, ptr %91, align 8, !alias.scope !1
  %broadcast.splatinsert106 = insertelement <4 x double> poison, double %123, i64 0
  %broadcast.splat107 = shufflevector <4 x double> %broadcast.splatinsert106, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %124 = getelementptr double, ptr %8, i64 %index
  %125 = getelementptr double, ptr %28, i64 %index
  %wide.load = load <4 x double>, ptr %125, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %124, align 8, !alias.scope !8
  %126 = fmul <4 x double> %broadcast.splat, %wide.load14
  %127 = fadd <4 x double> %wide.load, %126
  store <4 x double> %127, ptr %125, align 8, !alias.scope !4, !noalias !6
  %128 = getelementptr double, ptr %124, i64 32
  %wide.load15 = load <4 x double>, ptr %128, align 8, !alias.scope !8
  %129 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %130 = fadd <4 x double> %127, %129
  store <4 x double> %130, ptr %125, align 8, !alias.scope !4, !noalias !6
  %131 = getelementptr double, ptr %124, i64 64
  %wide.load18 = load <4 x double>, ptr %131, align 8, !alias.scope !8
  %132 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %133 = fadd <4 x double> %130, %132
  store <4 x double> %133, ptr %125, align 8, !alias.scope !4, !noalias !6
  %134 = getelementptr double, ptr %124, i64 96
  %wide.load21 = load <4 x double>, ptr %134, align 8, !alias.scope !8
  %135 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %136 = fadd <4 x double> %133, %135
  store <4 x double> %136, ptr %125, align 8, !alias.scope !4, !noalias !6
  %137 = getelementptr double, ptr %124, i64 128
  %wide.load24 = load <4 x double>, ptr %137, align 8, !alias.scope !8
  %138 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %139 = fadd <4 x double> %136, %138
  store <4 x double> %139, ptr %125, align 8, !alias.scope !4, !noalias !6
  %140 = getelementptr double, ptr %124, i64 160
  %wide.load27 = load <4 x double>, ptr %140, align 8, !alias.scope !8
  %141 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %142 = fadd <4 x double> %139, %141
  store <4 x double> %142, ptr %125, align 8, !alias.scope !4, !noalias !6
  %143 = getelementptr double, ptr %124, i64 192
  %wide.load30 = load <4 x double>, ptr %143, align 8, !alias.scope !8
  %144 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %145 = fadd <4 x double> %142, %144
  store <4 x double> %145, ptr %125, align 8, !alias.scope !4, !noalias !6
  %146 = getelementptr double, ptr %124, i64 224
  %wide.load33 = load <4 x double>, ptr %146, align 8, !alias.scope !8
  %147 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %148 = fadd <4 x double> %145, %147
  store <4 x double> %148, ptr %125, align 8, !alias.scope !4, !noalias !6
  %149 = getelementptr double, ptr %124, i64 256
  %wide.load36 = load <4 x double>, ptr %149, align 8, !alias.scope !8
  %150 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %151 = fadd <4 x double> %148, %150
  store <4 x double> %151, ptr %125, align 8, !alias.scope !4, !noalias !6
  %152 = getelementptr double, ptr %124, i64 288
  %wide.load39 = load <4 x double>, ptr %152, align 8, !alias.scope !8
  %153 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %154 = fadd <4 x double> %151, %153
  store <4 x double> %154, ptr %125, align 8, !alias.scope !4, !noalias !6
  %155 = getelementptr double, ptr %124, i64 320
  %wide.load42 = load <4 x double>, ptr %155, align 8, !alias.scope !8
  %156 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %157 = fadd <4 x double> %154, %156
  store <4 x double> %157, ptr %125, align 8, !alias.scope !4, !noalias !6
  %158 = getelementptr double, ptr %124, i64 352
  %wide.load45 = load <4 x double>, ptr %158, align 8, !alias.scope !8
  %159 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %160 = fadd <4 x double> %157, %159
  store <4 x double> %160, ptr %125, align 8, !alias.scope !4, !noalias !6
  %161 = getelementptr double, ptr %124, i64 384
  %wide.load48 = load <4 x double>, ptr %161, align 8, !alias.scope !8
  %162 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %163 = fadd <4 x double> %160, %162
  store <4 x double> %163, ptr %125, align 8, !alias.scope !4, !noalias !6
  %164 = getelementptr double, ptr %124, i64 416
  %wide.load51 = load <4 x double>, ptr %164, align 8, !alias.scope !8
  %165 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %166 = fadd <4 x double> %163, %165
  store <4 x double> %166, ptr %125, align 8, !alias.scope !4, !noalias !6
  %167 = getelementptr double, ptr %124, i64 448
  %wide.load54 = load <4 x double>, ptr %167, align 8, !alias.scope !8
  %168 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %169 = fadd <4 x double> %166, %168
  store <4 x double> %169, ptr %125, align 8, !alias.scope !4, !noalias !6
  %170 = getelementptr double, ptr %124, i64 480
  %wide.load57 = load <4 x double>, ptr %170, align 8, !alias.scope !8
  %171 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %172 = fadd <4 x double> %169, %171
  store <4 x double> %172, ptr %125, align 8, !alias.scope !4, !noalias !6
  %173 = getelementptr double, ptr %124, i64 512
  %wide.load60 = load <4 x double>, ptr %173, align 8, !alias.scope !8
  %174 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %175 = fadd <4 x double> %172, %174
  store <4 x double> %175, ptr %125, align 8, !alias.scope !4, !noalias !6
  %176 = getelementptr double, ptr %124, i64 544
  %wide.load63 = load <4 x double>, ptr %176, align 8, !alias.scope !8
  %177 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %178 = fadd <4 x double> %175, %177
  store <4 x double> %178, ptr %125, align 8, !alias.scope !4, !noalias !6
  %179 = getelementptr double, ptr %124, i64 576
  %wide.load66 = load <4 x double>, ptr %179, align 8, !alias.scope !8
  %180 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %181 = fadd <4 x double> %178, %180
  store <4 x double> %181, ptr %125, align 8, !alias.scope !4, !noalias !6
  %182 = getelementptr double, ptr %124, i64 608
  %wide.load69 = load <4 x double>, ptr %182, align 8, !alias.scope !8
  %183 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %184 = fadd <4 x double> %181, %183
  store <4 x double> %184, ptr %125, align 8, !alias.scope !4, !noalias !6
  %185 = getelementptr double, ptr %124, i64 640
  %wide.load72 = load <4 x double>, ptr %185, align 8, !alias.scope !8
  %186 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %187 = fadd <4 x double> %184, %186
  store <4 x double> %187, ptr %125, align 8, !alias.scope !4, !noalias !6
  %188 = getelementptr double, ptr %124, i64 672
  %wide.load75 = load <4 x double>, ptr %188, align 8, !alias.scope !8
  %189 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %190 = fadd <4 x double> %187, %189
  store <4 x double> %190, ptr %125, align 8, !alias.scope !4, !noalias !6
  %191 = getelementptr double, ptr %124, i64 704
  %wide.load78 = load <4 x double>, ptr %191, align 8, !alias.scope !8
  %192 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %193 = fadd <4 x double> %190, %192
  store <4 x double> %193, ptr %125, align 8, !alias.scope !4, !noalias !6
  %194 = getelementptr double, ptr %124, i64 736
  %wide.load81 = load <4 x double>, ptr %194, align 8, !alias.scope !8
  %195 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %196 = fadd <4 x double> %193, %195
  store <4 x double> %196, ptr %125, align 8, !alias.scope !4, !noalias !6
  %197 = getelementptr double, ptr %124, i64 768
  %wide.load84 = load <4 x double>, ptr %197, align 8, !alias.scope !8
  %198 = fmul <4 x double> %broadcast.splat86, %wide.load84
  %199 = fadd <4 x double> %196, %198
  store <4 x double> %199, ptr %125, align 8, !alias.scope !4, !noalias !6
  %200 = getelementptr double, ptr %124, i64 800
  %wide.load87 = load <4 x double>, ptr %200, align 8, !alias.scope !8
  %201 = fmul <4 x double> %broadcast.splat89, %wide.load87
  %202 = fadd <4 x double> %199, %201
  store <4 x double> %202, ptr %125, align 8, !alias.scope !4, !noalias !6
  %203 = getelementptr double, ptr %124, i64 832
  %wide.load90 = load <4 x double>, ptr %203, align 8, !alias.scope !8
  %204 = fmul <4 x double> %broadcast.splat92, %wide.load90
  %205 = fadd <4 x double> %202, %204
  store <4 x double> %205, ptr %125, align 8, !alias.scope !4, !noalias !6
  %206 = getelementptr double, ptr %124, i64 864
  %wide.load93 = load <4 x double>, ptr %206, align 8, !alias.scope !8
  %207 = fmul <4 x double> %broadcast.splat95, %wide.load93
  %208 = fadd <4 x double> %205, %207
  store <4 x double> %208, ptr %125, align 8, !alias.scope !4, !noalias !6
  %209 = getelementptr double, ptr %124, i64 896
  %wide.load96 = load <4 x double>, ptr %209, align 8, !alias.scope !8
  %210 = fmul <4 x double> %broadcast.splat98, %wide.load96
  %211 = fadd <4 x double> %208, %210
  store <4 x double> %211, ptr %125, align 8, !alias.scope !4, !noalias !6
  %212 = getelementptr double, ptr %124, i64 928
  %wide.load99 = load <4 x double>, ptr %212, align 8, !alias.scope !8
  %213 = fmul <4 x double> %broadcast.splat101, %wide.load99
  %214 = fadd <4 x double> %211, %213
  store <4 x double> %214, ptr %125, align 8, !alias.scope !4, !noalias !6
  %215 = getelementptr double, ptr %124, i64 960
  %wide.load102 = load <4 x double>, ptr %215, align 8, !alias.scope !8
  %216 = fmul <4 x double> %broadcast.splat104, %wide.load102
  %217 = fadd <4 x double> %214, %216
  store <4 x double> %217, ptr %125, align 8, !alias.scope !4, !noalias !6
  %218 = getelementptr double, ptr %124, i64 992
  %wide.load105 = load <4 x double>, ptr %218, align 8, !alias.scope !8
  %219 = fmul <4 x double> %broadcast.splat107, %wide.load105
  %220 = fadd <4 x double> %217, %219
  store <4 x double> %220, ptr %125, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %221 = icmp eq i64 %index.next, 32
  br i1 %221, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %222 = phi i64 [ %352, %.preheader ], [ 0, %.preheader3 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %222
  %223 = getelementptr double, ptr %28, i64 %222
  %.promoted = load double, ptr %223, align 8
  %224 = load double, ptr %29, align 8
  %225 = load double, ptr %invariant.gep, align 8
  %226 = fmul double %224, %225
  %227 = fadd double %.promoted, %226
  store double %227, ptr %223, align 8
  %228 = load double, ptr %31, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 32
  %229 = load double, ptr %gep.1, align 8
  %230 = fmul double %228, %229
  %231 = fadd double %227, %230
  store double %231, ptr %223, align 8
  %232 = load double, ptr %33, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 64
  %233 = load double, ptr %gep.2, align 8
  %234 = fmul double %232, %233
  %235 = fadd double %231, %234
  store double %235, ptr %223, align 8
  %236 = load double, ptr %35, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 96
  %237 = load double, ptr %gep.3, align 8
  %238 = fmul double %236, %237
  %239 = fadd double %235, %238
  store double %239, ptr %223, align 8
  %240 = load double, ptr %37, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 128
  %241 = load double, ptr %gep.4, align 8
  %242 = fmul double %240, %241
  %243 = fadd double %239, %242
  store double %243, ptr %223, align 8
  %244 = load double, ptr %39, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 160
  %245 = load double, ptr %gep.5, align 8
  %246 = fmul double %244, %245
  %247 = fadd double %243, %246
  store double %247, ptr %223, align 8
  %248 = load double, ptr %41, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 192
  %249 = load double, ptr %gep.6, align 8
  %250 = fmul double %248, %249
  %251 = fadd double %247, %250
  store double %251, ptr %223, align 8
  %252 = load double, ptr %43, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 224
  %253 = load double, ptr %gep.7, align 8
  %254 = fmul double %252, %253
  %255 = fadd double %251, %254
  store double %255, ptr %223, align 8
  %256 = load double, ptr %45, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 256
  %257 = load double, ptr %gep.8, align 8
  %258 = fmul double %256, %257
  %259 = fadd double %255, %258
  store double %259, ptr %223, align 8
  %260 = load double, ptr %47, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 288
  %261 = load double, ptr %gep.9, align 8
  %262 = fmul double %260, %261
  %263 = fadd double %259, %262
  store double %263, ptr %223, align 8
  %264 = load double, ptr %49, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 320
  %265 = load double, ptr %gep.10, align 8
  %266 = fmul double %264, %265
  %267 = fadd double %263, %266
  store double %267, ptr %223, align 8
  %268 = load double, ptr %51, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 352
  %269 = load double, ptr %gep.11, align 8
  %270 = fmul double %268, %269
  %271 = fadd double %267, %270
  store double %271, ptr %223, align 8
  %272 = load double, ptr %53, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 384
  %273 = load double, ptr %gep.12, align 8
  %274 = fmul double %272, %273
  %275 = fadd double %271, %274
  store double %275, ptr %223, align 8
  %276 = load double, ptr %55, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 416
  %277 = load double, ptr %gep.13, align 8
  %278 = fmul double %276, %277
  %279 = fadd double %275, %278
  store double %279, ptr %223, align 8
  %280 = load double, ptr %57, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 448
  %281 = load double, ptr %gep.14, align 8
  %282 = fmul double %280, %281
  %283 = fadd double %279, %282
  store double %283, ptr %223, align 8
  %284 = load double, ptr %59, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 480
  %285 = load double, ptr %gep.15, align 8
  %286 = fmul double %284, %285
  %287 = fadd double %283, %286
  store double %287, ptr %223, align 8
  %288 = load double, ptr %61, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 512
  %289 = load double, ptr %gep.16, align 8
  %290 = fmul double %288, %289
  %291 = fadd double %287, %290
  store double %291, ptr %223, align 8
  %292 = load double, ptr %63, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 544
  %293 = load double, ptr %gep.17, align 8
  %294 = fmul double %292, %293
  %295 = fadd double %291, %294
  store double %295, ptr %223, align 8
  %296 = load double, ptr %65, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 576
  %297 = load double, ptr %gep.18, align 8
  %298 = fmul double %296, %297
  %299 = fadd double %295, %298
  store double %299, ptr %223, align 8
  %300 = load double, ptr %67, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 608
  %301 = load double, ptr %gep.19, align 8
  %302 = fmul double %300, %301
  %303 = fadd double %299, %302
  store double %303, ptr %223, align 8
  %304 = load double, ptr %69, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 640
  %305 = load double, ptr %gep.20, align 8
  %306 = fmul double %304, %305
  %307 = fadd double %303, %306
  store double %307, ptr %223, align 8
  %308 = load double, ptr %71, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 672
  %309 = load double, ptr %gep.21, align 8
  %310 = fmul double %308, %309
  %311 = fadd double %307, %310
  store double %311, ptr %223, align 8
  %312 = load double, ptr %73, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 704
  %313 = load double, ptr %gep.22, align 8
  %314 = fmul double %312, %313
  %315 = fadd double %311, %314
  store double %315, ptr %223, align 8
  %316 = load double, ptr %75, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 736
  %317 = load double, ptr %gep.23, align 8
  %318 = fmul double %316, %317
  %319 = fadd double %315, %318
  store double %319, ptr %223, align 8
  %320 = load double, ptr %77, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 768
  %321 = load double, ptr %gep.24, align 8
  %322 = fmul double %320, %321
  %323 = fadd double %319, %322
  store double %323, ptr %223, align 8
  %324 = load double, ptr %79, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 800
  %325 = load double, ptr %gep.25, align 8
  %326 = fmul double %324, %325
  %327 = fadd double %323, %326
  store double %327, ptr %223, align 8
  %328 = load double, ptr %81, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 832
  %329 = load double, ptr %gep.26, align 8
  %330 = fmul double %328, %329
  %331 = fadd double %327, %330
  store double %331, ptr %223, align 8
  %332 = load double, ptr %83, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 864
  %333 = load double, ptr %gep.27, align 8
  %334 = fmul double %332, %333
  %335 = fadd double %331, %334
  store double %335, ptr %223, align 8
  %336 = load double, ptr %85, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 896
  %337 = load double, ptr %gep.28, align 8
  %338 = fmul double %336, %337
  %339 = fadd double %335, %338
  store double %339, ptr %223, align 8
  %340 = load double, ptr %87, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 928
  %341 = load double, ptr %gep.29, align 8
  %342 = fmul double %340, %341
  %343 = fadd double %339, %342
  store double %343, ptr %223, align 8
  %344 = load double, ptr %89, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 960
  %345 = load double, ptr %gep.30, align 8
  %346 = fmul double %344, %345
  %347 = fadd double %343, %346
  store double %347, ptr %223, align 8
  %348 = load double, ptr %91, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 992
  %349 = load double, ptr %gep.31, align 8
  %350 = fmul double %348, %349
  %351 = fadd double %347, %350
  store double %351, ptr %223, align 8
  %352 = add nuw nsw i64 %222, 1
  %exitcond.not = icmp eq i64 %352, 32
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %353 = add nuw nsw i64 %26, 1
  %exitcond6.not = icmp eq i64 %353, 16
  br i1 %exitcond6.not, label %354, label %.preheader3

354:                                              ; preds = %middle.block
  br i1 %21, label %.preheader4, label %355

355:                                              ; preds = %354
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
