; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(8192) %15, i8 0, i64 8192, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 8192
  %scevgep6 = getelementptr i8, ptr %1, i64 8192
  %scevgep7 = getelementptr i8, ptr %8, i64 8192
  %bound0 = icmp ugt ptr %scevgep6, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound08 = icmp ugt ptr %scevgep7, %15
  %bound19 = icmp ugt ptr %scevgep, %8
  %found.conflict10 = and i1 %bound08, %bound19
  %conflict.rdx = or i1 %found.conflict, %found.conflict10
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %middle.block
  %21 = phi i64 [ %348, %middle.block ], [ 0, %.preheader2.preheader ]
  %22 = shl i64 %21, 5
  %23 = getelementptr double, ptr %15, i64 %22
  %24 = getelementptr double, ptr %1, i64 %22
  %25 = or disjoint i64 %22, 1
  %26 = getelementptr double, ptr %1, i64 %25
  %27 = or disjoint i64 %22, 2
  %28 = getelementptr double, ptr %1, i64 %27
  %29 = or disjoint i64 %22, 3
  %30 = getelementptr double, ptr %1, i64 %29
  %31 = or disjoint i64 %22, 4
  %32 = getelementptr double, ptr %1, i64 %31
  %33 = or disjoint i64 %22, 5
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = or disjoint i64 %22, 6
  %36 = getelementptr double, ptr %1, i64 %35
  %37 = or disjoint i64 %22, 7
  %38 = getelementptr double, ptr %1, i64 %37
  %39 = or disjoint i64 %22, 8
  %40 = getelementptr double, ptr %1, i64 %39
  %41 = or disjoint i64 %22, 9
  %42 = getelementptr double, ptr %1, i64 %41
  %43 = or disjoint i64 %22, 10
  %44 = getelementptr double, ptr %1, i64 %43
  %45 = or disjoint i64 %22, 11
  %46 = getelementptr double, ptr %1, i64 %45
  %47 = or disjoint i64 %22, 12
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = or disjoint i64 %22, 13
  %50 = getelementptr double, ptr %1, i64 %49
  %51 = or disjoint i64 %22, 14
  %52 = getelementptr double, ptr %1, i64 %51
  %53 = or disjoint i64 %22, 15
  %54 = getelementptr double, ptr %1, i64 %53
  %55 = or disjoint i64 %22, 16
  %56 = getelementptr double, ptr %1, i64 %55
  %57 = or disjoint i64 %22, 17
  %58 = getelementptr double, ptr %1, i64 %57
  %59 = or disjoint i64 %22, 18
  %60 = getelementptr double, ptr %1, i64 %59
  %61 = or disjoint i64 %22, 19
  %62 = getelementptr double, ptr %1, i64 %61
  %63 = or disjoint i64 %22, 20
  %64 = getelementptr double, ptr %1, i64 %63
  %65 = or disjoint i64 %22, 21
  %66 = getelementptr double, ptr %1, i64 %65
  %67 = or disjoint i64 %22, 22
  %68 = getelementptr double, ptr %1, i64 %67
  %69 = or disjoint i64 %22, 23
  %70 = getelementptr double, ptr %1, i64 %69
  %71 = or disjoint i64 %22, 24
  %72 = getelementptr double, ptr %1, i64 %71
  %73 = or disjoint i64 %22, 25
  %74 = getelementptr double, ptr %1, i64 %73
  %75 = or disjoint i64 %22, 26
  %76 = getelementptr double, ptr %1, i64 %75
  %77 = or disjoint i64 %22, 27
  %78 = getelementptr double, ptr %1, i64 %77
  %79 = or disjoint i64 %22, 28
  %80 = getelementptr double, ptr %1, i64 %79
  %81 = or disjoint i64 %22, 29
  %82 = getelementptr double, ptr %1, i64 %81
  %83 = or disjoint i64 %22, 30
  %84 = getelementptr double, ptr %1, i64 %83
  %85 = or disjoint i64 %22, 31
  %86 = getelementptr double, ptr %1, i64 %85
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader2
  %87 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %87, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %88 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %88, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %89 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %89, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %90, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %91, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %92, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %102 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %102, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %103 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %103, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %104 = load double, ptr %58, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %104, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = load double, ptr %60, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %105, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %106 = load double, ptr %62, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %106, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = load double, ptr %64, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %107, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %108 = load double, ptr %66, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %108, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %109 = load double, ptr %68, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %109, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = load double, ptr %70, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %110, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %111 = load double, ptr %72, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %111, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  %112 = load double, ptr %74, align 8, !alias.scope !1
  %broadcast.splatinsert85 = insertelement <4 x double> poison, double %112, i64 0
  %broadcast.splat86 = shufflevector <4 x double> %broadcast.splatinsert85, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = load double, ptr %76, align 8, !alias.scope !1
  %broadcast.splatinsert88 = insertelement <4 x double> poison, double %113, i64 0
  %broadcast.splat89 = shufflevector <4 x double> %broadcast.splatinsert88, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = load double, ptr %78, align 8, !alias.scope !1
  %broadcast.splatinsert91 = insertelement <4 x double> poison, double %114, i64 0
  %broadcast.splat92 = shufflevector <4 x double> %broadcast.splatinsert91, <4 x double> poison, <4 x i32> zeroinitializer
  %115 = load double, ptr %80, align 8, !alias.scope !1
  %broadcast.splatinsert94 = insertelement <4 x double> poison, double %115, i64 0
  %broadcast.splat95 = shufflevector <4 x double> %broadcast.splatinsert94, <4 x double> poison, <4 x i32> zeroinitializer
  %116 = load double, ptr %82, align 8, !alias.scope !1
  %broadcast.splatinsert97 = insertelement <4 x double> poison, double %116, i64 0
  %broadcast.splat98 = shufflevector <4 x double> %broadcast.splatinsert97, <4 x double> poison, <4 x i32> zeroinitializer
  %117 = load double, ptr %84, align 8, !alias.scope !1
  %broadcast.splatinsert100 = insertelement <4 x double> poison, double %117, i64 0
  %broadcast.splat101 = shufflevector <4 x double> %broadcast.splatinsert100, <4 x double> poison, <4 x i32> zeroinitializer
  %118 = load double, ptr %86, align 8, !alias.scope !1
  %broadcast.splatinsert103 = insertelement <4 x double> poison, double %118, i64 0
  %broadcast.splat104 = shufflevector <4 x double> %broadcast.splatinsert103, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %119 = getelementptr double, ptr %8, i64 %index
  %120 = getelementptr double, ptr %23, i64 %index
  %wide.load = load <4 x double>, ptr %120, align 8, !alias.scope !4, !noalias !6
  %wide.load11 = load <4 x double>, ptr %119, align 8, !alias.scope !8
  %121 = fmul <4 x double> %broadcast.splat, %wide.load11
  %122 = fadd <4 x double> %wide.load, %121
  store <4 x double> %122, ptr %120, align 8, !alias.scope !4, !noalias !6
  %123 = getelementptr double, ptr %119, i64 32
  %wide.load12 = load <4 x double>, ptr %123, align 8, !alias.scope !8
  %124 = fmul <4 x double> %broadcast.splat14, %wide.load12
  %125 = fadd <4 x double> %122, %124
  store <4 x double> %125, ptr %120, align 8, !alias.scope !4, !noalias !6
  %126 = getelementptr double, ptr %119, i64 64
  %wide.load15 = load <4 x double>, ptr %126, align 8, !alias.scope !8
  %127 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %128 = fadd <4 x double> %125, %127
  store <4 x double> %128, ptr %120, align 8, !alias.scope !4, !noalias !6
  %129 = getelementptr double, ptr %119, i64 96
  %wide.load18 = load <4 x double>, ptr %129, align 8, !alias.scope !8
  %130 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %131 = fadd <4 x double> %128, %130
  store <4 x double> %131, ptr %120, align 8, !alias.scope !4, !noalias !6
  %132 = getelementptr double, ptr %119, i64 128
  %wide.load21 = load <4 x double>, ptr %132, align 8, !alias.scope !8
  %133 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %134 = fadd <4 x double> %131, %133
  store <4 x double> %134, ptr %120, align 8, !alias.scope !4, !noalias !6
  %135 = getelementptr double, ptr %119, i64 160
  %wide.load24 = load <4 x double>, ptr %135, align 8, !alias.scope !8
  %136 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %137 = fadd <4 x double> %134, %136
  store <4 x double> %137, ptr %120, align 8, !alias.scope !4, !noalias !6
  %138 = getelementptr double, ptr %119, i64 192
  %wide.load27 = load <4 x double>, ptr %138, align 8, !alias.scope !8
  %139 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %140 = fadd <4 x double> %137, %139
  store <4 x double> %140, ptr %120, align 8, !alias.scope !4, !noalias !6
  %141 = getelementptr double, ptr %119, i64 224
  %wide.load30 = load <4 x double>, ptr %141, align 8, !alias.scope !8
  %142 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %143 = fadd <4 x double> %140, %142
  store <4 x double> %143, ptr %120, align 8, !alias.scope !4, !noalias !6
  %144 = getelementptr double, ptr %119, i64 256
  %wide.load33 = load <4 x double>, ptr %144, align 8, !alias.scope !8
  %145 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %146 = fadd <4 x double> %143, %145
  store <4 x double> %146, ptr %120, align 8, !alias.scope !4, !noalias !6
  %147 = getelementptr double, ptr %119, i64 288
  %wide.load36 = load <4 x double>, ptr %147, align 8, !alias.scope !8
  %148 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %149 = fadd <4 x double> %146, %148
  store <4 x double> %149, ptr %120, align 8, !alias.scope !4, !noalias !6
  %150 = getelementptr double, ptr %119, i64 320
  %wide.load39 = load <4 x double>, ptr %150, align 8, !alias.scope !8
  %151 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %152 = fadd <4 x double> %149, %151
  store <4 x double> %152, ptr %120, align 8, !alias.scope !4, !noalias !6
  %153 = getelementptr double, ptr %119, i64 352
  %wide.load42 = load <4 x double>, ptr %153, align 8, !alias.scope !8
  %154 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %155 = fadd <4 x double> %152, %154
  store <4 x double> %155, ptr %120, align 8, !alias.scope !4, !noalias !6
  %156 = getelementptr double, ptr %119, i64 384
  %wide.load45 = load <4 x double>, ptr %156, align 8, !alias.scope !8
  %157 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %158 = fadd <4 x double> %155, %157
  store <4 x double> %158, ptr %120, align 8, !alias.scope !4, !noalias !6
  %159 = getelementptr double, ptr %119, i64 416
  %wide.load48 = load <4 x double>, ptr %159, align 8, !alias.scope !8
  %160 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %161 = fadd <4 x double> %158, %160
  store <4 x double> %161, ptr %120, align 8, !alias.scope !4, !noalias !6
  %162 = getelementptr double, ptr %119, i64 448
  %wide.load51 = load <4 x double>, ptr %162, align 8, !alias.scope !8
  %163 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %164 = fadd <4 x double> %161, %163
  store <4 x double> %164, ptr %120, align 8, !alias.scope !4, !noalias !6
  %165 = getelementptr double, ptr %119, i64 480
  %wide.load54 = load <4 x double>, ptr %165, align 8, !alias.scope !8
  %166 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %167 = fadd <4 x double> %164, %166
  store <4 x double> %167, ptr %120, align 8, !alias.scope !4, !noalias !6
  %168 = getelementptr double, ptr %119, i64 512
  %wide.load57 = load <4 x double>, ptr %168, align 8, !alias.scope !8
  %169 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %170 = fadd <4 x double> %167, %169
  store <4 x double> %170, ptr %120, align 8, !alias.scope !4, !noalias !6
  %171 = getelementptr double, ptr %119, i64 544
  %wide.load60 = load <4 x double>, ptr %171, align 8, !alias.scope !8
  %172 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %173 = fadd <4 x double> %170, %172
  store <4 x double> %173, ptr %120, align 8, !alias.scope !4, !noalias !6
  %174 = getelementptr double, ptr %119, i64 576
  %wide.load63 = load <4 x double>, ptr %174, align 8, !alias.scope !8
  %175 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %176 = fadd <4 x double> %173, %175
  store <4 x double> %176, ptr %120, align 8, !alias.scope !4, !noalias !6
  %177 = getelementptr double, ptr %119, i64 608
  %wide.load66 = load <4 x double>, ptr %177, align 8, !alias.scope !8
  %178 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %179 = fadd <4 x double> %176, %178
  store <4 x double> %179, ptr %120, align 8, !alias.scope !4, !noalias !6
  %180 = getelementptr double, ptr %119, i64 640
  %wide.load69 = load <4 x double>, ptr %180, align 8, !alias.scope !8
  %181 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %182 = fadd <4 x double> %179, %181
  store <4 x double> %182, ptr %120, align 8, !alias.scope !4, !noalias !6
  %183 = getelementptr double, ptr %119, i64 672
  %wide.load72 = load <4 x double>, ptr %183, align 8, !alias.scope !8
  %184 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %185 = fadd <4 x double> %182, %184
  store <4 x double> %185, ptr %120, align 8, !alias.scope !4, !noalias !6
  %186 = getelementptr double, ptr %119, i64 704
  %wide.load75 = load <4 x double>, ptr %186, align 8, !alias.scope !8
  %187 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %188 = fadd <4 x double> %185, %187
  store <4 x double> %188, ptr %120, align 8, !alias.scope !4, !noalias !6
  %189 = getelementptr double, ptr %119, i64 736
  %wide.load78 = load <4 x double>, ptr %189, align 8, !alias.scope !8
  %190 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %191 = fadd <4 x double> %188, %190
  store <4 x double> %191, ptr %120, align 8, !alias.scope !4, !noalias !6
  %192 = getelementptr double, ptr %119, i64 768
  %wide.load81 = load <4 x double>, ptr %192, align 8, !alias.scope !8
  %193 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %194 = fadd <4 x double> %191, %193
  store <4 x double> %194, ptr %120, align 8, !alias.scope !4, !noalias !6
  %195 = getelementptr double, ptr %119, i64 800
  %wide.load84 = load <4 x double>, ptr %195, align 8, !alias.scope !8
  %196 = fmul <4 x double> %broadcast.splat86, %wide.load84
  %197 = fadd <4 x double> %194, %196
  store <4 x double> %197, ptr %120, align 8, !alias.scope !4, !noalias !6
  %198 = getelementptr double, ptr %119, i64 832
  %wide.load87 = load <4 x double>, ptr %198, align 8, !alias.scope !8
  %199 = fmul <4 x double> %broadcast.splat89, %wide.load87
  %200 = fadd <4 x double> %197, %199
  store <4 x double> %200, ptr %120, align 8, !alias.scope !4, !noalias !6
  %201 = getelementptr double, ptr %119, i64 864
  %wide.load90 = load <4 x double>, ptr %201, align 8, !alias.scope !8
  %202 = fmul <4 x double> %broadcast.splat92, %wide.load90
  %203 = fadd <4 x double> %200, %202
  store <4 x double> %203, ptr %120, align 8, !alias.scope !4, !noalias !6
  %204 = getelementptr double, ptr %119, i64 896
  %wide.load93 = load <4 x double>, ptr %204, align 8, !alias.scope !8
  %205 = fmul <4 x double> %broadcast.splat95, %wide.load93
  %206 = fadd <4 x double> %203, %205
  store <4 x double> %206, ptr %120, align 8, !alias.scope !4, !noalias !6
  %207 = getelementptr double, ptr %119, i64 928
  %wide.load96 = load <4 x double>, ptr %207, align 8, !alias.scope !8
  %208 = fmul <4 x double> %broadcast.splat98, %wide.load96
  %209 = fadd <4 x double> %206, %208
  store <4 x double> %209, ptr %120, align 8, !alias.scope !4, !noalias !6
  %210 = getelementptr double, ptr %119, i64 960
  %wide.load99 = load <4 x double>, ptr %210, align 8, !alias.scope !8
  %211 = fmul <4 x double> %broadcast.splat101, %wide.load99
  %212 = fadd <4 x double> %209, %211
  store <4 x double> %212, ptr %120, align 8, !alias.scope !4, !noalias !6
  %213 = getelementptr double, ptr %119, i64 992
  %wide.load102 = load <4 x double>, ptr %213, align 8, !alias.scope !8
  %214 = fmul <4 x double> %broadcast.splat104, %wide.load102
  %215 = fadd <4 x double> %212, %214
  store <4 x double> %215, ptr %120, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %216 = icmp eq i64 %index.next, 32
  br i1 %216, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader2, %.preheader
  %217 = phi i64 [ %347, %.preheader ], [ 0, %.preheader2 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %217
  %218 = getelementptr double, ptr %23, i64 %217
  %.promoted = load double, ptr %218, align 8
  %219 = load double, ptr %24, align 8
  %220 = load double, ptr %invariant.gep, align 8
  %221 = fmul double %219, %220
  %222 = fadd double %.promoted, %221
  store double %222, ptr %218, align 8
  %223 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 32
  %224 = load double, ptr %gep.1, align 8
  %225 = fmul double %223, %224
  %226 = fadd double %222, %225
  store double %226, ptr %218, align 8
  %227 = load double, ptr %28, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 64
  %228 = load double, ptr %gep.2, align 8
  %229 = fmul double %227, %228
  %230 = fadd double %226, %229
  store double %230, ptr %218, align 8
  %231 = load double, ptr %30, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 96
  %232 = load double, ptr %gep.3, align 8
  %233 = fmul double %231, %232
  %234 = fadd double %230, %233
  store double %234, ptr %218, align 8
  %235 = load double, ptr %32, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 128
  %236 = load double, ptr %gep.4, align 8
  %237 = fmul double %235, %236
  %238 = fadd double %234, %237
  store double %238, ptr %218, align 8
  %239 = load double, ptr %34, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 160
  %240 = load double, ptr %gep.5, align 8
  %241 = fmul double %239, %240
  %242 = fadd double %238, %241
  store double %242, ptr %218, align 8
  %243 = load double, ptr %36, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 192
  %244 = load double, ptr %gep.6, align 8
  %245 = fmul double %243, %244
  %246 = fadd double %242, %245
  store double %246, ptr %218, align 8
  %247 = load double, ptr %38, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 224
  %248 = load double, ptr %gep.7, align 8
  %249 = fmul double %247, %248
  %250 = fadd double %246, %249
  store double %250, ptr %218, align 8
  %251 = load double, ptr %40, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 256
  %252 = load double, ptr %gep.8, align 8
  %253 = fmul double %251, %252
  %254 = fadd double %250, %253
  store double %254, ptr %218, align 8
  %255 = load double, ptr %42, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 288
  %256 = load double, ptr %gep.9, align 8
  %257 = fmul double %255, %256
  %258 = fadd double %254, %257
  store double %258, ptr %218, align 8
  %259 = load double, ptr %44, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 320
  %260 = load double, ptr %gep.10, align 8
  %261 = fmul double %259, %260
  %262 = fadd double %258, %261
  store double %262, ptr %218, align 8
  %263 = load double, ptr %46, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 352
  %264 = load double, ptr %gep.11, align 8
  %265 = fmul double %263, %264
  %266 = fadd double %262, %265
  store double %266, ptr %218, align 8
  %267 = load double, ptr %48, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 384
  %268 = load double, ptr %gep.12, align 8
  %269 = fmul double %267, %268
  %270 = fadd double %266, %269
  store double %270, ptr %218, align 8
  %271 = load double, ptr %50, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 416
  %272 = load double, ptr %gep.13, align 8
  %273 = fmul double %271, %272
  %274 = fadd double %270, %273
  store double %274, ptr %218, align 8
  %275 = load double, ptr %52, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 448
  %276 = load double, ptr %gep.14, align 8
  %277 = fmul double %275, %276
  %278 = fadd double %274, %277
  store double %278, ptr %218, align 8
  %279 = load double, ptr %54, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 480
  %280 = load double, ptr %gep.15, align 8
  %281 = fmul double %279, %280
  %282 = fadd double %278, %281
  store double %282, ptr %218, align 8
  %283 = load double, ptr %56, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 512
  %284 = load double, ptr %gep.16, align 8
  %285 = fmul double %283, %284
  %286 = fadd double %282, %285
  store double %286, ptr %218, align 8
  %287 = load double, ptr %58, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 544
  %288 = load double, ptr %gep.17, align 8
  %289 = fmul double %287, %288
  %290 = fadd double %286, %289
  store double %290, ptr %218, align 8
  %291 = load double, ptr %60, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 576
  %292 = load double, ptr %gep.18, align 8
  %293 = fmul double %291, %292
  %294 = fadd double %290, %293
  store double %294, ptr %218, align 8
  %295 = load double, ptr %62, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 608
  %296 = load double, ptr %gep.19, align 8
  %297 = fmul double %295, %296
  %298 = fadd double %294, %297
  store double %298, ptr %218, align 8
  %299 = load double, ptr %64, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 640
  %300 = load double, ptr %gep.20, align 8
  %301 = fmul double %299, %300
  %302 = fadd double %298, %301
  store double %302, ptr %218, align 8
  %303 = load double, ptr %66, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 672
  %304 = load double, ptr %gep.21, align 8
  %305 = fmul double %303, %304
  %306 = fadd double %302, %305
  store double %306, ptr %218, align 8
  %307 = load double, ptr %68, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 704
  %308 = load double, ptr %gep.22, align 8
  %309 = fmul double %307, %308
  %310 = fadd double %306, %309
  store double %310, ptr %218, align 8
  %311 = load double, ptr %70, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 736
  %312 = load double, ptr %gep.23, align 8
  %313 = fmul double %311, %312
  %314 = fadd double %310, %313
  store double %314, ptr %218, align 8
  %315 = load double, ptr %72, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 768
  %316 = load double, ptr %gep.24, align 8
  %317 = fmul double %315, %316
  %318 = fadd double %314, %317
  store double %318, ptr %218, align 8
  %319 = load double, ptr %74, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 800
  %320 = load double, ptr %gep.25, align 8
  %321 = fmul double %319, %320
  %322 = fadd double %318, %321
  store double %322, ptr %218, align 8
  %323 = load double, ptr %76, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 832
  %324 = load double, ptr %gep.26, align 8
  %325 = fmul double %323, %324
  %326 = fadd double %322, %325
  store double %326, ptr %218, align 8
  %327 = load double, ptr %78, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 864
  %328 = load double, ptr %gep.27, align 8
  %329 = fmul double %327, %328
  %330 = fadd double %326, %329
  store double %330, ptr %218, align 8
  %331 = load double, ptr %80, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 896
  %332 = load double, ptr %gep.28, align 8
  %333 = fmul double %331, %332
  %334 = fadd double %330, %333
  store double %334, ptr %218, align 8
  %335 = load double, ptr %82, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 928
  %336 = load double, ptr %gep.29, align 8
  %337 = fmul double %335, %336
  %338 = fadd double %334, %337
  store double %338, ptr %218, align 8
  %339 = load double, ptr %84, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 960
  %340 = load double, ptr %gep.30, align 8
  %341 = fmul double %339, %340
  %342 = fadd double %338, %341
  store double %342, ptr %218, align 8
  %343 = load double, ptr %86, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 992
  %344 = load double, ptr %gep.31, align 8
  %345 = fmul double %343, %344
  %346 = fadd double %342, %345
  store double %346, ptr %218, align 8
  %347 = add nuw nsw i64 %217, 1
  %exitcond.not = icmp eq i64 %347, 32
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %348 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %348, 32
  br i1 %exitcond5.not, label %349, label %.preheader2

349:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
