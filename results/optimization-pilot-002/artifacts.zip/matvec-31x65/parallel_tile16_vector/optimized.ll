; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  %.promoted = load <16 x double>, ptr %13, align 8
  br label %18

18:                                               ; preds = %17, %18
  %19 = phi <16 x double> [ %.promoted, %17 ], [ %70, %18 ]
  %20 = phi i64 [ 0, %17 ], [ %71, %18 ]
  %21 = getelementptr double, ptr %1, i64 %20
  %unmaskedload = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %21, i64 65
  %unmaskedload64 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %21, i64 130
  %unmaskedload65 = load <1 x double>, ptr %23, align 8
  %24 = shufflevector <1 x double> %unmaskedload65, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = getelementptr double, ptr %21, i64 195
  %unmaskedload66 = load <1 x double>, ptr %25, align 8
  %26 = shufflevector <1 x double> %unmaskedload66, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %27 = getelementptr double, ptr %21, i64 260
  %unmaskedload67 = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %21, i64 325
  %unmaskedload68 = load <1 x double>, ptr %28, align 8
  %29 = getelementptr double, ptr %21, i64 390
  %unmaskedload69 = load <1 x double>, ptr %29, align 8
  %30 = shufflevector <1 x double> %unmaskedload69, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = getelementptr double, ptr %21, i64 455
  %unmaskedload70 = load <1 x double>, ptr %31, align 8
  %32 = shufflevector <1 x double> %unmaskedload70, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %33 = getelementptr double, ptr %21, i64 520
  %unmaskedload71 = load <1 x double>, ptr %33, align 8
  %34 = getelementptr double, ptr %21, i64 585
  %unmaskedload72 = load <1 x double>, ptr %34, align 8
  %35 = getelementptr double, ptr %21, i64 650
  %unmaskedload73 = load <1 x double>, ptr %35, align 8
  %36 = shufflevector <1 x double> %unmaskedload73, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = getelementptr double, ptr %21, i64 715
  %unmaskedload74 = load <1 x double>, ptr %37, align 8
  %38 = shufflevector <1 x double> %unmaskedload74, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %39 = getelementptr double, ptr %21, i64 780
  %unmaskedload75 = load <1 x double>, ptr %39, align 8
  %40 = getelementptr double, ptr %21, i64 845
  %unmaskedload76 = load <1 x double>, ptr %40, align 8
  %41 = getelementptr double, ptr %21, i64 910
  %unmaskedload77 = load <1 x double>, ptr %41, align 8
  %42 = shufflevector <1 x double> %unmaskedload77, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %43 = getelementptr double, ptr %21, i64 975
  %unmaskedload78 = load <1 x double>, ptr %43, align 8
  %44 = shufflevector <1 x double> %unmaskedload78, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %45 = getelementptr double, ptr %8, i64 %20
  %46 = load double, ptr %45, align 8
  %47 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload64, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %49 = shufflevector <4 x double> %48, <4 x double> %26, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %50 = insertelement <4 x double> poison, double %46, i64 0
  %51 = shufflevector <4 x double> %50, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = fmul <4 x double> %49, %51
  %53 = shufflevector <1 x double> %unmaskedload67, <1 x double> %unmaskedload68, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %54 = shufflevector <4 x double> %53, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %55 = shufflevector <4 x double> %54, <4 x double> %32, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %56 = fmul <4 x double> %55, %51
  %57 = shufflevector <4 x double> %52, <4 x double> %56, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %58 = shufflevector <1 x double> %unmaskedload71, <1 x double> %unmaskedload72, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %60 = shufflevector <4 x double> %59, <4 x double> %38, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %61 = fmul <4 x double> %60, %51
  %62 = shufflevector <4 x double> %61, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %63 = shufflevector <16 x double> %57, <16 x double> %62, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <1 x double> %unmaskedload75, <1 x double> %unmaskedload76, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %65 = shufflevector <4 x double> %64, <4 x double> %42, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %66 = shufflevector <4 x double> %65, <4 x double> %44, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %67 = fmul <4 x double> %66, %51
  %68 = shufflevector <4 x double> %67, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %69 = shufflevector <16 x double> %63, <16 x double> %68, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %70 = fadd <16 x double> %19, %69
  store <16 x double> %70, ptr %13, align 8
  %71 = add nuw nsw i64 %20, 1
  %exitcond.not = icmp eq i64 %71, 65
  br i1 %exitcond.not, label %72, label %18

72:                                               ; preds = %18
  %73 = getelementptr double, ptr %1, i64 1040
  %74 = getelementptr double, ptr %13, i64 16
  br label %75

75:                                               ; preds = %75, %72
  %76 = phi i64 [ 0, %72 ], [ %125, %75 ]
  %77 = getelementptr double, ptr %73, i64 %76
  %unmaskedload.1 = load <1 x double>, ptr %77, align 8
  %78 = getelementptr double, ptr %77, i64 65
  %unmaskedload64.1 = load <1 x double>, ptr %78, align 8
  %79 = getelementptr double, ptr %77, i64 130
  %unmaskedload65.1 = load <1 x double>, ptr %79, align 8
  %80 = shufflevector <1 x double> %unmaskedload65.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = getelementptr double, ptr %77, i64 195
  %unmaskedload66.1 = load <1 x double>, ptr %81, align 8
  %82 = shufflevector <1 x double> %unmaskedload66.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %83 = getelementptr double, ptr %77, i64 260
  %unmaskedload67.1 = load <1 x double>, ptr %83, align 8
  %84 = getelementptr double, ptr %77, i64 325
  %unmaskedload68.1 = load <1 x double>, ptr %84, align 8
  %85 = getelementptr double, ptr %77, i64 390
  %unmaskedload69.1 = load <1 x double>, ptr %85, align 8
  %86 = shufflevector <1 x double> %unmaskedload69.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = getelementptr double, ptr %77, i64 455
  %unmaskedload70.1 = load <1 x double>, ptr %87, align 8
  %88 = shufflevector <1 x double> %unmaskedload70.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %89 = getelementptr double, ptr %77, i64 520
  %unmaskedload71.1 = load <1 x double>, ptr %89, align 8
  %90 = getelementptr double, ptr %77, i64 585
  %unmaskedload72.1 = load <1 x double>, ptr %90, align 8
  %91 = getelementptr double, ptr %77, i64 650
  %unmaskedload73.1 = load <1 x double>, ptr %91, align 8
  %92 = shufflevector <1 x double> %unmaskedload73.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %93 = getelementptr double, ptr %77, i64 715
  %unmaskedload74.1 = load <1 x double>, ptr %93, align 8
  %94 = shufflevector <1 x double> %unmaskedload74.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %95 = getelementptr double, ptr %77, i64 780
  %unmaskedload75.1 = load <1 x double>, ptr %95, align 8
  %96 = getelementptr double, ptr %77, i64 845
  %unmaskedload76.1 = load <1 x double>, ptr %96, align 8
  %97 = getelementptr double, ptr %77, i64 910
  %unmaskedload77.1 = load <1 x double>, ptr %97, align 8
  %98 = shufflevector <1 x double> %unmaskedload77.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %99 = getelementptr double, ptr %8, i64 %76
  %100 = load double, ptr %99, align 8
  %101 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %74, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %102 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload64.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %103 = shufflevector <4 x double> %102, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %104 = shufflevector <4 x double> %103, <4 x double> %82, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %105 = insertelement <4 x double> poison, double %100, i64 0
  %106 = shufflevector <4 x double> %105, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = fmul <4 x double> %104, %106
  %108 = shufflevector <1 x double> %unmaskedload67.1, <1 x double> %unmaskedload68.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %109 = shufflevector <4 x double> %108, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %110 = shufflevector <4 x double> %109, <4 x double> %88, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %111 = fmul <4 x double> %110, %106
  %112 = shufflevector <4 x double> %107, <4 x double> %111, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %113 = shufflevector <1 x double> %unmaskedload71.1, <1 x double> %unmaskedload72.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %114 = shufflevector <4 x double> %113, <4 x double> %92, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %115 = shufflevector <4 x double> %114, <4 x double> %94, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %116 = fmul <4 x double> %115, %106
  %117 = shufflevector <4 x double> %116, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %118 = shufflevector <16 x double> %112, <16 x double> %117, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %119 = shufflevector <1 x double> %unmaskedload75.1, <1 x double> %unmaskedload76.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %120 = shufflevector <4 x double> %119, <4 x double> %98, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %121 = fmul <4 x double> %120, %106
  %122 = shufflevector <4 x double> %121, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %123 = shufflevector <16 x double> %118, <16 x double> %122, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 poison>
  %124 = fadd <16 x double> %101, %123
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %124, ptr %74, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %125 = add nuw nsw i64 %76, 1
  %exitcond.not.1 = icmp eq i64 %125, 65
  br i1 %exitcond.not.1, label %126, label %75

126:                                              ; preds = %75
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi <16 x double> [ zeroinitializer, %3 ], [ %56, %4 ]
  %6 = phi i64 [ 0, %3 ], [ %57, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %6
  %unmaskedload.i = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %7, i64 65
  %unmaskedload64.i = load <1 x double>, ptr %8, align 8
  %9 = getelementptr double, ptr %7, i64 130
  %unmaskedload65.i = load <1 x double>, ptr %9, align 8
  %10 = shufflevector <1 x double> %unmaskedload65.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %11 = getelementptr double, ptr %7, i64 195
  %unmaskedload66.i = load <1 x double>, ptr %11, align 8
  %12 = shufflevector <1 x double> %unmaskedload66.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %13 = getelementptr double, ptr %7, i64 260
  %unmaskedload67.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %7, i64 325
  %unmaskedload68.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %7, i64 390
  %unmaskedload69.i = load <1 x double>, ptr %15, align 8
  %16 = shufflevector <1 x double> %unmaskedload69.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %17 = getelementptr double, ptr %7, i64 455
  %unmaskedload70.i = load <1 x double>, ptr %17, align 8
  %18 = shufflevector <1 x double> %unmaskedload70.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %19 = getelementptr double, ptr %7, i64 520
  %unmaskedload71.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %7, i64 585
  %unmaskedload72.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %7, i64 650
  %unmaskedload73.i = load <1 x double>, ptr %21, align 8
  %22 = shufflevector <1 x double> %unmaskedload73.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = getelementptr double, ptr %7, i64 715
  %unmaskedload74.i = load <1 x double>, ptr %23, align 8
  %24 = shufflevector <1 x double> %unmaskedload74.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = getelementptr double, ptr %7, i64 780
  %unmaskedload75.i = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %7, i64 845
  %unmaskedload76.i = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %7, i64 910
  %unmaskedload77.i = load <1 x double>, ptr %27, align 8
  %28 = shufflevector <1 x double> %unmaskedload77.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = getelementptr double, ptr %7, i64 975
  %unmaskedload = load <1 x double>, ptr %29, align 8
  %30 = shufflevector <1 x double> %unmaskedload, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = getelementptr double, ptr %.unpack17, i64 %6
  %32 = load double, ptr %31, align 8
  %33 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload64.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %34 = shufflevector <4 x double> %33, <4 x double> %10, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %35 = shufflevector <4 x double> %34, <4 x double> %12, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %36 = insertelement <4 x double> poison, double %32, i64 0
  %37 = shufflevector <4 x double> %36, <4 x double> poison, <4 x i32> zeroinitializer
  %38 = fmul <4 x double> %35, %37
  %39 = shufflevector <1 x double> %unmaskedload67.i, <1 x double> %unmaskedload68.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %16, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %18, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = fmul <4 x double> %41, %37
  %43 = shufflevector <4 x double> %38, <4 x double> %42, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %44 = shufflevector <1 x double> %unmaskedload71.i, <1 x double> %unmaskedload72.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %45 = shufflevector <4 x double> %44, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %47 = fmul <4 x double> %46, %37
  %48 = shufflevector <4 x double> %47, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %49 = shufflevector <16 x double> %43, <16 x double> %48, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %unmaskedload75.i, <1 x double> %unmaskedload76.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fmul <4 x double> %52, %37
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <16 x double> %49, <16 x double> %54, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %56 = fadd <16 x double> %5, %55
  store <16 x double> %56, ptr %.unpack28, align 8
  %57 = add nuw nsw i64 %6, 1
  %exitcond.not.i = icmp eq i64 %57, 65
  br i1 %exitcond.not.i, label %58, label %4

58:                                               ; preds = %4
  %59 = getelementptr double, ptr %.unpack2, i64 1040
  %60 = getelementptr double, ptr %.unpack28, i64 16
  br label %61

61:                                               ; preds = %61, %58
  %62 = phi i64 [ 0, %58 ], [ %114, %61 ]
  %63 = getelementptr double, ptr %59, i64 %62
  %unmaskedload.i.1 = load <1 x double>, ptr %63, align 8
  %64 = getelementptr double, ptr %63, i64 65
  %unmaskedload64.i.1 = load <1 x double>, ptr %64, align 8
  %65 = getelementptr double, ptr %63, i64 130
  %unmaskedload65.i.1 = load <1 x double>, ptr %65, align 8
  %66 = shufflevector <1 x double> %unmaskedload65.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %67 = getelementptr double, ptr %63, i64 195
  %unmaskedload66.i.1 = load <1 x double>, ptr %67, align 8
  %68 = shufflevector <1 x double> %unmaskedload66.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %69 = getelementptr double, ptr %63, i64 260
  %unmaskedload67.i.1 = load <1 x double>, ptr %69, align 8
  %70 = getelementptr double, ptr %63, i64 325
  %unmaskedload68.i.1 = load <1 x double>, ptr %70, align 8
  %71 = getelementptr double, ptr %63, i64 390
  %unmaskedload69.i.1 = load <1 x double>, ptr %71, align 8
  %72 = shufflevector <1 x double> %unmaskedload69.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = getelementptr double, ptr %63, i64 455
  %unmaskedload70.i.1 = load <1 x double>, ptr %73, align 8
  %74 = shufflevector <1 x double> %unmaskedload70.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = getelementptr double, ptr %63, i64 520
  %unmaskedload71.i.1 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %63, i64 585
  %unmaskedload72.i.1 = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %63, i64 650
  %unmaskedload73.i.1 = load <1 x double>, ptr %77, align 8
  %78 = shufflevector <1 x double> %unmaskedload73.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = getelementptr double, ptr %63, i64 715
  %unmaskedload74.i.1 = load <1 x double>, ptr %79, align 8
  %80 = shufflevector <1 x double> %unmaskedload74.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = getelementptr double, ptr %63, i64 780
  %unmaskedload75.i.1 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %63, i64 845
  %unmaskedload76.i.1 = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %63, i64 910
  %unmaskedload77.i.1 = load <1 x double>, ptr %83, align 8
  %84 = getelementptr double, ptr %.unpack17, i64 %62
  %85 = load double, ptr %84, align 8
  %86 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %60, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %87 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload64.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %88 = shufflevector <4 x double> %87, <4 x double> %66, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %89 = shufflevector <4 x double> %88, <4 x double> %68, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %90 = insertelement <4 x double> poison, double %85, i64 0
  %91 = shufflevector <4 x double> %90, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = fmul <4 x double> %89, %91
  %93 = shufflevector <1 x double> %unmaskedload67.i.1, <1 x double> %unmaskedload68.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %95 = shufflevector <4 x double> %94, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %96 = fmul <4 x double> %95, %91
  %97 = shufflevector <4 x double> %92, <4 x double> %96, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %98 = shufflevector <1 x double> %unmaskedload71.i.1, <1 x double> %unmaskedload72.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %99 = shufflevector <4 x double> %98, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %101 = fmul <4 x double> %100, %91
  %102 = shufflevector <4 x double> %101, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %103 = shufflevector <16 x double> %97, <16 x double> %102, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <1 x double> %unmaskedload75.i.1, <1 x double> %unmaskedload76.i.1, <2 x i32> <i32 0, i32 1>
  %105 = insertelement <2 x double> poison, double %85, i64 0
  %106 = shufflevector <2 x double> %105, <2 x double> poison, <2 x i32> zeroinitializer
  %107 = fmul <2 x double> %104, %106
  %108 = shufflevector <2 x double> %107, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %109 = shufflevector <16 x double> %103, <16 x double> %108, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %110 = extractelement <1 x double> %unmaskedload77.i.1, i64 0
  %111 = fmul double %110, %85
  %112 = insertelement <16 x double> %109, double %111, i64 14
  %113 = fadd <16 x double> %86, %112
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %113, ptr %60, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %114 = add nuw nsw i64 %62, 1
  %exitcond.not.i.1 = icmp eq i64 %114, 65
  br i1 %exitcond.not.i.1, label %kernel.exit, label %61

kernel.exit:                                      ; preds = %61
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <16 x double> @llvm.masked.load.v16f64.p0(ptr nocapture, i32 immarg, <16 x i1>, <16 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v16f64.p0(<16 x double>, ptr nocapture, i32 immarg, <16 x i1>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %10, i8 0, i64 248, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi <16 x double> [ zeroinitializer, %1 ], [ %63, %11 ]
  %13 = phi i64 [ 0, %1 ], [ %64, %11 ]
  %14 = getelementptr double, ptr %4, i64 %13
  %unmaskedload.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %14, i64 65
  %unmaskedload64.i = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %14, i64 130
  %unmaskedload65.i = load <1 x double>, ptr %16, align 8
  %17 = shufflevector <1 x double> %unmaskedload65.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %18 = getelementptr double, ptr %14, i64 195
  %unmaskedload66.i = load <1 x double>, ptr %18, align 8
  %19 = shufflevector <1 x double> %unmaskedload66.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %20 = getelementptr double, ptr %14, i64 260
  %unmaskedload67.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %14, i64 325
  %unmaskedload68.i = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %14, i64 390
  %unmaskedload69.i = load <1 x double>, ptr %22, align 8
  %23 = shufflevector <1 x double> %unmaskedload69.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %24 = getelementptr double, ptr %14, i64 455
  %unmaskedload70.i = load <1 x double>, ptr %24, align 8
  %25 = shufflevector <1 x double> %unmaskedload70.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %26 = getelementptr double, ptr %14, i64 520
  %unmaskedload71.i = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %14, i64 585
  %unmaskedload72.i = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %14, i64 650
  %unmaskedload73.i = load <1 x double>, ptr %28, align 8
  %29 = shufflevector <1 x double> %unmaskedload73.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %30 = getelementptr double, ptr %14, i64 715
  %unmaskedload74.i = load <1 x double>, ptr %30, align 8
  %31 = shufflevector <1 x double> %unmaskedload74.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %32 = getelementptr double, ptr %14, i64 780
  %unmaskedload75.i = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %14, i64 845
  %unmaskedload76.i = load <1 x double>, ptr %33, align 8
  %34 = getelementptr double, ptr %14, i64 910
  %unmaskedload77.i = load <1 x double>, ptr %34, align 8
  %35 = shufflevector <1 x double> %unmaskedload77.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %36 = getelementptr double, ptr %14, i64 975
  %unmaskedload = load <1 x double>, ptr %36, align 8
  %37 = shufflevector <1 x double> %unmaskedload, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %38 = getelementptr double, ptr %7, i64 %13
  %39 = load double, ptr %38, align 8
  %40 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload64.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %17, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %42 = shufflevector <4 x double> %41, <4 x double> %19, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %43 = insertelement <4 x double> poison, double %39, i64 0
  %44 = shufflevector <4 x double> %43, <4 x double> poison, <4 x i32> zeroinitializer
  %45 = fmul <4 x double> %42, %44
  %46 = shufflevector <1 x double> %unmaskedload67.i, <1 x double> %unmaskedload68.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %23, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %48 = shufflevector <4 x double> %47, <4 x double> %25, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %49 = fmul <4 x double> %48, %44
  %50 = shufflevector <4 x double> %45, <4 x double> %49, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %51 = shufflevector <1 x double> %unmaskedload71.i, <1 x double> %unmaskedload72.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %29, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %53 = shufflevector <4 x double> %52, <4 x double> %31, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %54 = fmul <4 x double> %53, %44
  %55 = shufflevector <4 x double> %54, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <16 x double> %50, <16 x double> %55, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %57 = shufflevector <1 x double> %unmaskedload75.i, <1 x double> %unmaskedload76.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %35, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %59 = shufflevector <4 x double> %58, <4 x double> %37, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %60 = fmul <4 x double> %59, %44
  %61 = shufflevector <4 x double> %60, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %62 = shufflevector <16 x double> %56, <16 x double> %61, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %63 = fadd <16 x double> %12, %62
  store <16 x double> %63, ptr %10, align 8
  %64 = add nuw nsw i64 %13, 1
  %exitcond.not.i = icmp eq i64 %64, 65
  br i1 %exitcond.not.i, label %65, label %11

65:                                               ; preds = %11
  %66 = getelementptr double, ptr %4, i64 1040
  %67 = getelementptr double, ptr %10, i64 16
  br label %68

68:                                               ; preds = %68, %65
  %69 = phi i64 [ 0, %65 ], [ %121, %68 ]
  %70 = getelementptr double, ptr %66, i64 %69
  %unmaskedload.i.1 = load <1 x double>, ptr %70, align 8
  %71 = getelementptr double, ptr %70, i64 65
  %unmaskedload64.i.1 = load <1 x double>, ptr %71, align 8
  %72 = getelementptr double, ptr %70, i64 130
  %unmaskedload65.i.1 = load <1 x double>, ptr %72, align 8
  %73 = shufflevector <1 x double> %unmaskedload65.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %74 = getelementptr double, ptr %70, i64 195
  %unmaskedload66.i.1 = load <1 x double>, ptr %74, align 8
  %75 = shufflevector <1 x double> %unmaskedload66.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %76 = getelementptr double, ptr %70, i64 260
  %unmaskedload67.i.1 = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %70, i64 325
  %unmaskedload68.i.1 = load <1 x double>, ptr %77, align 8
  %78 = getelementptr double, ptr %70, i64 390
  %unmaskedload69.i.1 = load <1 x double>, ptr %78, align 8
  %79 = shufflevector <1 x double> %unmaskedload69.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %80 = getelementptr double, ptr %70, i64 455
  %unmaskedload70.i.1 = load <1 x double>, ptr %80, align 8
  %81 = shufflevector <1 x double> %unmaskedload70.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %82 = getelementptr double, ptr %70, i64 520
  %unmaskedload71.i.1 = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %70, i64 585
  %unmaskedload72.i.1 = load <1 x double>, ptr %83, align 8
  %84 = getelementptr double, ptr %70, i64 650
  %unmaskedload73.i.1 = load <1 x double>, ptr %84, align 8
  %85 = shufflevector <1 x double> %unmaskedload73.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %86 = getelementptr double, ptr %70, i64 715
  %unmaskedload74.i.1 = load <1 x double>, ptr %86, align 8
  %87 = shufflevector <1 x double> %unmaskedload74.i.1, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %88 = getelementptr double, ptr %70, i64 780
  %unmaskedload75.i.1 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %70, i64 845
  %unmaskedload76.i.1 = load <1 x double>, ptr %89, align 8
  %90 = getelementptr double, ptr %70, i64 910
  %unmaskedload77.i.1 = load <1 x double>, ptr %90, align 8
  %91 = getelementptr double, ptr %7, i64 %69
  %92 = load double, ptr %91, align 8
  %93 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %67, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %94 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload64.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %95 = shufflevector <4 x double> %94, <4 x double> %73, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %96 = shufflevector <4 x double> %95, <4 x double> %75, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %97 = insertelement <4 x double> poison, double %92, i64 0
  %98 = shufflevector <4 x double> %97, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = fmul <4 x double> %96, %98
  %100 = shufflevector <1 x double> %unmaskedload67.i.1, <1 x double> %unmaskedload68.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %79, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %102 = shufflevector <4 x double> %101, <4 x double> %81, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %103 = fmul <4 x double> %102, %98
  %104 = shufflevector <4 x double> %99, <4 x double> %103, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %105 = shufflevector <1 x double> %unmaskedload71.i.1, <1 x double> %unmaskedload72.i.1, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %106 = shufflevector <4 x double> %105, <4 x double> %85, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %107 = shufflevector <4 x double> %106, <4 x double> %87, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %108 = fmul <4 x double> %107, %98
  %109 = shufflevector <4 x double> %108, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %110 = shufflevector <16 x double> %104, <16 x double> %109, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <1 x double> %unmaskedload75.i.1, <1 x double> %unmaskedload76.i.1, <2 x i32> <i32 0, i32 1>
  %112 = insertelement <2 x double> poison, double %92, i64 0
  %113 = shufflevector <2 x double> %112, <2 x double> poison, <2 x i32> zeroinitializer
  %114 = fmul <2 x double> %111, %113
  %115 = shufflevector <2 x double> %114, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %116 = shufflevector <16 x double> %110, <16 x double> %115, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %117 = extractelement <1 x double> %unmaskedload77.i.1, i64 0
  %118 = fmul double %117, %92
  %119 = insertelement <16 x double> %116, double %118, i64 14
  %120 = fadd <16 x double> %93, %119
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %120, ptr %67, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %121 = add nuw nsw i64 %69, 1
  %exitcond.not.i.1 = icmp eq i64 %121, 65
  br i1 %exitcond.not.i.1, label %kernel.exit, label %68

kernel.exit:                                      ; preds = %68
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28.i, i8 0, i64 248, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi <16 x double> [ zeroinitializer, %1 ], [ %62, %10 ]
  %12 = phi i64 [ 0, %1 ], [ %63, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %12
  %unmaskedload.i.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %13, i64 65
  %unmaskedload64.i.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %13, i64 130
  %unmaskedload65.i.i = load <1 x double>, ptr %15, align 8
  %16 = shufflevector <1 x double> %unmaskedload65.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %17 = getelementptr double, ptr %13, i64 195
  %unmaskedload66.i.i = load <1 x double>, ptr %17, align 8
  %18 = shufflevector <1 x double> %unmaskedload66.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %19 = getelementptr double, ptr %13, i64 260
  %unmaskedload67.i.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %13, i64 325
  %unmaskedload68.i.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %13, i64 390
  %unmaskedload69.i.i = load <1 x double>, ptr %21, align 8
  %22 = shufflevector <1 x double> %unmaskedload69.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %23 = getelementptr double, ptr %13, i64 455
  %unmaskedload70.i.i = load <1 x double>, ptr %23, align 8
  %24 = shufflevector <1 x double> %unmaskedload70.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %25 = getelementptr double, ptr %13, i64 520
  %unmaskedload71.i.i = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %13, i64 585
  %unmaskedload72.i.i = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %13, i64 650
  %unmaskedload73.i.i = load <1 x double>, ptr %27, align 8
  %28 = shufflevector <1 x double> %unmaskedload73.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %29 = getelementptr double, ptr %13, i64 715
  %unmaskedload74.i.i = load <1 x double>, ptr %29, align 8
  %30 = shufflevector <1 x double> %unmaskedload74.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %31 = getelementptr double, ptr %13, i64 780
  %unmaskedload75.i.i = load <1 x double>, ptr %31, align 8
  %32 = getelementptr double, ptr %13, i64 845
  %unmaskedload76.i.i = load <1 x double>, ptr %32, align 8
  %33 = getelementptr double, ptr %13, i64 910
  %unmaskedload77.i.i = load <1 x double>, ptr %33, align 8
  %34 = shufflevector <1 x double> %unmaskedload77.i.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %35 = getelementptr double, ptr %13, i64 975
  %unmaskedload.i = load <1 x double>, ptr %35, align 8
  %36 = shufflevector <1 x double> %unmaskedload.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %37 = getelementptr double, ptr %.unpack17.i, i64 %12
  %38 = load double, ptr %37, align 8
  %39 = shufflevector <1 x double> %unmaskedload.i.i, <1 x double> %unmaskedload64.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %40 = shufflevector <4 x double> %39, <4 x double> %16, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %41 = shufflevector <4 x double> %40, <4 x double> %18, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %42 = insertelement <4 x double> poison, double %38, i64 0
  %43 = shufflevector <4 x double> %42, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = fmul <4 x double> %41, %43
  %45 = shufflevector <1 x double> %unmaskedload67.i.i, <1 x double> %unmaskedload68.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %46 = shufflevector <4 x double> %45, <4 x double> %22, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %47 = shufflevector <4 x double> %46, <4 x double> %24, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %48 = fmul <4 x double> %47, %43
  %49 = shufflevector <4 x double> %44, <4 x double> %48, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %50 = shufflevector <1 x double> %unmaskedload71.i.i, <1 x double> %unmaskedload72.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %51 = shufflevector <4 x double> %50, <4 x double> %28, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %52 = shufflevector <4 x double> %51, <4 x double> %30, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %53 = fmul <4 x double> %52, %43
  %54 = shufflevector <4 x double> %53, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %55 = shufflevector <16 x double> %49, <16 x double> %54, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %56 = shufflevector <1 x double> %unmaskedload75.i.i, <1 x double> %unmaskedload76.i.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %57 = shufflevector <4 x double> %56, <4 x double> %34, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %58 = shufflevector <4 x double> %57, <4 x double> %36, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %59 = fmul <4 x double> %58, %43
  %60 = shufflevector <4 x double> %59, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %61 = shufflevector <16 x double> %55, <16 x double> %60, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 18, i32 19>
  %62 = fadd <16 x double> %11, %61
  store <16 x double> %62, ptr %.unpack28.i, align 8
  %63 = add nuw nsw i64 %12, 1
  %exitcond.not.i.i = icmp eq i64 %63, 65
  br i1 %exitcond.not.i.i, label %64, label %10

64:                                               ; preds = %10
  %65 = getelementptr double, ptr %.unpack2.i, i64 1040
  %66 = getelementptr double, ptr %.unpack28.i, i64 16
  br label %67

67:                                               ; preds = %67, %64
  %68 = phi i64 [ 0, %64 ], [ %120, %67 ]
  %69 = getelementptr double, ptr %65, i64 %68
  %unmaskedload.i.1.i = load <1 x double>, ptr %69, align 8
  %70 = getelementptr double, ptr %69, i64 65
  %unmaskedload64.i.1.i = load <1 x double>, ptr %70, align 8
  %71 = getelementptr double, ptr %69, i64 130
  %unmaskedload65.i.1.i = load <1 x double>, ptr %71, align 8
  %72 = shufflevector <1 x double> %unmaskedload65.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %73 = getelementptr double, ptr %69, i64 195
  %unmaskedload66.i.1.i = load <1 x double>, ptr %73, align 8
  %74 = shufflevector <1 x double> %unmaskedload66.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %75 = getelementptr double, ptr %69, i64 260
  %unmaskedload67.i.1.i = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %69, i64 325
  %unmaskedload68.i.1.i = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %69, i64 390
  %unmaskedload69.i.1.i = load <1 x double>, ptr %77, align 8
  %78 = shufflevector <1 x double> %unmaskedload69.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %79 = getelementptr double, ptr %69, i64 455
  %unmaskedload70.i.1.i = load <1 x double>, ptr %79, align 8
  %80 = shufflevector <1 x double> %unmaskedload70.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %81 = getelementptr double, ptr %69, i64 520
  %unmaskedload71.i.1.i = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %69, i64 585
  %unmaskedload72.i.1.i = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %69, i64 650
  %unmaskedload73.i.1.i = load <1 x double>, ptr %83, align 8
  %84 = shufflevector <1 x double> %unmaskedload73.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %85 = getelementptr double, ptr %69, i64 715
  %unmaskedload74.i.1.i = load <1 x double>, ptr %85, align 8
  %86 = shufflevector <1 x double> %unmaskedload74.i.1.i, <1 x double> poison, <4 x i32> <i32 0, i32 poison, i32 poison, i32 poison>
  %87 = getelementptr double, ptr %69, i64 780
  %unmaskedload75.i.1.i = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %69, i64 845
  %unmaskedload76.i.1.i = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %69, i64 910
  %unmaskedload77.i.1.i = load <1 x double>, ptr %89, align 8
  %90 = getelementptr double, ptr %.unpack17.i, i64 %68
  %91 = load double, ptr %90, align 8
  %92 = tail call <16 x double> @llvm.masked.load.v16f64.p0(ptr %66, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <16 x double> poison)
  %93 = shufflevector <1 x double> %unmaskedload.i.1.i, <1 x double> %unmaskedload64.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %94 = shufflevector <4 x double> %93, <4 x double> %72, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %95 = shufflevector <4 x double> %94, <4 x double> %74, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %96 = insertelement <4 x double> poison, double %91, i64 0
  %97 = shufflevector <4 x double> %96, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = fmul <4 x double> %95, %97
  %99 = shufflevector <1 x double> %unmaskedload67.i.1.i, <1 x double> %unmaskedload68.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %100 = shufflevector <4 x double> %99, <4 x double> %78, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %101 = shufflevector <4 x double> %100, <4 x double> %80, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %102 = fmul <4 x double> %101, %97
  %103 = shufflevector <4 x double> %98, <4 x double> %102, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <1 x double> %unmaskedload71.i.1.i, <1 x double> %unmaskedload72.i.1.i, <4 x i32> <i32 0, i32 1, i32 poison, i32 poison>
  %105 = shufflevector <4 x double> %104, <4 x double> %84, <4 x i32> <i32 0, i32 1, i32 4, i32 poison>
  %106 = shufflevector <4 x double> %105, <4 x double> %86, <4 x i32> <i32 0, i32 1, i32 2, i32 4>
  %107 = fmul <4 x double> %106, %97
  %108 = shufflevector <4 x double> %107, <4 x double> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %109 = shufflevector <16 x double> %103, <16 x double> %108, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 16, i32 17, i32 18, i32 19, i32 poison, i32 poison, i32 poison, i32 poison>
  %110 = shufflevector <1 x double> %unmaskedload75.i.1.i, <1 x double> %unmaskedload76.i.1.i, <2 x i32> <i32 0, i32 1>
  %111 = insertelement <2 x double> poison, double %91, i64 0
  %112 = shufflevector <2 x double> %111, <2 x double> poison, <2 x i32> zeroinitializer
  %113 = fmul <2 x double> %110, %112
  %114 = shufflevector <2 x double> %113, <2 x double> poison, <16 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %115 = shufflevector <16 x double> %109, <16 x double> %114, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 8, i32 9, i32 10, i32 11, i32 16, i32 17, i32 poison, i32 poison>
  %116 = extractelement <1 x double> %unmaskedload77.i.1.i, i64 0
  %117 = fmul double %116, %91
  %118 = insertelement <16 x double> %115, double %117, i64 14
  %119 = fadd <16 x double> %92, %118
  tail call void @llvm.masked.store.v16f64.p0(<16 x double> %119, ptr %66, i32 8, <16 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %120 = add nuw nsw i64 %68, 1
  %exitcond.not.i.1.i = icmp eq i64 %120, 65
  br i1 %exitcond.not.i.1.i, label %_mlir_ciface_kernel.exit, label %67

_mlir_ciface_kernel.exit:                         ; preds = %67
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
