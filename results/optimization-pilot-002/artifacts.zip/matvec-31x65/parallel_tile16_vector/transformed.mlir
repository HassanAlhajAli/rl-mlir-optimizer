#map = affine_map<(d0) -> (-d0 + 31, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0) -> (0, d0)>
module {
  func.func @kernel(%arg0: memref<31x65xf64>, %arg1: memref<65xf64>, %arg2: memref<31xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c16 = arith.constant 16 : index
    %c0_0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<31xf64>)
    %c0_1 = arith.constant 0 : index
    %c31 = arith.constant 31 : index
    %c16_2 = arith.constant 16 : index
    scf.for %arg3 = %c0_1 to %c31 step %c16_2 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 65] [1, 1] : memref<31x65xf64> to memref<?x65xf64, strided<[65, 1], offset: ?>>
      %subview_3 = memref.subview %arg2[%arg3] [%1] [1] : memref<31xf64> to memref<?xf64, strided<[1], offset: ?>>
      %c0_4 = arith.constant 0 : index
      %c0_5 = arith.constant 0 : index
      %c0_6 = arith.constant 0 : index
      %c65 = arith.constant 65 : index
      %c1_7 = arith.constant 1 : index
      scf.for %arg4 = %c0_6 to %c65 step %c1_7 {
        %2 = affine.apply #map1(%0)
        %c0_8 = arith.constant 0 : index
        %subview_9 = memref.subview %subview[0, %arg4] [%0, 1] [1, 1] : memref<?x65xf64, strided<[65, 1], offset: ?>> to memref<?x1xf64, strided<[65, 1], offset: ?>>
        %subview_10 = memref.subview %arg1[%arg4] [1] [1] : memref<65xf64> to memref<1xf64, strided<[1], offset: ?>>
        %c0_11 = arith.constant 0 : index
        %dim = memref.dim %subview_9, %c0_11 : memref<?x1xf64, strided<[65, 1], offset: ?>>
        %c1_12 = arith.constant 1 : index
        %c0_13 = arith.constant 0 : index
        %cst_14 = arith.constant 0.000000e+00 : f64
        %3 = vector.create_mask %dim, %c1_12 : vector<16x1xi1>
        %4 = vector.mask %3 { vector.transfer_read %subview_9[%c0_13, %c0_13], %cst_14 {in_bounds = [true, true]} : memref<?x1xf64, strided<[65, 1], offset: ?>>, vector<16x1xf64> } : vector<16x1xi1> -> vector<16x1xf64>
        %cst_15 = arith.constant 0.000000e+00 : f64
        %5 = vector.transfer_read %subview_10[%c0_13], %cst_15 {permutation_map = #map2} : memref<1xf64, strided<[1], offset: ?>>, vector<16x1xf64>
        %cst_16 = arith.constant 0.000000e+00 : f64
        %6 = vector.create_mask %dim : vector<16xi1>
        %7 = vector.mask %6 { vector.transfer_read %subview_3[%c0_13], %cst_16 {in_bounds = [true]} : memref<?xf64, strided<[1], offset: ?>>, vector<16xf64> } : vector<16xi1> -> vector<16xf64>
        %8 = arith.mulf %4, %5 : vector<16x1xf64>
        %9 = vector.mask %3 { vector.multi_reduction <add>, %8, %7 [1] : vector<16x1xf64> to vector<16xf64> } : vector<16x1xi1> -> vector<16xf64>
        %c0_17 = arith.constant 0 : index
        vector.mask %6 { vector.transfer_write %9, %subview_3[%c0_17] {in_bounds = [true]} : vector<16xf64>, memref<?xf64, strided<[1], offset: ?>> } : vector<16xi1>
      }
    }
    return
  }
}
