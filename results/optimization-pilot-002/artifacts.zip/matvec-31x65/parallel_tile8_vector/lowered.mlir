module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x8xf64>) : !llvm.array<1 x vector<8xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf64>) : vector<8xf64>
    %22 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x1xf64>) : !llvm.array<8 x vector<1xf64>>
    %23 = llvm.mlir.constant(dense<0.000000e+00> : vector<1xf64>) : vector<1xf64>
    %24 = llvm.mlir.constant(7 : index) : i64
    %25 = llvm.mlir.constant(6 : index) : i64
    %26 = llvm.mlir.constant(5 : index) : i64
    %27 = llvm.mlir.constant(4 : index) : i64
    %28 = llvm.mlir.constant(3 : index) : i64
    %29 = llvm.mlir.constant(2 : index) : i64
    %30 = llvm.mlir.constant(dense<false> : vector<8x1xi1>) : !llvm.array<8 x vector<1xi1>>
    %31 = llvm.mlir.constant(dense<false> : vector<1xi1>) : vector<1xi1>
    %32 = llvm.mlir.constant(dense<true> : vector<1xi1>) : vector<1xi1>
    %33 = llvm.mlir.constant(-1 : index) : i64
    %34 = llvm.mlir.constant(65 : index) : i64
    %35 = llvm.mlir.constant(31 : index) : i64
    %36 = llvm.mlir.constant(0 : index) : i64
    %37 = llvm.mlir.constant(1 : index) : i64
    %38 = llvm.mlir.constant(8 : index) : i64
    %39 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    llvm.br ^bb1(%36 : i64)
  ^bb1(%40: i64):  // 2 preds: ^bb0, ^bb2
    %41 = llvm.icmp "slt" %40, %35 : i64
    llvm.cond_br %41, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %42 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %43 = llvm.getelementptr %42[%40] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %39, %43 : f64, !llvm.ptr
    %44 = llvm.add %40, %37  : i64
    llvm.br ^bb1(%44 : i64)
  ^bb3:  // pred: ^bb1
    %45 = llvm.mlir.constant(1 : index) : i64
    %46 = llvm.alloca %45 x !llvm.array<8 x vector<1xf64>> : (i64) -> !llvm.ptr
    %47 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %48 = llvm.insertvalue %46, %47[0] : !llvm.struct<(ptr, ptr, i64)> 
    %49 = llvm.insertvalue %46, %48[1] : !llvm.struct<(ptr, ptr, i64)> 
    %50 = llvm.mlir.constant(0 : index) : i64
    %51 = llvm.insertvalue %50, %49[2] : !llvm.struct<(ptr, ptr, i64)> 
    %52 = llvm.mlir.constant(1 : index) : i64
    %53 = llvm.alloca %52 x !llvm.array<8 x vector<1xi1>> : (i64) -> !llvm.ptr
    %54 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %55 = llvm.insertvalue %53, %54[0] : !llvm.struct<(ptr, ptr, i64)> 
    %56 = llvm.insertvalue %53, %55[1] : !llvm.struct<(ptr, ptr, i64)> 
    %57 = llvm.mlir.constant(0 : index) : i64
    %58 = llvm.insertvalue %57, %56[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%36 : i64)
  ^bb4(%59: i64):  // 2 preds: ^bb3, ^bb11
    %60 = llvm.icmp "slt" %59, %35 : i64
    llvm.cond_br %60, ^bb5, ^bb12
  ^bb5:  // pred: ^bb4
    %61 = llvm.mul %59, %33  : i64
    %62 = llvm.add %61, %35  : i64
    %63 = llvm.icmp "slt" %62, %38 : i64
    %64 = llvm.select %63, %62, %38 : i1, i64
    %65 = llvm.mul %59, %33  : i64
    %66 = llvm.add %65, %35  : i64
    %67 = llvm.icmp "slt" %66, %38 : i64
    %68 = llvm.select %67, %66, %38 : i1, i64
    %69 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %70 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %71 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %72 = llvm.insertvalue %69, %71[0] : !llvm.struct<(ptr, ptr, i64)> 
    %73 = llvm.insertvalue %70, %72[1] : !llvm.struct<(ptr, ptr, i64)> 
    %74 = llvm.mlir.constant(0 : index) : i64
    %75 = llvm.insertvalue %74, %73[2] : !llvm.struct<(ptr, ptr, i64)> 
    %76 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %77 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %78 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %79 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %80 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %81 = llvm.mul %59, %34  : i64
    %82 = llvm.extractvalue %19[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %83 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %84 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %85 = llvm.insertvalue %82, %84[0] : !llvm.struct<(ptr, ptr, i64)> 
    %86 = llvm.insertvalue %83, %85[1] : !llvm.struct<(ptr, ptr, i64)> 
    %87 = llvm.mlir.constant(0 : index) : i64
    %88 = llvm.insertvalue %87, %86[2] : !llvm.struct<(ptr, ptr, i64)> 
    %89 = llvm.extractvalue %19[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.extractvalue %19[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %91 = llvm.extractvalue %19[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %92 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %93 = llvm.insertvalue %82, %92[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %94 = llvm.insertvalue %83, %93[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %95 = llvm.insertvalue %59, %94[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %96 = llvm.insertvalue %68, %95[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %97 = llvm.mlir.constant(1 : index) : i64
    %98 = llvm.insertvalue %97, %96[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%36 : i64)
  ^bb6(%99: i64):  // 2 preds: ^bb5, ^bb10
    %100 = llvm.icmp "slt" %99, %34 : i64
    llvm.cond_br %100, ^bb7, ^bb11
  ^bb7:  // pred: ^bb6
    %101 = llvm.add %81, %99  : i64
    %102 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %103 = llvm.insertvalue %69, %102[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %104 = llvm.insertvalue %70, %103[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %105 = llvm.insertvalue %101, %104[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %106 = llvm.insertvalue %64, %105[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %107 = llvm.mlir.constant(65 : index) : i64
    %108 = llvm.insertvalue %107, %106[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %109 = llvm.mlir.constant(1 : index) : i64
    %110 = llvm.insertvalue %109, %108[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %111 = llvm.mlir.constant(1 : index) : i64
    %112 = llvm.insertvalue %111, %110[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %113 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %114 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %115 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %116 = llvm.insertvalue %113, %115[0] : !llvm.struct<(ptr, ptr, i64)> 
    %117 = llvm.insertvalue %114, %116[1] : !llvm.struct<(ptr, ptr, i64)> 
    %118 = llvm.mlir.constant(0 : index) : i64
    %119 = llvm.insertvalue %118, %117[2] : !llvm.struct<(ptr, ptr, i64)> 
    %120 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %121 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %122 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %123 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %124 = llvm.insertvalue %113, %123[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %125 = llvm.insertvalue %114, %124[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %126 = llvm.insertvalue %99, %125[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %127 = llvm.mlir.constant(1 : index) : i64
    %128 = llvm.insertvalue %127, %126[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %129 = llvm.mlir.constant(1 : index) : i64
    %130 = llvm.insertvalue %129, %128[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %131 = llvm.icmp "sgt" %64, %36 : i64
    %132 = llvm.select %131, %32, %31 : i1, vector<1xi1>
    %133 = llvm.insertvalue %132, %30[0] : !llvm.array<8 x vector<1xi1>> 
    %134 = llvm.icmp "sgt" %64, %37 : i64
    %135 = llvm.select %134, %32, %31 : i1, vector<1xi1>
    %136 = llvm.insertvalue %135, %133[1] : !llvm.array<8 x vector<1xi1>> 
    %137 = llvm.icmp "sgt" %64, %29 : i64
    %138 = llvm.select %137, %32, %31 : i1, vector<1xi1>
    %139 = llvm.insertvalue %138, %136[2] : !llvm.array<8 x vector<1xi1>> 
    %140 = llvm.icmp "sgt" %64, %28 : i64
    %141 = llvm.select %140, %32, %31 : i1, vector<1xi1>
    %142 = llvm.insertvalue %141, %139[3] : !llvm.array<8 x vector<1xi1>> 
    %143 = llvm.icmp "sgt" %64, %27 : i64
    %144 = llvm.select %143, %32, %31 : i1, vector<1xi1>
    %145 = llvm.insertvalue %144, %142[4] : !llvm.array<8 x vector<1xi1>> 
    %146 = llvm.icmp "sgt" %64, %26 : i64
    %147 = llvm.select %146, %32, %31 : i1, vector<1xi1>
    %148 = llvm.insertvalue %147, %145[5] : !llvm.array<8 x vector<1xi1>> 
    %149 = llvm.icmp "sgt" %64, %25 : i64
    %150 = llvm.select %149, %32, %31 : i1, vector<1xi1>
    %151 = llvm.insertvalue %150, %148[6] : !llvm.array<8 x vector<1xi1>> 
    %152 = llvm.icmp "sgt" %64, %24 : i64
    %153 = llvm.select %152, %32, %31 : i1, vector<1xi1>
    %154 = llvm.insertvalue %153, %151[7] : !llvm.array<8 x vector<1xi1>> 
    llvm.store %154, %53 : !llvm.array<8 x vector<1xi1>>, !llvm.ptr
    %155 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %156 = llvm.extractvalue %51[0] : !llvm.struct<(ptr, ptr, i64)> 
    %157 = llvm.insertvalue %156, %155[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %158 = llvm.extractvalue %51[1] : !llvm.struct<(ptr, ptr, i64)> 
    %159 = llvm.insertvalue %158, %157[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %160 = llvm.mlir.constant(0 : index) : i64
    %161 = llvm.insertvalue %160, %159[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %162 = llvm.mlir.constant(8 : index) : i64
    %163 = llvm.insertvalue %162, %161[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %164 = llvm.mlir.constant(1 : index) : i64
    %165 = llvm.insertvalue %164, %163[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %166 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %167 = llvm.extractvalue %58[0] : !llvm.struct<(ptr, ptr, i64)> 
    %168 = llvm.insertvalue %167, %166[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %169 = llvm.extractvalue %58[1] : !llvm.struct<(ptr, ptr, i64)> 
    %170 = llvm.insertvalue %169, %168[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %171 = llvm.mlir.constant(0 : index) : i64
    %172 = llvm.insertvalue %171, %170[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %173 = llvm.mlir.constant(8 : index) : i64
    %174 = llvm.insertvalue %173, %172[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %175 = llvm.mlir.constant(1 : index) : i64
    %176 = llvm.insertvalue %175, %174[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb8(%36 : i64)
  ^bb8(%177: i64):  // 2 preds: ^bb7, ^bb9
    %178 = llvm.icmp "slt" %177, %38 : i64
    llvm.cond_br %178, ^bb9, ^bb10
  ^bb9:  // pred: ^bb8
    %179 = llvm.getelementptr %169[%177] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xi1>
    %180 = llvm.load %179 : !llvm.ptr -> vector<1xi1>
    %181 = llvm.extractvalue %112[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %182 = llvm.extractvalue %112[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %183 = llvm.getelementptr %181[%182] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %184 = llvm.mlir.constant(65 : index) : i64
    %185 = llvm.mul %177, %184  : i64
    %186 = llvm.add %185, %36  : i64
    %187 = llvm.getelementptr %183[%186] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %188 = llvm.intr.masked.load %187, %180, %23 {alignment = 8 : i32} : (!llvm.ptr, vector<1xi1>, vector<1xf64>) -> vector<1xf64>
    %189 = llvm.getelementptr %158[%177] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %188, %189 : vector<1xf64>, !llvm.ptr
    %190 = llvm.add %177, %37  : i64
    llvm.br ^bb8(%190 : i64)
  ^bb10:  // pred: ^bb8
    %191 = llvm.load %46 : !llvm.ptr -> !llvm.array<8 x vector<1xf64>>
    %192 = llvm.getelementptr %114[%99] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %193 = llvm.getelementptr %192[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %194 = llvm.load %193 : !llvm.ptr -> f64
    %195 = llvm.mlir.undef : vector<1xf64>
    %196 = llvm.mlir.constant(0 : i32) : i32
    %197 = llvm.insertelement %194, %195[%196 : i32] : vector<1xf64>
    %198 = llvm.shufflevector %197, %195 [0] : vector<1xf64> 
    %199 = llvm.insertvalue %198, %22[0] : !llvm.array<8 x vector<1xf64>> 
    %200 = llvm.insertvalue %198, %199[1] : !llvm.array<8 x vector<1xf64>> 
    %201 = llvm.insertvalue %198, %200[2] : !llvm.array<8 x vector<1xf64>> 
    %202 = llvm.insertvalue %198, %201[3] : !llvm.array<8 x vector<1xf64>> 
    %203 = llvm.insertvalue %198, %202[4] : !llvm.array<8 x vector<1xf64>> 
    %204 = llvm.insertvalue %198, %203[5] : !llvm.array<8 x vector<1xf64>> 
    %205 = llvm.insertvalue %198, %204[6] : !llvm.array<8 x vector<1xf64>> 
    %206 = llvm.insertvalue %198, %205[7] : !llvm.array<8 x vector<1xf64>> 
    %207 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
    %208 = llvm.trunc %64 : i64 to i32
    %209 = llvm.mlir.undef : vector<8xi32>
    %210 = llvm.mlir.constant(0 : i32) : i32
    %211 = llvm.insertelement %208, %209[%210 : i32] : vector<8xi32>
    %212 = llvm.shufflevector %211, %209 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
    %213 = llvm.icmp "sgt" %212, %207 : vector<8xi32>
    %214 = llvm.extractvalue %98[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %215 = llvm.extractvalue %98[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %216 = llvm.getelementptr %214[%215] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %217 = llvm.getelementptr %216[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %218 = llvm.intr.masked.load %217, %213, %21 {alignment = 8 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf64>) -> vector<8xf64>
    %219 = llvm.mlir.undef : !llvm.array<8 x vector<1xf64>>
    %220 = llvm.extractvalue %191[0] : !llvm.array<8 x vector<1xf64>> 
    %221 = llvm.fmul %220, %198  : vector<1xf64>
    %222 = llvm.insertvalue %221, %219[0] : !llvm.array<8 x vector<1xf64>> 
    %223 = llvm.extractvalue %191[1] : !llvm.array<8 x vector<1xf64>> 
    %224 = llvm.fmul %223, %198  : vector<1xf64>
    %225 = llvm.insertvalue %224, %222[1] : !llvm.array<8 x vector<1xf64>> 
    %226 = llvm.extractvalue %191[2] : !llvm.array<8 x vector<1xf64>> 
    %227 = llvm.fmul %226, %198  : vector<1xf64>
    %228 = llvm.insertvalue %227, %225[2] : !llvm.array<8 x vector<1xf64>> 
    %229 = llvm.extractvalue %191[3] : !llvm.array<8 x vector<1xf64>> 
    %230 = llvm.fmul %229, %198  : vector<1xf64>
    %231 = llvm.insertvalue %230, %228[3] : !llvm.array<8 x vector<1xf64>> 
    %232 = llvm.extractvalue %191[4] : !llvm.array<8 x vector<1xf64>> 
    %233 = llvm.fmul %232, %198  : vector<1xf64>
    %234 = llvm.insertvalue %233, %231[4] : !llvm.array<8 x vector<1xf64>> 
    %235 = llvm.extractvalue %191[5] : !llvm.array<8 x vector<1xf64>> 
    %236 = llvm.fmul %235, %198  : vector<1xf64>
    %237 = llvm.insertvalue %236, %234[5] : !llvm.array<8 x vector<1xf64>> 
    %238 = llvm.extractvalue %191[6] : !llvm.array<8 x vector<1xf64>> 
    %239 = llvm.fmul %238, %198  : vector<1xf64>
    %240 = llvm.insertvalue %239, %237[6] : !llvm.array<8 x vector<1xf64>> 
    %241 = llvm.extractvalue %191[7] : !llvm.array<8 x vector<1xf64>> 
    %242 = llvm.fmul %241, %198  : vector<1xf64>
    %243 = llvm.insertvalue %242, %240[7] : !llvm.array<8 x vector<1xf64>> 
    %244 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
    %245 = llvm.trunc %64 : i64 to i32
    %246 = llvm.mlir.undef : vector<8xi32>
    %247 = llvm.mlir.constant(0 : i32) : i32
    %248 = llvm.insertelement %245, %246[%247 : i32] : vector<8xi32>
    %249 = llvm.shufflevector %248, %246 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
    %250 = llvm.icmp "sgt" %249, %244 : vector<8xi32>
    %251 = llvm.extractvalue %243[0] : !llvm.array<8 x vector<1xf64>> 
    %252 = llvm.mlir.constant(0 : i64) : i64
    %253 = llvm.extractelement %251[%252 : i64] : vector<1xf64>
    %254 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<8xf64>> 
    %255 = llvm.mlir.constant(0 : i64) : i64
    %256 = llvm.insertelement %253, %254[%255 : i64] : vector<8xf64>
    %257 = llvm.insertvalue %256, %20[0] : !llvm.array<1 x vector<8xf64>> 
    %258 = llvm.extractvalue %243[1] : !llvm.array<8 x vector<1xf64>> 
    %259 = llvm.mlir.constant(0 : i64) : i64
    %260 = llvm.extractelement %258[%259 : i64] : vector<1xf64>
    %261 = llvm.mlir.constant(1 : i64) : i64
    %262 = llvm.insertelement %260, %256[%261 : i64] : vector<8xf64>
    %263 = llvm.insertvalue %262, %257[0] : !llvm.array<1 x vector<8xf64>> 
    %264 = llvm.extractvalue %243[2] : !llvm.array<8 x vector<1xf64>> 
    %265 = llvm.mlir.constant(0 : i64) : i64
    %266 = llvm.extractelement %264[%265 : i64] : vector<1xf64>
    %267 = llvm.mlir.constant(2 : i64) : i64
    %268 = llvm.insertelement %266, %262[%267 : i64] : vector<8xf64>
    %269 = llvm.insertvalue %268, %263[0] : !llvm.array<1 x vector<8xf64>> 
    %270 = llvm.extractvalue %243[3] : !llvm.array<8 x vector<1xf64>> 
    %271 = llvm.mlir.constant(0 : i64) : i64
    %272 = llvm.extractelement %270[%271 : i64] : vector<1xf64>
    %273 = llvm.mlir.constant(3 : i64) : i64
    %274 = llvm.insertelement %272, %268[%273 : i64] : vector<8xf64>
    %275 = llvm.insertvalue %274, %269[0] : !llvm.array<1 x vector<8xf64>> 
    %276 = llvm.extractvalue %243[4] : !llvm.array<8 x vector<1xf64>> 
    %277 = llvm.mlir.constant(0 : i64) : i64
    %278 = llvm.extractelement %276[%277 : i64] : vector<1xf64>
    %279 = llvm.mlir.constant(4 : i64) : i64
    %280 = llvm.insertelement %278, %274[%279 : i64] : vector<8xf64>
    %281 = llvm.insertvalue %280, %275[0] : !llvm.array<1 x vector<8xf64>> 
    %282 = llvm.extractvalue %243[5] : !llvm.array<8 x vector<1xf64>> 
    %283 = llvm.mlir.constant(0 : i64) : i64
    %284 = llvm.extractelement %282[%283 : i64] : vector<1xf64>
    %285 = llvm.mlir.constant(5 : i64) : i64
    %286 = llvm.insertelement %284, %280[%285 : i64] : vector<8xf64>
    %287 = llvm.insertvalue %286, %281[0] : !llvm.array<1 x vector<8xf64>> 
    %288 = llvm.extractvalue %243[6] : !llvm.array<8 x vector<1xf64>> 
    %289 = llvm.mlir.constant(0 : i64) : i64
    %290 = llvm.extractelement %288[%289 : i64] : vector<1xf64>
    %291 = llvm.mlir.constant(6 : i64) : i64
    %292 = llvm.insertelement %290, %286[%291 : i64] : vector<8xf64>
    %293 = llvm.insertvalue %292, %287[0] : !llvm.array<1 x vector<8xf64>> 
    %294 = llvm.extractvalue %243[7] : !llvm.array<8 x vector<1xf64>> 
    %295 = llvm.mlir.constant(0 : i64) : i64
    %296 = llvm.extractelement %294[%295 : i64] : vector<1xf64>
    %297 = llvm.mlir.constant(7 : i64) : i64
    %298 = llvm.insertelement %296, %292[%297 : i64] : vector<8xf64>
    %299 = llvm.insertvalue %298, %293[0] : !llvm.array<1 x vector<8xf64>> 
    %300 = llvm.fadd %218, %298  : vector<8xf64>
    %301 = llvm.select %250, %300, %298 : vector<8xi1>, vector<8xf64>
    %302 = llvm.extractvalue %98[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %303 = llvm.extractvalue %98[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %304 = llvm.getelementptr %302[%303] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %305 = llvm.getelementptr %304[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.intr.masked.store %301, %305, %213 {alignment = 8 : i32} : vector<8xf64>, vector<8xi1> into !llvm.ptr
    %306 = llvm.add %99, %37  : i64
    llvm.br ^bb6(%306 : i64)
  ^bb11:  // pred: ^bb6
    %307 = llvm.add %59, %38  : i64
    llvm.br ^bb4(%307 : i64)
  ^bb12:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
