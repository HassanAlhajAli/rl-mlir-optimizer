; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  %.promoted = load <8 x double>, ptr %13, align 8
  br label %18

18:                                               ; preds = %17, %18
  %19 = phi <8 x double> [ %.promoted, %17 ], [ %46, %18 ]
  %20 = phi i64 [ 0, %17 ], [ %47, %18 ]
  %21 = getelementptr double, ptr %1, i64 %20
  %unmaskedload = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %21, i64 65
  %unmaskedload32 = load <1 x double>, ptr %22, align 8
  %23 = getelementptr double, ptr %21, i64 130
  %unmaskedload33 = load <1 x double>, ptr %23, align 8
  %24 = getelementptr double, ptr %21, i64 195
  %unmaskedload34 = load <1 x double>, ptr %24, align 8
  %25 = getelementptr double, ptr %21, i64 260
  %unmaskedload35 = load <1 x double>, ptr %25, align 8
  %26 = getelementptr double, ptr %21, i64 325
  %unmaskedload36 = load <1 x double>, ptr %26, align 8
  %27 = getelementptr double, ptr %21, i64 390
  %unmaskedload37 = load <1 x double>, ptr %27, align 8
  %28 = getelementptr double, ptr %21, i64 455
  %unmaskedload38 = load <1 x double>, ptr %28, align 8
  %29 = getelementptr double, ptr %8, i64 %20
  %30 = load double, ptr %29, align 8
  %31 = shufflevector <1 x double> %unmaskedload, <1 x double> %unmaskedload32, <2 x i32> <i32 0, i32 1>
  %32 = insertelement <2 x double> poison, double %30, i64 0
  %33 = shufflevector <2 x double> %32, <2 x double> poison, <2 x i32> zeroinitializer
  %34 = fmul <2 x double> %31, %33
  %35 = shufflevector <1 x double> %unmaskedload33, <1 x double> %unmaskedload34, <2 x i32> <i32 0, i32 1>
  %36 = fmul <2 x double> %35, %33
  %37 = shufflevector <2 x double> %34, <2 x double> %36, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %38 = shufflevector <1 x double> %unmaskedload35, <1 x double> %unmaskedload36, <2 x i32> <i32 0, i32 1>
  %39 = fmul <2 x double> %38, %33
  %40 = shufflevector <2 x double> %39, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %41 = shufflevector <8 x double> %37, <8 x double> %40, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %42 = shufflevector <1 x double> %unmaskedload37, <1 x double> %unmaskedload38, <2 x i32> <i32 0, i32 1>
  %43 = fmul <2 x double> %42, %33
  %44 = shufflevector <2 x double> %43, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %45 = shufflevector <8 x double> %41, <8 x double> %44, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %46 = fadd <8 x double> %19, %45
  store <8 x double> %46, ptr %13, align 8
  %47 = add nuw nsw i64 %20, 1
  %exitcond.not = icmp eq i64 %47, 65
  br i1 %exitcond.not, label %48, label %18

48:                                               ; preds = %18
  %49 = getelementptr double, ptr %1, i64 520
  %50 = getelementptr double, ptr %13, i64 8
  %.promoted44 = load <8 x double>, ptr %50, align 8
  br label %51

51:                                               ; preds = %51, %48
  %52 = phi <8 x double> [ %.promoted44, %48 ], [ %79, %51 ]
  %53 = phi i64 [ 0, %48 ], [ %80, %51 ]
  %54 = getelementptr double, ptr %49, i64 %53
  %unmaskedload.1 = load <1 x double>, ptr %54, align 8
  %55 = getelementptr double, ptr %54, i64 65
  %unmaskedload32.1 = load <1 x double>, ptr %55, align 8
  %56 = getelementptr double, ptr %54, i64 130
  %unmaskedload33.1 = load <1 x double>, ptr %56, align 8
  %57 = getelementptr double, ptr %54, i64 195
  %unmaskedload34.1 = load <1 x double>, ptr %57, align 8
  %58 = getelementptr double, ptr %54, i64 260
  %unmaskedload35.1 = load <1 x double>, ptr %58, align 8
  %59 = getelementptr double, ptr %54, i64 325
  %unmaskedload36.1 = load <1 x double>, ptr %59, align 8
  %60 = getelementptr double, ptr %54, i64 390
  %unmaskedload37.1 = load <1 x double>, ptr %60, align 8
  %61 = getelementptr double, ptr %54, i64 455
  %unmaskedload40 = load <1 x double>, ptr %61, align 8
  %62 = getelementptr double, ptr %8, i64 %53
  %63 = load double, ptr %62, align 8
  %64 = shufflevector <1 x double> %unmaskedload.1, <1 x double> %unmaskedload32.1, <2 x i32> <i32 0, i32 1>
  %65 = insertelement <2 x double> poison, double %63, i64 0
  %66 = shufflevector <2 x double> %65, <2 x double> poison, <2 x i32> zeroinitializer
  %67 = fmul <2 x double> %64, %66
  %68 = shufflevector <1 x double> %unmaskedload33.1, <1 x double> %unmaskedload34.1, <2 x i32> <i32 0, i32 1>
  %69 = fmul <2 x double> %68, %66
  %70 = shufflevector <2 x double> %67, <2 x double> %69, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %71 = shufflevector <1 x double> %unmaskedload35.1, <1 x double> %unmaskedload36.1, <2 x i32> <i32 0, i32 1>
  %72 = fmul <2 x double> %71, %66
  %73 = shufflevector <2 x double> %72, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %74 = shufflevector <8 x double> %70, <8 x double> %73, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %75 = shufflevector <1 x double> %unmaskedload37.1, <1 x double> %unmaskedload40, <2 x i32> <i32 0, i32 1>
  %76 = fmul <2 x double> %75, %66
  %77 = shufflevector <2 x double> %76, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %78 = shufflevector <8 x double> %74, <8 x double> %77, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %79 = fadd <8 x double> %52, %78
  store <8 x double> %79, ptr %50, align 8
  %80 = add nuw nsw i64 %53, 1
  %exitcond.not.1 = icmp eq i64 %80, 65
  br i1 %exitcond.not.1, label %81, label %51

81:                                               ; preds = %51
  %82 = getelementptr double, ptr %1, i64 1040
  %83 = getelementptr double, ptr %13, i64 16
  %.promoted45 = load <8 x double>, ptr %83, align 8
  br label %84

84:                                               ; preds = %84, %81
  %85 = phi <8 x double> [ %.promoted45, %81 ], [ %112, %84 ]
  %86 = phi i64 [ 0, %81 ], [ %113, %84 ]
  %87 = getelementptr double, ptr %82, i64 %86
  %unmaskedload.2 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %87, i64 65
  %unmaskedload32.2 = load <1 x double>, ptr %88, align 8
  %89 = getelementptr double, ptr %87, i64 130
  %unmaskedload33.2 = load <1 x double>, ptr %89, align 8
  %90 = getelementptr double, ptr %87, i64 195
  %unmaskedload34.2 = load <1 x double>, ptr %90, align 8
  %91 = getelementptr double, ptr %87, i64 260
  %unmaskedload35.2 = load <1 x double>, ptr %91, align 8
  %92 = getelementptr double, ptr %87, i64 325
  %unmaskedload36.2 = load <1 x double>, ptr %92, align 8
  %93 = getelementptr double, ptr %87, i64 390
  %unmaskedload37.2 = load <1 x double>, ptr %93, align 8
  %94 = getelementptr double, ptr %87, i64 455
  %unmaskedload42 = load <1 x double>, ptr %94, align 8
  %95 = getelementptr double, ptr %8, i64 %86
  %96 = load double, ptr %95, align 8
  %97 = shufflevector <1 x double> %unmaskedload.2, <1 x double> %unmaskedload32.2, <2 x i32> <i32 0, i32 1>
  %98 = insertelement <2 x double> poison, double %96, i64 0
  %99 = shufflevector <2 x double> %98, <2 x double> poison, <2 x i32> zeroinitializer
  %100 = fmul <2 x double> %97, %99
  %101 = shufflevector <1 x double> %unmaskedload33.2, <1 x double> %unmaskedload34.2, <2 x i32> <i32 0, i32 1>
  %102 = fmul <2 x double> %101, %99
  %103 = shufflevector <2 x double> %100, <2 x double> %102, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <1 x double> %unmaskedload35.2, <1 x double> %unmaskedload36.2, <2 x i32> <i32 0, i32 1>
  %105 = fmul <2 x double> %104, %99
  %106 = shufflevector <2 x double> %105, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %107 = shufflevector <8 x double> %103, <8 x double> %106, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %108 = shufflevector <1 x double> %unmaskedload37.2, <1 x double> %unmaskedload42, <2 x i32> <i32 0, i32 1>
  %109 = fmul <2 x double> %108, %99
  %110 = shufflevector <2 x double> %109, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %111 = shufflevector <8 x double> %107, <8 x double> %110, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %112 = fadd <8 x double> %85, %111
  store <8 x double> %112, ptr %83, align 8
  %113 = add nuw nsw i64 %86, 1
  %exitcond.not.2 = icmp eq i64 %113, 65
  br i1 %exitcond.not.2, label %114, label %84

114:                                              ; preds = %84
  %115 = getelementptr double, ptr %1, i64 1560
  %116 = getelementptr double, ptr %13, i64 24
  br label %117

117:                                              ; preds = %117, %114
  %118 = phi i64 [ 0, %114 ], [ %145, %117 ]
  %119 = getelementptr double, ptr %115, i64 %118
  %unmaskedload.3 = load <1 x double>, ptr %119, align 8
  %120 = getelementptr double, ptr %119, i64 65
  %unmaskedload32.3 = load <1 x double>, ptr %120, align 8
  %121 = getelementptr double, ptr %119, i64 130
  %unmaskedload33.3 = load <1 x double>, ptr %121, align 8
  %122 = getelementptr double, ptr %119, i64 195
  %unmaskedload34.3 = load <1 x double>, ptr %122, align 8
  %123 = getelementptr double, ptr %119, i64 260
  %unmaskedload35.3 = load <1 x double>, ptr %123, align 8
  %124 = getelementptr double, ptr %119, i64 325
  %unmaskedload36.3 = load <1 x double>, ptr %124, align 8
  %125 = getelementptr double, ptr %119, i64 390
  %unmaskedload37.3 = load <1 x double>, ptr %125, align 8
  %126 = getelementptr double, ptr %8, i64 %118
  %127 = load double, ptr %126, align 8
  %128 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %116, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %129 = shufflevector <1 x double> %unmaskedload.3, <1 x double> %unmaskedload32.3, <2 x i32> <i32 0, i32 1>
  %130 = insertelement <2 x double> poison, double %127, i64 0
  %131 = shufflevector <2 x double> %130, <2 x double> poison, <2 x i32> zeroinitializer
  %132 = fmul <2 x double> %129, %131
  %133 = shufflevector <1 x double> %unmaskedload33.3, <1 x double> %unmaskedload34.3, <2 x i32> <i32 0, i32 1>
  %134 = fmul <2 x double> %133, %131
  %135 = shufflevector <2 x double> %132, <2 x double> %134, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %136 = shufflevector <1 x double> %unmaskedload35.3, <1 x double> %unmaskedload36.3, <2 x i32> <i32 0, i32 1>
  %137 = fmul <2 x double> %136, %131
  %138 = shufflevector <2 x double> %137, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %139 = shufflevector <8 x double> %135, <8 x double> %138, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %140 = shufflevector <1 x double> %unmaskedload37.3, <1 x double> poison, <2 x i32> <i32 0, i32 poison>
  %141 = fmul <2 x double> %140, %131
  %142 = shufflevector <2 x double> %141, <2 x double> poison, <8 x i32> <i32 0, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %143 = shufflevector <8 x double> %139, <8 x double> %142, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 poison>
  %144 = fadd <8 x double> %128, %143
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %144, ptr %116, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %145 = add nuw nsw i64 %118, 1
  %exitcond.not.3 = icmp eq i64 %145, 65
  br i1 %exitcond.not.3, label %146, label %117

146:                                              ; preds = %117
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi <8 x double> [ zeroinitializer, %3 ], [ %32, %4 ]
  %6 = phi i64 [ 0, %3 ], [ %33, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %6
  %unmaskedload.i = load <1 x double>, ptr %7, align 8
  %8 = getelementptr double, ptr %7, i64 65
  %unmaskedload32.i = load <1 x double>, ptr %8, align 8
  %9 = getelementptr double, ptr %7, i64 130
  %unmaskedload33.i = load <1 x double>, ptr %9, align 8
  %10 = getelementptr double, ptr %7, i64 195
  %unmaskedload34.i = load <1 x double>, ptr %10, align 8
  %11 = getelementptr double, ptr %7, i64 260
  %unmaskedload35.i = load <1 x double>, ptr %11, align 8
  %12 = getelementptr double, ptr %7, i64 325
  %unmaskedload36.i = load <1 x double>, ptr %12, align 8
  %13 = getelementptr double, ptr %7, i64 390
  %unmaskedload37.i = load <1 x double>, ptr %13, align 8
  %14 = getelementptr double, ptr %7, i64 455
  %unmaskedload = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %.unpack17, i64 %6
  %16 = load double, ptr %15, align 8
  %17 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload32.i, <2 x i32> <i32 0, i32 1>
  %18 = insertelement <2 x double> poison, double %16, i64 0
  %19 = shufflevector <2 x double> %18, <2 x double> poison, <2 x i32> zeroinitializer
  %20 = fmul <2 x double> %17, %19
  %21 = shufflevector <1 x double> %unmaskedload33.i, <1 x double> %unmaskedload34.i, <2 x i32> <i32 0, i32 1>
  %22 = fmul <2 x double> %21, %19
  %23 = shufflevector <2 x double> %20, <2 x double> %22, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %24 = shufflevector <1 x double> %unmaskedload35.i, <1 x double> %unmaskedload36.i, <2 x i32> <i32 0, i32 1>
  %25 = fmul <2 x double> %24, %19
  %26 = shufflevector <2 x double> %25, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %27 = shufflevector <8 x double> %23, <8 x double> %26, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %28 = shufflevector <1 x double> %unmaskedload37.i, <1 x double> %unmaskedload, <2 x i32> <i32 0, i32 1>
  %29 = fmul <2 x double> %28, %19
  %30 = shufflevector <2 x double> %29, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %31 = shufflevector <8 x double> %27, <8 x double> %30, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %32 = fadd <8 x double> %5, %31
  store <8 x double> %32, ptr %.unpack28, align 8
  %33 = add nuw nsw i64 %6, 1
  %exitcond.not.i = icmp eq i64 %33, 65
  br i1 %exitcond.not.i, label %34, label %4

34:                                               ; preds = %4
  %35 = getelementptr double, ptr %.unpack2, i64 520
  %36 = getelementptr double, ptr %.unpack28, i64 8
  %.promoted = load <8 x double>, ptr %36, align 8
  br label %37

37:                                               ; preds = %37, %34
  %38 = phi <8 x double> [ %.promoted, %34 ], [ %65, %37 ]
  %39 = phi i64 [ 0, %34 ], [ %66, %37 ]
  %40 = getelementptr double, ptr %35, i64 %39
  %unmaskedload.i.1 = load <1 x double>, ptr %40, align 8
  %41 = getelementptr double, ptr %40, i64 65
  %unmaskedload32.i.1 = load <1 x double>, ptr %41, align 8
  %42 = getelementptr double, ptr %40, i64 130
  %unmaskedload33.i.1 = load <1 x double>, ptr %42, align 8
  %43 = getelementptr double, ptr %40, i64 195
  %unmaskedload34.i.1 = load <1 x double>, ptr %43, align 8
  %44 = getelementptr double, ptr %40, i64 260
  %unmaskedload35.i.1 = load <1 x double>, ptr %44, align 8
  %45 = getelementptr double, ptr %40, i64 325
  %unmaskedload36.i.1 = load <1 x double>, ptr %45, align 8
  %46 = getelementptr double, ptr %40, i64 390
  %unmaskedload37.i.1 = load <1 x double>, ptr %46, align 8
  %47 = getelementptr double, ptr %40, i64 455
  %unmaskedload38 = load <1 x double>, ptr %47, align 8
  %48 = getelementptr double, ptr %.unpack17, i64 %39
  %49 = load double, ptr %48, align 8
  %50 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload32.i.1, <2 x i32> <i32 0, i32 1>
  %51 = insertelement <2 x double> poison, double %49, i64 0
  %52 = shufflevector <2 x double> %51, <2 x double> poison, <2 x i32> zeroinitializer
  %53 = fmul <2 x double> %50, %52
  %54 = shufflevector <1 x double> %unmaskedload33.i.1, <1 x double> %unmaskedload34.i.1, <2 x i32> <i32 0, i32 1>
  %55 = fmul <2 x double> %54, %52
  %56 = shufflevector <2 x double> %53, <2 x double> %55, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %57 = shufflevector <1 x double> %unmaskedload35.i.1, <1 x double> %unmaskedload36.i.1, <2 x i32> <i32 0, i32 1>
  %58 = fmul <2 x double> %57, %52
  %59 = shufflevector <2 x double> %58, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %60 = shufflevector <8 x double> %56, <8 x double> %59, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %61 = shufflevector <1 x double> %unmaskedload37.i.1, <1 x double> %unmaskedload38, <2 x i32> <i32 0, i32 1>
  %62 = fmul <2 x double> %61, %52
  %63 = shufflevector <2 x double> %62, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <8 x double> %60, <8 x double> %63, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %65 = fadd <8 x double> %38, %64
  store <8 x double> %65, ptr %36, align 8
  %66 = add nuw nsw i64 %39, 1
  %exitcond.not.i.1 = icmp eq i64 %66, 65
  br i1 %exitcond.not.i.1, label %67, label %37

67:                                               ; preds = %37
  %68 = getelementptr double, ptr %.unpack2, i64 1040
  %69 = getelementptr double, ptr %.unpack28, i64 16
  %.promoted42 = load <8 x double>, ptr %69, align 8
  br label %70

70:                                               ; preds = %70, %67
  %71 = phi <8 x double> [ %.promoted42, %67 ], [ %98, %70 ]
  %72 = phi i64 [ 0, %67 ], [ %99, %70 ]
  %73 = getelementptr double, ptr %68, i64 %72
  %unmaskedload.i.2 = load <1 x double>, ptr %73, align 8
  %74 = getelementptr double, ptr %73, i64 65
  %unmaskedload32.i.2 = load <1 x double>, ptr %74, align 8
  %75 = getelementptr double, ptr %73, i64 130
  %unmaskedload33.i.2 = load <1 x double>, ptr %75, align 8
  %76 = getelementptr double, ptr %73, i64 195
  %unmaskedload34.i.2 = load <1 x double>, ptr %76, align 8
  %77 = getelementptr double, ptr %73, i64 260
  %unmaskedload35.i.2 = load <1 x double>, ptr %77, align 8
  %78 = getelementptr double, ptr %73, i64 325
  %unmaskedload36.i.2 = load <1 x double>, ptr %78, align 8
  %79 = getelementptr double, ptr %73, i64 390
  %unmaskedload37.i.2 = load <1 x double>, ptr %79, align 8
  %80 = getelementptr double, ptr %73, i64 455
  %unmaskedload40 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %.unpack17, i64 %72
  %82 = load double, ptr %81, align 8
  %83 = shufflevector <1 x double> %unmaskedload.i.2, <1 x double> %unmaskedload32.i.2, <2 x i32> <i32 0, i32 1>
  %84 = insertelement <2 x double> poison, double %82, i64 0
  %85 = shufflevector <2 x double> %84, <2 x double> poison, <2 x i32> zeroinitializer
  %86 = fmul <2 x double> %83, %85
  %87 = shufflevector <1 x double> %unmaskedload33.i.2, <1 x double> %unmaskedload34.i.2, <2 x i32> <i32 0, i32 1>
  %88 = fmul <2 x double> %87, %85
  %89 = shufflevector <2 x double> %86, <2 x double> %88, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %90 = shufflevector <1 x double> %unmaskedload35.i.2, <1 x double> %unmaskedload36.i.2, <2 x i32> <i32 0, i32 1>
  %91 = fmul <2 x double> %90, %85
  %92 = shufflevector <2 x double> %91, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %93 = shufflevector <8 x double> %89, <8 x double> %92, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %94 = shufflevector <1 x double> %unmaskedload37.i.2, <1 x double> %unmaskedload40, <2 x i32> <i32 0, i32 1>
  %95 = fmul <2 x double> %94, %85
  %96 = shufflevector <2 x double> %95, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %97 = shufflevector <8 x double> %93, <8 x double> %96, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %98 = fadd <8 x double> %71, %97
  store <8 x double> %98, ptr %69, align 8
  %99 = add nuw nsw i64 %72, 1
  %exitcond.not.i.2 = icmp eq i64 %99, 65
  br i1 %exitcond.not.i.2, label %100, label %70

100:                                              ; preds = %70
  %101 = getelementptr double, ptr %.unpack2, i64 1560
  %102 = getelementptr double, ptr %.unpack28, i64 24
  br label %103

103:                                              ; preds = %103, %100
  %104 = phi i64 [ 0, %100 ], [ %130, %103 ]
  %105 = getelementptr double, ptr %101, i64 %104
  %unmaskedload.i.3 = load <1 x double>, ptr %105, align 8
  %106 = getelementptr double, ptr %105, i64 65
  %unmaskedload32.i.3 = load <1 x double>, ptr %106, align 8
  %107 = getelementptr double, ptr %105, i64 130
  %unmaskedload33.i.3 = load <1 x double>, ptr %107, align 8
  %108 = getelementptr double, ptr %105, i64 195
  %unmaskedload34.i.3 = load <1 x double>, ptr %108, align 8
  %109 = getelementptr double, ptr %105, i64 260
  %unmaskedload35.i.3 = load <1 x double>, ptr %109, align 8
  %110 = getelementptr double, ptr %105, i64 325
  %unmaskedload36.i.3 = load <1 x double>, ptr %110, align 8
  %111 = getelementptr double, ptr %105, i64 390
  %unmaskedload37.i.3 = load <1 x double>, ptr %111, align 8
  %112 = getelementptr double, ptr %.unpack17, i64 %104
  %113 = load double, ptr %112, align 8
  %114 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %102, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %115 = shufflevector <1 x double> %unmaskedload.i.3, <1 x double> %unmaskedload32.i.3, <2 x i32> <i32 0, i32 1>
  %116 = insertelement <2 x double> poison, double %113, i64 0
  %117 = shufflevector <2 x double> %116, <2 x double> poison, <2 x i32> zeroinitializer
  %118 = fmul <2 x double> %115, %117
  %119 = shufflevector <1 x double> %unmaskedload33.i.3, <1 x double> %unmaskedload34.i.3, <2 x i32> <i32 0, i32 1>
  %120 = fmul <2 x double> %119, %117
  %121 = shufflevector <2 x double> %118, <2 x double> %120, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %122 = shufflevector <1 x double> %unmaskedload35.i.3, <1 x double> %unmaskedload36.i.3, <2 x i32> <i32 0, i32 1>
  %123 = fmul <2 x double> %122, %117
  %124 = shufflevector <2 x double> %123, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %125 = shufflevector <8 x double> %121, <8 x double> %124, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %126 = extractelement <1 x double> %unmaskedload37.i.3, i64 0
  %127 = fmul double %126, %113
  %128 = insertelement <8 x double> %125, double %127, i64 6
  %129 = fadd <8 x double> %114, %128
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %129, ptr %102, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %130 = add nuw nsw i64 %104, 1
  %exitcond.not.i.3 = icmp eq i64 %130, 65
  br i1 %exitcond.not.i.3, label %kernel.exit, label %103

kernel.exit:                                      ; preds = %103
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x double> @llvm.masked.load.v8f64.p0(ptr nocapture, i32 immarg, <8 x i1>, <8 x double>) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f64.p0(<8 x double>, ptr nocapture, i32 immarg, <8 x i1>) #3

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %10, i8 0, i64 248, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi <8 x double> [ zeroinitializer, %1 ], [ %39, %11 ]
  %13 = phi i64 [ 0, %1 ], [ %40, %11 ]
  %14 = getelementptr double, ptr %4, i64 %13
  %unmaskedload.i = load <1 x double>, ptr %14, align 8
  %15 = getelementptr double, ptr %14, i64 65
  %unmaskedload32.i = load <1 x double>, ptr %15, align 8
  %16 = getelementptr double, ptr %14, i64 130
  %unmaskedload33.i = load <1 x double>, ptr %16, align 8
  %17 = getelementptr double, ptr %14, i64 195
  %unmaskedload34.i = load <1 x double>, ptr %17, align 8
  %18 = getelementptr double, ptr %14, i64 260
  %unmaskedload35.i = load <1 x double>, ptr %18, align 8
  %19 = getelementptr double, ptr %14, i64 325
  %unmaskedload36.i = load <1 x double>, ptr %19, align 8
  %20 = getelementptr double, ptr %14, i64 390
  %unmaskedload37.i = load <1 x double>, ptr %20, align 8
  %21 = getelementptr double, ptr %14, i64 455
  %unmaskedload = load <1 x double>, ptr %21, align 8
  %22 = getelementptr double, ptr %7, i64 %13
  %23 = load double, ptr %22, align 8
  %24 = shufflevector <1 x double> %unmaskedload.i, <1 x double> %unmaskedload32.i, <2 x i32> <i32 0, i32 1>
  %25 = insertelement <2 x double> poison, double %23, i64 0
  %26 = shufflevector <2 x double> %25, <2 x double> poison, <2 x i32> zeroinitializer
  %27 = fmul <2 x double> %24, %26
  %28 = shufflevector <1 x double> %unmaskedload33.i, <1 x double> %unmaskedload34.i, <2 x i32> <i32 0, i32 1>
  %29 = fmul <2 x double> %28, %26
  %30 = shufflevector <2 x double> %27, <2 x double> %29, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %31 = shufflevector <1 x double> %unmaskedload35.i, <1 x double> %unmaskedload36.i, <2 x i32> <i32 0, i32 1>
  %32 = fmul <2 x double> %31, %26
  %33 = shufflevector <2 x double> %32, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %34 = shufflevector <8 x double> %30, <8 x double> %33, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %35 = shufflevector <1 x double> %unmaskedload37.i, <1 x double> %unmaskedload, <2 x i32> <i32 0, i32 1>
  %36 = fmul <2 x double> %35, %26
  %37 = shufflevector <2 x double> %36, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %38 = shufflevector <8 x double> %34, <8 x double> %37, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %39 = fadd <8 x double> %12, %38
  store <8 x double> %39, ptr %10, align 8
  %40 = add nuw nsw i64 %13, 1
  %exitcond.not.i = icmp eq i64 %40, 65
  br i1 %exitcond.not.i, label %41, label %11

41:                                               ; preds = %11
  %42 = getelementptr double, ptr %4, i64 520
  %43 = getelementptr double, ptr %10, i64 8
  %.promoted6 = load <8 x double>, ptr %43, align 8
  br label %44

44:                                               ; preds = %44, %41
  %45 = phi <8 x double> [ %.promoted6, %41 ], [ %72, %44 ]
  %46 = phi i64 [ 0, %41 ], [ %73, %44 ]
  %47 = getelementptr double, ptr %42, i64 %46
  %unmaskedload.i.1 = load <1 x double>, ptr %47, align 8
  %48 = getelementptr double, ptr %47, i64 65
  %unmaskedload32.i.1 = load <1 x double>, ptr %48, align 8
  %49 = getelementptr double, ptr %47, i64 130
  %unmaskedload33.i.1 = load <1 x double>, ptr %49, align 8
  %50 = getelementptr double, ptr %47, i64 195
  %unmaskedload34.i.1 = load <1 x double>, ptr %50, align 8
  %51 = getelementptr double, ptr %47, i64 260
  %unmaskedload35.i.1 = load <1 x double>, ptr %51, align 8
  %52 = getelementptr double, ptr %47, i64 325
  %unmaskedload36.i.1 = load <1 x double>, ptr %52, align 8
  %53 = getelementptr double, ptr %47, i64 390
  %unmaskedload37.i.1 = load <1 x double>, ptr %53, align 8
  %54 = getelementptr double, ptr %47, i64 455
  %unmaskedload2 = load <1 x double>, ptr %54, align 8
  %55 = getelementptr double, ptr %7, i64 %46
  %56 = load double, ptr %55, align 8
  %57 = shufflevector <1 x double> %unmaskedload.i.1, <1 x double> %unmaskedload32.i.1, <2 x i32> <i32 0, i32 1>
  %58 = insertelement <2 x double> poison, double %56, i64 0
  %59 = shufflevector <2 x double> %58, <2 x double> poison, <2 x i32> zeroinitializer
  %60 = fmul <2 x double> %57, %59
  %61 = shufflevector <1 x double> %unmaskedload33.i.1, <1 x double> %unmaskedload34.i.1, <2 x i32> <i32 0, i32 1>
  %62 = fmul <2 x double> %61, %59
  %63 = shufflevector <2 x double> %60, <2 x double> %62, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %64 = shufflevector <1 x double> %unmaskedload35.i.1, <1 x double> %unmaskedload36.i.1, <2 x i32> <i32 0, i32 1>
  %65 = fmul <2 x double> %64, %59
  %66 = shufflevector <2 x double> %65, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %67 = shufflevector <8 x double> %63, <8 x double> %66, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %68 = shufflevector <1 x double> %unmaskedload37.i.1, <1 x double> %unmaskedload2, <2 x i32> <i32 0, i32 1>
  %69 = fmul <2 x double> %68, %59
  %70 = shufflevector <2 x double> %69, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %71 = shufflevector <8 x double> %67, <8 x double> %70, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %72 = fadd <8 x double> %45, %71
  store <8 x double> %72, ptr %43, align 8
  %73 = add nuw nsw i64 %46, 1
  %exitcond.not.i.1 = icmp eq i64 %73, 65
  br i1 %exitcond.not.i.1, label %74, label %44

74:                                               ; preds = %44
  %75 = getelementptr double, ptr %4, i64 1040
  %76 = getelementptr double, ptr %10, i64 16
  %.promoted7 = load <8 x double>, ptr %76, align 8
  br label %77

77:                                               ; preds = %77, %74
  %78 = phi <8 x double> [ %.promoted7, %74 ], [ %105, %77 ]
  %79 = phi i64 [ 0, %74 ], [ %106, %77 ]
  %80 = getelementptr double, ptr %75, i64 %79
  %unmaskedload.i.2 = load <1 x double>, ptr %80, align 8
  %81 = getelementptr double, ptr %80, i64 65
  %unmaskedload32.i.2 = load <1 x double>, ptr %81, align 8
  %82 = getelementptr double, ptr %80, i64 130
  %unmaskedload33.i.2 = load <1 x double>, ptr %82, align 8
  %83 = getelementptr double, ptr %80, i64 195
  %unmaskedload34.i.2 = load <1 x double>, ptr %83, align 8
  %84 = getelementptr double, ptr %80, i64 260
  %unmaskedload35.i.2 = load <1 x double>, ptr %84, align 8
  %85 = getelementptr double, ptr %80, i64 325
  %unmaskedload36.i.2 = load <1 x double>, ptr %85, align 8
  %86 = getelementptr double, ptr %80, i64 390
  %unmaskedload37.i.2 = load <1 x double>, ptr %86, align 8
  %87 = getelementptr double, ptr %80, i64 455
  %unmaskedload4 = load <1 x double>, ptr %87, align 8
  %88 = getelementptr double, ptr %7, i64 %79
  %89 = load double, ptr %88, align 8
  %90 = shufflevector <1 x double> %unmaskedload.i.2, <1 x double> %unmaskedload32.i.2, <2 x i32> <i32 0, i32 1>
  %91 = insertelement <2 x double> poison, double %89, i64 0
  %92 = shufflevector <2 x double> %91, <2 x double> poison, <2 x i32> zeroinitializer
  %93 = fmul <2 x double> %90, %92
  %94 = shufflevector <1 x double> %unmaskedload33.i.2, <1 x double> %unmaskedload34.i.2, <2 x i32> <i32 0, i32 1>
  %95 = fmul <2 x double> %94, %92
  %96 = shufflevector <2 x double> %93, <2 x double> %95, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %97 = shufflevector <1 x double> %unmaskedload35.i.2, <1 x double> %unmaskedload36.i.2, <2 x i32> <i32 0, i32 1>
  %98 = fmul <2 x double> %97, %92
  %99 = shufflevector <2 x double> %98, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %100 = shufflevector <8 x double> %96, <8 x double> %99, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %101 = shufflevector <1 x double> %unmaskedload37.i.2, <1 x double> %unmaskedload4, <2 x i32> <i32 0, i32 1>
  %102 = fmul <2 x double> %101, %92
  %103 = shufflevector <2 x double> %102, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %104 = shufflevector <8 x double> %100, <8 x double> %103, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 8, i32 9>
  %105 = fadd <8 x double> %78, %104
  store <8 x double> %105, ptr %76, align 8
  %106 = add nuw nsw i64 %79, 1
  %exitcond.not.i.2 = icmp eq i64 %106, 65
  br i1 %exitcond.not.i.2, label %107, label %77

107:                                              ; preds = %77
  %108 = getelementptr double, ptr %4, i64 1560
  %109 = getelementptr double, ptr %10, i64 24
  br label %110

110:                                              ; preds = %110, %107
  %111 = phi i64 [ 0, %107 ], [ %137, %110 ]
  %112 = getelementptr double, ptr %108, i64 %111
  %unmaskedload.i.3 = load <1 x double>, ptr %112, align 8
  %113 = getelementptr double, ptr %112, i64 65
  %unmaskedload32.i.3 = load <1 x double>, ptr %113, align 8
  %114 = getelementptr double, ptr %112, i64 130
  %unmaskedload33.i.3 = load <1 x double>, ptr %114, align 8
  %115 = getelementptr double, ptr %112, i64 195
  %unmaskedload34.i.3 = load <1 x double>, ptr %115, align 8
  %116 = getelementptr double, ptr %112, i64 260
  %unmaskedload35.i.3 = load <1 x double>, ptr %116, align 8
  %117 = getelementptr double, ptr %112, i64 325
  %unmaskedload36.i.3 = load <1 x double>, ptr %117, align 8
  %118 = getelementptr double, ptr %112, i64 390
  %unmaskedload37.i.3 = load <1 x double>, ptr %118, align 8
  %119 = getelementptr double, ptr %7, i64 %111
  %120 = load double, ptr %119, align 8
  %121 = tail call <8 x double> @llvm.masked.load.v8f64.p0(ptr %109, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>, <8 x double> poison)
  %122 = shufflevector <1 x double> %unmaskedload.i.3, <1 x double> %unmaskedload32.i.3, <2 x i32> <i32 0, i32 1>
  %123 = insertelement <2 x double> poison, double %120, i64 0
  %124 = shufflevector <2 x double> %123, <2 x double> poison, <2 x i32> zeroinitializer
  %125 = fmul <2 x double> %122, %124
  %126 = shufflevector <1 x double> %unmaskedload33.i.3, <1 x double> %unmaskedload34.i.3, <2 x i32> <i32 0, i32 1>
  %127 = fmul <2 x double> %126, %124
  %128 = shufflevector <2 x double> %125, <2 x double> %127, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %129 = shufflevector <1 x double> %unmaskedload35.i.3, <1 x double> %unmaskedload36.i.3, <2 x i32> <i32 0, i32 1>
  %130 = fmul <2 x double> %129, %124
  %131 = shufflevector <2 x double> %130, <2 x double> poison, <8 x i32> <i32 0, i32 1, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %132 = shufflevector <8 x double> %128, <8 x double> %131, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 8, i32 9, i32 poison, i32 poison>
  %133 = extractelement <1 x double> %unmaskedload37.i.3, i64 0
  %134 = fmul double %133, %120
  %135 = insertelement <8 x double> %132, double %134, i64 6
  %136 = fadd <8 x double> %121, %135
  tail call void @llvm.masked.store.v8f64.p0(<8 x double> %136, ptr %109, i32 8, <8 x i1> <i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 false>)
  %137 = add nuw nsw i64 %111, 1
  %exitcond.not.i.3 = icmp eq i64 %137, 65
  br i1 %exitcond.not.i.3, label %kernel.exit, label %110

kernel.exit:                                      ; preds = %110
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #4

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #3 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
