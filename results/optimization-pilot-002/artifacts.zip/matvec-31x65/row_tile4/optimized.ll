; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader3.preheader
  %18 = phi i64 [ 0, %.preheader3.preheader ], [ %54, %17 ]
  %19 = phi double [ 0.000000e+00, %.preheader3.preheader ], [ %53, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %8, i64 %18
  %23 = load double, ptr %22, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %13, align 8
  %26 = add nuw nsw i64 %18, 1
  %27 = getelementptr double, ptr %1, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %13, align 8
  %33 = add nuw nsw i64 %18, 2
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %33
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %13, align 8
  %40 = add nuw nsw i64 %18, 3
  %41 = getelementptr double, ptr %1, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %8, i64 %40
  %44 = load double, ptr %43, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %13, align 8
  %47 = add nuw nsw i64 %18, 4
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %8, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %46, %52
  store double %53, ptr %13, align 8
  %54 = add nuw nsw i64 %18, 5
  %exitcond.not.4 = icmp eq i64 %54, 65
  br i1 %exitcond.not.4, label %.preheader.16, label %17

.preheader.16:                                    ; preds = %17
  %55 = getelementptr double, ptr %1, i64 65
  %56 = getelementptr double, ptr %13, i64 1
  br label %57

57:                                               ; preds = %57, %.preheader.16
  %58 = phi i64 [ 0, %.preheader.16 ], [ %94, %57 ]
  %59 = phi double [ 0.000000e+00, %.preheader.16 ], [ %93, %57 ]
  %60 = getelementptr double, ptr %55, i64 %58
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %8, i64 %58
  %63 = load double, ptr %62, align 8
  %64 = fmul double %61, %63
  %65 = fadd double %59, %64
  store double %65, ptr %56, align 8
  %66 = add nuw nsw i64 %58, 1
  %67 = getelementptr double, ptr %55, i64 %66
  %68 = load double, ptr %67, align 8
  %69 = getelementptr double, ptr %8, i64 %66
  %70 = load double, ptr %69, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %65, %71
  store double %72, ptr %56, align 8
  %73 = add nuw nsw i64 %58, 2
  %74 = getelementptr double, ptr %55, i64 %73
  %75 = load double, ptr %74, align 8
  %76 = getelementptr double, ptr %8, i64 %73
  %77 = load double, ptr %76, align 8
  %78 = fmul double %75, %77
  %79 = fadd double %72, %78
  store double %79, ptr %56, align 8
  %80 = add nuw nsw i64 %58, 3
  %81 = getelementptr double, ptr %55, i64 %80
  %82 = load double, ptr %81, align 8
  %83 = getelementptr double, ptr %8, i64 %80
  %84 = load double, ptr %83, align 8
  %85 = fmul double %82, %84
  %86 = fadd double %79, %85
  store double %86, ptr %56, align 8
  %87 = add nuw nsw i64 %58, 4
  %88 = getelementptr double, ptr %55, i64 %87
  %89 = load double, ptr %88, align 8
  %90 = getelementptr double, ptr %8, i64 %87
  %91 = load double, ptr %90, align 8
  %92 = fmul double %89, %91
  %93 = fadd double %86, %92
  store double %93, ptr %56, align 8
  %94 = add nuw nsw i64 %58, 5
  %exitcond.17.not.4 = icmp eq i64 %94, 65
  br i1 %exitcond.17.not.4, label %.preheader.29, label %57

.preheader.29:                                    ; preds = %57
  %95 = getelementptr double, ptr %1, i64 130
  %96 = getelementptr double, ptr %13, i64 2
  br label %97

97:                                               ; preds = %97, %.preheader.29
  %98 = phi i64 [ 0, %.preheader.29 ], [ %134, %97 ]
  %99 = phi double [ 0.000000e+00, %.preheader.29 ], [ %133, %97 ]
  %100 = getelementptr double, ptr %95, i64 %98
  %101 = load double, ptr %100, align 8
  %102 = getelementptr double, ptr %8, i64 %98
  %103 = load double, ptr %102, align 8
  %104 = fmul double %101, %103
  %105 = fadd double %99, %104
  store double %105, ptr %96, align 8
  %106 = add nuw nsw i64 %98, 1
  %107 = getelementptr double, ptr %95, i64 %106
  %108 = load double, ptr %107, align 8
  %109 = getelementptr double, ptr %8, i64 %106
  %110 = load double, ptr %109, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %105, %111
  store double %112, ptr %96, align 8
  %113 = add nuw nsw i64 %98, 2
  %114 = getelementptr double, ptr %95, i64 %113
  %115 = load double, ptr %114, align 8
  %116 = getelementptr double, ptr %8, i64 %113
  %117 = load double, ptr %116, align 8
  %118 = fmul double %115, %117
  %119 = fadd double %112, %118
  store double %119, ptr %96, align 8
  %120 = add nuw nsw i64 %98, 3
  %121 = getelementptr double, ptr %95, i64 %120
  %122 = load double, ptr %121, align 8
  %123 = getelementptr double, ptr %8, i64 %120
  %124 = load double, ptr %123, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %119, %125
  store double %126, ptr %96, align 8
  %127 = add nuw nsw i64 %98, 4
  %128 = getelementptr double, ptr %95, i64 %127
  %129 = load double, ptr %128, align 8
  %130 = getelementptr double, ptr %8, i64 %127
  %131 = load double, ptr %130, align 8
  %132 = fmul double %129, %131
  %133 = fadd double %126, %132
  store double %133, ptr %96, align 8
  %134 = add nuw nsw i64 %98, 5
  %exitcond.210.not.4 = icmp eq i64 %134, 65
  br i1 %exitcond.210.not.4, label %.preheader.312, label %97

.preheader.312:                                   ; preds = %97
  %135 = getelementptr double, ptr %1, i64 195
  %136 = getelementptr double, ptr %13, i64 3
  br label %137

137:                                              ; preds = %137, %.preheader.312
  %138 = phi i64 [ 0, %.preheader.312 ], [ %174, %137 ]
  %139 = phi double [ 0.000000e+00, %.preheader.312 ], [ %173, %137 ]
  %140 = getelementptr double, ptr %135, i64 %138
  %141 = load double, ptr %140, align 8
  %142 = getelementptr double, ptr %8, i64 %138
  %143 = load double, ptr %142, align 8
  %144 = fmul double %141, %143
  %145 = fadd double %139, %144
  store double %145, ptr %136, align 8
  %146 = add nuw nsw i64 %138, 1
  %147 = getelementptr double, ptr %135, i64 %146
  %148 = load double, ptr %147, align 8
  %149 = getelementptr double, ptr %8, i64 %146
  %150 = load double, ptr %149, align 8
  %151 = fmul double %148, %150
  %152 = fadd double %145, %151
  store double %152, ptr %136, align 8
  %153 = add nuw nsw i64 %138, 2
  %154 = getelementptr double, ptr %135, i64 %153
  %155 = load double, ptr %154, align 8
  %156 = getelementptr double, ptr %8, i64 %153
  %157 = load double, ptr %156, align 8
  %158 = fmul double %155, %157
  %159 = fadd double %152, %158
  store double %159, ptr %136, align 8
  %160 = add nuw nsw i64 %138, 3
  %161 = getelementptr double, ptr %135, i64 %160
  %162 = load double, ptr %161, align 8
  %163 = getelementptr double, ptr %8, i64 %160
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %159, %165
  store double %166, ptr %136, align 8
  %167 = add nuw nsw i64 %138, 4
  %168 = getelementptr double, ptr %135, i64 %167
  %169 = load double, ptr %168, align 8
  %170 = getelementptr double, ptr %8, i64 %167
  %171 = load double, ptr %170, align 8
  %172 = fmul double %169, %171
  %173 = fadd double %166, %172
  store double %173, ptr %136, align 8
  %174 = add nuw nsw i64 %138, 5
  %exitcond.313.not.4 = icmp eq i64 %174, 65
  br i1 %exitcond.313.not.4, label %.preheader3.1, label %137

.preheader3.1:                                    ; preds = %137
  %175 = getelementptr double, ptr %1, i64 260
  %176 = getelementptr double, ptr %13, i64 4
  br label %177

177:                                              ; preds = %177, %.preheader3.1
  %178 = phi i64 [ 0, %.preheader3.1 ], [ %214, %177 ]
  %179 = phi double [ 0.000000e+00, %.preheader3.1 ], [ %213, %177 ]
  %180 = getelementptr double, ptr %175, i64 %178
  %181 = load double, ptr %180, align 8
  %182 = getelementptr double, ptr %8, i64 %178
  %183 = load double, ptr %182, align 8
  %184 = fmul double %181, %183
  %185 = fadd double %179, %184
  store double %185, ptr %176, align 8
  %186 = add nuw nsw i64 %178, 1
  %187 = getelementptr double, ptr %175, i64 %186
  %188 = load double, ptr %187, align 8
  %189 = getelementptr double, ptr %8, i64 %186
  %190 = load double, ptr %189, align 8
  %191 = fmul double %188, %190
  %192 = fadd double %185, %191
  store double %192, ptr %176, align 8
  %193 = add nuw nsw i64 %178, 2
  %194 = getelementptr double, ptr %175, i64 %193
  %195 = load double, ptr %194, align 8
  %196 = getelementptr double, ptr %8, i64 %193
  %197 = load double, ptr %196, align 8
  %198 = fmul double %195, %197
  %199 = fadd double %192, %198
  store double %199, ptr %176, align 8
  %200 = add nuw nsw i64 %178, 3
  %201 = getelementptr double, ptr %175, i64 %200
  %202 = load double, ptr %201, align 8
  %203 = getelementptr double, ptr %8, i64 %200
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %199, %205
  store double %206, ptr %176, align 8
  %207 = add nuw nsw i64 %178, 4
  %208 = getelementptr double, ptr %175, i64 %207
  %209 = load double, ptr %208, align 8
  %210 = getelementptr double, ptr %8, i64 %207
  %211 = load double, ptr %210, align 8
  %212 = fmul double %209, %211
  %213 = fadd double %206, %212
  store double %213, ptr %176, align 8
  %214 = add nuw nsw i64 %178, 5
  %exitcond.1.not.4 = icmp eq i64 %214, 65
  br i1 %exitcond.1.not.4, label %.preheader.1.1, label %177

.preheader.1.1:                                   ; preds = %177
  %215 = getelementptr double, ptr %1, i64 325
  %216 = getelementptr double, ptr %13, i64 5
  br label %217

217:                                              ; preds = %217, %.preheader.1.1
  %218 = phi i64 [ 0, %.preheader.1.1 ], [ %254, %217 ]
  %219 = phi double [ 0.000000e+00, %.preheader.1.1 ], [ %253, %217 ]
  %220 = getelementptr double, ptr %215, i64 %218
  %221 = load double, ptr %220, align 8
  %222 = getelementptr double, ptr %8, i64 %218
  %223 = load double, ptr %222, align 8
  %224 = fmul double %221, %223
  %225 = fadd double %219, %224
  store double %225, ptr %216, align 8
  %226 = add nuw nsw i64 %218, 1
  %227 = getelementptr double, ptr %215, i64 %226
  %228 = load double, ptr %227, align 8
  %229 = getelementptr double, ptr %8, i64 %226
  %230 = load double, ptr %229, align 8
  %231 = fmul double %228, %230
  %232 = fadd double %225, %231
  store double %232, ptr %216, align 8
  %233 = add nuw nsw i64 %218, 2
  %234 = getelementptr double, ptr %215, i64 %233
  %235 = load double, ptr %234, align 8
  %236 = getelementptr double, ptr %8, i64 %233
  %237 = load double, ptr %236, align 8
  %238 = fmul double %235, %237
  %239 = fadd double %232, %238
  store double %239, ptr %216, align 8
  %240 = add nuw nsw i64 %218, 3
  %241 = getelementptr double, ptr %215, i64 %240
  %242 = load double, ptr %241, align 8
  %243 = getelementptr double, ptr %8, i64 %240
  %244 = load double, ptr %243, align 8
  %245 = fmul double %242, %244
  %246 = fadd double %239, %245
  store double %246, ptr %216, align 8
  %247 = add nuw nsw i64 %218, 4
  %248 = getelementptr double, ptr %215, i64 %247
  %249 = load double, ptr %248, align 8
  %250 = getelementptr double, ptr %8, i64 %247
  %251 = load double, ptr %250, align 8
  %252 = fmul double %249, %251
  %253 = fadd double %246, %252
  store double %253, ptr %216, align 8
  %254 = add nuw nsw i64 %218, 5
  %exitcond.1.1.not.4 = icmp eq i64 %254, 65
  br i1 %exitcond.1.1.not.4, label %.preheader.1.2, label %217

.preheader.1.2:                                   ; preds = %217
  %255 = getelementptr double, ptr %1, i64 390
  %256 = getelementptr double, ptr %13, i64 6
  br label %257

257:                                              ; preds = %257, %.preheader.1.2
  %258 = phi i64 [ 0, %.preheader.1.2 ], [ %294, %257 ]
  %259 = phi double [ 0.000000e+00, %.preheader.1.2 ], [ %293, %257 ]
  %260 = getelementptr double, ptr %255, i64 %258
  %261 = load double, ptr %260, align 8
  %262 = getelementptr double, ptr %8, i64 %258
  %263 = load double, ptr %262, align 8
  %264 = fmul double %261, %263
  %265 = fadd double %259, %264
  store double %265, ptr %256, align 8
  %266 = add nuw nsw i64 %258, 1
  %267 = getelementptr double, ptr %255, i64 %266
  %268 = load double, ptr %267, align 8
  %269 = getelementptr double, ptr %8, i64 %266
  %270 = load double, ptr %269, align 8
  %271 = fmul double %268, %270
  %272 = fadd double %265, %271
  store double %272, ptr %256, align 8
  %273 = add nuw nsw i64 %258, 2
  %274 = getelementptr double, ptr %255, i64 %273
  %275 = load double, ptr %274, align 8
  %276 = getelementptr double, ptr %8, i64 %273
  %277 = load double, ptr %276, align 8
  %278 = fmul double %275, %277
  %279 = fadd double %272, %278
  store double %279, ptr %256, align 8
  %280 = add nuw nsw i64 %258, 3
  %281 = getelementptr double, ptr %255, i64 %280
  %282 = load double, ptr %281, align 8
  %283 = getelementptr double, ptr %8, i64 %280
  %284 = load double, ptr %283, align 8
  %285 = fmul double %282, %284
  %286 = fadd double %279, %285
  store double %286, ptr %256, align 8
  %287 = add nuw nsw i64 %258, 4
  %288 = getelementptr double, ptr %255, i64 %287
  %289 = load double, ptr %288, align 8
  %290 = getelementptr double, ptr %8, i64 %287
  %291 = load double, ptr %290, align 8
  %292 = fmul double %289, %291
  %293 = fadd double %286, %292
  store double %293, ptr %256, align 8
  %294 = add nuw nsw i64 %258, 5
  %exitcond.1.2.not.4 = icmp eq i64 %294, 65
  br i1 %exitcond.1.2.not.4, label %.preheader.1.3, label %257

.preheader.1.3:                                   ; preds = %257
  %295 = getelementptr double, ptr %1, i64 455
  %296 = getelementptr double, ptr %13, i64 7
  br label %297

297:                                              ; preds = %297, %.preheader.1.3
  %298 = phi i64 [ 0, %.preheader.1.3 ], [ %334, %297 ]
  %299 = phi double [ 0.000000e+00, %.preheader.1.3 ], [ %333, %297 ]
  %300 = getelementptr double, ptr %295, i64 %298
  %301 = load double, ptr %300, align 8
  %302 = getelementptr double, ptr %8, i64 %298
  %303 = load double, ptr %302, align 8
  %304 = fmul double %301, %303
  %305 = fadd double %299, %304
  store double %305, ptr %296, align 8
  %306 = add nuw nsw i64 %298, 1
  %307 = getelementptr double, ptr %295, i64 %306
  %308 = load double, ptr %307, align 8
  %309 = getelementptr double, ptr %8, i64 %306
  %310 = load double, ptr %309, align 8
  %311 = fmul double %308, %310
  %312 = fadd double %305, %311
  store double %312, ptr %296, align 8
  %313 = add nuw nsw i64 %298, 2
  %314 = getelementptr double, ptr %295, i64 %313
  %315 = load double, ptr %314, align 8
  %316 = getelementptr double, ptr %8, i64 %313
  %317 = load double, ptr %316, align 8
  %318 = fmul double %315, %317
  %319 = fadd double %312, %318
  store double %319, ptr %296, align 8
  %320 = add nuw nsw i64 %298, 3
  %321 = getelementptr double, ptr %295, i64 %320
  %322 = load double, ptr %321, align 8
  %323 = getelementptr double, ptr %8, i64 %320
  %324 = load double, ptr %323, align 8
  %325 = fmul double %322, %324
  %326 = fadd double %319, %325
  store double %326, ptr %296, align 8
  %327 = add nuw nsw i64 %298, 4
  %328 = getelementptr double, ptr %295, i64 %327
  %329 = load double, ptr %328, align 8
  %330 = getelementptr double, ptr %8, i64 %327
  %331 = load double, ptr %330, align 8
  %332 = fmul double %329, %331
  %333 = fadd double %326, %332
  store double %333, ptr %296, align 8
  %334 = add nuw nsw i64 %298, 5
  %exitcond.1.3.not.4 = icmp eq i64 %334, 65
  br i1 %exitcond.1.3.not.4, label %.preheader3.2, label %297

.preheader3.2:                                    ; preds = %297
  %335 = getelementptr double, ptr %1, i64 520
  %336 = getelementptr double, ptr %13, i64 8
  br label %337

337:                                              ; preds = %337, %.preheader3.2
  %338 = phi i64 [ 0, %.preheader3.2 ], [ %374, %337 ]
  %339 = phi double [ 0.000000e+00, %.preheader3.2 ], [ %373, %337 ]
  %340 = getelementptr double, ptr %335, i64 %338
  %341 = load double, ptr %340, align 8
  %342 = getelementptr double, ptr %8, i64 %338
  %343 = load double, ptr %342, align 8
  %344 = fmul double %341, %343
  %345 = fadd double %339, %344
  store double %345, ptr %336, align 8
  %346 = add nuw nsw i64 %338, 1
  %347 = getelementptr double, ptr %335, i64 %346
  %348 = load double, ptr %347, align 8
  %349 = getelementptr double, ptr %8, i64 %346
  %350 = load double, ptr %349, align 8
  %351 = fmul double %348, %350
  %352 = fadd double %345, %351
  store double %352, ptr %336, align 8
  %353 = add nuw nsw i64 %338, 2
  %354 = getelementptr double, ptr %335, i64 %353
  %355 = load double, ptr %354, align 8
  %356 = getelementptr double, ptr %8, i64 %353
  %357 = load double, ptr %356, align 8
  %358 = fmul double %355, %357
  %359 = fadd double %352, %358
  store double %359, ptr %336, align 8
  %360 = add nuw nsw i64 %338, 3
  %361 = getelementptr double, ptr %335, i64 %360
  %362 = load double, ptr %361, align 8
  %363 = getelementptr double, ptr %8, i64 %360
  %364 = load double, ptr %363, align 8
  %365 = fmul double %362, %364
  %366 = fadd double %359, %365
  store double %366, ptr %336, align 8
  %367 = add nuw nsw i64 %338, 4
  %368 = getelementptr double, ptr %335, i64 %367
  %369 = load double, ptr %368, align 8
  %370 = getelementptr double, ptr %8, i64 %367
  %371 = load double, ptr %370, align 8
  %372 = fmul double %369, %371
  %373 = fadd double %366, %372
  store double %373, ptr %336, align 8
  %374 = add nuw nsw i64 %338, 5
  %exitcond.2.not.4 = icmp eq i64 %374, 65
  br i1 %exitcond.2.not.4, label %.preheader.2.1, label %337

.preheader.2.1:                                   ; preds = %337
  %375 = getelementptr double, ptr %1, i64 585
  %376 = getelementptr double, ptr %13, i64 9
  br label %377

377:                                              ; preds = %377, %.preheader.2.1
  %378 = phi i64 [ 0, %.preheader.2.1 ], [ %414, %377 ]
  %379 = phi double [ 0.000000e+00, %.preheader.2.1 ], [ %413, %377 ]
  %380 = getelementptr double, ptr %375, i64 %378
  %381 = load double, ptr %380, align 8
  %382 = getelementptr double, ptr %8, i64 %378
  %383 = load double, ptr %382, align 8
  %384 = fmul double %381, %383
  %385 = fadd double %379, %384
  store double %385, ptr %376, align 8
  %386 = add nuw nsw i64 %378, 1
  %387 = getelementptr double, ptr %375, i64 %386
  %388 = load double, ptr %387, align 8
  %389 = getelementptr double, ptr %8, i64 %386
  %390 = load double, ptr %389, align 8
  %391 = fmul double %388, %390
  %392 = fadd double %385, %391
  store double %392, ptr %376, align 8
  %393 = add nuw nsw i64 %378, 2
  %394 = getelementptr double, ptr %375, i64 %393
  %395 = load double, ptr %394, align 8
  %396 = getelementptr double, ptr %8, i64 %393
  %397 = load double, ptr %396, align 8
  %398 = fmul double %395, %397
  %399 = fadd double %392, %398
  store double %399, ptr %376, align 8
  %400 = add nuw nsw i64 %378, 3
  %401 = getelementptr double, ptr %375, i64 %400
  %402 = load double, ptr %401, align 8
  %403 = getelementptr double, ptr %8, i64 %400
  %404 = load double, ptr %403, align 8
  %405 = fmul double %402, %404
  %406 = fadd double %399, %405
  store double %406, ptr %376, align 8
  %407 = add nuw nsw i64 %378, 4
  %408 = getelementptr double, ptr %375, i64 %407
  %409 = load double, ptr %408, align 8
  %410 = getelementptr double, ptr %8, i64 %407
  %411 = load double, ptr %410, align 8
  %412 = fmul double %409, %411
  %413 = fadd double %406, %412
  store double %413, ptr %376, align 8
  %414 = add nuw nsw i64 %378, 5
  %exitcond.2.1.not.4 = icmp eq i64 %414, 65
  br i1 %exitcond.2.1.not.4, label %.preheader.2.2, label %377

.preheader.2.2:                                   ; preds = %377
  %415 = getelementptr double, ptr %1, i64 650
  %416 = getelementptr double, ptr %13, i64 10
  br label %417

417:                                              ; preds = %417, %.preheader.2.2
  %418 = phi i64 [ 0, %.preheader.2.2 ], [ %454, %417 ]
  %419 = phi double [ 0.000000e+00, %.preheader.2.2 ], [ %453, %417 ]
  %420 = getelementptr double, ptr %415, i64 %418
  %421 = load double, ptr %420, align 8
  %422 = getelementptr double, ptr %8, i64 %418
  %423 = load double, ptr %422, align 8
  %424 = fmul double %421, %423
  %425 = fadd double %419, %424
  store double %425, ptr %416, align 8
  %426 = add nuw nsw i64 %418, 1
  %427 = getelementptr double, ptr %415, i64 %426
  %428 = load double, ptr %427, align 8
  %429 = getelementptr double, ptr %8, i64 %426
  %430 = load double, ptr %429, align 8
  %431 = fmul double %428, %430
  %432 = fadd double %425, %431
  store double %432, ptr %416, align 8
  %433 = add nuw nsw i64 %418, 2
  %434 = getelementptr double, ptr %415, i64 %433
  %435 = load double, ptr %434, align 8
  %436 = getelementptr double, ptr %8, i64 %433
  %437 = load double, ptr %436, align 8
  %438 = fmul double %435, %437
  %439 = fadd double %432, %438
  store double %439, ptr %416, align 8
  %440 = add nuw nsw i64 %418, 3
  %441 = getelementptr double, ptr %415, i64 %440
  %442 = load double, ptr %441, align 8
  %443 = getelementptr double, ptr %8, i64 %440
  %444 = load double, ptr %443, align 8
  %445 = fmul double %442, %444
  %446 = fadd double %439, %445
  store double %446, ptr %416, align 8
  %447 = add nuw nsw i64 %418, 4
  %448 = getelementptr double, ptr %415, i64 %447
  %449 = load double, ptr %448, align 8
  %450 = getelementptr double, ptr %8, i64 %447
  %451 = load double, ptr %450, align 8
  %452 = fmul double %449, %451
  %453 = fadd double %446, %452
  store double %453, ptr %416, align 8
  %454 = add nuw nsw i64 %418, 5
  %exitcond.2.2.not.4 = icmp eq i64 %454, 65
  br i1 %exitcond.2.2.not.4, label %.preheader.2.3, label %417

.preheader.2.3:                                   ; preds = %417
  %455 = getelementptr double, ptr %1, i64 715
  %456 = getelementptr double, ptr %13, i64 11
  br label %457

457:                                              ; preds = %457, %.preheader.2.3
  %458 = phi i64 [ 0, %.preheader.2.3 ], [ %494, %457 ]
  %459 = phi double [ 0.000000e+00, %.preheader.2.3 ], [ %493, %457 ]
  %460 = getelementptr double, ptr %455, i64 %458
  %461 = load double, ptr %460, align 8
  %462 = getelementptr double, ptr %8, i64 %458
  %463 = load double, ptr %462, align 8
  %464 = fmul double %461, %463
  %465 = fadd double %459, %464
  store double %465, ptr %456, align 8
  %466 = add nuw nsw i64 %458, 1
  %467 = getelementptr double, ptr %455, i64 %466
  %468 = load double, ptr %467, align 8
  %469 = getelementptr double, ptr %8, i64 %466
  %470 = load double, ptr %469, align 8
  %471 = fmul double %468, %470
  %472 = fadd double %465, %471
  store double %472, ptr %456, align 8
  %473 = add nuw nsw i64 %458, 2
  %474 = getelementptr double, ptr %455, i64 %473
  %475 = load double, ptr %474, align 8
  %476 = getelementptr double, ptr %8, i64 %473
  %477 = load double, ptr %476, align 8
  %478 = fmul double %475, %477
  %479 = fadd double %472, %478
  store double %479, ptr %456, align 8
  %480 = add nuw nsw i64 %458, 3
  %481 = getelementptr double, ptr %455, i64 %480
  %482 = load double, ptr %481, align 8
  %483 = getelementptr double, ptr %8, i64 %480
  %484 = load double, ptr %483, align 8
  %485 = fmul double %482, %484
  %486 = fadd double %479, %485
  store double %486, ptr %456, align 8
  %487 = add nuw nsw i64 %458, 4
  %488 = getelementptr double, ptr %455, i64 %487
  %489 = load double, ptr %488, align 8
  %490 = getelementptr double, ptr %8, i64 %487
  %491 = load double, ptr %490, align 8
  %492 = fmul double %489, %491
  %493 = fadd double %486, %492
  store double %493, ptr %456, align 8
  %494 = add nuw nsw i64 %458, 5
  %exitcond.2.3.not.4 = icmp eq i64 %494, 65
  br i1 %exitcond.2.3.not.4, label %.preheader3.3, label %457

.preheader3.3:                                    ; preds = %457
  %495 = getelementptr double, ptr %1, i64 780
  %496 = getelementptr double, ptr %13, i64 12
  br label %497

497:                                              ; preds = %497, %.preheader3.3
  %498 = phi i64 [ 0, %.preheader3.3 ], [ %534, %497 ]
  %499 = phi double [ 0.000000e+00, %.preheader3.3 ], [ %533, %497 ]
  %500 = getelementptr double, ptr %495, i64 %498
  %501 = load double, ptr %500, align 8
  %502 = getelementptr double, ptr %8, i64 %498
  %503 = load double, ptr %502, align 8
  %504 = fmul double %501, %503
  %505 = fadd double %499, %504
  store double %505, ptr %496, align 8
  %506 = add nuw nsw i64 %498, 1
  %507 = getelementptr double, ptr %495, i64 %506
  %508 = load double, ptr %507, align 8
  %509 = getelementptr double, ptr %8, i64 %506
  %510 = load double, ptr %509, align 8
  %511 = fmul double %508, %510
  %512 = fadd double %505, %511
  store double %512, ptr %496, align 8
  %513 = add nuw nsw i64 %498, 2
  %514 = getelementptr double, ptr %495, i64 %513
  %515 = load double, ptr %514, align 8
  %516 = getelementptr double, ptr %8, i64 %513
  %517 = load double, ptr %516, align 8
  %518 = fmul double %515, %517
  %519 = fadd double %512, %518
  store double %519, ptr %496, align 8
  %520 = add nuw nsw i64 %498, 3
  %521 = getelementptr double, ptr %495, i64 %520
  %522 = load double, ptr %521, align 8
  %523 = getelementptr double, ptr %8, i64 %520
  %524 = load double, ptr %523, align 8
  %525 = fmul double %522, %524
  %526 = fadd double %519, %525
  store double %526, ptr %496, align 8
  %527 = add nuw nsw i64 %498, 4
  %528 = getelementptr double, ptr %495, i64 %527
  %529 = load double, ptr %528, align 8
  %530 = getelementptr double, ptr %8, i64 %527
  %531 = load double, ptr %530, align 8
  %532 = fmul double %529, %531
  %533 = fadd double %526, %532
  store double %533, ptr %496, align 8
  %534 = add nuw nsw i64 %498, 5
  %exitcond.3.not.4 = icmp eq i64 %534, 65
  br i1 %exitcond.3.not.4, label %.preheader.3.1, label %497

.preheader.3.1:                                   ; preds = %497
  %535 = getelementptr double, ptr %1, i64 845
  %536 = getelementptr double, ptr %13, i64 13
  br label %537

537:                                              ; preds = %537, %.preheader.3.1
  %538 = phi i64 [ 0, %.preheader.3.1 ], [ %574, %537 ]
  %539 = phi double [ 0.000000e+00, %.preheader.3.1 ], [ %573, %537 ]
  %540 = getelementptr double, ptr %535, i64 %538
  %541 = load double, ptr %540, align 8
  %542 = getelementptr double, ptr %8, i64 %538
  %543 = load double, ptr %542, align 8
  %544 = fmul double %541, %543
  %545 = fadd double %539, %544
  store double %545, ptr %536, align 8
  %546 = add nuw nsw i64 %538, 1
  %547 = getelementptr double, ptr %535, i64 %546
  %548 = load double, ptr %547, align 8
  %549 = getelementptr double, ptr %8, i64 %546
  %550 = load double, ptr %549, align 8
  %551 = fmul double %548, %550
  %552 = fadd double %545, %551
  store double %552, ptr %536, align 8
  %553 = add nuw nsw i64 %538, 2
  %554 = getelementptr double, ptr %535, i64 %553
  %555 = load double, ptr %554, align 8
  %556 = getelementptr double, ptr %8, i64 %553
  %557 = load double, ptr %556, align 8
  %558 = fmul double %555, %557
  %559 = fadd double %552, %558
  store double %559, ptr %536, align 8
  %560 = add nuw nsw i64 %538, 3
  %561 = getelementptr double, ptr %535, i64 %560
  %562 = load double, ptr %561, align 8
  %563 = getelementptr double, ptr %8, i64 %560
  %564 = load double, ptr %563, align 8
  %565 = fmul double %562, %564
  %566 = fadd double %559, %565
  store double %566, ptr %536, align 8
  %567 = add nuw nsw i64 %538, 4
  %568 = getelementptr double, ptr %535, i64 %567
  %569 = load double, ptr %568, align 8
  %570 = getelementptr double, ptr %8, i64 %567
  %571 = load double, ptr %570, align 8
  %572 = fmul double %569, %571
  %573 = fadd double %566, %572
  store double %573, ptr %536, align 8
  %574 = add nuw nsw i64 %538, 5
  %exitcond.3.1.not.4 = icmp eq i64 %574, 65
  br i1 %exitcond.3.1.not.4, label %.preheader.3.2, label %537

.preheader.3.2:                                   ; preds = %537
  %575 = getelementptr double, ptr %1, i64 910
  %576 = getelementptr double, ptr %13, i64 14
  br label %577

577:                                              ; preds = %577, %.preheader.3.2
  %578 = phi i64 [ 0, %.preheader.3.2 ], [ %614, %577 ]
  %579 = phi double [ 0.000000e+00, %.preheader.3.2 ], [ %613, %577 ]
  %580 = getelementptr double, ptr %575, i64 %578
  %581 = load double, ptr %580, align 8
  %582 = getelementptr double, ptr %8, i64 %578
  %583 = load double, ptr %582, align 8
  %584 = fmul double %581, %583
  %585 = fadd double %579, %584
  store double %585, ptr %576, align 8
  %586 = add nuw nsw i64 %578, 1
  %587 = getelementptr double, ptr %575, i64 %586
  %588 = load double, ptr %587, align 8
  %589 = getelementptr double, ptr %8, i64 %586
  %590 = load double, ptr %589, align 8
  %591 = fmul double %588, %590
  %592 = fadd double %585, %591
  store double %592, ptr %576, align 8
  %593 = add nuw nsw i64 %578, 2
  %594 = getelementptr double, ptr %575, i64 %593
  %595 = load double, ptr %594, align 8
  %596 = getelementptr double, ptr %8, i64 %593
  %597 = load double, ptr %596, align 8
  %598 = fmul double %595, %597
  %599 = fadd double %592, %598
  store double %599, ptr %576, align 8
  %600 = add nuw nsw i64 %578, 3
  %601 = getelementptr double, ptr %575, i64 %600
  %602 = load double, ptr %601, align 8
  %603 = getelementptr double, ptr %8, i64 %600
  %604 = load double, ptr %603, align 8
  %605 = fmul double %602, %604
  %606 = fadd double %599, %605
  store double %606, ptr %576, align 8
  %607 = add nuw nsw i64 %578, 4
  %608 = getelementptr double, ptr %575, i64 %607
  %609 = load double, ptr %608, align 8
  %610 = getelementptr double, ptr %8, i64 %607
  %611 = load double, ptr %610, align 8
  %612 = fmul double %609, %611
  %613 = fadd double %606, %612
  store double %613, ptr %576, align 8
  %614 = add nuw nsw i64 %578, 5
  %exitcond.3.2.not.4 = icmp eq i64 %614, 65
  br i1 %exitcond.3.2.not.4, label %.preheader.3.3, label %577

.preheader.3.3:                                   ; preds = %577
  %615 = getelementptr double, ptr %1, i64 975
  %616 = getelementptr double, ptr %13, i64 15
  br label %617

617:                                              ; preds = %617, %.preheader.3.3
  %618 = phi i64 [ 0, %.preheader.3.3 ], [ %654, %617 ]
  %619 = phi double [ 0.000000e+00, %.preheader.3.3 ], [ %653, %617 ]
  %620 = getelementptr double, ptr %615, i64 %618
  %621 = load double, ptr %620, align 8
  %622 = getelementptr double, ptr %8, i64 %618
  %623 = load double, ptr %622, align 8
  %624 = fmul double %621, %623
  %625 = fadd double %619, %624
  store double %625, ptr %616, align 8
  %626 = add nuw nsw i64 %618, 1
  %627 = getelementptr double, ptr %615, i64 %626
  %628 = load double, ptr %627, align 8
  %629 = getelementptr double, ptr %8, i64 %626
  %630 = load double, ptr %629, align 8
  %631 = fmul double %628, %630
  %632 = fadd double %625, %631
  store double %632, ptr %616, align 8
  %633 = add nuw nsw i64 %618, 2
  %634 = getelementptr double, ptr %615, i64 %633
  %635 = load double, ptr %634, align 8
  %636 = getelementptr double, ptr %8, i64 %633
  %637 = load double, ptr %636, align 8
  %638 = fmul double %635, %637
  %639 = fadd double %632, %638
  store double %639, ptr %616, align 8
  %640 = add nuw nsw i64 %618, 3
  %641 = getelementptr double, ptr %615, i64 %640
  %642 = load double, ptr %641, align 8
  %643 = getelementptr double, ptr %8, i64 %640
  %644 = load double, ptr %643, align 8
  %645 = fmul double %642, %644
  %646 = fadd double %639, %645
  store double %646, ptr %616, align 8
  %647 = add nuw nsw i64 %618, 4
  %648 = getelementptr double, ptr %615, i64 %647
  %649 = load double, ptr %648, align 8
  %650 = getelementptr double, ptr %8, i64 %647
  %651 = load double, ptr %650, align 8
  %652 = fmul double %649, %651
  %653 = fadd double %646, %652
  store double %653, ptr %616, align 8
  %654 = add nuw nsw i64 %618, 5
  %exitcond.3.3.not.4 = icmp eq i64 %654, 65
  br i1 %exitcond.3.3.not.4, label %.preheader3.4, label %617

.preheader3.4:                                    ; preds = %617
  %655 = getelementptr double, ptr %1, i64 1040
  %656 = getelementptr double, ptr %13, i64 16
  br label %657

657:                                              ; preds = %657, %.preheader3.4
  %658 = phi i64 [ 0, %.preheader3.4 ], [ %694, %657 ]
  %659 = phi double [ 0.000000e+00, %.preheader3.4 ], [ %693, %657 ]
  %660 = getelementptr double, ptr %655, i64 %658
  %661 = load double, ptr %660, align 8
  %662 = getelementptr double, ptr %8, i64 %658
  %663 = load double, ptr %662, align 8
  %664 = fmul double %661, %663
  %665 = fadd double %659, %664
  store double %665, ptr %656, align 8
  %666 = add nuw nsw i64 %658, 1
  %667 = getelementptr double, ptr %655, i64 %666
  %668 = load double, ptr %667, align 8
  %669 = getelementptr double, ptr %8, i64 %666
  %670 = load double, ptr %669, align 8
  %671 = fmul double %668, %670
  %672 = fadd double %665, %671
  store double %672, ptr %656, align 8
  %673 = add nuw nsw i64 %658, 2
  %674 = getelementptr double, ptr %655, i64 %673
  %675 = load double, ptr %674, align 8
  %676 = getelementptr double, ptr %8, i64 %673
  %677 = load double, ptr %676, align 8
  %678 = fmul double %675, %677
  %679 = fadd double %672, %678
  store double %679, ptr %656, align 8
  %680 = add nuw nsw i64 %658, 3
  %681 = getelementptr double, ptr %655, i64 %680
  %682 = load double, ptr %681, align 8
  %683 = getelementptr double, ptr %8, i64 %680
  %684 = load double, ptr %683, align 8
  %685 = fmul double %682, %684
  %686 = fadd double %679, %685
  store double %686, ptr %656, align 8
  %687 = add nuw nsw i64 %658, 4
  %688 = getelementptr double, ptr %655, i64 %687
  %689 = load double, ptr %688, align 8
  %690 = getelementptr double, ptr %8, i64 %687
  %691 = load double, ptr %690, align 8
  %692 = fmul double %689, %691
  %693 = fadd double %686, %692
  store double %693, ptr %656, align 8
  %694 = add nuw nsw i64 %658, 5
  %exitcond.4.not.4 = icmp eq i64 %694, 65
  br i1 %exitcond.4.not.4, label %.preheader.4.1, label %657

.preheader.4.1:                                   ; preds = %657
  %695 = getelementptr double, ptr %1, i64 1105
  %696 = getelementptr double, ptr %13, i64 17
  br label %697

697:                                              ; preds = %697, %.preheader.4.1
  %698 = phi i64 [ 0, %.preheader.4.1 ], [ %734, %697 ]
  %699 = phi double [ 0.000000e+00, %.preheader.4.1 ], [ %733, %697 ]
  %700 = getelementptr double, ptr %695, i64 %698
  %701 = load double, ptr %700, align 8
  %702 = getelementptr double, ptr %8, i64 %698
  %703 = load double, ptr %702, align 8
  %704 = fmul double %701, %703
  %705 = fadd double %699, %704
  store double %705, ptr %696, align 8
  %706 = add nuw nsw i64 %698, 1
  %707 = getelementptr double, ptr %695, i64 %706
  %708 = load double, ptr %707, align 8
  %709 = getelementptr double, ptr %8, i64 %706
  %710 = load double, ptr %709, align 8
  %711 = fmul double %708, %710
  %712 = fadd double %705, %711
  store double %712, ptr %696, align 8
  %713 = add nuw nsw i64 %698, 2
  %714 = getelementptr double, ptr %695, i64 %713
  %715 = load double, ptr %714, align 8
  %716 = getelementptr double, ptr %8, i64 %713
  %717 = load double, ptr %716, align 8
  %718 = fmul double %715, %717
  %719 = fadd double %712, %718
  store double %719, ptr %696, align 8
  %720 = add nuw nsw i64 %698, 3
  %721 = getelementptr double, ptr %695, i64 %720
  %722 = load double, ptr %721, align 8
  %723 = getelementptr double, ptr %8, i64 %720
  %724 = load double, ptr %723, align 8
  %725 = fmul double %722, %724
  %726 = fadd double %719, %725
  store double %726, ptr %696, align 8
  %727 = add nuw nsw i64 %698, 4
  %728 = getelementptr double, ptr %695, i64 %727
  %729 = load double, ptr %728, align 8
  %730 = getelementptr double, ptr %8, i64 %727
  %731 = load double, ptr %730, align 8
  %732 = fmul double %729, %731
  %733 = fadd double %726, %732
  store double %733, ptr %696, align 8
  %734 = add nuw nsw i64 %698, 5
  %exitcond.4.1.not.4 = icmp eq i64 %734, 65
  br i1 %exitcond.4.1.not.4, label %.preheader.4.2, label %697

.preheader.4.2:                                   ; preds = %697
  %735 = getelementptr double, ptr %1, i64 1170
  %736 = getelementptr double, ptr %13, i64 18
  br label %737

737:                                              ; preds = %737, %.preheader.4.2
  %738 = phi i64 [ 0, %.preheader.4.2 ], [ %774, %737 ]
  %739 = phi double [ 0.000000e+00, %.preheader.4.2 ], [ %773, %737 ]
  %740 = getelementptr double, ptr %735, i64 %738
  %741 = load double, ptr %740, align 8
  %742 = getelementptr double, ptr %8, i64 %738
  %743 = load double, ptr %742, align 8
  %744 = fmul double %741, %743
  %745 = fadd double %739, %744
  store double %745, ptr %736, align 8
  %746 = add nuw nsw i64 %738, 1
  %747 = getelementptr double, ptr %735, i64 %746
  %748 = load double, ptr %747, align 8
  %749 = getelementptr double, ptr %8, i64 %746
  %750 = load double, ptr %749, align 8
  %751 = fmul double %748, %750
  %752 = fadd double %745, %751
  store double %752, ptr %736, align 8
  %753 = add nuw nsw i64 %738, 2
  %754 = getelementptr double, ptr %735, i64 %753
  %755 = load double, ptr %754, align 8
  %756 = getelementptr double, ptr %8, i64 %753
  %757 = load double, ptr %756, align 8
  %758 = fmul double %755, %757
  %759 = fadd double %752, %758
  store double %759, ptr %736, align 8
  %760 = add nuw nsw i64 %738, 3
  %761 = getelementptr double, ptr %735, i64 %760
  %762 = load double, ptr %761, align 8
  %763 = getelementptr double, ptr %8, i64 %760
  %764 = load double, ptr %763, align 8
  %765 = fmul double %762, %764
  %766 = fadd double %759, %765
  store double %766, ptr %736, align 8
  %767 = add nuw nsw i64 %738, 4
  %768 = getelementptr double, ptr %735, i64 %767
  %769 = load double, ptr %768, align 8
  %770 = getelementptr double, ptr %8, i64 %767
  %771 = load double, ptr %770, align 8
  %772 = fmul double %769, %771
  %773 = fadd double %766, %772
  store double %773, ptr %736, align 8
  %774 = add nuw nsw i64 %738, 5
  %exitcond.4.2.not.4 = icmp eq i64 %774, 65
  br i1 %exitcond.4.2.not.4, label %.preheader.4.3, label %737

.preheader.4.3:                                   ; preds = %737
  %775 = getelementptr double, ptr %1, i64 1235
  %776 = getelementptr double, ptr %13, i64 19
  br label %777

777:                                              ; preds = %777, %.preheader.4.3
  %778 = phi i64 [ 0, %.preheader.4.3 ], [ %814, %777 ]
  %779 = phi double [ 0.000000e+00, %.preheader.4.3 ], [ %813, %777 ]
  %780 = getelementptr double, ptr %775, i64 %778
  %781 = load double, ptr %780, align 8
  %782 = getelementptr double, ptr %8, i64 %778
  %783 = load double, ptr %782, align 8
  %784 = fmul double %781, %783
  %785 = fadd double %779, %784
  store double %785, ptr %776, align 8
  %786 = add nuw nsw i64 %778, 1
  %787 = getelementptr double, ptr %775, i64 %786
  %788 = load double, ptr %787, align 8
  %789 = getelementptr double, ptr %8, i64 %786
  %790 = load double, ptr %789, align 8
  %791 = fmul double %788, %790
  %792 = fadd double %785, %791
  store double %792, ptr %776, align 8
  %793 = add nuw nsw i64 %778, 2
  %794 = getelementptr double, ptr %775, i64 %793
  %795 = load double, ptr %794, align 8
  %796 = getelementptr double, ptr %8, i64 %793
  %797 = load double, ptr %796, align 8
  %798 = fmul double %795, %797
  %799 = fadd double %792, %798
  store double %799, ptr %776, align 8
  %800 = add nuw nsw i64 %778, 3
  %801 = getelementptr double, ptr %775, i64 %800
  %802 = load double, ptr %801, align 8
  %803 = getelementptr double, ptr %8, i64 %800
  %804 = load double, ptr %803, align 8
  %805 = fmul double %802, %804
  %806 = fadd double %799, %805
  store double %806, ptr %776, align 8
  %807 = add nuw nsw i64 %778, 4
  %808 = getelementptr double, ptr %775, i64 %807
  %809 = load double, ptr %808, align 8
  %810 = getelementptr double, ptr %8, i64 %807
  %811 = load double, ptr %810, align 8
  %812 = fmul double %809, %811
  %813 = fadd double %806, %812
  store double %813, ptr %776, align 8
  %814 = add nuw nsw i64 %778, 5
  %exitcond.4.3.not.4 = icmp eq i64 %814, 65
  br i1 %exitcond.4.3.not.4, label %.preheader3.5, label %777

.preheader3.5:                                    ; preds = %777
  %815 = getelementptr double, ptr %1, i64 1300
  %816 = getelementptr double, ptr %13, i64 20
  br label %817

817:                                              ; preds = %817, %.preheader3.5
  %818 = phi i64 [ 0, %.preheader3.5 ], [ %854, %817 ]
  %819 = phi double [ 0.000000e+00, %.preheader3.5 ], [ %853, %817 ]
  %820 = getelementptr double, ptr %815, i64 %818
  %821 = load double, ptr %820, align 8
  %822 = getelementptr double, ptr %8, i64 %818
  %823 = load double, ptr %822, align 8
  %824 = fmul double %821, %823
  %825 = fadd double %819, %824
  store double %825, ptr %816, align 8
  %826 = add nuw nsw i64 %818, 1
  %827 = getelementptr double, ptr %815, i64 %826
  %828 = load double, ptr %827, align 8
  %829 = getelementptr double, ptr %8, i64 %826
  %830 = load double, ptr %829, align 8
  %831 = fmul double %828, %830
  %832 = fadd double %825, %831
  store double %832, ptr %816, align 8
  %833 = add nuw nsw i64 %818, 2
  %834 = getelementptr double, ptr %815, i64 %833
  %835 = load double, ptr %834, align 8
  %836 = getelementptr double, ptr %8, i64 %833
  %837 = load double, ptr %836, align 8
  %838 = fmul double %835, %837
  %839 = fadd double %832, %838
  store double %839, ptr %816, align 8
  %840 = add nuw nsw i64 %818, 3
  %841 = getelementptr double, ptr %815, i64 %840
  %842 = load double, ptr %841, align 8
  %843 = getelementptr double, ptr %8, i64 %840
  %844 = load double, ptr %843, align 8
  %845 = fmul double %842, %844
  %846 = fadd double %839, %845
  store double %846, ptr %816, align 8
  %847 = add nuw nsw i64 %818, 4
  %848 = getelementptr double, ptr %815, i64 %847
  %849 = load double, ptr %848, align 8
  %850 = getelementptr double, ptr %8, i64 %847
  %851 = load double, ptr %850, align 8
  %852 = fmul double %849, %851
  %853 = fadd double %846, %852
  store double %853, ptr %816, align 8
  %854 = add nuw nsw i64 %818, 5
  %exitcond.5.not.4 = icmp eq i64 %854, 65
  br i1 %exitcond.5.not.4, label %.preheader.5.1, label %817

.preheader.5.1:                                   ; preds = %817
  %855 = getelementptr double, ptr %1, i64 1365
  %856 = getelementptr double, ptr %13, i64 21
  br label %857

857:                                              ; preds = %857, %.preheader.5.1
  %858 = phi i64 [ 0, %.preheader.5.1 ], [ %894, %857 ]
  %859 = phi double [ 0.000000e+00, %.preheader.5.1 ], [ %893, %857 ]
  %860 = getelementptr double, ptr %855, i64 %858
  %861 = load double, ptr %860, align 8
  %862 = getelementptr double, ptr %8, i64 %858
  %863 = load double, ptr %862, align 8
  %864 = fmul double %861, %863
  %865 = fadd double %859, %864
  store double %865, ptr %856, align 8
  %866 = add nuw nsw i64 %858, 1
  %867 = getelementptr double, ptr %855, i64 %866
  %868 = load double, ptr %867, align 8
  %869 = getelementptr double, ptr %8, i64 %866
  %870 = load double, ptr %869, align 8
  %871 = fmul double %868, %870
  %872 = fadd double %865, %871
  store double %872, ptr %856, align 8
  %873 = add nuw nsw i64 %858, 2
  %874 = getelementptr double, ptr %855, i64 %873
  %875 = load double, ptr %874, align 8
  %876 = getelementptr double, ptr %8, i64 %873
  %877 = load double, ptr %876, align 8
  %878 = fmul double %875, %877
  %879 = fadd double %872, %878
  store double %879, ptr %856, align 8
  %880 = add nuw nsw i64 %858, 3
  %881 = getelementptr double, ptr %855, i64 %880
  %882 = load double, ptr %881, align 8
  %883 = getelementptr double, ptr %8, i64 %880
  %884 = load double, ptr %883, align 8
  %885 = fmul double %882, %884
  %886 = fadd double %879, %885
  store double %886, ptr %856, align 8
  %887 = add nuw nsw i64 %858, 4
  %888 = getelementptr double, ptr %855, i64 %887
  %889 = load double, ptr %888, align 8
  %890 = getelementptr double, ptr %8, i64 %887
  %891 = load double, ptr %890, align 8
  %892 = fmul double %889, %891
  %893 = fadd double %886, %892
  store double %893, ptr %856, align 8
  %894 = add nuw nsw i64 %858, 5
  %exitcond.5.1.not.4 = icmp eq i64 %894, 65
  br i1 %exitcond.5.1.not.4, label %.preheader.5.2, label %857

.preheader.5.2:                                   ; preds = %857
  %895 = getelementptr double, ptr %1, i64 1430
  %896 = getelementptr double, ptr %13, i64 22
  br label %897

897:                                              ; preds = %897, %.preheader.5.2
  %898 = phi i64 [ 0, %.preheader.5.2 ], [ %934, %897 ]
  %899 = phi double [ 0.000000e+00, %.preheader.5.2 ], [ %933, %897 ]
  %900 = getelementptr double, ptr %895, i64 %898
  %901 = load double, ptr %900, align 8
  %902 = getelementptr double, ptr %8, i64 %898
  %903 = load double, ptr %902, align 8
  %904 = fmul double %901, %903
  %905 = fadd double %899, %904
  store double %905, ptr %896, align 8
  %906 = add nuw nsw i64 %898, 1
  %907 = getelementptr double, ptr %895, i64 %906
  %908 = load double, ptr %907, align 8
  %909 = getelementptr double, ptr %8, i64 %906
  %910 = load double, ptr %909, align 8
  %911 = fmul double %908, %910
  %912 = fadd double %905, %911
  store double %912, ptr %896, align 8
  %913 = add nuw nsw i64 %898, 2
  %914 = getelementptr double, ptr %895, i64 %913
  %915 = load double, ptr %914, align 8
  %916 = getelementptr double, ptr %8, i64 %913
  %917 = load double, ptr %916, align 8
  %918 = fmul double %915, %917
  %919 = fadd double %912, %918
  store double %919, ptr %896, align 8
  %920 = add nuw nsw i64 %898, 3
  %921 = getelementptr double, ptr %895, i64 %920
  %922 = load double, ptr %921, align 8
  %923 = getelementptr double, ptr %8, i64 %920
  %924 = load double, ptr %923, align 8
  %925 = fmul double %922, %924
  %926 = fadd double %919, %925
  store double %926, ptr %896, align 8
  %927 = add nuw nsw i64 %898, 4
  %928 = getelementptr double, ptr %895, i64 %927
  %929 = load double, ptr %928, align 8
  %930 = getelementptr double, ptr %8, i64 %927
  %931 = load double, ptr %930, align 8
  %932 = fmul double %929, %931
  %933 = fadd double %926, %932
  store double %933, ptr %896, align 8
  %934 = add nuw nsw i64 %898, 5
  %exitcond.5.2.not.4 = icmp eq i64 %934, 65
  br i1 %exitcond.5.2.not.4, label %.preheader.5.3, label %897

.preheader.5.3:                                   ; preds = %897
  %935 = getelementptr double, ptr %1, i64 1495
  %936 = getelementptr double, ptr %13, i64 23
  br label %937

937:                                              ; preds = %937, %.preheader.5.3
  %938 = phi i64 [ 0, %.preheader.5.3 ], [ %974, %937 ]
  %939 = phi double [ 0.000000e+00, %.preheader.5.3 ], [ %973, %937 ]
  %940 = getelementptr double, ptr %935, i64 %938
  %941 = load double, ptr %940, align 8
  %942 = getelementptr double, ptr %8, i64 %938
  %943 = load double, ptr %942, align 8
  %944 = fmul double %941, %943
  %945 = fadd double %939, %944
  store double %945, ptr %936, align 8
  %946 = add nuw nsw i64 %938, 1
  %947 = getelementptr double, ptr %935, i64 %946
  %948 = load double, ptr %947, align 8
  %949 = getelementptr double, ptr %8, i64 %946
  %950 = load double, ptr %949, align 8
  %951 = fmul double %948, %950
  %952 = fadd double %945, %951
  store double %952, ptr %936, align 8
  %953 = add nuw nsw i64 %938, 2
  %954 = getelementptr double, ptr %935, i64 %953
  %955 = load double, ptr %954, align 8
  %956 = getelementptr double, ptr %8, i64 %953
  %957 = load double, ptr %956, align 8
  %958 = fmul double %955, %957
  %959 = fadd double %952, %958
  store double %959, ptr %936, align 8
  %960 = add nuw nsw i64 %938, 3
  %961 = getelementptr double, ptr %935, i64 %960
  %962 = load double, ptr %961, align 8
  %963 = getelementptr double, ptr %8, i64 %960
  %964 = load double, ptr %963, align 8
  %965 = fmul double %962, %964
  %966 = fadd double %959, %965
  store double %966, ptr %936, align 8
  %967 = add nuw nsw i64 %938, 4
  %968 = getelementptr double, ptr %935, i64 %967
  %969 = load double, ptr %968, align 8
  %970 = getelementptr double, ptr %8, i64 %967
  %971 = load double, ptr %970, align 8
  %972 = fmul double %969, %971
  %973 = fadd double %966, %972
  store double %973, ptr %936, align 8
  %974 = add nuw nsw i64 %938, 5
  %exitcond.5.3.not.4 = icmp eq i64 %974, 65
  br i1 %exitcond.5.3.not.4, label %.preheader3.6, label %937

.preheader3.6:                                    ; preds = %937
  %975 = getelementptr double, ptr %1, i64 1560
  %976 = getelementptr double, ptr %13, i64 24
  br label %977

977:                                              ; preds = %977, %.preheader3.6
  %978 = phi i64 [ 0, %.preheader3.6 ], [ %1014, %977 ]
  %979 = phi double [ 0.000000e+00, %.preheader3.6 ], [ %1013, %977 ]
  %980 = getelementptr double, ptr %975, i64 %978
  %981 = load double, ptr %980, align 8
  %982 = getelementptr double, ptr %8, i64 %978
  %983 = load double, ptr %982, align 8
  %984 = fmul double %981, %983
  %985 = fadd double %979, %984
  store double %985, ptr %976, align 8
  %986 = add nuw nsw i64 %978, 1
  %987 = getelementptr double, ptr %975, i64 %986
  %988 = load double, ptr %987, align 8
  %989 = getelementptr double, ptr %8, i64 %986
  %990 = load double, ptr %989, align 8
  %991 = fmul double %988, %990
  %992 = fadd double %985, %991
  store double %992, ptr %976, align 8
  %993 = add nuw nsw i64 %978, 2
  %994 = getelementptr double, ptr %975, i64 %993
  %995 = load double, ptr %994, align 8
  %996 = getelementptr double, ptr %8, i64 %993
  %997 = load double, ptr %996, align 8
  %998 = fmul double %995, %997
  %999 = fadd double %992, %998
  store double %999, ptr %976, align 8
  %1000 = add nuw nsw i64 %978, 3
  %1001 = getelementptr double, ptr %975, i64 %1000
  %1002 = load double, ptr %1001, align 8
  %1003 = getelementptr double, ptr %8, i64 %1000
  %1004 = load double, ptr %1003, align 8
  %1005 = fmul double %1002, %1004
  %1006 = fadd double %999, %1005
  store double %1006, ptr %976, align 8
  %1007 = add nuw nsw i64 %978, 4
  %1008 = getelementptr double, ptr %975, i64 %1007
  %1009 = load double, ptr %1008, align 8
  %1010 = getelementptr double, ptr %8, i64 %1007
  %1011 = load double, ptr %1010, align 8
  %1012 = fmul double %1009, %1011
  %1013 = fadd double %1006, %1012
  store double %1013, ptr %976, align 8
  %1014 = add nuw nsw i64 %978, 5
  %exitcond.6.not.4 = icmp eq i64 %1014, 65
  br i1 %exitcond.6.not.4, label %.preheader.6.1, label %977

.preheader.6.1:                                   ; preds = %977
  %1015 = getelementptr double, ptr %1, i64 1625
  %1016 = getelementptr double, ptr %13, i64 25
  br label %1017

1017:                                             ; preds = %1017, %.preheader.6.1
  %1018 = phi i64 [ 0, %.preheader.6.1 ], [ %1054, %1017 ]
  %1019 = phi double [ 0.000000e+00, %.preheader.6.1 ], [ %1053, %1017 ]
  %1020 = getelementptr double, ptr %1015, i64 %1018
  %1021 = load double, ptr %1020, align 8
  %1022 = getelementptr double, ptr %8, i64 %1018
  %1023 = load double, ptr %1022, align 8
  %1024 = fmul double %1021, %1023
  %1025 = fadd double %1019, %1024
  store double %1025, ptr %1016, align 8
  %1026 = add nuw nsw i64 %1018, 1
  %1027 = getelementptr double, ptr %1015, i64 %1026
  %1028 = load double, ptr %1027, align 8
  %1029 = getelementptr double, ptr %8, i64 %1026
  %1030 = load double, ptr %1029, align 8
  %1031 = fmul double %1028, %1030
  %1032 = fadd double %1025, %1031
  store double %1032, ptr %1016, align 8
  %1033 = add nuw nsw i64 %1018, 2
  %1034 = getelementptr double, ptr %1015, i64 %1033
  %1035 = load double, ptr %1034, align 8
  %1036 = getelementptr double, ptr %8, i64 %1033
  %1037 = load double, ptr %1036, align 8
  %1038 = fmul double %1035, %1037
  %1039 = fadd double %1032, %1038
  store double %1039, ptr %1016, align 8
  %1040 = add nuw nsw i64 %1018, 3
  %1041 = getelementptr double, ptr %1015, i64 %1040
  %1042 = load double, ptr %1041, align 8
  %1043 = getelementptr double, ptr %8, i64 %1040
  %1044 = load double, ptr %1043, align 8
  %1045 = fmul double %1042, %1044
  %1046 = fadd double %1039, %1045
  store double %1046, ptr %1016, align 8
  %1047 = add nuw nsw i64 %1018, 4
  %1048 = getelementptr double, ptr %1015, i64 %1047
  %1049 = load double, ptr %1048, align 8
  %1050 = getelementptr double, ptr %8, i64 %1047
  %1051 = load double, ptr %1050, align 8
  %1052 = fmul double %1049, %1051
  %1053 = fadd double %1046, %1052
  store double %1053, ptr %1016, align 8
  %1054 = add nuw nsw i64 %1018, 5
  %exitcond.6.1.not.4 = icmp eq i64 %1054, 65
  br i1 %exitcond.6.1.not.4, label %.preheader.6.2, label %1017

.preheader.6.2:                                   ; preds = %1017
  %1055 = getelementptr double, ptr %1, i64 1690
  %1056 = getelementptr double, ptr %13, i64 26
  br label %1057

1057:                                             ; preds = %1057, %.preheader.6.2
  %1058 = phi i64 [ 0, %.preheader.6.2 ], [ %1094, %1057 ]
  %1059 = phi double [ 0.000000e+00, %.preheader.6.2 ], [ %1093, %1057 ]
  %1060 = getelementptr double, ptr %1055, i64 %1058
  %1061 = load double, ptr %1060, align 8
  %1062 = getelementptr double, ptr %8, i64 %1058
  %1063 = load double, ptr %1062, align 8
  %1064 = fmul double %1061, %1063
  %1065 = fadd double %1059, %1064
  store double %1065, ptr %1056, align 8
  %1066 = add nuw nsw i64 %1058, 1
  %1067 = getelementptr double, ptr %1055, i64 %1066
  %1068 = load double, ptr %1067, align 8
  %1069 = getelementptr double, ptr %8, i64 %1066
  %1070 = load double, ptr %1069, align 8
  %1071 = fmul double %1068, %1070
  %1072 = fadd double %1065, %1071
  store double %1072, ptr %1056, align 8
  %1073 = add nuw nsw i64 %1058, 2
  %1074 = getelementptr double, ptr %1055, i64 %1073
  %1075 = load double, ptr %1074, align 8
  %1076 = getelementptr double, ptr %8, i64 %1073
  %1077 = load double, ptr %1076, align 8
  %1078 = fmul double %1075, %1077
  %1079 = fadd double %1072, %1078
  store double %1079, ptr %1056, align 8
  %1080 = add nuw nsw i64 %1058, 3
  %1081 = getelementptr double, ptr %1055, i64 %1080
  %1082 = load double, ptr %1081, align 8
  %1083 = getelementptr double, ptr %8, i64 %1080
  %1084 = load double, ptr %1083, align 8
  %1085 = fmul double %1082, %1084
  %1086 = fadd double %1079, %1085
  store double %1086, ptr %1056, align 8
  %1087 = add nuw nsw i64 %1058, 4
  %1088 = getelementptr double, ptr %1055, i64 %1087
  %1089 = load double, ptr %1088, align 8
  %1090 = getelementptr double, ptr %8, i64 %1087
  %1091 = load double, ptr %1090, align 8
  %1092 = fmul double %1089, %1091
  %1093 = fadd double %1086, %1092
  store double %1093, ptr %1056, align 8
  %1094 = add nuw nsw i64 %1058, 5
  %exitcond.6.2.not.4 = icmp eq i64 %1094, 65
  br i1 %exitcond.6.2.not.4, label %.preheader.6.3, label %1057

.preheader.6.3:                                   ; preds = %1057
  %1095 = getelementptr double, ptr %1, i64 1755
  %1096 = getelementptr double, ptr %13, i64 27
  br label %1097

1097:                                             ; preds = %1097, %.preheader.6.3
  %1098 = phi i64 [ 0, %.preheader.6.3 ], [ %1134, %1097 ]
  %1099 = phi double [ 0.000000e+00, %.preheader.6.3 ], [ %1133, %1097 ]
  %1100 = getelementptr double, ptr %1095, i64 %1098
  %1101 = load double, ptr %1100, align 8
  %1102 = getelementptr double, ptr %8, i64 %1098
  %1103 = load double, ptr %1102, align 8
  %1104 = fmul double %1101, %1103
  %1105 = fadd double %1099, %1104
  store double %1105, ptr %1096, align 8
  %1106 = add nuw nsw i64 %1098, 1
  %1107 = getelementptr double, ptr %1095, i64 %1106
  %1108 = load double, ptr %1107, align 8
  %1109 = getelementptr double, ptr %8, i64 %1106
  %1110 = load double, ptr %1109, align 8
  %1111 = fmul double %1108, %1110
  %1112 = fadd double %1105, %1111
  store double %1112, ptr %1096, align 8
  %1113 = add nuw nsw i64 %1098, 2
  %1114 = getelementptr double, ptr %1095, i64 %1113
  %1115 = load double, ptr %1114, align 8
  %1116 = getelementptr double, ptr %8, i64 %1113
  %1117 = load double, ptr %1116, align 8
  %1118 = fmul double %1115, %1117
  %1119 = fadd double %1112, %1118
  store double %1119, ptr %1096, align 8
  %1120 = add nuw nsw i64 %1098, 3
  %1121 = getelementptr double, ptr %1095, i64 %1120
  %1122 = load double, ptr %1121, align 8
  %1123 = getelementptr double, ptr %8, i64 %1120
  %1124 = load double, ptr %1123, align 8
  %1125 = fmul double %1122, %1124
  %1126 = fadd double %1119, %1125
  store double %1126, ptr %1096, align 8
  %1127 = add nuw nsw i64 %1098, 4
  %1128 = getelementptr double, ptr %1095, i64 %1127
  %1129 = load double, ptr %1128, align 8
  %1130 = getelementptr double, ptr %8, i64 %1127
  %1131 = load double, ptr %1130, align 8
  %1132 = fmul double %1129, %1131
  %1133 = fadd double %1126, %1132
  store double %1133, ptr %1096, align 8
  %1134 = add nuw nsw i64 %1098, 5
  %exitcond.6.3.not.4 = icmp eq i64 %1134, 65
  br i1 %exitcond.6.3.not.4, label %.preheader3.7, label %1097

.preheader3.7:                                    ; preds = %1097
  %1135 = getelementptr double, ptr %1, i64 1820
  %1136 = getelementptr double, ptr %13, i64 28
  br label %1137

1137:                                             ; preds = %1137, %.preheader3.7
  %1138 = phi i64 [ 0, %.preheader3.7 ], [ %1174, %1137 ]
  %1139 = phi double [ 0.000000e+00, %.preheader3.7 ], [ %1173, %1137 ]
  %1140 = getelementptr double, ptr %1135, i64 %1138
  %1141 = load double, ptr %1140, align 8
  %1142 = getelementptr double, ptr %8, i64 %1138
  %1143 = load double, ptr %1142, align 8
  %1144 = fmul double %1141, %1143
  %1145 = fadd double %1139, %1144
  store double %1145, ptr %1136, align 8
  %1146 = add nuw nsw i64 %1138, 1
  %1147 = getelementptr double, ptr %1135, i64 %1146
  %1148 = load double, ptr %1147, align 8
  %1149 = getelementptr double, ptr %8, i64 %1146
  %1150 = load double, ptr %1149, align 8
  %1151 = fmul double %1148, %1150
  %1152 = fadd double %1145, %1151
  store double %1152, ptr %1136, align 8
  %1153 = add nuw nsw i64 %1138, 2
  %1154 = getelementptr double, ptr %1135, i64 %1153
  %1155 = load double, ptr %1154, align 8
  %1156 = getelementptr double, ptr %8, i64 %1153
  %1157 = load double, ptr %1156, align 8
  %1158 = fmul double %1155, %1157
  %1159 = fadd double %1152, %1158
  store double %1159, ptr %1136, align 8
  %1160 = add nuw nsw i64 %1138, 3
  %1161 = getelementptr double, ptr %1135, i64 %1160
  %1162 = load double, ptr %1161, align 8
  %1163 = getelementptr double, ptr %8, i64 %1160
  %1164 = load double, ptr %1163, align 8
  %1165 = fmul double %1162, %1164
  %1166 = fadd double %1159, %1165
  store double %1166, ptr %1136, align 8
  %1167 = add nuw nsw i64 %1138, 4
  %1168 = getelementptr double, ptr %1135, i64 %1167
  %1169 = load double, ptr %1168, align 8
  %1170 = getelementptr double, ptr %8, i64 %1167
  %1171 = load double, ptr %1170, align 8
  %1172 = fmul double %1169, %1171
  %1173 = fadd double %1166, %1172
  store double %1173, ptr %1136, align 8
  %1174 = add nuw nsw i64 %1138, 5
  %exitcond.7.not.4 = icmp eq i64 %1174, 65
  br i1 %exitcond.7.not.4, label %.preheader.7.1, label %1137

.preheader.7.1:                                   ; preds = %1137
  %1175 = getelementptr double, ptr %1, i64 1885
  %1176 = getelementptr double, ptr %13, i64 29
  br label %1177

1177:                                             ; preds = %1177, %.preheader.7.1
  %1178 = phi i64 [ 0, %.preheader.7.1 ], [ %1214, %1177 ]
  %1179 = phi double [ 0.000000e+00, %.preheader.7.1 ], [ %1213, %1177 ]
  %1180 = getelementptr double, ptr %1175, i64 %1178
  %1181 = load double, ptr %1180, align 8
  %1182 = getelementptr double, ptr %8, i64 %1178
  %1183 = load double, ptr %1182, align 8
  %1184 = fmul double %1181, %1183
  %1185 = fadd double %1179, %1184
  store double %1185, ptr %1176, align 8
  %1186 = add nuw nsw i64 %1178, 1
  %1187 = getelementptr double, ptr %1175, i64 %1186
  %1188 = load double, ptr %1187, align 8
  %1189 = getelementptr double, ptr %8, i64 %1186
  %1190 = load double, ptr %1189, align 8
  %1191 = fmul double %1188, %1190
  %1192 = fadd double %1185, %1191
  store double %1192, ptr %1176, align 8
  %1193 = add nuw nsw i64 %1178, 2
  %1194 = getelementptr double, ptr %1175, i64 %1193
  %1195 = load double, ptr %1194, align 8
  %1196 = getelementptr double, ptr %8, i64 %1193
  %1197 = load double, ptr %1196, align 8
  %1198 = fmul double %1195, %1197
  %1199 = fadd double %1192, %1198
  store double %1199, ptr %1176, align 8
  %1200 = add nuw nsw i64 %1178, 3
  %1201 = getelementptr double, ptr %1175, i64 %1200
  %1202 = load double, ptr %1201, align 8
  %1203 = getelementptr double, ptr %8, i64 %1200
  %1204 = load double, ptr %1203, align 8
  %1205 = fmul double %1202, %1204
  %1206 = fadd double %1199, %1205
  store double %1206, ptr %1176, align 8
  %1207 = add nuw nsw i64 %1178, 4
  %1208 = getelementptr double, ptr %1175, i64 %1207
  %1209 = load double, ptr %1208, align 8
  %1210 = getelementptr double, ptr %8, i64 %1207
  %1211 = load double, ptr %1210, align 8
  %1212 = fmul double %1209, %1211
  %1213 = fadd double %1206, %1212
  store double %1213, ptr %1176, align 8
  %1214 = add nuw nsw i64 %1178, 5
  %exitcond.7.1.not.4 = icmp eq i64 %1214, 65
  br i1 %exitcond.7.1.not.4, label %.preheader.7.2, label %1177

.preheader.7.2:                                   ; preds = %1177
  %1215 = getelementptr double, ptr %1, i64 1950
  %1216 = getelementptr double, ptr %13, i64 30
  br label %1217

1217:                                             ; preds = %1217, %.preheader.7.2
  %1218 = phi i64 [ 0, %.preheader.7.2 ], [ %1254, %1217 ]
  %1219 = phi double [ 0.000000e+00, %.preheader.7.2 ], [ %1253, %1217 ]
  %1220 = getelementptr double, ptr %1215, i64 %1218
  %1221 = load double, ptr %1220, align 8
  %1222 = getelementptr double, ptr %8, i64 %1218
  %1223 = load double, ptr %1222, align 8
  %1224 = fmul double %1221, %1223
  %1225 = fadd double %1219, %1224
  store double %1225, ptr %1216, align 8
  %1226 = add nuw nsw i64 %1218, 1
  %1227 = getelementptr double, ptr %1215, i64 %1226
  %1228 = load double, ptr %1227, align 8
  %1229 = getelementptr double, ptr %8, i64 %1226
  %1230 = load double, ptr %1229, align 8
  %1231 = fmul double %1228, %1230
  %1232 = fadd double %1225, %1231
  store double %1232, ptr %1216, align 8
  %1233 = add nuw nsw i64 %1218, 2
  %1234 = getelementptr double, ptr %1215, i64 %1233
  %1235 = load double, ptr %1234, align 8
  %1236 = getelementptr double, ptr %8, i64 %1233
  %1237 = load double, ptr %1236, align 8
  %1238 = fmul double %1235, %1237
  %1239 = fadd double %1232, %1238
  store double %1239, ptr %1216, align 8
  %1240 = add nuw nsw i64 %1218, 3
  %1241 = getelementptr double, ptr %1215, i64 %1240
  %1242 = load double, ptr %1241, align 8
  %1243 = getelementptr double, ptr %8, i64 %1240
  %1244 = load double, ptr %1243, align 8
  %1245 = fmul double %1242, %1244
  %1246 = fadd double %1239, %1245
  store double %1246, ptr %1216, align 8
  %1247 = add nuw nsw i64 %1218, 4
  %1248 = getelementptr double, ptr %1215, i64 %1247
  %1249 = load double, ptr %1248, align 8
  %1250 = getelementptr double, ptr %8, i64 %1247
  %1251 = load double, ptr %1250, align 8
  %1252 = fmul double %1249, %1251
  %1253 = fadd double %1246, %1252
  store double %1253, ptr %1216, align 8
  %1254 = add nuw nsw i64 %1218, 5
  %exitcond.7.2.not.4 = icmp eq i64 %1254, 65
  br i1 %exitcond.7.2.not.4, label %1255, label %1217

1255:                                             ; preds = %1217
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
