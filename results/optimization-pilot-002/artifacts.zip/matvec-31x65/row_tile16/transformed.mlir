#map = affine_map<(d0) -> (-d0 + 31, 16)>
#map1 = affine_map<(d0, d1) -> (d0, d1)>
#map2 = affine_map<(d0, d1) -> (d1)>
#map3 = affine_map<(d0, d1) -> (d0)>
module {
  func.func @kernel(%arg0: memref<31x65xf64>, %arg1: memref<65xf64>, %arg2: memref<31xf64>) attributes {llvm.emit_c_interface} {
    %c16 = arith.constant 16 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<31xf64>)
    %c0_0 = arith.constant 0 : index
    %c31 = arith.constant 31 : index
    %c16_1 = arith.constant 16 : index
    scf.for %arg3 = %c0_0 to %c31 step %c16_1 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 65] [1, 1] : memref<31x65xf64> to memref<?x65xf64, strided<[65, 1], offset: ?>>
      %subview_2 = memref.subview %arg2[%arg3] [%1] [1] : memref<31xf64> to memref<?xf64, strided<[1], offset: ?>>
      linalg.generic {indexing_maps = [#map1, #map2, #map3], iterator_types = ["parallel", "reduction"]} ins(%subview, %arg1 : memref<?x65xf64, strided<[65, 1], offset: ?>>, memref<65xf64>) outs(%subview_2 : memref<?xf64, strided<[1], offset: ?>>) {
      ^bb0(%in: f64, %in_3: f64, %out: f64):
        %2 = arith.mulf %in, %in_3 : f64
        %3 = arith.addf %out, %2 : f64
        linalg.yield %3 : f64
      }
    }
    return
  }
}
