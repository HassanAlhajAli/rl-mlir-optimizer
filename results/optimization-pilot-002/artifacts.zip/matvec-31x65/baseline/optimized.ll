; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %13, i8 0, i64 248, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %59
  %17 = phi i64 [ %60, %59 ], [ 0, %.preheader.preheader ]
  %18 = mul nuw nsw i64 %17, 65
  %19 = getelementptr double, ptr %1, i64 %18
  %20 = getelementptr double, ptr %13, i64 %17
  %.promoted = load double, ptr %20, align 8
  br label %21

21:                                               ; preds = %21, %.preheader
  %22 = phi i64 [ 0, %.preheader ], [ %58, %21 ]
  %23 = phi double [ %.promoted, %.preheader ], [ %57, %21 ]
  %24 = getelementptr double, ptr %19, i64 %22
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %8, i64 %22
  %27 = load double, ptr %26, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %23, %28
  store double %29, ptr %20, align 8
  %30 = add nuw nsw i64 %22, 1
  %31 = getelementptr double, ptr %19, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %8, i64 %30
  %34 = load double, ptr %33, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %29, %35
  store double %36, ptr %20, align 8
  %37 = add nuw nsw i64 %22, 2
  %38 = getelementptr double, ptr %19, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %8, i64 %37
  %41 = load double, ptr %40, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %20, align 8
  %44 = add nuw nsw i64 %22, 3
  %45 = getelementptr double, ptr %19, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %8, i64 %44
  %48 = load double, ptr %47, align 8
  %49 = fmul double %46, %48
  %50 = fadd double %43, %49
  store double %50, ptr %20, align 8
  %51 = add nuw nsw i64 %22, 4
  %52 = getelementptr double, ptr %19, i64 %51
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %8, i64 %51
  %55 = load double, ptr %54, align 8
  %56 = fmul double %53, %55
  %57 = fadd double %50, %56
  store double %57, ptr %20, align 8
  %58 = add nuw nsw i64 %22, 5
  %exitcond.not.4 = icmp eq i64 %58, 65
  br i1 %exitcond.not.4, label %59, label %21

59:                                               ; preds = %21
  %60 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %60, 31
  br i1 %exitcond3.not, label %61, label %.preheader

61:                                               ; preds = %59
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28, i8 0, i64 248, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %46, %3
  %4 = phi i64 [ %47, %46 ], [ 0, %3 ]
  %5 = mul nuw nsw i64 %4, 65
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %7 = getelementptr double, ptr %.unpack28, i64 %4
  %.promoted.i = load double, ptr %7, align 8
  br label %8

8:                                                ; preds = %8, %.preheader.i
  %9 = phi i64 [ 0, %.preheader.i ], [ %45, %8 ]
  %10 = phi double [ %.promoted.i, %.preheader.i ], [ %44, %8 ]
  %11 = getelementptr double, ptr %6, i64 %9
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %.unpack17, i64 %9
  %14 = load double, ptr %13, align 8
  %15 = fmul double %12, %14
  %16 = fadd double %10, %15
  store double %16, ptr %7, align 8
  %17 = add nuw nsw i64 %9, 1
  %18 = getelementptr double, ptr %6, i64 %17
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %.unpack17, i64 %17
  %21 = load double, ptr %20, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %16, %22
  store double %23, ptr %7, align 8
  %24 = add nuw nsw i64 %9, 2
  %25 = getelementptr double, ptr %6, i64 %24
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %.unpack17, i64 %24
  %28 = load double, ptr %27, align 8
  %29 = fmul double %26, %28
  %30 = fadd double %23, %29
  store double %30, ptr %7, align 8
  %31 = add nuw nsw i64 %9, 3
  %32 = getelementptr double, ptr %6, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %.unpack17, i64 %31
  %35 = load double, ptr %34, align 8
  %36 = fmul double %33, %35
  %37 = fadd double %30, %36
  store double %37, ptr %7, align 8
  %38 = add nuw nsw i64 %9, 4
  %39 = getelementptr double, ptr %6, i64 %38
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %.unpack17, i64 %38
  %42 = load double, ptr %41, align 8
  %43 = fmul double %40, %42
  %44 = fadd double %37, %43
  store double %44, ptr %7, align 8
  %45 = add nuw nsw i64 %9, 5
  %exitcond.not.i.4 = icmp eq i64 %45, 65
  br i1 %exitcond.not.i.4, label %46, label %8

46:                                               ; preds = %8
  %47 = add nuw nsw i64 %4, 1
  %exitcond3.not.i = icmp eq i64 %47, 31
  br i1 %exitcond3.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %46
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %10, i8 0, i64 248, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %53, %1
  %11 = phi i64 [ %54, %53 ], [ 0, %1 ]
  %12 = mul nuw nsw i64 %11, 65
  %13 = getelementptr double, ptr %4, i64 %12
  %14 = getelementptr double, ptr %10, i64 %11
  %.promoted.i = load double, ptr %14, align 8
  br label %15

15:                                               ; preds = %15, %.preheader.i
  %16 = phi i64 [ 0, %.preheader.i ], [ %52, %15 ]
  %17 = phi double [ %.promoted.i, %.preheader.i ], [ %51, %15 ]
  %18 = getelementptr double, ptr %13, i64 %16
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %7, i64 %16
  %21 = load double, ptr %20, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %17, %22
  store double %23, ptr %14, align 8
  %24 = add nuw nsw i64 %16, 1
  %25 = getelementptr double, ptr %13, i64 %24
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %7, i64 %24
  %28 = load double, ptr %27, align 8
  %29 = fmul double %26, %28
  %30 = fadd double %23, %29
  store double %30, ptr %14, align 8
  %31 = add nuw nsw i64 %16, 2
  %32 = getelementptr double, ptr %13, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %7, i64 %31
  %35 = load double, ptr %34, align 8
  %36 = fmul double %33, %35
  %37 = fadd double %30, %36
  store double %37, ptr %14, align 8
  %38 = add nuw nsw i64 %16, 3
  %39 = getelementptr double, ptr %13, i64 %38
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %7, i64 %38
  %42 = load double, ptr %41, align 8
  %43 = fmul double %40, %42
  %44 = fadd double %37, %43
  store double %44, ptr %14, align 8
  %45 = add nuw nsw i64 %16, 4
  %46 = getelementptr double, ptr %13, i64 %45
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %7, i64 %45
  %49 = load double, ptr %48, align 8
  %50 = fmul double %47, %49
  %51 = fadd double %44, %50
  store double %51, ptr %14, align 8
  %52 = add nuw nsw i64 %16, 5
  %exitcond.not.i.4 = icmp eq i64 %52, 65
  br i1 %exitcond.not.i.4, label %53, label %15

53:                                               ; preds = %15
  %54 = add nuw nsw i64 %11, 1
  %exitcond3.not.i = icmp eq i64 %54, 31
  br i1 %exitcond3.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %53
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(248) %.unpack28.i, i8 0, i64 248, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %52, %1
  %10 = phi i64 [ %53, %52 ], [ 0, %1 ]
  %11 = mul nuw nsw i64 %10, 65
  %12 = getelementptr double, ptr %.unpack2.i, i64 %11
  %13 = getelementptr double, ptr %.unpack28.i, i64 %10
  %.promoted.i.i = load double, ptr %13, align 8
  br label %14

14:                                               ; preds = %14, %.preheader.i.i
  %15 = phi i64 [ 0, %.preheader.i.i ], [ %51, %14 ]
  %16 = phi double [ %.promoted.i.i, %.preheader.i.i ], [ %50, %14 ]
  %17 = getelementptr double, ptr %12, i64 %15
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %.unpack17.i, i64 %15
  %20 = load double, ptr %19, align 8
  %21 = fmul double %18, %20
  %22 = fadd double %16, %21
  store double %22, ptr %13, align 8
  %23 = add nuw nsw i64 %15, 1
  %24 = getelementptr double, ptr %12, i64 %23
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %.unpack17.i, i64 %23
  %27 = load double, ptr %26, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %22, %28
  store double %29, ptr %13, align 8
  %30 = add nuw nsw i64 %15, 2
  %31 = getelementptr double, ptr %12, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %.unpack17.i, i64 %30
  %34 = load double, ptr %33, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %29, %35
  store double %36, ptr %13, align 8
  %37 = add nuw nsw i64 %15, 3
  %38 = getelementptr double, ptr %12, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %.unpack17.i, i64 %37
  %41 = load double, ptr %40, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %13, align 8
  %44 = add nuw nsw i64 %15, 4
  %45 = getelementptr double, ptr %12, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %.unpack17.i, i64 %44
  %48 = load double, ptr %47, align 8
  %49 = fmul double %46, %48
  %50 = fadd double %43, %49
  store double %50, ptr %13, align 8
  %51 = add nuw nsw i64 %15, 5
  %exitcond.not.i.i.4 = icmp eq i64 %51, 65
  br i1 %exitcond.not.i.i.4, label %52, label %14

52:                                               ; preds = %14
  %53 = add nuw nsw i64 %10, 1
  %exitcond3.not.i.i = icmp eq i64 %53, 31
  br i1 %exitcond3.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader.i.i

_mlir_ciface_kernel.exit:                         ; preds = %52
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
