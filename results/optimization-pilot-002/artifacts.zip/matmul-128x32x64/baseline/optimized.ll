; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %56
  %21 = phi i64 [ %57, %56 ], [ 0, %.preheader2.preheader ]
  %22 = shl i64 %21, 6
  %23 = shl i64 %21, 5
  %24 = getelementptr double, ptr %15, i64 %23
  %invariant.gep7 = getelementptr double, ptr %1, i64 %22
  br label %.preheader

.preheader:                                       ; preds = %.preheader2, %54
  %25 = phi i64 [ 0, %.preheader2 ], [ %55, %54 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %25
  %26 = getelementptr double, ptr %24, i64 %25
  %.promoted = load double, ptr %26, align 8
  br label %27

27:                                               ; preds = %27, %.preheader
  %28 = phi i64 [ 0, %.preheader ], [ %53, %27 ]
  %29 = phi double [ %.promoted, %.preheader ], [ %52, %27 ]
  %gep8 = getelementptr double, ptr %invariant.gep7, i64 %28
  %30 = load double, ptr %gep8, align 8
  %31 = shl nuw nsw i64 %28, 5
  %gep = getelementptr double, ptr %invariant.gep, i64 %31
  %32 = load double, ptr %gep, align 8
  %33 = fmul double %30, %32
  %34 = fadd double %29, %33
  store double %34, ptr %26, align 8
  %35 = or disjoint i64 %28, 1
  %gep8.1 = getelementptr double, ptr %invariant.gep7, i64 %35
  %36 = load double, ptr %gep8.1, align 8
  %37 = shl nuw nsw i64 %35, 5
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %37
  %38 = load double, ptr %gep.1, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %34, %39
  store double %40, ptr %26, align 8
  %41 = or disjoint i64 %28, 2
  %gep8.2 = getelementptr double, ptr %invariant.gep7, i64 %41
  %42 = load double, ptr %gep8.2, align 8
  %43 = shl nuw nsw i64 %41, 5
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %43
  %44 = load double, ptr %gep.2, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %40, %45
  store double %46, ptr %26, align 8
  %47 = or disjoint i64 %28, 3
  %gep8.3 = getelementptr double, ptr %invariant.gep7, i64 %47
  %48 = load double, ptr %gep8.3, align 8
  %49 = shl nuw nsw i64 %47, 5
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %49
  %50 = load double, ptr %gep.3, align 8
  %51 = fmul double %48, %50
  %52 = fadd double %46, %51
  store double %52, ptr %26, align 8
  %53 = add nuw nsw i64 %28, 4
  %exitcond.not.3 = icmp eq i64 %53, 64
  br i1 %exitcond.not.3, label %54, label %27

54:                                               ; preds = %27
  %55 = add nuw nsw i64 %25, 1
  %exitcond5.not = icmp eq i64 %55, 32
  br i1 %exitcond5.not, label %56, label %.preheader

56:                                               ; preds = %54
  %57 = add nuw nsw i64 %21, 1
  %exitcond6.not = icmp eq i64 %57, 128
  br i1 %exitcond6.not, label %58, label %.preheader2

58:                                               ; preds = %56
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  br label %.preheader2.i

.preheader2.i:                                    ; preds = %39, %3
  %4 = phi i64 [ %40, %39 ], [ 0, %3 ]
  %5 = shl i64 %4, 6
  %6 = shl i64 %4, 5
  %7 = getelementptr double, ptr %.unpack32, i64 %6
  %invariant.gep7.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %.preheader.i

.preheader.i:                                     ; preds = %37, %.preheader2.i
  %8 = phi i64 [ 0, %.preheader2.i ], [ %38, %37 ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %8
  %9 = getelementptr double, ptr %7, i64 %8
  %.promoted.i = load double, ptr %9, align 8
  br label %10

10:                                               ; preds = %10, %.preheader.i
  %11 = phi i64 [ 0, %.preheader.i ], [ %36, %10 ]
  %12 = phi double [ %.promoted.i, %.preheader.i ], [ %35, %10 ]
  %gep8.i = getelementptr double, ptr %invariant.gep7.i, i64 %11
  %13 = load double, ptr %gep8.i, align 8
  %14 = shl nuw nsw i64 %11, 5
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %14
  %15 = load double, ptr %gep.i, align 8
  %16 = fmul double %13, %15
  %17 = fadd double %12, %16
  store double %17, ptr %9, align 8
  %18 = or disjoint i64 %11, 1
  %gep8.i.1 = getelementptr double, ptr %invariant.gep7.i, i64 %18
  %19 = load double, ptr %gep8.i.1, align 8
  %20 = shl nuw nsw i64 %18, 5
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %20
  %21 = load double, ptr %gep.i.1, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %17, %22
  store double %23, ptr %9, align 8
  %24 = or disjoint i64 %11, 2
  %gep8.i.2 = getelementptr double, ptr %invariant.gep7.i, i64 %24
  %25 = load double, ptr %gep8.i.2, align 8
  %26 = shl nuw nsw i64 %24, 5
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %26
  %27 = load double, ptr %gep.i.2, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %23, %28
  store double %29, ptr %9, align 8
  %30 = or disjoint i64 %11, 3
  %gep8.i.3 = getelementptr double, ptr %invariant.gep7.i, i64 %30
  %31 = load double, ptr %gep8.i.3, align 8
  %32 = shl nuw nsw i64 %30, 5
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %32
  %33 = load double, ptr %gep.i.3, align 8
  %34 = fmul double %31, %33
  %35 = fadd double %29, %34
  store double %35, ptr %9, align 8
  %36 = add nuw nsw i64 %11, 4
  %exitcond.not.i.3 = icmp eq i64 %36, 64
  br i1 %exitcond.not.i.3, label %37, label %10

37:                                               ; preds = %10
  %38 = add nuw nsw i64 %8, 1
  %exitcond5.not.i = icmp eq i64 %38, 32
  br i1 %exitcond5.not.i, label %39, label %.preheader.i

39:                                               ; preds = %37
  %40 = add nuw nsw i64 %4, 1
  %exitcond6.not.i = icmp eq i64 %40, 128
  br i1 %exitcond6.not.i, label %kernel.exit, label %.preheader2.i

kernel.exit:                                      ; preds = %39
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  br label %.preheader2.i

.preheader2.i:                                    ; preds = %46, %1
  %11 = phi i64 [ %47, %46 ], [ 0, %1 ]
  %12 = shl i64 %11, 6
  %13 = shl i64 %11, 5
  %14 = getelementptr double, ptr %10, i64 %13
  %invariant.gep7.i = getelementptr double, ptr %4, i64 %12
  br label %.preheader.i

.preheader.i:                                     ; preds = %44, %.preheader2.i
  %15 = phi i64 [ 0, %.preheader2.i ], [ %45, %44 ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %15
  %16 = getelementptr double, ptr %14, i64 %15
  %.promoted.i = load double, ptr %16, align 8
  br label %17

17:                                               ; preds = %17, %.preheader.i
  %18 = phi i64 [ 0, %.preheader.i ], [ %43, %17 ]
  %19 = phi double [ %.promoted.i, %.preheader.i ], [ %42, %17 ]
  %gep8.i = getelementptr double, ptr %invariant.gep7.i, i64 %18
  %20 = load double, ptr %gep8.i, align 8
  %21 = shl nuw nsw i64 %18, 5
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %21
  %22 = load double, ptr %gep.i, align 8
  %23 = fmul double %20, %22
  %24 = fadd double %19, %23
  store double %24, ptr %16, align 8
  %25 = or disjoint i64 %18, 1
  %gep8.i.1 = getelementptr double, ptr %invariant.gep7.i, i64 %25
  %26 = load double, ptr %gep8.i.1, align 8
  %27 = shl nuw nsw i64 %25, 5
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %27
  %28 = load double, ptr %gep.i.1, align 8
  %29 = fmul double %26, %28
  %30 = fadd double %24, %29
  store double %30, ptr %16, align 8
  %31 = or disjoint i64 %18, 2
  %gep8.i.2 = getelementptr double, ptr %invariant.gep7.i, i64 %31
  %32 = load double, ptr %gep8.i.2, align 8
  %33 = shl nuw nsw i64 %31, 5
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %33
  %34 = load double, ptr %gep.i.2, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %30, %35
  store double %36, ptr %16, align 8
  %37 = or disjoint i64 %18, 3
  %gep8.i.3 = getelementptr double, ptr %invariant.gep7.i, i64 %37
  %38 = load double, ptr %gep8.i.3, align 8
  %39 = shl nuw nsw i64 %37, 5
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %39
  %40 = load double, ptr %gep.i.3, align 8
  %41 = fmul double %38, %40
  %42 = fadd double %36, %41
  store double %42, ptr %16, align 8
  %43 = add nuw nsw i64 %18, 4
  %exitcond.not.i.3 = icmp eq i64 %43, 64
  br i1 %exitcond.not.i.3, label %44, label %17

44:                                               ; preds = %17
  %45 = add nuw nsw i64 %15, 1
  %exitcond5.not.i = icmp eq i64 %45, 32
  br i1 %exitcond5.not.i, label %46, label %.preheader.i

46:                                               ; preds = %44
  %47 = add nuw nsw i64 %11, 1
  %exitcond6.not.i = icmp eq i64 %47, 128
  br i1 %exitcond6.not.i, label %kernel.exit, label %.preheader2.i

kernel.exit:                                      ; preds = %46
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32.i, i8 0, i64 32768, i1 false)
  br label %.preheader2.i.i

.preheader2.i.i:                                  ; preds = %45, %1
  %10 = phi i64 [ %46, %45 ], [ 0, %1 ]
  %11 = shl i64 %10, 6
  %12 = shl i64 %10, 5
  %13 = getelementptr double, ptr %.unpack32.i, i64 %12
  %invariant.gep7.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %43, %.preheader2.i.i
  %14 = phi i64 [ 0, %.preheader2.i.i ], [ %44, %43 ]
  %invariant.gep.i.i = getelementptr double, ptr %.unpack17.i, i64 %14
  %15 = getelementptr double, ptr %13, i64 %14
  %.promoted.i.i = load double, ptr %15, align 8
  br label %16

16:                                               ; preds = %16, %.preheader.i.i
  %17 = phi i64 [ 0, %.preheader.i.i ], [ %42, %16 ]
  %18 = phi double [ %.promoted.i.i, %.preheader.i.i ], [ %41, %16 ]
  %gep8.i.i = getelementptr double, ptr %invariant.gep7.i.i, i64 %17
  %19 = load double, ptr %gep8.i.i, align 8
  %20 = shl nuw nsw i64 %17, 5
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %20
  %21 = load double, ptr %gep.i.i, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %18, %22
  store double %23, ptr %15, align 8
  %24 = or disjoint i64 %17, 1
  %gep8.i.i.1 = getelementptr double, ptr %invariant.gep7.i.i, i64 %24
  %25 = load double, ptr %gep8.i.i.1, align 8
  %26 = shl nuw nsw i64 %24, 5
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %26
  %27 = load double, ptr %gep.i.i.1, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %23, %28
  store double %29, ptr %15, align 8
  %30 = or disjoint i64 %17, 2
  %gep8.i.i.2 = getelementptr double, ptr %invariant.gep7.i.i, i64 %30
  %31 = load double, ptr %gep8.i.i.2, align 8
  %32 = shl nuw nsw i64 %30, 5
  %gep.i.i.2 = getelementptr double, ptr %invariant.gep.i.i, i64 %32
  %33 = load double, ptr %gep.i.i.2, align 8
  %34 = fmul double %31, %33
  %35 = fadd double %29, %34
  store double %35, ptr %15, align 8
  %36 = or disjoint i64 %17, 3
  %gep8.i.i.3 = getelementptr double, ptr %invariant.gep7.i.i, i64 %36
  %37 = load double, ptr %gep8.i.i.3, align 8
  %38 = shl nuw nsw i64 %36, 5
  %gep.i.i.3 = getelementptr double, ptr %invariant.gep.i.i, i64 %38
  %39 = load double, ptr %gep.i.i.3, align 8
  %40 = fmul double %37, %39
  %41 = fadd double %35, %40
  store double %41, ptr %15, align 8
  %42 = add nuw nsw i64 %17, 4
  %exitcond.not.i.i.3 = icmp eq i64 %42, 64
  br i1 %exitcond.not.i.i.3, label %43, label %16

43:                                               ; preds = %16
  %44 = add nuw nsw i64 %14, 1
  %exitcond5.not.i.i = icmp eq i64 %44, 32
  br i1 %exitcond5.not.i.i, label %45, label %.preheader.i.i

45:                                               ; preds = %43
  %46 = add nuw nsw i64 %10, 1
  %exitcond6.not.i.i = icmp eq i64 %46, 128
  br i1 %exitcond6.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader2.i.i

_mlir_ciface_kernel.exit:                         ; preds = %45
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
