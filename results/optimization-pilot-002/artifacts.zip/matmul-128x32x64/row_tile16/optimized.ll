; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4.preheader, %56
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %57, %56 ]
  %22 = shl i64 %21, 6
  %23 = shl i64 %21, 5
  %24 = getelementptr double, ptr %15, i64 %23
  %invariant.gep8 = getelementptr double, ptr %1, i64 %22
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %54
  %25 = phi i64 [ 0, %.preheader3 ], [ %55, %54 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %25
  %26 = getelementptr double, ptr %24, i64 %25
  %.promoted = load double, ptr %26, align 8
  br label %27

27:                                               ; preds = %27, %.preheader
  %28 = phi i64 [ 0, %.preheader ], [ %53, %27 ]
  %29 = phi double [ %.promoted, %.preheader ], [ %52, %27 ]
  %gep9 = getelementptr double, ptr %invariant.gep8, i64 %28
  %30 = load double, ptr %gep9, align 8
  %31 = shl nuw nsw i64 %28, 5
  %gep = getelementptr double, ptr %invariant.gep, i64 %31
  %32 = load double, ptr %gep, align 8
  %33 = fmul double %30, %32
  %34 = fadd double %29, %33
  store double %34, ptr %26, align 8
  %35 = or disjoint i64 %28, 1
  %gep9.1 = getelementptr double, ptr %invariant.gep8, i64 %35
  %36 = load double, ptr %gep9.1, align 8
  %37 = shl nuw nsw i64 %35, 5
  %gep.124 = getelementptr double, ptr %invariant.gep, i64 %37
  %38 = load double, ptr %gep.124, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %34, %39
  store double %40, ptr %26, align 8
  %41 = or disjoint i64 %28, 2
  %gep9.2 = getelementptr double, ptr %invariant.gep8, i64 %41
  %42 = load double, ptr %gep9.2, align 8
  %43 = shl nuw nsw i64 %41, 5
  %gep.225 = getelementptr double, ptr %invariant.gep, i64 %43
  %44 = load double, ptr %gep.225, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %40, %45
  store double %46, ptr %26, align 8
  %47 = or disjoint i64 %28, 3
  %gep9.3 = getelementptr double, ptr %invariant.gep8, i64 %47
  %48 = load double, ptr %gep9.3, align 8
  %49 = shl nuw nsw i64 %47, 5
  %gep.326 = getelementptr double, ptr %invariant.gep, i64 %49
  %50 = load double, ptr %gep.326, align 8
  %51 = fmul double %48, %50
  %52 = fadd double %46, %51
  store double %52, ptr %26, align 8
  %53 = add nuw nsw i64 %28, 4
  %exitcond.not.3 = icmp eq i64 %53, 64
  br i1 %exitcond.not.3, label %54, label %27

54:                                               ; preds = %27
  %55 = add nuw nsw i64 %25, 1
  %exitcond6.not = icmp eq i64 %55, 32
  br i1 %exitcond6.not, label %56, label %.preheader

56:                                               ; preds = %54
  %57 = add nuw nsw i64 %21, 1
  %exitcond7.not = icmp eq i64 %57, 16
  br i1 %exitcond7.not, label %.preheader4.1, label %.preheader3

.preheader4.1:                                    ; preds = %56
  %58 = getelementptr double, ptr %1, i64 1024
  %59 = getelementptr double, ptr %15, i64 512
  br label %.preheader3.1

.preheader3.1:                                    ; preds = %95, %.preheader4.1
  %60 = phi i64 [ 0, %.preheader4.1 ], [ %96, %95 ]
  %61 = shl i64 %60, 6
  %62 = shl i64 %60, 5
  %63 = getelementptr double, ptr %59, i64 %62
  %invariant.gep10 = getelementptr double, ptr %58, i64 %61
  br label %.preheader.1

.preheader.1:                                     ; preds = %93, %.preheader3.1
  %64 = phi i64 [ 0, %.preheader3.1 ], [ %94, %93 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %64
  %65 = getelementptr double, ptr %63, i64 %64
  %.promoted.1 = load double, ptr %65, align 8
  br label %66

66:                                               ; preds = %66, %.preheader.1
  %67 = phi i64 [ 0, %.preheader.1 ], [ %92, %66 ]
  %68 = phi double [ %.promoted.1, %.preheader.1 ], [ %91, %66 ]
  %gep11 = getelementptr double, ptr %invariant.gep10, i64 %67
  %69 = load double, ptr %gep11, align 8
  %70 = shl nuw nsw i64 %67, 5
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %70
  %71 = load double, ptr %gep.1, align 8
  %72 = fmul double %69, %71
  %73 = fadd double %68, %72
  store double %73, ptr %65, align 8
  %74 = or disjoint i64 %67, 1
  %gep11.1 = getelementptr double, ptr %invariant.gep10, i64 %74
  %75 = load double, ptr %gep11.1, align 8
  %76 = shl nuw nsw i64 %74, 5
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %76
  %77 = load double, ptr %gep.1.1, align 8
  %78 = fmul double %75, %77
  %79 = fadd double %73, %78
  store double %79, ptr %65, align 8
  %80 = or disjoint i64 %67, 2
  %gep11.2 = getelementptr double, ptr %invariant.gep10, i64 %80
  %81 = load double, ptr %gep11.2, align 8
  %82 = shl nuw nsw i64 %80, 5
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %82
  %83 = load double, ptr %gep.1.2, align 8
  %84 = fmul double %81, %83
  %85 = fadd double %79, %84
  store double %85, ptr %65, align 8
  %86 = or disjoint i64 %67, 3
  %gep11.3 = getelementptr double, ptr %invariant.gep10, i64 %86
  %87 = load double, ptr %gep11.3, align 8
  %88 = shl nuw nsw i64 %86, 5
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %88
  %89 = load double, ptr %gep.1.3, align 8
  %90 = fmul double %87, %89
  %91 = fadd double %85, %90
  store double %91, ptr %65, align 8
  %92 = add nuw nsw i64 %67, 4
  %exitcond.1.not.3 = icmp eq i64 %92, 64
  br i1 %exitcond.1.not.3, label %93, label %66

93:                                               ; preds = %66
  %94 = add nuw nsw i64 %64, 1
  %exitcond6.1.not = icmp eq i64 %94, 32
  br i1 %exitcond6.1.not, label %95, label %.preheader.1

95:                                               ; preds = %93
  %96 = add nuw nsw i64 %60, 1
  %exitcond7.1.not = icmp eq i64 %96, 16
  br i1 %exitcond7.1.not, label %.preheader4.2, label %.preheader3.1

.preheader4.2:                                    ; preds = %95
  %97 = getelementptr double, ptr %1, i64 2048
  %98 = getelementptr double, ptr %15, i64 1024
  br label %.preheader3.2

.preheader3.2:                                    ; preds = %134, %.preheader4.2
  %99 = phi i64 [ 0, %.preheader4.2 ], [ %135, %134 ]
  %100 = shl i64 %99, 6
  %101 = shl i64 %99, 5
  %102 = getelementptr double, ptr %98, i64 %101
  %invariant.gep12 = getelementptr double, ptr %97, i64 %100
  br label %.preheader.2

.preheader.2:                                     ; preds = %132, %.preheader3.2
  %103 = phi i64 [ 0, %.preheader3.2 ], [ %133, %132 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %103
  %104 = getelementptr double, ptr %102, i64 %103
  %.promoted.2 = load double, ptr %104, align 8
  br label %105

105:                                              ; preds = %105, %.preheader.2
  %106 = phi i64 [ 0, %.preheader.2 ], [ %131, %105 ]
  %107 = phi double [ %.promoted.2, %.preheader.2 ], [ %130, %105 ]
  %gep13 = getelementptr double, ptr %invariant.gep12, i64 %106
  %108 = load double, ptr %gep13, align 8
  %109 = shl nuw nsw i64 %106, 5
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %109
  %110 = load double, ptr %gep.2, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %107, %111
  store double %112, ptr %104, align 8
  %113 = or disjoint i64 %106, 1
  %gep13.1 = getelementptr double, ptr %invariant.gep12, i64 %113
  %114 = load double, ptr %gep13.1, align 8
  %115 = shl nuw nsw i64 %113, 5
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %115
  %116 = load double, ptr %gep.2.1, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %112, %117
  store double %118, ptr %104, align 8
  %119 = or disjoint i64 %106, 2
  %gep13.2 = getelementptr double, ptr %invariant.gep12, i64 %119
  %120 = load double, ptr %gep13.2, align 8
  %121 = shl nuw nsw i64 %119, 5
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %121
  %122 = load double, ptr %gep.2.2, align 8
  %123 = fmul double %120, %122
  %124 = fadd double %118, %123
  store double %124, ptr %104, align 8
  %125 = or disjoint i64 %106, 3
  %gep13.3 = getelementptr double, ptr %invariant.gep12, i64 %125
  %126 = load double, ptr %gep13.3, align 8
  %127 = shl nuw nsw i64 %125, 5
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %127
  %128 = load double, ptr %gep.2.3, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %124, %129
  store double %130, ptr %104, align 8
  %131 = add nuw nsw i64 %106, 4
  %exitcond.2.not.3 = icmp eq i64 %131, 64
  br i1 %exitcond.2.not.3, label %132, label %105

132:                                              ; preds = %105
  %133 = add nuw nsw i64 %103, 1
  %exitcond6.2.not = icmp eq i64 %133, 32
  br i1 %exitcond6.2.not, label %134, label %.preheader.2

134:                                              ; preds = %132
  %135 = add nuw nsw i64 %99, 1
  %exitcond7.2.not = icmp eq i64 %135, 16
  br i1 %exitcond7.2.not, label %.preheader4.3, label %.preheader3.2

.preheader4.3:                                    ; preds = %134
  %136 = getelementptr double, ptr %1, i64 3072
  %137 = getelementptr double, ptr %15, i64 1536
  br label %.preheader3.3

.preheader3.3:                                    ; preds = %173, %.preheader4.3
  %138 = phi i64 [ 0, %.preheader4.3 ], [ %174, %173 ]
  %139 = shl i64 %138, 6
  %140 = shl i64 %138, 5
  %141 = getelementptr double, ptr %137, i64 %140
  %invariant.gep14 = getelementptr double, ptr %136, i64 %139
  br label %.preheader.3

.preheader.3:                                     ; preds = %171, %.preheader3.3
  %142 = phi i64 [ 0, %.preheader3.3 ], [ %172, %171 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %142
  %143 = getelementptr double, ptr %141, i64 %142
  %.promoted.3 = load double, ptr %143, align 8
  br label %144

144:                                              ; preds = %144, %.preheader.3
  %145 = phi i64 [ 0, %.preheader.3 ], [ %170, %144 ]
  %146 = phi double [ %.promoted.3, %.preheader.3 ], [ %169, %144 ]
  %gep15 = getelementptr double, ptr %invariant.gep14, i64 %145
  %147 = load double, ptr %gep15, align 8
  %148 = shl nuw nsw i64 %145, 5
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %148
  %149 = load double, ptr %gep.3, align 8
  %150 = fmul double %147, %149
  %151 = fadd double %146, %150
  store double %151, ptr %143, align 8
  %152 = or disjoint i64 %145, 1
  %gep15.1 = getelementptr double, ptr %invariant.gep14, i64 %152
  %153 = load double, ptr %gep15.1, align 8
  %154 = shl nuw nsw i64 %152, 5
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %154
  %155 = load double, ptr %gep.3.1, align 8
  %156 = fmul double %153, %155
  %157 = fadd double %151, %156
  store double %157, ptr %143, align 8
  %158 = or disjoint i64 %145, 2
  %gep15.2 = getelementptr double, ptr %invariant.gep14, i64 %158
  %159 = load double, ptr %gep15.2, align 8
  %160 = shl nuw nsw i64 %158, 5
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %160
  %161 = load double, ptr %gep.3.2, align 8
  %162 = fmul double %159, %161
  %163 = fadd double %157, %162
  store double %163, ptr %143, align 8
  %164 = or disjoint i64 %145, 3
  %gep15.3 = getelementptr double, ptr %invariant.gep14, i64 %164
  %165 = load double, ptr %gep15.3, align 8
  %166 = shl nuw nsw i64 %164, 5
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %166
  %167 = load double, ptr %gep.3.3, align 8
  %168 = fmul double %165, %167
  %169 = fadd double %163, %168
  store double %169, ptr %143, align 8
  %170 = add nuw nsw i64 %145, 4
  %exitcond.3.not.3 = icmp eq i64 %170, 64
  br i1 %exitcond.3.not.3, label %171, label %144

171:                                              ; preds = %144
  %172 = add nuw nsw i64 %142, 1
  %exitcond6.3.not = icmp eq i64 %172, 32
  br i1 %exitcond6.3.not, label %173, label %.preheader.3

173:                                              ; preds = %171
  %174 = add nuw nsw i64 %138, 1
  %exitcond7.3.not = icmp eq i64 %174, 16
  br i1 %exitcond7.3.not, label %.preheader4.4, label %.preheader3.3

.preheader4.4:                                    ; preds = %173
  %175 = getelementptr double, ptr %1, i64 4096
  %176 = getelementptr double, ptr %15, i64 2048
  br label %.preheader3.4

.preheader3.4:                                    ; preds = %212, %.preheader4.4
  %177 = phi i64 [ 0, %.preheader4.4 ], [ %213, %212 ]
  %178 = shl i64 %177, 6
  %179 = shl i64 %177, 5
  %180 = getelementptr double, ptr %176, i64 %179
  %invariant.gep16 = getelementptr double, ptr %175, i64 %178
  br label %.preheader.4

.preheader.4:                                     ; preds = %210, %.preheader3.4
  %181 = phi i64 [ 0, %.preheader3.4 ], [ %211, %210 ]
  %invariant.gep.4 = getelementptr double, ptr %8, i64 %181
  %182 = getelementptr double, ptr %180, i64 %181
  %.promoted.4 = load double, ptr %182, align 8
  br label %183

183:                                              ; preds = %183, %.preheader.4
  %184 = phi i64 [ 0, %.preheader.4 ], [ %209, %183 ]
  %185 = phi double [ %.promoted.4, %.preheader.4 ], [ %208, %183 ]
  %gep17 = getelementptr double, ptr %invariant.gep16, i64 %184
  %186 = load double, ptr %gep17, align 8
  %187 = shl nuw nsw i64 %184, 5
  %gep.4 = getelementptr double, ptr %invariant.gep.4, i64 %187
  %188 = load double, ptr %gep.4, align 8
  %189 = fmul double %186, %188
  %190 = fadd double %185, %189
  store double %190, ptr %182, align 8
  %191 = or disjoint i64 %184, 1
  %gep17.1 = getelementptr double, ptr %invariant.gep16, i64 %191
  %192 = load double, ptr %gep17.1, align 8
  %193 = shl nuw nsw i64 %191, 5
  %gep.4.1 = getelementptr double, ptr %invariant.gep.4, i64 %193
  %194 = load double, ptr %gep.4.1, align 8
  %195 = fmul double %192, %194
  %196 = fadd double %190, %195
  store double %196, ptr %182, align 8
  %197 = or disjoint i64 %184, 2
  %gep17.2 = getelementptr double, ptr %invariant.gep16, i64 %197
  %198 = load double, ptr %gep17.2, align 8
  %199 = shl nuw nsw i64 %197, 5
  %gep.4.2 = getelementptr double, ptr %invariant.gep.4, i64 %199
  %200 = load double, ptr %gep.4.2, align 8
  %201 = fmul double %198, %200
  %202 = fadd double %196, %201
  store double %202, ptr %182, align 8
  %203 = or disjoint i64 %184, 3
  %gep17.3 = getelementptr double, ptr %invariant.gep16, i64 %203
  %204 = load double, ptr %gep17.3, align 8
  %205 = shl nuw nsw i64 %203, 5
  %gep.4.3 = getelementptr double, ptr %invariant.gep.4, i64 %205
  %206 = load double, ptr %gep.4.3, align 8
  %207 = fmul double %204, %206
  %208 = fadd double %202, %207
  store double %208, ptr %182, align 8
  %209 = add nuw nsw i64 %184, 4
  %exitcond.4.not.3 = icmp eq i64 %209, 64
  br i1 %exitcond.4.not.3, label %210, label %183

210:                                              ; preds = %183
  %211 = add nuw nsw i64 %181, 1
  %exitcond6.4.not = icmp eq i64 %211, 32
  br i1 %exitcond6.4.not, label %212, label %.preheader.4

212:                                              ; preds = %210
  %213 = add nuw nsw i64 %177, 1
  %exitcond7.4.not = icmp eq i64 %213, 16
  br i1 %exitcond7.4.not, label %.preheader4.5, label %.preheader3.4

.preheader4.5:                                    ; preds = %212
  %214 = getelementptr double, ptr %1, i64 5120
  %215 = getelementptr double, ptr %15, i64 2560
  br label %.preheader3.5

.preheader3.5:                                    ; preds = %251, %.preheader4.5
  %216 = phi i64 [ 0, %.preheader4.5 ], [ %252, %251 ]
  %217 = shl i64 %216, 6
  %218 = shl i64 %216, 5
  %219 = getelementptr double, ptr %215, i64 %218
  %invariant.gep18 = getelementptr double, ptr %214, i64 %217
  br label %.preheader.5

.preheader.5:                                     ; preds = %249, %.preheader3.5
  %220 = phi i64 [ 0, %.preheader3.5 ], [ %250, %249 ]
  %invariant.gep.5 = getelementptr double, ptr %8, i64 %220
  %221 = getelementptr double, ptr %219, i64 %220
  %.promoted.5 = load double, ptr %221, align 8
  br label %222

222:                                              ; preds = %222, %.preheader.5
  %223 = phi i64 [ 0, %.preheader.5 ], [ %248, %222 ]
  %224 = phi double [ %.promoted.5, %.preheader.5 ], [ %247, %222 ]
  %gep19 = getelementptr double, ptr %invariant.gep18, i64 %223
  %225 = load double, ptr %gep19, align 8
  %226 = shl nuw nsw i64 %223, 5
  %gep.5 = getelementptr double, ptr %invariant.gep.5, i64 %226
  %227 = load double, ptr %gep.5, align 8
  %228 = fmul double %225, %227
  %229 = fadd double %224, %228
  store double %229, ptr %221, align 8
  %230 = or disjoint i64 %223, 1
  %gep19.1 = getelementptr double, ptr %invariant.gep18, i64 %230
  %231 = load double, ptr %gep19.1, align 8
  %232 = shl nuw nsw i64 %230, 5
  %gep.5.1 = getelementptr double, ptr %invariant.gep.5, i64 %232
  %233 = load double, ptr %gep.5.1, align 8
  %234 = fmul double %231, %233
  %235 = fadd double %229, %234
  store double %235, ptr %221, align 8
  %236 = or disjoint i64 %223, 2
  %gep19.2 = getelementptr double, ptr %invariant.gep18, i64 %236
  %237 = load double, ptr %gep19.2, align 8
  %238 = shl nuw nsw i64 %236, 5
  %gep.5.2 = getelementptr double, ptr %invariant.gep.5, i64 %238
  %239 = load double, ptr %gep.5.2, align 8
  %240 = fmul double %237, %239
  %241 = fadd double %235, %240
  store double %241, ptr %221, align 8
  %242 = or disjoint i64 %223, 3
  %gep19.3 = getelementptr double, ptr %invariant.gep18, i64 %242
  %243 = load double, ptr %gep19.3, align 8
  %244 = shl nuw nsw i64 %242, 5
  %gep.5.3 = getelementptr double, ptr %invariant.gep.5, i64 %244
  %245 = load double, ptr %gep.5.3, align 8
  %246 = fmul double %243, %245
  %247 = fadd double %241, %246
  store double %247, ptr %221, align 8
  %248 = add nuw nsw i64 %223, 4
  %exitcond.5.not.3 = icmp eq i64 %248, 64
  br i1 %exitcond.5.not.3, label %249, label %222

249:                                              ; preds = %222
  %250 = add nuw nsw i64 %220, 1
  %exitcond6.5.not = icmp eq i64 %250, 32
  br i1 %exitcond6.5.not, label %251, label %.preheader.5

251:                                              ; preds = %249
  %252 = add nuw nsw i64 %216, 1
  %exitcond7.5.not = icmp eq i64 %252, 16
  br i1 %exitcond7.5.not, label %.preheader4.6, label %.preheader3.5

.preheader4.6:                                    ; preds = %251
  %253 = getelementptr double, ptr %1, i64 6144
  %254 = getelementptr double, ptr %15, i64 3072
  br label %.preheader3.6

.preheader3.6:                                    ; preds = %290, %.preheader4.6
  %255 = phi i64 [ 0, %.preheader4.6 ], [ %291, %290 ]
  %256 = shl i64 %255, 6
  %257 = shl i64 %255, 5
  %258 = getelementptr double, ptr %254, i64 %257
  %invariant.gep20 = getelementptr double, ptr %253, i64 %256
  br label %.preheader.6

.preheader.6:                                     ; preds = %288, %.preheader3.6
  %259 = phi i64 [ 0, %.preheader3.6 ], [ %289, %288 ]
  %invariant.gep.6 = getelementptr double, ptr %8, i64 %259
  %260 = getelementptr double, ptr %258, i64 %259
  %.promoted.6 = load double, ptr %260, align 8
  br label %261

261:                                              ; preds = %261, %.preheader.6
  %262 = phi i64 [ 0, %.preheader.6 ], [ %287, %261 ]
  %263 = phi double [ %.promoted.6, %.preheader.6 ], [ %286, %261 ]
  %gep21 = getelementptr double, ptr %invariant.gep20, i64 %262
  %264 = load double, ptr %gep21, align 8
  %265 = shl nuw nsw i64 %262, 5
  %gep.6 = getelementptr double, ptr %invariant.gep.6, i64 %265
  %266 = load double, ptr %gep.6, align 8
  %267 = fmul double %264, %266
  %268 = fadd double %263, %267
  store double %268, ptr %260, align 8
  %269 = or disjoint i64 %262, 1
  %gep21.1 = getelementptr double, ptr %invariant.gep20, i64 %269
  %270 = load double, ptr %gep21.1, align 8
  %271 = shl nuw nsw i64 %269, 5
  %gep.6.1 = getelementptr double, ptr %invariant.gep.6, i64 %271
  %272 = load double, ptr %gep.6.1, align 8
  %273 = fmul double %270, %272
  %274 = fadd double %268, %273
  store double %274, ptr %260, align 8
  %275 = or disjoint i64 %262, 2
  %gep21.2 = getelementptr double, ptr %invariant.gep20, i64 %275
  %276 = load double, ptr %gep21.2, align 8
  %277 = shl nuw nsw i64 %275, 5
  %gep.6.2 = getelementptr double, ptr %invariant.gep.6, i64 %277
  %278 = load double, ptr %gep.6.2, align 8
  %279 = fmul double %276, %278
  %280 = fadd double %274, %279
  store double %280, ptr %260, align 8
  %281 = or disjoint i64 %262, 3
  %gep21.3 = getelementptr double, ptr %invariant.gep20, i64 %281
  %282 = load double, ptr %gep21.3, align 8
  %283 = shl nuw nsw i64 %281, 5
  %gep.6.3 = getelementptr double, ptr %invariant.gep.6, i64 %283
  %284 = load double, ptr %gep.6.3, align 8
  %285 = fmul double %282, %284
  %286 = fadd double %280, %285
  store double %286, ptr %260, align 8
  %287 = add nuw nsw i64 %262, 4
  %exitcond.6.not.3 = icmp eq i64 %287, 64
  br i1 %exitcond.6.not.3, label %288, label %261

288:                                              ; preds = %261
  %289 = add nuw nsw i64 %259, 1
  %exitcond6.6.not = icmp eq i64 %289, 32
  br i1 %exitcond6.6.not, label %290, label %.preheader.6

290:                                              ; preds = %288
  %291 = add nuw nsw i64 %255, 1
  %exitcond7.6.not = icmp eq i64 %291, 16
  br i1 %exitcond7.6.not, label %.preheader4.7, label %.preheader3.6

.preheader4.7:                                    ; preds = %290
  %292 = getelementptr double, ptr %1, i64 7168
  %293 = getelementptr double, ptr %15, i64 3584
  br label %.preheader3.7

.preheader3.7:                                    ; preds = %329, %.preheader4.7
  %294 = phi i64 [ 0, %.preheader4.7 ], [ %330, %329 ]
  %295 = shl i64 %294, 6
  %296 = shl i64 %294, 5
  %297 = getelementptr double, ptr %293, i64 %296
  %invariant.gep22 = getelementptr double, ptr %292, i64 %295
  br label %.preheader.7

.preheader.7:                                     ; preds = %327, %.preheader3.7
  %298 = phi i64 [ 0, %.preheader3.7 ], [ %328, %327 ]
  %invariant.gep.7 = getelementptr double, ptr %8, i64 %298
  %299 = getelementptr double, ptr %297, i64 %298
  %.promoted.7 = load double, ptr %299, align 8
  br label %300

300:                                              ; preds = %300, %.preheader.7
  %301 = phi i64 [ 0, %.preheader.7 ], [ %326, %300 ]
  %302 = phi double [ %.promoted.7, %.preheader.7 ], [ %325, %300 ]
  %gep23 = getelementptr double, ptr %invariant.gep22, i64 %301
  %303 = load double, ptr %gep23, align 8
  %304 = shl nuw nsw i64 %301, 5
  %gep.7 = getelementptr double, ptr %invariant.gep.7, i64 %304
  %305 = load double, ptr %gep.7, align 8
  %306 = fmul double %303, %305
  %307 = fadd double %302, %306
  store double %307, ptr %299, align 8
  %308 = or disjoint i64 %301, 1
  %gep23.1 = getelementptr double, ptr %invariant.gep22, i64 %308
  %309 = load double, ptr %gep23.1, align 8
  %310 = shl nuw nsw i64 %308, 5
  %gep.7.1 = getelementptr double, ptr %invariant.gep.7, i64 %310
  %311 = load double, ptr %gep.7.1, align 8
  %312 = fmul double %309, %311
  %313 = fadd double %307, %312
  store double %313, ptr %299, align 8
  %314 = or disjoint i64 %301, 2
  %gep23.2 = getelementptr double, ptr %invariant.gep22, i64 %314
  %315 = load double, ptr %gep23.2, align 8
  %316 = shl nuw nsw i64 %314, 5
  %gep.7.2 = getelementptr double, ptr %invariant.gep.7, i64 %316
  %317 = load double, ptr %gep.7.2, align 8
  %318 = fmul double %315, %317
  %319 = fadd double %313, %318
  store double %319, ptr %299, align 8
  %320 = or disjoint i64 %301, 3
  %gep23.3 = getelementptr double, ptr %invariant.gep22, i64 %320
  %321 = load double, ptr %gep23.3, align 8
  %322 = shl nuw nsw i64 %320, 5
  %gep.7.3 = getelementptr double, ptr %invariant.gep.7, i64 %322
  %323 = load double, ptr %gep.7.3, align 8
  %324 = fmul double %321, %323
  %325 = fadd double %319, %324
  store double %325, ptr %299, align 8
  %326 = add nuw nsw i64 %301, 4
  %exitcond.7.not.3 = icmp eq i64 %326, 64
  br i1 %exitcond.7.not.3, label %327, label %300

327:                                              ; preds = %300
  %328 = add nuw nsw i64 %298, 1
  %exitcond6.7.not = icmp eq i64 %328, 32
  br i1 %exitcond6.7.not, label %329, label %.preheader.7

329:                                              ; preds = %327
  %330 = add nuw nsw i64 %294, 1
  %exitcond7.7.not = icmp eq i64 %330, 16
  br i1 %exitcond7.7.not, label %331, label %.preheader3.7

331:                                              ; preds = %329
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
