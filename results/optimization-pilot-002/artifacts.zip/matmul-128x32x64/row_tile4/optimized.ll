; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %157
  %21 = phi i64 [ %158, %157 ], [ 0, %.preheader4.preheader ]
  %22 = shl nuw nsw i64 %21, 6
  %23 = shl nuw nsw i64 %21, 5
  %24 = getelementptr double, ptr %1, i64 %22
  %25 = getelementptr double, ptr %15, i64 %23
  br label %.preheader

.preheader:                                       ; preds = %.preheader4, %59
  %26 = phi i64 [ 0, %.preheader4 ], [ %60, %59 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %26
  %27 = getelementptr double, ptr %25, i64 %26
  %.promoted = load double, ptr %27, align 8
  br label %28

28:                                               ; preds = %28, %.preheader
  %29 = phi i64 [ 0, %.preheader ], [ %58, %28 ]
  %30 = phi double [ %.promoted, %.preheader ], [ %57, %28 ]
  %31 = getelementptr double, ptr %24, i64 %29
  %32 = load double, ptr %31, align 8
  %33 = shl nuw nsw i64 %29, 5
  %gep = getelementptr double, ptr %invariant.gep, i64 %33
  %34 = load double, ptr %gep, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %30, %35
  store double %36, ptr %27, align 8
  %37 = or disjoint i64 %29, 1
  %38 = getelementptr double, ptr %24, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = shl nuw nsw i64 %37, 5
  %gep.114 = getelementptr double, ptr %invariant.gep, i64 %40
  %41 = load double, ptr %gep.114, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %27, align 8
  %44 = or disjoint i64 %29, 2
  %45 = getelementptr double, ptr %24, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = shl nuw nsw i64 %44, 5
  %gep.215 = getelementptr double, ptr %invariant.gep, i64 %47
  %48 = load double, ptr %gep.215, align 8
  %49 = fmul double %46, %48
  %50 = fadd double %43, %49
  store double %50, ptr %27, align 8
  %51 = or disjoint i64 %29, 3
  %52 = getelementptr double, ptr %24, i64 %51
  %53 = load double, ptr %52, align 8
  %54 = shl nuw nsw i64 %51, 5
  %gep.316 = getelementptr double, ptr %invariant.gep, i64 %54
  %55 = load double, ptr %gep.316, align 8
  %56 = fmul double %53, %55
  %57 = fadd double %50, %56
  store double %57, ptr %27, align 8
  %58 = add nuw nsw i64 %29, 4
  %exitcond.not.3 = icmp eq i64 %58, 64
  br i1 %exitcond.not.3, label %59, label %28

59:                                               ; preds = %28
  %60 = add nuw nsw i64 %26, 1
  %exitcond6.not = icmp eq i64 %60, 32
  br i1 %exitcond6.not, label %.preheader3.1, label %.preheader

.preheader3.1:                                    ; preds = %59
  %61 = getelementptr double, ptr %25, i64 32
  %invariant.gep12 = getelementptr double, ptr %24, i64 64
  br label %.preheader.1

.preheader.1:                                     ; preds = %91, %.preheader3.1
  %62 = phi i64 [ 0, %.preheader3.1 ], [ %92, %91 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %62
  %63 = getelementptr double, ptr %61, i64 %62
  %.promoted.1 = load double, ptr %63, align 8
  br label %64

64:                                               ; preds = %64, %.preheader.1
  %65 = phi i64 [ 0, %.preheader.1 ], [ %90, %64 ]
  %66 = phi double [ %.promoted.1, %.preheader.1 ], [ %89, %64 ]
  %gep13 = getelementptr double, ptr %invariant.gep12, i64 %65
  %67 = load double, ptr %gep13, align 8
  %68 = shl nuw nsw i64 %65, 5
  %gep.1 = getelementptr double, ptr %invariant.gep.1, i64 %68
  %69 = load double, ptr %gep.1, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %66, %70
  store double %71, ptr %63, align 8
  %72 = or disjoint i64 %65, 1
  %gep13.1 = getelementptr double, ptr %invariant.gep12, i64 %72
  %73 = load double, ptr %gep13.1, align 8
  %74 = shl nuw nsw i64 %72, 5
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 %74
  %75 = load double, ptr %gep.1.1, align 8
  %76 = fmul double %73, %75
  %77 = fadd double %71, %76
  store double %77, ptr %63, align 8
  %78 = or disjoint i64 %65, 2
  %gep13.2 = getelementptr double, ptr %invariant.gep12, i64 %78
  %79 = load double, ptr %gep13.2, align 8
  %80 = shl nuw nsw i64 %78, 5
  %gep.1.2 = getelementptr double, ptr %invariant.gep.1, i64 %80
  %81 = load double, ptr %gep.1.2, align 8
  %82 = fmul double %79, %81
  %83 = fadd double %77, %82
  store double %83, ptr %63, align 8
  %84 = or disjoint i64 %65, 3
  %gep13.3 = getelementptr double, ptr %invariant.gep12, i64 %84
  %85 = load double, ptr %gep13.3, align 8
  %86 = shl nuw nsw i64 %84, 5
  %gep.1.3 = getelementptr double, ptr %invariant.gep.1, i64 %86
  %87 = load double, ptr %gep.1.3, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %83, %88
  store double %89, ptr %63, align 8
  %90 = add nuw nsw i64 %65, 4
  %exitcond.1.not.3 = icmp eq i64 %90, 64
  br i1 %exitcond.1.not.3, label %91, label %64

91:                                               ; preds = %64
  %92 = add nuw nsw i64 %62, 1
  %exitcond6.1.not = icmp eq i64 %92, 32
  br i1 %exitcond6.1.not, label %.preheader3.2, label %.preheader.1

.preheader3.2:                                    ; preds = %91
  %93 = getelementptr double, ptr %25, i64 64
  %invariant.gep10 = getelementptr double, ptr %24, i64 128
  br label %.preheader.2

.preheader.2:                                     ; preds = %123, %.preheader3.2
  %94 = phi i64 [ 0, %.preheader3.2 ], [ %124, %123 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %94
  %95 = getelementptr double, ptr %93, i64 %94
  %.promoted.2 = load double, ptr %95, align 8
  br label %96

96:                                               ; preds = %96, %.preheader.2
  %97 = phi i64 [ 0, %.preheader.2 ], [ %122, %96 ]
  %98 = phi double [ %.promoted.2, %.preheader.2 ], [ %121, %96 ]
  %gep11 = getelementptr double, ptr %invariant.gep10, i64 %97
  %99 = load double, ptr %gep11, align 8
  %100 = shl nuw nsw i64 %97, 5
  %gep.2 = getelementptr double, ptr %invariant.gep.2, i64 %100
  %101 = load double, ptr %gep.2, align 8
  %102 = fmul double %99, %101
  %103 = fadd double %98, %102
  store double %103, ptr %95, align 8
  %104 = or disjoint i64 %97, 1
  %gep11.1 = getelementptr double, ptr %invariant.gep10, i64 %104
  %105 = load double, ptr %gep11.1, align 8
  %106 = shl nuw nsw i64 %104, 5
  %gep.2.1 = getelementptr double, ptr %invariant.gep.2, i64 %106
  %107 = load double, ptr %gep.2.1, align 8
  %108 = fmul double %105, %107
  %109 = fadd double %103, %108
  store double %109, ptr %95, align 8
  %110 = or disjoint i64 %97, 2
  %gep11.2 = getelementptr double, ptr %invariant.gep10, i64 %110
  %111 = load double, ptr %gep11.2, align 8
  %112 = shl nuw nsw i64 %110, 5
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 %112
  %113 = load double, ptr %gep.2.2, align 8
  %114 = fmul double %111, %113
  %115 = fadd double %109, %114
  store double %115, ptr %95, align 8
  %116 = or disjoint i64 %97, 3
  %gep11.3 = getelementptr double, ptr %invariant.gep10, i64 %116
  %117 = load double, ptr %gep11.3, align 8
  %118 = shl nuw nsw i64 %116, 5
  %gep.2.3 = getelementptr double, ptr %invariant.gep.2, i64 %118
  %119 = load double, ptr %gep.2.3, align 8
  %120 = fmul double %117, %119
  %121 = fadd double %115, %120
  store double %121, ptr %95, align 8
  %122 = add nuw nsw i64 %97, 4
  %exitcond.2.not.3 = icmp eq i64 %122, 64
  br i1 %exitcond.2.not.3, label %123, label %96

123:                                              ; preds = %96
  %124 = add nuw nsw i64 %94, 1
  %exitcond6.2.not = icmp eq i64 %124, 32
  br i1 %exitcond6.2.not, label %.preheader3.3, label %.preheader.2

.preheader3.3:                                    ; preds = %123
  %125 = getelementptr double, ptr %25, i64 96
  %invariant.gep8 = getelementptr double, ptr %24, i64 192
  br label %.preheader.3

.preheader.3:                                     ; preds = %155, %.preheader3.3
  %126 = phi i64 [ 0, %.preheader3.3 ], [ %156, %155 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %126
  %127 = getelementptr double, ptr %125, i64 %126
  %.promoted.3 = load double, ptr %127, align 8
  br label %128

128:                                              ; preds = %128, %.preheader.3
  %129 = phi i64 [ 0, %.preheader.3 ], [ %154, %128 ]
  %130 = phi double [ %.promoted.3, %.preheader.3 ], [ %153, %128 ]
  %gep9 = getelementptr double, ptr %invariant.gep8, i64 %129
  %131 = load double, ptr %gep9, align 8
  %132 = shl nuw nsw i64 %129, 5
  %gep.3 = getelementptr double, ptr %invariant.gep.3, i64 %132
  %133 = load double, ptr %gep.3, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %130, %134
  store double %135, ptr %127, align 8
  %136 = or disjoint i64 %129, 1
  %gep9.1 = getelementptr double, ptr %invariant.gep8, i64 %136
  %137 = load double, ptr %gep9.1, align 8
  %138 = shl nuw nsw i64 %136, 5
  %gep.3.1 = getelementptr double, ptr %invariant.gep.3, i64 %138
  %139 = load double, ptr %gep.3.1, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %135, %140
  store double %141, ptr %127, align 8
  %142 = or disjoint i64 %129, 2
  %gep9.2 = getelementptr double, ptr %invariant.gep8, i64 %142
  %143 = load double, ptr %gep9.2, align 8
  %144 = shl nuw nsw i64 %142, 5
  %gep.3.2 = getelementptr double, ptr %invariant.gep.3, i64 %144
  %145 = load double, ptr %gep.3.2, align 8
  %146 = fmul double %143, %145
  %147 = fadd double %141, %146
  store double %147, ptr %127, align 8
  %148 = or disjoint i64 %129, 3
  %gep9.3 = getelementptr double, ptr %invariant.gep8, i64 %148
  %149 = load double, ptr %gep9.3, align 8
  %150 = shl nuw nsw i64 %148, 5
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 %150
  %151 = load double, ptr %gep.3.3, align 8
  %152 = fmul double %149, %151
  %153 = fadd double %147, %152
  store double %153, ptr %127, align 8
  %154 = add nuw nsw i64 %129, 4
  %exitcond.3.not.3 = icmp eq i64 %154, 64
  br i1 %exitcond.3.not.3, label %155, label %128

155:                                              ; preds = %128
  %156 = add nuw nsw i64 %126, 1
  %exitcond6.3.not = icmp eq i64 %156, 32
  br i1 %exitcond6.3.not, label %157, label %.preheader.3

157:                                              ; preds = %155
  %158 = add nuw nsw i64 %21, 4
  %159 = icmp ult i64 %21, 124
  br i1 %159, label %.preheader4, label %160

160:                                              ; preds = %157
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %.unpack32, i8 0, i64 32768, i1 false)
  br label %.preheader4.i

.preheader4.i:                                    ; preds = %140, %3
  %4 = phi i64 [ %141, %140 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 6
  %6 = shl nuw nsw i64 %4, 5
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = getelementptr double, ptr %.unpack32, i64 %6
  br label %.preheader.i

.preheader.i:                                     ; preds = %42, %.preheader4.i
  %9 = phi i64 [ 0, %.preheader4.i ], [ %43, %42 ]
  %invariant.gep.i = getelementptr double, ptr %.unpack17, i64 %9
  %10 = getelementptr double, ptr %8, i64 %9
  %.promoted.i = load double, ptr %10, align 8
  br label %11

11:                                               ; preds = %11, %.preheader.i
  %12 = phi i64 [ 0, %.preheader.i ], [ %41, %11 ]
  %13 = phi double [ %.promoted.i, %.preheader.i ], [ %40, %11 ]
  %14 = getelementptr double, ptr %7, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = shl nuw nsw i64 %12, 5
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %16
  %17 = load double, ptr %gep.i, align 8
  %18 = fmul double %15, %17
  %19 = fadd double %13, %18
  store double %19, ptr %10, align 8
  %20 = or disjoint i64 %12, 1
  %21 = getelementptr double, ptr %7, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = shl nuw nsw i64 %20, 5
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %23
  %24 = load double, ptr %gep.i.1, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %19, %25
  store double %26, ptr %10, align 8
  %27 = or disjoint i64 %12, 2
  %28 = getelementptr double, ptr %7, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = shl nuw nsw i64 %27, 5
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %30
  %31 = load double, ptr %gep.i.2, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %10, align 8
  %34 = or disjoint i64 %12, 3
  %35 = getelementptr double, ptr %7, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = shl nuw nsw i64 %34, 5
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %37
  %38 = load double, ptr %gep.i.3, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %10, align 8
  %41 = add nuw nsw i64 %12, 4
  %exitcond.not.i.3 = icmp eq i64 %41, 64
  br i1 %exitcond.not.i.3, label %42, label %11

42:                                               ; preds = %11
  %43 = add nuw nsw i64 %9, 1
  %exitcond6.not.i = icmp eq i64 %43, 32
  br i1 %exitcond6.not.i, label %.preheader3.1.i, label %.preheader.i

.preheader3.1.i:                                  ; preds = %42
  %44 = getelementptr double, ptr %8, i64 32
  %invariant.gep12.i = getelementptr double, ptr %7, i64 64
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %74, %.preheader3.1.i
  %45 = phi i64 [ 0, %.preheader3.1.i ], [ %75, %74 ]
  %invariant.gep.1.i = getelementptr double, ptr %.unpack17, i64 %45
  %46 = getelementptr double, ptr %44, i64 %45
  %.promoted.1.i = load double, ptr %46, align 8
  br label %47

47:                                               ; preds = %47, %.preheader.1.i
  %48 = phi i64 [ 0, %.preheader.1.i ], [ %73, %47 ]
  %49 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %72, %47 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %48
  %50 = load double, ptr %gep13.i, align 8
  %51 = shl nuw nsw i64 %48, 5
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %51
  %52 = load double, ptr %gep.1.i, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %49, %53
  store double %54, ptr %46, align 8
  %55 = or disjoint i64 %48, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %55
  %56 = load double, ptr %gep13.i.1, align 8
  %57 = shl nuw nsw i64 %55, 5
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %57
  %58 = load double, ptr %gep.1.i.1, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %54, %59
  store double %60, ptr %46, align 8
  %61 = or disjoint i64 %48, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %61
  %62 = load double, ptr %gep13.i.2, align 8
  %63 = shl nuw nsw i64 %61, 5
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %63
  %64 = load double, ptr %gep.1.i.2, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %60, %65
  store double %66, ptr %46, align 8
  %67 = or disjoint i64 %48, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %67
  %68 = load double, ptr %gep13.i.3, align 8
  %69 = shl nuw nsw i64 %67, 5
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %69
  %70 = load double, ptr %gep.1.i.3, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %46, align 8
  %73 = add nuw nsw i64 %48, 4
  %exitcond.1.not.i.3 = icmp eq i64 %73, 64
  br i1 %exitcond.1.not.i.3, label %74, label %47

74:                                               ; preds = %47
  %75 = add nuw nsw i64 %45, 1
  %exitcond6.1.not.i = icmp eq i64 %75, 32
  br i1 %exitcond6.1.not.i, label %.preheader3.2.i, label %.preheader.1.i

.preheader3.2.i:                                  ; preds = %74
  %76 = getelementptr double, ptr %8, i64 64
  %invariant.gep10.i = getelementptr double, ptr %7, i64 128
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %106, %.preheader3.2.i
  %77 = phi i64 [ 0, %.preheader3.2.i ], [ %107, %106 ]
  %invariant.gep.2.i = getelementptr double, ptr %.unpack17, i64 %77
  %78 = getelementptr double, ptr %76, i64 %77
  %.promoted.2.i = load double, ptr %78, align 8
  br label %79

79:                                               ; preds = %79, %.preheader.2.i
  %80 = phi i64 [ 0, %.preheader.2.i ], [ %105, %79 ]
  %81 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %104, %79 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %80
  %82 = load double, ptr %gep11.i, align 8
  %83 = shl nuw nsw i64 %80, 5
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %83
  %84 = load double, ptr %gep.2.i, align 8
  %85 = fmul double %82, %84
  %86 = fadd double %81, %85
  store double %86, ptr %78, align 8
  %87 = or disjoint i64 %80, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %87
  %88 = load double, ptr %gep11.i.1, align 8
  %89 = shl nuw nsw i64 %87, 5
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %89
  %90 = load double, ptr %gep.2.i.1, align 8
  %91 = fmul double %88, %90
  %92 = fadd double %86, %91
  store double %92, ptr %78, align 8
  %93 = or disjoint i64 %80, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %93
  %94 = load double, ptr %gep11.i.2, align 8
  %95 = shl nuw nsw i64 %93, 5
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %95
  %96 = load double, ptr %gep.2.i.2, align 8
  %97 = fmul double %94, %96
  %98 = fadd double %92, %97
  store double %98, ptr %78, align 8
  %99 = or disjoint i64 %80, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %99
  %100 = load double, ptr %gep11.i.3, align 8
  %101 = shl nuw nsw i64 %99, 5
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %101
  %102 = load double, ptr %gep.2.i.3, align 8
  %103 = fmul double %100, %102
  %104 = fadd double %98, %103
  store double %104, ptr %78, align 8
  %105 = add nuw nsw i64 %80, 4
  %exitcond.2.not.i.3 = icmp eq i64 %105, 64
  br i1 %exitcond.2.not.i.3, label %106, label %79

106:                                              ; preds = %79
  %107 = add nuw nsw i64 %77, 1
  %exitcond6.2.not.i = icmp eq i64 %107, 32
  br i1 %exitcond6.2.not.i, label %.preheader3.3.i, label %.preheader.2.i

.preheader3.3.i:                                  ; preds = %106
  %108 = getelementptr double, ptr %8, i64 96
  %invariant.gep8.i = getelementptr double, ptr %7, i64 192
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %138, %.preheader3.3.i
  %109 = phi i64 [ 0, %.preheader3.3.i ], [ %139, %138 ]
  %invariant.gep.3.i = getelementptr double, ptr %.unpack17, i64 %109
  %110 = getelementptr double, ptr %108, i64 %109
  %.promoted.3.i = load double, ptr %110, align 8
  br label %111

111:                                              ; preds = %111, %.preheader.3.i
  %112 = phi i64 [ 0, %.preheader.3.i ], [ %137, %111 ]
  %113 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %136, %111 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %112
  %114 = load double, ptr %gep9.i, align 8
  %115 = shl nuw nsw i64 %112, 5
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %115
  %116 = load double, ptr %gep.3.i, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %113, %117
  store double %118, ptr %110, align 8
  %119 = or disjoint i64 %112, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %119
  %120 = load double, ptr %gep9.i.1, align 8
  %121 = shl nuw nsw i64 %119, 5
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %121
  %122 = load double, ptr %gep.3.i.1, align 8
  %123 = fmul double %120, %122
  %124 = fadd double %118, %123
  store double %124, ptr %110, align 8
  %125 = or disjoint i64 %112, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %125
  %126 = load double, ptr %gep9.i.2, align 8
  %127 = shl nuw nsw i64 %125, 5
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %127
  %128 = load double, ptr %gep.3.i.2, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %124, %129
  store double %130, ptr %110, align 8
  %131 = or disjoint i64 %112, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %131
  %132 = load double, ptr %gep9.i.3, align 8
  %133 = shl nuw nsw i64 %131, 5
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %133
  %134 = load double, ptr %gep.3.i.3, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %110, align 8
  %137 = add nuw nsw i64 %112, 4
  %exitcond.3.not.i.3 = icmp eq i64 %137, 64
  br i1 %exitcond.3.not.i.3, label %138, label %111

138:                                              ; preds = %111
  %139 = add nuw nsw i64 %109, 1
  %exitcond6.3.not.i = icmp eq i64 %139, 32
  br i1 %exitcond6.3.not.i, label %140, label %.preheader.3.i

140:                                              ; preds = %138
  %141 = add nuw nsw i64 %4, 4
  %142 = icmp ult i64 %4, 124
  br i1 %142, label %.preheader4.i, label %kernel.exit

kernel.exit:                                      ; preds = %140
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %10, i8 0, i64 32768, i1 false)
  br label %.preheader4.i

.preheader4.i:                                    ; preds = %147, %1
  %11 = phi i64 [ %148, %147 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 6
  %13 = shl nuw nsw i64 %11, 5
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = getelementptr double, ptr %10, i64 %13
  br label %.preheader.i

.preheader.i:                                     ; preds = %49, %.preheader4.i
  %16 = phi i64 [ 0, %.preheader4.i ], [ %50, %49 ]
  %invariant.gep.i = getelementptr double, ptr %7, i64 %16
  %17 = getelementptr double, ptr %15, i64 %16
  %.promoted.i = load double, ptr %17, align 8
  br label %18

18:                                               ; preds = %18, %.preheader.i
  %19 = phi i64 [ 0, %.preheader.i ], [ %48, %18 ]
  %20 = phi double [ %.promoted.i, %.preheader.i ], [ %47, %18 ]
  %21 = getelementptr double, ptr %14, i64 %19
  %22 = load double, ptr %21, align 8
  %23 = shl nuw nsw i64 %19, 5
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %23
  %24 = load double, ptr %gep.i, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %20, %25
  store double %26, ptr %17, align 8
  %27 = or disjoint i64 %19, 1
  %28 = getelementptr double, ptr %14, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = shl nuw nsw i64 %27, 5
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %30
  %31 = load double, ptr %gep.i.1, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %17, align 8
  %34 = or disjoint i64 %19, 2
  %35 = getelementptr double, ptr %14, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = shl nuw nsw i64 %34, 5
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %37
  %38 = load double, ptr %gep.i.2, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %17, align 8
  %41 = or disjoint i64 %19, 3
  %42 = getelementptr double, ptr %14, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = shl nuw nsw i64 %41, 5
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %44
  %45 = load double, ptr %gep.i.3, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %40, %46
  store double %47, ptr %17, align 8
  %48 = add nuw nsw i64 %19, 4
  %exitcond.not.i.3 = icmp eq i64 %48, 64
  br i1 %exitcond.not.i.3, label %49, label %18

49:                                               ; preds = %18
  %50 = add nuw nsw i64 %16, 1
  %exitcond6.not.i = icmp eq i64 %50, 32
  br i1 %exitcond6.not.i, label %.preheader3.1.i, label %.preheader.i

.preheader3.1.i:                                  ; preds = %49
  %51 = getelementptr double, ptr %15, i64 32
  %invariant.gep12.i = getelementptr double, ptr %14, i64 64
  br label %.preheader.1.i

.preheader.1.i:                                   ; preds = %81, %.preheader3.1.i
  %52 = phi i64 [ 0, %.preheader3.1.i ], [ %82, %81 ]
  %invariant.gep.1.i = getelementptr double, ptr %7, i64 %52
  %53 = getelementptr double, ptr %51, i64 %52
  %.promoted.1.i = load double, ptr %53, align 8
  br label %54

54:                                               ; preds = %54, %.preheader.1.i
  %55 = phi i64 [ 0, %.preheader.1.i ], [ %80, %54 ]
  %56 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %79, %54 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %55
  %57 = load double, ptr %gep13.i, align 8
  %58 = shl nuw nsw i64 %55, 5
  %gep.1.i = getelementptr double, ptr %invariant.gep.1.i, i64 %58
  %59 = load double, ptr %gep.1.i, align 8
  %60 = fmul double %57, %59
  %61 = fadd double %56, %60
  store double %61, ptr %53, align 8
  %62 = or disjoint i64 %55, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %62
  %63 = load double, ptr %gep13.i.1, align 8
  %64 = shl nuw nsw i64 %62, 5
  %gep.1.i.1 = getelementptr double, ptr %invariant.gep.1.i, i64 %64
  %65 = load double, ptr %gep.1.i.1, align 8
  %66 = fmul double %63, %65
  %67 = fadd double %61, %66
  store double %67, ptr %53, align 8
  %68 = or disjoint i64 %55, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %68
  %69 = load double, ptr %gep13.i.2, align 8
  %70 = shl nuw nsw i64 %68, 5
  %gep.1.i.2 = getelementptr double, ptr %invariant.gep.1.i, i64 %70
  %71 = load double, ptr %gep.1.i.2, align 8
  %72 = fmul double %69, %71
  %73 = fadd double %67, %72
  store double %73, ptr %53, align 8
  %74 = or disjoint i64 %55, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %74
  %75 = load double, ptr %gep13.i.3, align 8
  %76 = shl nuw nsw i64 %74, 5
  %gep.1.i.3 = getelementptr double, ptr %invariant.gep.1.i, i64 %76
  %77 = load double, ptr %gep.1.i.3, align 8
  %78 = fmul double %75, %77
  %79 = fadd double %73, %78
  store double %79, ptr %53, align 8
  %80 = add nuw nsw i64 %55, 4
  %exitcond.1.not.i.3 = icmp eq i64 %80, 64
  br i1 %exitcond.1.not.i.3, label %81, label %54

81:                                               ; preds = %54
  %82 = add nuw nsw i64 %52, 1
  %exitcond6.1.not.i = icmp eq i64 %82, 32
  br i1 %exitcond6.1.not.i, label %.preheader3.2.i, label %.preheader.1.i

.preheader3.2.i:                                  ; preds = %81
  %83 = getelementptr double, ptr %15, i64 64
  %invariant.gep10.i = getelementptr double, ptr %14, i64 128
  br label %.preheader.2.i

.preheader.2.i:                                   ; preds = %113, %.preheader3.2.i
  %84 = phi i64 [ 0, %.preheader3.2.i ], [ %114, %113 ]
  %invariant.gep.2.i = getelementptr double, ptr %7, i64 %84
  %85 = getelementptr double, ptr %83, i64 %84
  %.promoted.2.i = load double, ptr %85, align 8
  br label %86

86:                                               ; preds = %86, %.preheader.2.i
  %87 = phi i64 [ 0, %.preheader.2.i ], [ %112, %86 ]
  %88 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %111, %86 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %87
  %89 = load double, ptr %gep11.i, align 8
  %90 = shl nuw nsw i64 %87, 5
  %gep.2.i = getelementptr double, ptr %invariant.gep.2.i, i64 %90
  %91 = load double, ptr %gep.2.i, align 8
  %92 = fmul double %89, %91
  %93 = fadd double %88, %92
  store double %93, ptr %85, align 8
  %94 = or disjoint i64 %87, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %94
  %95 = load double, ptr %gep11.i.1, align 8
  %96 = shl nuw nsw i64 %94, 5
  %gep.2.i.1 = getelementptr double, ptr %invariant.gep.2.i, i64 %96
  %97 = load double, ptr %gep.2.i.1, align 8
  %98 = fmul double %95, %97
  %99 = fadd double %93, %98
  store double %99, ptr %85, align 8
  %100 = or disjoint i64 %87, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %100
  %101 = load double, ptr %gep11.i.2, align 8
  %102 = shl nuw nsw i64 %100, 5
  %gep.2.i.2 = getelementptr double, ptr %invariant.gep.2.i, i64 %102
  %103 = load double, ptr %gep.2.i.2, align 8
  %104 = fmul double %101, %103
  %105 = fadd double %99, %104
  store double %105, ptr %85, align 8
  %106 = or disjoint i64 %87, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %106
  %107 = load double, ptr %gep11.i.3, align 8
  %108 = shl nuw nsw i64 %106, 5
  %gep.2.i.3 = getelementptr double, ptr %invariant.gep.2.i, i64 %108
  %109 = load double, ptr %gep.2.i.3, align 8
  %110 = fmul double %107, %109
  %111 = fadd double %105, %110
  store double %111, ptr %85, align 8
  %112 = add nuw nsw i64 %87, 4
  %exitcond.2.not.i.3 = icmp eq i64 %112, 64
  br i1 %exitcond.2.not.i.3, label %113, label %86

113:                                              ; preds = %86
  %114 = add nuw nsw i64 %84, 1
  %exitcond6.2.not.i = icmp eq i64 %114, 32
  br i1 %exitcond6.2.not.i, label %.preheader3.3.i, label %.preheader.2.i

.preheader3.3.i:                                  ; preds = %113
  %115 = getelementptr double, ptr %15, i64 96
  %invariant.gep8.i = getelementptr double, ptr %14, i64 192
  br label %.preheader.3.i

.preheader.3.i:                                   ; preds = %145, %.preheader3.3.i
  %116 = phi i64 [ 0, %.preheader3.3.i ], [ %146, %145 ]
  %invariant.gep.3.i = getelementptr double, ptr %7, i64 %116
  %117 = getelementptr double, ptr %115, i64 %116
  %.promoted.3.i = load double, ptr %117, align 8
  br label %118

118:                                              ; preds = %118, %.preheader.3.i
  %119 = phi i64 [ 0, %.preheader.3.i ], [ %144, %118 ]
  %120 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %143, %118 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %119
  %121 = load double, ptr %gep9.i, align 8
  %122 = shl nuw nsw i64 %119, 5
  %gep.3.i = getelementptr double, ptr %invariant.gep.3.i, i64 %122
  %123 = load double, ptr %gep.3.i, align 8
  %124 = fmul double %121, %123
  %125 = fadd double %120, %124
  store double %125, ptr %117, align 8
  %126 = or disjoint i64 %119, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %126
  %127 = load double, ptr %gep9.i.1, align 8
  %128 = shl nuw nsw i64 %126, 5
  %gep.3.i.1 = getelementptr double, ptr %invariant.gep.3.i, i64 %128
  %129 = load double, ptr %gep.3.i.1, align 8
  %130 = fmul double %127, %129
  %131 = fadd double %125, %130
  store double %131, ptr %117, align 8
  %132 = or disjoint i64 %119, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %132
  %133 = load double, ptr %gep9.i.2, align 8
  %134 = shl nuw nsw i64 %132, 5
  %gep.3.i.2 = getelementptr double, ptr %invariant.gep.3.i, i64 %134
  %135 = load double, ptr %gep.3.i.2, align 8
  %136 = fmul double %133, %135
  %137 = fadd double %131, %136
  store double %137, ptr %117, align 8
  %138 = or disjoint i64 %119, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %138
  %139 = load double, ptr %gep9.i.3, align 8
  %140 = shl nuw nsw i64 %138, 5
  %gep.3.i.3 = getelementptr double, ptr %invariant.gep.3.i, i64 %140
  %141 = load double, ptr %gep.3.i.3, align 8
  %142 = fmul double %139, %141
  %143 = fadd double %137, %142
  store double %143, ptr %117, align 8
  %144 = add nuw nsw i64 %119, 4
  %exitcond.3.not.i.3 = icmp eq i64 %144, 64
  br i1 %exitcond.3.not.i.3, label %145, label %118

145:                                              ; preds = %118
  %146 = add nuw nsw i64 %116, 1
  %exitcond6.3.not.i = icmp eq i64 %146, 32
  br i1 %exitcond6.3.not.i, label %147, label %.preheader.3.i

147:                                              ; preds = %145
  %148 = add nuw nsw i64 %11, 4
  %149 = icmp ult i64 %11, 124
  br i1 %149, label %.preheader4.i, label %kernel.exit

kernel.exit:                                      ; preds = %147
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
