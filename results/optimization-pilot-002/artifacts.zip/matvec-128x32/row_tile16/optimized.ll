; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  %17 = getelementptr double, ptr %8, i64 1
  %18 = getelementptr double, ptr %8, i64 2
  %19 = getelementptr double, ptr %8, i64 3
  %20 = getelementptr double, ptr %8, i64 4
  %21 = getelementptr double, ptr %8, i64 5
  %22 = getelementptr double, ptr %8, i64 6
  %23 = getelementptr double, ptr %8, i64 7
  %24 = getelementptr double, ptr %8, i64 8
  %25 = getelementptr double, ptr %8, i64 9
  %26 = getelementptr double, ptr %8, i64 10
  %27 = getelementptr double, ptr %8, i64 11
  %28 = getelementptr double, ptr %8, i64 12
  %29 = getelementptr double, ptr %8, i64 13
  %30 = getelementptr double, ptr %8, i64 14
  %31 = getelementptr double, ptr %8, i64 15
  %32 = getelementptr double, ptr %8, i64 16
  %33 = getelementptr double, ptr %8, i64 17
  %34 = getelementptr double, ptr %8, i64 18
  %35 = getelementptr double, ptr %8, i64 19
  %36 = getelementptr double, ptr %8, i64 20
  %37 = getelementptr double, ptr %8, i64 21
  %38 = getelementptr double, ptr %8, i64 22
  %39 = getelementptr double, ptr %8, i64 23
  %40 = getelementptr double, ptr %8, i64 24
  %41 = getelementptr double, ptr %8, i64 25
  %42 = getelementptr double, ptr %8, i64 26
  %43 = getelementptr double, ptr %8, i64 27
  %44 = getelementptr double, ptr %8, i64 28
  %45 = getelementptr double, ptr %8, i64 29
  %46 = getelementptr double, ptr %8, i64 30
  %47 = getelementptr double, ptr %8, i64 31
  %scevgep = getelementptr i8, ptr %13, i64 1024
  %scevgep4 = getelementptr i8, ptr %1, i64 32768
  %scevgep5 = getelementptr i8, ptr %8, i64 256
  %bound0 = icmp ugt ptr %scevgep4, %13
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound06 = icmp ugt ptr %scevgep5, %13
  %bound17 = icmp ugt ptr %scevgep, %8
  %found.conflict8 = and i1 %bound06, %bound17
  %conflict.rdx = or i1 %found.conflict, %found.conflict8
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %middle.block
  %48 = phi i64 [ %736, %middle.block ], [ 0, %.preheader3.preheader ]
  %49 = shl nuw nsw i64 %48, 5
  %50 = getelementptr double, ptr %1, i64 %49
  %51 = getelementptr double, ptr %13, i64 %48
  %52 = getelementptr double, ptr %50, i64 1
  %53 = getelementptr double, ptr %50, i64 2
  %54 = getelementptr double, ptr %50, i64 3
  %55 = getelementptr double, ptr %50, i64 4
  %56 = getelementptr double, ptr %50, i64 5
  %57 = getelementptr double, ptr %50, i64 6
  %58 = getelementptr double, ptr %50, i64 7
  %59 = getelementptr double, ptr %50, i64 8
  %60 = getelementptr double, ptr %50, i64 9
  %61 = getelementptr double, ptr %50, i64 10
  %62 = getelementptr double, ptr %50, i64 11
  %63 = getelementptr double, ptr %50, i64 12
  %64 = getelementptr double, ptr %50, i64 13
  %65 = getelementptr double, ptr %50, i64 14
  %66 = getelementptr double, ptr %50, i64 15
  %67 = getelementptr double, ptr %50, i64 16
  %68 = getelementptr double, ptr %50, i64 17
  %69 = getelementptr double, ptr %50, i64 18
  %70 = getelementptr double, ptr %50, i64 19
  %71 = getelementptr double, ptr %50, i64 20
  %72 = getelementptr double, ptr %50, i64 21
  %73 = getelementptr double, ptr %50, i64 22
  %74 = getelementptr double, ptr %50, i64 23
  %75 = getelementptr double, ptr %50, i64 24
  %76 = getelementptr double, ptr %50, i64 25
  %77 = getelementptr double, ptr %50, i64 26
  %78 = getelementptr double, ptr %50, i64 27
  %79 = getelementptr double, ptr %50, i64 28
  %80 = getelementptr double, ptr %50, i64 29
  %81 = getelementptr double, ptr %50, i64 30
  %82 = getelementptr double, ptr %50, i64 31
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %83 = load double, ptr %8, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %83, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = load double, ptr %17, align 8, !alias.scope !1
  %broadcast.splatinsert9 = insertelement <4 x double> poison, double %84, i64 0
  %broadcast.splat10 = shufflevector <4 x double> %broadcast.splatinsert9, <4 x double> poison, <4 x i32> zeroinitializer
  %85 = load double, ptr %18, align 8, !alias.scope !1
  %broadcast.splatinsert11 = insertelement <4 x double> poison, double %85, i64 0
  %broadcast.splat12 = shufflevector <4 x double> %broadcast.splatinsert11, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = load double, ptr %19, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %86, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %87 = load double, ptr %20, align 8, !alias.scope !1
  %broadcast.splatinsert15 = insertelement <4 x double> poison, double %87, i64 0
  %broadcast.splat16 = shufflevector <4 x double> %broadcast.splatinsert15, <4 x double> poison, <4 x i32> zeroinitializer
  %88 = load double, ptr %21, align 8, !alias.scope !1
  %broadcast.splatinsert17 = insertelement <4 x double> poison, double %88, i64 0
  %broadcast.splat18 = shufflevector <4 x double> %broadcast.splatinsert17, <4 x double> poison, <4 x i32> zeroinitializer
  %89 = load double, ptr %22, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %89, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert21 = insertelement <4 x double> poison, double %90, i64 0
  %broadcast.splat22 = shufflevector <4 x double> %broadcast.splatinsert21, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert23 = insertelement <4 x double> poison, double %91, i64 0
  %broadcast.splat24 = shufflevector <4 x double> %broadcast.splatinsert23, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = load double, ptr %25, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %92, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert27 = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat28 = shufflevector <4 x double> %broadcast.splatinsert27, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert29 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat30 = shufflevector <4 x double> %broadcast.splatinsert29, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert33 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat34 = shufflevector <4 x double> %broadcast.splatinsert33, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert35 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat36 = shufflevector <4 x double> %broadcast.splatinsert35, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert39 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat40 = shufflevector <4 x double> %broadcast.splatinsert39, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert41 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat42 = shufflevector <4 x double> %broadcast.splatinsert41, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %102 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert45 = insertelement <4 x double> poison, double %102, i64 0
  %broadcast.splat46 = shufflevector <4 x double> %broadcast.splatinsert45, <4 x double> poison, <4 x i32> zeroinitializer
  %103 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert47 = insertelement <4 x double> poison, double %103, i64 0
  %broadcast.splat48 = shufflevector <4 x double> %broadcast.splatinsert47, <4 x double> poison, <4 x i32> zeroinitializer
  %104 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %104, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert51 = insertelement <4 x double> poison, double %105, i64 0
  %broadcast.splat52 = shufflevector <4 x double> %broadcast.splatinsert51, <4 x double> poison, <4 x i32> zeroinitializer
  %106 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert53 = insertelement <4 x double> poison, double %106, i64 0
  %broadcast.splat54 = shufflevector <4 x double> %broadcast.splatinsert53, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %107, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %108 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert57 = insertelement <4 x double> poison, double %108, i64 0
  %broadcast.splat58 = shufflevector <4 x double> %broadcast.splatinsert57, <4 x double> poison, <4 x i32> zeroinitializer
  %109 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert59 = insertelement <4 x double> poison, double %109, i64 0
  %broadcast.splat60 = shufflevector <4 x double> %broadcast.splatinsert59, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %110, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %111 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert63 = insertelement <4 x double> poison, double %111, i64 0
  %broadcast.splat64 = shufflevector <4 x double> %broadcast.splatinsert63, <4 x double> poison, <4 x i32> zeroinitializer
  %112 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert65 = insertelement <4 x double> poison, double %112, i64 0
  %broadcast.splat66 = shufflevector <4 x double> %broadcast.splatinsert65, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %113, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert69 = insertelement <4 x double> poison, double %114, i64 0
  %broadcast.splat70 = shufflevector <4 x double> %broadcast.splatinsert69, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %115 = shl i64 %index, 5
  %116 = shl i64 %index, 5
  %117 = or disjoint i64 %116, 32
  %118 = shl i64 %index, 5
  %119 = or disjoint i64 %118, 64
  %120 = shl i64 %index, 5
  %121 = or disjoint i64 %120, 96
  %122 = getelementptr double, ptr %51, i64 %index
  %wide.load = load <4 x double>, ptr %122, align 8, !alias.scope !4, !noalias !6
  %123 = getelementptr double, ptr %50, i64 %115
  %124 = getelementptr double, ptr %50, i64 %117
  %125 = getelementptr double, ptr %50, i64 %119
  %126 = getelementptr double, ptr %50, i64 %121
  %127 = load double, ptr %123, align 8, !alias.scope !8
  %128 = load double, ptr %124, align 8, !alias.scope !8
  %129 = load double, ptr %125, align 8, !alias.scope !8
  %130 = load double, ptr %126, align 8, !alias.scope !8
  %131 = insertelement <4 x double> poison, double %127, i64 0
  %132 = insertelement <4 x double> %131, double %128, i64 1
  %133 = insertelement <4 x double> %132, double %129, i64 2
  %134 = insertelement <4 x double> %133, double %130, i64 3
  %135 = fmul <4 x double> %134, %broadcast.splat
  %136 = fadd <4 x double> %wide.load, %135
  store <4 x double> %136, ptr %122, align 8, !alias.scope !4, !noalias !6
  %137 = getelementptr double, ptr %52, i64 %115
  %138 = getelementptr double, ptr %52, i64 %117
  %139 = getelementptr double, ptr %52, i64 %119
  %140 = getelementptr double, ptr %52, i64 %121
  %141 = load double, ptr %137, align 8, !alias.scope !8
  %142 = load double, ptr %138, align 8, !alias.scope !8
  %143 = load double, ptr %139, align 8, !alias.scope !8
  %144 = load double, ptr %140, align 8, !alias.scope !8
  %145 = insertelement <4 x double> poison, double %141, i64 0
  %146 = insertelement <4 x double> %145, double %142, i64 1
  %147 = insertelement <4 x double> %146, double %143, i64 2
  %148 = insertelement <4 x double> %147, double %144, i64 3
  %149 = fmul <4 x double> %148, %broadcast.splat10
  %150 = fadd <4 x double> %136, %149
  store <4 x double> %150, ptr %122, align 8, !alias.scope !4, !noalias !6
  %151 = getelementptr double, ptr %53, i64 %115
  %152 = getelementptr double, ptr %53, i64 %117
  %153 = getelementptr double, ptr %53, i64 %119
  %154 = getelementptr double, ptr %53, i64 %121
  %155 = load double, ptr %151, align 8, !alias.scope !8
  %156 = load double, ptr %152, align 8, !alias.scope !8
  %157 = load double, ptr %153, align 8, !alias.scope !8
  %158 = load double, ptr %154, align 8, !alias.scope !8
  %159 = insertelement <4 x double> poison, double %155, i64 0
  %160 = insertelement <4 x double> %159, double %156, i64 1
  %161 = insertelement <4 x double> %160, double %157, i64 2
  %162 = insertelement <4 x double> %161, double %158, i64 3
  %163 = fmul <4 x double> %162, %broadcast.splat12
  %164 = fadd <4 x double> %150, %163
  store <4 x double> %164, ptr %122, align 8, !alias.scope !4, !noalias !6
  %165 = getelementptr double, ptr %54, i64 %115
  %166 = getelementptr double, ptr %54, i64 %117
  %167 = getelementptr double, ptr %54, i64 %119
  %168 = getelementptr double, ptr %54, i64 %121
  %169 = load double, ptr %165, align 8, !alias.scope !8
  %170 = load double, ptr %166, align 8, !alias.scope !8
  %171 = load double, ptr %167, align 8, !alias.scope !8
  %172 = load double, ptr %168, align 8, !alias.scope !8
  %173 = insertelement <4 x double> poison, double %169, i64 0
  %174 = insertelement <4 x double> %173, double %170, i64 1
  %175 = insertelement <4 x double> %174, double %171, i64 2
  %176 = insertelement <4 x double> %175, double %172, i64 3
  %177 = fmul <4 x double> %176, %broadcast.splat14
  %178 = fadd <4 x double> %164, %177
  store <4 x double> %178, ptr %122, align 8, !alias.scope !4, !noalias !6
  %179 = getelementptr double, ptr %55, i64 %115
  %180 = getelementptr double, ptr %55, i64 %117
  %181 = getelementptr double, ptr %55, i64 %119
  %182 = getelementptr double, ptr %55, i64 %121
  %183 = load double, ptr %179, align 8, !alias.scope !8
  %184 = load double, ptr %180, align 8, !alias.scope !8
  %185 = load double, ptr %181, align 8, !alias.scope !8
  %186 = load double, ptr %182, align 8, !alias.scope !8
  %187 = insertelement <4 x double> poison, double %183, i64 0
  %188 = insertelement <4 x double> %187, double %184, i64 1
  %189 = insertelement <4 x double> %188, double %185, i64 2
  %190 = insertelement <4 x double> %189, double %186, i64 3
  %191 = fmul <4 x double> %190, %broadcast.splat16
  %192 = fadd <4 x double> %178, %191
  store <4 x double> %192, ptr %122, align 8, !alias.scope !4, !noalias !6
  %193 = getelementptr double, ptr %56, i64 %115
  %194 = getelementptr double, ptr %56, i64 %117
  %195 = getelementptr double, ptr %56, i64 %119
  %196 = getelementptr double, ptr %56, i64 %121
  %197 = load double, ptr %193, align 8, !alias.scope !8
  %198 = load double, ptr %194, align 8, !alias.scope !8
  %199 = load double, ptr %195, align 8, !alias.scope !8
  %200 = load double, ptr %196, align 8, !alias.scope !8
  %201 = insertelement <4 x double> poison, double %197, i64 0
  %202 = insertelement <4 x double> %201, double %198, i64 1
  %203 = insertelement <4 x double> %202, double %199, i64 2
  %204 = insertelement <4 x double> %203, double %200, i64 3
  %205 = fmul <4 x double> %204, %broadcast.splat18
  %206 = fadd <4 x double> %192, %205
  store <4 x double> %206, ptr %122, align 8, !alias.scope !4, !noalias !6
  %207 = getelementptr double, ptr %57, i64 %115
  %208 = getelementptr double, ptr %57, i64 %117
  %209 = getelementptr double, ptr %57, i64 %119
  %210 = getelementptr double, ptr %57, i64 %121
  %211 = load double, ptr %207, align 8, !alias.scope !8
  %212 = load double, ptr %208, align 8, !alias.scope !8
  %213 = load double, ptr %209, align 8, !alias.scope !8
  %214 = load double, ptr %210, align 8, !alias.scope !8
  %215 = insertelement <4 x double> poison, double %211, i64 0
  %216 = insertelement <4 x double> %215, double %212, i64 1
  %217 = insertelement <4 x double> %216, double %213, i64 2
  %218 = insertelement <4 x double> %217, double %214, i64 3
  %219 = fmul <4 x double> %218, %broadcast.splat20
  %220 = fadd <4 x double> %206, %219
  store <4 x double> %220, ptr %122, align 8, !alias.scope !4, !noalias !6
  %221 = getelementptr double, ptr %58, i64 %115
  %222 = getelementptr double, ptr %58, i64 %117
  %223 = getelementptr double, ptr %58, i64 %119
  %224 = getelementptr double, ptr %58, i64 %121
  %225 = load double, ptr %221, align 8, !alias.scope !8
  %226 = load double, ptr %222, align 8, !alias.scope !8
  %227 = load double, ptr %223, align 8, !alias.scope !8
  %228 = load double, ptr %224, align 8, !alias.scope !8
  %229 = insertelement <4 x double> poison, double %225, i64 0
  %230 = insertelement <4 x double> %229, double %226, i64 1
  %231 = insertelement <4 x double> %230, double %227, i64 2
  %232 = insertelement <4 x double> %231, double %228, i64 3
  %233 = fmul <4 x double> %232, %broadcast.splat22
  %234 = fadd <4 x double> %220, %233
  store <4 x double> %234, ptr %122, align 8, !alias.scope !4, !noalias !6
  %235 = getelementptr double, ptr %59, i64 %115
  %236 = getelementptr double, ptr %59, i64 %117
  %237 = getelementptr double, ptr %59, i64 %119
  %238 = getelementptr double, ptr %59, i64 %121
  %239 = load double, ptr %235, align 8, !alias.scope !8
  %240 = load double, ptr %236, align 8, !alias.scope !8
  %241 = load double, ptr %237, align 8, !alias.scope !8
  %242 = load double, ptr %238, align 8, !alias.scope !8
  %243 = insertelement <4 x double> poison, double %239, i64 0
  %244 = insertelement <4 x double> %243, double %240, i64 1
  %245 = insertelement <4 x double> %244, double %241, i64 2
  %246 = insertelement <4 x double> %245, double %242, i64 3
  %247 = fmul <4 x double> %246, %broadcast.splat24
  %248 = fadd <4 x double> %234, %247
  store <4 x double> %248, ptr %122, align 8, !alias.scope !4, !noalias !6
  %249 = getelementptr double, ptr %60, i64 %115
  %250 = getelementptr double, ptr %60, i64 %117
  %251 = getelementptr double, ptr %60, i64 %119
  %252 = getelementptr double, ptr %60, i64 %121
  %253 = load double, ptr %249, align 8, !alias.scope !8
  %254 = load double, ptr %250, align 8, !alias.scope !8
  %255 = load double, ptr %251, align 8, !alias.scope !8
  %256 = load double, ptr %252, align 8, !alias.scope !8
  %257 = insertelement <4 x double> poison, double %253, i64 0
  %258 = insertelement <4 x double> %257, double %254, i64 1
  %259 = insertelement <4 x double> %258, double %255, i64 2
  %260 = insertelement <4 x double> %259, double %256, i64 3
  %261 = fmul <4 x double> %260, %broadcast.splat26
  %262 = fadd <4 x double> %248, %261
  store <4 x double> %262, ptr %122, align 8, !alias.scope !4, !noalias !6
  %263 = getelementptr double, ptr %61, i64 %115
  %264 = getelementptr double, ptr %61, i64 %117
  %265 = getelementptr double, ptr %61, i64 %119
  %266 = getelementptr double, ptr %61, i64 %121
  %267 = load double, ptr %263, align 8, !alias.scope !8
  %268 = load double, ptr %264, align 8, !alias.scope !8
  %269 = load double, ptr %265, align 8, !alias.scope !8
  %270 = load double, ptr %266, align 8, !alias.scope !8
  %271 = insertelement <4 x double> poison, double %267, i64 0
  %272 = insertelement <4 x double> %271, double %268, i64 1
  %273 = insertelement <4 x double> %272, double %269, i64 2
  %274 = insertelement <4 x double> %273, double %270, i64 3
  %275 = fmul <4 x double> %274, %broadcast.splat28
  %276 = fadd <4 x double> %262, %275
  store <4 x double> %276, ptr %122, align 8, !alias.scope !4, !noalias !6
  %277 = getelementptr double, ptr %62, i64 %115
  %278 = getelementptr double, ptr %62, i64 %117
  %279 = getelementptr double, ptr %62, i64 %119
  %280 = getelementptr double, ptr %62, i64 %121
  %281 = load double, ptr %277, align 8, !alias.scope !8
  %282 = load double, ptr %278, align 8, !alias.scope !8
  %283 = load double, ptr %279, align 8, !alias.scope !8
  %284 = load double, ptr %280, align 8, !alias.scope !8
  %285 = insertelement <4 x double> poison, double %281, i64 0
  %286 = insertelement <4 x double> %285, double %282, i64 1
  %287 = insertelement <4 x double> %286, double %283, i64 2
  %288 = insertelement <4 x double> %287, double %284, i64 3
  %289 = fmul <4 x double> %288, %broadcast.splat30
  %290 = fadd <4 x double> %276, %289
  store <4 x double> %290, ptr %122, align 8, !alias.scope !4, !noalias !6
  %291 = getelementptr double, ptr %63, i64 %115
  %292 = getelementptr double, ptr %63, i64 %117
  %293 = getelementptr double, ptr %63, i64 %119
  %294 = getelementptr double, ptr %63, i64 %121
  %295 = load double, ptr %291, align 8, !alias.scope !8
  %296 = load double, ptr %292, align 8, !alias.scope !8
  %297 = load double, ptr %293, align 8, !alias.scope !8
  %298 = load double, ptr %294, align 8, !alias.scope !8
  %299 = insertelement <4 x double> poison, double %295, i64 0
  %300 = insertelement <4 x double> %299, double %296, i64 1
  %301 = insertelement <4 x double> %300, double %297, i64 2
  %302 = insertelement <4 x double> %301, double %298, i64 3
  %303 = fmul <4 x double> %302, %broadcast.splat32
  %304 = fadd <4 x double> %290, %303
  store <4 x double> %304, ptr %122, align 8, !alias.scope !4, !noalias !6
  %305 = getelementptr double, ptr %64, i64 %115
  %306 = getelementptr double, ptr %64, i64 %117
  %307 = getelementptr double, ptr %64, i64 %119
  %308 = getelementptr double, ptr %64, i64 %121
  %309 = load double, ptr %305, align 8, !alias.scope !8
  %310 = load double, ptr %306, align 8, !alias.scope !8
  %311 = load double, ptr %307, align 8, !alias.scope !8
  %312 = load double, ptr %308, align 8, !alias.scope !8
  %313 = insertelement <4 x double> poison, double %309, i64 0
  %314 = insertelement <4 x double> %313, double %310, i64 1
  %315 = insertelement <4 x double> %314, double %311, i64 2
  %316 = insertelement <4 x double> %315, double %312, i64 3
  %317 = fmul <4 x double> %316, %broadcast.splat34
  %318 = fadd <4 x double> %304, %317
  store <4 x double> %318, ptr %122, align 8, !alias.scope !4, !noalias !6
  %319 = getelementptr double, ptr %65, i64 %115
  %320 = getelementptr double, ptr %65, i64 %117
  %321 = getelementptr double, ptr %65, i64 %119
  %322 = getelementptr double, ptr %65, i64 %121
  %323 = load double, ptr %319, align 8, !alias.scope !8
  %324 = load double, ptr %320, align 8, !alias.scope !8
  %325 = load double, ptr %321, align 8, !alias.scope !8
  %326 = load double, ptr %322, align 8, !alias.scope !8
  %327 = insertelement <4 x double> poison, double %323, i64 0
  %328 = insertelement <4 x double> %327, double %324, i64 1
  %329 = insertelement <4 x double> %328, double %325, i64 2
  %330 = insertelement <4 x double> %329, double %326, i64 3
  %331 = fmul <4 x double> %330, %broadcast.splat36
  %332 = fadd <4 x double> %318, %331
  store <4 x double> %332, ptr %122, align 8, !alias.scope !4, !noalias !6
  %333 = getelementptr double, ptr %66, i64 %115
  %334 = getelementptr double, ptr %66, i64 %117
  %335 = getelementptr double, ptr %66, i64 %119
  %336 = getelementptr double, ptr %66, i64 %121
  %337 = load double, ptr %333, align 8, !alias.scope !8
  %338 = load double, ptr %334, align 8, !alias.scope !8
  %339 = load double, ptr %335, align 8, !alias.scope !8
  %340 = load double, ptr %336, align 8, !alias.scope !8
  %341 = insertelement <4 x double> poison, double %337, i64 0
  %342 = insertelement <4 x double> %341, double %338, i64 1
  %343 = insertelement <4 x double> %342, double %339, i64 2
  %344 = insertelement <4 x double> %343, double %340, i64 3
  %345 = fmul <4 x double> %344, %broadcast.splat38
  %346 = fadd <4 x double> %332, %345
  store <4 x double> %346, ptr %122, align 8, !alias.scope !4, !noalias !6
  %347 = getelementptr double, ptr %67, i64 %115
  %348 = getelementptr double, ptr %67, i64 %117
  %349 = getelementptr double, ptr %67, i64 %119
  %350 = getelementptr double, ptr %67, i64 %121
  %351 = load double, ptr %347, align 8, !alias.scope !8
  %352 = load double, ptr %348, align 8, !alias.scope !8
  %353 = load double, ptr %349, align 8, !alias.scope !8
  %354 = load double, ptr %350, align 8, !alias.scope !8
  %355 = insertelement <4 x double> poison, double %351, i64 0
  %356 = insertelement <4 x double> %355, double %352, i64 1
  %357 = insertelement <4 x double> %356, double %353, i64 2
  %358 = insertelement <4 x double> %357, double %354, i64 3
  %359 = fmul <4 x double> %358, %broadcast.splat40
  %360 = fadd <4 x double> %346, %359
  store <4 x double> %360, ptr %122, align 8, !alias.scope !4, !noalias !6
  %361 = getelementptr double, ptr %68, i64 %115
  %362 = getelementptr double, ptr %68, i64 %117
  %363 = getelementptr double, ptr %68, i64 %119
  %364 = getelementptr double, ptr %68, i64 %121
  %365 = load double, ptr %361, align 8, !alias.scope !8
  %366 = load double, ptr %362, align 8, !alias.scope !8
  %367 = load double, ptr %363, align 8, !alias.scope !8
  %368 = load double, ptr %364, align 8, !alias.scope !8
  %369 = insertelement <4 x double> poison, double %365, i64 0
  %370 = insertelement <4 x double> %369, double %366, i64 1
  %371 = insertelement <4 x double> %370, double %367, i64 2
  %372 = insertelement <4 x double> %371, double %368, i64 3
  %373 = fmul <4 x double> %372, %broadcast.splat42
  %374 = fadd <4 x double> %360, %373
  store <4 x double> %374, ptr %122, align 8, !alias.scope !4, !noalias !6
  %375 = getelementptr double, ptr %69, i64 %115
  %376 = getelementptr double, ptr %69, i64 %117
  %377 = getelementptr double, ptr %69, i64 %119
  %378 = getelementptr double, ptr %69, i64 %121
  %379 = load double, ptr %375, align 8, !alias.scope !8
  %380 = load double, ptr %376, align 8, !alias.scope !8
  %381 = load double, ptr %377, align 8, !alias.scope !8
  %382 = load double, ptr %378, align 8, !alias.scope !8
  %383 = insertelement <4 x double> poison, double %379, i64 0
  %384 = insertelement <4 x double> %383, double %380, i64 1
  %385 = insertelement <4 x double> %384, double %381, i64 2
  %386 = insertelement <4 x double> %385, double %382, i64 3
  %387 = fmul <4 x double> %386, %broadcast.splat44
  %388 = fadd <4 x double> %374, %387
  store <4 x double> %388, ptr %122, align 8, !alias.scope !4, !noalias !6
  %389 = getelementptr double, ptr %70, i64 %115
  %390 = getelementptr double, ptr %70, i64 %117
  %391 = getelementptr double, ptr %70, i64 %119
  %392 = getelementptr double, ptr %70, i64 %121
  %393 = load double, ptr %389, align 8, !alias.scope !8
  %394 = load double, ptr %390, align 8, !alias.scope !8
  %395 = load double, ptr %391, align 8, !alias.scope !8
  %396 = load double, ptr %392, align 8, !alias.scope !8
  %397 = insertelement <4 x double> poison, double %393, i64 0
  %398 = insertelement <4 x double> %397, double %394, i64 1
  %399 = insertelement <4 x double> %398, double %395, i64 2
  %400 = insertelement <4 x double> %399, double %396, i64 3
  %401 = fmul <4 x double> %400, %broadcast.splat46
  %402 = fadd <4 x double> %388, %401
  store <4 x double> %402, ptr %122, align 8, !alias.scope !4, !noalias !6
  %403 = getelementptr double, ptr %71, i64 %115
  %404 = getelementptr double, ptr %71, i64 %117
  %405 = getelementptr double, ptr %71, i64 %119
  %406 = getelementptr double, ptr %71, i64 %121
  %407 = load double, ptr %403, align 8, !alias.scope !8
  %408 = load double, ptr %404, align 8, !alias.scope !8
  %409 = load double, ptr %405, align 8, !alias.scope !8
  %410 = load double, ptr %406, align 8, !alias.scope !8
  %411 = insertelement <4 x double> poison, double %407, i64 0
  %412 = insertelement <4 x double> %411, double %408, i64 1
  %413 = insertelement <4 x double> %412, double %409, i64 2
  %414 = insertelement <4 x double> %413, double %410, i64 3
  %415 = fmul <4 x double> %414, %broadcast.splat48
  %416 = fadd <4 x double> %402, %415
  store <4 x double> %416, ptr %122, align 8, !alias.scope !4, !noalias !6
  %417 = getelementptr double, ptr %72, i64 %115
  %418 = getelementptr double, ptr %72, i64 %117
  %419 = getelementptr double, ptr %72, i64 %119
  %420 = getelementptr double, ptr %72, i64 %121
  %421 = load double, ptr %417, align 8, !alias.scope !8
  %422 = load double, ptr %418, align 8, !alias.scope !8
  %423 = load double, ptr %419, align 8, !alias.scope !8
  %424 = load double, ptr %420, align 8, !alias.scope !8
  %425 = insertelement <4 x double> poison, double %421, i64 0
  %426 = insertelement <4 x double> %425, double %422, i64 1
  %427 = insertelement <4 x double> %426, double %423, i64 2
  %428 = insertelement <4 x double> %427, double %424, i64 3
  %429 = fmul <4 x double> %428, %broadcast.splat50
  %430 = fadd <4 x double> %416, %429
  store <4 x double> %430, ptr %122, align 8, !alias.scope !4, !noalias !6
  %431 = getelementptr double, ptr %73, i64 %115
  %432 = getelementptr double, ptr %73, i64 %117
  %433 = getelementptr double, ptr %73, i64 %119
  %434 = getelementptr double, ptr %73, i64 %121
  %435 = load double, ptr %431, align 8, !alias.scope !8
  %436 = load double, ptr %432, align 8, !alias.scope !8
  %437 = load double, ptr %433, align 8, !alias.scope !8
  %438 = load double, ptr %434, align 8, !alias.scope !8
  %439 = insertelement <4 x double> poison, double %435, i64 0
  %440 = insertelement <4 x double> %439, double %436, i64 1
  %441 = insertelement <4 x double> %440, double %437, i64 2
  %442 = insertelement <4 x double> %441, double %438, i64 3
  %443 = fmul <4 x double> %442, %broadcast.splat52
  %444 = fadd <4 x double> %430, %443
  store <4 x double> %444, ptr %122, align 8, !alias.scope !4, !noalias !6
  %445 = getelementptr double, ptr %74, i64 %115
  %446 = getelementptr double, ptr %74, i64 %117
  %447 = getelementptr double, ptr %74, i64 %119
  %448 = getelementptr double, ptr %74, i64 %121
  %449 = load double, ptr %445, align 8, !alias.scope !8
  %450 = load double, ptr %446, align 8, !alias.scope !8
  %451 = load double, ptr %447, align 8, !alias.scope !8
  %452 = load double, ptr %448, align 8, !alias.scope !8
  %453 = insertelement <4 x double> poison, double %449, i64 0
  %454 = insertelement <4 x double> %453, double %450, i64 1
  %455 = insertelement <4 x double> %454, double %451, i64 2
  %456 = insertelement <4 x double> %455, double %452, i64 3
  %457 = fmul <4 x double> %456, %broadcast.splat54
  %458 = fadd <4 x double> %444, %457
  store <4 x double> %458, ptr %122, align 8, !alias.scope !4, !noalias !6
  %459 = getelementptr double, ptr %75, i64 %115
  %460 = getelementptr double, ptr %75, i64 %117
  %461 = getelementptr double, ptr %75, i64 %119
  %462 = getelementptr double, ptr %75, i64 %121
  %463 = load double, ptr %459, align 8, !alias.scope !8
  %464 = load double, ptr %460, align 8, !alias.scope !8
  %465 = load double, ptr %461, align 8, !alias.scope !8
  %466 = load double, ptr %462, align 8, !alias.scope !8
  %467 = insertelement <4 x double> poison, double %463, i64 0
  %468 = insertelement <4 x double> %467, double %464, i64 1
  %469 = insertelement <4 x double> %468, double %465, i64 2
  %470 = insertelement <4 x double> %469, double %466, i64 3
  %471 = fmul <4 x double> %470, %broadcast.splat56
  %472 = fadd <4 x double> %458, %471
  store <4 x double> %472, ptr %122, align 8, !alias.scope !4, !noalias !6
  %473 = getelementptr double, ptr %76, i64 %115
  %474 = getelementptr double, ptr %76, i64 %117
  %475 = getelementptr double, ptr %76, i64 %119
  %476 = getelementptr double, ptr %76, i64 %121
  %477 = load double, ptr %473, align 8, !alias.scope !8
  %478 = load double, ptr %474, align 8, !alias.scope !8
  %479 = load double, ptr %475, align 8, !alias.scope !8
  %480 = load double, ptr %476, align 8, !alias.scope !8
  %481 = insertelement <4 x double> poison, double %477, i64 0
  %482 = insertelement <4 x double> %481, double %478, i64 1
  %483 = insertelement <4 x double> %482, double %479, i64 2
  %484 = insertelement <4 x double> %483, double %480, i64 3
  %485 = fmul <4 x double> %484, %broadcast.splat58
  %486 = fadd <4 x double> %472, %485
  store <4 x double> %486, ptr %122, align 8, !alias.scope !4, !noalias !6
  %487 = getelementptr double, ptr %77, i64 %115
  %488 = getelementptr double, ptr %77, i64 %117
  %489 = getelementptr double, ptr %77, i64 %119
  %490 = getelementptr double, ptr %77, i64 %121
  %491 = load double, ptr %487, align 8, !alias.scope !8
  %492 = load double, ptr %488, align 8, !alias.scope !8
  %493 = load double, ptr %489, align 8, !alias.scope !8
  %494 = load double, ptr %490, align 8, !alias.scope !8
  %495 = insertelement <4 x double> poison, double %491, i64 0
  %496 = insertelement <4 x double> %495, double %492, i64 1
  %497 = insertelement <4 x double> %496, double %493, i64 2
  %498 = insertelement <4 x double> %497, double %494, i64 3
  %499 = fmul <4 x double> %498, %broadcast.splat60
  %500 = fadd <4 x double> %486, %499
  store <4 x double> %500, ptr %122, align 8, !alias.scope !4, !noalias !6
  %501 = getelementptr double, ptr %78, i64 %115
  %502 = getelementptr double, ptr %78, i64 %117
  %503 = getelementptr double, ptr %78, i64 %119
  %504 = getelementptr double, ptr %78, i64 %121
  %505 = load double, ptr %501, align 8, !alias.scope !8
  %506 = load double, ptr %502, align 8, !alias.scope !8
  %507 = load double, ptr %503, align 8, !alias.scope !8
  %508 = load double, ptr %504, align 8, !alias.scope !8
  %509 = insertelement <4 x double> poison, double %505, i64 0
  %510 = insertelement <4 x double> %509, double %506, i64 1
  %511 = insertelement <4 x double> %510, double %507, i64 2
  %512 = insertelement <4 x double> %511, double %508, i64 3
  %513 = fmul <4 x double> %512, %broadcast.splat62
  %514 = fadd <4 x double> %500, %513
  store <4 x double> %514, ptr %122, align 8, !alias.scope !4, !noalias !6
  %515 = getelementptr double, ptr %79, i64 %115
  %516 = getelementptr double, ptr %79, i64 %117
  %517 = getelementptr double, ptr %79, i64 %119
  %518 = getelementptr double, ptr %79, i64 %121
  %519 = load double, ptr %515, align 8, !alias.scope !8
  %520 = load double, ptr %516, align 8, !alias.scope !8
  %521 = load double, ptr %517, align 8, !alias.scope !8
  %522 = load double, ptr %518, align 8, !alias.scope !8
  %523 = insertelement <4 x double> poison, double %519, i64 0
  %524 = insertelement <4 x double> %523, double %520, i64 1
  %525 = insertelement <4 x double> %524, double %521, i64 2
  %526 = insertelement <4 x double> %525, double %522, i64 3
  %527 = fmul <4 x double> %526, %broadcast.splat64
  %528 = fadd <4 x double> %514, %527
  store <4 x double> %528, ptr %122, align 8, !alias.scope !4, !noalias !6
  %529 = getelementptr double, ptr %80, i64 %115
  %530 = getelementptr double, ptr %80, i64 %117
  %531 = getelementptr double, ptr %80, i64 %119
  %532 = getelementptr double, ptr %80, i64 %121
  %533 = load double, ptr %529, align 8, !alias.scope !8
  %534 = load double, ptr %530, align 8, !alias.scope !8
  %535 = load double, ptr %531, align 8, !alias.scope !8
  %536 = load double, ptr %532, align 8, !alias.scope !8
  %537 = insertelement <4 x double> poison, double %533, i64 0
  %538 = insertelement <4 x double> %537, double %534, i64 1
  %539 = insertelement <4 x double> %538, double %535, i64 2
  %540 = insertelement <4 x double> %539, double %536, i64 3
  %541 = fmul <4 x double> %540, %broadcast.splat66
  %542 = fadd <4 x double> %528, %541
  store <4 x double> %542, ptr %122, align 8, !alias.scope !4, !noalias !6
  %543 = getelementptr double, ptr %81, i64 %115
  %544 = getelementptr double, ptr %81, i64 %117
  %545 = getelementptr double, ptr %81, i64 %119
  %546 = getelementptr double, ptr %81, i64 %121
  %547 = load double, ptr %543, align 8, !alias.scope !8
  %548 = load double, ptr %544, align 8, !alias.scope !8
  %549 = load double, ptr %545, align 8, !alias.scope !8
  %550 = load double, ptr %546, align 8, !alias.scope !8
  %551 = insertelement <4 x double> poison, double %547, i64 0
  %552 = insertelement <4 x double> %551, double %548, i64 1
  %553 = insertelement <4 x double> %552, double %549, i64 2
  %554 = insertelement <4 x double> %553, double %550, i64 3
  %555 = fmul <4 x double> %554, %broadcast.splat68
  %556 = fadd <4 x double> %542, %555
  store <4 x double> %556, ptr %122, align 8, !alias.scope !4, !noalias !6
  %557 = getelementptr double, ptr %82, i64 %115
  %558 = getelementptr double, ptr %82, i64 %117
  %559 = getelementptr double, ptr %82, i64 %119
  %560 = getelementptr double, ptr %82, i64 %121
  %561 = load double, ptr %557, align 8, !alias.scope !8
  %562 = load double, ptr %558, align 8, !alias.scope !8
  %563 = load double, ptr %559, align 8, !alias.scope !8
  %564 = load double, ptr %560, align 8, !alias.scope !8
  %565 = insertelement <4 x double> poison, double %561, i64 0
  %566 = insertelement <4 x double> %565, double %562, i64 1
  %567 = insertelement <4 x double> %566, double %563, i64 2
  %568 = insertelement <4 x double> %567, double %564, i64 3
  %569 = fmul <4 x double> %568, %broadcast.splat70
  %570 = fadd <4 x double> %556, %569
  store <4 x double> %570, ptr %122, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %571 = icmp eq i64 %index.next, 16
  br i1 %571, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %572 = phi i64 [ %735, %.preheader ], [ 0, %.preheader3 ]
  %573 = shl i64 %572, 5
  %574 = getelementptr double, ptr %51, i64 %572
  %.promoted = load double, ptr %574, align 8
  %575 = getelementptr double, ptr %50, i64 %573
  %576 = load double, ptr %575, align 8
  %577 = load double, ptr %8, align 8
  %578 = fmul double %576, %577
  %579 = fadd double %.promoted, %578
  store double %579, ptr %574, align 8
  %580 = getelementptr double, ptr %52, i64 %573
  %581 = load double, ptr %580, align 8
  %582 = load double, ptr %17, align 8
  %583 = fmul double %581, %582
  %584 = fadd double %579, %583
  store double %584, ptr %574, align 8
  %585 = getelementptr double, ptr %53, i64 %573
  %586 = load double, ptr %585, align 8
  %587 = load double, ptr %18, align 8
  %588 = fmul double %586, %587
  %589 = fadd double %584, %588
  store double %589, ptr %574, align 8
  %590 = getelementptr double, ptr %54, i64 %573
  %591 = load double, ptr %590, align 8
  %592 = load double, ptr %19, align 8
  %593 = fmul double %591, %592
  %594 = fadd double %589, %593
  store double %594, ptr %574, align 8
  %595 = getelementptr double, ptr %55, i64 %573
  %596 = load double, ptr %595, align 8
  %597 = load double, ptr %20, align 8
  %598 = fmul double %596, %597
  %599 = fadd double %594, %598
  store double %599, ptr %574, align 8
  %600 = getelementptr double, ptr %56, i64 %573
  %601 = load double, ptr %600, align 8
  %602 = load double, ptr %21, align 8
  %603 = fmul double %601, %602
  %604 = fadd double %599, %603
  store double %604, ptr %574, align 8
  %605 = getelementptr double, ptr %57, i64 %573
  %606 = load double, ptr %605, align 8
  %607 = load double, ptr %22, align 8
  %608 = fmul double %606, %607
  %609 = fadd double %604, %608
  store double %609, ptr %574, align 8
  %610 = getelementptr double, ptr %58, i64 %573
  %611 = load double, ptr %610, align 8
  %612 = load double, ptr %23, align 8
  %613 = fmul double %611, %612
  %614 = fadd double %609, %613
  store double %614, ptr %574, align 8
  %615 = getelementptr double, ptr %59, i64 %573
  %616 = load double, ptr %615, align 8
  %617 = load double, ptr %24, align 8
  %618 = fmul double %616, %617
  %619 = fadd double %614, %618
  store double %619, ptr %574, align 8
  %620 = getelementptr double, ptr %60, i64 %573
  %621 = load double, ptr %620, align 8
  %622 = load double, ptr %25, align 8
  %623 = fmul double %621, %622
  %624 = fadd double %619, %623
  store double %624, ptr %574, align 8
  %625 = getelementptr double, ptr %61, i64 %573
  %626 = load double, ptr %625, align 8
  %627 = load double, ptr %26, align 8
  %628 = fmul double %626, %627
  %629 = fadd double %624, %628
  store double %629, ptr %574, align 8
  %630 = getelementptr double, ptr %62, i64 %573
  %631 = load double, ptr %630, align 8
  %632 = load double, ptr %27, align 8
  %633 = fmul double %631, %632
  %634 = fadd double %629, %633
  store double %634, ptr %574, align 8
  %635 = getelementptr double, ptr %63, i64 %573
  %636 = load double, ptr %635, align 8
  %637 = load double, ptr %28, align 8
  %638 = fmul double %636, %637
  %639 = fadd double %634, %638
  store double %639, ptr %574, align 8
  %640 = getelementptr double, ptr %64, i64 %573
  %641 = load double, ptr %640, align 8
  %642 = load double, ptr %29, align 8
  %643 = fmul double %641, %642
  %644 = fadd double %639, %643
  store double %644, ptr %574, align 8
  %645 = getelementptr double, ptr %65, i64 %573
  %646 = load double, ptr %645, align 8
  %647 = load double, ptr %30, align 8
  %648 = fmul double %646, %647
  %649 = fadd double %644, %648
  store double %649, ptr %574, align 8
  %650 = getelementptr double, ptr %66, i64 %573
  %651 = load double, ptr %650, align 8
  %652 = load double, ptr %31, align 8
  %653 = fmul double %651, %652
  %654 = fadd double %649, %653
  store double %654, ptr %574, align 8
  %655 = getelementptr double, ptr %67, i64 %573
  %656 = load double, ptr %655, align 8
  %657 = load double, ptr %32, align 8
  %658 = fmul double %656, %657
  %659 = fadd double %654, %658
  store double %659, ptr %574, align 8
  %660 = getelementptr double, ptr %68, i64 %573
  %661 = load double, ptr %660, align 8
  %662 = load double, ptr %33, align 8
  %663 = fmul double %661, %662
  %664 = fadd double %659, %663
  store double %664, ptr %574, align 8
  %665 = getelementptr double, ptr %69, i64 %573
  %666 = load double, ptr %665, align 8
  %667 = load double, ptr %34, align 8
  %668 = fmul double %666, %667
  %669 = fadd double %664, %668
  store double %669, ptr %574, align 8
  %670 = getelementptr double, ptr %70, i64 %573
  %671 = load double, ptr %670, align 8
  %672 = load double, ptr %35, align 8
  %673 = fmul double %671, %672
  %674 = fadd double %669, %673
  store double %674, ptr %574, align 8
  %675 = getelementptr double, ptr %71, i64 %573
  %676 = load double, ptr %675, align 8
  %677 = load double, ptr %36, align 8
  %678 = fmul double %676, %677
  %679 = fadd double %674, %678
  store double %679, ptr %574, align 8
  %680 = getelementptr double, ptr %72, i64 %573
  %681 = load double, ptr %680, align 8
  %682 = load double, ptr %37, align 8
  %683 = fmul double %681, %682
  %684 = fadd double %679, %683
  store double %684, ptr %574, align 8
  %685 = getelementptr double, ptr %73, i64 %573
  %686 = load double, ptr %685, align 8
  %687 = load double, ptr %38, align 8
  %688 = fmul double %686, %687
  %689 = fadd double %684, %688
  store double %689, ptr %574, align 8
  %690 = getelementptr double, ptr %74, i64 %573
  %691 = load double, ptr %690, align 8
  %692 = load double, ptr %39, align 8
  %693 = fmul double %691, %692
  %694 = fadd double %689, %693
  store double %694, ptr %574, align 8
  %695 = getelementptr double, ptr %75, i64 %573
  %696 = load double, ptr %695, align 8
  %697 = load double, ptr %40, align 8
  %698 = fmul double %696, %697
  %699 = fadd double %694, %698
  store double %699, ptr %574, align 8
  %700 = getelementptr double, ptr %76, i64 %573
  %701 = load double, ptr %700, align 8
  %702 = load double, ptr %41, align 8
  %703 = fmul double %701, %702
  %704 = fadd double %699, %703
  store double %704, ptr %574, align 8
  %705 = getelementptr double, ptr %77, i64 %573
  %706 = load double, ptr %705, align 8
  %707 = load double, ptr %42, align 8
  %708 = fmul double %706, %707
  %709 = fadd double %704, %708
  store double %709, ptr %574, align 8
  %710 = getelementptr double, ptr %78, i64 %573
  %711 = load double, ptr %710, align 8
  %712 = load double, ptr %43, align 8
  %713 = fmul double %711, %712
  %714 = fadd double %709, %713
  store double %714, ptr %574, align 8
  %715 = getelementptr double, ptr %79, i64 %573
  %716 = load double, ptr %715, align 8
  %717 = load double, ptr %44, align 8
  %718 = fmul double %716, %717
  %719 = fadd double %714, %718
  store double %719, ptr %574, align 8
  %720 = getelementptr double, ptr %80, i64 %573
  %721 = load double, ptr %720, align 8
  %722 = load double, ptr %45, align 8
  %723 = fmul double %721, %722
  %724 = fadd double %719, %723
  store double %724, ptr %574, align 8
  %725 = getelementptr double, ptr %81, i64 %573
  %726 = load double, ptr %725, align 8
  %727 = load double, ptr %46, align 8
  %728 = fmul double %726, %727
  %729 = fadd double %724, %728
  store double %729, ptr %574, align 8
  %730 = getelementptr double, ptr %82, i64 %573
  %731 = load double, ptr %730, align 8
  %732 = load double, ptr %47, align 8
  %733 = fmul double %731, %732
  %734 = fadd double %729, %733
  store double %734, ptr %574, align 8
  %735 = add nuw nsw i64 %572, 1
  %exitcond.not = icmp eq i64 %735, 16
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %736 = add nuw nsw i64 %48, 16
  %737 = icmp ult i64 %48, 112
  br i1 %737, label %.preheader3, label %738

738:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!7, !2}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
