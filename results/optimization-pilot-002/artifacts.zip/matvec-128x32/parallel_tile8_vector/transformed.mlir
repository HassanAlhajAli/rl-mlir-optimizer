#map = affine_map<(d0) -> (0, d0)>
module {
  func.func @kernel(%arg0: memref<128x32xf64>, %arg1: memref<32xf64>, %arg2: memref<128xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c8 = arith.constant 8 : index
    %c0_0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<128xf64>)
    %c0_1 = arith.constant 0 : index
    %c128 = arith.constant 128 : index
    %c8_2 = arith.constant 8 : index
    scf.for %arg3 = %c0_1 to %c128 step %c8_2 {
      %subview = memref.subview %arg0[%arg3, 0] [8, 32] [1, 1] : memref<128x32xf64> to memref<8x32xf64, strided<[32, 1], offset: ?>>
      %subview_3 = memref.subview %arg2[%arg3] [8] [1] : memref<128xf64> to memref<8xf64, strided<[1], offset: ?>>
      %c0_4 = arith.constant 0 : index
      %c32 = arith.constant 32 : index
      %c1_5 = arith.constant 1 : index
      scf.for %arg4 = %c0_4 to %c32 step %c1_5 {
        %subview_6 = memref.subview %subview[0, %arg4] [8, 1] [1, 1] : memref<8x32xf64, strided<[32, 1], offset: ?>> to memref<8x1xf64, strided<[32, 1], offset: ?>>
        %subview_7 = memref.subview %arg1[%arg4] [1] [1] : memref<32xf64> to memref<1xf64, strided<[1], offset: ?>>
        %c8_8 = arith.constant 8 : index
        %c1_9 = arith.constant 1 : index
        %c0_10 = arith.constant 0 : index
        %cst_11 = arith.constant 0.000000e+00 : f64
        %0 = vector.transfer_read %subview_6[%c0_10, %c0_10], %cst_11 : memref<8x1xf64, strided<[32, 1], offset: ?>>, vector<8x1xf64>
        %cst_12 = arith.constant 0.000000e+00 : f64
        %1 = vector.transfer_read %subview_7[%c0_10], %cst_12 {permutation_map = #map} : memref<1xf64, strided<[1], offset: ?>>, vector<8x1xf64>
        %cst_13 = arith.constant 0.000000e+00 : f64
        %2 = vector.transfer_read %subview_3[%c0_10], %cst_13 : memref<8xf64, strided<[1], offset: ?>>, vector<8xf64>
        %3 = arith.mulf %0, %1 : vector<8x1xf64>
        %4 = vector.multi_reduction <add>, %3, %2 [1] : vector<8x1xf64> to vector<8xf64>
        %c0_14 = arith.constant 0 : index
        vector.transfer_write %4, %subview_3[%c0_14] : vector<8xf64>, memref<8xf64, strided<[1], offset: ?>>
      }
    }
    return
  }
}
