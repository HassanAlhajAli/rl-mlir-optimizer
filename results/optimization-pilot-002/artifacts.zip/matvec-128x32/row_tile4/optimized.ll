; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  %17 = getelementptr double, ptr %8, i64 1
  %18 = getelementptr double, ptr %8, i64 2
  %19 = getelementptr double, ptr %8, i64 3
  %20 = getelementptr double, ptr %8, i64 4
  %21 = getelementptr double, ptr %8, i64 5
  %22 = getelementptr double, ptr %8, i64 6
  %23 = getelementptr double, ptr %8, i64 7
  %24 = getelementptr double, ptr %8, i64 8
  %25 = getelementptr double, ptr %8, i64 9
  %26 = getelementptr double, ptr %8, i64 10
  %27 = getelementptr double, ptr %8, i64 11
  %28 = getelementptr double, ptr %8, i64 12
  %29 = getelementptr double, ptr %8, i64 13
  %30 = getelementptr double, ptr %8, i64 14
  %31 = getelementptr double, ptr %8, i64 15
  %32 = getelementptr double, ptr %8, i64 16
  %33 = getelementptr double, ptr %8, i64 17
  %34 = getelementptr double, ptr %8, i64 18
  %35 = getelementptr double, ptr %8, i64 19
  %36 = getelementptr double, ptr %8, i64 20
  %37 = getelementptr double, ptr %8, i64 21
  %38 = getelementptr double, ptr %8, i64 22
  %39 = getelementptr double, ptr %8, i64 23
  %40 = getelementptr double, ptr %8, i64 24
  %41 = getelementptr double, ptr %8, i64 25
  %42 = getelementptr double, ptr %8, i64 26
  %43 = getelementptr double, ptr %8, i64 27
  %44 = getelementptr double, ptr %8, i64 28
  %45 = getelementptr double, ptr %8, i64 29
  %46 = getelementptr double, ptr %8, i64 30
  %47 = getelementptr double, ptr %8, i64 31
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %247
  %48 = phi i64 [ %248, %247 ], [ 0, %.preheader3.preheader ]
  %49 = shl nuw nsw i64 %48, 5
  %50 = getelementptr double, ptr %1, i64 %49
  %51 = getelementptr double, ptr %13, i64 %48
  %52 = getelementptr double, ptr %50, i64 1
  %53 = getelementptr double, ptr %50, i64 2
  %54 = getelementptr double, ptr %50, i64 3
  %55 = getelementptr double, ptr %50, i64 4
  %56 = getelementptr double, ptr %50, i64 5
  %57 = getelementptr double, ptr %50, i64 6
  %58 = getelementptr double, ptr %50, i64 7
  %59 = getelementptr double, ptr %50, i64 8
  %60 = getelementptr double, ptr %50, i64 9
  %61 = getelementptr double, ptr %50, i64 10
  %62 = getelementptr double, ptr %50, i64 11
  %63 = getelementptr double, ptr %50, i64 12
  %64 = getelementptr double, ptr %50, i64 13
  %65 = getelementptr double, ptr %50, i64 14
  %66 = getelementptr double, ptr %50, i64 15
  %67 = getelementptr double, ptr %50, i64 16
  %68 = getelementptr double, ptr %50, i64 17
  %69 = getelementptr double, ptr %50, i64 18
  %70 = getelementptr double, ptr %50, i64 19
  %71 = getelementptr double, ptr %50, i64 20
  %72 = getelementptr double, ptr %50, i64 21
  %73 = getelementptr double, ptr %50, i64 22
  %74 = getelementptr double, ptr %50, i64 23
  %75 = getelementptr double, ptr %50, i64 24
  %76 = getelementptr double, ptr %50, i64 25
  %77 = getelementptr double, ptr %50, i64 26
  %78 = getelementptr double, ptr %50, i64 27
  %79 = getelementptr double, ptr %50, i64 28
  %80 = getelementptr double, ptr %50, i64 29
  %81 = getelementptr double, ptr %50, i64 30
  %82 = getelementptr double, ptr %50, i64 31
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %.preheader
  %83 = phi i64 [ 0, %.preheader3 ], [ %246, %.preheader ]
  %84 = shl i64 %83, 5
  %85 = getelementptr double, ptr %51, i64 %83
  %.promoted = load double, ptr %85, align 8
  %86 = getelementptr double, ptr %50, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = load double, ptr %8, align 8
  %89 = fmul double %87, %88
  %90 = fadd double %.promoted, %89
  store double %90, ptr %85, align 8
  %91 = getelementptr double, ptr %52, i64 %84
  %92 = load double, ptr %91, align 8
  %93 = load double, ptr %17, align 8
  %94 = fmul double %92, %93
  %95 = fadd double %90, %94
  store double %95, ptr %85, align 8
  %96 = getelementptr double, ptr %53, i64 %84
  %97 = load double, ptr %96, align 8
  %98 = load double, ptr %18, align 8
  %99 = fmul double %97, %98
  %100 = fadd double %95, %99
  store double %100, ptr %85, align 8
  %101 = getelementptr double, ptr %54, i64 %84
  %102 = load double, ptr %101, align 8
  %103 = load double, ptr %19, align 8
  %104 = fmul double %102, %103
  %105 = fadd double %100, %104
  store double %105, ptr %85, align 8
  %106 = getelementptr double, ptr %55, i64 %84
  %107 = load double, ptr %106, align 8
  %108 = load double, ptr %20, align 8
  %109 = fmul double %107, %108
  %110 = fadd double %105, %109
  store double %110, ptr %85, align 8
  %111 = getelementptr double, ptr %56, i64 %84
  %112 = load double, ptr %111, align 8
  %113 = load double, ptr %21, align 8
  %114 = fmul double %112, %113
  %115 = fadd double %110, %114
  store double %115, ptr %85, align 8
  %116 = getelementptr double, ptr %57, i64 %84
  %117 = load double, ptr %116, align 8
  %118 = load double, ptr %22, align 8
  %119 = fmul double %117, %118
  %120 = fadd double %115, %119
  store double %120, ptr %85, align 8
  %121 = getelementptr double, ptr %58, i64 %84
  %122 = load double, ptr %121, align 8
  %123 = load double, ptr %23, align 8
  %124 = fmul double %122, %123
  %125 = fadd double %120, %124
  store double %125, ptr %85, align 8
  %126 = getelementptr double, ptr %59, i64 %84
  %127 = load double, ptr %126, align 8
  %128 = load double, ptr %24, align 8
  %129 = fmul double %127, %128
  %130 = fadd double %125, %129
  store double %130, ptr %85, align 8
  %131 = getelementptr double, ptr %60, i64 %84
  %132 = load double, ptr %131, align 8
  %133 = load double, ptr %25, align 8
  %134 = fmul double %132, %133
  %135 = fadd double %130, %134
  store double %135, ptr %85, align 8
  %136 = getelementptr double, ptr %61, i64 %84
  %137 = load double, ptr %136, align 8
  %138 = load double, ptr %26, align 8
  %139 = fmul double %137, %138
  %140 = fadd double %135, %139
  store double %140, ptr %85, align 8
  %141 = getelementptr double, ptr %62, i64 %84
  %142 = load double, ptr %141, align 8
  %143 = load double, ptr %27, align 8
  %144 = fmul double %142, %143
  %145 = fadd double %140, %144
  store double %145, ptr %85, align 8
  %146 = getelementptr double, ptr %63, i64 %84
  %147 = load double, ptr %146, align 8
  %148 = load double, ptr %28, align 8
  %149 = fmul double %147, %148
  %150 = fadd double %145, %149
  store double %150, ptr %85, align 8
  %151 = getelementptr double, ptr %64, i64 %84
  %152 = load double, ptr %151, align 8
  %153 = load double, ptr %29, align 8
  %154 = fmul double %152, %153
  %155 = fadd double %150, %154
  store double %155, ptr %85, align 8
  %156 = getelementptr double, ptr %65, i64 %84
  %157 = load double, ptr %156, align 8
  %158 = load double, ptr %30, align 8
  %159 = fmul double %157, %158
  %160 = fadd double %155, %159
  store double %160, ptr %85, align 8
  %161 = getelementptr double, ptr %66, i64 %84
  %162 = load double, ptr %161, align 8
  %163 = load double, ptr %31, align 8
  %164 = fmul double %162, %163
  %165 = fadd double %160, %164
  store double %165, ptr %85, align 8
  %166 = getelementptr double, ptr %67, i64 %84
  %167 = load double, ptr %166, align 8
  %168 = load double, ptr %32, align 8
  %169 = fmul double %167, %168
  %170 = fadd double %165, %169
  store double %170, ptr %85, align 8
  %171 = getelementptr double, ptr %68, i64 %84
  %172 = load double, ptr %171, align 8
  %173 = load double, ptr %33, align 8
  %174 = fmul double %172, %173
  %175 = fadd double %170, %174
  store double %175, ptr %85, align 8
  %176 = getelementptr double, ptr %69, i64 %84
  %177 = load double, ptr %176, align 8
  %178 = load double, ptr %34, align 8
  %179 = fmul double %177, %178
  %180 = fadd double %175, %179
  store double %180, ptr %85, align 8
  %181 = getelementptr double, ptr %70, i64 %84
  %182 = load double, ptr %181, align 8
  %183 = load double, ptr %35, align 8
  %184 = fmul double %182, %183
  %185 = fadd double %180, %184
  store double %185, ptr %85, align 8
  %186 = getelementptr double, ptr %71, i64 %84
  %187 = load double, ptr %186, align 8
  %188 = load double, ptr %36, align 8
  %189 = fmul double %187, %188
  %190 = fadd double %185, %189
  store double %190, ptr %85, align 8
  %191 = getelementptr double, ptr %72, i64 %84
  %192 = load double, ptr %191, align 8
  %193 = load double, ptr %37, align 8
  %194 = fmul double %192, %193
  %195 = fadd double %190, %194
  store double %195, ptr %85, align 8
  %196 = getelementptr double, ptr %73, i64 %84
  %197 = load double, ptr %196, align 8
  %198 = load double, ptr %38, align 8
  %199 = fmul double %197, %198
  %200 = fadd double %195, %199
  store double %200, ptr %85, align 8
  %201 = getelementptr double, ptr %74, i64 %84
  %202 = load double, ptr %201, align 8
  %203 = load double, ptr %39, align 8
  %204 = fmul double %202, %203
  %205 = fadd double %200, %204
  store double %205, ptr %85, align 8
  %206 = getelementptr double, ptr %75, i64 %84
  %207 = load double, ptr %206, align 8
  %208 = load double, ptr %40, align 8
  %209 = fmul double %207, %208
  %210 = fadd double %205, %209
  store double %210, ptr %85, align 8
  %211 = getelementptr double, ptr %76, i64 %84
  %212 = load double, ptr %211, align 8
  %213 = load double, ptr %41, align 8
  %214 = fmul double %212, %213
  %215 = fadd double %210, %214
  store double %215, ptr %85, align 8
  %216 = getelementptr double, ptr %77, i64 %84
  %217 = load double, ptr %216, align 8
  %218 = load double, ptr %42, align 8
  %219 = fmul double %217, %218
  %220 = fadd double %215, %219
  store double %220, ptr %85, align 8
  %221 = getelementptr double, ptr %78, i64 %84
  %222 = load double, ptr %221, align 8
  %223 = load double, ptr %43, align 8
  %224 = fmul double %222, %223
  %225 = fadd double %220, %224
  store double %225, ptr %85, align 8
  %226 = getelementptr double, ptr %79, i64 %84
  %227 = load double, ptr %226, align 8
  %228 = load double, ptr %44, align 8
  %229 = fmul double %227, %228
  %230 = fadd double %225, %229
  store double %230, ptr %85, align 8
  %231 = getelementptr double, ptr %80, i64 %84
  %232 = load double, ptr %231, align 8
  %233 = load double, ptr %45, align 8
  %234 = fmul double %232, %233
  %235 = fadd double %230, %234
  store double %235, ptr %85, align 8
  %236 = getelementptr double, ptr %81, i64 %84
  %237 = load double, ptr %236, align 8
  %238 = load double, ptr %46, align 8
  %239 = fmul double %237, %238
  %240 = fadd double %235, %239
  store double %240, ptr %85, align 8
  %241 = getelementptr double, ptr %82, i64 %84
  %242 = load double, ptr %241, align 8
  %243 = load double, ptr %47, align 8
  %244 = fmul double %242, %243
  %245 = fadd double %240, %244
  store double %245, ptr %85, align 8
  %246 = add nuw nsw i64 %83, 1
  %exitcond.not = icmp eq i64 %246, 4
  br i1 %exitcond.not, label %247, label %.preheader

247:                                              ; preds = %.preheader
  %248 = add nuw nsw i64 %48, 4
  %249 = icmp ult i64 %48, 124
  br i1 %249, label %.preheader3, label %250

250:                                              ; preds = %247
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
