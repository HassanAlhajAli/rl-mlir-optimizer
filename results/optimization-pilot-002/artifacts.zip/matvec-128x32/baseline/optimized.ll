; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  %17 = getelementptr double, ptr %1, i64 1
  %18 = getelementptr double, ptr %8, i64 1
  %19 = getelementptr double, ptr %1, i64 2
  %20 = getelementptr double, ptr %8, i64 2
  %21 = getelementptr double, ptr %1, i64 3
  %22 = getelementptr double, ptr %8, i64 3
  %23 = getelementptr double, ptr %1, i64 4
  %24 = getelementptr double, ptr %8, i64 4
  %25 = getelementptr double, ptr %1, i64 5
  %26 = getelementptr double, ptr %8, i64 5
  %27 = getelementptr double, ptr %1, i64 6
  %28 = getelementptr double, ptr %8, i64 6
  %29 = getelementptr double, ptr %1, i64 7
  %30 = getelementptr double, ptr %8, i64 7
  %31 = getelementptr double, ptr %1, i64 8
  %32 = getelementptr double, ptr %8, i64 8
  %33 = getelementptr double, ptr %1, i64 9
  %34 = getelementptr double, ptr %8, i64 9
  %35 = getelementptr double, ptr %1, i64 10
  %36 = getelementptr double, ptr %8, i64 10
  %37 = getelementptr double, ptr %1, i64 11
  %38 = getelementptr double, ptr %8, i64 11
  %39 = getelementptr double, ptr %1, i64 12
  %40 = getelementptr double, ptr %8, i64 12
  %41 = getelementptr double, ptr %1, i64 13
  %42 = getelementptr double, ptr %8, i64 13
  %43 = getelementptr double, ptr %1, i64 14
  %44 = getelementptr double, ptr %8, i64 14
  %45 = getelementptr double, ptr %1, i64 15
  %46 = getelementptr double, ptr %8, i64 15
  %47 = getelementptr double, ptr %1, i64 16
  %48 = getelementptr double, ptr %8, i64 16
  %49 = getelementptr double, ptr %1, i64 17
  %50 = getelementptr double, ptr %8, i64 17
  %51 = getelementptr double, ptr %1, i64 18
  %52 = getelementptr double, ptr %8, i64 18
  %53 = getelementptr double, ptr %1, i64 19
  %54 = getelementptr double, ptr %8, i64 19
  %55 = getelementptr double, ptr %1, i64 20
  %56 = getelementptr double, ptr %8, i64 20
  %57 = getelementptr double, ptr %1, i64 21
  %58 = getelementptr double, ptr %8, i64 21
  %59 = getelementptr double, ptr %1, i64 22
  %60 = getelementptr double, ptr %8, i64 22
  %61 = getelementptr double, ptr %1, i64 23
  %62 = getelementptr double, ptr %8, i64 23
  %63 = getelementptr double, ptr %1, i64 24
  %64 = getelementptr double, ptr %8, i64 24
  %65 = getelementptr double, ptr %1, i64 25
  %66 = getelementptr double, ptr %8, i64 25
  %67 = getelementptr double, ptr %1, i64 26
  %68 = getelementptr double, ptr %8, i64 26
  %69 = getelementptr double, ptr %1, i64 27
  %70 = getelementptr double, ptr %8, i64 27
  %71 = getelementptr double, ptr %1, i64 28
  %72 = getelementptr double, ptr %8, i64 28
  %73 = getelementptr double, ptr %1, i64 29
  %74 = getelementptr double, ptr %8, i64 29
  %75 = getelementptr double, ptr %1, i64 30
  %76 = getelementptr double, ptr %8, i64 30
  %77 = getelementptr double, ptr %1, i64 31
  %78 = getelementptr double, ptr %8, i64 31
  %scevgep = getelementptr i8, ptr %13, i64 1024
  %scevgep3 = getelementptr i8, ptr %1, i64 32768
  %scevgep4 = getelementptr i8, ptr %8, i64 256
  %bound0 = icmp ugt ptr %scevgep3, %13
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound05 = icmp ugt ptr %scevgep4, %13
  %bound16 = icmp ugt ptr %scevgep, %8
  %found.conflict7 = and i1 %bound05, %bound16
  %conflict.rdx = or i1 %found.conflict, %found.conflict7
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader.preheader
  %79 = load double, ptr %8, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %79, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %80 = load double, ptr %18, align 8, !alias.scope !1
  %broadcast.splatinsert8 = insertelement <4 x double> poison, double %80, i64 0
  %broadcast.splat9 = shufflevector <4 x double> %broadcast.splatinsert8, <4 x double> poison, <4 x i32> zeroinitializer
  %81 = load double, ptr %20, align 8, !alias.scope !1
  %broadcast.splatinsert10 = insertelement <4 x double> poison, double %81, i64 0
  %broadcast.splat11 = shufflevector <4 x double> %broadcast.splatinsert10, <4 x double> poison, <4 x i32> zeroinitializer
  %82 = load double, ptr %22, align 8, !alias.scope !1
  %broadcast.splatinsert12 = insertelement <4 x double> poison, double %82, i64 0
  %broadcast.splat13 = shufflevector <4 x double> %broadcast.splatinsert12, <4 x double> poison, <4 x i32> zeroinitializer
  %83 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert14 = insertelement <4 x double> poison, double %83, i64 0
  %broadcast.splat15 = shufflevector <4 x double> %broadcast.splatinsert14, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %84, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %85 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert18 = insertelement <4 x double> poison, double %85, i64 0
  %broadcast.splat19 = shufflevector <4 x double> %broadcast.splatinsert18, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert20 = insertelement <4 x double> poison, double %86, i64 0
  %broadcast.splat21 = shufflevector <4 x double> %broadcast.splatinsert20, <4 x double> poison, <4 x i32> zeroinitializer
  %87 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %87, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %88 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert24 = insertelement <4 x double> poison, double %88, i64 0
  %broadcast.splat25 = shufflevector <4 x double> %broadcast.splatinsert24, <4 x double> poison, <4 x i32> zeroinitializer
  %89 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert26 = insertelement <4 x double> poison, double %89, i64 0
  %broadcast.splat27 = shufflevector <4 x double> %broadcast.splatinsert26, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %90, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert30 = insertelement <4 x double> poison, double %91, i64 0
  %broadcast.splat31 = shufflevector <4 x double> %broadcast.splatinsert30, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert32 = insertelement <4 x double> poison, double %92, i64 0
  %broadcast.splat33 = shufflevector <4 x double> %broadcast.splatinsert32, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert36 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat37 = shufflevector <4 x double> %broadcast.splatinsert36, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert38 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat39 = shufflevector <4 x double> %broadcast.splatinsert38, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert42 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat43 = shufflevector <4 x double> %broadcast.splatinsert42, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert44 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat45 = shufflevector <4 x double> %broadcast.splatinsert44, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %58, align 8, !alias.scope !1
  %broadcast.splatinsert48 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat49 = shufflevector <4 x double> %broadcast.splatinsert48, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %60, align 8, !alias.scope !1
  %broadcast.splatinsert50 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat51 = shufflevector <4 x double> %broadcast.splatinsert50, <4 x double> poison, <4 x i32> zeroinitializer
  %102 = load double, ptr %62, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %102, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %103 = load double, ptr %64, align 8, !alias.scope !1
  %broadcast.splatinsert54 = insertelement <4 x double> poison, double %103, i64 0
  %broadcast.splat55 = shufflevector <4 x double> %broadcast.splatinsert54, <4 x double> poison, <4 x i32> zeroinitializer
  %104 = load double, ptr %66, align 8, !alias.scope !1
  %broadcast.splatinsert56 = insertelement <4 x double> poison, double %104, i64 0
  %broadcast.splat57 = shufflevector <4 x double> %broadcast.splatinsert56, <4 x double> poison, <4 x i32> zeroinitializer
  %105 = load double, ptr %68, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %105, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %106 = load double, ptr %70, align 8, !alias.scope !1
  %broadcast.splatinsert60 = insertelement <4 x double> poison, double %106, i64 0
  %broadcast.splat61 = shufflevector <4 x double> %broadcast.splatinsert60, <4 x double> poison, <4 x i32> zeroinitializer
  %107 = load double, ptr %72, align 8, !alias.scope !1
  %broadcast.splatinsert62 = insertelement <4 x double> poison, double %107, i64 0
  %broadcast.splat63 = shufflevector <4 x double> %broadcast.splatinsert62, <4 x double> poison, <4 x i32> zeroinitializer
  %108 = load double, ptr %74, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %108, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %109 = load double, ptr %76, align 8, !alias.scope !1
  %broadcast.splatinsert66 = insertelement <4 x double> poison, double %109, i64 0
  %broadcast.splat67 = shufflevector <4 x double> %broadcast.splatinsert66, <4 x double> poison, <4 x i32> zeroinitializer
  %110 = load double, ptr %78, align 8, !alias.scope !1
  %broadcast.splatinsert68 = insertelement <4 x double> poison, double %110, i64 0
  %broadcast.splat69 = shufflevector <4 x double> %broadcast.splatinsert68, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %111 = shl i64 %index, 5
  %112 = shl i64 %index, 5
  %113 = or disjoint i64 %112, 32
  %114 = shl i64 %index, 5
  %115 = or disjoint i64 %114, 64
  %116 = shl i64 %index, 5
  %117 = or disjoint i64 %116, 96
  %118 = getelementptr double, ptr %13, i64 %index
  %wide.load = load <4 x double>, ptr %118, align 8, !alias.scope !4, !noalias !6
  %119 = getelementptr double, ptr %1, i64 %111
  %120 = getelementptr double, ptr %1, i64 %113
  %121 = getelementptr double, ptr %1, i64 %115
  %122 = getelementptr double, ptr %1, i64 %117
  %123 = load double, ptr %119, align 8, !alias.scope !8
  %124 = load double, ptr %120, align 8, !alias.scope !8
  %125 = load double, ptr %121, align 8, !alias.scope !8
  %126 = load double, ptr %122, align 8, !alias.scope !8
  %127 = insertelement <4 x double> poison, double %123, i64 0
  %128 = insertelement <4 x double> %127, double %124, i64 1
  %129 = insertelement <4 x double> %128, double %125, i64 2
  %130 = insertelement <4 x double> %129, double %126, i64 3
  %131 = fmul <4 x double> %130, %broadcast.splat
  %132 = fadd <4 x double> %wide.load, %131
  store <4 x double> %132, ptr %118, align 8, !alias.scope !4, !noalias !6
  %133 = getelementptr double, ptr %17, i64 %111
  %134 = getelementptr double, ptr %17, i64 %113
  %135 = getelementptr double, ptr %17, i64 %115
  %136 = getelementptr double, ptr %17, i64 %117
  %137 = load double, ptr %133, align 8, !alias.scope !8
  %138 = load double, ptr %134, align 8, !alias.scope !8
  %139 = load double, ptr %135, align 8, !alias.scope !8
  %140 = load double, ptr %136, align 8, !alias.scope !8
  %141 = insertelement <4 x double> poison, double %137, i64 0
  %142 = insertelement <4 x double> %141, double %138, i64 1
  %143 = insertelement <4 x double> %142, double %139, i64 2
  %144 = insertelement <4 x double> %143, double %140, i64 3
  %145 = fmul <4 x double> %144, %broadcast.splat9
  %146 = fadd <4 x double> %132, %145
  store <4 x double> %146, ptr %118, align 8, !alias.scope !4, !noalias !6
  %147 = getelementptr double, ptr %19, i64 %111
  %148 = getelementptr double, ptr %19, i64 %113
  %149 = getelementptr double, ptr %19, i64 %115
  %150 = getelementptr double, ptr %19, i64 %117
  %151 = load double, ptr %147, align 8, !alias.scope !8
  %152 = load double, ptr %148, align 8, !alias.scope !8
  %153 = load double, ptr %149, align 8, !alias.scope !8
  %154 = load double, ptr %150, align 8, !alias.scope !8
  %155 = insertelement <4 x double> poison, double %151, i64 0
  %156 = insertelement <4 x double> %155, double %152, i64 1
  %157 = insertelement <4 x double> %156, double %153, i64 2
  %158 = insertelement <4 x double> %157, double %154, i64 3
  %159 = fmul <4 x double> %158, %broadcast.splat11
  %160 = fadd <4 x double> %146, %159
  store <4 x double> %160, ptr %118, align 8, !alias.scope !4, !noalias !6
  %161 = getelementptr double, ptr %21, i64 %111
  %162 = getelementptr double, ptr %21, i64 %113
  %163 = getelementptr double, ptr %21, i64 %115
  %164 = getelementptr double, ptr %21, i64 %117
  %165 = load double, ptr %161, align 8, !alias.scope !8
  %166 = load double, ptr %162, align 8, !alias.scope !8
  %167 = load double, ptr %163, align 8, !alias.scope !8
  %168 = load double, ptr %164, align 8, !alias.scope !8
  %169 = insertelement <4 x double> poison, double %165, i64 0
  %170 = insertelement <4 x double> %169, double %166, i64 1
  %171 = insertelement <4 x double> %170, double %167, i64 2
  %172 = insertelement <4 x double> %171, double %168, i64 3
  %173 = fmul <4 x double> %172, %broadcast.splat13
  %174 = fadd <4 x double> %160, %173
  store <4 x double> %174, ptr %118, align 8, !alias.scope !4, !noalias !6
  %175 = getelementptr double, ptr %23, i64 %111
  %176 = getelementptr double, ptr %23, i64 %113
  %177 = getelementptr double, ptr %23, i64 %115
  %178 = getelementptr double, ptr %23, i64 %117
  %179 = load double, ptr %175, align 8, !alias.scope !8
  %180 = load double, ptr %176, align 8, !alias.scope !8
  %181 = load double, ptr %177, align 8, !alias.scope !8
  %182 = load double, ptr %178, align 8, !alias.scope !8
  %183 = insertelement <4 x double> poison, double %179, i64 0
  %184 = insertelement <4 x double> %183, double %180, i64 1
  %185 = insertelement <4 x double> %184, double %181, i64 2
  %186 = insertelement <4 x double> %185, double %182, i64 3
  %187 = fmul <4 x double> %186, %broadcast.splat15
  %188 = fadd <4 x double> %174, %187
  store <4 x double> %188, ptr %118, align 8, !alias.scope !4, !noalias !6
  %189 = getelementptr double, ptr %25, i64 %111
  %190 = getelementptr double, ptr %25, i64 %113
  %191 = getelementptr double, ptr %25, i64 %115
  %192 = getelementptr double, ptr %25, i64 %117
  %193 = load double, ptr %189, align 8, !alias.scope !8
  %194 = load double, ptr %190, align 8, !alias.scope !8
  %195 = load double, ptr %191, align 8, !alias.scope !8
  %196 = load double, ptr %192, align 8, !alias.scope !8
  %197 = insertelement <4 x double> poison, double %193, i64 0
  %198 = insertelement <4 x double> %197, double %194, i64 1
  %199 = insertelement <4 x double> %198, double %195, i64 2
  %200 = insertelement <4 x double> %199, double %196, i64 3
  %201 = fmul <4 x double> %200, %broadcast.splat17
  %202 = fadd <4 x double> %188, %201
  store <4 x double> %202, ptr %118, align 8, !alias.scope !4, !noalias !6
  %203 = getelementptr double, ptr %27, i64 %111
  %204 = getelementptr double, ptr %27, i64 %113
  %205 = getelementptr double, ptr %27, i64 %115
  %206 = getelementptr double, ptr %27, i64 %117
  %207 = load double, ptr %203, align 8, !alias.scope !8
  %208 = load double, ptr %204, align 8, !alias.scope !8
  %209 = load double, ptr %205, align 8, !alias.scope !8
  %210 = load double, ptr %206, align 8, !alias.scope !8
  %211 = insertelement <4 x double> poison, double %207, i64 0
  %212 = insertelement <4 x double> %211, double %208, i64 1
  %213 = insertelement <4 x double> %212, double %209, i64 2
  %214 = insertelement <4 x double> %213, double %210, i64 3
  %215 = fmul <4 x double> %214, %broadcast.splat19
  %216 = fadd <4 x double> %202, %215
  store <4 x double> %216, ptr %118, align 8, !alias.scope !4, !noalias !6
  %217 = getelementptr double, ptr %29, i64 %111
  %218 = getelementptr double, ptr %29, i64 %113
  %219 = getelementptr double, ptr %29, i64 %115
  %220 = getelementptr double, ptr %29, i64 %117
  %221 = load double, ptr %217, align 8, !alias.scope !8
  %222 = load double, ptr %218, align 8, !alias.scope !8
  %223 = load double, ptr %219, align 8, !alias.scope !8
  %224 = load double, ptr %220, align 8, !alias.scope !8
  %225 = insertelement <4 x double> poison, double %221, i64 0
  %226 = insertelement <4 x double> %225, double %222, i64 1
  %227 = insertelement <4 x double> %226, double %223, i64 2
  %228 = insertelement <4 x double> %227, double %224, i64 3
  %229 = fmul <4 x double> %228, %broadcast.splat21
  %230 = fadd <4 x double> %216, %229
  store <4 x double> %230, ptr %118, align 8, !alias.scope !4, !noalias !6
  %231 = getelementptr double, ptr %31, i64 %111
  %232 = getelementptr double, ptr %31, i64 %113
  %233 = getelementptr double, ptr %31, i64 %115
  %234 = getelementptr double, ptr %31, i64 %117
  %235 = load double, ptr %231, align 8, !alias.scope !8
  %236 = load double, ptr %232, align 8, !alias.scope !8
  %237 = load double, ptr %233, align 8, !alias.scope !8
  %238 = load double, ptr %234, align 8, !alias.scope !8
  %239 = insertelement <4 x double> poison, double %235, i64 0
  %240 = insertelement <4 x double> %239, double %236, i64 1
  %241 = insertelement <4 x double> %240, double %237, i64 2
  %242 = insertelement <4 x double> %241, double %238, i64 3
  %243 = fmul <4 x double> %242, %broadcast.splat23
  %244 = fadd <4 x double> %230, %243
  store <4 x double> %244, ptr %118, align 8, !alias.scope !4, !noalias !6
  %245 = getelementptr double, ptr %33, i64 %111
  %246 = getelementptr double, ptr %33, i64 %113
  %247 = getelementptr double, ptr %33, i64 %115
  %248 = getelementptr double, ptr %33, i64 %117
  %249 = load double, ptr %245, align 8, !alias.scope !8
  %250 = load double, ptr %246, align 8, !alias.scope !8
  %251 = load double, ptr %247, align 8, !alias.scope !8
  %252 = load double, ptr %248, align 8, !alias.scope !8
  %253 = insertelement <4 x double> poison, double %249, i64 0
  %254 = insertelement <4 x double> %253, double %250, i64 1
  %255 = insertelement <4 x double> %254, double %251, i64 2
  %256 = insertelement <4 x double> %255, double %252, i64 3
  %257 = fmul <4 x double> %256, %broadcast.splat25
  %258 = fadd <4 x double> %244, %257
  store <4 x double> %258, ptr %118, align 8, !alias.scope !4, !noalias !6
  %259 = getelementptr double, ptr %35, i64 %111
  %260 = getelementptr double, ptr %35, i64 %113
  %261 = getelementptr double, ptr %35, i64 %115
  %262 = getelementptr double, ptr %35, i64 %117
  %263 = load double, ptr %259, align 8, !alias.scope !8
  %264 = load double, ptr %260, align 8, !alias.scope !8
  %265 = load double, ptr %261, align 8, !alias.scope !8
  %266 = load double, ptr %262, align 8, !alias.scope !8
  %267 = insertelement <4 x double> poison, double %263, i64 0
  %268 = insertelement <4 x double> %267, double %264, i64 1
  %269 = insertelement <4 x double> %268, double %265, i64 2
  %270 = insertelement <4 x double> %269, double %266, i64 3
  %271 = fmul <4 x double> %270, %broadcast.splat27
  %272 = fadd <4 x double> %258, %271
  store <4 x double> %272, ptr %118, align 8, !alias.scope !4, !noalias !6
  %273 = getelementptr double, ptr %37, i64 %111
  %274 = getelementptr double, ptr %37, i64 %113
  %275 = getelementptr double, ptr %37, i64 %115
  %276 = getelementptr double, ptr %37, i64 %117
  %277 = load double, ptr %273, align 8, !alias.scope !8
  %278 = load double, ptr %274, align 8, !alias.scope !8
  %279 = load double, ptr %275, align 8, !alias.scope !8
  %280 = load double, ptr %276, align 8, !alias.scope !8
  %281 = insertelement <4 x double> poison, double %277, i64 0
  %282 = insertelement <4 x double> %281, double %278, i64 1
  %283 = insertelement <4 x double> %282, double %279, i64 2
  %284 = insertelement <4 x double> %283, double %280, i64 3
  %285 = fmul <4 x double> %284, %broadcast.splat29
  %286 = fadd <4 x double> %272, %285
  store <4 x double> %286, ptr %118, align 8, !alias.scope !4, !noalias !6
  %287 = getelementptr double, ptr %39, i64 %111
  %288 = getelementptr double, ptr %39, i64 %113
  %289 = getelementptr double, ptr %39, i64 %115
  %290 = getelementptr double, ptr %39, i64 %117
  %291 = load double, ptr %287, align 8, !alias.scope !8
  %292 = load double, ptr %288, align 8, !alias.scope !8
  %293 = load double, ptr %289, align 8, !alias.scope !8
  %294 = load double, ptr %290, align 8, !alias.scope !8
  %295 = insertelement <4 x double> poison, double %291, i64 0
  %296 = insertelement <4 x double> %295, double %292, i64 1
  %297 = insertelement <4 x double> %296, double %293, i64 2
  %298 = insertelement <4 x double> %297, double %294, i64 3
  %299 = fmul <4 x double> %298, %broadcast.splat31
  %300 = fadd <4 x double> %286, %299
  store <4 x double> %300, ptr %118, align 8, !alias.scope !4, !noalias !6
  %301 = getelementptr double, ptr %41, i64 %111
  %302 = getelementptr double, ptr %41, i64 %113
  %303 = getelementptr double, ptr %41, i64 %115
  %304 = getelementptr double, ptr %41, i64 %117
  %305 = load double, ptr %301, align 8, !alias.scope !8
  %306 = load double, ptr %302, align 8, !alias.scope !8
  %307 = load double, ptr %303, align 8, !alias.scope !8
  %308 = load double, ptr %304, align 8, !alias.scope !8
  %309 = insertelement <4 x double> poison, double %305, i64 0
  %310 = insertelement <4 x double> %309, double %306, i64 1
  %311 = insertelement <4 x double> %310, double %307, i64 2
  %312 = insertelement <4 x double> %311, double %308, i64 3
  %313 = fmul <4 x double> %312, %broadcast.splat33
  %314 = fadd <4 x double> %300, %313
  store <4 x double> %314, ptr %118, align 8, !alias.scope !4, !noalias !6
  %315 = getelementptr double, ptr %43, i64 %111
  %316 = getelementptr double, ptr %43, i64 %113
  %317 = getelementptr double, ptr %43, i64 %115
  %318 = getelementptr double, ptr %43, i64 %117
  %319 = load double, ptr %315, align 8, !alias.scope !8
  %320 = load double, ptr %316, align 8, !alias.scope !8
  %321 = load double, ptr %317, align 8, !alias.scope !8
  %322 = load double, ptr %318, align 8, !alias.scope !8
  %323 = insertelement <4 x double> poison, double %319, i64 0
  %324 = insertelement <4 x double> %323, double %320, i64 1
  %325 = insertelement <4 x double> %324, double %321, i64 2
  %326 = insertelement <4 x double> %325, double %322, i64 3
  %327 = fmul <4 x double> %326, %broadcast.splat35
  %328 = fadd <4 x double> %314, %327
  store <4 x double> %328, ptr %118, align 8, !alias.scope !4, !noalias !6
  %329 = getelementptr double, ptr %45, i64 %111
  %330 = getelementptr double, ptr %45, i64 %113
  %331 = getelementptr double, ptr %45, i64 %115
  %332 = getelementptr double, ptr %45, i64 %117
  %333 = load double, ptr %329, align 8, !alias.scope !8
  %334 = load double, ptr %330, align 8, !alias.scope !8
  %335 = load double, ptr %331, align 8, !alias.scope !8
  %336 = load double, ptr %332, align 8, !alias.scope !8
  %337 = insertelement <4 x double> poison, double %333, i64 0
  %338 = insertelement <4 x double> %337, double %334, i64 1
  %339 = insertelement <4 x double> %338, double %335, i64 2
  %340 = insertelement <4 x double> %339, double %336, i64 3
  %341 = fmul <4 x double> %340, %broadcast.splat37
  %342 = fadd <4 x double> %328, %341
  store <4 x double> %342, ptr %118, align 8, !alias.scope !4, !noalias !6
  %343 = getelementptr double, ptr %47, i64 %111
  %344 = getelementptr double, ptr %47, i64 %113
  %345 = getelementptr double, ptr %47, i64 %115
  %346 = getelementptr double, ptr %47, i64 %117
  %347 = load double, ptr %343, align 8, !alias.scope !8
  %348 = load double, ptr %344, align 8, !alias.scope !8
  %349 = load double, ptr %345, align 8, !alias.scope !8
  %350 = load double, ptr %346, align 8, !alias.scope !8
  %351 = insertelement <4 x double> poison, double %347, i64 0
  %352 = insertelement <4 x double> %351, double %348, i64 1
  %353 = insertelement <4 x double> %352, double %349, i64 2
  %354 = insertelement <4 x double> %353, double %350, i64 3
  %355 = fmul <4 x double> %354, %broadcast.splat39
  %356 = fadd <4 x double> %342, %355
  store <4 x double> %356, ptr %118, align 8, !alias.scope !4, !noalias !6
  %357 = getelementptr double, ptr %49, i64 %111
  %358 = getelementptr double, ptr %49, i64 %113
  %359 = getelementptr double, ptr %49, i64 %115
  %360 = getelementptr double, ptr %49, i64 %117
  %361 = load double, ptr %357, align 8, !alias.scope !8
  %362 = load double, ptr %358, align 8, !alias.scope !8
  %363 = load double, ptr %359, align 8, !alias.scope !8
  %364 = load double, ptr %360, align 8, !alias.scope !8
  %365 = insertelement <4 x double> poison, double %361, i64 0
  %366 = insertelement <4 x double> %365, double %362, i64 1
  %367 = insertelement <4 x double> %366, double %363, i64 2
  %368 = insertelement <4 x double> %367, double %364, i64 3
  %369 = fmul <4 x double> %368, %broadcast.splat41
  %370 = fadd <4 x double> %356, %369
  store <4 x double> %370, ptr %118, align 8, !alias.scope !4, !noalias !6
  %371 = getelementptr double, ptr %51, i64 %111
  %372 = getelementptr double, ptr %51, i64 %113
  %373 = getelementptr double, ptr %51, i64 %115
  %374 = getelementptr double, ptr %51, i64 %117
  %375 = load double, ptr %371, align 8, !alias.scope !8
  %376 = load double, ptr %372, align 8, !alias.scope !8
  %377 = load double, ptr %373, align 8, !alias.scope !8
  %378 = load double, ptr %374, align 8, !alias.scope !8
  %379 = insertelement <4 x double> poison, double %375, i64 0
  %380 = insertelement <4 x double> %379, double %376, i64 1
  %381 = insertelement <4 x double> %380, double %377, i64 2
  %382 = insertelement <4 x double> %381, double %378, i64 3
  %383 = fmul <4 x double> %382, %broadcast.splat43
  %384 = fadd <4 x double> %370, %383
  store <4 x double> %384, ptr %118, align 8, !alias.scope !4, !noalias !6
  %385 = getelementptr double, ptr %53, i64 %111
  %386 = getelementptr double, ptr %53, i64 %113
  %387 = getelementptr double, ptr %53, i64 %115
  %388 = getelementptr double, ptr %53, i64 %117
  %389 = load double, ptr %385, align 8, !alias.scope !8
  %390 = load double, ptr %386, align 8, !alias.scope !8
  %391 = load double, ptr %387, align 8, !alias.scope !8
  %392 = load double, ptr %388, align 8, !alias.scope !8
  %393 = insertelement <4 x double> poison, double %389, i64 0
  %394 = insertelement <4 x double> %393, double %390, i64 1
  %395 = insertelement <4 x double> %394, double %391, i64 2
  %396 = insertelement <4 x double> %395, double %392, i64 3
  %397 = fmul <4 x double> %396, %broadcast.splat45
  %398 = fadd <4 x double> %384, %397
  store <4 x double> %398, ptr %118, align 8, !alias.scope !4, !noalias !6
  %399 = getelementptr double, ptr %55, i64 %111
  %400 = getelementptr double, ptr %55, i64 %113
  %401 = getelementptr double, ptr %55, i64 %115
  %402 = getelementptr double, ptr %55, i64 %117
  %403 = load double, ptr %399, align 8, !alias.scope !8
  %404 = load double, ptr %400, align 8, !alias.scope !8
  %405 = load double, ptr %401, align 8, !alias.scope !8
  %406 = load double, ptr %402, align 8, !alias.scope !8
  %407 = insertelement <4 x double> poison, double %403, i64 0
  %408 = insertelement <4 x double> %407, double %404, i64 1
  %409 = insertelement <4 x double> %408, double %405, i64 2
  %410 = insertelement <4 x double> %409, double %406, i64 3
  %411 = fmul <4 x double> %410, %broadcast.splat47
  %412 = fadd <4 x double> %398, %411
  store <4 x double> %412, ptr %118, align 8, !alias.scope !4, !noalias !6
  %413 = getelementptr double, ptr %57, i64 %111
  %414 = getelementptr double, ptr %57, i64 %113
  %415 = getelementptr double, ptr %57, i64 %115
  %416 = getelementptr double, ptr %57, i64 %117
  %417 = load double, ptr %413, align 8, !alias.scope !8
  %418 = load double, ptr %414, align 8, !alias.scope !8
  %419 = load double, ptr %415, align 8, !alias.scope !8
  %420 = load double, ptr %416, align 8, !alias.scope !8
  %421 = insertelement <4 x double> poison, double %417, i64 0
  %422 = insertelement <4 x double> %421, double %418, i64 1
  %423 = insertelement <4 x double> %422, double %419, i64 2
  %424 = insertelement <4 x double> %423, double %420, i64 3
  %425 = fmul <4 x double> %424, %broadcast.splat49
  %426 = fadd <4 x double> %412, %425
  store <4 x double> %426, ptr %118, align 8, !alias.scope !4, !noalias !6
  %427 = getelementptr double, ptr %59, i64 %111
  %428 = getelementptr double, ptr %59, i64 %113
  %429 = getelementptr double, ptr %59, i64 %115
  %430 = getelementptr double, ptr %59, i64 %117
  %431 = load double, ptr %427, align 8, !alias.scope !8
  %432 = load double, ptr %428, align 8, !alias.scope !8
  %433 = load double, ptr %429, align 8, !alias.scope !8
  %434 = load double, ptr %430, align 8, !alias.scope !8
  %435 = insertelement <4 x double> poison, double %431, i64 0
  %436 = insertelement <4 x double> %435, double %432, i64 1
  %437 = insertelement <4 x double> %436, double %433, i64 2
  %438 = insertelement <4 x double> %437, double %434, i64 3
  %439 = fmul <4 x double> %438, %broadcast.splat51
  %440 = fadd <4 x double> %426, %439
  store <4 x double> %440, ptr %118, align 8, !alias.scope !4, !noalias !6
  %441 = getelementptr double, ptr %61, i64 %111
  %442 = getelementptr double, ptr %61, i64 %113
  %443 = getelementptr double, ptr %61, i64 %115
  %444 = getelementptr double, ptr %61, i64 %117
  %445 = load double, ptr %441, align 8, !alias.scope !8
  %446 = load double, ptr %442, align 8, !alias.scope !8
  %447 = load double, ptr %443, align 8, !alias.scope !8
  %448 = load double, ptr %444, align 8, !alias.scope !8
  %449 = insertelement <4 x double> poison, double %445, i64 0
  %450 = insertelement <4 x double> %449, double %446, i64 1
  %451 = insertelement <4 x double> %450, double %447, i64 2
  %452 = insertelement <4 x double> %451, double %448, i64 3
  %453 = fmul <4 x double> %452, %broadcast.splat53
  %454 = fadd <4 x double> %440, %453
  store <4 x double> %454, ptr %118, align 8, !alias.scope !4, !noalias !6
  %455 = getelementptr double, ptr %63, i64 %111
  %456 = getelementptr double, ptr %63, i64 %113
  %457 = getelementptr double, ptr %63, i64 %115
  %458 = getelementptr double, ptr %63, i64 %117
  %459 = load double, ptr %455, align 8, !alias.scope !8
  %460 = load double, ptr %456, align 8, !alias.scope !8
  %461 = load double, ptr %457, align 8, !alias.scope !8
  %462 = load double, ptr %458, align 8, !alias.scope !8
  %463 = insertelement <4 x double> poison, double %459, i64 0
  %464 = insertelement <4 x double> %463, double %460, i64 1
  %465 = insertelement <4 x double> %464, double %461, i64 2
  %466 = insertelement <4 x double> %465, double %462, i64 3
  %467 = fmul <4 x double> %466, %broadcast.splat55
  %468 = fadd <4 x double> %454, %467
  store <4 x double> %468, ptr %118, align 8, !alias.scope !4, !noalias !6
  %469 = getelementptr double, ptr %65, i64 %111
  %470 = getelementptr double, ptr %65, i64 %113
  %471 = getelementptr double, ptr %65, i64 %115
  %472 = getelementptr double, ptr %65, i64 %117
  %473 = load double, ptr %469, align 8, !alias.scope !8
  %474 = load double, ptr %470, align 8, !alias.scope !8
  %475 = load double, ptr %471, align 8, !alias.scope !8
  %476 = load double, ptr %472, align 8, !alias.scope !8
  %477 = insertelement <4 x double> poison, double %473, i64 0
  %478 = insertelement <4 x double> %477, double %474, i64 1
  %479 = insertelement <4 x double> %478, double %475, i64 2
  %480 = insertelement <4 x double> %479, double %476, i64 3
  %481 = fmul <4 x double> %480, %broadcast.splat57
  %482 = fadd <4 x double> %468, %481
  store <4 x double> %482, ptr %118, align 8, !alias.scope !4, !noalias !6
  %483 = getelementptr double, ptr %67, i64 %111
  %484 = getelementptr double, ptr %67, i64 %113
  %485 = getelementptr double, ptr %67, i64 %115
  %486 = getelementptr double, ptr %67, i64 %117
  %487 = load double, ptr %483, align 8, !alias.scope !8
  %488 = load double, ptr %484, align 8, !alias.scope !8
  %489 = load double, ptr %485, align 8, !alias.scope !8
  %490 = load double, ptr %486, align 8, !alias.scope !8
  %491 = insertelement <4 x double> poison, double %487, i64 0
  %492 = insertelement <4 x double> %491, double %488, i64 1
  %493 = insertelement <4 x double> %492, double %489, i64 2
  %494 = insertelement <4 x double> %493, double %490, i64 3
  %495 = fmul <4 x double> %494, %broadcast.splat59
  %496 = fadd <4 x double> %482, %495
  store <4 x double> %496, ptr %118, align 8, !alias.scope !4, !noalias !6
  %497 = getelementptr double, ptr %69, i64 %111
  %498 = getelementptr double, ptr %69, i64 %113
  %499 = getelementptr double, ptr %69, i64 %115
  %500 = getelementptr double, ptr %69, i64 %117
  %501 = load double, ptr %497, align 8, !alias.scope !8
  %502 = load double, ptr %498, align 8, !alias.scope !8
  %503 = load double, ptr %499, align 8, !alias.scope !8
  %504 = load double, ptr %500, align 8, !alias.scope !8
  %505 = insertelement <4 x double> poison, double %501, i64 0
  %506 = insertelement <4 x double> %505, double %502, i64 1
  %507 = insertelement <4 x double> %506, double %503, i64 2
  %508 = insertelement <4 x double> %507, double %504, i64 3
  %509 = fmul <4 x double> %508, %broadcast.splat61
  %510 = fadd <4 x double> %496, %509
  store <4 x double> %510, ptr %118, align 8, !alias.scope !4, !noalias !6
  %511 = getelementptr double, ptr %71, i64 %111
  %512 = getelementptr double, ptr %71, i64 %113
  %513 = getelementptr double, ptr %71, i64 %115
  %514 = getelementptr double, ptr %71, i64 %117
  %515 = load double, ptr %511, align 8, !alias.scope !8
  %516 = load double, ptr %512, align 8, !alias.scope !8
  %517 = load double, ptr %513, align 8, !alias.scope !8
  %518 = load double, ptr %514, align 8, !alias.scope !8
  %519 = insertelement <4 x double> poison, double %515, i64 0
  %520 = insertelement <4 x double> %519, double %516, i64 1
  %521 = insertelement <4 x double> %520, double %517, i64 2
  %522 = insertelement <4 x double> %521, double %518, i64 3
  %523 = fmul <4 x double> %522, %broadcast.splat63
  %524 = fadd <4 x double> %510, %523
  store <4 x double> %524, ptr %118, align 8, !alias.scope !4, !noalias !6
  %525 = getelementptr double, ptr %73, i64 %111
  %526 = getelementptr double, ptr %73, i64 %113
  %527 = getelementptr double, ptr %73, i64 %115
  %528 = getelementptr double, ptr %73, i64 %117
  %529 = load double, ptr %525, align 8, !alias.scope !8
  %530 = load double, ptr %526, align 8, !alias.scope !8
  %531 = load double, ptr %527, align 8, !alias.scope !8
  %532 = load double, ptr %528, align 8, !alias.scope !8
  %533 = insertelement <4 x double> poison, double %529, i64 0
  %534 = insertelement <4 x double> %533, double %530, i64 1
  %535 = insertelement <4 x double> %534, double %531, i64 2
  %536 = insertelement <4 x double> %535, double %532, i64 3
  %537 = fmul <4 x double> %536, %broadcast.splat65
  %538 = fadd <4 x double> %524, %537
  store <4 x double> %538, ptr %118, align 8, !alias.scope !4, !noalias !6
  %539 = getelementptr double, ptr %75, i64 %111
  %540 = getelementptr double, ptr %75, i64 %113
  %541 = getelementptr double, ptr %75, i64 %115
  %542 = getelementptr double, ptr %75, i64 %117
  %543 = load double, ptr %539, align 8, !alias.scope !8
  %544 = load double, ptr %540, align 8, !alias.scope !8
  %545 = load double, ptr %541, align 8, !alias.scope !8
  %546 = load double, ptr %542, align 8, !alias.scope !8
  %547 = insertelement <4 x double> poison, double %543, i64 0
  %548 = insertelement <4 x double> %547, double %544, i64 1
  %549 = insertelement <4 x double> %548, double %545, i64 2
  %550 = insertelement <4 x double> %549, double %546, i64 3
  %551 = fmul <4 x double> %550, %broadcast.splat67
  %552 = fadd <4 x double> %538, %551
  store <4 x double> %552, ptr %118, align 8, !alias.scope !4, !noalias !6
  %553 = getelementptr double, ptr %77, i64 %111
  %554 = getelementptr double, ptr %77, i64 %113
  %555 = getelementptr double, ptr %77, i64 %115
  %556 = getelementptr double, ptr %77, i64 %117
  %557 = load double, ptr %553, align 8, !alias.scope !8
  %558 = load double, ptr %554, align 8, !alias.scope !8
  %559 = load double, ptr %555, align 8, !alias.scope !8
  %560 = load double, ptr %556, align 8, !alias.scope !8
  %561 = insertelement <4 x double> poison, double %557, i64 0
  %562 = insertelement <4 x double> %561, double %558, i64 1
  %563 = insertelement <4 x double> %562, double %559, i64 2
  %564 = insertelement <4 x double> %563, double %560, i64 3
  %565 = fmul <4 x double> %564, %broadcast.splat69
  %566 = fadd <4 x double> %552, %565
  store <4 x double> %566, ptr %118, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %567 = icmp eq i64 %index.next, 128
  br i1 %567, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %568 = phi i64 [ %731, %.preheader ], [ 0, %.preheader.preheader ]
  %569 = shl i64 %568, 5
  %570 = getelementptr double, ptr %13, i64 %568
  %.promoted = load double, ptr %570, align 8
  %571 = getelementptr double, ptr %1, i64 %569
  %572 = load double, ptr %571, align 8
  %573 = load double, ptr %8, align 8
  %574 = fmul double %572, %573
  %575 = fadd double %.promoted, %574
  store double %575, ptr %570, align 8
  %576 = getelementptr double, ptr %17, i64 %569
  %577 = load double, ptr %576, align 8
  %578 = load double, ptr %18, align 8
  %579 = fmul double %577, %578
  %580 = fadd double %575, %579
  store double %580, ptr %570, align 8
  %581 = getelementptr double, ptr %19, i64 %569
  %582 = load double, ptr %581, align 8
  %583 = load double, ptr %20, align 8
  %584 = fmul double %582, %583
  %585 = fadd double %580, %584
  store double %585, ptr %570, align 8
  %586 = getelementptr double, ptr %21, i64 %569
  %587 = load double, ptr %586, align 8
  %588 = load double, ptr %22, align 8
  %589 = fmul double %587, %588
  %590 = fadd double %585, %589
  store double %590, ptr %570, align 8
  %591 = getelementptr double, ptr %23, i64 %569
  %592 = load double, ptr %591, align 8
  %593 = load double, ptr %24, align 8
  %594 = fmul double %592, %593
  %595 = fadd double %590, %594
  store double %595, ptr %570, align 8
  %596 = getelementptr double, ptr %25, i64 %569
  %597 = load double, ptr %596, align 8
  %598 = load double, ptr %26, align 8
  %599 = fmul double %597, %598
  %600 = fadd double %595, %599
  store double %600, ptr %570, align 8
  %601 = getelementptr double, ptr %27, i64 %569
  %602 = load double, ptr %601, align 8
  %603 = load double, ptr %28, align 8
  %604 = fmul double %602, %603
  %605 = fadd double %600, %604
  store double %605, ptr %570, align 8
  %606 = getelementptr double, ptr %29, i64 %569
  %607 = load double, ptr %606, align 8
  %608 = load double, ptr %30, align 8
  %609 = fmul double %607, %608
  %610 = fadd double %605, %609
  store double %610, ptr %570, align 8
  %611 = getelementptr double, ptr %31, i64 %569
  %612 = load double, ptr %611, align 8
  %613 = load double, ptr %32, align 8
  %614 = fmul double %612, %613
  %615 = fadd double %610, %614
  store double %615, ptr %570, align 8
  %616 = getelementptr double, ptr %33, i64 %569
  %617 = load double, ptr %616, align 8
  %618 = load double, ptr %34, align 8
  %619 = fmul double %617, %618
  %620 = fadd double %615, %619
  store double %620, ptr %570, align 8
  %621 = getelementptr double, ptr %35, i64 %569
  %622 = load double, ptr %621, align 8
  %623 = load double, ptr %36, align 8
  %624 = fmul double %622, %623
  %625 = fadd double %620, %624
  store double %625, ptr %570, align 8
  %626 = getelementptr double, ptr %37, i64 %569
  %627 = load double, ptr %626, align 8
  %628 = load double, ptr %38, align 8
  %629 = fmul double %627, %628
  %630 = fadd double %625, %629
  store double %630, ptr %570, align 8
  %631 = getelementptr double, ptr %39, i64 %569
  %632 = load double, ptr %631, align 8
  %633 = load double, ptr %40, align 8
  %634 = fmul double %632, %633
  %635 = fadd double %630, %634
  store double %635, ptr %570, align 8
  %636 = getelementptr double, ptr %41, i64 %569
  %637 = load double, ptr %636, align 8
  %638 = load double, ptr %42, align 8
  %639 = fmul double %637, %638
  %640 = fadd double %635, %639
  store double %640, ptr %570, align 8
  %641 = getelementptr double, ptr %43, i64 %569
  %642 = load double, ptr %641, align 8
  %643 = load double, ptr %44, align 8
  %644 = fmul double %642, %643
  %645 = fadd double %640, %644
  store double %645, ptr %570, align 8
  %646 = getelementptr double, ptr %45, i64 %569
  %647 = load double, ptr %646, align 8
  %648 = load double, ptr %46, align 8
  %649 = fmul double %647, %648
  %650 = fadd double %645, %649
  store double %650, ptr %570, align 8
  %651 = getelementptr double, ptr %47, i64 %569
  %652 = load double, ptr %651, align 8
  %653 = load double, ptr %48, align 8
  %654 = fmul double %652, %653
  %655 = fadd double %650, %654
  store double %655, ptr %570, align 8
  %656 = getelementptr double, ptr %49, i64 %569
  %657 = load double, ptr %656, align 8
  %658 = load double, ptr %50, align 8
  %659 = fmul double %657, %658
  %660 = fadd double %655, %659
  store double %660, ptr %570, align 8
  %661 = getelementptr double, ptr %51, i64 %569
  %662 = load double, ptr %661, align 8
  %663 = load double, ptr %52, align 8
  %664 = fmul double %662, %663
  %665 = fadd double %660, %664
  store double %665, ptr %570, align 8
  %666 = getelementptr double, ptr %53, i64 %569
  %667 = load double, ptr %666, align 8
  %668 = load double, ptr %54, align 8
  %669 = fmul double %667, %668
  %670 = fadd double %665, %669
  store double %670, ptr %570, align 8
  %671 = getelementptr double, ptr %55, i64 %569
  %672 = load double, ptr %671, align 8
  %673 = load double, ptr %56, align 8
  %674 = fmul double %672, %673
  %675 = fadd double %670, %674
  store double %675, ptr %570, align 8
  %676 = getelementptr double, ptr %57, i64 %569
  %677 = load double, ptr %676, align 8
  %678 = load double, ptr %58, align 8
  %679 = fmul double %677, %678
  %680 = fadd double %675, %679
  store double %680, ptr %570, align 8
  %681 = getelementptr double, ptr %59, i64 %569
  %682 = load double, ptr %681, align 8
  %683 = load double, ptr %60, align 8
  %684 = fmul double %682, %683
  %685 = fadd double %680, %684
  store double %685, ptr %570, align 8
  %686 = getelementptr double, ptr %61, i64 %569
  %687 = load double, ptr %686, align 8
  %688 = load double, ptr %62, align 8
  %689 = fmul double %687, %688
  %690 = fadd double %685, %689
  store double %690, ptr %570, align 8
  %691 = getelementptr double, ptr %63, i64 %569
  %692 = load double, ptr %691, align 8
  %693 = load double, ptr %64, align 8
  %694 = fmul double %692, %693
  %695 = fadd double %690, %694
  store double %695, ptr %570, align 8
  %696 = getelementptr double, ptr %65, i64 %569
  %697 = load double, ptr %696, align 8
  %698 = load double, ptr %66, align 8
  %699 = fmul double %697, %698
  %700 = fadd double %695, %699
  store double %700, ptr %570, align 8
  %701 = getelementptr double, ptr %67, i64 %569
  %702 = load double, ptr %701, align 8
  %703 = load double, ptr %68, align 8
  %704 = fmul double %702, %703
  %705 = fadd double %700, %704
  store double %705, ptr %570, align 8
  %706 = getelementptr double, ptr %69, i64 %569
  %707 = load double, ptr %706, align 8
  %708 = load double, ptr %70, align 8
  %709 = fmul double %707, %708
  %710 = fadd double %705, %709
  store double %710, ptr %570, align 8
  %711 = getelementptr double, ptr %71, i64 %569
  %712 = load double, ptr %711, align 8
  %713 = load double, ptr %72, align 8
  %714 = fmul double %712, %713
  %715 = fadd double %710, %714
  store double %715, ptr %570, align 8
  %716 = getelementptr double, ptr %73, i64 %569
  %717 = load double, ptr %716, align 8
  %718 = load double, ptr %74, align 8
  %719 = fmul double %717, %718
  %720 = fadd double %715, %719
  store double %720, ptr %570, align 8
  %721 = getelementptr double, ptr %75, i64 %569
  %722 = load double, ptr %721, align 8
  %723 = load double, ptr %76, align 8
  %724 = fmul double %722, %723
  %725 = fadd double %720, %724
  store double %725, ptr %570, align 8
  %726 = getelementptr double, ptr %77, i64 %569
  %727 = load double, ptr %726, align 8
  %728 = load double, ptr %78, align 8
  %729 = fmul double %727, %728
  %730 = fadd double %725, %729
  store double %730, ptr %570, align 8
  %731 = add nuw nsw i64 %568, 1
  %exitcond.not = icmp eq i64 %731, 128
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!7, !2}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
