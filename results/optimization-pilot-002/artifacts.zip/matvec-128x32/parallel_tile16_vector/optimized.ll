; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  br label %18

18:                                               ; preds = %17, %79
  %19 = phi i64 [ 0, %17 ], [ %80, %79 ]
  %20 = shl nuw nsw i64 %19, 5
  %21 = getelementptr double, ptr %13, i64 %19
  %.promoted = load <16 x double>, ptr %21, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %20
  br label %22

22:                                               ; preds = %18, %22
  %23 = phi i64 [ 0, %18 ], [ %78, %22 ]
  %24 = phi <16 x double> [ %.promoted, %18 ], [ %77, %22 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %23
  %25 = load double, ptr %gep, align 8
  %26 = getelementptr double, ptr %gep, i64 32
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep, i64 64
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep, i64 96
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep, i64 128
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep, i64 160
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep, i64 192
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep, i64 224
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep, i64 256
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %gep, i64 288
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %gep, i64 320
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %gep, i64 352
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %gep, i64 384
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %gep, i64 416
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %gep, i64 448
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %gep, i64 480
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %8, i64 %23
  %57 = load double, ptr %56, align 8
  %58 = insertelement <16 x double> poison, double %25, i64 0
  %59 = insertelement <16 x double> %58, double %27, i64 1
  %60 = insertelement <16 x double> %59, double %29, i64 2
  %61 = insertelement <16 x double> %60, double %31, i64 3
  %62 = insertelement <16 x double> %61, double %33, i64 4
  %63 = insertelement <16 x double> %62, double %35, i64 5
  %64 = insertelement <16 x double> %63, double %37, i64 6
  %65 = insertelement <16 x double> %64, double %39, i64 7
  %66 = insertelement <16 x double> %65, double %41, i64 8
  %67 = insertelement <16 x double> %66, double %43, i64 9
  %68 = insertelement <16 x double> %67, double %45, i64 10
  %69 = insertelement <16 x double> %68, double %47, i64 11
  %70 = insertelement <16 x double> %69, double %49, i64 12
  %71 = insertelement <16 x double> %70, double %51, i64 13
  %72 = insertelement <16 x double> %71, double %53, i64 14
  %73 = insertelement <16 x double> %72, double %55, i64 15
  %74 = insertelement <16 x double> poison, double %57, i64 0
  %75 = shufflevector <16 x double> %74, <16 x double> poison, <16 x i32> zeroinitializer
  %76 = fmul <16 x double> %73, %75
  %77 = fadd <16 x double> %24, %76
  store <16 x double> %77, ptr %21, align 8
  %78 = add nuw nsw i64 %23, 1
  %exitcond.not = icmp eq i64 %78, 32
  br i1 %exitcond.not, label %79, label %22

79:                                               ; preds = %22
  %80 = add nuw nsw i64 %19, 16
  %81 = icmp ult i64 %19, 112
  br i1 %81, label %18, label %82

82:                                               ; preds = %79
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28, i8 0, i64 1024, i1 false)
  br label %4

4:                                                ; preds = %65, %3
  %5 = phi i64 [ 0, %3 ], [ %66, %65 ]
  %6 = shl nuw nsw i64 %5, 5
  %7 = getelementptr double, ptr %.unpack28, i64 %5
  %.promoted.i = load <16 x double>, ptr %7, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %8

8:                                                ; preds = %8, %4
  %9 = phi i64 [ 0, %4 ], [ %64, %8 ]
  %10 = phi <16 x double> [ %.promoted.i, %4 ], [ %63, %8 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %9
  %11 = load double, ptr %gep.i, align 8
  %12 = getelementptr double, ptr %gep.i, i64 32
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %gep.i, i64 64
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %gep.i, i64 96
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %gep.i, i64 128
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 160
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 192
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i, i64 224
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep.i, i64 256
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep.i, i64 288
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep.i, i64 320
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep.i, i64 352
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep.i, i64 384
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep.i, i64 416
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep.i, i64 448
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep.i, i64 480
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %.unpack17, i64 %9
  %43 = load double, ptr %42, align 8
  %44 = insertelement <16 x double> poison, double %11, i64 0
  %45 = insertelement <16 x double> %44, double %13, i64 1
  %46 = insertelement <16 x double> %45, double %15, i64 2
  %47 = insertelement <16 x double> %46, double %17, i64 3
  %48 = insertelement <16 x double> %47, double %19, i64 4
  %49 = insertelement <16 x double> %48, double %21, i64 5
  %50 = insertelement <16 x double> %49, double %23, i64 6
  %51 = insertelement <16 x double> %50, double %25, i64 7
  %52 = insertelement <16 x double> %51, double %27, i64 8
  %53 = insertelement <16 x double> %52, double %29, i64 9
  %54 = insertelement <16 x double> %53, double %31, i64 10
  %55 = insertelement <16 x double> %54, double %33, i64 11
  %56 = insertelement <16 x double> %55, double %35, i64 12
  %57 = insertelement <16 x double> %56, double %37, i64 13
  %58 = insertelement <16 x double> %57, double %39, i64 14
  %59 = insertelement <16 x double> %58, double %41, i64 15
  %60 = insertelement <16 x double> poison, double %43, i64 0
  %61 = shufflevector <16 x double> %60, <16 x double> poison, <16 x i32> zeroinitializer
  %62 = fmul <16 x double> %59, %61
  %63 = fadd <16 x double> %10, %62
  store <16 x double> %63, ptr %7, align 8
  %64 = add nuw nsw i64 %9, 1
  %exitcond.not.i = icmp eq i64 %64, 32
  br i1 %exitcond.not.i, label %65, label %8

65:                                               ; preds = %8
  %66 = add nuw nsw i64 %5, 16
  %67 = icmp ult i64 %5, 112
  br i1 %67, label %4, label %kernel.exit

kernel.exit:                                      ; preds = %65
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %10, i8 0, i64 1024, i1 false)
  br label %11

11:                                               ; preds = %72, %1
  %12 = phi i64 [ 0, %1 ], [ %73, %72 ]
  %13 = shl nuw nsw i64 %12, 5
  %14 = getelementptr double, ptr %10, i64 %12
  %.promoted.i = load <16 x double>, ptr %14, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %13
  br label %15

15:                                               ; preds = %15, %11
  %16 = phi i64 [ 0, %11 ], [ %71, %15 ]
  %17 = phi <16 x double> [ %.promoted.i, %11 ], [ %70, %15 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %16
  %18 = load double, ptr %gep.i, align 8
  %19 = getelementptr double, ptr %gep.i, i64 32
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i, i64 64
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i, i64 96
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %gep.i, i64 128
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep.i, i64 160
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep.i, i64 192
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i, i64 224
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %gep.i, i64 256
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %gep.i, i64 288
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %gep.i, i64 320
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %gep.i, i64 352
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %gep.i, i64 384
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %gep.i, i64 416
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %gep.i, i64 448
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %gep.i, i64 480
  %48 = load double, ptr %47, align 8
  %49 = getelementptr double, ptr %7, i64 %16
  %50 = load double, ptr %49, align 8
  %51 = insertelement <16 x double> poison, double %18, i64 0
  %52 = insertelement <16 x double> %51, double %20, i64 1
  %53 = insertelement <16 x double> %52, double %22, i64 2
  %54 = insertelement <16 x double> %53, double %24, i64 3
  %55 = insertelement <16 x double> %54, double %26, i64 4
  %56 = insertelement <16 x double> %55, double %28, i64 5
  %57 = insertelement <16 x double> %56, double %30, i64 6
  %58 = insertelement <16 x double> %57, double %32, i64 7
  %59 = insertelement <16 x double> %58, double %34, i64 8
  %60 = insertelement <16 x double> %59, double %36, i64 9
  %61 = insertelement <16 x double> %60, double %38, i64 10
  %62 = insertelement <16 x double> %61, double %40, i64 11
  %63 = insertelement <16 x double> %62, double %42, i64 12
  %64 = insertelement <16 x double> %63, double %44, i64 13
  %65 = insertelement <16 x double> %64, double %46, i64 14
  %66 = insertelement <16 x double> %65, double %48, i64 15
  %67 = insertelement <16 x double> poison, double %50, i64 0
  %68 = shufflevector <16 x double> %67, <16 x double> poison, <16 x i32> zeroinitializer
  %69 = fmul <16 x double> %66, %68
  %70 = fadd <16 x double> %17, %69
  store <16 x double> %70, ptr %14, align 8
  %71 = add nuw nsw i64 %16, 1
  %exitcond.not.i = icmp eq i64 %71, 32
  br i1 %exitcond.not.i, label %72, label %15

72:                                               ; preds = %15
  %73 = add nuw nsw i64 %12, 16
  %74 = icmp ult i64 %12, 112
  br i1 %74, label %11, label %kernel.exit

kernel.exit:                                      ; preds = %72
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28.i, i8 0, i64 1024, i1 false)
  br label %10

10:                                               ; preds = %71, %1
  %11 = phi i64 [ 0, %1 ], [ %72, %71 ]
  %12 = shl nuw nsw i64 %11, 5
  %13 = getelementptr double, ptr %.unpack28.i, i64 %11
  %.promoted.i.i = load <16 x double>, ptr %13, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %14

14:                                               ; preds = %14, %10
  %15 = phi i64 [ 0, %10 ], [ %70, %14 ]
  %16 = phi <16 x double> [ %.promoted.i.i, %10 ], [ %69, %14 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %15
  %17 = load double, ptr %gep.i.i, align 8
  %18 = getelementptr double, ptr %gep.i.i, i64 32
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i.i, i64 64
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i.i, i64 96
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i.i, i64 128
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep.i.i, i64 160
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep.i.i, i64 192
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep.i.i, i64 224
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep.i.i, i64 256
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep.i.i, i64 288
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep.i.i, i64 320
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep.i.i, i64 352
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %gep.i.i, i64 384
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %gep.i.i, i64 416
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %gep.i.i, i64 448
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %gep.i.i, i64 480
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %.unpack17.i, i64 %15
  %49 = load double, ptr %48, align 8
  %50 = insertelement <16 x double> poison, double %17, i64 0
  %51 = insertelement <16 x double> %50, double %19, i64 1
  %52 = insertelement <16 x double> %51, double %21, i64 2
  %53 = insertelement <16 x double> %52, double %23, i64 3
  %54 = insertelement <16 x double> %53, double %25, i64 4
  %55 = insertelement <16 x double> %54, double %27, i64 5
  %56 = insertelement <16 x double> %55, double %29, i64 6
  %57 = insertelement <16 x double> %56, double %31, i64 7
  %58 = insertelement <16 x double> %57, double %33, i64 8
  %59 = insertelement <16 x double> %58, double %35, i64 9
  %60 = insertelement <16 x double> %59, double %37, i64 10
  %61 = insertelement <16 x double> %60, double %39, i64 11
  %62 = insertelement <16 x double> %61, double %41, i64 12
  %63 = insertelement <16 x double> %62, double %43, i64 13
  %64 = insertelement <16 x double> %63, double %45, i64 14
  %65 = insertelement <16 x double> %64, double %47, i64 15
  %66 = insertelement <16 x double> poison, double %49, i64 0
  %67 = shufflevector <16 x double> %66, <16 x double> poison, <16 x i32> zeroinitializer
  %68 = fmul <16 x double> %65, %67
  %69 = fadd <16 x double> %16, %68
  store <16 x double> %69, ptr %13, align 8
  %70 = add nuw nsw i64 %15, 1
  %exitcond.not.i.i = icmp eq i64 %70, 32
  br i1 %exitcond.not.i.i, label %71, label %14

71:                                               ; preds = %14
  %72 = add nuw nsw i64 %11, 16
  %73 = icmp ult i64 %11, 112
  br i1 %73, label %10, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %71
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
