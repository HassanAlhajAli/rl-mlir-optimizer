#map = affine_map<(d0, d1) -> (d0, d1)>
#map1 = affine_map<(d0, d1) -> (d1)>
#map2 = affine_map<(d0, d1) -> (d0)>
module {
  func.func @kernel(%arg0: memref<128x256xf64>, %arg1: memref<256xf64>, %arg2: memref<128xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<128xf64>)
    %c0_0 = arith.constant 0 : index
    %c128 = arith.constant 128 : index
    %c4_1 = arith.constant 4 : index
    scf.for %arg3 = %c0_0 to %c128 step %c4_1 {
      %subview = memref.subview %arg0[%arg3, 0] [4, 256] [1, 1] : memref<128x256xf64> to memref<4x256xf64, strided<[256, 1], offset: ?>>
      %subview_2 = memref.subview %arg2[%arg3] [4] [1] : memref<128xf64> to memref<4xf64, strided<[1], offset: ?>>
      linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "reduction"]} ins(%subview, %arg1 : memref<4x256xf64, strided<[256, 1], offset: ?>>, memref<256xf64>) outs(%subview_2 : memref<4xf64, strided<[1], offset: ?>>) {
      ^bb0(%in: f64, %in_3: f64, %out: f64):
        %0 = arith.mulf %in, %in_3 : f64
        %1 = arith.addf %out, %0 : f64
        linalg.yield %1 : f64
      }
    }
    return
  }
}
