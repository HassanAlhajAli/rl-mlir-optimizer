; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %13, i8 0, i64 1024, i1 false)
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %208
  %17 = phi i64 [ %209, %208 ], [ 0, %.preheader3.preheader ]
  %18 = shl nuw nsw i64 %17, 8
  %19 = getelementptr double, ptr %1, i64 %18
  %20 = getelementptr double, ptr %13, i64 %17
  %.promoted = load double, ptr %20, align 8
  br label %21

21:                                               ; preds = %21, %.preheader3
  %22 = phi i64 [ 0, %.preheader3 ], [ %51, %21 ]
  %23 = phi double [ %.promoted, %.preheader3 ], [ %50, %21 ]
  %24 = getelementptr double, ptr %19, i64 %22
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %8, i64 %22
  %27 = load double, ptr %26, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %23, %28
  store double %29, ptr %20, align 8
  %30 = or disjoint i64 %22, 1
  %31 = getelementptr double, ptr %19, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %8, i64 %30
  %34 = load double, ptr %33, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %29, %35
  store double %36, ptr %20, align 8
  %37 = or disjoint i64 %22, 2
  %38 = getelementptr double, ptr %19, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %8, i64 %37
  %41 = load double, ptr %40, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %20, align 8
  %44 = or disjoint i64 %22, 3
  %45 = getelementptr double, ptr %19, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %8, i64 %44
  %48 = load double, ptr %47, align 8
  %49 = fmul double %46, %48
  %50 = fadd double %43, %49
  store double %50, ptr %20, align 8
  %51 = add nuw nsw i64 %22, 4
  %exitcond.not.3 = icmp eq i64 %51, 256
  br i1 %exitcond.not.3, label %.preheader.1, label %21

.preheader.1:                                     ; preds = %21
  %52 = getelementptr double, ptr %20, i64 1
  %.promoted.1 = load double, ptr %52, align 8
  %invariant.gep7 = getelementptr double, ptr %19, i64 256
  br label %53

53:                                               ; preds = %53, %.preheader.1
  %54 = phi i64 [ 0, %.preheader.1 ], [ %103, %53 ]
  %55 = phi double [ %.promoted.1, %.preheader.1 ], [ %102, %53 ]
  %gep8 = getelementptr double, ptr %invariant.gep7, i64 %54
  %56 = load double, ptr %gep8, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %55, %59
  store double %60, ptr %52, align 8
  %61 = or disjoint i64 %54, 1
  %gep8.1 = getelementptr double, ptr %invariant.gep7, i64 %61
  %62 = load double, ptr %gep8.1, align 8
  %63 = getelementptr double, ptr %8, i64 %61
  %64 = load double, ptr %63, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %60, %65
  store double %66, ptr %52, align 8
  %67 = or disjoint i64 %54, 2
  %gep8.2 = getelementptr double, ptr %invariant.gep7, i64 %67
  %68 = load double, ptr %gep8.2, align 8
  %69 = getelementptr double, ptr %8, i64 %67
  %70 = load double, ptr %69, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %52, align 8
  %73 = or disjoint i64 %54, 3
  %gep8.3 = getelementptr double, ptr %invariant.gep7, i64 %73
  %74 = load double, ptr %gep8.3, align 8
  %75 = getelementptr double, ptr %8, i64 %73
  %76 = load double, ptr %75, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %72, %77
  store double %78, ptr %52, align 8
  %79 = or disjoint i64 %54, 4
  %gep8.4 = getelementptr double, ptr %invariant.gep7, i64 %79
  %80 = load double, ptr %gep8.4, align 8
  %81 = getelementptr double, ptr %8, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %52, align 8
  %85 = or disjoint i64 %54, 5
  %gep8.5 = getelementptr double, ptr %invariant.gep7, i64 %85
  %86 = load double, ptr %gep8.5, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %52, align 8
  %91 = or disjoint i64 %54, 6
  %gep8.6 = getelementptr double, ptr %invariant.gep7, i64 %91
  %92 = load double, ptr %gep8.6, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %52, align 8
  %97 = or disjoint i64 %54, 7
  %gep8.7 = getelementptr double, ptr %invariant.gep7, i64 %97
  %98 = load double, ptr %gep8.7, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %52, align 8
  %103 = add nuw nsw i64 %54, 8
  %exitcond.1.not.7 = icmp eq i64 %103, 256
  br i1 %exitcond.1.not.7, label %.preheader.2, label %53

.preheader.2:                                     ; preds = %53
  %104 = getelementptr double, ptr %20, i64 2
  %.promoted.2 = load double, ptr %104, align 8
  %invariant.gep5 = getelementptr double, ptr %19, i64 512
  br label %105

105:                                              ; preds = %105, %.preheader.2
  %106 = phi i64 [ 0, %.preheader.2 ], [ %155, %105 ]
  %107 = phi double [ %.promoted.2, %.preheader.2 ], [ %154, %105 ]
  %gep6 = getelementptr double, ptr %invariant.gep5, i64 %106
  %108 = load double, ptr %gep6, align 8
  %109 = getelementptr double, ptr %8, i64 %106
  %110 = load double, ptr %109, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %107, %111
  store double %112, ptr %104, align 8
  %113 = or disjoint i64 %106, 1
  %gep6.1 = getelementptr double, ptr %invariant.gep5, i64 %113
  %114 = load double, ptr %gep6.1, align 8
  %115 = getelementptr double, ptr %8, i64 %113
  %116 = load double, ptr %115, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %112, %117
  store double %118, ptr %104, align 8
  %119 = or disjoint i64 %106, 2
  %gep6.2 = getelementptr double, ptr %invariant.gep5, i64 %119
  %120 = load double, ptr %gep6.2, align 8
  %121 = getelementptr double, ptr %8, i64 %119
  %122 = load double, ptr %121, align 8
  %123 = fmul double %120, %122
  %124 = fadd double %118, %123
  store double %124, ptr %104, align 8
  %125 = or disjoint i64 %106, 3
  %gep6.3 = getelementptr double, ptr %invariant.gep5, i64 %125
  %126 = load double, ptr %gep6.3, align 8
  %127 = getelementptr double, ptr %8, i64 %125
  %128 = load double, ptr %127, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %124, %129
  store double %130, ptr %104, align 8
  %131 = or disjoint i64 %106, 4
  %gep6.4 = getelementptr double, ptr %invariant.gep5, i64 %131
  %132 = load double, ptr %gep6.4, align 8
  %133 = getelementptr double, ptr %8, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %104, align 8
  %137 = or disjoint i64 %106, 5
  %gep6.5 = getelementptr double, ptr %invariant.gep5, i64 %137
  %138 = load double, ptr %gep6.5, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %104, align 8
  %143 = or disjoint i64 %106, 6
  %gep6.6 = getelementptr double, ptr %invariant.gep5, i64 %143
  %144 = load double, ptr %gep6.6, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %104, align 8
  %149 = or disjoint i64 %106, 7
  %gep6.7 = getelementptr double, ptr %invariant.gep5, i64 %149
  %150 = load double, ptr %gep6.7, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %104, align 8
  %155 = add nuw nsw i64 %106, 8
  %exitcond.2.not.7 = icmp eq i64 %155, 256
  br i1 %exitcond.2.not.7, label %.preheader.3, label %105

.preheader.3:                                     ; preds = %105
  %156 = getelementptr double, ptr %20, i64 3
  %.promoted.3 = load double, ptr %156, align 8
  %invariant.gep = getelementptr double, ptr %19, i64 768
  br label %157

157:                                              ; preds = %157, %.preheader.3
  %158 = phi i64 [ 0, %.preheader.3 ], [ %207, %157 ]
  %159 = phi double [ %.promoted.3, %.preheader.3 ], [ %206, %157 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %158
  %160 = load double, ptr %gep, align 8
  %161 = getelementptr double, ptr %8, i64 %158
  %162 = load double, ptr %161, align 8
  %163 = fmul double %160, %162
  %164 = fadd double %159, %163
  store double %164, ptr %156, align 8
  %165 = or disjoint i64 %158, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %165
  %166 = load double, ptr %gep.1, align 8
  %167 = getelementptr double, ptr %8, i64 %165
  %168 = load double, ptr %167, align 8
  %169 = fmul double %166, %168
  %170 = fadd double %164, %169
  store double %170, ptr %156, align 8
  %171 = or disjoint i64 %158, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %171
  %172 = load double, ptr %gep.2, align 8
  %173 = getelementptr double, ptr %8, i64 %171
  %174 = load double, ptr %173, align 8
  %175 = fmul double %172, %174
  %176 = fadd double %170, %175
  store double %176, ptr %156, align 8
  %177 = or disjoint i64 %158, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %177
  %178 = load double, ptr %gep.3, align 8
  %179 = getelementptr double, ptr %8, i64 %177
  %180 = load double, ptr %179, align 8
  %181 = fmul double %178, %180
  %182 = fadd double %176, %181
  store double %182, ptr %156, align 8
  %183 = or disjoint i64 %158, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %183
  %184 = load double, ptr %gep.4, align 8
  %185 = getelementptr double, ptr %8, i64 %183
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %182, %187
  store double %188, ptr %156, align 8
  %189 = or disjoint i64 %158, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %189
  %190 = load double, ptr %gep.5, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %156, align 8
  %195 = or disjoint i64 %158, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %195
  %196 = load double, ptr %gep.6, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %156, align 8
  %201 = or disjoint i64 %158, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %201
  %202 = load double, ptr %gep.7, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %156, align 8
  %207 = add nuw nsw i64 %158, 8
  %exitcond.3.not.7 = icmp eq i64 %207, 256
  br i1 %exitcond.3.not.7, label %208, label %157

208:                                              ; preds = %157
  %209 = add nuw nsw i64 %17, 4
  %210 = icmp ult i64 %17, 124
  br i1 %210, label %.preheader3, label %211

211:                                              ; preds = %208
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28, i8 0, i64 1024, i1 false)
  br label %.preheader3.i

.preheader3.i:                                    ; preds = %195, %3
  %4 = phi i64 [ %196, %195 ], [ 0, %3 ]
  %5 = shl nuw nsw i64 %4, 8
  %6 = getelementptr double, ptr %.unpack2, i64 %5
  %7 = getelementptr double, ptr %.unpack28, i64 %4
  %.promoted.i = load double, ptr %7, align 8
  br label %8

8:                                                ; preds = %8, %.preheader3.i
  %9 = phi i64 [ 0, %.preheader3.i ], [ %38, %8 ]
  %10 = phi double [ %.promoted.i, %.preheader3.i ], [ %37, %8 ]
  %11 = getelementptr double, ptr %6, i64 %9
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %.unpack17, i64 %9
  %14 = load double, ptr %13, align 8
  %15 = fmul double %12, %14
  %16 = fadd double %10, %15
  store double %16, ptr %7, align 8
  %17 = or disjoint i64 %9, 1
  %18 = getelementptr double, ptr %6, i64 %17
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %.unpack17, i64 %17
  %21 = load double, ptr %20, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %16, %22
  store double %23, ptr %7, align 8
  %24 = or disjoint i64 %9, 2
  %25 = getelementptr double, ptr %6, i64 %24
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %.unpack17, i64 %24
  %28 = load double, ptr %27, align 8
  %29 = fmul double %26, %28
  %30 = fadd double %23, %29
  store double %30, ptr %7, align 8
  %31 = or disjoint i64 %9, 3
  %32 = getelementptr double, ptr %6, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %.unpack17, i64 %31
  %35 = load double, ptr %34, align 8
  %36 = fmul double %33, %35
  %37 = fadd double %30, %36
  store double %37, ptr %7, align 8
  %38 = add nuw nsw i64 %9, 4
  %exitcond.not.i.3 = icmp eq i64 %38, 256
  br i1 %exitcond.not.i.3, label %.preheader.1.i, label %8

.preheader.1.i:                                   ; preds = %8
  %39 = getelementptr double, ptr %7, i64 1
  %.promoted.1.i = load double, ptr %39, align 8
  %invariant.gep7.i = getelementptr double, ptr %6, i64 256
  br label %40

40:                                               ; preds = %40, %.preheader.1.i
  %41 = phi i64 [ 0, %.preheader.1.i ], [ %90, %40 ]
  %42 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %89, %40 ]
  %gep8.i = getelementptr double, ptr %invariant.gep7.i, i64 %41
  %43 = load double, ptr %gep8.i, align 8
  %44 = getelementptr double, ptr %.unpack17, i64 %41
  %45 = load double, ptr %44, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %42, %46
  store double %47, ptr %39, align 8
  %48 = or disjoint i64 %41, 1
  %gep8.i.1 = getelementptr double, ptr %invariant.gep7.i, i64 %48
  %49 = load double, ptr %gep8.i.1, align 8
  %50 = getelementptr double, ptr %.unpack17, i64 %48
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %47, %52
  store double %53, ptr %39, align 8
  %54 = or disjoint i64 %41, 2
  %gep8.i.2 = getelementptr double, ptr %invariant.gep7.i, i64 %54
  %55 = load double, ptr %gep8.i.2, align 8
  %56 = getelementptr double, ptr %.unpack17, i64 %54
  %57 = load double, ptr %56, align 8
  %58 = fmul double %55, %57
  %59 = fadd double %53, %58
  store double %59, ptr %39, align 8
  %60 = or disjoint i64 %41, 3
  %gep8.i.3 = getelementptr double, ptr %invariant.gep7.i, i64 %60
  %61 = load double, ptr %gep8.i.3, align 8
  %62 = getelementptr double, ptr %.unpack17, i64 %60
  %63 = load double, ptr %62, align 8
  %64 = fmul double %61, %63
  %65 = fadd double %59, %64
  store double %65, ptr %39, align 8
  %66 = or disjoint i64 %41, 4
  %gep8.i.4 = getelementptr double, ptr %invariant.gep7.i, i64 %66
  %67 = load double, ptr %gep8.i.4, align 8
  %68 = getelementptr double, ptr %.unpack17, i64 %66
  %69 = load double, ptr %68, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %65, %70
  store double %71, ptr %39, align 8
  %72 = or disjoint i64 %41, 5
  %gep8.i.5 = getelementptr double, ptr %invariant.gep7.i, i64 %72
  %73 = load double, ptr %gep8.i.5, align 8
  %74 = getelementptr double, ptr %.unpack17, i64 %72
  %75 = load double, ptr %74, align 8
  %76 = fmul double %73, %75
  %77 = fadd double %71, %76
  store double %77, ptr %39, align 8
  %78 = or disjoint i64 %41, 6
  %gep8.i.6 = getelementptr double, ptr %invariant.gep7.i, i64 %78
  %79 = load double, ptr %gep8.i.6, align 8
  %80 = getelementptr double, ptr %.unpack17, i64 %78
  %81 = load double, ptr %80, align 8
  %82 = fmul double %79, %81
  %83 = fadd double %77, %82
  store double %83, ptr %39, align 8
  %84 = or disjoint i64 %41, 7
  %gep8.i.7 = getelementptr double, ptr %invariant.gep7.i, i64 %84
  %85 = load double, ptr %gep8.i.7, align 8
  %86 = getelementptr double, ptr %.unpack17, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %83, %88
  store double %89, ptr %39, align 8
  %90 = add nuw nsw i64 %41, 8
  %exitcond.1.not.i.7 = icmp eq i64 %90, 256
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %40

.preheader.2.i:                                   ; preds = %40
  %91 = getelementptr double, ptr %7, i64 2
  %.promoted.2.i = load double, ptr %91, align 8
  %invariant.gep5.i = getelementptr double, ptr %6, i64 512
  br label %92

92:                                               ; preds = %92, %.preheader.2.i
  %93 = phi i64 [ 0, %.preheader.2.i ], [ %142, %92 ]
  %94 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %141, %92 ]
  %gep6.i = getelementptr double, ptr %invariant.gep5.i, i64 %93
  %95 = load double, ptr %gep6.i, align 8
  %96 = getelementptr double, ptr %.unpack17, i64 %93
  %97 = load double, ptr %96, align 8
  %98 = fmul double %95, %97
  %99 = fadd double %94, %98
  store double %99, ptr %91, align 8
  %100 = or disjoint i64 %93, 1
  %gep6.i.1 = getelementptr double, ptr %invariant.gep5.i, i64 %100
  %101 = load double, ptr %gep6.i.1, align 8
  %102 = getelementptr double, ptr %.unpack17, i64 %100
  %103 = load double, ptr %102, align 8
  %104 = fmul double %101, %103
  %105 = fadd double %99, %104
  store double %105, ptr %91, align 8
  %106 = or disjoint i64 %93, 2
  %gep6.i.2 = getelementptr double, ptr %invariant.gep5.i, i64 %106
  %107 = load double, ptr %gep6.i.2, align 8
  %108 = getelementptr double, ptr %.unpack17, i64 %106
  %109 = load double, ptr %108, align 8
  %110 = fmul double %107, %109
  %111 = fadd double %105, %110
  store double %111, ptr %91, align 8
  %112 = or disjoint i64 %93, 3
  %gep6.i.3 = getelementptr double, ptr %invariant.gep5.i, i64 %112
  %113 = load double, ptr %gep6.i.3, align 8
  %114 = getelementptr double, ptr %.unpack17, i64 %112
  %115 = load double, ptr %114, align 8
  %116 = fmul double %113, %115
  %117 = fadd double %111, %116
  store double %117, ptr %91, align 8
  %118 = or disjoint i64 %93, 4
  %gep6.i.4 = getelementptr double, ptr %invariant.gep5.i, i64 %118
  %119 = load double, ptr %gep6.i.4, align 8
  %120 = getelementptr double, ptr %.unpack17, i64 %118
  %121 = load double, ptr %120, align 8
  %122 = fmul double %119, %121
  %123 = fadd double %117, %122
  store double %123, ptr %91, align 8
  %124 = or disjoint i64 %93, 5
  %gep6.i.5 = getelementptr double, ptr %invariant.gep5.i, i64 %124
  %125 = load double, ptr %gep6.i.5, align 8
  %126 = getelementptr double, ptr %.unpack17, i64 %124
  %127 = load double, ptr %126, align 8
  %128 = fmul double %125, %127
  %129 = fadd double %123, %128
  store double %129, ptr %91, align 8
  %130 = or disjoint i64 %93, 6
  %gep6.i.6 = getelementptr double, ptr %invariant.gep5.i, i64 %130
  %131 = load double, ptr %gep6.i.6, align 8
  %132 = getelementptr double, ptr %.unpack17, i64 %130
  %133 = load double, ptr %132, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %129, %134
  store double %135, ptr %91, align 8
  %136 = or disjoint i64 %93, 7
  %gep6.i.7 = getelementptr double, ptr %invariant.gep5.i, i64 %136
  %137 = load double, ptr %gep6.i.7, align 8
  %138 = getelementptr double, ptr %.unpack17, i64 %136
  %139 = load double, ptr %138, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %135, %140
  store double %141, ptr %91, align 8
  %142 = add nuw nsw i64 %93, 8
  %exitcond.2.not.i.7 = icmp eq i64 %142, 256
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %92

.preheader.3.i:                                   ; preds = %92
  %143 = getelementptr double, ptr %7, i64 3
  %.promoted.3.i = load double, ptr %143, align 8
  %invariant.gep.i = getelementptr double, ptr %6, i64 768
  br label %144

144:                                              ; preds = %144, %.preheader.3.i
  %145 = phi i64 [ 0, %.preheader.3.i ], [ %194, %144 ]
  %146 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %193, %144 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %145
  %147 = load double, ptr %gep.i, align 8
  %148 = getelementptr double, ptr %.unpack17, i64 %145
  %149 = load double, ptr %148, align 8
  %150 = fmul double %147, %149
  %151 = fadd double %146, %150
  store double %151, ptr %143, align 8
  %152 = or disjoint i64 %145, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %152
  %153 = load double, ptr %gep.i.1, align 8
  %154 = getelementptr double, ptr %.unpack17, i64 %152
  %155 = load double, ptr %154, align 8
  %156 = fmul double %153, %155
  %157 = fadd double %151, %156
  store double %157, ptr %143, align 8
  %158 = or disjoint i64 %145, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %158
  %159 = load double, ptr %gep.i.2, align 8
  %160 = getelementptr double, ptr %.unpack17, i64 %158
  %161 = load double, ptr %160, align 8
  %162 = fmul double %159, %161
  %163 = fadd double %157, %162
  store double %163, ptr %143, align 8
  %164 = or disjoint i64 %145, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %164
  %165 = load double, ptr %gep.i.3, align 8
  %166 = getelementptr double, ptr %.unpack17, i64 %164
  %167 = load double, ptr %166, align 8
  %168 = fmul double %165, %167
  %169 = fadd double %163, %168
  store double %169, ptr %143, align 8
  %170 = or disjoint i64 %145, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %170
  %171 = load double, ptr %gep.i.4, align 8
  %172 = getelementptr double, ptr %.unpack17, i64 %170
  %173 = load double, ptr %172, align 8
  %174 = fmul double %171, %173
  %175 = fadd double %169, %174
  store double %175, ptr %143, align 8
  %176 = or disjoint i64 %145, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %176
  %177 = load double, ptr %gep.i.5, align 8
  %178 = getelementptr double, ptr %.unpack17, i64 %176
  %179 = load double, ptr %178, align 8
  %180 = fmul double %177, %179
  %181 = fadd double %175, %180
  store double %181, ptr %143, align 8
  %182 = or disjoint i64 %145, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %182
  %183 = load double, ptr %gep.i.6, align 8
  %184 = getelementptr double, ptr %.unpack17, i64 %182
  %185 = load double, ptr %184, align 8
  %186 = fmul double %183, %185
  %187 = fadd double %181, %186
  store double %187, ptr %143, align 8
  %188 = or disjoint i64 %145, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %188
  %189 = load double, ptr %gep.i.7, align 8
  %190 = getelementptr double, ptr %.unpack17, i64 %188
  %191 = load double, ptr %190, align 8
  %192 = fmul double %189, %191
  %193 = fadd double %187, %192
  store double %193, ptr %143, align 8
  %194 = add nuw nsw i64 %145, 8
  %exitcond.3.not.i.7 = icmp eq i64 %194, 256
  br i1 %exitcond.3.not.i.7, label %195, label %144

195:                                              ; preds = %144
  %196 = add nuw nsw i64 %4, 4
  %197 = icmp ult i64 %4, 124
  br i1 %197, label %.preheader3.i, label %kernel.exit

kernel.exit:                                      ; preds = %195
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %10, i8 0, i64 1024, i1 false)
  br label %.preheader3.i

.preheader3.i:                                    ; preds = %202, %1
  %11 = phi i64 [ %203, %202 ], [ 0, %1 ]
  %12 = shl nuw nsw i64 %11, 8
  %13 = getelementptr double, ptr %4, i64 %12
  %14 = getelementptr double, ptr %10, i64 %11
  %.promoted.i = load double, ptr %14, align 8
  br label %15

15:                                               ; preds = %15, %.preheader3.i
  %16 = phi i64 [ 0, %.preheader3.i ], [ %45, %15 ]
  %17 = phi double [ %.promoted.i, %.preheader3.i ], [ %44, %15 ]
  %18 = getelementptr double, ptr %13, i64 %16
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %7, i64 %16
  %21 = load double, ptr %20, align 8
  %22 = fmul double %19, %21
  %23 = fadd double %17, %22
  store double %23, ptr %14, align 8
  %24 = or disjoint i64 %16, 1
  %25 = getelementptr double, ptr %13, i64 %24
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %7, i64 %24
  %28 = load double, ptr %27, align 8
  %29 = fmul double %26, %28
  %30 = fadd double %23, %29
  store double %30, ptr %14, align 8
  %31 = or disjoint i64 %16, 2
  %32 = getelementptr double, ptr %13, i64 %31
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %7, i64 %31
  %35 = load double, ptr %34, align 8
  %36 = fmul double %33, %35
  %37 = fadd double %30, %36
  store double %37, ptr %14, align 8
  %38 = or disjoint i64 %16, 3
  %39 = getelementptr double, ptr %13, i64 %38
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %7, i64 %38
  %42 = load double, ptr %41, align 8
  %43 = fmul double %40, %42
  %44 = fadd double %37, %43
  store double %44, ptr %14, align 8
  %45 = add nuw nsw i64 %16, 4
  %exitcond.not.i.3 = icmp eq i64 %45, 256
  br i1 %exitcond.not.i.3, label %.preheader.1.i, label %15

.preheader.1.i:                                   ; preds = %15
  %46 = getelementptr double, ptr %14, i64 1
  %.promoted.1.i = load double, ptr %46, align 8
  %invariant.gep7.i = getelementptr double, ptr %13, i64 256
  br label %47

47:                                               ; preds = %47, %.preheader.1.i
  %48 = phi i64 [ 0, %.preheader.1.i ], [ %97, %47 ]
  %49 = phi double [ %.promoted.1.i, %.preheader.1.i ], [ %96, %47 ]
  %gep8.i = getelementptr double, ptr %invariant.gep7.i, i64 %48
  %50 = load double, ptr %gep8.i, align 8
  %51 = getelementptr double, ptr %7, i64 %48
  %52 = load double, ptr %51, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %49, %53
  store double %54, ptr %46, align 8
  %55 = or disjoint i64 %48, 1
  %gep8.i.1 = getelementptr double, ptr %invariant.gep7.i, i64 %55
  %56 = load double, ptr %gep8.i.1, align 8
  %57 = getelementptr double, ptr %7, i64 %55
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %54, %59
  store double %60, ptr %46, align 8
  %61 = or disjoint i64 %48, 2
  %gep8.i.2 = getelementptr double, ptr %invariant.gep7.i, i64 %61
  %62 = load double, ptr %gep8.i.2, align 8
  %63 = getelementptr double, ptr %7, i64 %61
  %64 = load double, ptr %63, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %60, %65
  store double %66, ptr %46, align 8
  %67 = or disjoint i64 %48, 3
  %gep8.i.3 = getelementptr double, ptr %invariant.gep7.i, i64 %67
  %68 = load double, ptr %gep8.i.3, align 8
  %69 = getelementptr double, ptr %7, i64 %67
  %70 = load double, ptr %69, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %46, align 8
  %73 = or disjoint i64 %48, 4
  %gep8.i.4 = getelementptr double, ptr %invariant.gep7.i, i64 %73
  %74 = load double, ptr %gep8.i.4, align 8
  %75 = getelementptr double, ptr %7, i64 %73
  %76 = load double, ptr %75, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %72, %77
  store double %78, ptr %46, align 8
  %79 = or disjoint i64 %48, 5
  %gep8.i.5 = getelementptr double, ptr %invariant.gep7.i, i64 %79
  %80 = load double, ptr %gep8.i.5, align 8
  %81 = getelementptr double, ptr %7, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %46, align 8
  %85 = or disjoint i64 %48, 6
  %gep8.i.6 = getelementptr double, ptr %invariant.gep7.i, i64 %85
  %86 = load double, ptr %gep8.i.6, align 8
  %87 = getelementptr double, ptr %7, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %46, align 8
  %91 = or disjoint i64 %48, 7
  %gep8.i.7 = getelementptr double, ptr %invariant.gep7.i, i64 %91
  %92 = load double, ptr %gep8.i.7, align 8
  %93 = getelementptr double, ptr %7, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %46, align 8
  %97 = add nuw nsw i64 %48, 8
  %exitcond.1.not.i.7 = icmp eq i64 %97, 256
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %47

.preheader.2.i:                                   ; preds = %47
  %98 = getelementptr double, ptr %14, i64 2
  %.promoted.2.i = load double, ptr %98, align 8
  %invariant.gep5.i = getelementptr double, ptr %13, i64 512
  br label %99

99:                                               ; preds = %99, %.preheader.2.i
  %100 = phi i64 [ 0, %.preheader.2.i ], [ %149, %99 ]
  %101 = phi double [ %.promoted.2.i, %.preheader.2.i ], [ %148, %99 ]
  %gep6.i = getelementptr double, ptr %invariant.gep5.i, i64 %100
  %102 = load double, ptr %gep6.i, align 8
  %103 = getelementptr double, ptr %7, i64 %100
  %104 = load double, ptr %103, align 8
  %105 = fmul double %102, %104
  %106 = fadd double %101, %105
  store double %106, ptr %98, align 8
  %107 = or disjoint i64 %100, 1
  %gep6.i.1 = getelementptr double, ptr %invariant.gep5.i, i64 %107
  %108 = load double, ptr %gep6.i.1, align 8
  %109 = getelementptr double, ptr %7, i64 %107
  %110 = load double, ptr %109, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %106, %111
  store double %112, ptr %98, align 8
  %113 = or disjoint i64 %100, 2
  %gep6.i.2 = getelementptr double, ptr %invariant.gep5.i, i64 %113
  %114 = load double, ptr %gep6.i.2, align 8
  %115 = getelementptr double, ptr %7, i64 %113
  %116 = load double, ptr %115, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %112, %117
  store double %118, ptr %98, align 8
  %119 = or disjoint i64 %100, 3
  %gep6.i.3 = getelementptr double, ptr %invariant.gep5.i, i64 %119
  %120 = load double, ptr %gep6.i.3, align 8
  %121 = getelementptr double, ptr %7, i64 %119
  %122 = load double, ptr %121, align 8
  %123 = fmul double %120, %122
  %124 = fadd double %118, %123
  store double %124, ptr %98, align 8
  %125 = or disjoint i64 %100, 4
  %gep6.i.4 = getelementptr double, ptr %invariant.gep5.i, i64 %125
  %126 = load double, ptr %gep6.i.4, align 8
  %127 = getelementptr double, ptr %7, i64 %125
  %128 = load double, ptr %127, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %124, %129
  store double %130, ptr %98, align 8
  %131 = or disjoint i64 %100, 5
  %gep6.i.5 = getelementptr double, ptr %invariant.gep5.i, i64 %131
  %132 = load double, ptr %gep6.i.5, align 8
  %133 = getelementptr double, ptr %7, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %98, align 8
  %137 = or disjoint i64 %100, 6
  %gep6.i.6 = getelementptr double, ptr %invariant.gep5.i, i64 %137
  %138 = load double, ptr %gep6.i.6, align 8
  %139 = getelementptr double, ptr %7, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %98, align 8
  %143 = or disjoint i64 %100, 7
  %gep6.i.7 = getelementptr double, ptr %invariant.gep5.i, i64 %143
  %144 = load double, ptr %gep6.i.7, align 8
  %145 = getelementptr double, ptr %7, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %98, align 8
  %149 = add nuw nsw i64 %100, 8
  %exitcond.2.not.i.7 = icmp eq i64 %149, 256
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %99

.preheader.3.i:                                   ; preds = %99
  %150 = getelementptr double, ptr %14, i64 3
  %.promoted.3.i = load double, ptr %150, align 8
  %invariant.gep.i = getelementptr double, ptr %13, i64 768
  br label %151

151:                                              ; preds = %151, %.preheader.3.i
  %152 = phi i64 [ 0, %.preheader.3.i ], [ %201, %151 ]
  %153 = phi double [ %.promoted.3.i, %.preheader.3.i ], [ %200, %151 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %152
  %154 = load double, ptr %gep.i, align 8
  %155 = getelementptr double, ptr %7, i64 %152
  %156 = load double, ptr %155, align 8
  %157 = fmul double %154, %156
  %158 = fadd double %153, %157
  store double %158, ptr %150, align 8
  %159 = or disjoint i64 %152, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %159
  %160 = load double, ptr %gep.i.1, align 8
  %161 = getelementptr double, ptr %7, i64 %159
  %162 = load double, ptr %161, align 8
  %163 = fmul double %160, %162
  %164 = fadd double %158, %163
  store double %164, ptr %150, align 8
  %165 = or disjoint i64 %152, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %165
  %166 = load double, ptr %gep.i.2, align 8
  %167 = getelementptr double, ptr %7, i64 %165
  %168 = load double, ptr %167, align 8
  %169 = fmul double %166, %168
  %170 = fadd double %164, %169
  store double %170, ptr %150, align 8
  %171 = or disjoint i64 %152, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %171
  %172 = load double, ptr %gep.i.3, align 8
  %173 = getelementptr double, ptr %7, i64 %171
  %174 = load double, ptr %173, align 8
  %175 = fmul double %172, %174
  %176 = fadd double %170, %175
  store double %176, ptr %150, align 8
  %177 = or disjoint i64 %152, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %177
  %178 = load double, ptr %gep.i.4, align 8
  %179 = getelementptr double, ptr %7, i64 %177
  %180 = load double, ptr %179, align 8
  %181 = fmul double %178, %180
  %182 = fadd double %176, %181
  store double %182, ptr %150, align 8
  %183 = or disjoint i64 %152, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %183
  %184 = load double, ptr %gep.i.5, align 8
  %185 = getelementptr double, ptr %7, i64 %183
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %182, %187
  store double %188, ptr %150, align 8
  %189 = or disjoint i64 %152, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %189
  %190 = load double, ptr %gep.i.6, align 8
  %191 = getelementptr double, ptr %7, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %150, align 8
  %195 = or disjoint i64 %152, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %195
  %196 = load double, ptr %gep.i.7, align 8
  %197 = getelementptr double, ptr %7, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %150, align 8
  %201 = add nuw nsw i64 %152, 8
  %exitcond.3.not.i.7 = icmp eq i64 %201, 256
  br i1 %exitcond.3.not.i.7, label %202, label %151

202:                                              ; preds = %151
  %203 = add nuw nsw i64 %11, 4
  %204 = icmp ult i64 %11, 124
  br i1 %204, label %.preheader3.i, label %kernel.exit

kernel.exit:                                      ; preds = %202
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(1024) %.unpack28.i, i8 0, i64 1024, i1 false)
  br label %.preheader3.i.i

.preheader3.i.i:                                  ; preds = %201, %1
  %10 = phi i64 [ %202, %201 ], [ 0, %1 ]
  %11 = shl nuw nsw i64 %10, 8
  %12 = getelementptr double, ptr %.unpack2.i, i64 %11
  %13 = getelementptr double, ptr %.unpack28.i, i64 %10
  %.promoted.i.i = load double, ptr %13, align 8
  br label %14

14:                                               ; preds = %14, %.preheader3.i.i
  %15 = phi i64 [ 0, %.preheader3.i.i ], [ %44, %14 ]
  %16 = phi double [ %.promoted.i.i, %.preheader3.i.i ], [ %43, %14 ]
  %17 = getelementptr double, ptr %12, i64 %15
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %.unpack17.i, i64 %15
  %20 = load double, ptr %19, align 8
  %21 = fmul double %18, %20
  %22 = fadd double %16, %21
  store double %22, ptr %13, align 8
  %23 = or disjoint i64 %15, 1
  %24 = getelementptr double, ptr %12, i64 %23
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %.unpack17.i, i64 %23
  %27 = load double, ptr %26, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %22, %28
  store double %29, ptr %13, align 8
  %30 = or disjoint i64 %15, 2
  %31 = getelementptr double, ptr %12, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %.unpack17.i, i64 %30
  %34 = load double, ptr %33, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %29, %35
  store double %36, ptr %13, align 8
  %37 = or disjoint i64 %15, 3
  %38 = getelementptr double, ptr %12, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %.unpack17.i, i64 %37
  %41 = load double, ptr %40, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %13, align 8
  %44 = add nuw nsw i64 %15, 4
  %exitcond.not.i.i.3 = icmp eq i64 %44, 256
  br i1 %exitcond.not.i.i.3, label %.preheader.1.i.i, label %14

.preheader.1.i.i:                                 ; preds = %14
  %45 = getelementptr double, ptr %13, i64 1
  %.promoted.1.i.i = load double, ptr %45, align 8
  %invariant.gep7.i.i = getelementptr double, ptr %12, i64 256
  br label %46

46:                                               ; preds = %46, %.preheader.1.i.i
  %47 = phi i64 [ 0, %.preheader.1.i.i ], [ %96, %46 ]
  %48 = phi double [ %.promoted.1.i.i, %.preheader.1.i.i ], [ %95, %46 ]
  %gep8.i.i = getelementptr double, ptr %invariant.gep7.i.i, i64 %47
  %49 = load double, ptr %gep8.i.i, align 8
  %50 = getelementptr double, ptr %.unpack17.i, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %48, %52
  store double %53, ptr %45, align 8
  %54 = or disjoint i64 %47, 1
  %gep8.i.i.1 = getelementptr double, ptr %invariant.gep7.i.i, i64 %54
  %55 = load double, ptr %gep8.i.i.1, align 8
  %56 = getelementptr double, ptr %.unpack17.i, i64 %54
  %57 = load double, ptr %56, align 8
  %58 = fmul double %55, %57
  %59 = fadd double %53, %58
  store double %59, ptr %45, align 8
  %60 = or disjoint i64 %47, 2
  %gep8.i.i.2 = getelementptr double, ptr %invariant.gep7.i.i, i64 %60
  %61 = load double, ptr %gep8.i.i.2, align 8
  %62 = getelementptr double, ptr %.unpack17.i, i64 %60
  %63 = load double, ptr %62, align 8
  %64 = fmul double %61, %63
  %65 = fadd double %59, %64
  store double %65, ptr %45, align 8
  %66 = or disjoint i64 %47, 3
  %gep8.i.i.3 = getelementptr double, ptr %invariant.gep7.i.i, i64 %66
  %67 = load double, ptr %gep8.i.i.3, align 8
  %68 = getelementptr double, ptr %.unpack17.i, i64 %66
  %69 = load double, ptr %68, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %65, %70
  store double %71, ptr %45, align 8
  %72 = or disjoint i64 %47, 4
  %gep8.i.i.4 = getelementptr double, ptr %invariant.gep7.i.i, i64 %72
  %73 = load double, ptr %gep8.i.i.4, align 8
  %74 = getelementptr double, ptr %.unpack17.i, i64 %72
  %75 = load double, ptr %74, align 8
  %76 = fmul double %73, %75
  %77 = fadd double %71, %76
  store double %77, ptr %45, align 8
  %78 = or disjoint i64 %47, 5
  %gep8.i.i.5 = getelementptr double, ptr %invariant.gep7.i.i, i64 %78
  %79 = load double, ptr %gep8.i.i.5, align 8
  %80 = getelementptr double, ptr %.unpack17.i, i64 %78
  %81 = load double, ptr %80, align 8
  %82 = fmul double %79, %81
  %83 = fadd double %77, %82
  store double %83, ptr %45, align 8
  %84 = or disjoint i64 %47, 6
  %gep8.i.i.6 = getelementptr double, ptr %invariant.gep7.i.i, i64 %84
  %85 = load double, ptr %gep8.i.i.6, align 8
  %86 = getelementptr double, ptr %.unpack17.i, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %83, %88
  store double %89, ptr %45, align 8
  %90 = or disjoint i64 %47, 7
  %gep8.i.i.7 = getelementptr double, ptr %invariant.gep7.i.i, i64 %90
  %91 = load double, ptr %gep8.i.i.7, align 8
  %92 = getelementptr double, ptr %.unpack17.i, i64 %90
  %93 = load double, ptr %92, align 8
  %94 = fmul double %91, %93
  %95 = fadd double %89, %94
  store double %95, ptr %45, align 8
  %96 = add nuw nsw i64 %47, 8
  %exitcond.1.not.i.i.7 = icmp eq i64 %96, 256
  br i1 %exitcond.1.not.i.i.7, label %.preheader.2.i.i, label %46

.preheader.2.i.i:                                 ; preds = %46
  %97 = getelementptr double, ptr %13, i64 2
  %.promoted.2.i.i = load double, ptr %97, align 8
  %invariant.gep5.i.i = getelementptr double, ptr %12, i64 512
  br label %98

98:                                               ; preds = %98, %.preheader.2.i.i
  %99 = phi i64 [ 0, %.preheader.2.i.i ], [ %148, %98 ]
  %100 = phi double [ %.promoted.2.i.i, %.preheader.2.i.i ], [ %147, %98 ]
  %gep6.i.i = getelementptr double, ptr %invariant.gep5.i.i, i64 %99
  %101 = load double, ptr %gep6.i.i, align 8
  %102 = getelementptr double, ptr %.unpack17.i, i64 %99
  %103 = load double, ptr %102, align 8
  %104 = fmul double %101, %103
  %105 = fadd double %100, %104
  store double %105, ptr %97, align 8
  %106 = or disjoint i64 %99, 1
  %gep6.i.i.1 = getelementptr double, ptr %invariant.gep5.i.i, i64 %106
  %107 = load double, ptr %gep6.i.i.1, align 8
  %108 = getelementptr double, ptr %.unpack17.i, i64 %106
  %109 = load double, ptr %108, align 8
  %110 = fmul double %107, %109
  %111 = fadd double %105, %110
  store double %111, ptr %97, align 8
  %112 = or disjoint i64 %99, 2
  %gep6.i.i.2 = getelementptr double, ptr %invariant.gep5.i.i, i64 %112
  %113 = load double, ptr %gep6.i.i.2, align 8
  %114 = getelementptr double, ptr %.unpack17.i, i64 %112
  %115 = load double, ptr %114, align 8
  %116 = fmul double %113, %115
  %117 = fadd double %111, %116
  store double %117, ptr %97, align 8
  %118 = or disjoint i64 %99, 3
  %gep6.i.i.3 = getelementptr double, ptr %invariant.gep5.i.i, i64 %118
  %119 = load double, ptr %gep6.i.i.3, align 8
  %120 = getelementptr double, ptr %.unpack17.i, i64 %118
  %121 = load double, ptr %120, align 8
  %122 = fmul double %119, %121
  %123 = fadd double %117, %122
  store double %123, ptr %97, align 8
  %124 = or disjoint i64 %99, 4
  %gep6.i.i.4 = getelementptr double, ptr %invariant.gep5.i.i, i64 %124
  %125 = load double, ptr %gep6.i.i.4, align 8
  %126 = getelementptr double, ptr %.unpack17.i, i64 %124
  %127 = load double, ptr %126, align 8
  %128 = fmul double %125, %127
  %129 = fadd double %123, %128
  store double %129, ptr %97, align 8
  %130 = or disjoint i64 %99, 5
  %gep6.i.i.5 = getelementptr double, ptr %invariant.gep5.i.i, i64 %130
  %131 = load double, ptr %gep6.i.i.5, align 8
  %132 = getelementptr double, ptr %.unpack17.i, i64 %130
  %133 = load double, ptr %132, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %129, %134
  store double %135, ptr %97, align 8
  %136 = or disjoint i64 %99, 6
  %gep6.i.i.6 = getelementptr double, ptr %invariant.gep5.i.i, i64 %136
  %137 = load double, ptr %gep6.i.i.6, align 8
  %138 = getelementptr double, ptr %.unpack17.i, i64 %136
  %139 = load double, ptr %138, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %135, %140
  store double %141, ptr %97, align 8
  %142 = or disjoint i64 %99, 7
  %gep6.i.i.7 = getelementptr double, ptr %invariant.gep5.i.i, i64 %142
  %143 = load double, ptr %gep6.i.i.7, align 8
  %144 = getelementptr double, ptr %.unpack17.i, i64 %142
  %145 = load double, ptr %144, align 8
  %146 = fmul double %143, %145
  %147 = fadd double %141, %146
  store double %147, ptr %97, align 8
  %148 = add nuw nsw i64 %99, 8
  %exitcond.2.not.i.i.7 = icmp eq i64 %148, 256
  br i1 %exitcond.2.not.i.i.7, label %.preheader.3.i.i, label %98

.preheader.3.i.i:                                 ; preds = %98
  %149 = getelementptr double, ptr %13, i64 3
  %.promoted.3.i.i = load double, ptr %149, align 8
  %invariant.gep.i.i = getelementptr double, ptr %12, i64 768
  br label %150

150:                                              ; preds = %150, %.preheader.3.i.i
  %151 = phi i64 [ 0, %.preheader.3.i.i ], [ %200, %150 ]
  %152 = phi double [ %.promoted.3.i.i, %.preheader.3.i.i ], [ %199, %150 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %151
  %153 = load double, ptr %gep.i.i, align 8
  %154 = getelementptr double, ptr %.unpack17.i, i64 %151
  %155 = load double, ptr %154, align 8
  %156 = fmul double %153, %155
  %157 = fadd double %152, %156
  store double %157, ptr %149, align 8
  %158 = or disjoint i64 %151, 1
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %158
  %159 = load double, ptr %gep.i.i.1, align 8
  %160 = getelementptr double, ptr %.unpack17.i, i64 %158
  %161 = load double, ptr %160, align 8
  %162 = fmul double %159, %161
  %163 = fadd double %157, %162
  store double %163, ptr %149, align 8
  %164 = or disjoint i64 %151, 2
  %gep.i.i.2 = getelementptr double, ptr %invariant.gep.i.i, i64 %164
  %165 = load double, ptr %gep.i.i.2, align 8
  %166 = getelementptr double, ptr %.unpack17.i, i64 %164
  %167 = load double, ptr %166, align 8
  %168 = fmul double %165, %167
  %169 = fadd double %163, %168
  store double %169, ptr %149, align 8
  %170 = or disjoint i64 %151, 3
  %gep.i.i.3 = getelementptr double, ptr %invariant.gep.i.i, i64 %170
  %171 = load double, ptr %gep.i.i.3, align 8
  %172 = getelementptr double, ptr %.unpack17.i, i64 %170
  %173 = load double, ptr %172, align 8
  %174 = fmul double %171, %173
  %175 = fadd double %169, %174
  store double %175, ptr %149, align 8
  %176 = or disjoint i64 %151, 4
  %gep.i.i.4 = getelementptr double, ptr %invariant.gep.i.i, i64 %176
  %177 = load double, ptr %gep.i.i.4, align 8
  %178 = getelementptr double, ptr %.unpack17.i, i64 %176
  %179 = load double, ptr %178, align 8
  %180 = fmul double %177, %179
  %181 = fadd double %175, %180
  store double %181, ptr %149, align 8
  %182 = or disjoint i64 %151, 5
  %gep.i.i.5 = getelementptr double, ptr %invariant.gep.i.i, i64 %182
  %183 = load double, ptr %gep.i.i.5, align 8
  %184 = getelementptr double, ptr %.unpack17.i, i64 %182
  %185 = load double, ptr %184, align 8
  %186 = fmul double %183, %185
  %187 = fadd double %181, %186
  store double %187, ptr %149, align 8
  %188 = or disjoint i64 %151, 6
  %gep.i.i.6 = getelementptr double, ptr %invariant.gep.i.i, i64 %188
  %189 = load double, ptr %gep.i.i.6, align 8
  %190 = getelementptr double, ptr %.unpack17.i, i64 %188
  %191 = load double, ptr %190, align 8
  %192 = fmul double %189, %191
  %193 = fadd double %187, %192
  store double %193, ptr %149, align 8
  %194 = or disjoint i64 %151, 7
  %gep.i.i.7 = getelementptr double, ptr %invariant.gep.i.i, i64 %194
  %195 = load double, ptr %gep.i.i.7, align 8
  %196 = getelementptr double, ptr %.unpack17.i, i64 %194
  %197 = load double, ptr %196, align 8
  %198 = fmul double %195, %197
  %199 = fadd double %193, %198
  store double %199, ptr %149, align 8
  %200 = add nuw nsw i64 %151, 8
  %exitcond.3.not.i.i.7 = icmp eq i64 %200, 256
  br i1 %exitcond.3.not.i.i.7, label %201, label %150

201:                                              ; preds = %150
  %202 = add nuw nsw i64 %10, 4
  %203 = icmp ult i64 %10, 124
  br i1 %203, label %.preheader3.i.i, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %201
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
