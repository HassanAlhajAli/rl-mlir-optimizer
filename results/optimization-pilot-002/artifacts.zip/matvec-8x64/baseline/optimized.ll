; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %13, i8 0, i64 64, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader.preheader
  %18 = phi i64 [ 0, %.preheader.preheader ], [ %75, %17 ]
  %19 = phi double [ 0.000000e+00, %.preheader.preheader ], [ %74, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %8, i64 %18
  %23 = load double, ptr %22, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %13, align 8
  %26 = or disjoint i64 %18, 1
  %27 = getelementptr double, ptr %1, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %13, align 8
  %33 = or disjoint i64 %18, 2
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %33
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %13, align 8
  %40 = or disjoint i64 %18, 3
  %41 = getelementptr double, ptr %1, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %8, i64 %40
  %44 = load double, ptr %43, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %13, align 8
  %47 = or disjoint i64 %18, 4
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %8, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %46, %52
  store double %53, ptr %13, align 8
  %54 = or disjoint i64 %18, 5
  %55 = getelementptr double, ptr %1, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %53, %59
  store double %60, ptr %13, align 8
  %61 = or disjoint i64 %18, 6
  %62 = getelementptr double, ptr %1, i64 %61
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %8, i64 %61
  %65 = load double, ptr %64, align 8
  %66 = fmul double %63, %65
  %67 = fadd double %60, %66
  store double %67, ptr %13, align 8
  %68 = or disjoint i64 %18, 7
  %69 = getelementptr double, ptr %1, i64 %68
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %68
  %72 = load double, ptr %71, align 8
  %73 = fmul double %70, %72
  %74 = fadd double %67, %73
  store double %74, ptr %13, align 8
  %75 = add nuw nsw i64 %18, 8
  %exitcond.not.7 = icmp eq i64 %75, 64
  br i1 %exitcond.not.7, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %76 = getelementptr double, ptr %13, i64 1
  %invariant.gep = getelementptr double, ptr %1, i64 64
  br label %77

77:                                               ; preds = %77, %.preheader.1
  %78 = phi i64 [ 0, %.preheader.1 ], [ %127, %77 ]
  %79 = phi double [ 0.000000e+00, %.preheader.1 ], [ %126, %77 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %78
  %80 = load double, ptr %gep, align 8
  %81 = getelementptr double, ptr %8, i64 %78
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %79, %83
  store double %84, ptr %76, align 8
  %85 = or disjoint i64 %78, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %85
  %86 = load double, ptr %gep.1, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %76, align 8
  %91 = or disjoint i64 %78, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %91
  %92 = load double, ptr %gep.2, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %76, align 8
  %97 = or disjoint i64 %78, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %97
  %98 = load double, ptr %gep.3, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %76, align 8
  %103 = or disjoint i64 %78, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %103
  %104 = load double, ptr %gep.4, align 8
  %105 = getelementptr double, ptr %8, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %76, align 8
  %109 = or disjoint i64 %78, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %109
  %110 = load double, ptr %gep.5, align 8
  %111 = getelementptr double, ptr %8, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %76, align 8
  %115 = or disjoint i64 %78, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %115
  %116 = load double, ptr %gep.6, align 8
  %117 = getelementptr double, ptr %8, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %76, align 8
  %121 = or disjoint i64 %78, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %121
  %122 = load double, ptr %gep.7, align 8
  %123 = getelementptr double, ptr %8, i64 %121
  %124 = load double, ptr %123, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %120, %125
  store double %126, ptr %76, align 8
  %127 = add nuw nsw i64 %78, 8
  %exitcond.1.not.7 = icmp eq i64 %127, 64
  br i1 %exitcond.1.not.7, label %.preheader.2, label %77

.preheader.2:                                     ; preds = %77
  %128 = getelementptr double, ptr %13, i64 2
  %invariant.gep4 = getelementptr double, ptr %1, i64 128
  br label %129

129:                                              ; preds = %129, %.preheader.2
  %130 = phi i64 [ 0, %.preheader.2 ], [ %179, %129 ]
  %131 = phi double [ 0.000000e+00, %.preheader.2 ], [ %178, %129 ]
  %gep5 = getelementptr double, ptr %invariant.gep4, i64 %130
  %132 = load double, ptr %gep5, align 8
  %133 = getelementptr double, ptr %8, i64 %130
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %131, %135
  store double %136, ptr %128, align 8
  %137 = or disjoint i64 %130, 1
  %gep5.1 = getelementptr double, ptr %invariant.gep4, i64 %137
  %138 = load double, ptr %gep5.1, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %128, align 8
  %143 = or disjoint i64 %130, 2
  %gep5.2 = getelementptr double, ptr %invariant.gep4, i64 %143
  %144 = load double, ptr %gep5.2, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %128, align 8
  %149 = or disjoint i64 %130, 3
  %gep5.3 = getelementptr double, ptr %invariant.gep4, i64 %149
  %150 = load double, ptr %gep5.3, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %128, align 8
  %155 = or disjoint i64 %130, 4
  %gep5.4 = getelementptr double, ptr %invariant.gep4, i64 %155
  %156 = load double, ptr %gep5.4, align 8
  %157 = getelementptr double, ptr %8, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %128, align 8
  %161 = or disjoint i64 %130, 5
  %gep5.5 = getelementptr double, ptr %invariant.gep4, i64 %161
  %162 = load double, ptr %gep5.5, align 8
  %163 = getelementptr double, ptr %8, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %128, align 8
  %167 = or disjoint i64 %130, 6
  %gep5.6 = getelementptr double, ptr %invariant.gep4, i64 %167
  %168 = load double, ptr %gep5.6, align 8
  %169 = getelementptr double, ptr %8, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %128, align 8
  %173 = or disjoint i64 %130, 7
  %gep5.7 = getelementptr double, ptr %invariant.gep4, i64 %173
  %174 = load double, ptr %gep5.7, align 8
  %175 = getelementptr double, ptr %8, i64 %173
  %176 = load double, ptr %175, align 8
  %177 = fmul double %174, %176
  %178 = fadd double %172, %177
  store double %178, ptr %128, align 8
  %179 = add nuw nsw i64 %130, 8
  %exitcond.2.not.7 = icmp eq i64 %179, 64
  br i1 %exitcond.2.not.7, label %.preheader.3, label %129

.preheader.3:                                     ; preds = %129
  %180 = getelementptr double, ptr %13, i64 3
  %invariant.gep6 = getelementptr double, ptr %1, i64 192
  br label %181

181:                                              ; preds = %181, %.preheader.3
  %182 = phi i64 [ 0, %.preheader.3 ], [ %231, %181 ]
  %183 = phi double [ 0.000000e+00, %.preheader.3 ], [ %230, %181 ]
  %gep7 = getelementptr double, ptr %invariant.gep6, i64 %182
  %184 = load double, ptr %gep7, align 8
  %185 = getelementptr double, ptr %8, i64 %182
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %183, %187
  store double %188, ptr %180, align 8
  %189 = or disjoint i64 %182, 1
  %gep7.1 = getelementptr double, ptr %invariant.gep6, i64 %189
  %190 = load double, ptr %gep7.1, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %180, align 8
  %195 = or disjoint i64 %182, 2
  %gep7.2 = getelementptr double, ptr %invariant.gep6, i64 %195
  %196 = load double, ptr %gep7.2, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %180, align 8
  %201 = or disjoint i64 %182, 3
  %gep7.3 = getelementptr double, ptr %invariant.gep6, i64 %201
  %202 = load double, ptr %gep7.3, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %180, align 8
  %207 = or disjoint i64 %182, 4
  %gep7.4 = getelementptr double, ptr %invariant.gep6, i64 %207
  %208 = load double, ptr %gep7.4, align 8
  %209 = getelementptr double, ptr %8, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %180, align 8
  %213 = or disjoint i64 %182, 5
  %gep7.5 = getelementptr double, ptr %invariant.gep6, i64 %213
  %214 = load double, ptr %gep7.5, align 8
  %215 = getelementptr double, ptr %8, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %180, align 8
  %219 = or disjoint i64 %182, 6
  %gep7.6 = getelementptr double, ptr %invariant.gep6, i64 %219
  %220 = load double, ptr %gep7.6, align 8
  %221 = getelementptr double, ptr %8, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %180, align 8
  %225 = or disjoint i64 %182, 7
  %gep7.7 = getelementptr double, ptr %invariant.gep6, i64 %225
  %226 = load double, ptr %gep7.7, align 8
  %227 = getelementptr double, ptr %8, i64 %225
  %228 = load double, ptr %227, align 8
  %229 = fmul double %226, %228
  %230 = fadd double %224, %229
  store double %230, ptr %180, align 8
  %231 = add nuw nsw i64 %182, 8
  %exitcond.3.not.7 = icmp eq i64 %231, 64
  br i1 %exitcond.3.not.7, label %.preheader.4, label %181

.preheader.4:                                     ; preds = %181
  %232 = getelementptr double, ptr %13, i64 4
  %invariant.gep8 = getelementptr double, ptr %1, i64 256
  br label %233

233:                                              ; preds = %233, %.preheader.4
  %234 = phi i64 [ 0, %.preheader.4 ], [ %283, %233 ]
  %235 = phi double [ 0.000000e+00, %.preheader.4 ], [ %282, %233 ]
  %gep9 = getelementptr double, ptr %invariant.gep8, i64 %234
  %236 = load double, ptr %gep9, align 8
  %237 = getelementptr double, ptr %8, i64 %234
  %238 = load double, ptr %237, align 8
  %239 = fmul double %236, %238
  %240 = fadd double %235, %239
  store double %240, ptr %232, align 8
  %241 = or disjoint i64 %234, 1
  %gep9.1 = getelementptr double, ptr %invariant.gep8, i64 %241
  %242 = load double, ptr %gep9.1, align 8
  %243 = getelementptr double, ptr %8, i64 %241
  %244 = load double, ptr %243, align 8
  %245 = fmul double %242, %244
  %246 = fadd double %240, %245
  store double %246, ptr %232, align 8
  %247 = or disjoint i64 %234, 2
  %gep9.2 = getelementptr double, ptr %invariant.gep8, i64 %247
  %248 = load double, ptr %gep9.2, align 8
  %249 = getelementptr double, ptr %8, i64 %247
  %250 = load double, ptr %249, align 8
  %251 = fmul double %248, %250
  %252 = fadd double %246, %251
  store double %252, ptr %232, align 8
  %253 = or disjoint i64 %234, 3
  %gep9.3 = getelementptr double, ptr %invariant.gep8, i64 %253
  %254 = load double, ptr %gep9.3, align 8
  %255 = getelementptr double, ptr %8, i64 %253
  %256 = load double, ptr %255, align 8
  %257 = fmul double %254, %256
  %258 = fadd double %252, %257
  store double %258, ptr %232, align 8
  %259 = or disjoint i64 %234, 4
  %gep9.4 = getelementptr double, ptr %invariant.gep8, i64 %259
  %260 = load double, ptr %gep9.4, align 8
  %261 = getelementptr double, ptr %8, i64 %259
  %262 = load double, ptr %261, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %258, %263
  store double %264, ptr %232, align 8
  %265 = or disjoint i64 %234, 5
  %gep9.5 = getelementptr double, ptr %invariant.gep8, i64 %265
  %266 = load double, ptr %gep9.5, align 8
  %267 = getelementptr double, ptr %8, i64 %265
  %268 = load double, ptr %267, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %264, %269
  store double %270, ptr %232, align 8
  %271 = or disjoint i64 %234, 6
  %gep9.6 = getelementptr double, ptr %invariant.gep8, i64 %271
  %272 = load double, ptr %gep9.6, align 8
  %273 = getelementptr double, ptr %8, i64 %271
  %274 = load double, ptr %273, align 8
  %275 = fmul double %272, %274
  %276 = fadd double %270, %275
  store double %276, ptr %232, align 8
  %277 = or disjoint i64 %234, 7
  %gep9.7 = getelementptr double, ptr %invariant.gep8, i64 %277
  %278 = load double, ptr %gep9.7, align 8
  %279 = getelementptr double, ptr %8, i64 %277
  %280 = load double, ptr %279, align 8
  %281 = fmul double %278, %280
  %282 = fadd double %276, %281
  store double %282, ptr %232, align 8
  %283 = add nuw nsw i64 %234, 8
  %exitcond.4.not.7 = icmp eq i64 %283, 64
  br i1 %exitcond.4.not.7, label %.preheader.5, label %233

.preheader.5:                                     ; preds = %233
  %284 = getelementptr double, ptr %13, i64 5
  %invariant.gep10 = getelementptr double, ptr %1, i64 320
  br label %285

285:                                              ; preds = %285, %.preheader.5
  %286 = phi i64 [ 0, %.preheader.5 ], [ %335, %285 ]
  %287 = phi double [ 0.000000e+00, %.preheader.5 ], [ %334, %285 ]
  %gep11 = getelementptr double, ptr %invariant.gep10, i64 %286
  %288 = load double, ptr %gep11, align 8
  %289 = getelementptr double, ptr %8, i64 %286
  %290 = load double, ptr %289, align 8
  %291 = fmul double %288, %290
  %292 = fadd double %287, %291
  store double %292, ptr %284, align 8
  %293 = or disjoint i64 %286, 1
  %gep11.1 = getelementptr double, ptr %invariant.gep10, i64 %293
  %294 = load double, ptr %gep11.1, align 8
  %295 = getelementptr double, ptr %8, i64 %293
  %296 = load double, ptr %295, align 8
  %297 = fmul double %294, %296
  %298 = fadd double %292, %297
  store double %298, ptr %284, align 8
  %299 = or disjoint i64 %286, 2
  %gep11.2 = getelementptr double, ptr %invariant.gep10, i64 %299
  %300 = load double, ptr %gep11.2, align 8
  %301 = getelementptr double, ptr %8, i64 %299
  %302 = load double, ptr %301, align 8
  %303 = fmul double %300, %302
  %304 = fadd double %298, %303
  store double %304, ptr %284, align 8
  %305 = or disjoint i64 %286, 3
  %gep11.3 = getelementptr double, ptr %invariant.gep10, i64 %305
  %306 = load double, ptr %gep11.3, align 8
  %307 = getelementptr double, ptr %8, i64 %305
  %308 = load double, ptr %307, align 8
  %309 = fmul double %306, %308
  %310 = fadd double %304, %309
  store double %310, ptr %284, align 8
  %311 = or disjoint i64 %286, 4
  %gep11.4 = getelementptr double, ptr %invariant.gep10, i64 %311
  %312 = load double, ptr %gep11.4, align 8
  %313 = getelementptr double, ptr %8, i64 %311
  %314 = load double, ptr %313, align 8
  %315 = fmul double %312, %314
  %316 = fadd double %310, %315
  store double %316, ptr %284, align 8
  %317 = or disjoint i64 %286, 5
  %gep11.5 = getelementptr double, ptr %invariant.gep10, i64 %317
  %318 = load double, ptr %gep11.5, align 8
  %319 = getelementptr double, ptr %8, i64 %317
  %320 = load double, ptr %319, align 8
  %321 = fmul double %318, %320
  %322 = fadd double %316, %321
  store double %322, ptr %284, align 8
  %323 = or disjoint i64 %286, 6
  %gep11.6 = getelementptr double, ptr %invariant.gep10, i64 %323
  %324 = load double, ptr %gep11.6, align 8
  %325 = getelementptr double, ptr %8, i64 %323
  %326 = load double, ptr %325, align 8
  %327 = fmul double %324, %326
  %328 = fadd double %322, %327
  store double %328, ptr %284, align 8
  %329 = or disjoint i64 %286, 7
  %gep11.7 = getelementptr double, ptr %invariant.gep10, i64 %329
  %330 = load double, ptr %gep11.7, align 8
  %331 = getelementptr double, ptr %8, i64 %329
  %332 = load double, ptr %331, align 8
  %333 = fmul double %330, %332
  %334 = fadd double %328, %333
  store double %334, ptr %284, align 8
  %335 = add nuw nsw i64 %286, 8
  %exitcond.5.not.7 = icmp eq i64 %335, 64
  br i1 %exitcond.5.not.7, label %.preheader.6, label %285

.preheader.6:                                     ; preds = %285
  %336 = getelementptr double, ptr %13, i64 6
  %invariant.gep12 = getelementptr double, ptr %1, i64 384
  br label %337

337:                                              ; preds = %337, %.preheader.6
  %338 = phi i64 [ 0, %.preheader.6 ], [ %387, %337 ]
  %339 = phi double [ 0.000000e+00, %.preheader.6 ], [ %386, %337 ]
  %gep13 = getelementptr double, ptr %invariant.gep12, i64 %338
  %340 = load double, ptr %gep13, align 8
  %341 = getelementptr double, ptr %8, i64 %338
  %342 = load double, ptr %341, align 8
  %343 = fmul double %340, %342
  %344 = fadd double %339, %343
  store double %344, ptr %336, align 8
  %345 = or disjoint i64 %338, 1
  %gep13.1 = getelementptr double, ptr %invariant.gep12, i64 %345
  %346 = load double, ptr %gep13.1, align 8
  %347 = getelementptr double, ptr %8, i64 %345
  %348 = load double, ptr %347, align 8
  %349 = fmul double %346, %348
  %350 = fadd double %344, %349
  store double %350, ptr %336, align 8
  %351 = or disjoint i64 %338, 2
  %gep13.2 = getelementptr double, ptr %invariant.gep12, i64 %351
  %352 = load double, ptr %gep13.2, align 8
  %353 = getelementptr double, ptr %8, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = fmul double %352, %354
  %356 = fadd double %350, %355
  store double %356, ptr %336, align 8
  %357 = or disjoint i64 %338, 3
  %gep13.3 = getelementptr double, ptr %invariant.gep12, i64 %357
  %358 = load double, ptr %gep13.3, align 8
  %359 = getelementptr double, ptr %8, i64 %357
  %360 = load double, ptr %359, align 8
  %361 = fmul double %358, %360
  %362 = fadd double %356, %361
  store double %362, ptr %336, align 8
  %363 = or disjoint i64 %338, 4
  %gep13.4 = getelementptr double, ptr %invariant.gep12, i64 %363
  %364 = load double, ptr %gep13.4, align 8
  %365 = getelementptr double, ptr %8, i64 %363
  %366 = load double, ptr %365, align 8
  %367 = fmul double %364, %366
  %368 = fadd double %362, %367
  store double %368, ptr %336, align 8
  %369 = or disjoint i64 %338, 5
  %gep13.5 = getelementptr double, ptr %invariant.gep12, i64 %369
  %370 = load double, ptr %gep13.5, align 8
  %371 = getelementptr double, ptr %8, i64 %369
  %372 = load double, ptr %371, align 8
  %373 = fmul double %370, %372
  %374 = fadd double %368, %373
  store double %374, ptr %336, align 8
  %375 = or disjoint i64 %338, 6
  %gep13.6 = getelementptr double, ptr %invariant.gep12, i64 %375
  %376 = load double, ptr %gep13.6, align 8
  %377 = getelementptr double, ptr %8, i64 %375
  %378 = load double, ptr %377, align 8
  %379 = fmul double %376, %378
  %380 = fadd double %374, %379
  store double %380, ptr %336, align 8
  %381 = or disjoint i64 %338, 7
  %gep13.7 = getelementptr double, ptr %invariant.gep12, i64 %381
  %382 = load double, ptr %gep13.7, align 8
  %383 = getelementptr double, ptr %8, i64 %381
  %384 = load double, ptr %383, align 8
  %385 = fmul double %382, %384
  %386 = fadd double %380, %385
  store double %386, ptr %336, align 8
  %387 = add nuw nsw i64 %338, 8
  %exitcond.6.not.7 = icmp eq i64 %387, 64
  br i1 %exitcond.6.not.7, label %.preheader.7, label %337

.preheader.7:                                     ; preds = %337
  %388 = getelementptr double, ptr %13, i64 7
  %invariant.gep14 = getelementptr double, ptr %1, i64 448
  br label %389

389:                                              ; preds = %389, %.preheader.7
  %390 = phi i64 [ 0, %.preheader.7 ], [ %439, %389 ]
  %391 = phi double [ 0.000000e+00, %.preheader.7 ], [ %438, %389 ]
  %gep15 = getelementptr double, ptr %invariant.gep14, i64 %390
  %392 = load double, ptr %gep15, align 8
  %393 = getelementptr double, ptr %8, i64 %390
  %394 = load double, ptr %393, align 8
  %395 = fmul double %392, %394
  %396 = fadd double %391, %395
  store double %396, ptr %388, align 8
  %397 = or disjoint i64 %390, 1
  %gep15.1 = getelementptr double, ptr %invariant.gep14, i64 %397
  %398 = load double, ptr %gep15.1, align 8
  %399 = getelementptr double, ptr %8, i64 %397
  %400 = load double, ptr %399, align 8
  %401 = fmul double %398, %400
  %402 = fadd double %396, %401
  store double %402, ptr %388, align 8
  %403 = or disjoint i64 %390, 2
  %gep15.2 = getelementptr double, ptr %invariant.gep14, i64 %403
  %404 = load double, ptr %gep15.2, align 8
  %405 = getelementptr double, ptr %8, i64 %403
  %406 = load double, ptr %405, align 8
  %407 = fmul double %404, %406
  %408 = fadd double %402, %407
  store double %408, ptr %388, align 8
  %409 = or disjoint i64 %390, 3
  %gep15.3 = getelementptr double, ptr %invariant.gep14, i64 %409
  %410 = load double, ptr %gep15.3, align 8
  %411 = getelementptr double, ptr %8, i64 %409
  %412 = load double, ptr %411, align 8
  %413 = fmul double %410, %412
  %414 = fadd double %408, %413
  store double %414, ptr %388, align 8
  %415 = or disjoint i64 %390, 4
  %gep15.4 = getelementptr double, ptr %invariant.gep14, i64 %415
  %416 = load double, ptr %gep15.4, align 8
  %417 = getelementptr double, ptr %8, i64 %415
  %418 = load double, ptr %417, align 8
  %419 = fmul double %416, %418
  %420 = fadd double %414, %419
  store double %420, ptr %388, align 8
  %421 = or disjoint i64 %390, 5
  %gep15.5 = getelementptr double, ptr %invariant.gep14, i64 %421
  %422 = load double, ptr %gep15.5, align 8
  %423 = getelementptr double, ptr %8, i64 %421
  %424 = load double, ptr %423, align 8
  %425 = fmul double %422, %424
  %426 = fadd double %420, %425
  store double %426, ptr %388, align 8
  %427 = or disjoint i64 %390, 6
  %gep15.6 = getelementptr double, ptr %invariant.gep14, i64 %427
  %428 = load double, ptr %gep15.6, align 8
  %429 = getelementptr double, ptr %8, i64 %427
  %430 = load double, ptr %429, align 8
  %431 = fmul double %428, %430
  %432 = fadd double %426, %431
  store double %432, ptr %388, align 8
  %433 = or disjoint i64 %390, 7
  %gep15.7 = getelementptr double, ptr %invariant.gep14, i64 %433
  %434 = load double, ptr %gep15.7, align 8
  %435 = getelementptr double, ptr %8, i64 %433
  %436 = load double, ptr %435, align 8
  %437 = fmul double %434, %436
  %438 = fadd double %432, %437
  store double %438, ptr %388, align 8
  %439 = add nuw nsw i64 %390, 8
  %exitcond.7.not.7 = icmp eq i64 %439, 64
  br i1 %exitcond.7.not.7, label %440, label %389

440:                                              ; preds = %389
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28, i8 0, i64 64, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %62, %4 ]
  %6 = phi double [ 0.000000e+00, %3 ], [ %61, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %.unpack17, i64 %5
  %10 = load double, ptr %9, align 8
  %11 = fmul double %8, %10
  %12 = fadd double %6, %11
  store double %12, ptr %.unpack28, align 8
  %13 = or disjoint i64 %5, 1
  %14 = getelementptr double, ptr %.unpack2, i64 %13
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %.unpack17, i64 %13
  %17 = load double, ptr %16, align 8
  %18 = fmul double %15, %17
  %19 = fadd double %12, %18
  store double %19, ptr %.unpack28, align 8
  %20 = or disjoint i64 %5, 2
  %21 = getelementptr double, ptr %.unpack2, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17, i64 %20
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %19, %25
  store double %26, ptr %.unpack28, align 8
  %27 = or disjoint i64 %5, 3
  %28 = getelementptr double, ptr %.unpack2, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %.unpack17, i64 %27
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %.unpack28, align 8
  %34 = or disjoint i64 %5, 4
  %35 = getelementptr double, ptr %.unpack2, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %.unpack17, i64 %34
  %38 = load double, ptr %37, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %.unpack28, align 8
  %41 = or disjoint i64 %5, 5
  %42 = getelementptr double, ptr %.unpack2, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %.unpack17, i64 %41
  %45 = load double, ptr %44, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %40, %46
  store double %47, ptr %.unpack28, align 8
  %48 = or disjoint i64 %5, 6
  %49 = getelementptr double, ptr %.unpack2, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %.unpack17, i64 %48
  %52 = load double, ptr %51, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %47, %53
  store double %54, ptr %.unpack28, align 8
  %55 = or disjoint i64 %5, 7
  %56 = getelementptr double, ptr %.unpack2, i64 %55
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %55
  %59 = load double, ptr %58, align 8
  %60 = fmul double %57, %59
  %61 = fadd double %54, %60
  store double %61, ptr %.unpack28, align 8
  %62 = add nuw nsw i64 %5, 8
  %exitcond.not.i.7 = icmp eq i64 %62, 64
  br i1 %exitcond.not.i.7, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %63 = getelementptr double, ptr %.unpack28, i64 1
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 64
  br label %64

64:                                               ; preds = %64, %.preheader.1.i
  %65 = phi i64 [ 0, %.preheader.1.i ], [ %114, %64 ]
  %66 = phi double [ 0.000000e+00, %.preheader.1.i ], [ %113, %64 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %65
  %67 = load double, ptr %gep.i, align 8
  %68 = getelementptr double, ptr %.unpack17, i64 %65
  %69 = load double, ptr %68, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %66, %70
  store double %71, ptr %63, align 8
  %72 = or disjoint i64 %65, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %72
  %73 = load double, ptr %gep.i.1, align 8
  %74 = getelementptr double, ptr %.unpack17, i64 %72
  %75 = load double, ptr %74, align 8
  %76 = fmul double %73, %75
  %77 = fadd double %71, %76
  store double %77, ptr %63, align 8
  %78 = or disjoint i64 %65, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %78
  %79 = load double, ptr %gep.i.2, align 8
  %80 = getelementptr double, ptr %.unpack17, i64 %78
  %81 = load double, ptr %80, align 8
  %82 = fmul double %79, %81
  %83 = fadd double %77, %82
  store double %83, ptr %63, align 8
  %84 = or disjoint i64 %65, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %84
  %85 = load double, ptr %gep.i.3, align 8
  %86 = getelementptr double, ptr %.unpack17, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %83, %88
  store double %89, ptr %63, align 8
  %90 = or disjoint i64 %65, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %90
  %91 = load double, ptr %gep.i.4, align 8
  %92 = getelementptr double, ptr %.unpack17, i64 %90
  %93 = load double, ptr %92, align 8
  %94 = fmul double %91, %93
  %95 = fadd double %89, %94
  store double %95, ptr %63, align 8
  %96 = or disjoint i64 %65, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %96
  %97 = load double, ptr %gep.i.5, align 8
  %98 = getelementptr double, ptr %.unpack17, i64 %96
  %99 = load double, ptr %98, align 8
  %100 = fmul double %97, %99
  %101 = fadd double %95, %100
  store double %101, ptr %63, align 8
  %102 = or disjoint i64 %65, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %102
  %103 = load double, ptr %gep.i.6, align 8
  %104 = getelementptr double, ptr %.unpack17, i64 %102
  %105 = load double, ptr %104, align 8
  %106 = fmul double %103, %105
  %107 = fadd double %101, %106
  store double %107, ptr %63, align 8
  %108 = or disjoint i64 %65, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %108
  %109 = load double, ptr %gep.i.7, align 8
  %110 = getelementptr double, ptr %.unpack17, i64 %108
  %111 = load double, ptr %110, align 8
  %112 = fmul double %109, %111
  %113 = fadd double %107, %112
  store double %113, ptr %63, align 8
  %114 = add nuw nsw i64 %65, 8
  %exitcond.1.not.i.7 = icmp eq i64 %114, 64
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %64

.preheader.2.i:                                   ; preds = %64
  %115 = getelementptr double, ptr %.unpack28, i64 2
  %invariant.gep4.i = getelementptr double, ptr %.unpack2, i64 128
  br label %116

116:                                              ; preds = %116, %.preheader.2.i
  %117 = phi i64 [ 0, %.preheader.2.i ], [ %166, %116 ]
  %118 = phi double [ 0.000000e+00, %.preheader.2.i ], [ %165, %116 ]
  %gep5.i = getelementptr double, ptr %invariant.gep4.i, i64 %117
  %119 = load double, ptr %gep5.i, align 8
  %120 = getelementptr double, ptr %.unpack17, i64 %117
  %121 = load double, ptr %120, align 8
  %122 = fmul double %119, %121
  %123 = fadd double %118, %122
  store double %123, ptr %115, align 8
  %124 = or disjoint i64 %117, 1
  %gep5.i.1 = getelementptr double, ptr %invariant.gep4.i, i64 %124
  %125 = load double, ptr %gep5.i.1, align 8
  %126 = getelementptr double, ptr %.unpack17, i64 %124
  %127 = load double, ptr %126, align 8
  %128 = fmul double %125, %127
  %129 = fadd double %123, %128
  store double %129, ptr %115, align 8
  %130 = or disjoint i64 %117, 2
  %gep5.i.2 = getelementptr double, ptr %invariant.gep4.i, i64 %130
  %131 = load double, ptr %gep5.i.2, align 8
  %132 = getelementptr double, ptr %.unpack17, i64 %130
  %133 = load double, ptr %132, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %129, %134
  store double %135, ptr %115, align 8
  %136 = or disjoint i64 %117, 3
  %gep5.i.3 = getelementptr double, ptr %invariant.gep4.i, i64 %136
  %137 = load double, ptr %gep5.i.3, align 8
  %138 = getelementptr double, ptr %.unpack17, i64 %136
  %139 = load double, ptr %138, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %135, %140
  store double %141, ptr %115, align 8
  %142 = or disjoint i64 %117, 4
  %gep5.i.4 = getelementptr double, ptr %invariant.gep4.i, i64 %142
  %143 = load double, ptr %gep5.i.4, align 8
  %144 = getelementptr double, ptr %.unpack17, i64 %142
  %145 = load double, ptr %144, align 8
  %146 = fmul double %143, %145
  %147 = fadd double %141, %146
  store double %147, ptr %115, align 8
  %148 = or disjoint i64 %117, 5
  %gep5.i.5 = getelementptr double, ptr %invariant.gep4.i, i64 %148
  %149 = load double, ptr %gep5.i.5, align 8
  %150 = getelementptr double, ptr %.unpack17, i64 %148
  %151 = load double, ptr %150, align 8
  %152 = fmul double %149, %151
  %153 = fadd double %147, %152
  store double %153, ptr %115, align 8
  %154 = or disjoint i64 %117, 6
  %gep5.i.6 = getelementptr double, ptr %invariant.gep4.i, i64 %154
  %155 = load double, ptr %gep5.i.6, align 8
  %156 = getelementptr double, ptr %.unpack17, i64 %154
  %157 = load double, ptr %156, align 8
  %158 = fmul double %155, %157
  %159 = fadd double %153, %158
  store double %159, ptr %115, align 8
  %160 = or disjoint i64 %117, 7
  %gep5.i.7 = getelementptr double, ptr %invariant.gep4.i, i64 %160
  %161 = load double, ptr %gep5.i.7, align 8
  %162 = getelementptr double, ptr %.unpack17, i64 %160
  %163 = load double, ptr %162, align 8
  %164 = fmul double %161, %163
  %165 = fadd double %159, %164
  store double %165, ptr %115, align 8
  %166 = add nuw nsw i64 %117, 8
  %exitcond.2.not.i.7 = icmp eq i64 %166, 64
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %116

.preheader.3.i:                                   ; preds = %116
  %167 = getelementptr double, ptr %.unpack28, i64 3
  %invariant.gep6.i = getelementptr double, ptr %.unpack2, i64 192
  br label %168

168:                                              ; preds = %168, %.preheader.3.i
  %169 = phi i64 [ 0, %.preheader.3.i ], [ %218, %168 ]
  %170 = phi double [ 0.000000e+00, %.preheader.3.i ], [ %217, %168 ]
  %gep7.i = getelementptr double, ptr %invariant.gep6.i, i64 %169
  %171 = load double, ptr %gep7.i, align 8
  %172 = getelementptr double, ptr %.unpack17, i64 %169
  %173 = load double, ptr %172, align 8
  %174 = fmul double %171, %173
  %175 = fadd double %170, %174
  store double %175, ptr %167, align 8
  %176 = or disjoint i64 %169, 1
  %gep7.i.1 = getelementptr double, ptr %invariant.gep6.i, i64 %176
  %177 = load double, ptr %gep7.i.1, align 8
  %178 = getelementptr double, ptr %.unpack17, i64 %176
  %179 = load double, ptr %178, align 8
  %180 = fmul double %177, %179
  %181 = fadd double %175, %180
  store double %181, ptr %167, align 8
  %182 = or disjoint i64 %169, 2
  %gep7.i.2 = getelementptr double, ptr %invariant.gep6.i, i64 %182
  %183 = load double, ptr %gep7.i.2, align 8
  %184 = getelementptr double, ptr %.unpack17, i64 %182
  %185 = load double, ptr %184, align 8
  %186 = fmul double %183, %185
  %187 = fadd double %181, %186
  store double %187, ptr %167, align 8
  %188 = or disjoint i64 %169, 3
  %gep7.i.3 = getelementptr double, ptr %invariant.gep6.i, i64 %188
  %189 = load double, ptr %gep7.i.3, align 8
  %190 = getelementptr double, ptr %.unpack17, i64 %188
  %191 = load double, ptr %190, align 8
  %192 = fmul double %189, %191
  %193 = fadd double %187, %192
  store double %193, ptr %167, align 8
  %194 = or disjoint i64 %169, 4
  %gep7.i.4 = getelementptr double, ptr %invariant.gep6.i, i64 %194
  %195 = load double, ptr %gep7.i.4, align 8
  %196 = getelementptr double, ptr %.unpack17, i64 %194
  %197 = load double, ptr %196, align 8
  %198 = fmul double %195, %197
  %199 = fadd double %193, %198
  store double %199, ptr %167, align 8
  %200 = or disjoint i64 %169, 5
  %gep7.i.5 = getelementptr double, ptr %invariant.gep6.i, i64 %200
  %201 = load double, ptr %gep7.i.5, align 8
  %202 = getelementptr double, ptr %.unpack17, i64 %200
  %203 = load double, ptr %202, align 8
  %204 = fmul double %201, %203
  %205 = fadd double %199, %204
  store double %205, ptr %167, align 8
  %206 = or disjoint i64 %169, 6
  %gep7.i.6 = getelementptr double, ptr %invariant.gep6.i, i64 %206
  %207 = load double, ptr %gep7.i.6, align 8
  %208 = getelementptr double, ptr %.unpack17, i64 %206
  %209 = load double, ptr %208, align 8
  %210 = fmul double %207, %209
  %211 = fadd double %205, %210
  store double %211, ptr %167, align 8
  %212 = or disjoint i64 %169, 7
  %gep7.i.7 = getelementptr double, ptr %invariant.gep6.i, i64 %212
  %213 = load double, ptr %gep7.i.7, align 8
  %214 = getelementptr double, ptr %.unpack17, i64 %212
  %215 = load double, ptr %214, align 8
  %216 = fmul double %213, %215
  %217 = fadd double %211, %216
  store double %217, ptr %167, align 8
  %218 = add nuw nsw i64 %169, 8
  %exitcond.3.not.i.7 = icmp eq i64 %218, 64
  br i1 %exitcond.3.not.i.7, label %.preheader.4.i, label %168

.preheader.4.i:                                   ; preds = %168
  %219 = getelementptr double, ptr %.unpack28, i64 4
  %invariant.gep8.i = getelementptr double, ptr %.unpack2, i64 256
  br label %220

220:                                              ; preds = %220, %.preheader.4.i
  %221 = phi i64 [ 0, %.preheader.4.i ], [ %270, %220 ]
  %222 = phi double [ 0.000000e+00, %.preheader.4.i ], [ %269, %220 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %221
  %223 = load double, ptr %gep9.i, align 8
  %224 = getelementptr double, ptr %.unpack17, i64 %221
  %225 = load double, ptr %224, align 8
  %226 = fmul double %223, %225
  %227 = fadd double %222, %226
  store double %227, ptr %219, align 8
  %228 = or disjoint i64 %221, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %228
  %229 = load double, ptr %gep9.i.1, align 8
  %230 = getelementptr double, ptr %.unpack17, i64 %228
  %231 = load double, ptr %230, align 8
  %232 = fmul double %229, %231
  %233 = fadd double %227, %232
  store double %233, ptr %219, align 8
  %234 = or disjoint i64 %221, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %234
  %235 = load double, ptr %gep9.i.2, align 8
  %236 = getelementptr double, ptr %.unpack17, i64 %234
  %237 = load double, ptr %236, align 8
  %238 = fmul double %235, %237
  %239 = fadd double %233, %238
  store double %239, ptr %219, align 8
  %240 = or disjoint i64 %221, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %240
  %241 = load double, ptr %gep9.i.3, align 8
  %242 = getelementptr double, ptr %.unpack17, i64 %240
  %243 = load double, ptr %242, align 8
  %244 = fmul double %241, %243
  %245 = fadd double %239, %244
  store double %245, ptr %219, align 8
  %246 = or disjoint i64 %221, 4
  %gep9.i.4 = getelementptr double, ptr %invariant.gep8.i, i64 %246
  %247 = load double, ptr %gep9.i.4, align 8
  %248 = getelementptr double, ptr %.unpack17, i64 %246
  %249 = load double, ptr %248, align 8
  %250 = fmul double %247, %249
  %251 = fadd double %245, %250
  store double %251, ptr %219, align 8
  %252 = or disjoint i64 %221, 5
  %gep9.i.5 = getelementptr double, ptr %invariant.gep8.i, i64 %252
  %253 = load double, ptr %gep9.i.5, align 8
  %254 = getelementptr double, ptr %.unpack17, i64 %252
  %255 = load double, ptr %254, align 8
  %256 = fmul double %253, %255
  %257 = fadd double %251, %256
  store double %257, ptr %219, align 8
  %258 = or disjoint i64 %221, 6
  %gep9.i.6 = getelementptr double, ptr %invariant.gep8.i, i64 %258
  %259 = load double, ptr %gep9.i.6, align 8
  %260 = getelementptr double, ptr %.unpack17, i64 %258
  %261 = load double, ptr %260, align 8
  %262 = fmul double %259, %261
  %263 = fadd double %257, %262
  store double %263, ptr %219, align 8
  %264 = or disjoint i64 %221, 7
  %gep9.i.7 = getelementptr double, ptr %invariant.gep8.i, i64 %264
  %265 = load double, ptr %gep9.i.7, align 8
  %266 = getelementptr double, ptr %.unpack17, i64 %264
  %267 = load double, ptr %266, align 8
  %268 = fmul double %265, %267
  %269 = fadd double %263, %268
  store double %269, ptr %219, align 8
  %270 = add nuw nsw i64 %221, 8
  %exitcond.4.not.i.7 = icmp eq i64 %270, 64
  br i1 %exitcond.4.not.i.7, label %.preheader.5.i, label %220

.preheader.5.i:                                   ; preds = %220
  %271 = getelementptr double, ptr %.unpack28, i64 5
  %invariant.gep10.i = getelementptr double, ptr %.unpack2, i64 320
  br label %272

272:                                              ; preds = %272, %.preheader.5.i
  %273 = phi i64 [ 0, %.preheader.5.i ], [ %322, %272 ]
  %274 = phi double [ 0.000000e+00, %.preheader.5.i ], [ %321, %272 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %273
  %275 = load double, ptr %gep11.i, align 8
  %276 = getelementptr double, ptr %.unpack17, i64 %273
  %277 = load double, ptr %276, align 8
  %278 = fmul double %275, %277
  %279 = fadd double %274, %278
  store double %279, ptr %271, align 8
  %280 = or disjoint i64 %273, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %280
  %281 = load double, ptr %gep11.i.1, align 8
  %282 = getelementptr double, ptr %.unpack17, i64 %280
  %283 = load double, ptr %282, align 8
  %284 = fmul double %281, %283
  %285 = fadd double %279, %284
  store double %285, ptr %271, align 8
  %286 = or disjoint i64 %273, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %286
  %287 = load double, ptr %gep11.i.2, align 8
  %288 = getelementptr double, ptr %.unpack17, i64 %286
  %289 = load double, ptr %288, align 8
  %290 = fmul double %287, %289
  %291 = fadd double %285, %290
  store double %291, ptr %271, align 8
  %292 = or disjoint i64 %273, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %292
  %293 = load double, ptr %gep11.i.3, align 8
  %294 = getelementptr double, ptr %.unpack17, i64 %292
  %295 = load double, ptr %294, align 8
  %296 = fmul double %293, %295
  %297 = fadd double %291, %296
  store double %297, ptr %271, align 8
  %298 = or disjoint i64 %273, 4
  %gep11.i.4 = getelementptr double, ptr %invariant.gep10.i, i64 %298
  %299 = load double, ptr %gep11.i.4, align 8
  %300 = getelementptr double, ptr %.unpack17, i64 %298
  %301 = load double, ptr %300, align 8
  %302 = fmul double %299, %301
  %303 = fadd double %297, %302
  store double %303, ptr %271, align 8
  %304 = or disjoint i64 %273, 5
  %gep11.i.5 = getelementptr double, ptr %invariant.gep10.i, i64 %304
  %305 = load double, ptr %gep11.i.5, align 8
  %306 = getelementptr double, ptr %.unpack17, i64 %304
  %307 = load double, ptr %306, align 8
  %308 = fmul double %305, %307
  %309 = fadd double %303, %308
  store double %309, ptr %271, align 8
  %310 = or disjoint i64 %273, 6
  %gep11.i.6 = getelementptr double, ptr %invariant.gep10.i, i64 %310
  %311 = load double, ptr %gep11.i.6, align 8
  %312 = getelementptr double, ptr %.unpack17, i64 %310
  %313 = load double, ptr %312, align 8
  %314 = fmul double %311, %313
  %315 = fadd double %309, %314
  store double %315, ptr %271, align 8
  %316 = or disjoint i64 %273, 7
  %gep11.i.7 = getelementptr double, ptr %invariant.gep10.i, i64 %316
  %317 = load double, ptr %gep11.i.7, align 8
  %318 = getelementptr double, ptr %.unpack17, i64 %316
  %319 = load double, ptr %318, align 8
  %320 = fmul double %317, %319
  %321 = fadd double %315, %320
  store double %321, ptr %271, align 8
  %322 = add nuw nsw i64 %273, 8
  %exitcond.5.not.i.7 = icmp eq i64 %322, 64
  br i1 %exitcond.5.not.i.7, label %.preheader.6.i, label %272

.preheader.6.i:                                   ; preds = %272
  %323 = getelementptr double, ptr %.unpack28, i64 6
  %invariant.gep12.i = getelementptr double, ptr %.unpack2, i64 384
  br label %324

324:                                              ; preds = %324, %.preheader.6.i
  %325 = phi i64 [ 0, %.preheader.6.i ], [ %374, %324 ]
  %326 = phi double [ 0.000000e+00, %.preheader.6.i ], [ %373, %324 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %325
  %327 = load double, ptr %gep13.i, align 8
  %328 = getelementptr double, ptr %.unpack17, i64 %325
  %329 = load double, ptr %328, align 8
  %330 = fmul double %327, %329
  %331 = fadd double %326, %330
  store double %331, ptr %323, align 8
  %332 = or disjoint i64 %325, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %332
  %333 = load double, ptr %gep13.i.1, align 8
  %334 = getelementptr double, ptr %.unpack17, i64 %332
  %335 = load double, ptr %334, align 8
  %336 = fmul double %333, %335
  %337 = fadd double %331, %336
  store double %337, ptr %323, align 8
  %338 = or disjoint i64 %325, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %338
  %339 = load double, ptr %gep13.i.2, align 8
  %340 = getelementptr double, ptr %.unpack17, i64 %338
  %341 = load double, ptr %340, align 8
  %342 = fmul double %339, %341
  %343 = fadd double %337, %342
  store double %343, ptr %323, align 8
  %344 = or disjoint i64 %325, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %344
  %345 = load double, ptr %gep13.i.3, align 8
  %346 = getelementptr double, ptr %.unpack17, i64 %344
  %347 = load double, ptr %346, align 8
  %348 = fmul double %345, %347
  %349 = fadd double %343, %348
  store double %349, ptr %323, align 8
  %350 = or disjoint i64 %325, 4
  %gep13.i.4 = getelementptr double, ptr %invariant.gep12.i, i64 %350
  %351 = load double, ptr %gep13.i.4, align 8
  %352 = getelementptr double, ptr %.unpack17, i64 %350
  %353 = load double, ptr %352, align 8
  %354 = fmul double %351, %353
  %355 = fadd double %349, %354
  store double %355, ptr %323, align 8
  %356 = or disjoint i64 %325, 5
  %gep13.i.5 = getelementptr double, ptr %invariant.gep12.i, i64 %356
  %357 = load double, ptr %gep13.i.5, align 8
  %358 = getelementptr double, ptr %.unpack17, i64 %356
  %359 = load double, ptr %358, align 8
  %360 = fmul double %357, %359
  %361 = fadd double %355, %360
  store double %361, ptr %323, align 8
  %362 = or disjoint i64 %325, 6
  %gep13.i.6 = getelementptr double, ptr %invariant.gep12.i, i64 %362
  %363 = load double, ptr %gep13.i.6, align 8
  %364 = getelementptr double, ptr %.unpack17, i64 %362
  %365 = load double, ptr %364, align 8
  %366 = fmul double %363, %365
  %367 = fadd double %361, %366
  store double %367, ptr %323, align 8
  %368 = or disjoint i64 %325, 7
  %gep13.i.7 = getelementptr double, ptr %invariant.gep12.i, i64 %368
  %369 = load double, ptr %gep13.i.7, align 8
  %370 = getelementptr double, ptr %.unpack17, i64 %368
  %371 = load double, ptr %370, align 8
  %372 = fmul double %369, %371
  %373 = fadd double %367, %372
  store double %373, ptr %323, align 8
  %374 = add nuw nsw i64 %325, 8
  %exitcond.6.not.i.7 = icmp eq i64 %374, 64
  br i1 %exitcond.6.not.i.7, label %.preheader.7.i, label %324

.preheader.7.i:                                   ; preds = %324
  %375 = getelementptr double, ptr %.unpack28, i64 7
  %invariant.gep14.i = getelementptr double, ptr %.unpack2, i64 448
  br label %376

376:                                              ; preds = %376, %.preheader.7.i
  %377 = phi i64 [ 0, %.preheader.7.i ], [ %426, %376 ]
  %378 = phi double [ 0.000000e+00, %.preheader.7.i ], [ %425, %376 ]
  %gep15.i = getelementptr double, ptr %invariant.gep14.i, i64 %377
  %379 = load double, ptr %gep15.i, align 8
  %380 = getelementptr double, ptr %.unpack17, i64 %377
  %381 = load double, ptr %380, align 8
  %382 = fmul double %379, %381
  %383 = fadd double %378, %382
  store double %383, ptr %375, align 8
  %384 = or disjoint i64 %377, 1
  %gep15.i.1 = getelementptr double, ptr %invariant.gep14.i, i64 %384
  %385 = load double, ptr %gep15.i.1, align 8
  %386 = getelementptr double, ptr %.unpack17, i64 %384
  %387 = load double, ptr %386, align 8
  %388 = fmul double %385, %387
  %389 = fadd double %383, %388
  store double %389, ptr %375, align 8
  %390 = or disjoint i64 %377, 2
  %gep15.i.2 = getelementptr double, ptr %invariant.gep14.i, i64 %390
  %391 = load double, ptr %gep15.i.2, align 8
  %392 = getelementptr double, ptr %.unpack17, i64 %390
  %393 = load double, ptr %392, align 8
  %394 = fmul double %391, %393
  %395 = fadd double %389, %394
  store double %395, ptr %375, align 8
  %396 = or disjoint i64 %377, 3
  %gep15.i.3 = getelementptr double, ptr %invariant.gep14.i, i64 %396
  %397 = load double, ptr %gep15.i.3, align 8
  %398 = getelementptr double, ptr %.unpack17, i64 %396
  %399 = load double, ptr %398, align 8
  %400 = fmul double %397, %399
  %401 = fadd double %395, %400
  store double %401, ptr %375, align 8
  %402 = or disjoint i64 %377, 4
  %gep15.i.4 = getelementptr double, ptr %invariant.gep14.i, i64 %402
  %403 = load double, ptr %gep15.i.4, align 8
  %404 = getelementptr double, ptr %.unpack17, i64 %402
  %405 = load double, ptr %404, align 8
  %406 = fmul double %403, %405
  %407 = fadd double %401, %406
  store double %407, ptr %375, align 8
  %408 = or disjoint i64 %377, 5
  %gep15.i.5 = getelementptr double, ptr %invariant.gep14.i, i64 %408
  %409 = load double, ptr %gep15.i.5, align 8
  %410 = getelementptr double, ptr %.unpack17, i64 %408
  %411 = load double, ptr %410, align 8
  %412 = fmul double %409, %411
  %413 = fadd double %407, %412
  store double %413, ptr %375, align 8
  %414 = or disjoint i64 %377, 6
  %gep15.i.6 = getelementptr double, ptr %invariant.gep14.i, i64 %414
  %415 = load double, ptr %gep15.i.6, align 8
  %416 = getelementptr double, ptr %.unpack17, i64 %414
  %417 = load double, ptr %416, align 8
  %418 = fmul double %415, %417
  %419 = fadd double %413, %418
  store double %419, ptr %375, align 8
  %420 = or disjoint i64 %377, 7
  %gep15.i.7 = getelementptr double, ptr %invariant.gep14.i, i64 %420
  %421 = load double, ptr %gep15.i.7, align 8
  %422 = getelementptr double, ptr %.unpack17, i64 %420
  %423 = load double, ptr %422, align 8
  %424 = fmul double %421, %423
  %425 = fadd double %419, %424
  store double %425, ptr %375, align 8
  %426 = add nuw nsw i64 %377, 8
  %exitcond.7.not.i.7 = icmp eq i64 %426, 64
  br i1 %exitcond.7.not.i.7, label %kernel.exit, label %376

kernel.exit:                                      ; preds = %376
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %10, i8 0, i64 64, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %69, %11 ]
  %13 = phi double [ 0.000000e+00, %1 ], [ %68, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %7, i64 %12
  %17 = load double, ptr %16, align 8
  %18 = fmul double %15, %17
  %19 = fadd double %13, %18
  store double %19, ptr %10, align 8
  %20 = or disjoint i64 %12, 1
  %21 = getelementptr double, ptr %4, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %7, i64 %20
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %19, %25
  store double %26, ptr %10, align 8
  %27 = or disjoint i64 %12, 2
  %28 = getelementptr double, ptr %4, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %7, i64 %27
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %10, align 8
  %34 = or disjoint i64 %12, 3
  %35 = getelementptr double, ptr %4, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %7, i64 %34
  %38 = load double, ptr %37, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %10, align 8
  %41 = or disjoint i64 %12, 4
  %42 = getelementptr double, ptr %4, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %7, i64 %41
  %45 = load double, ptr %44, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %40, %46
  store double %47, ptr %10, align 8
  %48 = or disjoint i64 %12, 5
  %49 = getelementptr double, ptr %4, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %7, i64 %48
  %52 = load double, ptr %51, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %47, %53
  store double %54, ptr %10, align 8
  %55 = or disjoint i64 %12, 6
  %56 = getelementptr double, ptr %4, i64 %55
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %7, i64 %55
  %59 = load double, ptr %58, align 8
  %60 = fmul double %57, %59
  %61 = fadd double %54, %60
  store double %61, ptr %10, align 8
  %62 = or disjoint i64 %12, 7
  %63 = getelementptr double, ptr %4, i64 %62
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %62
  %66 = load double, ptr %65, align 8
  %67 = fmul double %64, %66
  %68 = fadd double %61, %67
  store double %68, ptr %10, align 8
  %69 = add nuw nsw i64 %12, 8
  %exitcond.not.i.7 = icmp eq i64 %69, 64
  br i1 %exitcond.not.i.7, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %70 = getelementptr double, ptr %10, i64 1
  %invariant.gep.i = getelementptr double, ptr %4, i64 64
  br label %71

71:                                               ; preds = %71, %.preheader.1.i
  %72 = phi i64 [ 0, %.preheader.1.i ], [ %121, %71 ]
  %73 = phi double [ 0.000000e+00, %.preheader.1.i ], [ %120, %71 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %72
  %74 = load double, ptr %gep.i, align 8
  %75 = getelementptr double, ptr %7, i64 %72
  %76 = load double, ptr %75, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %73, %77
  store double %78, ptr %70, align 8
  %79 = or disjoint i64 %72, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %79
  %80 = load double, ptr %gep.i.1, align 8
  %81 = getelementptr double, ptr %7, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %70, align 8
  %85 = or disjoint i64 %72, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %85
  %86 = load double, ptr %gep.i.2, align 8
  %87 = getelementptr double, ptr %7, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %70, align 8
  %91 = or disjoint i64 %72, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %91
  %92 = load double, ptr %gep.i.3, align 8
  %93 = getelementptr double, ptr %7, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %70, align 8
  %97 = or disjoint i64 %72, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %97
  %98 = load double, ptr %gep.i.4, align 8
  %99 = getelementptr double, ptr %7, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %70, align 8
  %103 = or disjoint i64 %72, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %103
  %104 = load double, ptr %gep.i.5, align 8
  %105 = getelementptr double, ptr %7, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %70, align 8
  %109 = or disjoint i64 %72, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %109
  %110 = load double, ptr %gep.i.6, align 8
  %111 = getelementptr double, ptr %7, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %70, align 8
  %115 = or disjoint i64 %72, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %115
  %116 = load double, ptr %gep.i.7, align 8
  %117 = getelementptr double, ptr %7, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %70, align 8
  %121 = add nuw nsw i64 %72, 8
  %exitcond.1.not.i.7 = icmp eq i64 %121, 64
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %71

.preheader.2.i:                                   ; preds = %71
  %122 = getelementptr double, ptr %10, i64 2
  %invariant.gep4.i = getelementptr double, ptr %4, i64 128
  br label %123

123:                                              ; preds = %123, %.preheader.2.i
  %124 = phi i64 [ 0, %.preheader.2.i ], [ %173, %123 ]
  %125 = phi double [ 0.000000e+00, %.preheader.2.i ], [ %172, %123 ]
  %gep5.i = getelementptr double, ptr %invariant.gep4.i, i64 %124
  %126 = load double, ptr %gep5.i, align 8
  %127 = getelementptr double, ptr %7, i64 %124
  %128 = load double, ptr %127, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %125, %129
  store double %130, ptr %122, align 8
  %131 = or disjoint i64 %124, 1
  %gep5.i.1 = getelementptr double, ptr %invariant.gep4.i, i64 %131
  %132 = load double, ptr %gep5.i.1, align 8
  %133 = getelementptr double, ptr %7, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %122, align 8
  %137 = or disjoint i64 %124, 2
  %gep5.i.2 = getelementptr double, ptr %invariant.gep4.i, i64 %137
  %138 = load double, ptr %gep5.i.2, align 8
  %139 = getelementptr double, ptr %7, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %122, align 8
  %143 = or disjoint i64 %124, 3
  %gep5.i.3 = getelementptr double, ptr %invariant.gep4.i, i64 %143
  %144 = load double, ptr %gep5.i.3, align 8
  %145 = getelementptr double, ptr %7, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %122, align 8
  %149 = or disjoint i64 %124, 4
  %gep5.i.4 = getelementptr double, ptr %invariant.gep4.i, i64 %149
  %150 = load double, ptr %gep5.i.4, align 8
  %151 = getelementptr double, ptr %7, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %122, align 8
  %155 = or disjoint i64 %124, 5
  %gep5.i.5 = getelementptr double, ptr %invariant.gep4.i, i64 %155
  %156 = load double, ptr %gep5.i.5, align 8
  %157 = getelementptr double, ptr %7, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %122, align 8
  %161 = or disjoint i64 %124, 6
  %gep5.i.6 = getelementptr double, ptr %invariant.gep4.i, i64 %161
  %162 = load double, ptr %gep5.i.6, align 8
  %163 = getelementptr double, ptr %7, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %122, align 8
  %167 = or disjoint i64 %124, 7
  %gep5.i.7 = getelementptr double, ptr %invariant.gep4.i, i64 %167
  %168 = load double, ptr %gep5.i.7, align 8
  %169 = getelementptr double, ptr %7, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %122, align 8
  %173 = add nuw nsw i64 %124, 8
  %exitcond.2.not.i.7 = icmp eq i64 %173, 64
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %123

.preheader.3.i:                                   ; preds = %123
  %174 = getelementptr double, ptr %10, i64 3
  %invariant.gep6.i = getelementptr double, ptr %4, i64 192
  br label %175

175:                                              ; preds = %175, %.preheader.3.i
  %176 = phi i64 [ 0, %.preheader.3.i ], [ %225, %175 ]
  %177 = phi double [ 0.000000e+00, %.preheader.3.i ], [ %224, %175 ]
  %gep7.i = getelementptr double, ptr %invariant.gep6.i, i64 %176
  %178 = load double, ptr %gep7.i, align 8
  %179 = getelementptr double, ptr %7, i64 %176
  %180 = load double, ptr %179, align 8
  %181 = fmul double %178, %180
  %182 = fadd double %177, %181
  store double %182, ptr %174, align 8
  %183 = or disjoint i64 %176, 1
  %gep7.i.1 = getelementptr double, ptr %invariant.gep6.i, i64 %183
  %184 = load double, ptr %gep7.i.1, align 8
  %185 = getelementptr double, ptr %7, i64 %183
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %182, %187
  store double %188, ptr %174, align 8
  %189 = or disjoint i64 %176, 2
  %gep7.i.2 = getelementptr double, ptr %invariant.gep6.i, i64 %189
  %190 = load double, ptr %gep7.i.2, align 8
  %191 = getelementptr double, ptr %7, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %174, align 8
  %195 = or disjoint i64 %176, 3
  %gep7.i.3 = getelementptr double, ptr %invariant.gep6.i, i64 %195
  %196 = load double, ptr %gep7.i.3, align 8
  %197 = getelementptr double, ptr %7, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %174, align 8
  %201 = or disjoint i64 %176, 4
  %gep7.i.4 = getelementptr double, ptr %invariant.gep6.i, i64 %201
  %202 = load double, ptr %gep7.i.4, align 8
  %203 = getelementptr double, ptr %7, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %174, align 8
  %207 = or disjoint i64 %176, 5
  %gep7.i.5 = getelementptr double, ptr %invariant.gep6.i, i64 %207
  %208 = load double, ptr %gep7.i.5, align 8
  %209 = getelementptr double, ptr %7, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %174, align 8
  %213 = or disjoint i64 %176, 6
  %gep7.i.6 = getelementptr double, ptr %invariant.gep6.i, i64 %213
  %214 = load double, ptr %gep7.i.6, align 8
  %215 = getelementptr double, ptr %7, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %174, align 8
  %219 = or disjoint i64 %176, 7
  %gep7.i.7 = getelementptr double, ptr %invariant.gep6.i, i64 %219
  %220 = load double, ptr %gep7.i.7, align 8
  %221 = getelementptr double, ptr %7, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %174, align 8
  %225 = add nuw nsw i64 %176, 8
  %exitcond.3.not.i.7 = icmp eq i64 %225, 64
  br i1 %exitcond.3.not.i.7, label %.preheader.4.i, label %175

.preheader.4.i:                                   ; preds = %175
  %226 = getelementptr double, ptr %10, i64 4
  %invariant.gep8.i = getelementptr double, ptr %4, i64 256
  br label %227

227:                                              ; preds = %227, %.preheader.4.i
  %228 = phi i64 [ 0, %.preheader.4.i ], [ %277, %227 ]
  %229 = phi double [ 0.000000e+00, %.preheader.4.i ], [ %276, %227 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %228
  %230 = load double, ptr %gep9.i, align 8
  %231 = getelementptr double, ptr %7, i64 %228
  %232 = load double, ptr %231, align 8
  %233 = fmul double %230, %232
  %234 = fadd double %229, %233
  store double %234, ptr %226, align 8
  %235 = or disjoint i64 %228, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %235
  %236 = load double, ptr %gep9.i.1, align 8
  %237 = getelementptr double, ptr %7, i64 %235
  %238 = load double, ptr %237, align 8
  %239 = fmul double %236, %238
  %240 = fadd double %234, %239
  store double %240, ptr %226, align 8
  %241 = or disjoint i64 %228, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %241
  %242 = load double, ptr %gep9.i.2, align 8
  %243 = getelementptr double, ptr %7, i64 %241
  %244 = load double, ptr %243, align 8
  %245 = fmul double %242, %244
  %246 = fadd double %240, %245
  store double %246, ptr %226, align 8
  %247 = or disjoint i64 %228, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %247
  %248 = load double, ptr %gep9.i.3, align 8
  %249 = getelementptr double, ptr %7, i64 %247
  %250 = load double, ptr %249, align 8
  %251 = fmul double %248, %250
  %252 = fadd double %246, %251
  store double %252, ptr %226, align 8
  %253 = or disjoint i64 %228, 4
  %gep9.i.4 = getelementptr double, ptr %invariant.gep8.i, i64 %253
  %254 = load double, ptr %gep9.i.4, align 8
  %255 = getelementptr double, ptr %7, i64 %253
  %256 = load double, ptr %255, align 8
  %257 = fmul double %254, %256
  %258 = fadd double %252, %257
  store double %258, ptr %226, align 8
  %259 = or disjoint i64 %228, 5
  %gep9.i.5 = getelementptr double, ptr %invariant.gep8.i, i64 %259
  %260 = load double, ptr %gep9.i.5, align 8
  %261 = getelementptr double, ptr %7, i64 %259
  %262 = load double, ptr %261, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %258, %263
  store double %264, ptr %226, align 8
  %265 = or disjoint i64 %228, 6
  %gep9.i.6 = getelementptr double, ptr %invariant.gep8.i, i64 %265
  %266 = load double, ptr %gep9.i.6, align 8
  %267 = getelementptr double, ptr %7, i64 %265
  %268 = load double, ptr %267, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %264, %269
  store double %270, ptr %226, align 8
  %271 = or disjoint i64 %228, 7
  %gep9.i.7 = getelementptr double, ptr %invariant.gep8.i, i64 %271
  %272 = load double, ptr %gep9.i.7, align 8
  %273 = getelementptr double, ptr %7, i64 %271
  %274 = load double, ptr %273, align 8
  %275 = fmul double %272, %274
  %276 = fadd double %270, %275
  store double %276, ptr %226, align 8
  %277 = add nuw nsw i64 %228, 8
  %exitcond.4.not.i.7 = icmp eq i64 %277, 64
  br i1 %exitcond.4.not.i.7, label %.preheader.5.i, label %227

.preheader.5.i:                                   ; preds = %227
  %278 = getelementptr double, ptr %10, i64 5
  %invariant.gep10.i = getelementptr double, ptr %4, i64 320
  br label %279

279:                                              ; preds = %279, %.preheader.5.i
  %280 = phi i64 [ 0, %.preheader.5.i ], [ %329, %279 ]
  %281 = phi double [ 0.000000e+00, %.preheader.5.i ], [ %328, %279 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %280
  %282 = load double, ptr %gep11.i, align 8
  %283 = getelementptr double, ptr %7, i64 %280
  %284 = load double, ptr %283, align 8
  %285 = fmul double %282, %284
  %286 = fadd double %281, %285
  store double %286, ptr %278, align 8
  %287 = or disjoint i64 %280, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %287
  %288 = load double, ptr %gep11.i.1, align 8
  %289 = getelementptr double, ptr %7, i64 %287
  %290 = load double, ptr %289, align 8
  %291 = fmul double %288, %290
  %292 = fadd double %286, %291
  store double %292, ptr %278, align 8
  %293 = or disjoint i64 %280, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %293
  %294 = load double, ptr %gep11.i.2, align 8
  %295 = getelementptr double, ptr %7, i64 %293
  %296 = load double, ptr %295, align 8
  %297 = fmul double %294, %296
  %298 = fadd double %292, %297
  store double %298, ptr %278, align 8
  %299 = or disjoint i64 %280, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %299
  %300 = load double, ptr %gep11.i.3, align 8
  %301 = getelementptr double, ptr %7, i64 %299
  %302 = load double, ptr %301, align 8
  %303 = fmul double %300, %302
  %304 = fadd double %298, %303
  store double %304, ptr %278, align 8
  %305 = or disjoint i64 %280, 4
  %gep11.i.4 = getelementptr double, ptr %invariant.gep10.i, i64 %305
  %306 = load double, ptr %gep11.i.4, align 8
  %307 = getelementptr double, ptr %7, i64 %305
  %308 = load double, ptr %307, align 8
  %309 = fmul double %306, %308
  %310 = fadd double %304, %309
  store double %310, ptr %278, align 8
  %311 = or disjoint i64 %280, 5
  %gep11.i.5 = getelementptr double, ptr %invariant.gep10.i, i64 %311
  %312 = load double, ptr %gep11.i.5, align 8
  %313 = getelementptr double, ptr %7, i64 %311
  %314 = load double, ptr %313, align 8
  %315 = fmul double %312, %314
  %316 = fadd double %310, %315
  store double %316, ptr %278, align 8
  %317 = or disjoint i64 %280, 6
  %gep11.i.6 = getelementptr double, ptr %invariant.gep10.i, i64 %317
  %318 = load double, ptr %gep11.i.6, align 8
  %319 = getelementptr double, ptr %7, i64 %317
  %320 = load double, ptr %319, align 8
  %321 = fmul double %318, %320
  %322 = fadd double %316, %321
  store double %322, ptr %278, align 8
  %323 = or disjoint i64 %280, 7
  %gep11.i.7 = getelementptr double, ptr %invariant.gep10.i, i64 %323
  %324 = load double, ptr %gep11.i.7, align 8
  %325 = getelementptr double, ptr %7, i64 %323
  %326 = load double, ptr %325, align 8
  %327 = fmul double %324, %326
  %328 = fadd double %322, %327
  store double %328, ptr %278, align 8
  %329 = add nuw nsw i64 %280, 8
  %exitcond.5.not.i.7 = icmp eq i64 %329, 64
  br i1 %exitcond.5.not.i.7, label %.preheader.6.i, label %279

.preheader.6.i:                                   ; preds = %279
  %330 = getelementptr double, ptr %10, i64 6
  %invariant.gep12.i = getelementptr double, ptr %4, i64 384
  br label %331

331:                                              ; preds = %331, %.preheader.6.i
  %332 = phi i64 [ 0, %.preheader.6.i ], [ %381, %331 ]
  %333 = phi double [ 0.000000e+00, %.preheader.6.i ], [ %380, %331 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %332
  %334 = load double, ptr %gep13.i, align 8
  %335 = getelementptr double, ptr %7, i64 %332
  %336 = load double, ptr %335, align 8
  %337 = fmul double %334, %336
  %338 = fadd double %333, %337
  store double %338, ptr %330, align 8
  %339 = or disjoint i64 %332, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %339
  %340 = load double, ptr %gep13.i.1, align 8
  %341 = getelementptr double, ptr %7, i64 %339
  %342 = load double, ptr %341, align 8
  %343 = fmul double %340, %342
  %344 = fadd double %338, %343
  store double %344, ptr %330, align 8
  %345 = or disjoint i64 %332, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %345
  %346 = load double, ptr %gep13.i.2, align 8
  %347 = getelementptr double, ptr %7, i64 %345
  %348 = load double, ptr %347, align 8
  %349 = fmul double %346, %348
  %350 = fadd double %344, %349
  store double %350, ptr %330, align 8
  %351 = or disjoint i64 %332, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %351
  %352 = load double, ptr %gep13.i.3, align 8
  %353 = getelementptr double, ptr %7, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = fmul double %352, %354
  %356 = fadd double %350, %355
  store double %356, ptr %330, align 8
  %357 = or disjoint i64 %332, 4
  %gep13.i.4 = getelementptr double, ptr %invariant.gep12.i, i64 %357
  %358 = load double, ptr %gep13.i.4, align 8
  %359 = getelementptr double, ptr %7, i64 %357
  %360 = load double, ptr %359, align 8
  %361 = fmul double %358, %360
  %362 = fadd double %356, %361
  store double %362, ptr %330, align 8
  %363 = or disjoint i64 %332, 5
  %gep13.i.5 = getelementptr double, ptr %invariant.gep12.i, i64 %363
  %364 = load double, ptr %gep13.i.5, align 8
  %365 = getelementptr double, ptr %7, i64 %363
  %366 = load double, ptr %365, align 8
  %367 = fmul double %364, %366
  %368 = fadd double %362, %367
  store double %368, ptr %330, align 8
  %369 = or disjoint i64 %332, 6
  %gep13.i.6 = getelementptr double, ptr %invariant.gep12.i, i64 %369
  %370 = load double, ptr %gep13.i.6, align 8
  %371 = getelementptr double, ptr %7, i64 %369
  %372 = load double, ptr %371, align 8
  %373 = fmul double %370, %372
  %374 = fadd double %368, %373
  store double %374, ptr %330, align 8
  %375 = or disjoint i64 %332, 7
  %gep13.i.7 = getelementptr double, ptr %invariant.gep12.i, i64 %375
  %376 = load double, ptr %gep13.i.7, align 8
  %377 = getelementptr double, ptr %7, i64 %375
  %378 = load double, ptr %377, align 8
  %379 = fmul double %376, %378
  %380 = fadd double %374, %379
  store double %380, ptr %330, align 8
  %381 = add nuw nsw i64 %332, 8
  %exitcond.6.not.i.7 = icmp eq i64 %381, 64
  br i1 %exitcond.6.not.i.7, label %.preheader.7.i, label %331

.preheader.7.i:                                   ; preds = %331
  %382 = getelementptr double, ptr %10, i64 7
  %invariant.gep14.i = getelementptr double, ptr %4, i64 448
  br label %383

383:                                              ; preds = %383, %.preheader.7.i
  %384 = phi i64 [ 0, %.preheader.7.i ], [ %433, %383 ]
  %385 = phi double [ 0.000000e+00, %.preheader.7.i ], [ %432, %383 ]
  %gep15.i = getelementptr double, ptr %invariant.gep14.i, i64 %384
  %386 = load double, ptr %gep15.i, align 8
  %387 = getelementptr double, ptr %7, i64 %384
  %388 = load double, ptr %387, align 8
  %389 = fmul double %386, %388
  %390 = fadd double %385, %389
  store double %390, ptr %382, align 8
  %391 = or disjoint i64 %384, 1
  %gep15.i.1 = getelementptr double, ptr %invariant.gep14.i, i64 %391
  %392 = load double, ptr %gep15.i.1, align 8
  %393 = getelementptr double, ptr %7, i64 %391
  %394 = load double, ptr %393, align 8
  %395 = fmul double %392, %394
  %396 = fadd double %390, %395
  store double %396, ptr %382, align 8
  %397 = or disjoint i64 %384, 2
  %gep15.i.2 = getelementptr double, ptr %invariant.gep14.i, i64 %397
  %398 = load double, ptr %gep15.i.2, align 8
  %399 = getelementptr double, ptr %7, i64 %397
  %400 = load double, ptr %399, align 8
  %401 = fmul double %398, %400
  %402 = fadd double %396, %401
  store double %402, ptr %382, align 8
  %403 = or disjoint i64 %384, 3
  %gep15.i.3 = getelementptr double, ptr %invariant.gep14.i, i64 %403
  %404 = load double, ptr %gep15.i.3, align 8
  %405 = getelementptr double, ptr %7, i64 %403
  %406 = load double, ptr %405, align 8
  %407 = fmul double %404, %406
  %408 = fadd double %402, %407
  store double %408, ptr %382, align 8
  %409 = or disjoint i64 %384, 4
  %gep15.i.4 = getelementptr double, ptr %invariant.gep14.i, i64 %409
  %410 = load double, ptr %gep15.i.4, align 8
  %411 = getelementptr double, ptr %7, i64 %409
  %412 = load double, ptr %411, align 8
  %413 = fmul double %410, %412
  %414 = fadd double %408, %413
  store double %414, ptr %382, align 8
  %415 = or disjoint i64 %384, 5
  %gep15.i.5 = getelementptr double, ptr %invariant.gep14.i, i64 %415
  %416 = load double, ptr %gep15.i.5, align 8
  %417 = getelementptr double, ptr %7, i64 %415
  %418 = load double, ptr %417, align 8
  %419 = fmul double %416, %418
  %420 = fadd double %414, %419
  store double %420, ptr %382, align 8
  %421 = or disjoint i64 %384, 6
  %gep15.i.6 = getelementptr double, ptr %invariant.gep14.i, i64 %421
  %422 = load double, ptr %gep15.i.6, align 8
  %423 = getelementptr double, ptr %7, i64 %421
  %424 = load double, ptr %423, align 8
  %425 = fmul double %422, %424
  %426 = fadd double %420, %425
  store double %426, ptr %382, align 8
  %427 = or disjoint i64 %384, 7
  %gep15.i.7 = getelementptr double, ptr %invariant.gep14.i, i64 %427
  %428 = load double, ptr %gep15.i.7, align 8
  %429 = getelementptr double, ptr %7, i64 %427
  %430 = load double, ptr %429, align 8
  %431 = fmul double %428, %430
  %432 = fadd double %426, %431
  store double %432, ptr %382, align 8
  %433 = add nuw nsw i64 %384, 8
  %exitcond.7.not.i.7 = icmp eq i64 %433, 64
  br i1 %exitcond.7.not.i.7, label %kernel.exit, label %383

kernel.exit:                                      ; preds = %383
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
