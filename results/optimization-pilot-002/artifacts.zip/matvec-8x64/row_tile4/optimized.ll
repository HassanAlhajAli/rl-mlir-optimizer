; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %13, i8 0, i64 64, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader3.preheader
  %18 = phi i64 [ 0, %.preheader3.preheader ], [ %75, %17 ]
  %19 = phi double [ 0.000000e+00, %.preheader3.preheader ], [ %74, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %8, i64 %18
  %23 = load double, ptr %22, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %13, align 8
  %26 = or disjoint i64 %18, 1
  %27 = getelementptr double, ptr %1, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %13, align 8
  %33 = or disjoint i64 %18, 2
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %33
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %13, align 8
  %40 = or disjoint i64 %18, 3
  %41 = getelementptr double, ptr %1, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %8, i64 %40
  %44 = load double, ptr %43, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %13, align 8
  %47 = or disjoint i64 %18, 4
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %8, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %46, %52
  store double %53, ptr %13, align 8
  %54 = or disjoint i64 %18, 5
  %55 = getelementptr double, ptr %1, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %53, %59
  store double %60, ptr %13, align 8
  %61 = or disjoint i64 %18, 6
  %62 = getelementptr double, ptr %1, i64 %61
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %8, i64 %61
  %65 = load double, ptr %64, align 8
  %66 = fmul double %63, %65
  %67 = fadd double %60, %66
  store double %67, ptr %13, align 8
  %68 = or disjoint i64 %18, 7
  %69 = getelementptr double, ptr %1, i64 %68
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %68
  %72 = load double, ptr %71, align 8
  %73 = fmul double %70, %72
  %74 = fadd double %67, %73
  store double %74, ptr %13, align 8
  %75 = add nuw nsw i64 %18, 8
  %exitcond.not.7 = icmp eq i64 %75, 64
  br i1 %exitcond.not.7, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %76 = getelementptr double, ptr %13, i64 1
  %invariant.gep10 = getelementptr double, ptr %1, i64 64
  br label %77

77:                                               ; preds = %77, %.preheader.1
  %78 = phi i64 [ 0, %.preheader.1 ], [ %127, %77 ]
  %79 = phi double [ 0.000000e+00, %.preheader.1 ], [ %126, %77 ]
  %gep11 = getelementptr double, ptr %invariant.gep10, i64 %78
  %80 = load double, ptr %gep11, align 8
  %81 = getelementptr double, ptr %8, i64 %78
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %79, %83
  store double %84, ptr %76, align 8
  %85 = or disjoint i64 %78, 1
  %gep11.1 = getelementptr double, ptr %invariant.gep10, i64 %85
  %86 = load double, ptr %gep11.1, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %76, align 8
  %91 = or disjoint i64 %78, 2
  %gep11.2 = getelementptr double, ptr %invariant.gep10, i64 %91
  %92 = load double, ptr %gep11.2, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %76, align 8
  %97 = or disjoint i64 %78, 3
  %gep11.3 = getelementptr double, ptr %invariant.gep10, i64 %97
  %98 = load double, ptr %gep11.3, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %76, align 8
  %103 = or disjoint i64 %78, 4
  %gep11.4 = getelementptr double, ptr %invariant.gep10, i64 %103
  %104 = load double, ptr %gep11.4, align 8
  %105 = getelementptr double, ptr %8, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %76, align 8
  %109 = or disjoint i64 %78, 5
  %gep11.5 = getelementptr double, ptr %invariant.gep10, i64 %109
  %110 = load double, ptr %gep11.5, align 8
  %111 = getelementptr double, ptr %8, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %76, align 8
  %115 = or disjoint i64 %78, 6
  %gep11.6 = getelementptr double, ptr %invariant.gep10, i64 %115
  %116 = load double, ptr %gep11.6, align 8
  %117 = getelementptr double, ptr %8, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %76, align 8
  %121 = or disjoint i64 %78, 7
  %gep11.7 = getelementptr double, ptr %invariant.gep10, i64 %121
  %122 = load double, ptr %gep11.7, align 8
  %123 = getelementptr double, ptr %8, i64 %121
  %124 = load double, ptr %123, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %120, %125
  store double %126, ptr %76, align 8
  %127 = add nuw nsw i64 %78, 8
  %exitcond.1.not.7 = icmp eq i64 %127, 64
  br i1 %exitcond.1.not.7, label %.preheader.2, label %77

.preheader.2:                                     ; preds = %77
  %128 = getelementptr double, ptr %13, i64 2
  %invariant.gep8 = getelementptr double, ptr %1, i64 128
  br label %129

129:                                              ; preds = %129, %.preheader.2
  %130 = phi i64 [ 0, %.preheader.2 ], [ %179, %129 ]
  %131 = phi double [ 0.000000e+00, %.preheader.2 ], [ %178, %129 ]
  %gep9 = getelementptr double, ptr %invariant.gep8, i64 %130
  %132 = load double, ptr %gep9, align 8
  %133 = getelementptr double, ptr %8, i64 %130
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %131, %135
  store double %136, ptr %128, align 8
  %137 = or disjoint i64 %130, 1
  %gep9.1 = getelementptr double, ptr %invariant.gep8, i64 %137
  %138 = load double, ptr %gep9.1, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %128, align 8
  %143 = or disjoint i64 %130, 2
  %gep9.2 = getelementptr double, ptr %invariant.gep8, i64 %143
  %144 = load double, ptr %gep9.2, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %128, align 8
  %149 = or disjoint i64 %130, 3
  %gep9.3 = getelementptr double, ptr %invariant.gep8, i64 %149
  %150 = load double, ptr %gep9.3, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %128, align 8
  %155 = or disjoint i64 %130, 4
  %gep9.4 = getelementptr double, ptr %invariant.gep8, i64 %155
  %156 = load double, ptr %gep9.4, align 8
  %157 = getelementptr double, ptr %8, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %128, align 8
  %161 = or disjoint i64 %130, 5
  %gep9.5 = getelementptr double, ptr %invariant.gep8, i64 %161
  %162 = load double, ptr %gep9.5, align 8
  %163 = getelementptr double, ptr %8, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %128, align 8
  %167 = or disjoint i64 %130, 6
  %gep9.6 = getelementptr double, ptr %invariant.gep8, i64 %167
  %168 = load double, ptr %gep9.6, align 8
  %169 = getelementptr double, ptr %8, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %128, align 8
  %173 = or disjoint i64 %130, 7
  %gep9.7 = getelementptr double, ptr %invariant.gep8, i64 %173
  %174 = load double, ptr %gep9.7, align 8
  %175 = getelementptr double, ptr %8, i64 %173
  %176 = load double, ptr %175, align 8
  %177 = fmul double %174, %176
  %178 = fadd double %172, %177
  store double %178, ptr %128, align 8
  %179 = add nuw nsw i64 %130, 8
  %exitcond.2.not.7 = icmp eq i64 %179, 64
  br i1 %exitcond.2.not.7, label %.preheader.3, label %129

.preheader.3:                                     ; preds = %129
  %180 = getelementptr double, ptr %13, i64 3
  %invariant.gep = getelementptr double, ptr %1, i64 192
  br label %181

181:                                              ; preds = %181, %.preheader.3
  %182 = phi i64 [ 0, %.preheader.3 ], [ %231, %181 ]
  %183 = phi double [ 0.000000e+00, %.preheader.3 ], [ %230, %181 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %182
  %184 = load double, ptr %gep, align 8
  %185 = getelementptr double, ptr %8, i64 %182
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %183, %187
  store double %188, ptr %180, align 8
  %189 = or disjoint i64 %182, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %189
  %190 = load double, ptr %gep.1, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %180, align 8
  %195 = or disjoint i64 %182, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %195
  %196 = load double, ptr %gep.2, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %180, align 8
  %201 = or disjoint i64 %182, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %201
  %202 = load double, ptr %gep.3, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %180, align 8
  %207 = or disjoint i64 %182, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %207
  %208 = load double, ptr %gep.4, align 8
  %209 = getelementptr double, ptr %8, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %180, align 8
  %213 = or disjoint i64 %182, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %213
  %214 = load double, ptr %gep.5, align 8
  %215 = getelementptr double, ptr %8, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %180, align 8
  %219 = or disjoint i64 %182, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %219
  %220 = load double, ptr %gep.6, align 8
  %221 = getelementptr double, ptr %8, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %180, align 8
  %225 = or disjoint i64 %182, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %225
  %226 = load double, ptr %gep.7, align 8
  %227 = getelementptr double, ptr %8, i64 %225
  %228 = load double, ptr %227, align 8
  %229 = fmul double %226, %228
  %230 = fadd double %224, %229
  store double %230, ptr %180, align 8
  %231 = add nuw nsw i64 %182, 8
  %exitcond.3.not.7 = icmp eq i64 %231, 64
  br i1 %exitcond.3.not.7, label %.preheader3.1, label %181

.preheader3.1:                                    ; preds = %181
  %232 = getelementptr double, ptr %1, i64 256
  %233 = getelementptr double, ptr %13, i64 4
  br label %234

234:                                              ; preds = %234, %.preheader3.1
  %235 = phi i64 [ 0, %.preheader3.1 ], [ %292, %234 ]
  %236 = phi double [ 0.000000e+00, %.preheader3.1 ], [ %291, %234 ]
  %237 = getelementptr double, ptr %232, i64 %235
  %238 = load double, ptr %237, align 8
  %239 = getelementptr double, ptr %8, i64 %235
  %240 = load double, ptr %239, align 8
  %241 = fmul double %238, %240
  %242 = fadd double %236, %241
  store double %242, ptr %233, align 8
  %243 = or disjoint i64 %235, 1
  %244 = getelementptr double, ptr %232, i64 %243
  %245 = load double, ptr %244, align 8
  %246 = getelementptr double, ptr %8, i64 %243
  %247 = load double, ptr %246, align 8
  %248 = fmul double %245, %247
  %249 = fadd double %242, %248
  store double %249, ptr %233, align 8
  %250 = or disjoint i64 %235, 2
  %251 = getelementptr double, ptr %232, i64 %250
  %252 = load double, ptr %251, align 8
  %253 = getelementptr double, ptr %8, i64 %250
  %254 = load double, ptr %253, align 8
  %255 = fmul double %252, %254
  %256 = fadd double %249, %255
  store double %256, ptr %233, align 8
  %257 = or disjoint i64 %235, 3
  %258 = getelementptr double, ptr %232, i64 %257
  %259 = load double, ptr %258, align 8
  %260 = getelementptr double, ptr %8, i64 %257
  %261 = load double, ptr %260, align 8
  %262 = fmul double %259, %261
  %263 = fadd double %256, %262
  store double %263, ptr %233, align 8
  %264 = or disjoint i64 %235, 4
  %265 = getelementptr double, ptr %232, i64 %264
  %266 = load double, ptr %265, align 8
  %267 = getelementptr double, ptr %8, i64 %264
  %268 = load double, ptr %267, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %263, %269
  store double %270, ptr %233, align 8
  %271 = or disjoint i64 %235, 5
  %272 = getelementptr double, ptr %232, i64 %271
  %273 = load double, ptr %272, align 8
  %274 = getelementptr double, ptr %8, i64 %271
  %275 = load double, ptr %274, align 8
  %276 = fmul double %273, %275
  %277 = fadd double %270, %276
  store double %277, ptr %233, align 8
  %278 = or disjoint i64 %235, 6
  %279 = getelementptr double, ptr %232, i64 %278
  %280 = load double, ptr %279, align 8
  %281 = getelementptr double, ptr %8, i64 %278
  %282 = load double, ptr %281, align 8
  %283 = fmul double %280, %282
  %284 = fadd double %277, %283
  store double %284, ptr %233, align 8
  %285 = or disjoint i64 %235, 7
  %286 = getelementptr double, ptr %232, i64 %285
  %287 = load double, ptr %286, align 8
  %288 = getelementptr double, ptr %8, i64 %285
  %289 = load double, ptr %288, align 8
  %290 = fmul double %287, %289
  %291 = fadd double %284, %290
  store double %291, ptr %233, align 8
  %292 = add nuw nsw i64 %235, 8
  %exitcond.17.not.7 = icmp eq i64 %292, 64
  br i1 %exitcond.17.not.7, label %.preheader.1.1, label %234

.preheader.1.1:                                   ; preds = %234
  %293 = getelementptr double, ptr %13, i64 5
  %invariant.gep12 = getelementptr double, ptr %1, i64 320
  br label %294

294:                                              ; preds = %294, %.preheader.1.1
  %295 = phi i64 [ 0, %.preheader.1.1 ], [ %344, %294 ]
  %296 = phi double [ 0.000000e+00, %.preheader.1.1 ], [ %343, %294 ]
  %gep13 = getelementptr double, ptr %invariant.gep12, i64 %295
  %297 = load double, ptr %gep13, align 8
  %298 = getelementptr double, ptr %8, i64 %295
  %299 = load double, ptr %298, align 8
  %300 = fmul double %297, %299
  %301 = fadd double %296, %300
  store double %301, ptr %293, align 8
  %302 = or disjoint i64 %295, 1
  %gep13.1 = getelementptr double, ptr %invariant.gep12, i64 %302
  %303 = load double, ptr %gep13.1, align 8
  %304 = getelementptr double, ptr %8, i64 %302
  %305 = load double, ptr %304, align 8
  %306 = fmul double %303, %305
  %307 = fadd double %301, %306
  store double %307, ptr %293, align 8
  %308 = or disjoint i64 %295, 2
  %gep13.2 = getelementptr double, ptr %invariant.gep12, i64 %308
  %309 = load double, ptr %gep13.2, align 8
  %310 = getelementptr double, ptr %8, i64 %308
  %311 = load double, ptr %310, align 8
  %312 = fmul double %309, %311
  %313 = fadd double %307, %312
  store double %313, ptr %293, align 8
  %314 = or disjoint i64 %295, 3
  %gep13.3 = getelementptr double, ptr %invariant.gep12, i64 %314
  %315 = load double, ptr %gep13.3, align 8
  %316 = getelementptr double, ptr %8, i64 %314
  %317 = load double, ptr %316, align 8
  %318 = fmul double %315, %317
  %319 = fadd double %313, %318
  store double %319, ptr %293, align 8
  %320 = or disjoint i64 %295, 4
  %gep13.4 = getelementptr double, ptr %invariant.gep12, i64 %320
  %321 = load double, ptr %gep13.4, align 8
  %322 = getelementptr double, ptr %8, i64 %320
  %323 = load double, ptr %322, align 8
  %324 = fmul double %321, %323
  %325 = fadd double %319, %324
  store double %325, ptr %293, align 8
  %326 = or disjoint i64 %295, 5
  %gep13.5 = getelementptr double, ptr %invariant.gep12, i64 %326
  %327 = load double, ptr %gep13.5, align 8
  %328 = getelementptr double, ptr %8, i64 %326
  %329 = load double, ptr %328, align 8
  %330 = fmul double %327, %329
  %331 = fadd double %325, %330
  store double %331, ptr %293, align 8
  %332 = or disjoint i64 %295, 6
  %gep13.6 = getelementptr double, ptr %invariant.gep12, i64 %332
  %333 = load double, ptr %gep13.6, align 8
  %334 = getelementptr double, ptr %8, i64 %332
  %335 = load double, ptr %334, align 8
  %336 = fmul double %333, %335
  %337 = fadd double %331, %336
  store double %337, ptr %293, align 8
  %338 = or disjoint i64 %295, 7
  %gep13.7 = getelementptr double, ptr %invariant.gep12, i64 %338
  %339 = load double, ptr %gep13.7, align 8
  %340 = getelementptr double, ptr %8, i64 %338
  %341 = load double, ptr %340, align 8
  %342 = fmul double %339, %341
  %343 = fadd double %337, %342
  store double %343, ptr %293, align 8
  %344 = add nuw nsw i64 %295, 8
  %exitcond.1.1.not.7 = icmp eq i64 %344, 64
  br i1 %exitcond.1.1.not.7, label %.preheader.2.1, label %294

.preheader.2.1:                                   ; preds = %294
  %345 = getelementptr double, ptr %13, i64 6
  %invariant.gep14 = getelementptr double, ptr %1, i64 384
  br label %346

346:                                              ; preds = %346, %.preheader.2.1
  %347 = phi i64 [ 0, %.preheader.2.1 ], [ %396, %346 ]
  %348 = phi double [ 0.000000e+00, %.preheader.2.1 ], [ %395, %346 ]
  %gep15 = getelementptr double, ptr %invariant.gep14, i64 %347
  %349 = load double, ptr %gep15, align 8
  %350 = getelementptr double, ptr %8, i64 %347
  %351 = load double, ptr %350, align 8
  %352 = fmul double %349, %351
  %353 = fadd double %348, %352
  store double %353, ptr %345, align 8
  %354 = or disjoint i64 %347, 1
  %gep15.1 = getelementptr double, ptr %invariant.gep14, i64 %354
  %355 = load double, ptr %gep15.1, align 8
  %356 = getelementptr double, ptr %8, i64 %354
  %357 = load double, ptr %356, align 8
  %358 = fmul double %355, %357
  %359 = fadd double %353, %358
  store double %359, ptr %345, align 8
  %360 = or disjoint i64 %347, 2
  %gep15.2 = getelementptr double, ptr %invariant.gep14, i64 %360
  %361 = load double, ptr %gep15.2, align 8
  %362 = getelementptr double, ptr %8, i64 %360
  %363 = load double, ptr %362, align 8
  %364 = fmul double %361, %363
  %365 = fadd double %359, %364
  store double %365, ptr %345, align 8
  %366 = or disjoint i64 %347, 3
  %gep15.3 = getelementptr double, ptr %invariant.gep14, i64 %366
  %367 = load double, ptr %gep15.3, align 8
  %368 = getelementptr double, ptr %8, i64 %366
  %369 = load double, ptr %368, align 8
  %370 = fmul double %367, %369
  %371 = fadd double %365, %370
  store double %371, ptr %345, align 8
  %372 = or disjoint i64 %347, 4
  %gep15.4 = getelementptr double, ptr %invariant.gep14, i64 %372
  %373 = load double, ptr %gep15.4, align 8
  %374 = getelementptr double, ptr %8, i64 %372
  %375 = load double, ptr %374, align 8
  %376 = fmul double %373, %375
  %377 = fadd double %371, %376
  store double %377, ptr %345, align 8
  %378 = or disjoint i64 %347, 5
  %gep15.5 = getelementptr double, ptr %invariant.gep14, i64 %378
  %379 = load double, ptr %gep15.5, align 8
  %380 = getelementptr double, ptr %8, i64 %378
  %381 = load double, ptr %380, align 8
  %382 = fmul double %379, %381
  %383 = fadd double %377, %382
  store double %383, ptr %345, align 8
  %384 = or disjoint i64 %347, 6
  %gep15.6 = getelementptr double, ptr %invariant.gep14, i64 %384
  %385 = load double, ptr %gep15.6, align 8
  %386 = getelementptr double, ptr %8, i64 %384
  %387 = load double, ptr %386, align 8
  %388 = fmul double %385, %387
  %389 = fadd double %383, %388
  store double %389, ptr %345, align 8
  %390 = or disjoint i64 %347, 7
  %gep15.7 = getelementptr double, ptr %invariant.gep14, i64 %390
  %391 = load double, ptr %gep15.7, align 8
  %392 = getelementptr double, ptr %8, i64 %390
  %393 = load double, ptr %392, align 8
  %394 = fmul double %391, %393
  %395 = fadd double %389, %394
  store double %395, ptr %345, align 8
  %396 = add nuw nsw i64 %347, 8
  %exitcond.2.1.not.7 = icmp eq i64 %396, 64
  br i1 %exitcond.2.1.not.7, label %.preheader.3.1, label %346

.preheader.3.1:                                   ; preds = %346
  %397 = getelementptr double, ptr %13, i64 7
  %invariant.gep16 = getelementptr double, ptr %1, i64 448
  br label %398

398:                                              ; preds = %398, %.preheader.3.1
  %399 = phi i64 [ 0, %.preheader.3.1 ], [ %448, %398 ]
  %400 = phi double [ 0.000000e+00, %.preheader.3.1 ], [ %447, %398 ]
  %gep17 = getelementptr double, ptr %invariant.gep16, i64 %399
  %401 = load double, ptr %gep17, align 8
  %402 = getelementptr double, ptr %8, i64 %399
  %403 = load double, ptr %402, align 8
  %404 = fmul double %401, %403
  %405 = fadd double %400, %404
  store double %405, ptr %397, align 8
  %406 = or disjoint i64 %399, 1
  %gep17.1 = getelementptr double, ptr %invariant.gep16, i64 %406
  %407 = load double, ptr %gep17.1, align 8
  %408 = getelementptr double, ptr %8, i64 %406
  %409 = load double, ptr %408, align 8
  %410 = fmul double %407, %409
  %411 = fadd double %405, %410
  store double %411, ptr %397, align 8
  %412 = or disjoint i64 %399, 2
  %gep17.2 = getelementptr double, ptr %invariant.gep16, i64 %412
  %413 = load double, ptr %gep17.2, align 8
  %414 = getelementptr double, ptr %8, i64 %412
  %415 = load double, ptr %414, align 8
  %416 = fmul double %413, %415
  %417 = fadd double %411, %416
  store double %417, ptr %397, align 8
  %418 = or disjoint i64 %399, 3
  %gep17.3 = getelementptr double, ptr %invariant.gep16, i64 %418
  %419 = load double, ptr %gep17.3, align 8
  %420 = getelementptr double, ptr %8, i64 %418
  %421 = load double, ptr %420, align 8
  %422 = fmul double %419, %421
  %423 = fadd double %417, %422
  store double %423, ptr %397, align 8
  %424 = or disjoint i64 %399, 4
  %gep17.4 = getelementptr double, ptr %invariant.gep16, i64 %424
  %425 = load double, ptr %gep17.4, align 8
  %426 = getelementptr double, ptr %8, i64 %424
  %427 = load double, ptr %426, align 8
  %428 = fmul double %425, %427
  %429 = fadd double %423, %428
  store double %429, ptr %397, align 8
  %430 = or disjoint i64 %399, 5
  %gep17.5 = getelementptr double, ptr %invariant.gep16, i64 %430
  %431 = load double, ptr %gep17.5, align 8
  %432 = getelementptr double, ptr %8, i64 %430
  %433 = load double, ptr %432, align 8
  %434 = fmul double %431, %433
  %435 = fadd double %429, %434
  store double %435, ptr %397, align 8
  %436 = or disjoint i64 %399, 6
  %gep17.6 = getelementptr double, ptr %invariant.gep16, i64 %436
  %437 = load double, ptr %gep17.6, align 8
  %438 = getelementptr double, ptr %8, i64 %436
  %439 = load double, ptr %438, align 8
  %440 = fmul double %437, %439
  %441 = fadd double %435, %440
  store double %441, ptr %397, align 8
  %442 = or disjoint i64 %399, 7
  %gep17.7 = getelementptr double, ptr %invariant.gep16, i64 %442
  %443 = load double, ptr %gep17.7, align 8
  %444 = getelementptr double, ptr %8, i64 %442
  %445 = load double, ptr %444, align 8
  %446 = fmul double %443, %445
  %447 = fadd double %441, %446
  store double %447, ptr %397, align 8
  %448 = add nuw nsw i64 %399, 8
  %exitcond.3.1.not.7 = icmp eq i64 %448, 64
  br i1 %exitcond.3.1.not.7, label %449, label %398

449:                                              ; preds = %398
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28, i8 0, i64 64, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %62, %4 ]
  %6 = phi double [ 0.000000e+00, %3 ], [ %61, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %.unpack17, i64 %5
  %10 = load double, ptr %9, align 8
  %11 = fmul double %8, %10
  %12 = fadd double %6, %11
  store double %12, ptr %.unpack28, align 8
  %13 = or disjoint i64 %5, 1
  %14 = getelementptr double, ptr %.unpack2, i64 %13
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %.unpack17, i64 %13
  %17 = load double, ptr %16, align 8
  %18 = fmul double %15, %17
  %19 = fadd double %12, %18
  store double %19, ptr %.unpack28, align 8
  %20 = or disjoint i64 %5, 2
  %21 = getelementptr double, ptr %.unpack2, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17, i64 %20
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %19, %25
  store double %26, ptr %.unpack28, align 8
  %27 = or disjoint i64 %5, 3
  %28 = getelementptr double, ptr %.unpack2, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %.unpack17, i64 %27
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %.unpack28, align 8
  %34 = or disjoint i64 %5, 4
  %35 = getelementptr double, ptr %.unpack2, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %.unpack17, i64 %34
  %38 = load double, ptr %37, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %.unpack28, align 8
  %41 = or disjoint i64 %5, 5
  %42 = getelementptr double, ptr %.unpack2, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %.unpack17, i64 %41
  %45 = load double, ptr %44, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %40, %46
  store double %47, ptr %.unpack28, align 8
  %48 = or disjoint i64 %5, 6
  %49 = getelementptr double, ptr %.unpack2, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %.unpack17, i64 %48
  %52 = load double, ptr %51, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %47, %53
  store double %54, ptr %.unpack28, align 8
  %55 = or disjoint i64 %5, 7
  %56 = getelementptr double, ptr %.unpack2, i64 %55
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %.unpack17, i64 %55
  %59 = load double, ptr %58, align 8
  %60 = fmul double %57, %59
  %61 = fadd double %54, %60
  store double %61, ptr %.unpack28, align 8
  %62 = add nuw nsw i64 %5, 8
  %exitcond.not.i.7 = icmp eq i64 %62, 64
  br i1 %exitcond.not.i.7, label %.preheader.1.i, label %4

.preheader.1.i:                                   ; preds = %4
  %63 = getelementptr double, ptr %.unpack28, i64 1
  %invariant.gep10.i = getelementptr double, ptr %.unpack2, i64 64
  br label %64

64:                                               ; preds = %64, %.preheader.1.i
  %65 = phi i64 [ 0, %.preheader.1.i ], [ %114, %64 ]
  %66 = phi double [ 0.000000e+00, %.preheader.1.i ], [ %113, %64 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %65
  %67 = load double, ptr %gep11.i, align 8
  %68 = getelementptr double, ptr %.unpack17, i64 %65
  %69 = load double, ptr %68, align 8
  %70 = fmul double %67, %69
  %71 = fadd double %66, %70
  store double %71, ptr %63, align 8
  %72 = or disjoint i64 %65, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %72
  %73 = load double, ptr %gep11.i.1, align 8
  %74 = getelementptr double, ptr %.unpack17, i64 %72
  %75 = load double, ptr %74, align 8
  %76 = fmul double %73, %75
  %77 = fadd double %71, %76
  store double %77, ptr %63, align 8
  %78 = or disjoint i64 %65, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %78
  %79 = load double, ptr %gep11.i.2, align 8
  %80 = getelementptr double, ptr %.unpack17, i64 %78
  %81 = load double, ptr %80, align 8
  %82 = fmul double %79, %81
  %83 = fadd double %77, %82
  store double %83, ptr %63, align 8
  %84 = or disjoint i64 %65, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %84
  %85 = load double, ptr %gep11.i.3, align 8
  %86 = getelementptr double, ptr %.unpack17, i64 %84
  %87 = load double, ptr %86, align 8
  %88 = fmul double %85, %87
  %89 = fadd double %83, %88
  store double %89, ptr %63, align 8
  %90 = or disjoint i64 %65, 4
  %gep11.i.4 = getelementptr double, ptr %invariant.gep10.i, i64 %90
  %91 = load double, ptr %gep11.i.4, align 8
  %92 = getelementptr double, ptr %.unpack17, i64 %90
  %93 = load double, ptr %92, align 8
  %94 = fmul double %91, %93
  %95 = fadd double %89, %94
  store double %95, ptr %63, align 8
  %96 = or disjoint i64 %65, 5
  %gep11.i.5 = getelementptr double, ptr %invariant.gep10.i, i64 %96
  %97 = load double, ptr %gep11.i.5, align 8
  %98 = getelementptr double, ptr %.unpack17, i64 %96
  %99 = load double, ptr %98, align 8
  %100 = fmul double %97, %99
  %101 = fadd double %95, %100
  store double %101, ptr %63, align 8
  %102 = or disjoint i64 %65, 6
  %gep11.i.6 = getelementptr double, ptr %invariant.gep10.i, i64 %102
  %103 = load double, ptr %gep11.i.6, align 8
  %104 = getelementptr double, ptr %.unpack17, i64 %102
  %105 = load double, ptr %104, align 8
  %106 = fmul double %103, %105
  %107 = fadd double %101, %106
  store double %107, ptr %63, align 8
  %108 = or disjoint i64 %65, 7
  %gep11.i.7 = getelementptr double, ptr %invariant.gep10.i, i64 %108
  %109 = load double, ptr %gep11.i.7, align 8
  %110 = getelementptr double, ptr %.unpack17, i64 %108
  %111 = load double, ptr %110, align 8
  %112 = fmul double %109, %111
  %113 = fadd double %107, %112
  store double %113, ptr %63, align 8
  %114 = add nuw nsw i64 %65, 8
  %exitcond.1.not.i.7 = icmp eq i64 %114, 64
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %64

.preheader.2.i:                                   ; preds = %64
  %115 = getelementptr double, ptr %.unpack28, i64 2
  %invariant.gep8.i = getelementptr double, ptr %.unpack2, i64 128
  br label %116

116:                                              ; preds = %116, %.preheader.2.i
  %117 = phi i64 [ 0, %.preheader.2.i ], [ %166, %116 ]
  %118 = phi double [ 0.000000e+00, %.preheader.2.i ], [ %165, %116 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %117
  %119 = load double, ptr %gep9.i, align 8
  %120 = getelementptr double, ptr %.unpack17, i64 %117
  %121 = load double, ptr %120, align 8
  %122 = fmul double %119, %121
  %123 = fadd double %118, %122
  store double %123, ptr %115, align 8
  %124 = or disjoint i64 %117, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %124
  %125 = load double, ptr %gep9.i.1, align 8
  %126 = getelementptr double, ptr %.unpack17, i64 %124
  %127 = load double, ptr %126, align 8
  %128 = fmul double %125, %127
  %129 = fadd double %123, %128
  store double %129, ptr %115, align 8
  %130 = or disjoint i64 %117, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %130
  %131 = load double, ptr %gep9.i.2, align 8
  %132 = getelementptr double, ptr %.unpack17, i64 %130
  %133 = load double, ptr %132, align 8
  %134 = fmul double %131, %133
  %135 = fadd double %129, %134
  store double %135, ptr %115, align 8
  %136 = or disjoint i64 %117, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %136
  %137 = load double, ptr %gep9.i.3, align 8
  %138 = getelementptr double, ptr %.unpack17, i64 %136
  %139 = load double, ptr %138, align 8
  %140 = fmul double %137, %139
  %141 = fadd double %135, %140
  store double %141, ptr %115, align 8
  %142 = or disjoint i64 %117, 4
  %gep9.i.4 = getelementptr double, ptr %invariant.gep8.i, i64 %142
  %143 = load double, ptr %gep9.i.4, align 8
  %144 = getelementptr double, ptr %.unpack17, i64 %142
  %145 = load double, ptr %144, align 8
  %146 = fmul double %143, %145
  %147 = fadd double %141, %146
  store double %147, ptr %115, align 8
  %148 = or disjoint i64 %117, 5
  %gep9.i.5 = getelementptr double, ptr %invariant.gep8.i, i64 %148
  %149 = load double, ptr %gep9.i.5, align 8
  %150 = getelementptr double, ptr %.unpack17, i64 %148
  %151 = load double, ptr %150, align 8
  %152 = fmul double %149, %151
  %153 = fadd double %147, %152
  store double %153, ptr %115, align 8
  %154 = or disjoint i64 %117, 6
  %gep9.i.6 = getelementptr double, ptr %invariant.gep8.i, i64 %154
  %155 = load double, ptr %gep9.i.6, align 8
  %156 = getelementptr double, ptr %.unpack17, i64 %154
  %157 = load double, ptr %156, align 8
  %158 = fmul double %155, %157
  %159 = fadd double %153, %158
  store double %159, ptr %115, align 8
  %160 = or disjoint i64 %117, 7
  %gep9.i.7 = getelementptr double, ptr %invariant.gep8.i, i64 %160
  %161 = load double, ptr %gep9.i.7, align 8
  %162 = getelementptr double, ptr %.unpack17, i64 %160
  %163 = load double, ptr %162, align 8
  %164 = fmul double %161, %163
  %165 = fadd double %159, %164
  store double %165, ptr %115, align 8
  %166 = add nuw nsw i64 %117, 8
  %exitcond.2.not.i.7 = icmp eq i64 %166, 64
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %116

.preheader.3.i:                                   ; preds = %116
  %167 = getelementptr double, ptr %.unpack28, i64 3
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 192
  br label %168

168:                                              ; preds = %168, %.preheader.3.i
  %169 = phi i64 [ 0, %.preheader.3.i ], [ %218, %168 ]
  %170 = phi double [ 0.000000e+00, %.preheader.3.i ], [ %217, %168 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %169
  %171 = load double, ptr %gep.i, align 8
  %172 = getelementptr double, ptr %.unpack17, i64 %169
  %173 = load double, ptr %172, align 8
  %174 = fmul double %171, %173
  %175 = fadd double %170, %174
  store double %175, ptr %167, align 8
  %176 = or disjoint i64 %169, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %176
  %177 = load double, ptr %gep.i.1, align 8
  %178 = getelementptr double, ptr %.unpack17, i64 %176
  %179 = load double, ptr %178, align 8
  %180 = fmul double %177, %179
  %181 = fadd double %175, %180
  store double %181, ptr %167, align 8
  %182 = or disjoint i64 %169, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %182
  %183 = load double, ptr %gep.i.2, align 8
  %184 = getelementptr double, ptr %.unpack17, i64 %182
  %185 = load double, ptr %184, align 8
  %186 = fmul double %183, %185
  %187 = fadd double %181, %186
  store double %187, ptr %167, align 8
  %188 = or disjoint i64 %169, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %188
  %189 = load double, ptr %gep.i.3, align 8
  %190 = getelementptr double, ptr %.unpack17, i64 %188
  %191 = load double, ptr %190, align 8
  %192 = fmul double %189, %191
  %193 = fadd double %187, %192
  store double %193, ptr %167, align 8
  %194 = or disjoint i64 %169, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %194
  %195 = load double, ptr %gep.i.4, align 8
  %196 = getelementptr double, ptr %.unpack17, i64 %194
  %197 = load double, ptr %196, align 8
  %198 = fmul double %195, %197
  %199 = fadd double %193, %198
  store double %199, ptr %167, align 8
  %200 = or disjoint i64 %169, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %200
  %201 = load double, ptr %gep.i.5, align 8
  %202 = getelementptr double, ptr %.unpack17, i64 %200
  %203 = load double, ptr %202, align 8
  %204 = fmul double %201, %203
  %205 = fadd double %199, %204
  store double %205, ptr %167, align 8
  %206 = or disjoint i64 %169, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %206
  %207 = load double, ptr %gep.i.6, align 8
  %208 = getelementptr double, ptr %.unpack17, i64 %206
  %209 = load double, ptr %208, align 8
  %210 = fmul double %207, %209
  %211 = fadd double %205, %210
  store double %211, ptr %167, align 8
  %212 = or disjoint i64 %169, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %212
  %213 = load double, ptr %gep.i.7, align 8
  %214 = getelementptr double, ptr %.unpack17, i64 %212
  %215 = load double, ptr %214, align 8
  %216 = fmul double %213, %215
  %217 = fadd double %211, %216
  store double %217, ptr %167, align 8
  %218 = add nuw nsw i64 %169, 8
  %exitcond.3.not.i.7 = icmp eq i64 %218, 64
  br i1 %exitcond.3.not.i.7, label %.preheader3.1.i, label %168

.preheader3.1.i:                                  ; preds = %168
  %219 = getelementptr double, ptr %.unpack2, i64 256
  %220 = getelementptr double, ptr %.unpack28, i64 4
  br label %221

221:                                              ; preds = %221, %.preheader3.1.i
  %222 = phi i64 [ 0, %.preheader3.1.i ], [ %279, %221 ]
  %223 = phi double [ 0.000000e+00, %.preheader3.1.i ], [ %278, %221 ]
  %224 = getelementptr double, ptr %219, i64 %222
  %225 = load double, ptr %224, align 8
  %226 = getelementptr double, ptr %.unpack17, i64 %222
  %227 = load double, ptr %226, align 8
  %228 = fmul double %225, %227
  %229 = fadd double %223, %228
  store double %229, ptr %220, align 8
  %230 = or disjoint i64 %222, 1
  %231 = getelementptr double, ptr %219, i64 %230
  %232 = load double, ptr %231, align 8
  %233 = getelementptr double, ptr %.unpack17, i64 %230
  %234 = load double, ptr %233, align 8
  %235 = fmul double %232, %234
  %236 = fadd double %229, %235
  store double %236, ptr %220, align 8
  %237 = or disjoint i64 %222, 2
  %238 = getelementptr double, ptr %219, i64 %237
  %239 = load double, ptr %238, align 8
  %240 = getelementptr double, ptr %.unpack17, i64 %237
  %241 = load double, ptr %240, align 8
  %242 = fmul double %239, %241
  %243 = fadd double %236, %242
  store double %243, ptr %220, align 8
  %244 = or disjoint i64 %222, 3
  %245 = getelementptr double, ptr %219, i64 %244
  %246 = load double, ptr %245, align 8
  %247 = getelementptr double, ptr %.unpack17, i64 %244
  %248 = load double, ptr %247, align 8
  %249 = fmul double %246, %248
  %250 = fadd double %243, %249
  store double %250, ptr %220, align 8
  %251 = or disjoint i64 %222, 4
  %252 = getelementptr double, ptr %219, i64 %251
  %253 = load double, ptr %252, align 8
  %254 = getelementptr double, ptr %.unpack17, i64 %251
  %255 = load double, ptr %254, align 8
  %256 = fmul double %253, %255
  %257 = fadd double %250, %256
  store double %257, ptr %220, align 8
  %258 = or disjoint i64 %222, 5
  %259 = getelementptr double, ptr %219, i64 %258
  %260 = load double, ptr %259, align 8
  %261 = getelementptr double, ptr %.unpack17, i64 %258
  %262 = load double, ptr %261, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %257, %263
  store double %264, ptr %220, align 8
  %265 = or disjoint i64 %222, 6
  %266 = getelementptr double, ptr %219, i64 %265
  %267 = load double, ptr %266, align 8
  %268 = getelementptr double, ptr %.unpack17, i64 %265
  %269 = load double, ptr %268, align 8
  %270 = fmul double %267, %269
  %271 = fadd double %264, %270
  store double %271, ptr %220, align 8
  %272 = or disjoint i64 %222, 7
  %273 = getelementptr double, ptr %219, i64 %272
  %274 = load double, ptr %273, align 8
  %275 = getelementptr double, ptr %.unpack17, i64 %272
  %276 = load double, ptr %275, align 8
  %277 = fmul double %274, %276
  %278 = fadd double %271, %277
  store double %278, ptr %220, align 8
  %279 = add nuw nsw i64 %222, 8
  %exitcond.17.not.i.7 = icmp eq i64 %279, 64
  br i1 %exitcond.17.not.i.7, label %.preheader.1.1.i, label %221

.preheader.1.1.i:                                 ; preds = %221
  %280 = getelementptr double, ptr %.unpack28, i64 5
  %invariant.gep12.i = getelementptr double, ptr %.unpack2, i64 320
  br label %281

281:                                              ; preds = %281, %.preheader.1.1.i
  %282 = phi i64 [ 0, %.preheader.1.1.i ], [ %331, %281 ]
  %283 = phi double [ 0.000000e+00, %.preheader.1.1.i ], [ %330, %281 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %282
  %284 = load double, ptr %gep13.i, align 8
  %285 = getelementptr double, ptr %.unpack17, i64 %282
  %286 = load double, ptr %285, align 8
  %287 = fmul double %284, %286
  %288 = fadd double %283, %287
  store double %288, ptr %280, align 8
  %289 = or disjoint i64 %282, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %289
  %290 = load double, ptr %gep13.i.1, align 8
  %291 = getelementptr double, ptr %.unpack17, i64 %289
  %292 = load double, ptr %291, align 8
  %293 = fmul double %290, %292
  %294 = fadd double %288, %293
  store double %294, ptr %280, align 8
  %295 = or disjoint i64 %282, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %295
  %296 = load double, ptr %gep13.i.2, align 8
  %297 = getelementptr double, ptr %.unpack17, i64 %295
  %298 = load double, ptr %297, align 8
  %299 = fmul double %296, %298
  %300 = fadd double %294, %299
  store double %300, ptr %280, align 8
  %301 = or disjoint i64 %282, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %301
  %302 = load double, ptr %gep13.i.3, align 8
  %303 = getelementptr double, ptr %.unpack17, i64 %301
  %304 = load double, ptr %303, align 8
  %305 = fmul double %302, %304
  %306 = fadd double %300, %305
  store double %306, ptr %280, align 8
  %307 = or disjoint i64 %282, 4
  %gep13.i.4 = getelementptr double, ptr %invariant.gep12.i, i64 %307
  %308 = load double, ptr %gep13.i.4, align 8
  %309 = getelementptr double, ptr %.unpack17, i64 %307
  %310 = load double, ptr %309, align 8
  %311 = fmul double %308, %310
  %312 = fadd double %306, %311
  store double %312, ptr %280, align 8
  %313 = or disjoint i64 %282, 5
  %gep13.i.5 = getelementptr double, ptr %invariant.gep12.i, i64 %313
  %314 = load double, ptr %gep13.i.5, align 8
  %315 = getelementptr double, ptr %.unpack17, i64 %313
  %316 = load double, ptr %315, align 8
  %317 = fmul double %314, %316
  %318 = fadd double %312, %317
  store double %318, ptr %280, align 8
  %319 = or disjoint i64 %282, 6
  %gep13.i.6 = getelementptr double, ptr %invariant.gep12.i, i64 %319
  %320 = load double, ptr %gep13.i.6, align 8
  %321 = getelementptr double, ptr %.unpack17, i64 %319
  %322 = load double, ptr %321, align 8
  %323 = fmul double %320, %322
  %324 = fadd double %318, %323
  store double %324, ptr %280, align 8
  %325 = or disjoint i64 %282, 7
  %gep13.i.7 = getelementptr double, ptr %invariant.gep12.i, i64 %325
  %326 = load double, ptr %gep13.i.7, align 8
  %327 = getelementptr double, ptr %.unpack17, i64 %325
  %328 = load double, ptr %327, align 8
  %329 = fmul double %326, %328
  %330 = fadd double %324, %329
  store double %330, ptr %280, align 8
  %331 = add nuw nsw i64 %282, 8
  %exitcond.1.1.not.i.7 = icmp eq i64 %331, 64
  br i1 %exitcond.1.1.not.i.7, label %.preheader.2.1.i, label %281

.preheader.2.1.i:                                 ; preds = %281
  %332 = getelementptr double, ptr %.unpack28, i64 6
  %invariant.gep14.i = getelementptr double, ptr %.unpack2, i64 384
  br label %333

333:                                              ; preds = %333, %.preheader.2.1.i
  %334 = phi i64 [ 0, %.preheader.2.1.i ], [ %383, %333 ]
  %335 = phi double [ 0.000000e+00, %.preheader.2.1.i ], [ %382, %333 ]
  %gep15.i = getelementptr double, ptr %invariant.gep14.i, i64 %334
  %336 = load double, ptr %gep15.i, align 8
  %337 = getelementptr double, ptr %.unpack17, i64 %334
  %338 = load double, ptr %337, align 8
  %339 = fmul double %336, %338
  %340 = fadd double %335, %339
  store double %340, ptr %332, align 8
  %341 = or disjoint i64 %334, 1
  %gep15.i.1 = getelementptr double, ptr %invariant.gep14.i, i64 %341
  %342 = load double, ptr %gep15.i.1, align 8
  %343 = getelementptr double, ptr %.unpack17, i64 %341
  %344 = load double, ptr %343, align 8
  %345 = fmul double %342, %344
  %346 = fadd double %340, %345
  store double %346, ptr %332, align 8
  %347 = or disjoint i64 %334, 2
  %gep15.i.2 = getelementptr double, ptr %invariant.gep14.i, i64 %347
  %348 = load double, ptr %gep15.i.2, align 8
  %349 = getelementptr double, ptr %.unpack17, i64 %347
  %350 = load double, ptr %349, align 8
  %351 = fmul double %348, %350
  %352 = fadd double %346, %351
  store double %352, ptr %332, align 8
  %353 = or disjoint i64 %334, 3
  %gep15.i.3 = getelementptr double, ptr %invariant.gep14.i, i64 %353
  %354 = load double, ptr %gep15.i.3, align 8
  %355 = getelementptr double, ptr %.unpack17, i64 %353
  %356 = load double, ptr %355, align 8
  %357 = fmul double %354, %356
  %358 = fadd double %352, %357
  store double %358, ptr %332, align 8
  %359 = or disjoint i64 %334, 4
  %gep15.i.4 = getelementptr double, ptr %invariant.gep14.i, i64 %359
  %360 = load double, ptr %gep15.i.4, align 8
  %361 = getelementptr double, ptr %.unpack17, i64 %359
  %362 = load double, ptr %361, align 8
  %363 = fmul double %360, %362
  %364 = fadd double %358, %363
  store double %364, ptr %332, align 8
  %365 = or disjoint i64 %334, 5
  %gep15.i.5 = getelementptr double, ptr %invariant.gep14.i, i64 %365
  %366 = load double, ptr %gep15.i.5, align 8
  %367 = getelementptr double, ptr %.unpack17, i64 %365
  %368 = load double, ptr %367, align 8
  %369 = fmul double %366, %368
  %370 = fadd double %364, %369
  store double %370, ptr %332, align 8
  %371 = or disjoint i64 %334, 6
  %gep15.i.6 = getelementptr double, ptr %invariant.gep14.i, i64 %371
  %372 = load double, ptr %gep15.i.6, align 8
  %373 = getelementptr double, ptr %.unpack17, i64 %371
  %374 = load double, ptr %373, align 8
  %375 = fmul double %372, %374
  %376 = fadd double %370, %375
  store double %376, ptr %332, align 8
  %377 = or disjoint i64 %334, 7
  %gep15.i.7 = getelementptr double, ptr %invariant.gep14.i, i64 %377
  %378 = load double, ptr %gep15.i.7, align 8
  %379 = getelementptr double, ptr %.unpack17, i64 %377
  %380 = load double, ptr %379, align 8
  %381 = fmul double %378, %380
  %382 = fadd double %376, %381
  store double %382, ptr %332, align 8
  %383 = add nuw nsw i64 %334, 8
  %exitcond.2.1.not.i.7 = icmp eq i64 %383, 64
  br i1 %exitcond.2.1.not.i.7, label %.preheader.3.1.i, label %333

.preheader.3.1.i:                                 ; preds = %333
  %384 = getelementptr double, ptr %.unpack28, i64 7
  %invariant.gep16.i = getelementptr double, ptr %.unpack2, i64 448
  br label %385

385:                                              ; preds = %385, %.preheader.3.1.i
  %386 = phi i64 [ 0, %.preheader.3.1.i ], [ %435, %385 ]
  %387 = phi double [ 0.000000e+00, %.preheader.3.1.i ], [ %434, %385 ]
  %gep17.i = getelementptr double, ptr %invariant.gep16.i, i64 %386
  %388 = load double, ptr %gep17.i, align 8
  %389 = getelementptr double, ptr %.unpack17, i64 %386
  %390 = load double, ptr %389, align 8
  %391 = fmul double %388, %390
  %392 = fadd double %387, %391
  store double %392, ptr %384, align 8
  %393 = or disjoint i64 %386, 1
  %gep17.i.1 = getelementptr double, ptr %invariant.gep16.i, i64 %393
  %394 = load double, ptr %gep17.i.1, align 8
  %395 = getelementptr double, ptr %.unpack17, i64 %393
  %396 = load double, ptr %395, align 8
  %397 = fmul double %394, %396
  %398 = fadd double %392, %397
  store double %398, ptr %384, align 8
  %399 = or disjoint i64 %386, 2
  %gep17.i.2 = getelementptr double, ptr %invariant.gep16.i, i64 %399
  %400 = load double, ptr %gep17.i.2, align 8
  %401 = getelementptr double, ptr %.unpack17, i64 %399
  %402 = load double, ptr %401, align 8
  %403 = fmul double %400, %402
  %404 = fadd double %398, %403
  store double %404, ptr %384, align 8
  %405 = or disjoint i64 %386, 3
  %gep17.i.3 = getelementptr double, ptr %invariant.gep16.i, i64 %405
  %406 = load double, ptr %gep17.i.3, align 8
  %407 = getelementptr double, ptr %.unpack17, i64 %405
  %408 = load double, ptr %407, align 8
  %409 = fmul double %406, %408
  %410 = fadd double %404, %409
  store double %410, ptr %384, align 8
  %411 = or disjoint i64 %386, 4
  %gep17.i.4 = getelementptr double, ptr %invariant.gep16.i, i64 %411
  %412 = load double, ptr %gep17.i.4, align 8
  %413 = getelementptr double, ptr %.unpack17, i64 %411
  %414 = load double, ptr %413, align 8
  %415 = fmul double %412, %414
  %416 = fadd double %410, %415
  store double %416, ptr %384, align 8
  %417 = or disjoint i64 %386, 5
  %gep17.i.5 = getelementptr double, ptr %invariant.gep16.i, i64 %417
  %418 = load double, ptr %gep17.i.5, align 8
  %419 = getelementptr double, ptr %.unpack17, i64 %417
  %420 = load double, ptr %419, align 8
  %421 = fmul double %418, %420
  %422 = fadd double %416, %421
  store double %422, ptr %384, align 8
  %423 = or disjoint i64 %386, 6
  %gep17.i.6 = getelementptr double, ptr %invariant.gep16.i, i64 %423
  %424 = load double, ptr %gep17.i.6, align 8
  %425 = getelementptr double, ptr %.unpack17, i64 %423
  %426 = load double, ptr %425, align 8
  %427 = fmul double %424, %426
  %428 = fadd double %422, %427
  store double %428, ptr %384, align 8
  %429 = or disjoint i64 %386, 7
  %gep17.i.7 = getelementptr double, ptr %invariant.gep16.i, i64 %429
  %430 = load double, ptr %gep17.i.7, align 8
  %431 = getelementptr double, ptr %.unpack17, i64 %429
  %432 = load double, ptr %431, align 8
  %433 = fmul double %430, %432
  %434 = fadd double %428, %433
  store double %434, ptr %384, align 8
  %435 = add nuw nsw i64 %386, 8
  %exitcond.3.1.not.i.7 = icmp eq i64 %435, 64
  br i1 %exitcond.3.1.not.i.7, label %kernel.exit, label %385

kernel.exit:                                      ; preds = %385
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %10, i8 0, i64 64, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %69, %11 ]
  %13 = phi double [ 0.000000e+00, %1 ], [ %68, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %7, i64 %12
  %17 = load double, ptr %16, align 8
  %18 = fmul double %15, %17
  %19 = fadd double %13, %18
  store double %19, ptr %10, align 8
  %20 = or disjoint i64 %12, 1
  %21 = getelementptr double, ptr %4, i64 %20
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %7, i64 %20
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %19, %25
  store double %26, ptr %10, align 8
  %27 = or disjoint i64 %12, 2
  %28 = getelementptr double, ptr %4, i64 %27
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %7, i64 %27
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %26, %32
  store double %33, ptr %10, align 8
  %34 = or disjoint i64 %12, 3
  %35 = getelementptr double, ptr %4, i64 %34
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %7, i64 %34
  %38 = load double, ptr %37, align 8
  %39 = fmul double %36, %38
  %40 = fadd double %33, %39
  store double %40, ptr %10, align 8
  %41 = or disjoint i64 %12, 4
  %42 = getelementptr double, ptr %4, i64 %41
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %7, i64 %41
  %45 = load double, ptr %44, align 8
  %46 = fmul double %43, %45
  %47 = fadd double %40, %46
  store double %47, ptr %10, align 8
  %48 = or disjoint i64 %12, 5
  %49 = getelementptr double, ptr %4, i64 %48
  %50 = load double, ptr %49, align 8
  %51 = getelementptr double, ptr %7, i64 %48
  %52 = load double, ptr %51, align 8
  %53 = fmul double %50, %52
  %54 = fadd double %47, %53
  store double %54, ptr %10, align 8
  %55 = or disjoint i64 %12, 6
  %56 = getelementptr double, ptr %4, i64 %55
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %7, i64 %55
  %59 = load double, ptr %58, align 8
  %60 = fmul double %57, %59
  %61 = fadd double %54, %60
  store double %61, ptr %10, align 8
  %62 = or disjoint i64 %12, 7
  %63 = getelementptr double, ptr %4, i64 %62
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %7, i64 %62
  %66 = load double, ptr %65, align 8
  %67 = fmul double %64, %66
  %68 = fadd double %61, %67
  store double %68, ptr %10, align 8
  %69 = add nuw nsw i64 %12, 8
  %exitcond.not.i.7 = icmp eq i64 %69, 64
  br i1 %exitcond.not.i.7, label %.preheader.1.i, label %11

.preheader.1.i:                                   ; preds = %11
  %70 = getelementptr double, ptr %10, i64 1
  %invariant.gep10.i = getelementptr double, ptr %4, i64 64
  br label %71

71:                                               ; preds = %71, %.preheader.1.i
  %72 = phi i64 [ 0, %.preheader.1.i ], [ %121, %71 ]
  %73 = phi double [ 0.000000e+00, %.preheader.1.i ], [ %120, %71 ]
  %gep11.i = getelementptr double, ptr %invariant.gep10.i, i64 %72
  %74 = load double, ptr %gep11.i, align 8
  %75 = getelementptr double, ptr %7, i64 %72
  %76 = load double, ptr %75, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %73, %77
  store double %78, ptr %70, align 8
  %79 = or disjoint i64 %72, 1
  %gep11.i.1 = getelementptr double, ptr %invariant.gep10.i, i64 %79
  %80 = load double, ptr %gep11.i.1, align 8
  %81 = getelementptr double, ptr %7, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %70, align 8
  %85 = or disjoint i64 %72, 2
  %gep11.i.2 = getelementptr double, ptr %invariant.gep10.i, i64 %85
  %86 = load double, ptr %gep11.i.2, align 8
  %87 = getelementptr double, ptr %7, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %70, align 8
  %91 = or disjoint i64 %72, 3
  %gep11.i.3 = getelementptr double, ptr %invariant.gep10.i, i64 %91
  %92 = load double, ptr %gep11.i.3, align 8
  %93 = getelementptr double, ptr %7, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %70, align 8
  %97 = or disjoint i64 %72, 4
  %gep11.i.4 = getelementptr double, ptr %invariant.gep10.i, i64 %97
  %98 = load double, ptr %gep11.i.4, align 8
  %99 = getelementptr double, ptr %7, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %70, align 8
  %103 = or disjoint i64 %72, 5
  %gep11.i.5 = getelementptr double, ptr %invariant.gep10.i, i64 %103
  %104 = load double, ptr %gep11.i.5, align 8
  %105 = getelementptr double, ptr %7, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %70, align 8
  %109 = or disjoint i64 %72, 6
  %gep11.i.6 = getelementptr double, ptr %invariant.gep10.i, i64 %109
  %110 = load double, ptr %gep11.i.6, align 8
  %111 = getelementptr double, ptr %7, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %70, align 8
  %115 = or disjoint i64 %72, 7
  %gep11.i.7 = getelementptr double, ptr %invariant.gep10.i, i64 %115
  %116 = load double, ptr %gep11.i.7, align 8
  %117 = getelementptr double, ptr %7, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %70, align 8
  %121 = add nuw nsw i64 %72, 8
  %exitcond.1.not.i.7 = icmp eq i64 %121, 64
  br i1 %exitcond.1.not.i.7, label %.preheader.2.i, label %71

.preheader.2.i:                                   ; preds = %71
  %122 = getelementptr double, ptr %10, i64 2
  %invariant.gep8.i = getelementptr double, ptr %4, i64 128
  br label %123

123:                                              ; preds = %123, %.preheader.2.i
  %124 = phi i64 [ 0, %.preheader.2.i ], [ %173, %123 ]
  %125 = phi double [ 0.000000e+00, %.preheader.2.i ], [ %172, %123 ]
  %gep9.i = getelementptr double, ptr %invariant.gep8.i, i64 %124
  %126 = load double, ptr %gep9.i, align 8
  %127 = getelementptr double, ptr %7, i64 %124
  %128 = load double, ptr %127, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %125, %129
  store double %130, ptr %122, align 8
  %131 = or disjoint i64 %124, 1
  %gep9.i.1 = getelementptr double, ptr %invariant.gep8.i, i64 %131
  %132 = load double, ptr %gep9.i.1, align 8
  %133 = getelementptr double, ptr %7, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %122, align 8
  %137 = or disjoint i64 %124, 2
  %gep9.i.2 = getelementptr double, ptr %invariant.gep8.i, i64 %137
  %138 = load double, ptr %gep9.i.2, align 8
  %139 = getelementptr double, ptr %7, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %122, align 8
  %143 = or disjoint i64 %124, 3
  %gep9.i.3 = getelementptr double, ptr %invariant.gep8.i, i64 %143
  %144 = load double, ptr %gep9.i.3, align 8
  %145 = getelementptr double, ptr %7, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %122, align 8
  %149 = or disjoint i64 %124, 4
  %gep9.i.4 = getelementptr double, ptr %invariant.gep8.i, i64 %149
  %150 = load double, ptr %gep9.i.4, align 8
  %151 = getelementptr double, ptr %7, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %122, align 8
  %155 = or disjoint i64 %124, 5
  %gep9.i.5 = getelementptr double, ptr %invariant.gep8.i, i64 %155
  %156 = load double, ptr %gep9.i.5, align 8
  %157 = getelementptr double, ptr %7, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %122, align 8
  %161 = or disjoint i64 %124, 6
  %gep9.i.6 = getelementptr double, ptr %invariant.gep8.i, i64 %161
  %162 = load double, ptr %gep9.i.6, align 8
  %163 = getelementptr double, ptr %7, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %122, align 8
  %167 = or disjoint i64 %124, 7
  %gep9.i.7 = getelementptr double, ptr %invariant.gep8.i, i64 %167
  %168 = load double, ptr %gep9.i.7, align 8
  %169 = getelementptr double, ptr %7, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %122, align 8
  %173 = add nuw nsw i64 %124, 8
  %exitcond.2.not.i.7 = icmp eq i64 %173, 64
  br i1 %exitcond.2.not.i.7, label %.preheader.3.i, label %123

.preheader.3.i:                                   ; preds = %123
  %174 = getelementptr double, ptr %10, i64 3
  %invariant.gep.i = getelementptr double, ptr %4, i64 192
  br label %175

175:                                              ; preds = %175, %.preheader.3.i
  %176 = phi i64 [ 0, %.preheader.3.i ], [ %225, %175 ]
  %177 = phi double [ 0.000000e+00, %.preheader.3.i ], [ %224, %175 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %176
  %178 = load double, ptr %gep.i, align 8
  %179 = getelementptr double, ptr %7, i64 %176
  %180 = load double, ptr %179, align 8
  %181 = fmul double %178, %180
  %182 = fadd double %177, %181
  store double %182, ptr %174, align 8
  %183 = or disjoint i64 %176, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %183
  %184 = load double, ptr %gep.i.1, align 8
  %185 = getelementptr double, ptr %7, i64 %183
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %182, %187
  store double %188, ptr %174, align 8
  %189 = or disjoint i64 %176, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %189
  %190 = load double, ptr %gep.i.2, align 8
  %191 = getelementptr double, ptr %7, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %174, align 8
  %195 = or disjoint i64 %176, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %195
  %196 = load double, ptr %gep.i.3, align 8
  %197 = getelementptr double, ptr %7, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %174, align 8
  %201 = or disjoint i64 %176, 4
  %gep.i.4 = getelementptr double, ptr %invariant.gep.i, i64 %201
  %202 = load double, ptr %gep.i.4, align 8
  %203 = getelementptr double, ptr %7, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %174, align 8
  %207 = or disjoint i64 %176, 5
  %gep.i.5 = getelementptr double, ptr %invariant.gep.i, i64 %207
  %208 = load double, ptr %gep.i.5, align 8
  %209 = getelementptr double, ptr %7, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %174, align 8
  %213 = or disjoint i64 %176, 6
  %gep.i.6 = getelementptr double, ptr %invariant.gep.i, i64 %213
  %214 = load double, ptr %gep.i.6, align 8
  %215 = getelementptr double, ptr %7, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %174, align 8
  %219 = or disjoint i64 %176, 7
  %gep.i.7 = getelementptr double, ptr %invariant.gep.i, i64 %219
  %220 = load double, ptr %gep.i.7, align 8
  %221 = getelementptr double, ptr %7, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %174, align 8
  %225 = add nuw nsw i64 %176, 8
  %exitcond.3.not.i.7 = icmp eq i64 %225, 64
  br i1 %exitcond.3.not.i.7, label %.preheader3.1.i, label %175

.preheader3.1.i:                                  ; preds = %175
  %226 = getelementptr double, ptr %4, i64 256
  %227 = getelementptr double, ptr %10, i64 4
  br label %228

228:                                              ; preds = %228, %.preheader3.1.i
  %229 = phi i64 [ 0, %.preheader3.1.i ], [ %286, %228 ]
  %230 = phi double [ 0.000000e+00, %.preheader3.1.i ], [ %285, %228 ]
  %231 = getelementptr double, ptr %226, i64 %229
  %232 = load double, ptr %231, align 8
  %233 = getelementptr double, ptr %7, i64 %229
  %234 = load double, ptr %233, align 8
  %235 = fmul double %232, %234
  %236 = fadd double %230, %235
  store double %236, ptr %227, align 8
  %237 = or disjoint i64 %229, 1
  %238 = getelementptr double, ptr %226, i64 %237
  %239 = load double, ptr %238, align 8
  %240 = getelementptr double, ptr %7, i64 %237
  %241 = load double, ptr %240, align 8
  %242 = fmul double %239, %241
  %243 = fadd double %236, %242
  store double %243, ptr %227, align 8
  %244 = or disjoint i64 %229, 2
  %245 = getelementptr double, ptr %226, i64 %244
  %246 = load double, ptr %245, align 8
  %247 = getelementptr double, ptr %7, i64 %244
  %248 = load double, ptr %247, align 8
  %249 = fmul double %246, %248
  %250 = fadd double %243, %249
  store double %250, ptr %227, align 8
  %251 = or disjoint i64 %229, 3
  %252 = getelementptr double, ptr %226, i64 %251
  %253 = load double, ptr %252, align 8
  %254 = getelementptr double, ptr %7, i64 %251
  %255 = load double, ptr %254, align 8
  %256 = fmul double %253, %255
  %257 = fadd double %250, %256
  store double %257, ptr %227, align 8
  %258 = or disjoint i64 %229, 4
  %259 = getelementptr double, ptr %226, i64 %258
  %260 = load double, ptr %259, align 8
  %261 = getelementptr double, ptr %7, i64 %258
  %262 = load double, ptr %261, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %257, %263
  store double %264, ptr %227, align 8
  %265 = or disjoint i64 %229, 5
  %266 = getelementptr double, ptr %226, i64 %265
  %267 = load double, ptr %266, align 8
  %268 = getelementptr double, ptr %7, i64 %265
  %269 = load double, ptr %268, align 8
  %270 = fmul double %267, %269
  %271 = fadd double %264, %270
  store double %271, ptr %227, align 8
  %272 = or disjoint i64 %229, 6
  %273 = getelementptr double, ptr %226, i64 %272
  %274 = load double, ptr %273, align 8
  %275 = getelementptr double, ptr %7, i64 %272
  %276 = load double, ptr %275, align 8
  %277 = fmul double %274, %276
  %278 = fadd double %271, %277
  store double %278, ptr %227, align 8
  %279 = or disjoint i64 %229, 7
  %280 = getelementptr double, ptr %226, i64 %279
  %281 = load double, ptr %280, align 8
  %282 = getelementptr double, ptr %7, i64 %279
  %283 = load double, ptr %282, align 8
  %284 = fmul double %281, %283
  %285 = fadd double %278, %284
  store double %285, ptr %227, align 8
  %286 = add nuw nsw i64 %229, 8
  %exitcond.17.not.i.7 = icmp eq i64 %286, 64
  br i1 %exitcond.17.not.i.7, label %.preheader.1.1.i, label %228

.preheader.1.1.i:                                 ; preds = %228
  %287 = getelementptr double, ptr %10, i64 5
  %invariant.gep12.i = getelementptr double, ptr %4, i64 320
  br label %288

288:                                              ; preds = %288, %.preheader.1.1.i
  %289 = phi i64 [ 0, %.preheader.1.1.i ], [ %338, %288 ]
  %290 = phi double [ 0.000000e+00, %.preheader.1.1.i ], [ %337, %288 ]
  %gep13.i = getelementptr double, ptr %invariant.gep12.i, i64 %289
  %291 = load double, ptr %gep13.i, align 8
  %292 = getelementptr double, ptr %7, i64 %289
  %293 = load double, ptr %292, align 8
  %294 = fmul double %291, %293
  %295 = fadd double %290, %294
  store double %295, ptr %287, align 8
  %296 = or disjoint i64 %289, 1
  %gep13.i.1 = getelementptr double, ptr %invariant.gep12.i, i64 %296
  %297 = load double, ptr %gep13.i.1, align 8
  %298 = getelementptr double, ptr %7, i64 %296
  %299 = load double, ptr %298, align 8
  %300 = fmul double %297, %299
  %301 = fadd double %295, %300
  store double %301, ptr %287, align 8
  %302 = or disjoint i64 %289, 2
  %gep13.i.2 = getelementptr double, ptr %invariant.gep12.i, i64 %302
  %303 = load double, ptr %gep13.i.2, align 8
  %304 = getelementptr double, ptr %7, i64 %302
  %305 = load double, ptr %304, align 8
  %306 = fmul double %303, %305
  %307 = fadd double %301, %306
  store double %307, ptr %287, align 8
  %308 = or disjoint i64 %289, 3
  %gep13.i.3 = getelementptr double, ptr %invariant.gep12.i, i64 %308
  %309 = load double, ptr %gep13.i.3, align 8
  %310 = getelementptr double, ptr %7, i64 %308
  %311 = load double, ptr %310, align 8
  %312 = fmul double %309, %311
  %313 = fadd double %307, %312
  store double %313, ptr %287, align 8
  %314 = or disjoint i64 %289, 4
  %gep13.i.4 = getelementptr double, ptr %invariant.gep12.i, i64 %314
  %315 = load double, ptr %gep13.i.4, align 8
  %316 = getelementptr double, ptr %7, i64 %314
  %317 = load double, ptr %316, align 8
  %318 = fmul double %315, %317
  %319 = fadd double %313, %318
  store double %319, ptr %287, align 8
  %320 = or disjoint i64 %289, 5
  %gep13.i.5 = getelementptr double, ptr %invariant.gep12.i, i64 %320
  %321 = load double, ptr %gep13.i.5, align 8
  %322 = getelementptr double, ptr %7, i64 %320
  %323 = load double, ptr %322, align 8
  %324 = fmul double %321, %323
  %325 = fadd double %319, %324
  store double %325, ptr %287, align 8
  %326 = or disjoint i64 %289, 6
  %gep13.i.6 = getelementptr double, ptr %invariant.gep12.i, i64 %326
  %327 = load double, ptr %gep13.i.6, align 8
  %328 = getelementptr double, ptr %7, i64 %326
  %329 = load double, ptr %328, align 8
  %330 = fmul double %327, %329
  %331 = fadd double %325, %330
  store double %331, ptr %287, align 8
  %332 = or disjoint i64 %289, 7
  %gep13.i.7 = getelementptr double, ptr %invariant.gep12.i, i64 %332
  %333 = load double, ptr %gep13.i.7, align 8
  %334 = getelementptr double, ptr %7, i64 %332
  %335 = load double, ptr %334, align 8
  %336 = fmul double %333, %335
  %337 = fadd double %331, %336
  store double %337, ptr %287, align 8
  %338 = add nuw nsw i64 %289, 8
  %exitcond.1.1.not.i.7 = icmp eq i64 %338, 64
  br i1 %exitcond.1.1.not.i.7, label %.preheader.2.1.i, label %288

.preheader.2.1.i:                                 ; preds = %288
  %339 = getelementptr double, ptr %10, i64 6
  %invariant.gep14.i = getelementptr double, ptr %4, i64 384
  br label %340

340:                                              ; preds = %340, %.preheader.2.1.i
  %341 = phi i64 [ 0, %.preheader.2.1.i ], [ %390, %340 ]
  %342 = phi double [ 0.000000e+00, %.preheader.2.1.i ], [ %389, %340 ]
  %gep15.i = getelementptr double, ptr %invariant.gep14.i, i64 %341
  %343 = load double, ptr %gep15.i, align 8
  %344 = getelementptr double, ptr %7, i64 %341
  %345 = load double, ptr %344, align 8
  %346 = fmul double %343, %345
  %347 = fadd double %342, %346
  store double %347, ptr %339, align 8
  %348 = or disjoint i64 %341, 1
  %gep15.i.1 = getelementptr double, ptr %invariant.gep14.i, i64 %348
  %349 = load double, ptr %gep15.i.1, align 8
  %350 = getelementptr double, ptr %7, i64 %348
  %351 = load double, ptr %350, align 8
  %352 = fmul double %349, %351
  %353 = fadd double %347, %352
  store double %353, ptr %339, align 8
  %354 = or disjoint i64 %341, 2
  %gep15.i.2 = getelementptr double, ptr %invariant.gep14.i, i64 %354
  %355 = load double, ptr %gep15.i.2, align 8
  %356 = getelementptr double, ptr %7, i64 %354
  %357 = load double, ptr %356, align 8
  %358 = fmul double %355, %357
  %359 = fadd double %353, %358
  store double %359, ptr %339, align 8
  %360 = or disjoint i64 %341, 3
  %gep15.i.3 = getelementptr double, ptr %invariant.gep14.i, i64 %360
  %361 = load double, ptr %gep15.i.3, align 8
  %362 = getelementptr double, ptr %7, i64 %360
  %363 = load double, ptr %362, align 8
  %364 = fmul double %361, %363
  %365 = fadd double %359, %364
  store double %365, ptr %339, align 8
  %366 = or disjoint i64 %341, 4
  %gep15.i.4 = getelementptr double, ptr %invariant.gep14.i, i64 %366
  %367 = load double, ptr %gep15.i.4, align 8
  %368 = getelementptr double, ptr %7, i64 %366
  %369 = load double, ptr %368, align 8
  %370 = fmul double %367, %369
  %371 = fadd double %365, %370
  store double %371, ptr %339, align 8
  %372 = or disjoint i64 %341, 5
  %gep15.i.5 = getelementptr double, ptr %invariant.gep14.i, i64 %372
  %373 = load double, ptr %gep15.i.5, align 8
  %374 = getelementptr double, ptr %7, i64 %372
  %375 = load double, ptr %374, align 8
  %376 = fmul double %373, %375
  %377 = fadd double %371, %376
  store double %377, ptr %339, align 8
  %378 = or disjoint i64 %341, 6
  %gep15.i.6 = getelementptr double, ptr %invariant.gep14.i, i64 %378
  %379 = load double, ptr %gep15.i.6, align 8
  %380 = getelementptr double, ptr %7, i64 %378
  %381 = load double, ptr %380, align 8
  %382 = fmul double %379, %381
  %383 = fadd double %377, %382
  store double %383, ptr %339, align 8
  %384 = or disjoint i64 %341, 7
  %gep15.i.7 = getelementptr double, ptr %invariant.gep14.i, i64 %384
  %385 = load double, ptr %gep15.i.7, align 8
  %386 = getelementptr double, ptr %7, i64 %384
  %387 = load double, ptr %386, align 8
  %388 = fmul double %385, %387
  %389 = fadd double %383, %388
  store double %389, ptr %339, align 8
  %390 = add nuw nsw i64 %341, 8
  %exitcond.2.1.not.i.7 = icmp eq i64 %390, 64
  br i1 %exitcond.2.1.not.i.7, label %.preheader.3.1.i, label %340

.preheader.3.1.i:                                 ; preds = %340
  %391 = getelementptr double, ptr %10, i64 7
  %invariant.gep16.i = getelementptr double, ptr %4, i64 448
  br label %392

392:                                              ; preds = %392, %.preheader.3.1.i
  %393 = phi i64 [ 0, %.preheader.3.1.i ], [ %442, %392 ]
  %394 = phi double [ 0.000000e+00, %.preheader.3.1.i ], [ %441, %392 ]
  %gep17.i = getelementptr double, ptr %invariant.gep16.i, i64 %393
  %395 = load double, ptr %gep17.i, align 8
  %396 = getelementptr double, ptr %7, i64 %393
  %397 = load double, ptr %396, align 8
  %398 = fmul double %395, %397
  %399 = fadd double %394, %398
  store double %399, ptr %391, align 8
  %400 = or disjoint i64 %393, 1
  %gep17.i.1 = getelementptr double, ptr %invariant.gep16.i, i64 %400
  %401 = load double, ptr %gep17.i.1, align 8
  %402 = getelementptr double, ptr %7, i64 %400
  %403 = load double, ptr %402, align 8
  %404 = fmul double %401, %403
  %405 = fadd double %399, %404
  store double %405, ptr %391, align 8
  %406 = or disjoint i64 %393, 2
  %gep17.i.2 = getelementptr double, ptr %invariant.gep16.i, i64 %406
  %407 = load double, ptr %gep17.i.2, align 8
  %408 = getelementptr double, ptr %7, i64 %406
  %409 = load double, ptr %408, align 8
  %410 = fmul double %407, %409
  %411 = fadd double %405, %410
  store double %411, ptr %391, align 8
  %412 = or disjoint i64 %393, 3
  %gep17.i.3 = getelementptr double, ptr %invariant.gep16.i, i64 %412
  %413 = load double, ptr %gep17.i.3, align 8
  %414 = getelementptr double, ptr %7, i64 %412
  %415 = load double, ptr %414, align 8
  %416 = fmul double %413, %415
  %417 = fadd double %411, %416
  store double %417, ptr %391, align 8
  %418 = or disjoint i64 %393, 4
  %gep17.i.4 = getelementptr double, ptr %invariant.gep16.i, i64 %418
  %419 = load double, ptr %gep17.i.4, align 8
  %420 = getelementptr double, ptr %7, i64 %418
  %421 = load double, ptr %420, align 8
  %422 = fmul double %419, %421
  %423 = fadd double %417, %422
  store double %423, ptr %391, align 8
  %424 = or disjoint i64 %393, 5
  %gep17.i.5 = getelementptr double, ptr %invariant.gep16.i, i64 %424
  %425 = load double, ptr %gep17.i.5, align 8
  %426 = getelementptr double, ptr %7, i64 %424
  %427 = load double, ptr %426, align 8
  %428 = fmul double %425, %427
  %429 = fadd double %423, %428
  store double %429, ptr %391, align 8
  %430 = or disjoint i64 %393, 6
  %gep17.i.6 = getelementptr double, ptr %invariant.gep16.i, i64 %430
  %431 = load double, ptr %gep17.i.6, align 8
  %432 = getelementptr double, ptr %7, i64 %430
  %433 = load double, ptr %432, align 8
  %434 = fmul double %431, %433
  %435 = fadd double %429, %434
  store double %435, ptr %391, align 8
  %436 = or disjoint i64 %393, 7
  %gep17.i.7 = getelementptr double, ptr %invariant.gep16.i, i64 %436
  %437 = load double, ptr %gep17.i.7, align 8
  %438 = getelementptr double, ptr %7, i64 %436
  %439 = load double, ptr %438, align 8
  %440 = fmul double %437, %439
  %441 = fadd double %435, %440
  store double %441, ptr %391, align 8
  %442 = add nuw nsw i64 %393, 8
  %exitcond.3.1.not.i.7 = icmp eq i64 %442, 64
  br i1 %exitcond.3.1.not.i.7, label %kernel.exit, label %392

kernel.exit:                                      ; preds = %392
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  tail call void @_mlir_ciface_kernel(ptr %3, ptr %6, ptr %9)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
