; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %13, i8 0, i64 64, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %17, %.preheader
  %18 = phi i64 [ 0, %17 ], [ %50, %.preheader ]
  %19 = phi <8 x double> [ zeroinitializer, %17 ], [ %49, %.preheader ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 64
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 128
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 192
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %20, i64 256
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %20, i64 320
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %20, i64 384
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %20, i64 448
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %18
  %37 = load double, ptr %36, align 8
  %38 = insertelement <8 x double> poison, double %21, i64 0
  %39 = insertelement <8 x double> %38, double %23, i64 1
  %40 = insertelement <8 x double> %39, double %25, i64 2
  %41 = insertelement <8 x double> %40, double %27, i64 3
  %42 = insertelement <8 x double> %41, double %29, i64 4
  %43 = insertelement <8 x double> %42, double %31, i64 5
  %44 = insertelement <8 x double> %43, double %33, i64 6
  %45 = insertelement <8 x double> %44, double %35, i64 7
  %46 = insertelement <8 x double> poison, double %37, i64 0
  %47 = shufflevector <8 x double> %46, <8 x double> poison, <8 x i32> zeroinitializer
  %48 = fmul <8 x double> %45, %47
  %49 = fadd <8 x double> %19, %48
  store <8 x double> %49, ptr %13, align 8
  %50 = add nuw nsw i64 %18, 1
  %exitcond.not = icmp eq i64 %50, 64
  br i1 %exitcond.not, label %51, label %.preheader

51:                                               ; preds = %.preheader
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28, i8 0, i64 64, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %3
  %4 = phi i64 [ 0, %3 ], [ %36, %.preheader.i ]
  %5 = phi <8 x double> [ zeroinitializer, %3 ], [ %35, %.preheader.i ]
  %6 = getelementptr double, ptr %.unpack2, i64 %4
  %7 = load double, ptr %6, align 8
  %8 = getelementptr double, ptr %6, i64 64
  %9 = load double, ptr %8, align 8
  %10 = getelementptr double, ptr %6, i64 128
  %11 = load double, ptr %10, align 8
  %12 = getelementptr double, ptr %6, i64 192
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %6, i64 256
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %6, i64 320
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %6, i64 384
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %6, i64 448
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %.unpack17, i64 %4
  %23 = load double, ptr %22, align 8
  %24 = insertelement <8 x double> poison, double %7, i64 0
  %25 = insertelement <8 x double> %24, double %9, i64 1
  %26 = insertelement <8 x double> %25, double %11, i64 2
  %27 = insertelement <8 x double> %26, double %13, i64 3
  %28 = insertelement <8 x double> %27, double %15, i64 4
  %29 = insertelement <8 x double> %28, double %17, i64 5
  %30 = insertelement <8 x double> %29, double %19, i64 6
  %31 = insertelement <8 x double> %30, double %21, i64 7
  %32 = insertelement <8 x double> poison, double %23, i64 0
  %33 = shufflevector <8 x double> %32, <8 x double> poison, <8 x i32> zeroinitializer
  %34 = fmul <8 x double> %31, %33
  %35 = fadd <8 x double> %5, %34
  store <8 x double> %35, ptr %.unpack28, align 8
  %36 = add nuw nsw i64 %4, 1
  %exitcond.not.i = icmp eq i64 %36, 64
  br i1 %exitcond.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %.preheader.i
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %10, i8 0, i64 64, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %1
  %11 = phi i64 [ 0, %1 ], [ %43, %.preheader.i ]
  %12 = phi <8 x double> [ zeroinitializer, %1 ], [ %42, %.preheader.i ]
  %13 = getelementptr double, ptr %4, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 64
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 128
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 192
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %13, i64 256
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %13, i64 320
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %13, i64 384
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %13, i64 448
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %7, i64 %11
  %30 = load double, ptr %29, align 8
  %31 = insertelement <8 x double> poison, double %14, i64 0
  %32 = insertelement <8 x double> %31, double %16, i64 1
  %33 = insertelement <8 x double> %32, double %18, i64 2
  %34 = insertelement <8 x double> %33, double %20, i64 3
  %35 = insertelement <8 x double> %34, double %22, i64 4
  %36 = insertelement <8 x double> %35, double %24, i64 5
  %37 = insertelement <8 x double> %36, double %26, i64 6
  %38 = insertelement <8 x double> %37, double %28, i64 7
  %39 = insertelement <8 x double> poison, double %30, i64 0
  %40 = shufflevector <8 x double> %39, <8 x double> poison, <8 x i32> zeroinitializer
  %41 = fmul <8 x double> %38, %40
  %42 = fadd <8 x double> %12, %41
  store <8 x double> %42, ptr %10, align 8
  %43 = add nuw nsw i64 %11, 1
  %exitcond.not.i = icmp eq i64 %43, 64
  br i1 %exitcond.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %.preheader.i
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64) %.unpack28.i, i8 0, i64 64, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %.preheader.i.i, %1
  %10 = phi i64 [ 0, %1 ], [ %42, %.preheader.i.i ]
  %11 = phi <8 x double> [ zeroinitializer, %1 ], [ %41, %.preheader.i.i ]
  %12 = getelementptr double, ptr %.unpack2.i, i64 %10
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %12, i64 64
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %12, i64 128
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %12, i64 192
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %12, i64 256
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %12, i64 320
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %12, i64 384
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %12, i64 448
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %.unpack17.i, i64 %10
  %29 = load double, ptr %28, align 8
  %30 = insertelement <8 x double> poison, double %13, i64 0
  %31 = insertelement <8 x double> %30, double %15, i64 1
  %32 = insertelement <8 x double> %31, double %17, i64 2
  %33 = insertelement <8 x double> %32, double %19, i64 3
  %34 = insertelement <8 x double> %33, double %21, i64 4
  %35 = insertelement <8 x double> %34, double %23, i64 5
  %36 = insertelement <8 x double> %35, double %25, i64 6
  %37 = insertelement <8 x double> %36, double %27, i64 7
  %38 = insertelement <8 x double> poison, double %29, i64 0
  %39 = shufflevector <8 x double> %38, <8 x double> poison, <8 x i32> zeroinitializer
  %40 = fmul <8 x double> %37, %39
  %41 = fadd <8 x double> %11, %40
  store <8 x double> %41, ptr %.unpack28.i, align 8
  %42 = add nuw nsw i64 %10, 1
  %exitcond.not.i.i = icmp eq i64 %42, 64
  br i1 %exitcond.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader.i.i

_mlir_ciface_kernel.exit:                         ; preds = %.preheader.i.i
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
