module {
  llvm.func @kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: i64, %arg3: i64, %arg4: i64, %arg5: i64, %arg6: i64, %arg7: !llvm.ptr, %arg8: !llvm.ptr, %arg9: i64, %arg10: i64, %arg11: i64, %arg12: !llvm.ptr, %arg13: !llvm.ptr, %arg14: i64, %arg15: i64, %arg16: i64) attributes {llvm.emit_c_interface} {
    %0 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.insertvalue %arg0, %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.insertvalue %arg1, %1[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.insertvalue %arg2, %2[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.insertvalue %arg3, %3[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.insertvalue %arg5, %4[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.insertvalue %arg4, %5[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.insertvalue %arg6, %6[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.insertvalue %arg7, %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.insertvalue %arg8, %9[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.insertvalue %arg9, %10[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.insertvalue %arg10, %11[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.insertvalue %arg11, %12[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.insertvalue %arg12, %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.insertvalue %arg13, %15[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.insertvalue %arg14, %16[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.insertvalue %arg15, %17[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.insertvalue %arg16, %18[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %20 = llvm.mlir.constant(dense<0.000000e+00> : vector<1x8xf64>) : !llvm.array<1 x vector<8xf64>>
    %21 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x1xf64>) : !llvm.array<8 x vector<1xf64>>
    %22 = llvm.mlir.constant(64 : index) : i64
    %23 = llvm.mlir.constant(0 : index) : i64
    %24 = llvm.mlir.constant(1 : index) : i64
    %25 = llvm.mlir.constant(0.000000e+00 : f64) : f64
    %26 = llvm.mlir.constant(8 : index) : i64
    llvm.br ^bb1(%23 : i64)
  ^bb1(%27: i64):  // 2 preds: ^bb0, ^bb2
    %28 = llvm.icmp "slt" %27, %26 : i64
    llvm.cond_br %28, ^bb2, ^bb3
  ^bb2:  // pred: ^bb1
    %29 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %30 = llvm.getelementptr %29[%27] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %25, %30 : f64, !llvm.ptr
    %31 = llvm.add %27, %24  : i64
    llvm.br ^bb1(%31 : i64)
  ^bb3:  // pred: ^bb1
    %32 = llvm.mlir.constant(1 : index) : i64
    %33 = llvm.alloca %32 x !llvm.array<8 x vector<1xf64>> : (i64) -> !llvm.ptr
    %34 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %35 = llvm.insertvalue %33, %34[0] : !llvm.struct<(ptr, ptr, i64)> 
    %36 = llvm.insertvalue %33, %35[1] : !llvm.struct<(ptr, ptr, i64)> 
    %37 = llvm.mlir.constant(0 : index) : i64
    %38 = llvm.insertvalue %37, %36[2] : !llvm.struct<(ptr, ptr, i64)> 
    llvm.br ^bb4(%23 : i64)
  ^bb4(%39: i64):  // 2 preds: ^bb3, ^bb8
    %40 = llvm.icmp "slt" %39, %22 : i64
    llvm.cond_br %40, ^bb5, ^bb9
  ^bb5:  // pred: ^bb4
    %41 = llvm.extractvalue %7[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %42 = llvm.extractvalue %7[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %43 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %44 = llvm.insertvalue %41, %43[0] : !llvm.struct<(ptr, ptr, i64)> 
    %45 = llvm.insertvalue %42, %44[1] : !llvm.struct<(ptr, ptr, i64)> 
    %46 = llvm.mlir.constant(0 : index) : i64
    %47 = llvm.insertvalue %46, %45[2] : !llvm.struct<(ptr, ptr, i64)> 
    %48 = llvm.extractvalue %7[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %49 = llvm.extractvalue %7[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %50 = llvm.extractvalue %7[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %51 = llvm.extractvalue %7[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %52 = llvm.extractvalue %7[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %53 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %54 = llvm.insertvalue %41, %53[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %55 = llvm.insertvalue %42, %54[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %56 = llvm.insertvalue %39, %55[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %57 = llvm.mlir.constant(8 : index) : i64
    %58 = llvm.insertvalue %57, %56[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %59 = llvm.mlir.constant(64 : index) : i64
    %60 = llvm.insertvalue %59, %58[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %61 = llvm.mlir.constant(1 : index) : i64
    %62 = llvm.insertvalue %61, %60[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %63 = llvm.mlir.constant(1 : index) : i64
    %64 = llvm.insertvalue %63, %62[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %65 = llvm.extractvalue %13[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %66 = llvm.extractvalue %13[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %67 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64)>
    %68 = llvm.insertvalue %65, %67[0] : !llvm.struct<(ptr, ptr, i64)> 
    %69 = llvm.insertvalue %66, %68[1] : !llvm.struct<(ptr, ptr, i64)> 
    %70 = llvm.mlir.constant(0 : index) : i64
    %71 = llvm.insertvalue %70, %69[2] : !llvm.struct<(ptr, ptr, i64)> 
    %72 = llvm.extractvalue %13[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %73 = llvm.extractvalue %13[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %74 = llvm.extractvalue %13[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %75 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %76 = llvm.insertvalue %65, %75[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %77 = llvm.insertvalue %66, %76[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %78 = llvm.insertvalue %39, %77[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %79 = llvm.mlir.constant(1 : index) : i64
    %80 = llvm.insertvalue %79, %78[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %81 = llvm.mlir.constant(1 : index) : i64
    %82 = llvm.insertvalue %81, %80[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %83 = llvm.mlir.undef : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %84 = llvm.extractvalue %38[0] : !llvm.struct<(ptr, ptr, i64)> 
    %85 = llvm.insertvalue %84, %83[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %86 = llvm.extractvalue %38[1] : !llvm.struct<(ptr, ptr, i64)> 
    %87 = llvm.insertvalue %86, %85[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %88 = llvm.mlir.constant(0 : index) : i64
    %89 = llvm.insertvalue %88, %87[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %90 = llvm.mlir.constant(8 : index) : i64
    %91 = llvm.insertvalue %90, %89[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %92 = llvm.mlir.constant(1 : index) : i64
    %93 = llvm.insertvalue %92, %91[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.br ^bb6(%23 : i64)
  ^bb6(%94: i64):  // 2 preds: ^bb5, ^bb7
    %95 = llvm.icmp "slt" %94, %26 : i64
    llvm.cond_br %95, ^bb7, ^bb8
  ^bb7:  // pred: ^bb6
    %96 = llvm.getelementptr %42[%39] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %97 = llvm.mlir.constant(64 : index) : i64
    %98 = llvm.mul %94, %97  : i64
    %99 = llvm.add %98, %23  : i64
    %100 = llvm.getelementptr %96[%99] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %101 = llvm.load %100 : !llvm.ptr -> f64
    %102 = llvm.mlir.undef : vector<1xf64>
    %103 = llvm.mlir.constant(0 : i32) : i32
    %104 = llvm.insertelement %101, %102[%103 : i32] : vector<1xf64>
    %105 = llvm.shufflevector %104, %102 [0] : vector<1xf64> 
    %106 = llvm.getelementptr %86[%94] : (!llvm.ptr, i64) -> !llvm.ptr, vector<1xf64>
    llvm.store %105, %106 : vector<1xf64>, !llvm.ptr
    %107 = llvm.add %94, %24  : i64
    llvm.br ^bb6(%107 : i64)
  ^bb8:  // pred: ^bb6
    %108 = llvm.load %33 : !llvm.ptr -> !llvm.array<8 x vector<1xf64>>
    %109 = llvm.getelementptr %66[%39] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %110 = llvm.getelementptr %109[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %111 = llvm.load %110 : !llvm.ptr -> f64
    %112 = llvm.mlir.undef : vector<1xf64>
    %113 = llvm.mlir.constant(0 : i32) : i32
    %114 = llvm.insertelement %111, %112[%113 : i32] : vector<1xf64>
    %115 = llvm.shufflevector %114, %112 [0] : vector<1xf64> 
    %116 = llvm.insertvalue %115, %21[0] : !llvm.array<8 x vector<1xf64>> 
    %117 = llvm.insertvalue %115, %116[1] : !llvm.array<8 x vector<1xf64>> 
    %118 = llvm.insertvalue %115, %117[2] : !llvm.array<8 x vector<1xf64>> 
    %119 = llvm.insertvalue %115, %118[3] : !llvm.array<8 x vector<1xf64>> 
    %120 = llvm.insertvalue %115, %119[4] : !llvm.array<8 x vector<1xf64>> 
    %121 = llvm.insertvalue %115, %120[5] : !llvm.array<8 x vector<1xf64>> 
    %122 = llvm.insertvalue %115, %121[6] : !llvm.array<8 x vector<1xf64>> 
    %123 = llvm.insertvalue %115, %122[7] : !llvm.array<8 x vector<1xf64>> 
    %124 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %125 = llvm.getelementptr %124[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    %126 = llvm.load %125 {alignment = 8 : i64} : !llvm.ptr -> vector<8xf64>
    %127 = llvm.mlir.undef : !llvm.array<8 x vector<1xf64>>
    %128 = llvm.extractvalue %108[0] : !llvm.array<8 x vector<1xf64>> 
    %129 = llvm.fmul %128, %115  : vector<1xf64>
    %130 = llvm.insertvalue %129, %127[0] : !llvm.array<8 x vector<1xf64>> 
    %131 = llvm.extractvalue %108[1] : !llvm.array<8 x vector<1xf64>> 
    %132 = llvm.fmul %131, %115  : vector<1xf64>
    %133 = llvm.insertvalue %132, %130[1] : !llvm.array<8 x vector<1xf64>> 
    %134 = llvm.extractvalue %108[2] : !llvm.array<8 x vector<1xf64>> 
    %135 = llvm.fmul %134, %115  : vector<1xf64>
    %136 = llvm.insertvalue %135, %133[2] : !llvm.array<8 x vector<1xf64>> 
    %137 = llvm.extractvalue %108[3] : !llvm.array<8 x vector<1xf64>> 
    %138 = llvm.fmul %137, %115  : vector<1xf64>
    %139 = llvm.insertvalue %138, %136[3] : !llvm.array<8 x vector<1xf64>> 
    %140 = llvm.extractvalue %108[4] : !llvm.array<8 x vector<1xf64>> 
    %141 = llvm.fmul %140, %115  : vector<1xf64>
    %142 = llvm.insertvalue %141, %139[4] : !llvm.array<8 x vector<1xf64>> 
    %143 = llvm.extractvalue %108[5] : !llvm.array<8 x vector<1xf64>> 
    %144 = llvm.fmul %143, %115  : vector<1xf64>
    %145 = llvm.insertvalue %144, %142[5] : !llvm.array<8 x vector<1xf64>> 
    %146 = llvm.extractvalue %108[6] : !llvm.array<8 x vector<1xf64>> 
    %147 = llvm.fmul %146, %115  : vector<1xf64>
    %148 = llvm.insertvalue %147, %145[6] : !llvm.array<8 x vector<1xf64>> 
    %149 = llvm.extractvalue %108[7] : !llvm.array<8 x vector<1xf64>> 
    %150 = llvm.fmul %149, %115  : vector<1xf64>
    %151 = llvm.insertvalue %150, %148[7] : !llvm.array<8 x vector<1xf64>> 
    %152 = llvm.extractvalue %151[0] : !llvm.array<8 x vector<1xf64>> 
    %153 = llvm.mlir.constant(0 : i64) : i64
    %154 = llvm.extractelement %152[%153 : i64] : vector<1xf64>
    %155 = llvm.extractvalue %20[0] : !llvm.array<1 x vector<8xf64>> 
    %156 = llvm.mlir.constant(0 : i64) : i64
    %157 = llvm.insertelement %154, %155[%156 : i64] : vector<8xf64>
    %158 = llvm.insertvalue %157, %20[0] : !llvm.array<1 x vector<8xf64>> 
    %159 = llvm.extractvalue %151[1] : !llvm.array<8 x vector<1xf64>> 
    %160 = llvm.mlir.constant(0 : i64) : i64
    %161 = llvm.extractelement %159[%160 : i64] : vector<1xf64>
    %162 = llvm.mlir.constant(1 : i64) : i64
    %163 = llvm.insertelement %161, %157[%162 : i64] : vector<8xf64>
    %164 = llvm.insertvalue %163, %158[0] : !llvm.array<1 x vector<8xf64>> 
    %165 = llvm.extractvalue %151[2] : !llvm.array<8 x vector<1xf64>> 
    %166 = llvm.mlir.constant(0 : i64) : i64
    %167 = llvm.extractelement %165[%166 : i64] : vector<1xf64>
    %168 = llvm.mlir.constant(2 : i64) : i64
    %169 = llvm.insertelement %167, %163[%168 : i64] : vector<8xf64>
    %170 = llvm.insertvalue %169, %164[0] : !llvm.array<1 x vector<8xf64>> 
    %171 = llvm.extractvalue %151[3] : !llvm.array<8 x vector<1xf64>> 
    %172 = llvm.mlir.constant(0 : i64) : i64
    %173 = llvm.extractelement %171[%172 : i64] : vector<1xf64>
    %174 = llvm.mlir.constant(3 : i64) : i64
    %175 = llvm.insertelement %173, %169[%174 : i64] : vector<8xf64>
    %176 = llvm.insertvalue %175, %170[0] : !llvm.array<1 x vector<8xf64>> 
    %177 = llvm.extractvalue %151[4] : !llvm.array<8 x vector<1xf64>> 
    %178 = llvm.mlir.constant(0 : i64) : i64
    %179 = llvm.extractelement %177[%178 : i64] : vector<1xf64>
    %180 = llvm.mlir.constant(4 : i64) : i64
    %181 = llvm.insertelement %179, %175[%180 : i64] : vector<8xf64>
    %182 = llvm.insertvalue %181, %176[0] : !llvm.array<1 x vector<8xf64>> 
    %183 = llvm.extractvalue %151[5] : !llvm.array<8 x vector<1xf64>> 
    %184 = llvm.mlir.constant(0 : i64) : i64
    %185 = llvm.extractelement %183[%184 : i64] : vector<1xf64>
    %186 = llvm.mlir.constant(5 : i64) : i64
    %187 = llvm.insertelement %185, %181[%186 : i64] : vector<8xf64>
    %188 = llvm.insertvalue %187, %182[0] : !llvm.array<1 x vector<8xf64>> 
    %189 = llvm.extractvalue %151[6] : !llvm.array<8 x vector<1xf64>> 
    %190 = llvm.mlir.constant(0 : i64) : i64
    %191 = llvm.extractelement %189[%190 : i64] : vector<1xf64>
    %192 = llvm.mlir.constant(6 : i64) : i64
    %193 = llvm.insertelement %191, %187[%192 : i64] : vector<8xf64>
    %194 = llvm.insertvalue %193, %188[0] : !llvm.array<1 x vector<8xf64>> 
    %195 = llvm.extractvalue %151[7] : !llvm.array<8 x vector<1xf64>> 
    %196 = llvm.mlir.constant(0 : i64) : i64
    %197 = llvm.extractelement %195[%196 : i64] : vector<1xf64>
    %198 = llvm.mlir.constant(7 : i64) : i64
    %199 = llvm.insertelement %197, %193[%198 : i64] : vector<8xf64>
    %200 = llvm.insertvalue %199, %194[0] : !llvm.array<1 x vector<8xf64>> 
    %201 = llvm.fadd %199, %126  : vector<8xf64>
    %202 = llvm.extractvalue %19[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %203 = llvm.getelementptr %202[%23] : (!llvm.ptr, i64) -> !llvm.ptr, f64
    llvm.store %201, %203 {alignment = 8 : i64} : vector<8xf64>, !llvm.ptr
    %204 = llvm.add %39, %24  : i64
    llvm.br ^bb4(%204 : i64)
  ^bb9:  // pred: ^bb4
    llvm.return
  }
  llvm.func @_mlir_ciface_kernel(%arg0: !llvm.ptr, %arg1: !llvm.ptr, %arg2: !llvm.ptr) attributes {llvm.emit_c_interface} {
    %0 = llvm.load %arg0 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)>
    %1 = llvm.extractvalue %0[0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %2 = llvm.extractvalue %0[1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %3 = llvm.extractvalue %0[2] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %4 = llvm.extractvalue %0[3, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %5 = llvm.extractvalue %0[3, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %6 = llvm.extractvalue %0[4, 0] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %7 = llvm.extractvalue %0[4, 1] : !llvm.struct<(ptr, ptr, i64, array<2 x i64>, array<2 x i64>)> 
    %8 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %9 = llvm.extractvalue %8[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %10 = llvm.extractvalue %8[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %11 = llvm.extractvalue %8[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %12 = llvm.extractvalue %8[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %13 = llvm.extractvalue %8[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %14 = llvm.load %arg2 : !llvm.ptr -> !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)>
    %15 = llvm.extractvalue %14[0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %16 = llvm.extractvalue %14[1] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %17 = llvm.extractvalue %14[2] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %18 = llvm.extractvalue %14[3, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    %19 = llvm.extractvalue %14[4, 0] : !llvm.struct<(ptr, ptr, i64, array<1 x i64>, array<1 x i64>)> 
    llvm.call @kernel(%1, %2, %3, %4, %5, %6, %7, %9, %10, %11, %12, %13, %15, %16, %17, %18, %19) : (!llvm.ptr, !llvm.ptr, i64, i64, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64, !llvm.ptr, !llvm.ptr, i64, i64, i64) -> ()
    llvm.return
  }
}
