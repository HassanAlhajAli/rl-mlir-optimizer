; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 3072
  %scevgep7 = getelementptr i8, ptr %15, i64 32768
  %scevgep8 = getelementptr i8, ptr %1, i64 192
  %scevgep9 = getelementptr i8, ptr %1, i64 2048
  %scevgep10 = getelementptr i8, ptr %8, i64 8192
  %scevgep37 = getelementptr i8, ptr %15, i64 2048
  %scevgep38 = getelementptr i8, ptr %15, i64 31744
  %scevgep39 = getelementptr i8, ptr %1, i64 128
  %scevgep40 = getelementptr i8, ptr %1, i64 1984
  %scevgep81 = getelementptr i8, ptr %15, i64 1024
  %scevgep82 = getelementptr i8, ptr %15, i64 30720
  %scevgep83 = getelementptr i8, ptr %1, i64 64
  %scevgep84 = getelementptr i8, ptr %1, i64 1920
  %scevgep85 = getelementptr i8, ptr %8, i64 8192
  %scevgep126 = getelementptr i8, ptr %15, i64 29696
  %scevgep127 = getelementptr i8, ptr %1, i64 1856
  %bound0128 = icmp ugt ptr %scevgep127, %15
  %bound1129 = icmp ugt ptr %scevgep126, %1
  %found.conflict130 = and i1 %bound0128, %bound1129
  %bound0131 = icmp ugt ptr %scevgep85, %15
  %bound1132 = icmp ugt ptr %scevgep126, %8
  %found.conflict133 = and i1 %bound0131, %bound1132
  %conflict.rdx134 = or i1 %found.conflict130, %found.conflict133
  %bound086 = icmp ult ptr %scevgep81, %scevgep84
  %bound187 = icmp ult ptr %scevgep83, %scevgep82
  %found.conflict88 = and i1 %bound086, %bound187
  %bound089 = icmp ult ptr %scevgep81, %scevgep85
  %bound190 = icmp ugt ptr %scevgep82, %8
  %found.conflict91 = and i1 %bound089, %bound190
  %conflict.rdx92 = or i1 %found.conflict88, %found.conflict91
  %bound041 = icmp ult ptr %scevgep37, %scevgep40
  %bound142 = icmp ult ptr %scevgep39, %scevgep38
  %found.conflict43 = and i1 %bound041, %bound142
  %bound044 = icmp ult ptr %scevgep37, %scevgep10
  %bound145 = icmp ugt ptr %scevgep38, %8
  %found.conflict46 = and i1 %bound044, %bound145
  %conflict.rdx47 = or i1 %found.conflict43, %found.conflict46
  %bound0 = icmp ult ptr %scevgep, %scevgep9
  %bound1 = icmp ult ptr %scevgep8, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %middle.block
  %21 = phi i64 [ %336, %middle.block ], [ 0, %.preheader4.preheader ]
  %22 = shl nuw nsw i64 %21, 3
  %23 = shl nuw nsw i64 %21, 7
  %24 = getelementptr double, ptr %1, i64 %22
  %25 = getelementptr double, ptr %15, i64 %23
  %26 = getelementptr double, ptr %24, i64 1
  %27 = getelementptr double, ptr %24, i64 2
  %28 = getelementptr double, ptr %24, i64 3
  %29 = getelementptr double, ptr %24, i64 4
  %30 = getelementptr double, ptr %24, i64 5
  %31 = getelementptr double, ptr %24, i64 6
  %32 = getelementptr double, ptr %24, i64 7
  br i1 %conflict.rdx134, label %.preheader, label %vector.body139.preheader

vector.body139.preheader:                         ; preds = %.preheader4
  %33 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert143 = insertelement <4 x double> poison, double %33, i64 0
  %broadcast.splat144 = shufflevector <4 x double> %broadcast.splatinsert143, <4 x double> poison, <4 x i32> zeroinitializer
  %34 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert146 = insertelement <4 x double> poison, double %34, i64 0
  %broadcast.splat147 = shufflevector <4 x double> %broadcast.splatinsert146, <4 x double> poison, <4 x i32> zeroinitializer
  %35 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert149 = insertelement <4 x double> poison, double %35, i64 0
  %broadcast.splat150 = shufflevector <4 x double> %broadcast.splatinsert149, <4 x double> poison, <4 x i32> zeroinitializer
  %36 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert152 = insertelement <4 x double> poison, double %36, i64 0
  %broadcast.splat153 = shufflevector <4 x double> %broadcast.splatinsert152, <4 x double> poison, <4 x i32> zeroinitializer
  %37 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert155 = insertelement <4 x double> poison, double %37, i64 0
  %broadcast.splat156 = shufflevector <4 x double> %broadcast.splatinsert155, <4 x double> poison, <4 x i32> zeroinitializer
  %38 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert158 = insertelement <4 x double> poison, double %38, i64 0
  %broadcast.splat159 = shufflevector <4 x double> %broadcast.splatinsert158, <4 x double> poison, <4 x i32> zeroinitializer
  %39 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert161 = insertelement <4 x double> poison, double %39, i64 0
  %broadcast.splat162 = shufflevector <4 x double> %broadcast.splatinsert161, <4 x double> poison, <4 x i32> zeroinitializer
  %40 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert164 = insertelement <4 x double> poison, double %40, i64 0
  %broadcast.splat165 = shufflevector <4 x double> %broadcast.splatinsert164, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body139

vector.body139:                                   ; preds = %vector.body139.preheader, %vector.body139
  %index140 = phi i64 [ %index.next166, %vector.body139 ], [ 0, %vector.body139.preheader ]
  %41 = getelementptr double, ptr %8, i64 %index140
  %42 = getelementptr double, ptr %25, i64 %index140
  %wide.load141 = load <4 x double>, ptr %42, align 8, !alias.scope !4, !noalias !6
  %wide.load142 = load <4 x double>, ptr %41, align 8, !alias.scope !8
  %43 = fmul <4 x double> %broadcast.splat144, %wide.load142
  %44 = fadd <4 x double> %wide.load141, %43
  store <4 x double> %44, ptr %42, align 8, !alias.scope !4, !noalias !6
  %45 = getelementptr double, ptr %41, i64 128
  %wide.load145 = load <4 x double>, ptr %45, align 8, !alias.scope !8
  %46 = fmul <4 x double> %broadcast.splat147, %wide.load145
  %47 = fadd <4 x double> %44, %46
  store <4 x double> %47, ptr %42, align 8, !alias.scope !4, !noalias !6
  %48 = getelementptr double, ptr %41, i64 256
  %wide.load148 = load <4 x double>, ptr %48, align 8, !alias.scope !8
  %49 = fmul <4 x double> %broadcast.splat150, %wide.load148
  %50 = fadd <4 x double> %47, %49
  store <4 x double> %50, ptr %42, align 8, !alias.scope !4, !noalias !6
  %51 = getelementptr double, ptr %41, i64 384
  %wide.load151 = load <4 x double>, ptr %51, align 8, !alias.scope !8
  %52 = fmul <4 x double> %broadcast.splat153, %wide.load151
  %53 = fadd <4 x double> %50, %52
  store <4 x double> %53, ptr %42, align 8, !alias.scope !4, !noalias !6
  %54 = getelementptr double, ptr %41, i64 512
  %wide.load154 = load <4 x double>, ptr %54, align 8, !alias.scope !8
  %55 = fmul <4 x double> %broadcast.splat156, %wide.load154
  %56 = fadd <4 x double> %53, %55
  store <4 x double> %56, ptr %42, align 8, !alias.scope !4, !noalias !6
  %57 = getelementptr double, ptr %41, i64 640
  %wide.load157 = load <4 x double>, ptr %57, align 8, !alias.scope !8
  %58 = fmul <4 x double> %broadcast.splat159, %wide.load157
  %59 = fadd <4 x double> %56, %58
  store <4 x double> %59, ptr %42, align 8, !alias.scope !4, !noalias !6
  %60 = getelementptr double, ptr %41, i64 768
  %wide.load160 = load <4 x double>, ptr %60, align 8, !alias.scope !8
  %61 = fmul <4 x double> %broadcast.splat162, %wide.load160
  %62 = fadd <4 x double> %59, %61
  store <4 x double> %62, ptr %42, align 8, !alias.scope !4, !noalias !6
  %63 = getelementptr double, ptr %41, i64 896
  %wide.load163 = load <4 x double>, ptr %63, align 8, !alias.scope !8
  %64 = fmul <4 x double> %broadcast.splat165, %wide.load163
  %65 = fadd <4 x double> %62, %64
  store <4 x double> %65, ptr %42, align 8, !alias.scope !4, !noalias !6
  %index.next166 = add nuw i64 %index140, 4
  %66 = icmp eq i64 %index.next166, 128
  br i1 %66, label %.preheader3.1, label %vector.body139, !llvm.loop !9

.preheader:                                       ; preds = %.preheader4, %.preheader
  %67 = phi i64 [ %101, %.preheader ], [ 0, %.preheader4 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %67
  %68 = getelementptr double, ptr %25, i64 %67
  %.promoted = load double, ptr %68, align 8
  %69 = load double, ptr %24, align 8
  %70 = load double, ptr %invariant.gep, align 8
  %71 = fmul double %69, %70
  %72 = fadd double %.promoted, %71
  store double %72, ptr %68, align 8
  %73 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 128
  %74 = load double, ptr %gep.1, align 8
  %75 = fmul double %73, %74
  %76 = fadd double %72, %75
  store double %76, ptr %68, align 8
  %77 = load double, ptr %27, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 256
  %78 = load double, ptr %gep.2, align 8
  %79 = fmul double %77, %78
  %80 = fadd double %76, %79
  store double %80, ptr %68, align 8
  %81 = load double, ptr %28, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 384
  %82 = load double, ptr %gep.3, align 8
  %83 = fmul double %81, %82
  %84 = fadd double %80, %83
  store double %84, ptr %68, align 8
  %85 = load double, ptr %29, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 512
  %86 = load double, ptr %gep.4, align 8
  %87 = fmul double %85, %86
  %88 = fadd double %84, %87
  store double %88, ptr %68, align 8
  %89 = load double, ptr %30, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 640
  %90 = load double, ptr %gep.5, align 8
  %91 = fmul double %89, %90
  %92 = fadd double %88, %91
  store double %92, ptr %68, align 8
  %93 = load double, ptr %31, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 768
  %94 = load double, ptr %gep.6, align 8
  %95 = fmul double %93, %94
  %96 = fadd double %92, %95
  store double %96, ptr %68, align 8
  %97 = load double, ptr %32, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 896
  %98 = load double, ptr %gep.7, align 8
  %99 = fmul double %97, %98
  %100 = fadd double %96, %99
  store double %100, ptr %68, align 8
  %101 = add nuw nsw i64 %67, 1
  %exitcond.not = icmp eq i64 %101, 128
  br i1 %exitcond.not, label %.preheader3.1, label %.preheader, !llvm.loop !12

.preheader3.1:                                    ; preds = %vector.body139, %.preheader
  %102 = getelementptr double, ptr %25, i64 128
  %103 = getelementptr double, ptr %24, i64 8
  %104 = getelementptr double, ptr %24, i64 9
  %105 = getelementptr double, ptr %24, i64 10
  %106 = getelementptr double, ptr %24, i64 11
  %107 = getelementptr double, ptr %24, i64 12
  %108 = getelementptr double, ptr %24, i64 13
  %109 = getelementptr double, ptr %24, i64 14
  %110 = getelementptr double, ptr %24, i64 15
  br i1 %conflict.rdx92, label %.preheader.1, label %vector.body97.preheader

vector.body97.preheader:                          ; preds = %.preheader3.1
  %111 = load double, ptr %103, align 8, !alias.scope !13
  %broadcast.splatinsert101 = insertelement <4 x double> poison, double %111, i64 0
  %broadcast.splat102 = shufflevector <4 x double> %broadcast.splatinsert101, <4 x double> poison, <4 x i32> zeroinitializer
  %112 = load double, ptr %104, align 8, !alias.scope !13
  %broadcast.splatinsert104 = insertelement <4 x double> poison, double %112, i64 0
  %broadcast.splat105 = shufflevector <4 x double> %broadcast.splatinsert104, <4 x double> poison, <4 x i32> zeroinitializer
  %113 = load double, ptr %105, align 8, !alias.scope !13
  %broadcast.splatinsert107 = insertelement <4 x double> poison, double %113, i64 0
  %broadcast.splat108 = shufflevector <4 x double> %broadcast.splatinsert107, <4 x double> poison, <4 x i32> zeroinitializer
  %114 = load double, ptr %106, align 8, !alias.scope !13
  %broadcast.splatinsert110 = insertelement <4 x double> poison, double %114, i64 0
  %broadcast.splat111 = shufflevector <4 x double> %broadcast.splatinsert110, <4 x double> poison, <4 x i32> zeroinitializer
  %115 = load double, ptr %107, align 8, !alias.scope !13
  %broadcast.splatinsert113 = insertelement <4 x double> poison, double %115, i64 0
  %broadcast.splat114 = shufflevector <4 x double> %broadcast.splatinsert113, <4 x double> poison, <4 x i32> zeroinitializer
  %116 = load double, ptr %108, align 8, !alias.scope !13
  %broadcast.splatinsert116 = insertelement <4 x double> poison, double %116, i64 0
  %broadcast.splat117 = shufflevector <4 x double> %broadcast.splatinsert116, <4 x double> poison, <4 x i32> zeroinitializer
  %117 = load double, ptr %109, align 8, !alias.scope !13
  %broadcast.splatinsert119 = insertelement <4 x double> poison, double %117, i64 0
  %broadcast.splat120 = shufflevector <4 x double> %broadcast.splatinsert119, <4 x double> poison, <4 x i32> zeroinitializer
  %118 = load double, ptr %110, align 8, !alias.scope !13
  %broadcast.splatinsert122 = insertelement <4 x double> poison, double %118, i64 0
  %broadcast.splat123 = shufflevector <4 x double> %broadcast.splatinsert122, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body97

vector.body97:                                    ; preds = %vector.body97.preheader, %vector.body97
  %index98 = phi i64 [ %index.next124, %vector.body97 ], [ 0, %vector.body97.preheader ]
  %119 = getelementptr double, ptr %8, i64 %index98
  %120 = getelementptr double, ptr %102, i64 %index98
  %wide.load99 = load <4 x double>, ptr %120, align 8, !alias.scope !16, !noalias !18
  %wide.load100 = load <4 x double>, ptr %119, align 8, !alias.scope !20
  %121 = fmul <4 x double> %broadcast.splat102, %wide.load100
  %122 = fadd <4 x double> %wide.load99, %121
  store <4 x double> %122, ptr %120, align 8, !alias.scope !16, !noalias !18
  %123 = getelementptr double, ptr %119, i64 128
  %wide.load103 = load <4 x double>, ptr %123, align 8, !alias.scope !20
  %124 = fmul <4 x double> %broadcast.splat105, %wide.load103
  %125 = fadd <4 x double> %122, %124
  store <4 x double> %125, ptr %120, align 8, !alias.scope !16, !noalias !18
  %126 = getelementptr double, ptr %119, i64 256
  %wide.load106 = load <4 x double>, ptr %126, align 8, !alias.scope !20
  %127 = fmul <4 x double> %broadcast.splat108, %wide.load106
  %128 = fadd <4 x double> %125, %127
  store <4 x double> %128, ptr %120, align 8, !alias.scope !16, !noalias !18
  %129 = getelementptr double, ptr %119, i64 384
  %wide.load109 = load <4 x double>, ptr %129, align 8, !alias.scope !20
  %130 = fmul <4 x double> %broadcast.splat111, %wide.load109
  %131 = fadd <4 x double> %128, %130
  store <4 x double> %131, ptr %120, align 8, !alias.scope !16, !noalias !18
  %132 = getelementptr double, ptr %119, i64 512
  %wide.load112 = load <4 x double>, ptr %132, align 8, !alias.scope !20
  %133 = fmul <4 x double> %broadcast.splat114, %wide.load112
  %134 = fadd <4 x double> %131, %133
  store <4 x double> %134, ptr %120, align 8, !alias.scope !16, !noalias !18
  %135 = getelementptr double, ptr %119, i64 640
  %wide.load115 = load <4 x double>, ptr %135, align 8, !alias.scope !20
  %136 = fmul <4 x double> %broadcast.splat117, %wide.load115
  %137 = fadd <4 x double> %134, %136
  store <4 x double> %137, ptr %120, align 8, !alias.scope !16, !noalias !18
  %138 = getelementptr double, ptr %119, i64 768
  %wide.load118 = load <4 x double>, ptr %138, align 8, !alias.scope !20
  %139 = fmul <4 x double> %broadcast.splat120, %wide.load118
  %140 = fadd <4 x double> %137, %139
  store <4 x double> %140, ptr %120, align 8, !alias.scope !16, !noalias !18
  %141 = getelementptr double, ptr %119, i64 896
  %wide.load121 = load <4 x double>, ptr %141, align 8, !alias.scope !20
  %142 = fmul <4 x double> %broadcast.splat123, %wide.load121
  %143 = fadd <4 x double> %140, %142
  store <4 x double> %143, ptr %120, align 8, !alias.scope !16, !noalias !18
  %index.next124 = add nuw i64 %index98, 4
  %144 = icmp eq i64 %index.next124, 128
  br i1 %144, label %.preheader3.2, label %vector.body97, !llvm.loop !21

.preheader.1:                                     ; preds = %.preheader3.1, %.preheader.1
  %145 = phi i64 [ %179, %.preheader.1 ], [ 0, %.preheader3.1 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %145
  %146 = getelementptr double, ptr %102, i64 %145
  %.promoted.1 = load double, ptr %146, align 8
  %147 = load double, ptr %103, align 8
  %148 = load double, ptr %invariant.gep.1, align 8
  %149 = fmul double %147, %148
  %150 = fadd double %.promoted.1, %149
  store double %150, ptr %146, align 8
  %151 = load double, ptr %104, align 8
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 128
  %152 = load double, ptr %gep.1.1, align 8
  %153 = fmul double %151, %152
  %154 = fadd double %150, %153
  store double %154, ptr %146, align 8
  %155 = load double, ptr %105, align 8
  %gep.2.1 = getelementptr double, ptr %invariant.gep.1, i64 256
  %156 = load double, ptr %gep.2.1, align 8
  %157 = fmul double %155, %156
  %158 = fadd double %154, %157
  store double %158, ptr %146, align 8
  %159 = load double, ptr %106, align 8
  %gep.3.1 = getelementptr double, ptr %invariant.gep.1, i64 384
  %160 = load double, ptr %gep.3.1, align 8
  %161 = fmul double %159, %160
  %162 = fadd double %158, %161
  store double %162, ptr %146, align 8
  %163 = load double, ptr %107, align 8
  %gep.4.1 = getelementptr double, ptr %invariant.gep.1, i64 512
  %164 = load double, ptr %gep.4.1, align 8
  %165 = fmul double %163, %164
  %166 = fadd double %162, %165
  store double %166, ptr %146, align 8
  %167 = load double, ptr %108, align 8
  %gep.5.1 = getelementptr double, ptr %invariant.gep.1, i64 640
  %168 = load double, ptr %gep.5.1, align 8
  %169 = fmul double %167, %168
  %170 = fadd double %166, %169
  store double %170, ptr %146, align 8
  %171 = load double, ptr %109, align 8
  %gep.6.1 = getelementptr double, ptr %invariant.gep.1, i64 768
  %172 = load double, ptr %gep.6.1, align 8
  %173 = fmul double %171, %172
  %174 = fadd double %170, %173
  store double %174, ptr %146, align 8
  %175 = load double, ptr %110, align 8
  %gep.7.1 = getelementptr double, ptr %invariant.gep.1, i64 896
  %176 = load double, ptr %gep.7.1, align 8
  %177 = fmul double %175, %176
  %178 = fadd double %174, %177
  store double %178, ptr %146, align 8
  %179 = add nuw nsw i64 %145, 1
  %exitcond.1.not = icmp eq i64 %179, 128
  br i1 %exitcond.1.not, label %.preheader3.2, label %.preheader.1, !llvm.loop !22

.preheader3.2:                                    ; preds = %vector.body97, %.preheader.1
  %180 = getelementptr double, ptr %25, i64 256
  %181 = getelementptr double, ptr %24, i64 16
  %182 = getelementptr double, ptr %24, i64 17
  %183 = getelementptr double, ptr %24, i64 18
  %184 = getelementptr double, ptr %24, i64 19
  %185 = getelementptr double, ptr %24, i64 20
  %186 = getelementptr double, ptr %24, i64 21
  %187 = getelementptr double, ptr %24, i64 22
  %188 = getelementptr double, ptr %24, i64 23
  br i1 %conflict.rdx47, label %.preheader.2, label %vector.body52.preheader

vector.body52.preheader:                          ; preds = %.preheader3.2
  %189 = load double, ptr %181, align 8, !alias.scope !23
  %broadcast.splatinsert56 = insertelement <4 x double> poison, double %189, i64 0
  %broadcast.splat57 = shufflevector <4 x double> %broadcast.splatinsert56, <4 x double> poison, <4 x i32> zeroinitializer
  %190 = load double, ptr %182, align 8, !alias.scope !23
  %broadcast.splatinsert59 = insertelement <4 x double> poison, double %190, i64 0
  %broadcast.splat60 = shufflevector <4 x double> %broadcast.splatinsert59, <4 x double> poison, <4 x i32> zeroinitializer
  %191 = load double, ptr %183, align 8, !alias.scope !23
  %broadcast.splatinsert62 = insertelement <4 x double> poison, double %191, i64 0
  %broadcast.splat63 = shufflevector <4 x double> %broadcast.splatinsert62, <4 x double> poison, <4 x i32> zeroinitializer
  %192 = load double, ptr %184, align 8, !alias.scope !23
  %broadcast.splatinsert65 = insertelement <4 x double> poison, double %192, i64 0
  %broadcast.splat66 = shufflevector <4 x double> %broadcast.splatinsert65, <4 x double> poison, <4 x i32> zeroinitializer
  %193 = load double, ptr %185, align 8, !alias.scope !23
  %broadcast.splatinsert68 = insertelement <4 x double> poison, double %193, i64 0
  %broadcast.splat69 = shufflevector <4 x double> %broadcast.splatinsert68, <4 x double> poison, <4 x i32> zeroinitializer
  %194 = load double, ptr %186, align 8, !alias.scope !23
  %broadcast.splatinsert71 = insertelement <4 x double> poison, double %194, i64 0
  %broadcast.splat72 = shufflevector <4 x double> %broadcast.splatinsert71, <4 x double> poison, <4 x i32> zeroinitializer
  %195 = load double, ptr %187, align 8, !alias.scope !23
  %broadcast.splatinsert74 = insertelement <4 x double> poison, double %195, i64 0
  %broadcast.splat75 = shufflevector <4 x double> %broadcast.splatinsert74, <4 x double> poison, <4 x i32> zeroinitializer
  %196 = load double, ptr %188, align 8, !alias.scope !23
  %broadcast.splatinsert77 = insertelement <4 x double> poison, double %196, i64 0
  %broadcast.splat78 = shufflevector <4 x double> %broadcast.splatinsert77, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body52

vector.body52:                                    ; preds = %vector.body52.preheader, %vector.body52
  %index53 = phi i64 [ %index.next79, %vector.body52 ], [ 0, %vector.body52.preheader ]
  %197 = getelementptr double, ptr %8, i64 %index53
  %198 = getelementptr double, ptr %180, i64 %index53
  %wide.load54 = load <4 x double>, ptr %198, align 8, !alias.scope !26, !noalias !28
  %wide.load55 = load <4 x double>, ptr %197, align 8, !alias.scope !30
  %199 = fmul <4 x double> %broadcast.splat57, %wide.load55
  %200 = fadd <4 x double> %wide.load54, %199
  store <4 x double> %200, ptr %198, align 8, !alias.scope !26, !noalias !28
  %201 = getelementptr double, ptr %197, i64 128
  %wide.load58 = load <4 x double>, ptr %201, align 8, !alias.scope !30
  %202 = fmul <4 x double> %broadcast.splat60, %wide.load58
  %203 = fadd <4 x double> %200, %202
  store <4 x double> %203, ptr %198, align 8, !alias.scope !26, !noalias !28
  %204 = getelementptr double, ptr %197, i64 256
  %wide.load61 = load <4 x double>, ptr %204, align 8, !alias.scope !30
  %205 = fmul <4 x double> %broadcast.splat63, %wide.load61
  %206 = fadd <4 x double> %203, %205
  store <4 x double> %206, ptr %198, align 8, !alias.scope !26, !noalias !28
  %207 = getelementptr double, ptr %197, i64 384
  %wide.load64 = load <4 x double>, ptr %207, align 8, !alias.scope !30
  %208 = fmul <4 x double> %broadcast.splat66, %wide.load64
  %209 = fadd <4 x double> %206, %208
  store <4 x double> %209, ptr %198, align 8, !alias.scope !26, !noalias !28
  %210 = getelementptr double, ptr %197, i64 512
  %wide.load67 = load <4 x double>, ptr %210, align 8, !alias.scope !30
  %211 = fmul <4 x double> %broadcast.splat69, %wide.load67
  %212 = fadd <4 x double> %209, %211
  store <4 x double> %212, ptr %198, align 8, !alias.scope !26, !noalias !28
  %213 = getelementptr double, ptr %197, i64 640
  %wide.load70 = load <4 x double>, ptr %213, align 8, !alias.scope !30
  %214 = fmul <4 x double> %broadcast.splat72, %wide.load70
  %215 = fadd <4 x double> %212, %214
  store <4 x double> %215, ptr %198, align 8, !alias.scope !26, !noalias !28
  %216 = getelementptr double, ptr %197, i64 768
  %wide.load73 = load <4 x double>, ptr %216, align 8, !alias.scope !30
  %217 = fmul <4 x double> %broadcast.splat75, %wide.load73
  %218 = fadd <4 x double> %215, %217
  store <4 x double> %218, ptr %198, align 8, !alias.scope !26, !noalias !28
  %219 = getelementptr double, ptr %197, i64 896
  %wide.load76 = load <4 x double>, ptr %219, align 8, !alias.scope !30
  %220 = fmul <4 x double> %broadcast.splat78, %wide.load76
  %221 = fadd <4 x double> %218, %220
  store <4 x double> %221, ptr %198, align 8, !alias.scope !26, !noalias !28
  %index.next79 = add nuw i64 %index53, 4
  %222 = icmp eq i64 %index.next79, 128
  br i1 %222, label %.preheader3.3, label %vector.body52, !llvm.loop !31

.preheader.2:                                     ; preds = %.preheader3.2, %.preheader.2
  %223 = phi i64 [ %257, %.preheader.2 ], [ 0, %.preheader3.2 ]
  %invariant.gep.2 = getelementptr double, ptr %8, i64 %223
  %224 = getelementptr double, ptr %180, i64 %223
  %.promoted.2 = load double, ptr %224, align 8
  %225 = load double, ptr %181, align 8
  %226 = load double, ptr %invariant.gep.2, align 8
  %227 = fmul double %225, %226
  %228 = fadd double %.promoted.2, %227
  store double %228, ptr %224, align 8
  %229 = load double, ptr %182, align 8
  %gep.1.2 = getelementptr double, ptr %invariant.gep.2, i64 128
  %230 = load double, ptr %gep.1.2, align 8
  %231 = fmul double %229, %230
  %232 = fadd double %228, %231
  store double %232, ptr %224, align 8
  %233 = load double, ptr %183, align 8
  %gep.2.2 = getelementptr double, ptr %invariant.gep.2, i64 256
  %234 = load double, ptr %gep.2.2, align 8
  %235 = fmul double %233, %234
  %236 = fadd double %232, %235
  store double %236, ptr %224, align 8
  %237 = load double, ptr %184, align 8
  %gep.3.2 = getelementptr double, ptr %invariant.gep.2, i64 384
  %238 = load double, ptr %gep.3.2, align 8
  %239 = fmul double %237, %238
  %240 = fadd double %236, %239
  store double %240, ptr %224, align 8
  %241 = load double, ptr %185, align 8
  %gep.4.2 = getelementptr double, ptr %invariant.gep.2, i64 512
  %242 = load double, ptr %gep.4.2, align 8
  %243 = fmul double %241, %242
  %244 = fadd double %240, %243
  store double %244, ptr %224, align 8
  %245 = load double, ptr %186, align 8
  %gep.5.2 = getelementptr double, ptr %invariant.gep.2, i64 640
  %246 = load double, ptr %gep.5.2, align 8
  %247 = fmul double %245, %246
  %248 = fadd double %244, %247
  store double %248, ptr %224, align 8
  %249 = load double, ptr %187, align 8
  %gep.6.2 = getelementptr double, ptr %invariant.gep.2, i64 768
  %250 = load double, ptr %gep.6.2, align 8
  %251 = fmul double %249, %250
  %252 = fadd double %248, %251
  store double %252, ptr %224, align 8
  %253 = load double, ptr %188, align 8
  %gep.7.2 = getelementptr double, ptr %invariant.gep.2, i64 896
  %254 = load double, ptr %gep.7.2, align 8
  %255 = fmul double %253, %254
  %256 = fadd double %252, %255
  store double %256, ptr %224, align 8
  %257 = add nuw nsw i64 %223, 1
  %exitcond.2.not = icmp eq i64 %257, 128
  br i1 %exitcond.2.not, label %.preheader3.3, label %.preheader.2, !llvm.loop !32

.preheader3.3:                                    ; preds = %vector.body52, %.preheader.2
  %258 = getelementptr double, ptr %25, i64 384
  %259 = getelementptr double, ptr %24, i64 24
  %260 = getelementptr double, ptr %24, i64 25
  %261 = getelementptr double, ptr %24, i64 26
  %262 = getelementptr double, ptr %24, i64 27
  %263 = getelementptr double, ptr %24, i64 28
  %264 = getelementptr double, ptr %24, i64 29
  %265 = getelementptr double, ptr %24, i64 30
  %266 = getelementptr double, ptr %24, i64 31
  br i1 %conflict.rdx, label %.preheader.3, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3.3
  %267 = load double, ptr %259, align 8, !alias.scope !33
  %broadcast.splatinsert = insertelement <4 x double> poison, double %267, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %268 = load double, ptr %260, align 8, !alias.scope !33
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %268, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %269 = load double, ptr %261, align 8, !alias.scope !33
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %269, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %270 = load double, ptr %262, align 8, !alias.scope !33
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %270, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %271 = load double, ptr %263, align 8, !alias.scope !33
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %271, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %272 = load double, ptr %264, align 8, !alias.scope !33
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %272, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %273 = load double, ptr %265, align 8, !alias.scope !33
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %273, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %274 = load double, ptr %266, align 8, !alias.scope !33
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %274, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %275 = getelementptr double, ptr %8, i64 %index
  %276 = getelementptr double, ptr %258, i64 %index
  %wide.load = load <4 x double>, ptr %276, align 8, !alias.scope !36, !noalias !38
  %wide.load14 = load <4 x double>, ptr %275, align 8, !alias.scope !40
  %277 = fmul <4 x double> %broadcast.splat, %wide.load14
  %278 = fadd <4 x double> %wide.load, %277
  store <4 x double> %278, ptr %276, align 8, !alias.scope !36, !noalias !38
  %279 = getelementptr double, ptr %275, i64 128
  %wide.load15 = load <4 x double>, ptr %279, align 8, !alias.scope !40
  %280 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %281 = fadd <4 x double> %278, %280
  store <4 x double> %281, ptr %276, align 8, !alias.scope !36, !noalias !38
  %282 = getelementptr double, ptr %275, i64 256
  %wide.load18 = load <4 x double>, ptr %282, align 8, !alias.scope !40
  %283 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %284 = fadd <4 x double> %281, %283
  store <4 x double> %284, ptr %276, align 8, !alias.scope !36, !noalias !38
  %285 = getelementptr double, ptr %275, i64 384
  %wide.load21 = load <4 x double>, ptr %285, align 8, !alias.scope !40
  %286 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %287 = fadd <4 x double> %284, %286
  store <4 x double> %287, ptr %276, align 8, !alias.scope !36, !noalias !38
  %288 = getelementptr double, ptr %275, i64 512
  %wide.load24 = load <4 x double>, ptr %288, align 8, !alias.scope !40
  %289 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %290 = fadd <4 x double> %287, %289
  store <4 x double> %290, ptr %276, align 8, !alias.scope !36, !noalias !38
  %291 = getelementptr double, ptr %275, i64 640
  %wide.load27 = load <4 x double>, ptr %291, align 8, !alias.scope !40
  %292 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %293 = fadd <4 x double> %290, %292
  store <4 x double> %293, ptr %276, align 8, !alias.scope !36, !noalias !38
  %294 = getelementptr double, ptr %275, i64 768
  %wide.load30 = load <4 x double>, ptr %294, align 8, !alias.scope !40
  %295 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %296 = fadd <4 x double> %293, %295
  store <4 x double> %296, ptr %276, align 8, !alias.scope !36, !noalias !38
  %297 = getelementptr double, ptr %275, i64 896
  %wide.load33 = load <4 x double>, ptr %297, align 8, !alias.scope !40
  %298 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %299 = fadd <4 x double> %296, %298
  store <4 x double> %299, ptr %276, align 8, !alias.scope !36, !noalias !38
  %index.next = add nuw i64 %index, 4
  %300 = icmp eq i64 %index.next, 128
  br i1 %300, label %middle.block, label %vector.body, !llvm.loop !41

.preheader.3:                                     ; preds = %.preheader3.3, %.preheader.3
  %301 = phi i64 [ %335, %.preheader.3 ], [ 0, %.preheader3.3 ]
  %invariant.gep.3 = getelementptr double, ptr %8, i64 %301
  %302 = getelementptr double, ptr %258, i64 %301
  %.promoted.3 = load double, ptr %302, align 8
  %303 = load double, ptr %259, align 8
  %304 = load double, ptr %invariant.gep.3, align 8
  %305 = fmul double %303, %304
  %306 = fadd double %.promoted.3, %305
  store double %306, ptr %302, align 8
  %307 = load double, ptr %260, align 8
  %gep.1.3 = getelementptr double, ptr %invariant.gep.3, i64 128
  %308 = load double, ptr %gep.1.3, align 8
  %309 = fmul double %307, %308
  %310 = fadd double %306, %309
  store double %310, ptr %302, align 8
  %311 = load double, ptr %261, align 8
  %gep.2.3 = getelementptr double, ptr %invariant.gep.3, i64 256
  %312 = load double, ptr %gep.2.3, align 8
  %313 = fmul double %311, %312
  %314 = fadd double %310, %313
  store double %314, ptr %302, align 8
  %315 = load double, ptr %262, align 8
  %gep.3.3 = getelementptr double, ptr %invariant.gep.3, i64 384
  %316 = load double, ptr %gep.3.3, align 8
  %317 = fmul double %315, %316
  %318 = fadd double %314, %317
  store double %318, ptr %302, align 8
  %319 = load double, ptr %263, align 8
  %gep.4.3 = getelementptr double, ptr %invariant.gep.3, i64 512
  %320 = load double, ptr %gep.4.3, align 8
  %321 = fmul double %319, %320
  %322 = fadd double %318, %321
  store double %322, ptr %302, align 8
  %323 = load double, ptr %264, align 8
  %gep.5.3 = getelementptr double, ptr %invariant.gep.3, i64 640
  %324 = load double, ptr %gep.5.3, align 8
  %325 = fmul double %323, %324
  %326 = fadd double %322, %325
  store double %326, ptr %302, align 8
  %327 = load double, ptr %265, align 8
  %gep.6.3 = getelementptr double, ptr %invariant.gep.3, i64 768
  %328 = load double, ptr %gep.6.3, align 8
  %329 = fmul double %327, %328
  %330 = fadd double %326, %329
  store double %330, ptr %302, align 8
  %331 = load double, ptr %266, align 8
  %gep.7.3 = getelementptr double, ptr %invariant.gep.3, i64 896
  %332 = load double, ptr %gep.7.3, align 8
  %333 = fmul double %331, %332
  %334 = fadd double %330, %333
  store double %334, ptr %302, align 8
  %335 = add nuw nsw i64 %301, 1
  %exitcond.3.not = icmp eq i64 %335, 128
  br i1 %exitcond.3.not, label %middle.block, label %.preheader.3, !llvm.loop !42

middle.block:                                     ; preds = %vector.body, %.preheader.3
  %336 = add nuw nsw i64 %21, 4
  %337 = icmp ult i64 %21, 28
  br i1 %337, label %.preheader4, label %338

338:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
!13 = !{!14}
!14 = distinct !{!14, !15}
!15 = distinct !{!15, !"LVerDomain"}
!16 = !{!17}
!17 = distinct !{!17, !15}
!18 = !{!14, !19}
!19 = distinct !{!19, !15}
!20 = !{!19}
!21 = distinct !{!21, !10, !11}
!22 = distinct !{!22, !10}
!23 = !{!24}
!24 = distinct !{!24, !25}
!25 = distinct !{!25, !"LVerDomain"}
!26 = !{!27}
!27 = distinct !{!27, !25}
!28 = !{!24, !29}
!29 = distinct !{!29, !25}
!30 = !{!29}
!31 = distinct !{!31, !10, !11}
!32 = distinct !{!32, !10}
!33 = !{!34}
!34 = distinct !{!34, !35}
!35 = distinct !{!35, !"LVerDomain"}
!36 = !{!37}
!37 = distinct !{!37, !35}
!38 = !{!34, !39}
!39 = distinct !{!39, !35}
!40 = !{!39}
!41 = distinct !{!41, !10, !11}
!42 = distinct !{!42, !10}
