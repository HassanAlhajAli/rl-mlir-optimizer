; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32768) %15, i8 0, i64 32768, i1 false)
  %21 = getelementptr double, ptr %1, i64 1
  %22 = getelementptr double, ptr %1, i64 2
  %23 = getelementptr double, ptr %1, i64 3
  %24 = getelementptr double, ptr %1, i64 4
  %25 = getelementptr double, ptr %1, i64 5
  %26 = getelementptr double, ptr %1, i64 6
  %27 = getelementptr double, ptr %1, i64 7
  %scevgep = getelementptr i8, ptr %15, i64 16384
  %scevgep7 = getelementptr i8, ptr %1, i64 1024
  %scevgep8 = getelementptr i8, ptr %8, i64 8192
  %bound0 = icmp ugt ptr %scevgep7, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound09 = icmp ugt ptr %scevgep8, %15
  %bound110 = icmp ugt ptr %scevgep, %8
  %found.conflict11 = and i1 %bound09, %bound110
  %conflict.rdx = or i1 %found.conflict, %found.conflict11
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4.preheader, %middle.block
  %28 = phi i64 [ 0, %.preheader4.preheader ], [ %109, %middle.block ]
  %29 = shl i64 %28, 3
  %30 = shl i64 %28, 7
  %31 = getelementptr double, ptr %15, i64 %30
  %32 = getelementptr double, ptr %1, i64 %29
  %33 = getelementptr double, ptr %21, i64 %29
  %34 = getelementptr double, ptr %22, i64 %29
  %35 = getelementptr double, ptr %23, i64 %29
  %36 = getelementptr double, ptr %24, i64 %29
  %37 = getelementptr double, ptr %25, i64 %29
  %38 = getelementptr double, ptr %26, i64 %29
  %39 = getelementptr double, ptr %27, i64 %29
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %40 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %40, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %41 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert14 = insertelement <4 x double> poison, double %41, i64 0
  %broadcast.splat15 = shufflevector <4 x double> %broadcast.splatinsert14, <4 x double> poison, <4 x i32> zeroinitializer
  %42 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert17 = insertelement <4 x double> poison, double %42, i64 0
  %broadcast.splat18 = shufflevector <4 x double> %broadcast.splatinsert17, <4 x double> poison, <4 x i32> zeroinitializer
  %43 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert20 = insertelement <4 x double> poison, double %43, i64 0
  %broadcast.splat21 = shufflevector <4 x double> %broadcast.splatinsert20, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert23 = insertelement <4 x double> poison, double %44, i64 0
  %broadcast.splat24 = shufflevector <4 x double> %broadcast.splatinsert23, <4 x double> poison, <4 x i32> zeroinitializer
  %45 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert26 = insertelement <4 x double> poison, double %45, i64 0
  %broadcast.splat27 = shufflevector <4 x double> %broadcast.splatinsert26, <4 x double> poison, <4 x i32> zeroinitializer
  %46 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert29 = insertelement <4 x double> poison, double %46, i64 0
  %broadcast.splat30 = shufflevector <4 x double> %broadcast.splatinsert29, <4 x double> poison, <4 x i32> zeroinitializer
  %47 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert32 = insertelement <4 x double> poison, double %47, i64 0
  %broadcast.splat33 = shufflevector <4 x double> %broadcast.splatinsert32, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %48 = getelementptr double, ptr %8, i64 %index
  %49 = getelementptr double, ptr %31, i64 %index
  %wide.load = load <4 x double>, ptr %49, align 8, !alias.scope !4, !noalias !6
  %wide.load12 = load <4 x double>, ptr %48, align 8, !alias.scope !8
  %50 = fmul <4 x double> %broadcast.splat, %wide.load12
  %51 = fadd <4 x double> %wide.load, %50
  store <4 x double> %51, ptr %49, align 8, !alias.scope !4, !noalias !6
  %52 = getelementptr double, ptr %48, i64 128
  %wide.load13 = load <4 x double>, ptr %52, align 8, !alias.scope !8
  %53 = fmul <4 x double> %broadcast.splat15, %wide.load13
  %54 = fadd <4 x double> %51, %53
  store <4 x double> %54, ptr %49, align 8, !alias.scope !4, !noalias !6
  %55 = getelementptr double, ptr %48, i64 256
  %wide.load16 = load <4 x double>, ptr %55, align 8, !alias.scope !8
  %56 = fmul <4 x double> %broadcast.splat18, %wide.load16
  %57 = fadd <4 x double> %54, %56
  store <4 x double> %57, ptr %49, align 8, !alias.scope !4, !noalias !6
  %58 = getelementptr double, ptr %48, i64 384
  %wide.load19 = load <4 x double>, ptr %58, align 8, !alias.scope !8
  %59 = fmul <4 x double> %broadcast.splat21, %wide.load19
  %60 = fadd <4 x double> %57, %59
  store <4 x double> %60, ptr %49, align 8, !alias.scope !4, !noalias !6
  %61 = getelementptr double, ptr %48, i64 512
  %wide.load22 = load <4 x double>, ptr %61, align 8, !alias.scope !8
  %62 = fmul <4 x double> %broadcast.splat24, %wide.load22
  %63 = fadd <4 x double> %60, %62
  store <4 x double> %63, ptr %49, align 8, !alias.scope !4, !noalias !6
  %64 = getelementptr double, ptr %48, i64 640
  %wide.load25 = load <4 x double>, ptr %64, align 8, !alias.scope !8
  %65 = fmul <4 x double> %broadcast.splat27, %wide.load25
  %66 = fadd <4 x double> %63, %65
  store <4 x double> %66, ptr %49, align 8, !alias.scope !4, !noalias !6
  %67 = getelementptr double, ptr %48, i64 768
  %wide.load28 = load <4 x double>, ptr %67, align 8, !alias.scope !8
  %68 = fmul <4 x double> %broadcast.splat30, %wide.load28
  %69 = fadd <4 x double> %66, %68
  store <4 x double> %69, ptr %49, align 8, !alias.scope !4, !noalias !6
  %70 = getelementptr double, ptr %48, i64 896
  %wide.load31 = load <4 x double>, ptr %70, align 8, !alias.scope !8
  %71 = fmul <4 x double> %broadcast.splat33, %wide.load31
  %72 = fadd <4 x double> %69, %71
  store <4 x double> %72, ptr %49, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %73 = icmp eq i64 %index.next, 128
  br i1 %73, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %74 = phi i64 [ %108, %.preheader ], [ 0, %.preheader3 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %74
  %75 = getelementptr double, ptr %31, i64 %74
  %.promoted = load double, ptr %75, align 8
  %76 = load double, ptr %32, align 8
  %77 = load double, ptr %invariant.gep, align 8
  %78 = fmul double %76, %77
  %79 = fadd double %.promoted, %78
  store double %79, ptr %75, align 8
  %80 = load double, ptr %33, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 128
  %81 = load double, ptr %gep.1, align 8
  %82 = fmul double %80, %81
  %83 = fadd double %79, %82
  store double %83, ptr %75, align 8
  %84 = load double, ptr %34, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 256
  %85 = load double, ptr %gep.2, align 8
  %86 = fmul double %84, %85
  %87 = fadd double %83, %86
  store double %87, ptr %75, align 8
  %88 = load double, ptr %35, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 384
  %89 = load double, ptr %gep.3, align 8
  %90 = fmul double %88, %89
  %91 = fadd double %87, %90
  store double %91, ptr %75, align 8
  %92 = load double, ptr %36, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 512
  %93 = load double, ptr %gep.4, align 8
  %94 = fmul double %92, %93
  %95 = fadd double %91, %94
  store double %95, ptr %75, align 8
  %96 = load double, ptr %37, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 640
  %97 = load double, ptr %gep.5, align 8
  %98 = fmul double %96, %97
  %99 = fadd double %95, %98
  store double %99, ptr %75, align 8
  %100 = load double, ptr %38, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 768
  %101 = load double, ptr %gep.6, align 8
  %102 = fmul double %100, %101
  %103 = fadd double %99, %102
  store double %103, ptr %75, align 8
  %104 = load double, ptr %39, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 896
  %105 = load double, ptr %gep.7, align 8
  %106 = fmul double %104, %105
  %107 = fadd double %103, %106
  store double %107, ptr %75, align 8
  %108 = add nuw nsw i64 %74, 1
  %exitcond.not = icmp eq i64 %108, 128
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %109 = add nuw nsw i64 %28, 1
  %exitcond6.not = icmp eq i64 %109, 16
  br i1 %exitcond6.not, label %.preheader4.1, label %.preheader3

.preheader4.1:                                    ; preds = %middle.block
  %110 = getelementptr double, ptr %1, i64 128
  %111 = getelementptr double, ptr %15, i64 2048
  %112 = getelementptr double, ptr %1, i64 129
  %113 = getelementptr double, ptr %1, i64 130
  %114 = getelementptr double, ptr %1, i64 131
  %115 = getelementptr double, ptr %1, i64 132
  %116 = getelementptr double, ptr %1, i64 133
  %117 = getelementptr double, ptr %1, i64 134
  %118 = getelementptr double, ptr %1, i64 135
  %scevgep35 = getelementptr i8, ptr %15, i64 32768
  %scevgep36 = getelementptr i8, ptr %1, i64 2048
  %scevgep37 = getelementptr i8, ptr %8, i64 8192
  %bound038 = icmp ult ptr %111, %scevgep36
  %bound139 = icmp ult ptr %110, %scevgep35
  %found.conflict40 = and i1 %bound038, %bound139
  %bound041 = icmp ult ptr %111, %scevgep37
  %bound142 = icmp ugt ptr %scevgep35, %8
  %found.conflict43 = and i1 %bound041, %bound142
  %conflict.rdx44 = or i1 %found.conflict40, %found.conflict43
  br label %.preheader3.1

.preheader3.1:                                    ; preds = %middle.block45, %.preheader4.1
  %119 = phi i64 [ 0, %.preheader4.1 ], [ %200, %middle.block45 ]
  %120 = shl i64 %119, 3
  %121 = shl i64 %119, 7
  %122 = getelementptr double, ptr %111, i64 %121
  %123 = getelementptr double, ptr %110, i64 %120
  %124 = getelementptr double, ptr %112, i64 %120
  %125 = getelementptr double, ptr %113, i64 %120
  %126 = getelementptr double, ptr %114, i64 %120
  %127 = getelementptr double, ptr %115, i64 %120
  %128 = getelementptr double, ptr %116, i64 %120
  %129 = getelementptr double, ptr %117, i64 %120
  %130 = getelementptr double, ptr %118, i64 %120
  br i1 %conflict.rdx44, label %.preheader.1, label %vector.body49.preheader

vector.body49.preheader:                          ; preds = %.preheader3.1
  %131 = load double, ptr %123, align 8, !alias.scope !13
  %broadcast.splatinsert53 = insertelement <4 x double> poison, double %131, i64 0
  %broadcast.splat54 = shufflevector <4 x double> %broadcast.splatinsert53, <4 x double> poison, <4 x i32> zeroinitializer
  %132 = load double, ptr %124, align 8, !alias.scope !13
  %broadcast.splatinsert56 = insertelement <4 x double> poison, double %132, i64 0
  %broadcast.splat57 = shufflevector <4 x double> %broadcast.splatinsert56, <4 x double> poison, <4 x i32> zeroinitializer
  %133 = load double, ptr %125, align 8, !alias.scope !13
  %broadcast.splatinsert59 = insertelement <4 x double> poison, double %133, i64 0
  %broadcast.splat60 = shufflevector <4 x double> %broadcast.splatinsert59, <4 x double> poison, <4 x i32> zeroinitializer
  %134 = load double, ptr %126, align 8, !alias.scope !13
  %broadcast.splatinsert62 = insertelement <4 x double> poison, double %134, i64 0
  %broadcast.splat63 = shufflevector <4 x double> %broadcast.splatinsert62, <4 x double> poison, <4 x i32> zeroinitializer
  %135 = load double, ptr %127, align 8, !alias.scope !13
  %broadcast.splatinsert65 = insertelement <4 x double> poison, double %135, i64 0
  %broadcast.splat66 = shufflevector <4 x double> %broadcast.splatinsert65, <4 x double> poison, <4 x i32> zeroinitializer
  %136 = load double, ptr %128, align 8, !alias.scope !13
  %broadcast.splatinsert68 = insertelement <4 x double> poison, double %136, i64 0
  %broadcast.splat69 = shufflevector <4 x double> %broadcast.splatinsert68, <4 x double> poison, <4 x i32> zeroinitializer
  %137 = load double, ptr %129, align 8, !alias.scope !13
  %broadcast.splatinsert71 = insertelement <4 x double> poison, double %137, i64 0
  %broadcast.splat72 = shufflevector <4 x double> %broadcast.splatinsert71, <4 x double> poison, <4 x i32> zeroinitializer
  %138 = load double, ptr %130, align 8, !alias.scope !13
  %broadcast.splatinsert74 = insertelement <4 x double> poison, double %138, i64 0
  %broadcast.splat75 = shufflevector <4 x double> %broadcast.splatinsert74, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body49

vector.body49:                                    ; preds = %vector.body49.preheader, %vector.body49
  %index50 = phi i64 [ %index.next76, %vector.body49 ], [ 0, %vector.body49.preheader ]
  %139 = getelementptr double, ptr %8, i64 %index50
  %140 = getelementptr double, ptr %122, i64 %index50
  %wide.load51 = load <4 x double>, ptr %140, align 8, !alias.scope !16, !noalias !18
  %wide.load52 = load <4 x double>, ptr %139, align 8, !alias.scope !20
  %141 = fmul <4 x double> %broadcast.splat54, %wide.load52
  %142 = fadd <4 x double> %wide.load51, %141
  store <4 x double> %142, ptr %140, align 8, !alias.scope !16, !noalias !18
  %143 = getelementptr double, ptr %139, i64 128
  %wide.load55 = load <4 x double>, ptr %143, align 8, !alias.scope !20
  %144 = fmul <4 x double> %broadcast.splat57, %wide.load55
  %145 = fadd <4 x double> %142, %144
  store <4 x double> %145, ptr %140, align 8, !alias.scope !16, !noalias !18
  %146 = getelementptr double, ptr %139, i64 256
  %wide.load58 = load <4 x double>, ptr %146, align 8, !alias.scope !20
  %147 = fmul <4 x double> %broadcast.splat60, %wide.load58
  %148 = fadd <4 x double> %145, %147
  store <4 x double> %148, ptr %140, align 8, !alias.scope !16, !noalias !18
  %149 = getelementptr double, ptr %139, i64 384
  %wide.load61 = load <4 x double>, ptr %149, align 8, !alias.scope !20
  %150 = fmul <4 x double> %broadcast.splat63, %wide.load61
  %151 = fadd <4 x double> %148, %150
  store <4 x double> %151, ptr %140, align 8, !alias.scope !16, !noalias !18
  %152 = getelementptr double, ptr %139, i64 512
  %wide.load64 = load <4 x double>, ptr %152, align 8, !alias.scope !20
  %153 = fmul <4 x double> %broadcast.splat66, %wide.load64
  %154 = fadd <4 x double> %151, %153
  store <4 x double> %154, ptr %140, align 8, !alias.scope !16, !noalias !18
  %155 = getelementptr double, ptr %139, i64 640
  %wide.load67 = load <4 x double>, ptr %155, align 8, !alias.scope !20
  %156 = fmul <4 x double> %broadcast.splat69, %wide.load67
  %157 = fadd <4 x double> %154, %156
  store <4 x double> %157, ptr %140, align 8, !alias.scope !16, !noalias !18
  %158 = getelementptr double, ptr %139, i64 768
  %wide.load70 = load <4 x double>, ptr %158, align 8, !alias.scope !20
  %159 = fmul <4 x double> %broadcast.splat72, %wide.load70
  %160 = fadd <4 x double> %157, %159
  store <4 x double> %160, ptr %140, align 8, !alias.scope !16, !noalias !18
  %161 = getelementptr double, ptr %139, i64 896
  %wide.load73 = load <4 x double>, ptr %161, align 8, !alias.scope !20
  %162 = fmul <4 x double> %broadcast.splat75, %wide.load73
  %163 = fadd <4 x double> %160, %162
  store <4 x double> %163, ptr %140, align 8, !alias.scope !16, !noalias !18
  %index.next76 = add nuw i64 %index50, 4
  %164 = icmp eq i64 %index.next76, 128
  br i1 %164, label %middle.block45, label %vector.body49, !llvm.loop !21

.preheader.1:                                     ; preds = %.preheader3.1, %.preheader.1
  %165 = phi i64 [ %199, %.preheader.1 ], [ 0, %.preheader3.1 ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %165
  %166 = getelementptr double, ptr %122, i64 %165
  %.promoted.1 = load double, ptr %166, align 8
  %167 = load double, ptr %123, align 8
  %168 = load double, ptr %invariant.gep.1, align 8
  %169 = fmul double %167, %168
  %170 = fadd double %.promoted.1, %169
  store double %170, ptr %166, align 8
  %171 = load double, ptr %124, align 8
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 128
  %172 = load double, ptr %gep.1.1, align 8
  %173 = fmul double %171, %172
  %174 = fadd double %170, %173
  store double %174, ptr %166, align 8
  %175 = load double, ptr %125, align 8
  %gep.2.1 = getelementptr double, ptr %invariant.gep.1, i64 256
  %176 = load double, ptr %gep.2.1, align 8
  %177 = fmul double %175, %176
  %178 = fadd double %174, %177
  store double %178, ptr %166, align 8
  %179 = load double, ptr %126, align 8
  %gep.3.1 = getelementptr double, ptr %invariant.gep.1, i64 384
  %180 = load double, ptr %gep.3.1, align 8
  %181 = fmul double %179, %180
  %182 = fadd double %178, %181
  store double %182, ptr %166, align 8
  %183 = load double, ptr %127, align 8
  %gep.4.1 = getelementptr double, ptr %invariant.gep.1, i64 512
  %184 = load double, ptr %gep.4.1, align 8
  %185 = fmul double %183, %184
  %186 = fadd double %182, %185
  store double %186, ptr %166, align 8
  %187 = load double, ptr %128, align 8
  %gep.5.1 = getelementptr double, ptr %invariant.gep.1, i64 640
  %188 = load double, ptr %gep.5.1, align 8
  %189 = fmul double %187, %188
  %190 = fadd double %186, %189
  store double %190, ptr %166, align 8
  %191 = load double, ptr %129, align 8
  %gep.6.1 = getelementptr double, ptr %invariant.gep.1, i64 768
  %192 = load double, ptr %gep.6.1, align 8
  %193 = fmul double %191, %192
  %194 = fadd double %190, %193
  store double %194, ptr %166, align 8
  %195 = load double, ptr %130, align 8
  %gep.7.1 = getelementptr double, ptr %invariant.gep.1, i64 896
  %196 = load double, ptr %gep.7.1, align 8
  %197 = fmul double %195, %196
  %198 = fadd double %194, %197
  store double %198, ptr %166, align 8
  %199 = add nuw nsw i64 %165, 1
  %exitcond.1.not = icmp eq i64 %199, 128
  br i1 %exitcond.1.not, label %middle.block45, label %.preheader.1, !llvm.loop !22

middle.block45:                                   ; preds = %vector.body49, %.preheader.1
  %200 = add nuw nsw i64 %119, 1
  %exitcond6.1.not = icmp eq i64 %200, 16
  br i1 %exitcond6.1.not, label %201, label %.preheader3.1

201:                                              ; preds = %middle.block45
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
!13 = !{!14}
!14 = distinct !{!14, !15}
!15 = distinct !{!15, !"LVerDomain"}
!16 = !{!17}
!17 = distinct !{!17, !15}
!18 = !{!14, !19}
!19 = distinct !{!19, !15}
!20 = !{!19}
!21 = distinct !{!21, !10, !11}
!22 = distinct !{!22, !10}
