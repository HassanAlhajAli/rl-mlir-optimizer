#map = affine_map<(d0, d1) -> (d0, 0, d1)>
#map1 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<32x8xf64>, %arg1: memref<8x128xf64>, %arg2: memref<32x128xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_2 = arith.constant 0 : index
    %c16_3 = arith.constant 16 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<32x128xf64>)
    %c0_6 = arith.constant 0 : index
    %c32 = arith.constant 32 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_6 to %c32 step %c16_7 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 8] [1, 1] : memref<32x8xf64> to memref<16x8xf64, strided<[8, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [16, 128] [1, 1] : memref<32x128xf64> to memref<16x128xf64, strided<[128, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c128 = arith.constant 128 : index
      %c16_10 = arith.constant 16 : index
      scf.for %arg4 = %c0_9 to %c128 step %c16_10 {
        %subview_11 = memref.subview %arg1[0, %arg4] [8, 16] [1, 1] : memref<8x128xf64> to memref<8x16xf64, strided<[128, 1], offset: ?>>
        %subview_12 = memref.subview %subview_8[0, %arg4] [16, 16] [1, 1] : memref<16x128xf64, strided<[128, 1], offset: ?>> to memref<16x16xf64, strided<[128, 1], offset: ?>>
        %c0_13 = arith.constant 0 : index
        %c8 = arith.constant 8 : index
        %c1_14 = arith.constant 1 : index
        scf.for %arg5 = %c0_13 to %c8 step %c1_14 {
          %subview_15 = memref.subview %subview[0, %arg5] [16, 1] [1, 1] : memref<16x8xf64, strided<[8, 1], offset: ?>> to memref<16x1xf64, strided<[8, 1], offset: ?>>
          %subview_16 = memref.subview %subview_11[%arg5, 0] [1, 16] [1, 1] : memref<8x16xf64, strided<[128, 1], offset: ?>> to memref<1x16xf64, strided<[128, 1], offset: ?>>
          %c16_17 = arith.constant 16 : index
          %c16_18 = arith.constant 16 : index
          %c1_19 = arith.constant 1 : index
          %c0_20 = arith.constant 0 : index
          %cst_21 = arith.constant 0.000000e+00 : f64
          %0 = vector.transfer_read %subview_15[%c0_20, %c0_20], %cst_21 {permutation_map = #map} : memref<16x1xf64, strided<[8, 1], offset: ?>>, vector<16x16x1xf64>
          %cst_22 = arith.constant 0.000000e+00 : f64
          %1 = vector.transfer_read %subview_16[%c0_20, %c0_20], %cst_22 {permutation_map = #map1} : memref<1x16xf64, strided<[128, 1], offset: ?>>, vector<16x16x1xf64>
          %cst_23 = arith.constant 0.000000e+00 : f64
          %2 = vector.transfer_read %subview_12[%c0_20, %c0_20], %cst_23 : memref<16x16xf64, strided<[128, 1], offset: ?>>, vector<16x16xf64>
          %3 = arith.mulf %0, %1 : vector<16x16x1xf64>
          %4 = vector.multi_reduction <add>, %3, %2 [2] : vector<16x16x1xf64> to vector<16x16xf64>
          %c0_24 = arith.constant 0 : index
          vector.transfer_write %4, %subview_12[%c0_24, %c0_24] : vector<16x16xf64>, memref<16x16xf64, strided<[128, 1], offset: ?>>
        }
      }
    }
    return
  }
}
