; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %15, i8 0, i64 16120, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 16120
  %scevgep6 = getelementptr i8, ptr %1, i64 4216
  %scevgep7 = getelementptr i8, ptr %8, i64 8840
  %bound0 = icmp ugt ptr %scevgep6, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound08 = icmp ugt ptr %scevgep7, %15
  %bound19 = icmp ugt ptr %scevgep, %8
  %found.conflict10 = and i1 %bound08, %bound19
  %conflict.rdx = or i1 %found.conflict, %found.conflict10
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %.loopexit
  %21 = phi i64 [ %183, %.loopexit ], [ 0, %.preheader2.preheader ]
  %22 = mul nuw nsw i64 %21, 17
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = mul nuw nsw i64 %21, 65
  %25 = getelementptr double, ptr %15, i64 %24
  %26 = getelementptr double, ptr %23, i64 1
  %27 = getelementptr double, ptr %23, i64 2
  %28 = getelementptr double, ptr %23, i64 3
  %29 = getelementptr double, ptr %23, i64 4
  %30 = getelementptr double, ptr %23, i64 5
  %31 = getelementptr double, ptr %23, i64 6
  %32 = getelementptr double, ptr %23, i64 7
  %33 = getelementptr double, ptr %23, i64 8
  %34 = getelementptr double, ptr %23, i64 9
  %35 = getelementptr double, ptr %23, i64 10
  %36 = getelementptr double, ptr %23, i64 11
  %37 = getelementptr double, ptr %23, i64 12
  %38 = getelementptr double, ptr %23, i64 13
  %39 = getelementptr double, ptr %23, i64 14
  %40 = getelementptr double, ptr %23, i64 15
  %41 = getelementptr double, ptr %23, i64 16
  br i1 %conflict.rdx, label %.preheader.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader2
  %42 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %42, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %43 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %43, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %44, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %45 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %45, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %46 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %46, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %47 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %47, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %48 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %48, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %49, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %50, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %51 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %51, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %52, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %53 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %59 = getelementptr double, ptr %8, i64 %index
  %60 = getelementptr double, ptr %25, i64 %index
  %wide.load = load <4 x double>, ptr %60, align 8, !alias.scope !4, !noalias !6
  %wide.load11 = load <4 x double>, ptr %59, align 8, !alias.scope !8
  %61 = fmul <4 x double> %broadcast.splat, %wide.load11
  %62 = fadd <4 x double> %wide.load, %61
  store <4 x double> %62, ptr %60, align 8, !alias.scope !4, !noalias !6
  %63 = getelementptr double, ptr %59, i64 65
  %wide.load12 = load <4 x double>, ptr %63, align 8, !alias.scope !8
  %64 = fmul <4 x double> %broadcast.splat14, %wide.load12
  %65 = fadd <4 x double> %62, %64
  store <4 x double> %65, ptr %60, align 8, !alias.scope !4, !noalias !6
  %66 = getelementptr double, ptr %59, i64 130
  %wide.load15 = load <4 x double>, ptr %66, align 8, !alias.scope !8
  %67 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %68 = fadd <4 x double> %65, %67
  store <4 x double> %68, ptr %60, align 8, !alias.scope !4, !noalias !6
  %69 = getelementptr double, ptr %59, i64 195
  %wide.load18 = load <4 x double>, ptr %69, align 8, !alias.scope !8
  %70 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %71 = fadd <4 x double> %68, %70
  store <4 x double> %71, ptr %60, align 8, !alias.scope !4, !noalias !6
  %72 = getelementptr double, ptr %59, i64 260
  %wide.load21 = load <4 x double>, ptr %72, align 8, !alias.scope !8
  %73 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %74 = fadd <4 x double> %71, %73
  store <4 x double> %74, ptr %60, align 8, !alias.scope !4, !noalias !6
  %75 = getelementptr double, ptr %59, i64 325
  %wide.load24 = load <4 x double>, ptr %75, align 8, !alias.scope !8
  %76 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %77 = fadd <4 x double> %74, %76
  store <4 x double> %77, ptr %60, align 8, !alias.scope !4, !noalias !6
  %78 = getelementptr double, ptr %59, i64 390
  %wide.load27 = load <4 x double>, ptr %78, align 8, !alias.scope !8
  %79 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %80 = fadd <4 x double> %77, %79
  store <4 x double> %80, ptr %60, align 8, !alias.scope !4, !noalias !6
  %81 = getelementptr double, ptr %59, i64 455
  %wide.load30 = load <4 x double>, ptr %81, align 8, !alias.scope !8
  %82 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %83 = fadd <4 x double> %80, %82
  store <4 x double> %83, ptr %60, align 8, !alias.scope !4, !noalias !6
  %84 = getelementptr double, ptr %59, i64 520
  %wide.load33 = load <4 x double>, ptr %84, align 8, !alias.scope !8
  %85 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %86 = fadd <4 x double> %83, %85
  store <4 x double> %86, ptr %60, align 8, !alias.scope !4, !noalias !6
  %87 = getelementptr double, ptr %59, i64 585
  %wide.load36 = load <4 x double>, ptr %87, align 8, !alias.scope !8
  %88 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %89 = fadd <4 x double> %86, %88
  store <4 x double> %89, ptr %60, align 8, !alias.scope !4, !noalias !6
  %90 = getelementptr double, ptr %59, i64 650
  %wide.load39 = load <4 x double>, ptr %90, align 8, !alias.scope !8
  %91 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %92 = fadd <4 x double> %89, %91
  store <4 x double> %92, ptr %60, align 8, !alias.scope !4, !noalias !6
  %93 = getelementptr double, ptr %59, i64 715
  %wide.load42 = load <4 x double>, ptr %93, align 8, !alias.scope !8
  %94 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %95 = fadd <4 x double> %92, %94
  store <4 x double> %95, ptr %60, align 8, !alias.scope !4, !noalias !6
  %96 = getelementptr double, ptr %59, i64 780
  %wide.load45 = load <4 x double>, ptr %96, align 8, !alias.scope !8
  %97 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %98 = fadd <4 x double> %95, %97
  store <4 x double> %98, ptr %60, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %59, i64 845
  %wide.load48 = load <4 x double>, ptr %99, align 8, !alias.scope !8
  %100 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %101 = fadd <4 x double> %98, %100
  store <4 x double> %101, ptr %60, align 8, !alias.scope !4, !noalias !6
  %102 = getelementptr double, ptr %59, i64 910
  %wide.load51 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %103 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %104 = fadd <4 x double> %101, %103
  store <4 x double> %104, ptr %60, align 8, !alias.scope !4, !noalias !6
  %105 = getelementptr double, ptr %59, i64 975
  %wide.load54 = load <4 x double>, ptr %105, align 8, !alias.scope !8
  %106 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %107 = fadd <4 x double> %104, %106
  store <4 x double> %107, ptr %60, align 8, !alias.scope !4, !noalias !6
  %108 = getelementptr double, ptr %59, i64 1040
  %wide.load57 = load <4 x double>, ptr %108, align 8, !alias.scope !8
  %109 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %110 = fadd <4 x double> %107, %109
  store <4 x double> %110, ptr %60, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %111 = icmp eq i64 %index.next, 64
  br i1 %111, label %.preheader.preheader, label %vector.body, !llvm.loop !9

.preheader.preheader:                             ; preds = %vector.body, %.preheader2
  %.ph = phi i64 [ 0, %.preheader2 ], [ 64, %vector.body ]
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %112 = phi i64 [ %182, %.preheader ], [ %.ph, %.preheader.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %112
  %113 = getelementptr double, ptr %25, i64 %112
  %.promoted = load double, ptr %113, align 8
  %114 = load double, ptr %23, align 8
  %115 = load double, ptr %invariant.gep, align 8
  %116 = fmul double %114, %115
  %117 = fadd double %.promoted, %116
  store double %117, ptr %113, align 8
  %118 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 65
  %119 = load double, ptr %gep.1, align 8
  %120 = fmul double %118, %119
  %121 = fadd double %117, %120
  store double %121, ptr %113, align 8
  %122 = load double, ptr %27, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 130
  %123 = load double, ptr %gep.2, align 8
  %124 = fmul double %122, %123
  %125 = fadd double %121, %124
  store double %125, ptr %113, align 8
  %126 = load double, ptr %28, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 195
  %127 = load double, ptr %gep.3, align 8
  %128 = fmul double %126, %127
  %129 = fadd double %125, %128
  store double %129, ptr %113, align 8
  %130 = load double, ptr %29, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 260
  %131 = load double, ptr %gep.4, align 8
  %132 = fmul double %130, %131
  %133 = fadd double %129, %132
  store double %133, ptr %113, align 8
  %134 = load double, ptr %30, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 325
  %135 = load double, ptr %gep.5, align 8
  %136 = fmul double %134, %135
  %137 = fadd double %133, %136
  store double %137, ptr %113, align 8
  %138 = load double, ptr %31, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 390
  %139 = load double, ptr %gep.6, align 8
  %140 = fmul double %138, %139
  %141 = fadd double %137, %140
  store double %141, ptr %113, align 8
  %142 = load double, ptr %32, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 455
  %143 = load double, ptr %gep.7, align 8
  %144 = fmul double %142, %143
  %145 = fadd double %141, %144
  store double %145, ptr %113, align 8
  %146 = load double, ptr %33, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 520
  %147 = load double, ptr %gep.8, align 8
  %148 = fmul double %146, %147
  %149 = fadd double %145, %148
  store double %149, ptr %113, align 8
  %150 = load double, ptr %34, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 585
  %151 = load double, ptr %gep.9, align 8
  %152 = fmul double %150, %151
  %153 = fadd double %149, %152
  store double %153, ptr %113, align 8
  %154 = load double, ptr %35, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 650
  %155 = load double, ptr %gep.10, align 8
  %156 = fmul double %154, %155
  %157 = fadd double %153, %156
  store double %157, ptr %113, align 8
  %158 = load double, ptr %36, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 715
  %159 = load double, ptr %gep.11, align 8
  %160 = fmul double %158, %159
  %161 = fadd double %157, %160
  store double %161, ptr %113, align 8
  %162 = load double, ptr %37, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 780
  %163 = load double, ptr %gep.12, align 8
  %164 = fmul double %162, %163
  %165 = fadd double %161, %164
  store double %165, ptr %113, align 8
  %166 = load double, ptr %38, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 845
  %167 = load double, ptr %gep.13, align 8
  %168 = fmul double %166, %167
  %169 = fadd double %165, %168
  store double %169, ptr %113, align 8
  %170 = load double, ptr %39, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 910
  %171 = load double, ptr %gep.14, align 8
  %172 = fmul double %170, %171
  %173 = fadd double %169, %172
  store double %173, ptr %113, align 8
  %174 = load double, ptr %40, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 975
  %175 = load double, ptr %gep.15, align 8
  %176 = fmul double %174, %175
  %177 = fadd double %173, %176
  store double %177, ptr %113, align 8
  %178 = load double, ptr %41, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1040
  %179 = load double, ptr %gep.16, align 8
  %180 = fmul double %178, %179
  %181 = fadd double %177, %180
  store double %181, ptr %113, align 8
  %182 = add nuw nsw i64 %112, 1
  %exitcond.not = icmp eq i64 %182, 65
  br i1 %exitcond.not, label %.loopexit, label %.preheader, !llvm.loop !12

.loopexit:                                        ; preds = %.preheader
  %183 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %183, 31
  br i1 %exitcond5.not, label %184, label %.preheader2

184:                                              ; preds = %.loopexit
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
