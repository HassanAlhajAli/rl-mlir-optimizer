; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %15, i8 0, i64 16120, i1 false)
  %scevgep10 = getelementptr i8, ptr %8, i64 8840
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %195
  %indvar = phi i64 [ 0, %.preheader4.preheader ], [ %indvar.next, %195 ]
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %196, %195 ]
  %22 = mul nuw nsw i64 %indvar, 2080
  %scevgep = getelementptr i8, ptr %15, i64 %22
  %23 = mul nuw nsw i64 %indvar, 544
  %scevgep8 = getelementptr i8, ptr %1, i64 %23
  %24 = icmp eq i64 %21, 28
  %25 = select i1 %24, i64 3, i64 4
  %26 = mul nuw nsw i64 %21, 17
  %27 = mul nuw nsw i64 %21, 65
  %28 = getelementptr double, ptr %1, i64 %26
  %29 = getelementptr double, ptr %15, i64 %27
  %30 = mul nuw nsw i64 %25, 520
  %scevgep7 = getelementptr i8, ptr %scevgep, i64 %30
  %31 = mul nuw nsw i64 %25, 136
  %scevgep9 = getelementptr i8, ptr %scevgep8, i64 %31
  %bound0 = icmp ult ptr %scevgep, %scevgep9
  %bound1 = icmp ult ptr %scevgep8, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %.loopexit
  %32 = phi i64 [ 0, %.preheader4 ], [ %194, %.loopexit ]
  %33 = mul nuw nsw i64 %32, 17
  %34 = getelementptr double, ptr %28, i64 %33
  %35 = mul nuw nsw i64 %32, 65
  %36 = getelementptr double, ptr %29, i64 %35
  %37 = getelementptr double, ptr %34, i64 1
  %38 = getelementptr double, ptr %34, i64 2
  %39 = getelementptr double, ptr %34, i64 3
  %40 = getelementptr double, ptr %34, i64 4
  %41 = getelementptr double, ptr %34, i64 5
  %42 = getelementptr double, ptr %34, i64 6
  %43 = getelementptr double, ptr %34, i64 7
  %44 = getelementptr double, ptr %34, i64 8
  %45 = getelementptr double, ptr %34, i64 9
  %46 = getelementptr double, ptr %34, i64 10
  %47 = getelementptr double, ptr %34, i64 11
  %48 = getelementptr double, ptr %34, i64 12
  %49 = getelementptr double, ptr %34, i64 13
  %50 = getelementptr double, ptr %34, i64 14
  %51 = getelementptr double, ptr %34, i64 15
  %52 = getelementptr double, ptr %34, i64 16
  br i1 %conflict.rdx, label %.preheader.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %53 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %49, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %51, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %70 = getelementptr double, ptr %8, i64 %index
  %71 = getelementptr double, ptr %36, i64 %index
  %wide.load = load <4 x double>, ptr %71, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %70, align 8, !alias.scope !8
  %72 = fmul <4 x double> %broadcast.splat, %wide.load14
  %73 = fadd <4 x double> %wide.load, %72
  store <4 x double> %73, ptr %71, align 8, !alias.scope !4, !noalias !6
  %74 = getelementptr double, ptr %70, i64 65
  %wide.load15 = load <4 x double>, ptr %74, align 8, !alias.scope !8
  %75 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %76 = fadd <4 x double> %73, %75
  store <4 x double> %76, ptr %71, align 8, !alias.scope !4, !noalias !6
  %77 = getelementptr double, ptr %70, i64 130
  %wide.load18 = load <4 x double>, ptr %77, align 8, !alias.scope !8
  %78 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %79 = fadd <4 x double> %76, %78
  store <4 x double> %79, ptr %71, align 8, !alias.scope !4, !noalias !6
  %80 = getelementptr double, ptr %70, i64 195
  %wide.load21 = load <4 x double>, ptr %80, align 8, !alias.scope !8
  %81 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %82 = fadd <4 x double> %79, %81
  store <4 x double> %82, ptr %71, align 8, !alias.scope !4, !noalias !6
  %83 = getelementptr double, ptr %70, i64 260
  %wide.load24 = load <4 x double>, ptr %83, align 8, !alias.scope !8
  %84 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %85 = fadd <4 x double> %82, %84
  store <4 x double> %85, ptr %71, align 8, !alias.scope !4, !noalias !6
  %86 = getelementptr double, ptr %70, i64 325
  %wide.load27 = load <4 x double>, ptr %86, align 8, !alias.scope !8
  %87 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %88 = fadd <4 x double> %85, %87
  store <4 x double> %88, ptr %71, align 8, !alias.scope !4, !noalias !6
  %89 = getelementptr double, ptr %70, i64 390
  %wide.load30 = load <4 x double>, ptr %89, align 8, !alias.scope !8
  %90 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %91 = fadd <4 x double> %88, %90
  store <4 x double> %91, ptr %71, align 8, !alias.scope !4, !noalias !6
  %92 = getelementptr double, ptr %70, i64 455
  %wide.load33 = load <4 x double>, ptr %92, align 8, !alias.scope !8
  %93 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %94 = fadd <4 x double> %91, %93
  store <4 x double> %94, ptr %71, align 8, !alias.scope !4, !noalias !6
  %95 = getelementptr double, ptr %70, i64 520
  %wide.load36 = load <4 x double>, ptr %95, align 8, !alias.scope !8
  %96 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %97 = fadd <4 x double> %94, %96
  store <4 x double> %97, ptr %71, align 8, !alias.scope !4, !noalias !6
  %98 = getelementptr double, ptr %70, i64 585
  %wide.load39 = load <4 x double>, ptr %98, align 8, !alias.scope !8
  %99 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %100 = fadd <4 x double> %97, %99
  store <4 x double> %100, ptr %71, align 8, !alias.scope !4, !noalias !6
  %101 = getelementptr double, ptr %70, i64 650
  %wide.load42 = load <4 x double>, ptr %101, align 8, !alias.scope !8
  %102 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %103 = fadd <4 x double> %100, %102
  store <4 x double> %103, ptr %71, align 8, !alias.scope !4, !noalias !6
  %104 = getelementptr double, ptr %70, i64 715
  %wide.load45 = load <4 x double>, ptr %104, align 8, !alias.scope !8
  %105 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %106 = fadd <4 x double> %103, %105
  store <4 x double> %106, ptr %71, align 8, !alias.scope !4, !noalias !6
  %107 = getelementptr double, ptr %70, i64 780
  %wide.load48 = load <4 x double>, ptr %107, align 8, !alias.scope !8
  %108 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %109 = fadd <4 x double> %106, %108
  store <4 x double> %109, ptr %71, align 8, !alias.scope !4, !noalias !6
  %110 = getelementptr double, ptr %70, i64 845
  %wide.load51 = load <4 x double>, ptr %110, align 8, !alias.scope !8
  %111 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %112 = fadd <4 x double> %109, %111
  store <4 x double> %112, ptr %71, align 8, !alias.scope !4, !noalias !6
  %113 = getelementptr double, ptr %70, i64 910
  %wide.load54 = load <4 x double>, ptr %113, align 8, !alias.scope !8
  %114 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %115 = fadd <4 x double> %112, %114
  store <4 x double> %115, ptr %71, align 8, !alias.scope !4, !noalias !6
  %116 = getelementptr double, ptr %70, i64 975
  %wide.load57 = load <4 x double>, ptr %116, align 8, !alias.scope !8
  %117 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %118 = fadd <4 x double> %115, %117
  store <4 x double> %118, ptr %71, align 8, !alias.scope !4, !noalias !6
  %119 = getelementptr double, ptr %70, i64 1040
  %wide.load60 = load <4 x double>, ptr %119, align 8, !alias.scope !8
  %120 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %121 = fadd <4 x double> %118, %120
  store <4 x double> %121, ptr %71, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %122 = icmp eq i64 %index.next, 64
  br i1 %122, label %.preheader.preheader, label %vector.body, !llvm.loop !9

.preheader.preheader:                             ; preds = %vector.body, %.preheader3
  %.ph = phi i64 [ 0, %.preheader3 ], [ 64, %vector.body ]
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %123 = phi i64 [ %193, %.preheader ], [ %.ph, %.preheader.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %123
  %124 = getelementptr double, ptr %36, i64 %123
  %.promoted = load double, ptr %124, align 8
  %125 = load double, ptr %34, align 8
  %126 = load double, ptr %invariant.gep, align 8
  %127 = fmul double %125, %126
  %128 = fadd double %.promoted, %127
  store double %128, ptr %124, align 8
  %129 = load double, ptr %37, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 65
  %130 = load double, ptr %gep.1, align 8
  %131 = fmul double %129, %130
  %132 = fadd double %128, %131
  store double %132, ptr %124, align 8
  %133 = load double, ptr %38, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 130
  %134 = load double, ptr %gep.2, align 8
  %135 = fmul double %133, %134
  %136 = fadd double %132, %135
  store double %136, ptr %124, align 8
  %137 = load double, ptr %39, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 195
  %138 = load double, ptr %gep.3, align 8
  %139 = fmul double %137, %138
  %140 = fadd double %136, %139
  store double %140, ptr %124, align 8
  %141 = load double, ptr %40, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 260
  %142 = load double, ptr %gep.4, align 8
  %143 = fmul double %141, %142
  %144 = fadd double %140, %143
  store double %144, ptr %124, align 8
  %145 = load double, ptr %41, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 325
  %146 = load double, ptr %gep.5, align 8
  %147 = fmul double %145, %146
  %148 = fadd double %144, %147
  store double %148, ptr %124, align 8
  %149 = load double, ptr %42, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 390
  %150 = load double, ptr %gep.6, align 8
  %151 = fmul double %149, %150
  %152 = fadd double %148, %151
  store double %152, ptr %124, align 8
  %153 = load double, ptr %43, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 455
  %154 = load double, ptr %gep.7, align 8
  %155 = fmul double %153, %154
  %156 = fadd double %152, %155
  store double %156, ptr %124, align 8
  %157 = load double, ptr %44, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 520
  %158 = load double, ptr %gep.8, align 8
  %159 = fmul double %157, %158
  %160 = fadd double %156, %159
  store double %160, ptr %124, align 8
  %161 = load double, ptr %45, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 585
  %162 = load double, ptr %gep.9, align 8
  %163 = fmul double %161, %162
  %164 = fadd double %160, %163
  store double %164, ptr %124, align 8
  %165 = load double, ptr %46, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 650
  %166 = load double, ptr %gep.10, align 8
  %167 = fmul double %165, %166
  %168 = fadd double %164, %167
  store double %168, ptr %124, align 8
  %169 = load double, ptr %47, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 715
  %170 = load double, ptr %gep.11, align 8
  %171 = fmul double %169, %170
  %172 = fadd double %168, %171
  store double %172, ptr %124, align 8
  %173 = load double, ptr %48, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 780
  %174 = load double, ptr %gep.12, align 8
  %175 = fmul double %173, %174
  %176 = fadd double %172, %175
  store double %176, ptr %124, align 8
  %177 = load double, ptr %49, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 845
  %178 = load double, ptr %gep.13, align 8
  %179 = fmul double %177, %178
  %180 = fadd double %176, %179
  store double %180, ptr %124, align 8
  %181 = load double, ptr %50, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 910
  %182 = load double, ptr %gep.14, align 8
  %183 = fmul double %181, %182
  %184 = fadd double %180, %183
  store double %184, ptr %124, align 8
  %185 = load double, ptr %51, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 975
  %186 = load double, ptr %gep.15, align 8
  %187 = fmul double %185, %186
  %188 = fadd double %184, %187
  store double %188, ptr %124, align 8
  %189 = load double, ptr %52, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1040
  %190 = load double, ptr %gep.16, align 8
  %191 = fmul double %189, %190
  %192 = fadd double %188, %191
  store double %192, ptr %124, align 8
  %193 = add nuw nsw i64 %123, 1
  %exitcond.not = icmp eq i64 %193, 65
  br i1 %exitcond.not, label %.loopexit, label %.preheader, !llvm.loop !12

.loopexit:                                        ; preds = %.preheader
  %194 = add nuw nsw i64 %32, 1
  %exitcond6.not = icmp eq i64 %194, %25
  br i1 %exitcond6.not, label %195, label %.preheader3

195:                                              ; preds = %.loopexit
  %196 = add nuw nsw i64 %21, 4
  %197 = icmp ult i64 %21, 27
  %indvar.next = add i64 %indvar, 1
  br i1 %197, label %.preheader4, label %198

198:                                              ; preds = %195
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
