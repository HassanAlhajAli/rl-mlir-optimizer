; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16120) %15, i8 0, i64 16120, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 8320
  %scevgep7 = getelementptr i8, ptr %1, i64 2176
  %scevgep8 = getelementptr i8, ptr %8, i64 8840
  %bound0 = icmp ugt ptr %scevgep7, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound09 = icmp ugt ptr %scevgep8, %15
  %bound110 = icmp ugt ptr %scevgep, %8
  %found.conflict11 = and i1 %bound09, %bound110
  %conflict.rdx = or i1 %found.conflict, %found.conflict11
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4.preheader, %.loopexit131
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %183, %.loopexit131 ]
  %22 = mul nuw nsw i64 %21, 17
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = mul nuw nsw i64 %21, 65
  %25 = getelementptr double, ptr %15, i64 %24
  %26 = getelementptr double, ptr %23, i64 1
  %27 = getelementptr double, ptr %23, i64 2
  %28 = getelementptr double, ptr %23, i64 3
  %29 = getelementptr double, ptr %23, i64 4
  %30 = getelementptr double, ptr %23, i64 5
  %31 = getelementptr double, ptr %23, i64 6
  %32 = getelementptr double, ptr %23, i64 7
  %33 = getelementptr double, ptr %23, i64 8
  %34 = getelementptr double, ptr %23, i64 9
  %35 = getelementptr double, ptr %23, i64 10
  %36 = getelementptr double, ptr %23, i64 11
  %37 = getelementptr double, ptr %23, i64 12
  %38 = getelementptr double, ptr %23, i64 13
  %39 = getelementptr double, ptr %23, i64 14
  %40 = getelementptr double, ptr %23, i64 15
  %41 = getelementptr double, ptr %23, i64 16
  br i1 %conflict.rdx, label %.preheader.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %42 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %42, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %43 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert14 = insertelement <4 x double> poison, double %43, i64 0
  %broadcast.splat15 = shufflevector <4 x double> %broadcast.splatinsert14, <4 x double> poison, <4 x i32> zeroinitializer
  %44 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert17 = insertelement <4 x double> poison, double %44, i64 0
  %broadcast.splat18 = shufflevector <4 x double> %broadcast.splatinsert17, <4 x double> poison, <4 x i32> zeroinitializer
  %45 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert20 = insertelement <4 x double> poison, double %45, i64 0
  %broadcast.splat21 = shufflevector <4 x double> %broadcast.splatinsert20, <4 x double> poison, <4 x i32> zeroinitializer
  %46 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert23 = insertelement <4 x double> poison, double %46, i64 0
  %broadcast.splat24 = shufflevector <4 x double> %broadcast.splatinsert23, <4 x double> poison, <4 x i32> zeroinitializer
  %47 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert26 = insertelement <4 x double> poison, double %47, i64 0
  %broadcast.splat27 = shufflevector <4 x double> %broadcast.splatinsert26, <4 x double> poison, <4 x i32> zeroinitializer
  %48 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert29 = insertelement <4 x double> poison, double %48, i64 0
  %broadcast.splat30 = shufflevector <4 x double> %broadcast.splatinsert29, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert32 = insertelement <4 x double> poison, double %49, i64 0
  %broadcast.splat33 = shufflevector <4 x double> %broadcast.splatinsert32, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert35 = insertelement <4 x double> poison, double %50, i64 0
  %broadcast.splat36 = shufflevector <4 x double> %broadcast.splatinsert35, <4 x double> poison, <4 x i32> zeroinitializer
  %51 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert38 = insertelement <4 x double> poison, double %51, i64 0
  %broadcast.splat39 = shufflevector <4 x double> %broadcast.splatinsert38, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert41 = insertelement <4 x double> poison, double %52, i64 0
  %broadcast.splat42 = shufflevector <4 x double> %broadcast.splatinsert41, <4 x double> poison, <4 x i32> zeroinitializer
  %53 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert44 = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat45 = shufflevector <4 x double> %broadcast.splatinsert44, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert47 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat48 = shufflevector <4 x double> %broadcast.splatinsert47, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert50 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat51 = shufflevector <4 x double> %broadcast.splatinsert50, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert53 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat54 = shufflevector <4 x double> %broadcast.splatinsert53, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert56 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat57 = shufflevector <4 x double> %broadcast.splatinsert56, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert59 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat60 = shufflevector <4 x double> %broadcast.splatinsert59, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %59 = getelementptr double, ptr %8, i64 %index
  %60 = getelementptr double, ptr %25, i64 %index
  %wide.load = load <4 x double>, ptr %60, align 8, !alias.scope !4, !noalias !6
  %wide.load12 = load <4 x double>, ptr %59, align 8, !alias.scope !8
  %61 = fmul <4 x double> %broadcast.splat, %wide.load12
  %62 = fadd <4 x double> %wide.load, %61
  store <4 x double> %62, ptr %60, align 8, !alias.scope !4, !noalias !6
  %63 = getelementptr double, ptr %59, i64 65
  %wide.load13 = load <4 x double>, ptr %63, align 8, !alias.scope !8
  %64 = fmul <4 x double> %broadcast.splat15, %wide.load13
  %65 = fadd <4 x double> %62, %64
  store <4 x double> %65, ptr %60, align 8, !alias.scope !4, !noalias !6
  %66 = getelementptr double, ptr %59, i64 130
  %wide.load16 = load <4 x double>, ptr %66, align 8, !alias.scope !8
  %67 = fmul <4 x double> %broadcast.splat18, %wide.load16
  %68 = fadd <4 x double> %65, %67
  store <4 x double> %68, ptr %60, align 8, !alias.scope !4, !noalias !6
  %69 = getelementptr double, ptr %59, i64 195
  %wide.load19 = load <4 x double>, ptr %69, align 8, !alias.scope !8
  %70 = fmul <4 x double> %broadcast.splat21, %wide.load19
  %71 = fadd <4 x double> %68, %70
  store <4 x double> %71, ptr %60, align 8, !alias.scope !4, !noalias !6
  %72 = getelementptr double, ptr %59, i64 260
  %wide.load22 = load <4 x double>, ptr %72, align 8, !alias.scope !8
  %73 = fmul <4 x double> %broadcast.splat24, %wide.load22
  %74 = fadd <4 x double> %71, %73
  store <4 x double> %74, ptr %60, align 8, !alias.scope !4, !noalias !6
  %75 = getelementptr double, ptr %59, i64 325
  %wide.load25 = load <4 x double>, ptr %75, align 8, !alias.scope !8
  %76 = fmul <4 x double> %broadcast.splat27, %wide.load25
  %77 = fadd <4 x double> %74, %76
  store <4 x double> %77, ptr %60, align 8, !alias.scope !4, !noalias !6
  %78 = getelementptr double, ptr %59, i64 390
  %wide.load28 = load <4 x double>, ptr %78, align 8, !alias.scope !8
  %79 = fmul <4 x double> %broadcast.splat30, %wide.load28
  %80 = fadd <4 x double> %77, %79
  store <4 x double> %80, ptr %60, align 8, !alias.scope !4, !noalias !6
  %81 = getelementptr double, ptr %59, i64 455
  %wide.load31 = load <4 x double>, ptr %81, align 8, !alias.scope !8
  %82 = fmul <4 x double> %broadcast.splat33, %wide.load31
  %83 = fadd <4 x double> %80, %82
  store <4 x double> %83, ptr %60, align 8, !alias.scope !4, !noalias !6
  %84 = getelementptr double, ptr %59, i64 520
  %wide.load34 = load <4 x double>, ptr %84, align 8, !alias.scope !8
  %85 = fmul <4 x double> %broadcast.splat36, %wide.load34
  %86 = fadd <4 x double> %83, %85
  store <4 x double> %86, ptr %60, align 8, !alias.scope !4, !noalias !6
  %87 = getelementptr double, ptr %59, i64 585
  %wide.load37 = load <4 x double>, ptr %87, align 8, !alias.scope !8
  %88 = fmul <4 x double> %broadcast.splat39, %wide.load37
  %89 = fadd <4 x double> %86, %88
  store <4 x double> %89, ptr %60, align 8, !alias.scope !4, !noalias !6
  %90 = getelementptr double, ptr %59, i64 650
  %wide.load40 = load <4 x double>, ptr %90, align 8, !alias.scope !8
  %91 = fmul <4 x double> %broadcast.splat42, %wide.load40
  %92 = fadd <4 x double> %89, %91
  store <4 x double> %92, ptr %60, align 8, !alias.scope !4, !noalias !6
  %93 = getelementptr double, ptr %59, i64 715
  %wide.load43 = load <4 x double>, ptr %93, align 8, !alias.scope !8
  %94 = fmul <4 x double> %broadcast.splat45, %wide.load43
  %95 = fadd <4 x double> %92, %94
  store <4 x double> %95, ptr %60, align 8, !alias.scope !4, !noalias !6
  %96 = getelementptr double, ptr %59, i64 780
  %wide.load46 = load <4 x double>, ptr %96, align 8, !alias.scope !8
  %97 = fmul <4 x double> %broadcast.splat48, %wide.load46
  %98 = fadd <4 x double> %95, %97
  store <4 x double> %98, ptr %60, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %59, i64 845
  %wide.load49 = load <4 x double>, ptr %99, align 8, !alias.scope !8
  %100 = fmul <4 x double> %broadcast.splat51, %wide.load49
  %101 = fadd <4 x double> %98, %100
  store <4 x double> %101, ptr %60, align 8, !alias.scope !4, !noalias !6
  %102 = getelementptr double, ptr %59, i64 910
  %wide.load52 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %103 = fmul <4 x double> %broadcast.splat54, %wide.load52
  %104 = fadd <4 x double> %101, %103
  store <4 x double> %104, ptr %60, align 8, !alias.scope !4, !noalias !6
  %105 = getelementptr double, ptr %59, i64 975
  %wide.load55 = load <4 x double>, ptr %105, align 8, !alias.scope !8
  %106 = fmul <4 x double> %broadcast.splat57, %wide.load55
  %107 = fadd <4 x double> %104, %106
  store <4 x double> %107, ptr %60, align 8, !alias.scope !4, !noalias !6
  %108 = getelementptr double, ptr %59, i64 1040
  %wide.load58 = load <4 x double>, ptr %108, align 8, !alias.scope !8
  %109 = fmul <4 x double> %broadcast.splat60, %wide.load58
  %110 = fadd <4 x double> %107, %109
  store <4 x double> %110, ptr %60, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %111 = icmp eq i64 %index.next, 64
  br i1 %111, label %.preheader.preheader, label %vector.body, !llvm.loop !9

.preheader.preheader:                             ; preds = %vector.body, %.preheader3
  %.ph132 = phi i64 [ 0, %.preheader3 ], [ 64, %vector.body ]
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %112 = phi i64 [ %182, %.preheader ], [ %.ph132, %.preheader.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %112
  %113 = getelementptr double, ptr %25, i64 %112
  %.promoted = load double, ptr %113, align 8
  %114 = load double, ptr %23, align 8
  %115 = load double, ptr %invariant.gep, align 8
  %116 = fmul double %114, %115
  %117 = fadd double %.promoted, %116
  store double %117, ptr %113, align 8
  %118 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 65
  %119 = load double, ptr %gep.1, align 8
  %120 = fmul double %118, %119
  %121 = fadd double %117, %120
  store double %121, ptr %113, align 8
  %122 = load double, ptr %27, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 130
  %123 = load double, ptr %gep.2, align 8
  %124 = fmul double %122, %123
  %125 = fadd double %121, %124
  store double %125, ptr %113, align 8
  %126 = load double, ptr %28, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 195
  %127 = load double, ptr %gep.3, align 8
  %128 = fmul double %126, %127
  %129 = fadd double %125, %128
  store double %129, ptr %113, align 8
  %130 = load double, ptr %29, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 260
  %131 = load double, ptr %gep.4, align 8
  %132 = fmul double %130, %131
  %133 = fadd double %129, %132
  store double %133, ptr %113, align 8
  %134 = load double, ptr %30, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 325
  %135 = load double, ptr %gep.5, align 8
  %136 = fmul double %134, %135
  %137 = fadd double %133, %136
  store double %137, ptr %113, align 8
  %138 = load double, ptr %31, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 390
  %139 = load double, ptr %gep.6, align 8
  %140 = fmul double %138, %139
  %141 = fadd double %137, %140
  store double %141, ptr %113, align 8
  %142 = load double, ptr %32, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 455
  %143 = load double, ptr %gep.7, align 8
  %144 = fmul double %142, %143
  %145 = fadd double %141, %144
  store double %145, ptr %113, align 8
  %146 = load double, ptr %33, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 520
  %147 = load double, ptr %gep.8, align 8
  %148 = fmul double %146, %147
  %149 = fadd double %145, %148
  store double %149, ptr %113, align 8
  %150 = load double, ptr %34, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 585
  %151 = load double, ptr %gep.9, align 8
  %152 = fmul double %150, %151
  %153 = fadd double %149, %152
  store double %153, ptr %113, align 8
  %154 = load double, ptr %35, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 650
  %155 = load double, ptr %gep.10, align 8
  %156 = fmul double %154, %155
  %157 = fadd double %153, %156
  store double %157, ptr %113, align 8
  %158 = load double, ptr %36, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 715
  %159 = load double, ptr %gep.11, align 8
  %160 = fmul double %158, %159
  %161 = fadd double %157, %160
  store double %161, ptr %113, align 8
  %162 = load double, ptr %37, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 780
  %163 = load double, ptr %gep.12, align 8
  %164 = fmul double %162, %163
  %165 = fadd double %161, %164
  store double %165, ptr %113, align 8
  %166 = load double, ptr %38, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 845
  %167 = load double, ptr %gep.13, align 8
  %168 = fmul double %166, %167
  %169 = fadd double %165, %168
  store double %169, ptr %113, align 8
  %170 = load double, ptr %39, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 910
  %171 = load double, ptr %gep.14, align 8
  %172 = fmul double %170, %171
  %173 = fadd double %169, %172
  store double %173, ptr %113, align 8
  %174 = load double, ptr %40, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 975
  %175 = load double, ptr %gep.15, align 8
  %176 = fmul double %174, %175
  %177 = fadd double %173, %176
  store double %177, ptr %113, align 8
  %178 = load double, ptr %41, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1040
  %179 = load double, ptr %gep.16, align 8
  %180 = fmul double %178, %179
  %181 = fadd double %177, %180
  store double %181, ptr %113, align 8
  %182 = add nuw nsw i64 %112, 1
  %exitcond.not = icmp eq i64 %182, 65
  br i1 %exitcond.not, label %.loopexit131, label %.preheader, !llvm.loop !12

.loopexit131:                                     ; preds = %.preheader
  %183 = add nuw nsw i64 %21, 1
  %exitcond6.not = icmp eq i64 %183, 16
  br i1 %exitcond6.not, label %.preheader4.1, label %.preheader3

.preheader4.1:                                    ; preds = %.loopexit131
  %184 = getelementptr double, ptr %1, i64 272
  %185 = getelementptr double, ptr %15, i64 1040
  %scevgep62 = getelementptr i8, ptr %15, i64 16120
  %scevgep63 = getelementptr i8, ptr %1, i64 4216
  %scevgep64 = getelementptr i8, ptr %8, i64 8840
  %bound065 = icmp ult ptr %185, %scevgep63
  %bound166 = icmp ult ptr %184, %scevgep62
  %found.conflict67 = and i1 %bound065, %bound166
  %bound068 = icmp ult ptr %185, %scevgep64
  %bound169 = icmp ugt ptr %scevgep62, %8
  %found.conflict70 = and i1 %bound068, %bound169
  %conflict.rdx71 = or i1 %found.conflict67, %found.conflict70
  br label %.preheader3.1

.preheader3.1:                                    ; preds = %.loopexit, %.preheader4.1
  %186 = phi i64 [ 0, %.preheader4.1 ], [ %348, %.loopexit ]
  %187 = mul nuw nsw i64 %186, 17
  %188 = getelementptr double, ptr %184, i64 %187
  %189 = mul nuw nsw i64 %186, 65
  %190 = getelementptr double, ptr %185, i64 %189
  %191 = getelementptr double, ptr %188, i64 1
  %192 = getelementptr double, ptr %188, i64 2
  %193 = getelementptr double, ptr %188, i64 3
  %194 = getelementptr double, ptr %188, i64 4
  %195 = getelementptr double, ptr %188, i64 5
  %196 = getelementptr double, ptr %188, i64 6
  %197 = getelementptr double, ptr %188, i64 7
  %198 = getelementptr double, ptr %188, i64 8
  %199 = getelementptr double, ptr %188, i64 9
  %200 = getelementptr double, ptr %188, i64 10
  %201 = getelementptr double, ptr %188, i64 11
  %202 = getelementptr double, ptr %188, i64 12
  %203 = getelementptr double, ptr %188, i64 13
  %204 = getelementptr double, ptr %188, i64 14
  %205 = getelementptr double, ptr %188, i64 15
  %206 = getelementptr double, ptr %188, i64 16
  br i1 %conflict.rdx71, label %.preheader.1.preheader, label %vector.body76.preheader

vector.body76.preheader:                          ; preds = %.preheader3.1
  %207 = load double, ptr %188, align 8, !alias.scope !13
  %broadcast.splatinsert80 = insertelement <4 x double> poison, double %207, i64 0
  %broadcast.splat81 = shufflevector <4 x double> %broadcast.splatinsert80, <4 x double> poison, <4 x i32> zeroinitializer
  %208 = load double, ptr %191, align 8, !alias.scope !13
  %broadcast.splatinsert83 = insertelement <4 x double> poison, double %208, i64 0
  %broadcast.splat84 = shufflevector <4 x double> %broadcast.splatinsert83, <4 x double> poison, <4 x i32> zeroinitializer
  %209 = load double, ptr %192, align 8, !alias.scope !13
  %broadcast.splatinsert86 = insertelement <4 x double> poison, double %209, i64 0
  %broadcast.splat87 = shufflevector <4 x double> %broadcast.splatinsert86, <4 x double> poison, <4 x i32> zeroinitializer
  %210 = load double, ptr %193, align 8, !alias.scope !13
  %broadcast.splatinsert89 = insertelement <4 x double> poison, double %210, i64 0
  %broadcast.splat90 = shufflevector <4 x double> %broadcast.splatinsert89, <4 x double> poison, <4 x i32> zeroinitializer
  %211 = load double, ptr %194, align 8, !alias.scope !13
  %broadcast.splatinsert92 = insertelement <4 x double> poison, double %211, i64 0
  %broadcast.splat93 = shufflevector <4 x double> %broadcast.splatinsert92, <4 x double> poison, <4 x i32> zeroinitializer
  %212 = load double, ptr %195, align 8, !alias.scope !13
  %broadcast.splatinsert95 = insertelement <4 x double> poison, double %212, i64 0
  %broadcast.splat96 = shufflevector <4 x double> %broadcast.splatinsert95, <4 x double> poison, <4 x i32> zeroinitializer
  %213 = load double, ptr %196, align 8, !alias.scope !13
  %broadcast.splatinsert98 = insertelement <4 x double> poison, double %213, i64 0
  %broadcast.splat99 = shufflevector <4 x double> %broadcast.splatinsert98, <4 x double> poison, <4 x i32> zeroinitializer
  %214 = load double, ptr %197, align 8, !alias.scope !13
  %broadcast.splatinsert101 = insertelement <4 x double> poison, double %214, i64 0
  %broadcast.splat102 = shufflevector <4 x double> %broadcast.splatinsert101, <4 x double> poison, <4 x i32> zeroinitializer
  %215 = load double, ptr %198, align 8, !alias.scope !13
  %broadcast.splatinsert104 = insertelement <4 x double> poison, double %215, i64 0
  %broadcast.splat105 = shufflevector <4 x double> %broadcast.splatinsert104, <4 x double> poison, <4 x i32> zeroinitializer
  %216 = load double, ptr %199, align 8, !alias.scope !13
  %broadcast.splatinsert107 = insertelement <4 x double> poison, double %216, i64 0
  %broadcast.splat108 = shufflevector <4 x double> %broadcast.splatinsert107, <4 x double> poison, <4 x i32> zeroinitializer
  %217 = load double, ptr %200, align 8, !alias.scope !13
  %broadcast.splatinsert110 = insertelement <4 x double> poison, double %217, i64 0
  %broadcast.splat111 = shufflevector <4 x double> %broadcast.splatinsert110, <4 x double> poison, <4 x i32> zeroinitializer
  %218 = load double, ptr %201, align 8, !alias.scope !13
  %broadcast.splatinsert113 = insertelement <4 x double> poison, double %218, i64 0
  %broadcast.splat114 = shufflevector <4 x double> %broadcast.splatinsert113, <4 x double> poison, <4 x i32> zeroinitializer
  %219 = load double, ptr %202, align 8, !alias.scope !13
  %broadcast.splatinsert116 = insertelement <4 x double> poison, double %219, i64 0
  %broadcast.splat117 = shufflevector <4 x double> %broadcast.splatinsert116, <4 x double> poison, <4 x i32> zeroinitializer
  %220 = load double, ptr %203, align 8, !alias.scope !13
  %broadcast.splatinsert119 = insertelement <4 x double> poison, double %220, i64 0
  %broadcast.splat120 = shufflevector <4 x double> %broadcast.splatinsert119, <4 x double> poison, <4 x i32> zeroinitializer
  %221 = load double, ptr %204, align 8, !alias.scope !13
  %broadcast.splatinsert122 = insertelement <4 x double> poison, double %221, i64 0
  %broadcast.splat123 = shufflevector <4 x double> %broadcast.splatinsert122, <4 x double> poison, <4 x i32> zeroinitializer
  %222 = load double, ptr %205, align 8, !alias.scope !13
  %broadcast.splatinsert125 = insertelement <4 x double> poison, double %222, i64 0
  %broadcast.splat126 = shufflevector <4 x double> %broadcast.splatinsert125, <4 x double> poison, <4 x i32> zeroinitializer
  %223 = load double, ptr %206, align 8, !alias.scope !13
  %broadcast.splatinsert128 = insertelement <4 x double> poison, double %223, i64 0
  %broadcast.splat129 = shufflevector <4 x double> %broadcast.splatinsert128, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body76

vector.body76:                                    ; preds = %vector.body76.preheader, %vector.body76
  %index77 = phi i64 [ %index.next130, %vector.body76 ], [ 0, %vector.body76.preheader ]
  %224 = getelementptr double, ptr %8, i64 %index77
  %225 = getelementptr double, ptr %190, i64 %index77
  %wide.load78 = load <4 x double>, ptr %225, align 8, !alias.scope !16, !noalias !18
  %wide.load79 = load <4 x double>, ptr %224, align 8, !alias.scope !20
  %226 = fmul <4 x double> %broadcast.splat81, %wide.load79
  %227 = fadd <4 x double> %wide.load78, %226
  store <4 x double> %227, ptr %225, align 8, !alias.scope !16, !noalias !18
  %228 = getelementptr double, ptr %224, i64 65
  %wide.load82 = load <4 x double>, ptr %228, align 8, !alias.scope !20
  %229 = fmul <4 x double> %broadcast.splat84, %wide.load82
  %230 = fadd <4 x double> %227, %229
  store <4 x double> %230, ptr %225, align 8, !alias.scope !16, !noalias !18
  %231 = getelementptr double, ptr %224, i64 130
  %wide.load85 = load <4 x double>, ptr %231, align 8, !alias.scope !20
  %232 = fmul <4 x double> %broadcast.splat87, %wide.load85
  %233 = fadd <4 x double> %230, %232
  store <4 x double> %233, ptr %225, align 8, !alias.scope !16, !noalias !18
  %234 = getelementptr double, ptr %224, i64 195
  %wide.load88 = load <4 x double>, ptr %234, align 8, !alias.scope !20
  %235 = fmul <4 x double> %broadcast.splat90, %wide.load88
  %236 = fadd <4 x double> %233, %235
  store <4 x double> %236, ptr %225, align 8, !alias.scope !16, !noalias !18
  %237 = getelementptr double, ptr %224, i64 260
  %wide.load91 = load <4 x double>, ptr %237, align 8, !alias.scope !20
  %238 = fmul <4 x double> %broadcast.splat93, %wide.load91
  %239 = fadd <4 x double> %236, %238
  store <4 x double> %239, ptr %225, align 8, !alias.scope !16, !noalias !18
  %240 = getelementptr double, ptr %224, i64 325
  %wide.load94 = load <4 x double>, ptr %240, align 8, !alias.scope !20
  %241 = fmul <4 x double> %broadcast.splat96, %wide.load94
  %242 = fadd <4 x double> %239, %241
  store <4 x double> %242, ptr %225, align 8, !alias.scope !16, !noalias !18
  %243 = getelementptr double, ptr %224, i64 390
  %wide.load97 = load <4 x double>, ptr %243, align 8, !alias.scope !20
  %244 = fmul <4 x double> %broadcast.splat99, %wide.load97
  %245 = fadd <4 x double> %242, %244
  store <4 x double> %245, ptr %225, align 8, !alias.scope !16, !noalias !18
  %246 = getelementptr double, ptr %224, i64 455
  %wide.load100 = load <4 x double>, ptr %246, align 8, !alias.scope !20
  %247 = fmul <4 x double> %broadcast.splat102, %wide.load100
  %248 = fadd <4 x double> %245, %247
  store <4 x double> %248, ptr %225, align 8, !alias.scope !16, !noalias !18
  %249 = getelementptr double, ptr %224, i64 520
  %wide.load103 = load <4 x double>, ptr %249, align 8, !alias.scope !20
  %250 = fmul <4 x double> %broadcast.splat105, %wide.load103
  %251 = fadd <4 x double> %248, %250
  store <4 x double> %251, ptr %225, align 8, !alias.scope !16, !noalias !18
  %252 = getelementptr double, ptr %224, i64 585
  %wide.load106 = load <4 x double>, ptr %252, align 8, !alias.scope !20
  %253 = fmul <4 x double> %broadcast.splat108, %wide.load106
  %254 = fadd <4 x double> %251, %253
  store <4 x double> %254, ptr %225, align 8, !alias.scope !16, !noalias !18
  %255 = getelementptr double, ptr %224, i64 650
  %wide.load109 = load <4 x double>, ptr %255, align 8, !alias.scope !20
  %256 = fmul <4 x double> %broadcast.splat111, %wide.load109
  %257 = fadd <4 x double> %254, %256
  store <4 x double> %257, ptr %225, align 8, !alias.scope !16, !noalias !18
  %258 = getelementptr double, ptr %224, i64 715
  %wide.load112 = load <4 x double>, ptr %258, align 8, !alias.scope !20
  %259 = fmul <4 x double> %broadcast.splat114, %wide.load112
  %260 = fadd <4 x double> %257, %259
  store <4 x double> %260, ptr %225, align 8, !alias.scope !16, !noalias !18
  %261 = getelementptr double, ptr %224, i64 780
  %wide.load115 = load <4 x double>, ptr %261, align 8, !alias.scope !20
  %262 = fmul <4 x double> %broadcast.splat117, %wide.load115
  %263 = fadd <4 x double> %260, %262
  store <4 x double> %263, ptr %225, align 8, !alias.scope !16, !noalias !18
  %264 = getelementptr double, ptr %224, i64 845
  %wide.load118 = load <4 x double>, ptr %264, align 8, !alias.scope !20
  %265 = fmul <4 x double> %broadcast.splat120, %wide.load118
  %266 = fadd <4 x double> %263, %265
  store <4 x double> %266, ptr %225, align 8, !alias.scope !16, !noalias !18
  %267 = getelementptr double, ptr %224, i64 910
  %wide.load121 = load <4 x double>, ptr %267, align 8, !alias.scope !20
  %268 = fmul <4 x double> %broadcast.splat123, %wide.load121
  %269 = fadd <4 x double> %266, %268
  store <4 x double> %269, ptr %225, align 8, !alias.scope !16, !noalias !18
  %270 = getelementptr double, ptr %224, i64 975
  %wide.load124 = load <4 x double>, ptr %270, align 8, !alias.scope !20
  %271 = fmul <4 x double> %broadcast.splat126, %wide.load124
  %272 = fadd <4 x double> %269, %271
  store <4 x double> %272, ptr %225, align 8, !alias.scope !16, !noalias !18
  %273 = getelementptr double, ptr %224, i64 1040
  %wide.load127 = load <4 x double>, ptr %273, align 8, !alias.scope !20
  %274 = fmul <4 x double> %broadcast.splat129, %wide.load127
  %275 = fadd <4 x double> %272, %274
  store <4 x double> %275, ptr %225, align 8, !alias.scope !16, !noalias !18
  %index.next130 = add nuw i64 %index77, 4
  %276 = icmp eq i64 %index.next130, 64
  br i1 %276, label %.preheader.1.preheader, label %vector.body76, !llvm.loop !21

.preheader.1.preheader:                           ; preds = %vector.body76, %.preheader3.1
  %.ph = phi i64 [ 0, %.preheader3.1 ], [ 64, %vector.body76 ]
  br label %.preheader.1

.preheader.1:                                     ; preds = %.preheader.1.preheader, %.preheader.1
  %277 = phi i64 [ %347, %.preheader.1 ], [ %.ph, %.preheader.1.preheader ]
  %invariant.gep.1 = getelementptr double, ptr %8, i64 %277
  %278 = getelementptr double, ptr %190, i64 %277
  %.promoted.1 = load double, ptr %278, align 8
  %279 = load double, ptr %188, align 8
  %280 = load double, ptr %invariant.gep.1, align 8
  %281 = fmul double %279, %280
  %282 = fadd double %.promoted.1, %281
  store double %282, ptr %278, align 8
  %283 = load double, ptr %191, align 8
  %gep.1.1 = getelementptr double, ptr %invariant.gep.1, i64 65
  %284 = load double, ptr %gep.1.1, align 8
  %285 = fmul double %283, %284
  %286 = fadd double %282, %285
  store double %286, ptr %278, align 8
  %287 = load double, ptr %192, align 8
  %gep.2.1 = getelementptr double, ptr %invariant.gep.1, i64 130
  %288 = load double, ptr %gep.2.1, align 8
  %289 = fmul double %287, %288
  %290 = fadd double %286, %289
  store double %290, ptr %278, align 8
  %291 = load double, ptr %193, align 8
  %gep.3.1 = getelementptr double, ptr %invariant.gep.1, i64 195
  %292 = load double, ptr %gep.3.1, align 8
  %293 = fmul double %291, %292
  %294 = fadd double %290, %293
  store double %294, ptr %278, align 8
  %295 = load double, ptr %194, align 8
  %gep.4.1 = getelementptr double, ptr %invariant.gep.1, i64 260
  %296 = load double, ptr %gep.4.1, align 8
  %297 = fmul double %295, %296
  %298 = fadd double %294, %297
  store double %298, ptr %278, align 8
  %299 = load double, ptr %195, align 8
  %gep.5.1 = getelementptr double, ptr %invariant.gep.1, i64 325
  %300 = load double, ptr %gep.5.1, align 8
  %301 = fmul double %299, %300
  %302 = fadd double %298, %301
  store double %302, ptr %278, align 8
  %303 = load double, ptr %196, align 8
  %gep.6.1 = getelementptr double, ptr %invariant.gep.1, i64 390
  %304 = load double, ptr %gep.6.1, align 8
  %305 = fmul double %303, %304
  %306 = fadd double %302, %305
  store double %306, ptr %278, align 8
  %307 = load double, ptr %197, align 8
  %gep.7.1 = getelementptr double, ptr %invariant.gep.1, i64 455
  %308 = load double, ptr %gep.7.1, align 8
  %309 = fmul double %307, %308
  %310 = fadd double %306, %309
  store double %310, ptr %278, align 8
  %311 = load double, ptr %198, align 8
  %gep.8.1 = getelementptr double, ptr %invariant.gep.1, i64 520
  %312 = load double, ptr %gep.8.1, align 8
  %313 = fmul double %311, %312
  %314 = fadd double %310, %313
  store double %314, ptr %278, align 8
  %315 = load double, ptr %199, align 8
  %gep.9.1 = getelementptr double, ptr %invariant.gep.1, i64 585
  %316 = load double, ptr %gep.9.1, align 8
  %317 = fmul double %315, %316
  %318 = fadd double %314, %317
  store double %318, ptr %278, align 8
  %319 = load double, ptr %200, align 8
  %gep.10.1 = getelementptr double, ptr %invariant.gep.1, i64 650
  %320 = load double, ptr %gep.10.1, align 8
  %321 = fmul double %319, %320
  %322 = fadd double %318, %321
  store double %322, ptr %278, align 8
  %323 = load double, ptr %201, align 8
  %gep.11.1 = getelementptr double, ptr %invariant.gep.1, i64 715
  %324 = load double, ptr %gep.11.1, align 8
  %325 = fmul double %323, %324
  %326 = fadd double %322, %325
  store double %326, ptr %278, align 8
  %327 = load double, ptr %202, align 8
  %gep.12.1 = getelementptr double, ptr %invariant.gep.1, i64 780
  %328 = load double, ptr %gep.12.1, align 8
  %329 = fmul double %327, %328
  %330 = fadd double %326, %329
  store double %330, ptr %278, align 8
  %331 = load double, ptr %203, align 8
  %gep.13.1 = getelementptr double, ptr %invariant.gep.1, i64 845
  %332 = load double, ptr %gep.13.1, align 8
  %333 = fmul double %331, %332
  %334 = fadd double %330, %333
  store double %334, ptr %278, align 8
  %335 = load double, ptr %204, align 8
  %gep.14.1 = getelementptr double, ptr %invariant.gep.1, i64 910
  %336 = load double, ptr %gep.14.1, align 8
  %337 = fmul double %335, %336
  %338 = fadd double %334, %337
  store double %338, ptr %278, align 8
  %339 = load double, ptr %205, align 8
  %gep.15.1 = getelementptr double, ptr %invariant.gep.1, i64 975
  %340 = load double, ptr %gep.15.1, align 8
  %341 = fmul double %339, %340
  %342 = fadd double %338, %341
  store double %342, ptr %278, align 8
  %343 = load double, ptr %206, align 8
  %gep.16.1 = getelementptr double, ptr %invariant.gep.1, i64 1040
  %344 = load double, ptr %gep.16.1, align 8
  %345 = fmul double %343, %344
  %346 = fadd double %342, %345
  store double %346, ptr %278, align 8
  %347 = add nuw nsw i64 %277, 1
  %exitcond.1.not = icmp eq i64 %347, 65
  br i1 %exitcond.1.not, label %.loopexit, label %.preheader.1, !llvm.loop !22

.loopexit:                                        ; preds = %.preheader.1
  %348 = add nuw nsw i64 %186, 1
  %exitcond6.1.not = icmp eq i64 %348, 15
  br i1 %exitcond6.1.not, label %349, label %.preheader3.1

349:                                              ; preds = %.loopexit
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
!13 = !{!14}
!14 = distinct !{!14, !15}
!15 = distinct !{!15, !"LVerDomain"}
!16 = !{!17}
!17 = distinct !{!17, !15}
!18 = !{!14, !19}
!19 = distinct !{!19, !15}
!20 = !{!19}
!21 = distinct !{!21, !10, !11}
!22 = distinct !{!22, !10}
