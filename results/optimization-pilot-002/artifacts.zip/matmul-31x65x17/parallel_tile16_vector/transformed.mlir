#map = affine_map<(d0) -> (-d0 + 31, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0) -> (-d0 + 65, 16)>
#map3 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map4 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<31x17xf64>, %arg1: memref<17x65xf64>, %arg2: memref<31x65xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_2 = arith.constant 0 : index
    %c16_3 = arith.constant 16 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<31x65xf64>)
    %c0_6 = arith.constant 0 : index
    %c31 = arith.constant 31 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_6 to %c31 step %c16_7 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 17] [1, 1] : memref<31x17xf64> to memref<?x17xf64, strided<[17, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [%1, 65] [1, 1] : memref<31x65xf64> to memref<?x65xf64, strided<[65, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c0_10 = arith.constant 0 : index
      %c0_11 = arith.constant 0 : index
      %c65 = arith.constant 65 : index
      %c16_12 = arith.constant 16 : index
      scf.for %arg4 = %c0_11 to %c65 step %c16_12 {
        %2 = affine.apply #map1(%0)
        %3 = affine.apply #map1(%0)
        %4 = affine.min #map2(%arg4)
        %c0_13 = arith.constant 0 : index
        %5 = affine.apply #map1(%0)
        %6 = affine.min #map2(%arg4)
        %subview_14 = memref.subview %arg1[0, %arg4] [17, %4] [1, 1] : memref<17x65xf64> to memref<17x?xf64, strided<[65, 1], offset: ?>>
        %subview_15 = memref.subview %subview_8[0, %arg4] [%1, %6] [1, 1] : memref<?x65xf64, strided<[65, 1], offset: ?>> to memref<?x?xf64, strided<[65, 1], offset: ?>>
        %c0_16 = arith.constant 0 : index
        %c1_17 = arith.constant 1 : index
        %c0_18 = arith.constant 0 : index
        %c1_19 = arith.constant 1 : index
        %c0_20 = arith.constant 0 : index
        %c17 = arith.constant 17 : index
        %c1_21 = arith.constant 1 : index
        scf.for %arg5 = %c0_20 to %c17 step %c1_21 {
          %7 = affine.apply #map1(%0)
          %8 = affine.apply #map1(%4)
          %c0_22 = arith.constant 0 : index
          %c1_23 = arith.constant 1 : index
          %subview_24 = memref.subview %subview[0, %arg5] [%0, 1] [1, 1] : memref<?x17xf64, strided<[17, 1], offset: ?>> to memref<?x1xf64, strided<[17, 1], offset: ?>>
          %subview_25 = memref.subview %subview_14[%arg5, 0] [1, %4] [1, 1] : memref<17x?xf64, strided<[65, 1], offset: ?>> to memref<1x?xf64, strided<[65, 1], offset: ?>>
          %c0_26 = arith.constant 0 : index
          %dim = memref.dim %subview_24, %c0_26 : memref<?x1xf64, strided<[17, 1], offset: ?>>
          %c1_27 = arith.constant 1 : index
          %dim_28 = memref.dim %subview_25, %c1_27 : memref<1x?xf64, strided<[65, 1], offset: ?>>
          %c1_29 = arith.constant 1 : index
          %c0_30 = arith.constant 0 : index
          %cst_31 = arith.constant 0.000000e+00 : f64
          %9 = vector.create_mask %dim, %c1_29 : vector<16x1xi1>
          %10 = vector.mask %9 { vector.transfer_read %subview_24[%c0_30, %c0_30], %cst_31 {in_bounds = [true, true, true], permutation_map = #map3} : memref<?x1xf64, strided<[17, 1], offset: ?>>, vector<16x16x1xf64> } : vector<16x1xi1> -> vector<16x16x1xf64>
          %cst_32 = arith.constant 0.000000e+00 : f64
          %11 = vector.create_mask %c1_29, %dim_28 : vector<1x16xi1>
          %12 = vector.mask %11 { vector.transfer_read %subview_25[%c0_30, %c0_30], %cst_32 {in_bounds = [true, true, true], permutation_map = #map4} : memref<1x?xf64, strided<[65, 1], offset: ?>>, vector<16x16x1xf64> } : vector<1x16xi1> -> vector<16x16x1xf64>
          %cst_33 = arith.constant 0.000000e+00 : f64
          %13 = vector.create_mask %dim, %dim_28 : vector<16x16xi1>
          %14 = vector.mask %13 { vector.transfer_read %subview_15[%c0_30, %c0_30], %cst_33 {in_bounds = [true, true]} : memref<?x?xf64, strided<[65, 1], offset: ?>>, vector<16x16xf64> } : vector<16x16xi1> -> vector<16x16xf64>
          %15 = arith.mulf %10, %12 : vector<16x16x1xf64>
          %16 = vector.create_mask %dim, %dim_28, %c1_29 : vector<16x16x1xi1>
          %17 = vector.mask %16 { vector.multi_reduction <add>, %15, %14 [2] : vector<16x16x1xf64> to vector<16x16xf64> } : vector<16x16x1xi1> -> vector<16x16xf64>
          %c0_34 = arith.constant 0 : index
          vector.mask %13 { vector.transfer_write %17, %subview_15[%c0_34, %c0_34] {in_bounds = [true, true]} : vector<16x16xf64>, memref<?x?xf64, strided<[65, 1], offset: ?>> } : vector<16x16xi1>
        }
      }
    }
    return
  }
}
