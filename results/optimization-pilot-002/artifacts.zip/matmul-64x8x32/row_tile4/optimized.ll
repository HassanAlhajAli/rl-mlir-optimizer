; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %226
  %21 = phi i64 [ %227, %226 ], [ 0, %.preheader4.preheader ]
  %22 = shl nuw nsw i64 %21, 5
  %23 = shl nuw nsw i64 %21, 3
  %24 = getelementptr double, ptr %1, i64 %22
  %25 = getelementptr double, ptr %15, i64 %23
  %26 = getelementptr double, ptr %24, i64 1
  %27 = getelementptr double, ptr %24, i64 2
  %28 = getelementptr double, ptr %24, i64 3
  %29 = getelementptr double, ptr %24, i64 4
  %30 = getelementptr double, ptr %24, i64 5
  %31 = getelementptr double, ptr %24, i64 6
  %32 = getelementptr double, ptr %24, i64 7
  %33 = getelementptr double, ptr %24, i64 8
  %34 = getelementptr double, ptr %24, i64 9
  %35 = getelementptr double, ptr %24, i64 10
  %36 = getelementptr double, ptr %24, i64 11
  %37 = getelementptr double, ptr %24, i64 12
  %38 = getelementptr double, ptr %24, i64 13
  %39 = getelementptr double, ptr %24, i64 14
  %40 = getelementptr double, ptr %24, i64 15
  %41 = getelementptr double, ptr %24, i64 16
  %42 = getelementptr double, ptr %24, i64 17
  %43 = getelementptr double, ptr %24, i64 18
  %44 = getelementptr double, ptr %24, i64 19
  %45 = getelementptr double, ptr %24, i64 20
  %46 = getelementptr double, ptr %24, i64 21
  %47 = getelementptr double, ptr %24, i64 22
  %48 = getelementptr double, ptr %24, i64 23
  %49 = getelementptr double, ptr %24, i64 24
  %50 = getelementptr double, ptr %24, i64 25
  %51 = getelementptr double, ptr %24, i64 26
  %52 = getelementptr double, ptr %24, i64 27
  %53 = getelementptr double, ptr %24, i64 28
  %54 = getelementptr double, ptr %24, i64 29
  %55 = getelementptr double, ptr %24, i64 30
  %56 = getelementptr double, ptr %24, i64 31
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %224
  %57 = phi i64 [ 0, %.preheader4 ], [ %225, %224 ]
  %58 = shl i64 %57, 5
  %59 = shl i64 %57, 3
  %60 = getelementptr double, ptr %25, i64 %59
  %61 = getelementptr double, ptr %24, i64 %58
  %62 = getelementptr double, ptr %26, i64 %58
  %63 = getelementptr double, ptr %27, i64 %58
  %64 = getelementptr double, ptr %28, i64 %58
  %65 = getelementptr double, ptr %29, i64 %58
  %66 = getelementptr double, ptr %30, i64 %58
  %67 = getelementptr double, ptr %31, i64 %58
  %68 = getelementptr double, ptr %32, i64 %58
  %69 = getelementptr double, ptr %33, i64 %58
  %70 = getelementptr double, ptr %34, i64 %58
  %71 = getelementptr double, ptr %35, i64 %58
  %72 = getelementptr double, ptr %36, i64 %58
  %73 = getelementptr double, ptr %37, i64 %58
  %74 = getelementptr double, ptr %38, i64 %58
  %75 = getelementptr double, ptr %39, i64 %58
  %76 = getelementptr double, ptr %40, i64 %58
  %77 = getelementptr double, ptr %41, i64 %58
  %78 = getelementptr double, ptr %42, i64 %58
  %79 = getelementptr double, ptr %43, i64 %58
  %80 = getelementptr double, ptr %44, i64 %58
  %81 = getelementptr double, ptr %45, i64 %58
  %82 = getelementptr double, ptr %46, i64 %58
  %83 = getelementptr double, ptr %47, i64 %58
  %84 = getelementptr double, ptr %48, i64 %58
  %85 = getelementptr double, ptr %49, i64 %58
  %86 = getelementptr double, ptr %50, i64 %58
  %87 = getelementptr double, ptr %51, i64 %58
  %88 = getelementptr double, ptr %52, i64 %58
  %89 = getelementptr double, ptr %53, i64 %58
  %90 = getelementptr double, ptr %54, i64 %58
  %91 = getelementptr double, ptr %55, i64 %58
  %92 = getelementptr double, ptr %56, i64 %58
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %.preheader
  %93 = phi i64 [ 0, %.preheader3 ], [ %223, %.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %93
  %94 = getelementptr double, ptr %60, i64 %93
  %.promoted = load double, ptr %94, align 8
  %95 = load double, ptr %61, align 8
  %96 = load double, ptr %invariant.gep, align 8
  %97 = fmul double %95, %96
  %98 = fadd double %.promoted, %97
  store double %98, ptr %94, align 8
  %99 = load double, ptr %62, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 8
  %100 = load double, ptr %gep.1, align 8
  %101 = fmul double %99, %100
  %102 = fadd double %98, %101
  store double %102, ptr %94, align 8
  %103 = load double, ptr %63, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 16
  %104 = load double, ptr %gep.2, align 8
  %105 = fmul double %103, %104
  %106 = fadd double %102, %105
  store double %106, ptr %94, align 8
  %107 = load double, ptr %64, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 24
  %108 = load double, ptr %gep.3, align 8
  %109 = fmul double %107, %108
  %110 = fadd double %106, %109
  store double %110, ptr %94, align 8
  %111 = load double, ptr %65, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 32
  %112 = load double, ptr %gep.4, align 8
  %113 = fmul double %111, %112
  %114 = fadd double %110, %113
  store double %114, ptr %94, align 8
  %115 = load double, ptr %66, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 40
  %116 = load double, ptr %gep.5, align 8
  %117 = fmul double %115, %116
  %118 = fadd double %114, %117
  store double %118, ptr %94, align 8
  %119 = load double, ptr %67, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 48
  %120 = load double, ptr %gep.6, align 8
  %121 = fmul double %119, %120
  %122 = fadd double %118, %121
  store double %122, ptr %94, align 8
  %123 = load double, ptr %68, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 56
  %124 = load double, ptr %gep.7, align 8
  %125 = fmul double %123, %124
  %126 = fadd double %122, %125
  store double %126, ptr %94, align 8
  %127 = load double, ptr %69, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 64
  %128 = load double, ptr %gep.8, align 8
  %129 = fmul double %127, %128
  %130 = fadd double %126, %129
  store double %130, ptr %94, align 8
  %131 = load double, ptr %70, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 72
  %132 = load double, ptr %gep.9, align 8
  %133 = fmul double %131, %132
  %134 = fadd double %130, %133
  store double %134, ptr %94, align 8
  %135 = load double, ptr %71, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 80
  %136 = load double, ptr %gep.10, align 8
  %137 = fmul double %135, %136
  %138 = fadd double %134, %137
  store double %138, ptr %94, align 8
  %139 = load double, ptr %72, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 88
  %140 = load double, ptr %gep.11, align 8
  %141 = fmul double %139, %140
  %142 = fadd double %138, %141
  store double %142, ptr %94, align 8
  %143 = load double, ptr %73, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 96
  %144 = load double, ptr %gep.12, align 8
  %145 = fmul double %143, %144
  %146 = fadd double %142, %145
  store double %146, ptr %94, align 8
  %147 = load double, ptr %74, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 104
  %148 = load double, ptr %gep.13, align 8
  %149 = fmul double %147, %148
  %150 = fadd double %146, %149
  store double %150, ptr %94, align 8
  %151 = load double, ptr %75, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 112
  %152 = load double, ptr %gep.14, align 8
  %153 = fmul double %151, %152
  %154 = fadd double %150, %153
  store double %154, ptr %94, align 8
  %155 = load double, ptr %76, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 120
  %156 = load double, ptr %gep.15, align 8
  %157 = fmul double %155, %156
  %158 = fadd double %154, %157
  store double %158, ptr %94, align 8
  %159 = load double, ptr %77, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 128
  %160 = load double, ptr %gep.16, align 8
  %161 = fmul double %159, %160
  %162 = fadd double %158, %161
  store double %162, ptr %94, align 8
  %163 = load double, ptr %78, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 136
  %164 = load double, ptr %gep.17, align 8
  %165 = fmul double %163, %164
  %166 = fadd double %162, %165
  store double %166, ptr %94, align 8
  %167 = load double, ptr %79, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 144
  %168 = load double, ptr %gep.18, align 8
  %169 = fmul double %167, %168
  %170 = fadd double %166, %169
  store double %170, ptr %94, align 8
  %171 = load double, ptr %80, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 152
  %172 = load double, ptr %gep.19, align 8
  %173 = fmul double %171, %172
  %174 = fadd double %170, %173
  store double %174, ptr %94, align 8
  %175 = load double, ptr %81, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 160
  %176 = load double, ptr %gep.20, align 8
  %177 = fmul double %175, %176
  %178 = fadd double %174, %177
  store double %178, ptr %94, align 8
  %179 = load double, ptr %82, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 168
  %180 = load double, ptr %gep.21, align 8
  %181 = fmul double %179, %180
  %182 = fadd double %178, %181
  store double %182, ptr %94, align 8
  %183 = load double, ptr %83, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 176
  %184 = load double, ptr %gep.22, align 8
  %185 = fmul double %183, %184
  %186 = fadd double %182, %185
  store double %186, ptr %94, align 8
  %187 = load double, ptr %84, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 184
  %188 = load double, ptr %gep.23, align 8
  %189 = fmul double %187, %188
  %190 = fadd double %186, %189
  store double %190, ptr %94, align 8
  %191 = load double, ptr %85, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 192
  %192 = load double, ptr %gep.24, align 8
  %193 = fmul double %191, %192
  %194 = fadd double %190, %193
  store double %194, ptr %94, align 8
  %195 = load double, ptr %86, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 200
  %196 = load double, ptr %gep.25, align 8
  %197 = fmul double %195, %196
  %198 = fadd double %194, %197
  store double %198, ptr %94, align 8
  %199 = load double, ptr %87, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 208
  %200 = load double, ptr %gep.26, align 8
  %201 = fmul double %199, %200
  %202 = fadd double %198, %201
  store double %202, ptr %94, align 8
  %203 = load double, ptr %88, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 216
  %204 = load double, ptr %gep.27, align 8
  %205 = fmul double %203, %204
  %206 = fadd double %202, %205
  store double %206, ptr %94, align 8
  %207 = load double, ptr %89, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 224
  %208 = load double, ptr %gep.28, align 8
  %209 = fmul double %207, %208
  %210 = fadd double %206, %209
  store double %210, ptr %94, align 8
  %211 = load double, ptr %90, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 232
  %212 = load double, ptr %gep.29, align 8
  %213 = fmul double %211, %212
  %214 = fadd double %210, %213
  store double %214, ptr %94, align 8
  %215 = load double, ptr %91, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 240
  %216 = load double, ptr %gep.30, align 8
  %217 = fmul double %215, %216
  %218 = fadd double %214, %217
  store double %218, ptr %94, align 8
  %219 = load double, ptr %92, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 248
  %220 = load double, ptr %gep.31, align 8
  %221 = fmul double %219, %220
  %222 = fadd double %218, %221
  store double %222, ptr %94, align 8
  %223 = add nuw nsw i64 %93, 1
  %exitcond.not = icmp eq i64 %223, 8
  br i1 %exitcond.not, label %224, label %.preheader

224:                                              ; preds = %.preheader
  %225 = add nuw nsw i64 %57, 1
  %exitcond6.not = icmp eq i64 %225, 4
  br i1 %exitcond6.not, label %226, label %.preheader3

226:                                              ; preds = %224
  %227 = add nuw nsw i64 %21, 4
  %228 = icmp ult i64 %21, 60
  br i1 %228, label %.preheader4, label %229

229:                                              ; preds = %226
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
