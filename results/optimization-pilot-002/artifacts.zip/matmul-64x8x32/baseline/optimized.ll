; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %15, i8 0, i64 4096, i1 false)
  %21 = getelementptr double, ptr %1, i64 1
  %22 = getelementptr double, ptr %1, i64 2
  %23 = getelementptr double, ptr %1, i64 3
  %24 = getelementptr double, ptr %1, i64 4
  %25 = getelementptr double, ptr %1, i64 5
  %26 = getelementptr double, ptr %1, i64 6
  %27 = getelementptr double, ptr %1, i64 7
  %28 = getelementptr double, ptr %1, i64 8
  %29 = getelementptr double, ptr %1, i64 9
  %30 = getelementptr double, ptr %1, i64 10
  %31 = getelementptr double, ptr %1, i64 11
  %32 = getelementptr double, ptr %1, i64 12
  %33 = getelementptr double, ptr %1, i64 13
  %34 = getelementptr double, ptr %1, i64 14
  %35 = getelementptr double, ptr %1, i64 15
  %36 = getelementptr double, ptr %1, i64 16
  %37 = getelementptr double, ptr %1, i64 17
  %38 = getelementptr double, ptr %1, i64 18
  %39 = getelementptr double, ptr %1, i64 19
  %40 = getelementptr double, ptr %1, i64 20
  %41 = getelementptr double, ptr %1, i64 21
  %42 = getelementptr double, ptr %1, i64 22
  %43 = getelementptr double, ptr %1, i64 23
  %44 = getelementptr double, ptr %1, i64 24
  %45 = getelementptr double, ptr %1, i64 25
  %46 = getelementptr double, ptr %1, i64 26
  %47 = getelementptr double, ptr %1, i64 27
  %48 = getelementptr double, ptr %1, i64 28
  %49 = getelementptr double, ptr %1, i64 29
  %50 = getelementptr double, ptr %1, i64 30
  %51 = getelementptr double, ptr %1, i64 31
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %219
  %52 = phi i64 [ %220, %219 ], [ 0, %.preheader2.preheader ]
  %53 = shl i64 %52, 5
  %54 = shl i64 %52, 3
  %55 = getelementptr double, ptr %15, i64 %54
  %56 = getelementptr double, ptr %1, i64 %53
  %57 = getelementptr double, ptr %21, i64 %53
  %58 = getelementptr double, ptr %22, i64 %53
  %59 = getelementptr double, ptr %23, i64 %53
  %60 = getelementptr double, ptr %24, i64 %53
  %61 = getelementptr double, ptr %25, i64 %53
  %62 = getelementptr double, ptr %26, i64 %53
  %63 = getelementptr double, ptr %27, i64 %53
  %64 = getelementptr double, ptr %28, i64 %53
  %65 = getelementptr double, ptr %29, i64 %53
  %66 = getelementptr double, ptr %30, i64 %53
  %67 = getelementptr double, ptr %31, i64 %53
  %68 = getelementptr double, ptr %32, i64 %53
  %69 = getelementptr double, ptr %33, i64 %53
  %70 = getelementptr double, ptr %34, i64 %53
  %71 = getelementptr double, ptr %35, i64 %53
  %72 = getelementptr double, ptr %36, i64 %53
  %73 = getelementptr double, ptr %37, i64 %53
  %74 = getelementptr double, ptr %38, i64 %53
  %75 = getelementptr double, ptr %39, i64 %53
  %76 = getelementptr double, ptr %40, i64 %53
  %77 = getelementptr double, ptr %41, i64 %53
  %78 = getelementptr double, ptr %42, i64 %53
  %79 = getelementptr double, ptr %43, i64 %53
  %80 = getelementptr double, ptr %44, i64 %53
  %81 = getelementptr double, ptr %45, i64 %53
  %82 = getelementptr double, ptr %46, i64 %53
  %83 = getelementptr double, ptr %47, i64 %53
  %84 = getelementptr double, ptr %48, i64 %53
  %85 = getelementptr double, ptr %49, i64 %53
  %86 = getelementptr double, ptr %50, i64 %53
  %87 = getelementptr double, ptr %51, i64 %53
  br label %.preheader

.preheader:                                       ; preds = %.preheader2, %.preheader
  %88 = phi i64 [ 0, %.preheader2 ], [ %218, %.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %88
  %89 = getelementptr double, ptr %55, i64 %88
  %.promoted = load double, ptr %89, align 8
  %90 = load double, ptr %56, align 8
  %91 = load double, ptr %invariant.gep, align 8
  %92 = fmul double %90, %91
  %93 = fadd double %.promoted, %92
  store double %93, ptr %89, align 8
  %94 = load double, ptr %57, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 8
  %95 = load double, ptr %gep.1, align 8
  %96 = fmul double %94, %95
  %97 = fadd double %93, %96
  store double %97, ptr %89, align 8
  %98 = load double, ptr %58, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 16
  %99 = load double, ptr %gep.2, align 8
  %100 = fmul double %98, %99
  %101 = fadd double %97, %100
  store double %101, ptr %89, align 8
  %102 = load double, ptr %59, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 24
  %103 = load double, ptr %gep.3, align 8
  %104 = fmul double %102, %103
  %105 = fadd double %101, %104
  store double %105, ptr %89, align 8
  %106 = load double, ptr %60, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 32
  %107 = load double, ptr %gep.4, align 8
  %108 = fmul double %106, %107
  %109 = fadd double %105, %108
  store double %109, ptr %89, align 8
  %110 = load double, ptr %61, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 40
  %111 = load double, ptr %gep.5, align 8
  %112 = fmul double %110, %111
  %113 = fadd double %109, %112
  store double %113, ptr %89, align 8
  %114 = load double, ptr %62, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 48
  %115 = load double, ptr %gep.6, align 8
  %116 = fmul double %114, %115
  %117 = fadd double %113, %116
  store double %117, ptr %89, align 8
  %118 = load double, ptr %63, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 56
  %119 = load double, ptr %gep.7, align 8
  %120 = fmul double %118, %119
  %121 = fadd double %117, %120
  store double %121, ptr %89, align 8
  %122 = load double, ptr %64, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 64
  %123 = load double, ptr %gep.8, align 8
  %124 = fmul double %122, %123
  %125 = fadd double %121, %124
  store double %125, ptr %89, align 8
  %126 = load double, ptr %65, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 72
  %127 = load double, ptr %gep.9, align 8
  %128 = fmul double %126, %127
  %129 = fadd double %125, %128
  store double %129, ptr %89, align 8
  %130 = load double, ptr %66, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 80
  %131 = load double, ptr %gep.10, align 8
  %132 = fmul double %130, %131
  %133 = fadd double %129, %132
  store double %133, ptr %89, align 8
  %134 = load double, ptr %67, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 88
  %135 = load double, ptr %gep.11, align 8
  %136 = fmul double %134, %135
  %137 = fadd double %133, %136
  store double %137, ptr %89, align 8
  %138 = load double, ptr %68, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 96
  %139 = load double, ptr %gep.12, align 8
  %140 = fmul double %138, %139
  %141 = fadd double %137, %140
  store double %141, ptr %89, align 8
  %142 = load double, ptr %69, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 104
  %143 = load double, ptr %gep.13, align 8
  %144 = fmul double %142, %143
  %145 = fadd double %141, %144
  store double %145, ptr %89, align 8
  %146 = load double, ptr %70, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 112
  %147 = load double, ptr %gep.14, align 8
  %148 = fmul double %146, %147
  %149 = fadd double %145, %148
  store double %149, ptr %89, align 8
  %150 = load double, ptr %71, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 120
  %151 = load double, ptr %gep.15, align 8
  %152 = fmul double %150, %151
  %153 = fadd double %149, %152
  store double %153, ptr %89, align 8
  %154 = load double, ptr %72, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 128
  %155 = load double, ptr %gep.16, align 8
  %156 = fmul double %154, %155
  %157 = fadd double %153, %156
  store double %157, ptr %89, align 8
  %158 = load double, ptr %73, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 136
  %159 = load double, ptr %gep.17, align 8
  %160 = fmul double %158, %159
  %161 = fadd double %157, %160
  store double %161, ptr %89, align 8
  %162 = load double, ptr %74, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 144
  %163 = load double, ptr %gep.18, align 8
  %164 = fmul double %162, %163
  %165 = fadd double %161, %164
  store double %165, ptr %89, align 8
  %166 = load double, ptr %75, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 152
  %167 = load double, ptr %gep.19, align 8
  %168 = fmul double %166, %167
  %169 = fadd double %165, %168
  store double %169, ptr %89, align 8
  %170 = load double, ptr %76, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 160
  %171 = load double, ptr %gep.20, align 8
  %172 = fmul double %170, %171
  %173 = fadd double %169, %172
  store double %173, ptr %89, align 8
  %174 = load double, ptr %77, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 168
  %175 = load double, ptr %gep.21, align 8
  %176 = fmul double %174, %175
  %177 = fadd double %173, %176
  store double %177, ptr %89, align 8
  %178 = load double, ptr %78, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 176
  %179 = load double, ptr %gep.22, align 8
  %180 = fmul double %178, %179
  %181 = fadd double %177, %180
  store double %181, ptr %89, align 8
  %182 = load double, ptr %79, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 184
  %183 = load double, ptr %gep.23, align 8
  %184 = fmul double %182, %183
  %185 = fadd double %181, %184
  store double %185, ptr %89, align 8
  %186 = load double, ptr %80, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 192
  %187 = load double, ptr %gep.24, align 8
  %188 = fmul double %186, %187
  %189 = fadd double %185, %188
  store double %189, ptr %89, align 8
  %190 = load double, ptr %81, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 200
  %191 = load double, ptr %gep.25, align 8
  %192 = fmul double %190, %191
  %193 = fadd double %189, %192
  store double %193, ptr %89, align 8
  %194 = load double, ptr %82, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 208
  %195 = load double, ptr %gep.26, align 8
  %196 = fmul double %194, %195
  %197 = fadd double %193, %196
  store double %197, ptr %89, align 8
  %198 = load double, ptr %83, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 216
  %199 = load double, ptr %gep.27, align 8
  %200 = fmul double %198, %199
  %201 = fadd double %197, %200
  store double %201, ptr %89, align 8
  %202 = load double, ptr %84, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 224
  %203 = load double, ptr %gep.28, align 8
  %204 = fmul double %202, %203
  %205 = fadd double %201, %204
  store double %205, ptr %89, align 8
  %206 = load double, ptr %85, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 232
  %207 = load double, ptr %gep.29, align 8
  %208 = fmul double %206, %207
  %209 = fadd double %205, %208
  store double %209, ptr %89, align 8
  %210 = load double, ptr %86, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 240
  %211 = load double, ptr %gep.30, align 8
  %212 = fmul double %210, %211
  %213 = fadd double %209, %212
  store double %213, ptr %89, align 8
  %214 = load double, ptr %87, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 248
  %215 = load double, ptr %gep.31, align 8
  %216 = fmul double %214, %215
  %217 = fadd double %213, %216
  store double %217, ptr %89, align 8
  %218 = add nuw nsw i64 %88, 1
  %exitcond.not = icmp eq i64 %218, 8
  br i1 %exitcond.not, label %219, label %.preheader

219:                                              ; preds = %.preheader
  %220 = add nuw nsw i64 %52, 1
  %exitcond5.not = icmp eq i64 %220, 64
  br i1 %exitcond5.not, label %221, label %.preheader2

221:                                              ; preds = %219
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
