#map = affine_map<(d0) -> (-d0 + 8, 16)>
#map1 = affine_map<(d0) -> (d0 - 1)>
#map2 = affine_map<(d0, d1) -> (d0, 0, d1)>
#map3 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<64x32xf64>, %arg1: memref<32x8xf64>, %arg2: memref<64x8xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c16 = arith.constant 16 : index
    %c0_2 = arith.constant 0 : index
    %c16_3 = arith.constant 16 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<64x8xf64>)
    %c0_6 = arith.constant 0 : index
    %c64 = arith.constant 64 : index
    %c16_7 = arith.constant 16 : index
    scf.for %arg3 = %c0_6 to %c64 step %c16_7 {
      %subview = memref.subview %arg0[%arg3, 0] [16, 32] [1, 1] : memref<64x32xf64> to memref<16x32xf64, strided<[32, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [16, 8] [1, 1] : memref<64x8xf64> to memref<16x8xf64, strided<[8, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c8 = arith.constant 8 : index
      %c16_10 = arith.constant 16 : index
      scf.for %arg4 = %c0_9 to %c8 step %c16_10 {
        %0 = affine.min #map(%arg4)
        %1 = affine.min #map(%arg4)
        %subview_11 = memref.subview %arg1[0, %arg4] [32, %0] [1, 1] : memref<32x8xf64> to memref<32x?xf64, strided<[8, 1], offset: ?>>
        %subview_12 = memref.subview %subview_8[0, %arg4] [16, %1] [1, 1] : memref<16x8xf64, strided<[8, 1], offset: ?>> to memref<16x?xf64, strided<[8, 1], offset: ?>>
        %c1_13 = arith.constant 1 : index
        %c1_14 = arith.constant 1 : index
        %c0_15 = arith.constant 0 : index
        %c32 = arith.constant 32 : index
        %c1_16 = arith.constant 1 : index
        scf.for %arg5 = %c0_15 to %c32 step %c1_16 {
          %2 = affine.apply #map1(%0)
          %c1_17 = arith.constant 1 : index
          %subview_18 = memref.subview %subview[0, %arg5] [16, 1] [1, 1] : memref<16x32xf64, strided<[32, 1], offset: ?>> to memref<16x1xf64, strided<[32, 1], offset: ?>>
          %subview_19 = memref.subview %subview_11[%arg5, 0] [1, %0] [1, 1] : memref<32x?xf64, strided<[8, 1], offset: ?>> to memref<1x?xf64, strided<[8, 1], offset: ?>>
          %c16_20 = arith.constant 16 : index
          %c1_21 = arith.constant 1 : index
          %dim = memref.dim %subview_19, %c1_21 : memref<1x?xf64, strided<[8, 1], offset: ?>>
          %c1_22 = arith.constant 1 : index
          %c0_23 = arith.constant 0 : index
          %cst_24 = arith.constant 0.000000e+00 : f64
          %3 = vector.transfer_read %subview_18[%c0_23, %c0_23], %cst_24 {permutation_map = #map2} : memref<16x1xf64, strided<[32, 1], offset: ?>>, vector<16x8x1xf64>
          %cst_25 = arith.constant 0.000000e+00 : f64
          %4 = vector.create_mask %c1_22, %dim : vector<1x8xi1>
          %5 = vector.mask %4 { vector.transfer_read %subview_19[%c0_23, %c0_23], %cst_25 {in_bounds = [true, true, true], permutation_map = #map3} : memref<1x?xf64, strided<[8, 1], offset: ?>>, vector<16x8x1xf64> } : vector<1x8xi1> -> vector<16x8x1xf64>
          %cst_26 = arith.constant 0.000000e+00 : f64
          %6 = vector.create_mask %c16_20, %dim : vector<16x8xi1>
          %7 = vector.mask %6 { vector.transfer_read %subview_12[%c0_23, %c0_23], %cst_26 {in_bounds = [true, true]} : memref<16x?xf64, strided<[8, 1], offset: ?>>, vector<16x8xf64> } : vector<16x8xi1> -> vector<16x8xf64>
          %8 = arith.mulf %3, %5 : vector<16x8x1xf64>
          %9 = vector.create_mask %c16_20, %dim, %c1_22 : vector<16x8x1xi1>
          %10 = vector.mask %9 { vector.multi_reduction <add>, %8, %7 [2] : vector<16x8x1xf64> to vector<16x8xf64> } : vector<16x8x1xi1> -> vector<16x8xf64>
          %c0_27 = arith.constant 0 : index
          vector.mask %6 { vector.transfer_write %10, %subview_12[%c0_27, %c0_27] {in_bounds = [true, true]} : vector<16x8xf64>, memref<16x?xf64, strided<[8, 1], offset: ?>> } : vector<16x8xi1>
        }
      }
    }
    return
  }
}
