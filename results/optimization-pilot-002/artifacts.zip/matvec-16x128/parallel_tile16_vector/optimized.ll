; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %17, %.preheader
  %18 = phi i64 [ 0, %17 ], [ %74, %.preheader ]
  %19 = phi <16 x double> [ zeroinitializer, %17 ], [ %73, %.preheader ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %20, i64 128
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %20, i64 256
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %20, i64 384
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %20, i64 512
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %20, i64 640
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %20, i64 768
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %20, i64 896
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %20, i64 1024
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %20, i64 1152
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %20, i64 1280
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %20, i64 1408
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %20, i64 1536
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %20, i64 1664
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %20, i64 1792
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %20, i64 1920
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %8, i64 %18
  %53 = load double, ptr %52, align 8
  %54 = insertelement <16 x double> poison, double %21, i64 0
  %55 = insertelement <16 x double> %54, double %23, i64 1
  %56 = insertelement <16 x double> %55, double %25, i64 2
  %57 = insertelement <16 x double> %56, double %27, i64 3
  %58 = insertelement <16 x double> %57, double %29, i64 4
  %59 = insertelement <16 x double> %58, double %31, i64 5
  %60 = insertelement <16 x double> %59, double %33, i64 6
  %61 = insertelement <16 x double> %60, double %35, i64 7
  %62 = insertelement <16 x double> %61, double %37, i64 8
  %63 = insertelement <16 x double> %62, double %39, i64 9
  %64 = insertelement <16 x double> %63, double %41, i64 10
  %65 = insertelement <16 x double> %64, double %43, i64 11
  %66 = insertelement <16 x double> %65, double %45, i64 12
  %67 = insertelement <16 x double> %66, double %47, i64 13
  %68 = insertelement <16 x double> %67, double %49, i64 14
  %69 = insertelement <16 x double> %68, double %51, i64 15
  %70 = insertelement <16 x double> poison, double %53, i64 0
  %71 = shufflevector <16 x double> %70, <16 x double> poison, <16 x i32> zeroinitializer
  %72 = fmul <16 x double> %69, %71
  %73 = fadd <16 x double> %19, %72
  store <16 x double> %73, ptr %13, align 8
  %74 = add nuw nsw i64 %18, 1
  %exitcond.not = icmp eq i64 %74, 128
  br i1 %exitcond.not, label %75, label %.preheader

75:                                               ; preds = %.preheader
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28, i8 0, i64 128, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %3
  %4 = phi i64 [ 0, %3 ], [ %60, %.preheader.i ]
  %5 = phi <16 x double> [ zeroinitializer, %3 ], [ %59, %.preheader.i ]
  %6 = getelementptr double, ptr %.unpack2, i64 %4
  %7 = load double, ptr %6, align 8
  %8 = getelementptr double, ptr %6, i64 128
  %9 = load double, ptr %8, align 8
  %10 = getelementptr double, ptr %6, i64 256
  %11 = load double, ptr %10, align 8
  %12 = getelementptr double, ptr %6, i64 384
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %6, i64 512
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %6, i64 640
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %6, i64 768
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %6, i64 896
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %6, i64 1024
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %6, i64 1152
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %6, i64 1280
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %6, i64 1408
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %6, i64 1536
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %6, i64 1664
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %6, i64 1792
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %6, i64 1920
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %.unpack17, i64 %4
  %39 = load double, ptr %38, align 8
  %40 = insertelement <16 x double> poison, double %7, i64 0
  %41 = insertelement <16 x double> %40, double %9, i64 1
  %42 = insertelement <16 x double> %41, double %11, i64 2
  %43 = insertelement <16 x double> %42, double %13, i64 3
  %44 = insertelement <16 x double> %43, double %15, i64 4
  %45 = insertelement <16 x double> %44, double %17, i64 5
  %46 = insertelement <16 x double> %45, double %19, i64 6
  %47 = insertelement <16 x double> %46, double %21, i64 7
  %48 = insertelement <16 x double> %47, double %23, i64 8
  %49 = insertelement <16 x double> %48, double %25, i64 9
  %50 = insertelement <16 x double> %49, double %27, i64 10
  %51 = insertelement <16 x double> %50, double %29, i64 11
  %52 = insertelement <16 x double> %51, double %31, i64 12
  %53 = insertelement <16 x double> %52, double %33, i64 13
  %54 = insertelement <16 x double> %53, double %35, i64 14
  %55 = insertelement <16 x double> %54, double %37, i64 15
  %56 = insertelement <16 x double> poison, double %39, i64 0
  %57 = shufflevector <16 x double> %56, <16 x double> poison, <16 x i32> zeroinitializer
  %58 = fmul <16 x double> %55, %57
  %59 = fadd <16 x double> %5, %58
  store <16 x double> %59, ptr %.unpack28, align 8
  %60 = add nuw nsw i64 %4, 1
  %exitcond.not.i = icmp eq i64 %60, 128
  br i1 %exitcond.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %.preheader.i
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %10, i8 0, i64 128, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %.preheader.i, %1
  %11 = phi i64 [ 0, %1 ], [ %67, %.preheader.i ]
  %12 = phi <16 x double> [ zeroinitializer, %1 ], [ %66, %.preheader.i ]
  %13 = getelementptr double, ptr %4, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 384
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %13, i64 512
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %13, i64 640
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %13, i64 768
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %13, i64 896
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %13, i64 1024
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %13, i64 1152
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %13, i64 1280
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %13, i64 1408
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %13, i64 1536
  %38 = load double, ptr %37, align 8
  %39 = getelementptr double, ptr %13, i64 1664
  %40 = load double, ptr %39, align 8
  %41 = getelementptr double, ptr %13, i64 1792
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %13, i64 1920
  %44 = load double, ptr %43, align 8
  %45 = getelementptr double, ptr %7, i64 %11
  %46 = load double, ptr %45, align 8
  %47 = insertelement <16 x double> poison, double %14, i64 0
  %48 = insertelement <16 x double> %47, double %16, i64 1
  %49 = insertelement <16 x double> %48, double %18, i64 2
  %50 = insertelement <16 x double> %49, double %20, i64 3
  %51 = insertelement <16 x double> %50, double %22, i64 4
  %52 = insertelement <16 x double> %51, double %24, i64 5
  %53 = insertelement <16 x double> %52, double %26, i64 6
  %54 = insertelement <16 x double> %53, double %28, i64 7
  %55 = insertelement <16 x double> %54, double %30, i64 8
  %56 = insertelement <16 x double> %55, double %32, i64 9
  %57 = insertelement <16 x double> %56, double %34, i64 10
  %58 = insertelement <16 x double> %57, double %36, i64 11
  %59 = insertelement <16 x double> %58, double %38, i64 12
  %60 = insertelement <16 x double> %59, double %40, i64 13
  %61 = insertelement <16 x double> %60, double %42, i64 14
  %62 = insertelement <16 x double> %61, double %44, i64 15
  %63 = insertelement <16 x double> poison, double %46, i64 0
  %64 = shufflevector <16 x double> %63, <16 x double> poison, <16 x i32> zeroinitializer
  %65 = fmul <16 x double> %62, %64
  %66 = fadd <16 x double> %12, %65
  store <16 x double> %66, ptr %10, align 8
  %67 = add nuw nsw i64 %11, 1
  %exitcond.not.i = icmp eq i64 %67, 128
  br i1 %exitcond.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %.preheader.i
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28.i, i8 0, i64 128, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %.preheader.i.i, %1
  %10 = phi i64 [ 0, %1 ], [ %66, %.preheader.i.i ]
  %11 = phi <16 x double> [ zeroinitializer, %1 ], [ %65, %.preheader.i.i ]
  %12 = getelementptr double, ptr %.unpack2.i, i64 %10
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %12, i64 128
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %12, i64 256
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %12, i64 384
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %12, i64 512
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %12, i64 640
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %12, i64 768
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %12, i64 896
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %12, i64 1024
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %12, i64 1152
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %12, i64 1280
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %12, i64 1408
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %12, i64 1536
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %12, i64 1664
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %12, i64 1792
  %41 = load double, ptr %40, align 8
  %42 = getelementptr double, ptr %12, i64 1920
  %43 = load double, ptr %42, align 8
  %44 = getelementptr double, ptr %.unpack17.i, i64 %10
  %45 = load double, ptr %44, align 8
  %46 = insertelement <16 x double> poison, double %13, i64 0
  %47 = insertelement <16 x double> %46, double %15, i64 1
  %48 = insertelement <16 x double> %47, double %17, i64 2
  %49 = insertelement <16 x double> %48, double %19, i64 3
  %50 = insertelement <16 x double> %49, double %21, i64 4
  %51 = insertelement <16 x double> %50, double %23, i64 5
  %52 = insertelement <16 x double> %51, double %25, i64 6
  %53 = insertelement <16 x double> %52, double %27, i64 7
  %54 = insertelement <16 x double> %53, double %29, i64 8
  %55 = insertelement <16 x double> %54, double %31, i64 9
  %56 = insertelement <16 x double> %55, double %33, i64 10
  %57 = insertelement <16 x double> %56, double %35, i64 11
  %58 = insertelement <16 x double> %57, double %37, i64 12
  %59 = insertelement <16 x double> %58, double %39, i64 13
  %60 = insertelement <16 x double> %59, double %41, i64 14
  %61 = insertelement <16 x double> %60, double %43, i64 15
  %62 = insertelement <16 x double> poison, double %45, i64 0
  %63 = shufflevector <16 x double> %62, <16 x double> poison, <16 x i32> zeroinitializer
  %64 = fmul <16 x double> %61, %63
  %65 = fadd <16 x double> %11, %64
  store <16 x double> %65, ptr %.unpack28.i, align 8
  %66 = add nuw nsw i64 %10, 1
  %exitcond.not.i.i = icmp eq i64 %66, 128
  br i1 %exitcond.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader.i.i

_mlir_ciface_kernel.exit:                         ; preds = %.preheader.i.i
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
