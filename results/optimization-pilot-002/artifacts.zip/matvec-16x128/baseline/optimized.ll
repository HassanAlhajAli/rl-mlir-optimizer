; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader.preheader
  %18 = phi i64 [ 0, %.preheader.preheader ], [ %75, %17 ]
  %19 = phi double [ 0.000000e+00, %.preheader.preheader ], [ %74, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %8, i64 %18
  %23 = load double, ptr %22, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %13, align 8
  %26 = or disjoint i64 %18, 1
  %27 = getelementptr double, ptr %1, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %13, align 8
  %33 = or disjoint i64 %18, 2
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %33
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %13, align 8
  %40 = or disjoint i64 %18, 3
  %41 = getelementptr double, ptr %1, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %8, i64 %40
  %44 = load double, ptr %43, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %13, align 8
  %47 = or disjoint i64 %18, 4
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %8, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %46, %52
  store double %53, ptr %13, align 8
  %54 = or disjoint i64 %18, 5
  %55 = getelementptr double, ptr %1, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %53, %59
  store double %60, ptr %13, align 8
  %61 = or disjoint i64 %18, 6
  %62 = getelementptr double, ptr %1, i64 %61
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %8, i64 %61
  %65 = load double, ptr %64, align 8
  %66 = fmul double %63, %65
  %67 = fadd double %60, %66
  store double %67, ptr %13, align 8
  %68 = or disjoint i64 %18, 7
  %69 = getelementptr double, ptr %1, i64 %68
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %68
  %72 = load double, ptr %71, align 8
  %73 = fmul double %70, %72
  %74 = fadd double %67, %73
  store double %74, ptr %13, align 8
  %75 = add nuw nsw i64 %18, 8
  %exitcond.not.7 = icmp eq i64 %75, 128
  br i1 %exitcond.not.7, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %76 = getelementptr double, ptr %13, i64 1
  %invariant.gep = getelementptr double, ptr %1, i64 128
  br label %77

77:                                               ; preds = %77, %.preheader.1
  %78 = phi i64 [ 0, %.preheader.1 ], [ %127, %77 ]
  %79 = phi double [ 0.000000e+00, %.preheader.1 ], [ %126, %77 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %78
  %80 = load double, ptr %gep, align 8
  %81 = getelementptr double, ptr %8, i64 %78
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %79, %83
  store double %84, ptr %76, align 8
  %85 = or disjoint i64 %78, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %85
  %86 = load double, ptr %gep.1, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %76, align 8
  %91 = or disjoint i64 %78, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %91
  %92 = load double, ptr %gep.2, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %76, align 8
  %97 = or disjoint i64 %78, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %97
  %98 = load double, ptr %gep.3, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %76, align 8
  %103 = or disjoint i64 %78, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %103
  %104 = load double, ptr %gep.4, align 8
  %105 = getelementptr double, ptr %8, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %76, align 8
  %109 = or disjoint i64 %78, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %109
  %110 = load double, ptr %gep.5, align 8
  %111 = getelementptr double, ptr %8, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %76, align 8
  %115 = or disjoint i64 %78, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %115
  %116 = load double, ptr %gep.6, align 8
  %117 = getelementptr double, ptr %8, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %76, align 8
  %121 = or disjoint i64 %78, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %121
  %122 = load double, ptr %gep.7, align 8
  %123 = getelementptr double, ptr %8, i64 %121
  %124 = load double, ptr %123, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %120, %125
  store double %126, ptr %76, align 8
  %127 = add nuw nsw i64 %78, 8
  %exitcond.1.not.7 = icmp eq i64 %127, 128
  br i1 %exitcond.1.not.7, label %.preheader.2, label %77

.preheader.2:                                     ; preds = %77
  %128 = getelementptr double, ptr %13, i64 2
  %invariant.gep4 = getelementptr double, ptr %1, i64 256
  br label %129

129:                                              ; preds = %129, %.preheader.2
  %130 = phi i64 [ 0, %.preheader.2 ], [ %179, %129 ]
  %131 = phi double [ 0.000000e+00, %.preheader.2 ], [ %178, %129 ]
  %gep5 = getelementptr double, ptr %invariant.gep4, i64 %130
  %132 = load double, ptr %gep5, align 8
  %133 = getelementptr double, ptr %8, i64 %130
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %131, %135
  store double %136, ptr %128, align 8
  %137 = or disjoint i64 %130, 1
  %gep5.1 = getelementptr double, ptr %invariant.gep4, i64 %137
  %138 = load double, ptr %gep5.1, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %128, align 8
  %143 = or disjoint i64 %130, 2
  %gep5.2 = getelementptr double, ptr %invariant.gep4, i64 %143
  %144 = load double, ptr %gep5.2, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %128, align 8
  %149 = or disjoint i64 %130, 3
  %gep5.3 = getelementptr double, ptr %invariant.gep4, i64 %149
  %150 = load double, ptr %gep5.3, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %128, align 8
  %155 = or disjoint i64 %130, 4
  %gep5.4 = getelementptr double, ptr %invariant.gep4, i64 %155
  %156 = load double, ptr %gep5.4, align 8
  %157 = getelementptr double, ptr %8, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %128, align 8
  %161 = or disjoint i64 %130, 5
  %gep5.5 = getelementptr double, ptr %invariant.gep4, i64 %161
  %162 = load double, ptr %gep5.5, align 8
  %163 = getelementptr double, ptr %8, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %128, align 8
  %167 = or disjoint i64 %130, 6
  %gep5.6 = getelementptr double, ptr %invariant.gep4, i64 %167
  %168 = load double, ptr %gep5.6, align 8
  %169 = getelementptr double, ptr %8, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %128, align 8
  %173 = or disjoint i64 %130, 7
  %gep5.7 = getelementptr double, ptr %invariant.gep4, i64 %173
  %174 = load double, ptr %gep5.7, align 8
  %175 = getelementptr double, ptr %8, i64 %173
  %176 = load double, ptr %175, align 8
  %177 = fmul double %174, %176
  %178 = fadd double %172, %177
  store double %178, ptr %128, align 8
  %179 = add nuw nsw i64 %130, 8
  %exitcond.2.not.7 = icmp eq i64 %179, 128
  br i1 %exitcond.2.not.7, label %.preheader.3, label %129

.preheader.3:                                     ; preds = %129
  %180 = getelementptr double, ptr %13, i64 3
  %invariant.gep6 = getelementptr double, ptr %1, i64 384
  br label %181

181:                                              ; preds = %181, %.preheader.3
  %182 = phi i64 [ 0, %.preheader.3 ], [ %231, %181 ]
  %183 = phi double [ 0.000000e+00, %.preheader.3 ], [ %230, %181 ]
  %gep7 = getelementptr double, ptr %invariant.gep6, i64 %182
  %184 = load double, ptr %gep7, align 8
  %185 = getelementptr double, ptr %8, i64 %182
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %183, %187
  store double %188, ptr %180, align 8
  %189 = or disjoint i64 %182, 1
  %gep7.1 = getelementptr double, ptr %invariant.gep6, i64 %189
  %190 = load double, ptr %gep7.1, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %180, align 8
  %195 = or disjoint i64 %182, 2
  %gep7.2 = getelementptr double, ptr %invariant.gep6, i64 %195
  %196 = load double, ptr %gep7.2, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %180, align 8
  %201 = or disjoint i64 %182, 3
  %gep7.3 = getelementptr double, ptr %invariant.gep6, i64 %201
  %202 = load double, ptr %gep7.3, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %180, align 8
  %207 = or disjoint i64 %182, 4
  %gep7.4 = getelementptr double, ptr %invariant.gep6, i64 %207
  %208 = load double, ptr %gep7.4, align 8
  %209 = getelementptr double, ptr %8, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %180, align 8
  %213 = or disjoint i64 %182, 5
  %gep7.5 = getelementptr double, ptr %invariant.gep6, i64 %213
  %214 = load double, ptr %gep7.5, align 8
  %215 = getelementptr double, ptr %8, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %180, align 8
  %219 = or disjoint i64 %182, 6
  %gep7.6 = getelementptr double, ptr %invariant.gep6, i64 %219
  %220 = load double, ptr %gep7.6, align 8
  %221 = getelementptr double, ptr %8, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %180, align 8
  %225 = or disjoint i64 %182, 7
  %gep7.7 = getelementptr double, ptr %invariant.gep6, i64 %225
  %226 = load double, ptr %gep7.7, align 8
  %227 = getelementptr double, ptr %8, i64 %225
  %228 = load double, ptr %227, align 8
  %229 = fmul double %226, %228
  %230 = fadd double %224, %229
  store double %230, ptr %180, align 8
  %231 = add nuw nsw i64 %182, 8
  %exitcond.3.not.7 = icmp eq i64 %231, 128
  br i1 %exitcond.3.not.7, label %.preheader.4, label %181

.preheader.4:                                     ; preds = %181
  %232 = getelementptr double, ptr %13, i64 4
  %invariant.gep8 = getelementptr double, ptr %1, i64 512
  br label %233

233:                                              ; preds = %233, %.preheader.4
  %234 = phi i64 [ 0, %.preheader.4 ], [ %283, %233 ]
  %235 = phi double [ 0.000000e+00, %.preheader.4 ], [ %282, %233 ]
  %gep9 = getelementptr double, ptr %invariant.gep8, i64 %234
  %236 = load double, ptr %gep9, align 8
  %237 = getelementptr double, ptr %8, i64 %234
  %238 = load double, ptr %237, align 8
  %239 = fmul double %236, %238
  %240 = fadd double %235, %239
  store double %240, ptr %232, align 8
  %241 = or disjoint i64 %234, 1
  %gep9.1 = getelementptr double, ptr %invariant.gep8, i64 %241
  %242 = load double, ptr %gep9.1, align 8
  %243 = getelementptr double, ptr %8, i64 %241
  %244 = load double, ptr %243, align 8
  %245 = fmul double %242, %244
  %246 = fadd double %240, %245
  store double %246, ptr %232, align 8
  %247 = or disjoint i64 %234, 2
  %gep9.2 = getelementptr double, ptr %invariant.gep8, i64 %247
  %248 = load double, ptr %gep9.2, align 8
  %249 = getelementptr double, ptr %8, i64 %247
  %250 = load double, ptr %249, align 8
  %251 = fmul double %248, %250
  %252 = fadd double %246, %251
  store double %252, ptr %232, align 8
  %253 = or disjoint i64 %234, 3
  %gep9.3 = getelementptr double, ptr %invariant.gep8, i64 %253
  %254 = load double, ptr %gep9.3, align 8
  %255 = getelementptr double, ptr %8, i64 %253
  %256 = load double, ptr %255, align 8
  %257 = fmul double %254, %256
  %258 = fadd double %252, %257
  store double %258, ptr %232, align 8
  %259 = or disjoint i64 %234, 4
  %gep9.4 = getelementptr double, ptr %invariant.gep8, i64 %259
  %260 = load double, ptr %gep9.4, align 8
  %261 = getelementptr double, ptr %8, i64 %259
  %262 = load double, ptr %261, align 8
  %263 = fmul double %260, %262
  %264 = fadd double %258, %263
  store double %264, ptr %232, align 8
  %265 = or disjoint i64 %234, 5
  %gep9.5 = getelementptr double, ptr %invariant.gep8, i64 %265
  %266 = load double, ptr %gep9.5, align 8
  %267 = getelementptr double, ptr %8, i64 %265
  %268 = load double, ptr %267, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %264, %269
  store double %270, ptr %232, align 8
  %271 = or disjoint i64 %234, 6
  %gep9.6 = getelementptr double, ptr %invariant.gep8, i64 %271
  %272 = load double, ptr %gep9.6, align 8
  %273 = getelementptr double, ptr %8, i64 %271
  %274 = load double, ptr %273, align 8
  %275 = fmul double %272, %274
  %276 = fadd double %270, %275
  store double %276, ptr %232, align 8
  %277 = or disjoint i64 %234, 7
  %gep9.7 = getelementptr double, ptr %invariant.gep8, i64 %277
  %278 = load double, ptr %gep9.7, align 8
  %279 = getelementptr double, ptr %8, i64 %277
  %280 = load double, ptr %279, align 8
  %281 = fmul double %278, %280
  %282 = fadd double %276, %281
  store double %282, ptr %232, align 8
  %283 = add nuw nsw i64 %234, 8
  %exitcond.4.not.7 = icmp eq i64 %283, 128
  br i1 %exitcond.4.not.7, label %.preheader.5, label %233

.preheader.5:                                     ; preds = %233
  %284 = getelementptr double, ptr %13, i64 5
  %invariant.gep10 = getelementptr double, ptr %1, i64 640
  br label %285

285:                                              ; preds = %285, %.preheader.5
  %286 = phi i64 [ 0, %.preheader.5 ], [ %335, %285 ]
  %287 = phi double [ 0.000000e+00, %.preheader.5 ], [ %334, %285 ]
  %gep11 = getelementptr double, ptr %invariant.gep10, i64 %286
  %288 = load double, ptr %gep11, align 8
  %289 = getelementptr double, ptr %8, i64 %286
  %290 = load double, ptr %289, align 8
  %291 = fmul double %288, %290
  %292 = fadd double %287, %291
  store double %292, ptr %284, align 8
  %293 = or disjoint i64 %286, 1
  %gep11.1 = getelementptr double, ptr %invariant.gep10, i64 %293
  %294 = load double, ptr %gep11.1, align 8
  %295 = getelementptr double, ptr %8, i64 %293
  %296 = load double, ptr %295, align 8
  %297 = fmul double %294, %296
  %298 = fadd double %292, %297
  store double %298, ptr %284, align 8
  %299 = or disjoint i64 %286, 2
  %gep11.2 = getelementptr double, ptr %invariant.gep10, i64 %299
  %300 = load double, ptr %gep11.2, align 8
  %301 = getelementptr double, ptr %8, i64 %299
  %302 = load double, ptr %301, align 8
  %303 = fmul double %300, %302
  %304 = fadd double %298, %303
  store double %304, ptr %284, align 8
  %305 = or disjoint i64 %286, 3
  %gep11.3 = getelementptr double, ptr %invariant.gep10, i64 %305
  %306 = load double, ptr %gep11.3, align 8
  %307 = getelementptr double, ptr %8, i64 %305
  %308 = load double, ptr %307, align 8
  %309 = fmul double %306, %308
  %310 = fadd double %304, %309
  store double %310, ptr %284, align 8
  %311 = or disjoint i64 %286, 4
  %gep11.4 = getelementptr double, ptr %invariant.gep10, i64 %311
  %312 = load double, ptr %gep11.4, align 8
  %313 = getelementptr double, ptr %8, i64 %311
  %314 = load double, ptr %313, align 8
  %315 = fmul double %312, %314
  %316 = fadd double %310, %315
  store double %316, ptr %284, align 8
  %317 = or disjoint i64 %286, 5
  %gep11.5 = getelementptr double, ptr %invariant.gep10, i64 %317
  %318 = load double, ptr %gep11.5, align 8
  %319 = getelementptr double, ptr %8, i64 %317
  %320 = load double, ptr %319, align 8
  %321 = fmul double %318, %320
  %322 = fadd double %316, %321
  store double %322, ptr %284, align 8
  %323 = or disjoint i64 %286, 6
  %gep11.6 = getelementptr double, ptr %invariant.gep10, i64 %323
  %324 = load double, ptr %gep11.6, align 8
  %325 = getelementptr double, ptr %8, i64 %323
  %326 = load double, ptr %325, align 8
  %327 = fmul double %324, %326
  %328 = fadd double %322, %327
  store double %328, ptr %284, align 8
  %329 = or disjoint i64 %286, 7
  %gep11.7 = getelementptr double, ptr %invariant.gep10, i64 %329
  %330 = load double, ptr %gep11.7, align 8
  %331 = getelementptr double, ptr %8, i64 %329
  %332 = load double, ptr %331, align 8
  %333 = fmul double %330, %332
  %334 = fadd double %328, %333
  store double %334, ptr %284, align 8
  %335 = add nuw nsw i64 %286, 8
  %exitcond.5.not.7 = icmp eq i64 %335, 128
  br i1 %exitcond.5.not.7, label %.preheader.6, label %285

.preheader.6:                                     ; preds = %285
  %336 = getelementptr double, ptr %13, i64 6
  %invariant.gep12 = getelementptr double, ptr %1, i64 768
  br label %337

337:                                              ; preds = %337, %.preheader.6
  %338 = phi i64 [ 0, %.preheader.6 ], [ %387, %337 ]
  %339 = phi double [ 0.000000e+00, %.preheader.6 ], [ %386, %337 ]
  %gep13 = getelementptr double, ptr %invariant.gep12, i64 %338
  %340 = load double, ptr %gep13, align 8
  %341 = getelementptr double, ptr %8, i64 %338
  %342 = load double, ptr %341, align 8
  %343 = fmul double %340, %342
  %344 = fadd double %339, %343
  store double %344, ptr %336, align 8
  %345 = or disjoint i64 %338, 1
  %gep13.1 = getelementptr double, ptr %invariant.gep12, i64 %345
  %346 = load double, ptr %gep13.1, align 8
  %347 = getelementptr double, ptr %8, i64 %345
  %348 = load double, ptr %347, align 8
  %349 = fmul double %346, %348
  %350 = fadd double %344, %349
  store double %350, ptr %336, align 8
  %351 = or disjoint i64 %338, 2
  %gep13.2 = getelementptr double, ptr %invariant.gep12, i64 %351
  %352 = load double, ptr %gep13.2, align 8
  %353 = getelementptr double, ptr %8, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = fmul double %352, %354
  %356 = fadd double %350, %355
  store double %356, ptr %336, align 8
  %357 = or disjoint i64 %338, 3
  %gep13.3 = getelementptr double, ptr %invariant.gep12, i64 %357
  %358 = load double, ptr %gep13.3, align 8
  %359 = getelementptr double, ptr %8, i64 %357
  %360 = load double, ptr %359, align 8
  %361 = fmul double %358, %360
  %362 = fadd double %356, %361
  store double %362, ptr %336, align 8
  %363 = or disjoint i64 %338, 4
  %gep13.4 = getelementptr double, ptr %invariant.gep12, i64 %363
  %364 = load double, ptr %gep13.4, align 8
  %365 = getelementptr double, ptr %8, i64 %363
  %366 = load double, ptr %365, align 8
  %367 = fmul double %364, %366
  %368 = fadd double %362, %367
  store double %368, ptr %336, align 8
  %369 = or disjoint i64 %338, 5
  %gep13.5 = getelementptr double, ptr %invariant.gep12, i64 %369
  %370 = load double, ptr %gep13.5, align 8
  %371 = getelementptr double, ptr %8, i64 %369
  %372 = load double, ptr %371, align 8
  %373 = fmul double %370, %372
  %374 = fadd double %368, %373
  store double %374, ptr %336, align 8
  %375 = or disjoint i64 %338, 6
  %gep13.6 = getelementptr double, ptr %invariant.gep12, i64 %375
  %376 = load double, ptr %gep13.6, align 8
  %377 = getelementptr double, ptr %8, i64 %375
  %378 = load double, ptr %377, align 8
  %379 = fmul double %376, %378
  %380 = fadd double %374, %379
  store double %380, ptr %336, align 8
  %381 = or disjoint i64 %338, 7
  %gep13.7 = getelementptr double, ptr %invariant.gep12, i64 %381
  %382 = load double, ptr %gep13.7, align 8
  %383 = getelementptr double, ptr %8, i64 %381
  %384 = load double, ptr %383, align 8
  %385 = fmul double %382, %384
  %386 = fadd double %380, %385
  store double %386, ptr %336, align 8
  %387 = add nuw nsw i64 %338, 8
  %exitcond.6.not.7 = icmp eq i64 %387, 128
  br i1 %exitcond.6.not.7, label %.preheader.7, label %337

.preheader.7:                                     ; preds = %337
  %388 = getelementptr double, ptr %13, i64 7
  %invariant.gep14 = getelementptr double, ptr %1, i64 896
  br label %389

389:                                              ; preds = %389, %.preheader.7
  %390 = phi i64 [ 0, %.preheader.7 ], [ %439, %389 ]
  %391 = phi double [ 0.000000e+00, %.preheader.7 ], [ %438, %389 ]
  %gep15 = getelementptr double, ptr %invariant.gep14, i64 %390
  %392 = load double, ptr %gep15, align 8
  %393 = getelementptr double, ptr %8, i64 %390
  %394 = load double, ptr %393, align 8
  %395 = fmul double %392, %394
  %396 = fadd double %391, %395
  store double %396, ptr %388, align 8
  %397 = or disjoint i64 %390, 1
  %gep15.1 = getelementptr double, ptr %invariant.gep14, i64 %397
  %398 = load double, ptr %gep15.1, align 8
  %399 = getelementptr double, ptr %8, i64 %397
  %400 = load double, ptr %399, align 8
  %401 = fmul double %398, %400
  %402 = fadd double %396, %401
  store double %402, ptr %388, align 8
  %403 = or disjoint i64 %390, 2
  %gep15.2 = getelementptr double, ptr %invariant.gep14, i64 %403
  %404 = load double, ptr %gep15.2, align 8
  %405 = getelementptr double, ptr %8, i64 %403
  %406 = load double, ptr %405, align 8
  %407 = fmul double %404, %406
  %408 = fadd double %402, %407
  store double %408, ptr %388, align 8
  %409 = or disjoint i64 %390, 3
  %gep15.3 = getelementptr double, ptr %invariant.gep14, i64 %409
  %410 = load double, ptr %gep15.3, align 8
  %411 = getelementptr double, ptr %8, i64 %409
  %412 = load double, ptr %411, align 8
  %413 = fmul double %410, %412
  %414 = fadd double %408, %413
  store double %414, ptr %388, align 8
  %415 = or disjoint i64 %390, 4
  %gep15.4 = getelementptr double, ptr %invariant.gep14, i64 %415
  %416 = load double, ptr %gep15.4, align 8
  %417 = getelementptr double, ptr %8, i64 %415
  %418 = load double, ptr %417, align 8
  %419 = fmul double %416, %418
  %420 = fadd double %414, %419
  store double %420, ptr %388, align 8
  %421 = or disjoint i64 %390, 5
  %gep15.5 = getelementptr double, ptr %invariant.gep14, i64 %421
  %422 = load double, ptr %gep15.5, align 8
  %423 = getelementptr double, ptr %8, i64 %421
  %424 = load double, ptr %423, align 8
  %425 = fmul double %422, %424
  %426 = fadd double %420, %425
  store double %426, ptr %388, align 8
  %427 = or disjoint i64 %390, 6
  %gep15.6 = getelementptr double, ptr %invariant.gep14, i64 %427
  %428 = load double, ptr %gep15.6, align 8
  %429 = getelementptr double, ptr %8, i64 %427
  %430 = load double, ptr %429, align 8
  %431 = fmul double %428, %430
  %432 = fadd double %426, %431
  store double %432, ptr %388, align 8
  %433 = or disjoint i64 %390, 7
  %gep15.7 = getelementptr double, ptr %invariant.gep14, i64 %433
  %434 = load double, ptr %gep15.7, align 8
  %435 = getelementptr double, ptr %8, i64 %433
  %436 = load double, ptr %435, align 8
  %437 = fmul double %434, %436
  %438 = fadd double %432, %437
  store double %438, ptr %388, align 8
  %439 = add nuw nsw i64 %390, 8
  %exitcond.7.not.7 = icmp eq i64 %439, 128
  br i1 %exitcond.7.not.7, label %.preheader.8, label %389

.preheader.8:                                     ; preds = %389
  %440 = getelementptr double, ptr %13, i64 8
  %invariant.gep16 = getelementptr double, ptr %1, i64 1024
  br label %441

441:                                              ; preds = %441, %.preheader.8
  %442 = phi i64 [ 0, %.preheader.8 ], [ %491, %441 ]
  %443 = phi double [ 0.000000e+00, %.preheader.8 ], [ %490, %441 ]
  %gep17 = getelementptr double, ptr %invariant.gep16, i64 %442
  %444 = load double, ptr %gep17, align 8
  %445 = getelementptr double, ptr %8, i64 %442
  %446 = load double, ptr %445, align 8
  %447 = fmul double %444, %446
  %448 = fadd double %443, %447
  store double %448, ptr %440, align 8
  %449 = or disjoint i64 %442, 1
  %gep17.1 = getelementptr double, ptr %invariant.gep16, i64 %449
  %450 = load double, ptr %gep17.1, align 8
  %451 = getelementptr double, ptr %8, i64 %449
  %452 = load double, ptr %451, align 8
  %453 = fmul double %450, %452
  %454 = fadd double %448, %453
  store double %454, ptr %440, align 8
  %455 = or disjoint i64 %442, 2
  %gep17.2 = getelementptr double, ptr %invariant.gep16, i64 %455
  %456 = load double, ptr %gep17.2, align 8
  %457 = getelementptr double, ptr %8, i64 %455
  %458 = load double, ptr %457, align 8
  %459 = fmul double %456, %458
  %460 = fadd double %454, %459
  store double %460, ptr %440, align 8
  %461 = or disjoint i64 %442, 3
  %gep17.3 = getelementptr double, ptr %invariant.gep16, i64 %461
  %462 = load double, ptr %gep17.3, align 8
  %463 = getelementptr double, ptr %8, i64 %461
  %464 = load double, ptr %463, align 8
  %465 = fmul double %462, %464
  %466 = fadd double %460, %465
  store double %466, ptr %440, align 8
  %467 = or disjoint i64 %442, 4
  %gep17.4 = getelementptr double, ptr %invariant.gep16, i64 %467
  %468 = load double, ptr %gep17.4, align 8
  %469 = getelementptr double, ptr %8, i64 %467
  %470 = load double, ptr %469, align 8
  %471 = fmul double %468, %470
  %472 = fadd double %466, %471
  store double %472, ptr %440, align 8
  %473 = or disjoint i64 %442, 5
  %gep17.5 = getelementptr double, ptr %invariant.gep16, i64 %473
  %474 = load double, ptr %gep17.5, align 8
  %475 = getelementptr double, ptr %8, i64 %473
  %476 = load double, ptr %475, align 8
  %477 = fmul double %474, %476
  %478 = fadd double %472, %477
  store double %478, ptr %440, align 8
  %479 = or disjoint i64 %442, 6
  %gep17.6 = getelementptr double, ptr %invariant.gep16, i64 %479
  %480 = load double, ptr %gep17.6, align 8
  %481 = getelementptr double, ptr %8, i64 %479
  %482 = load double, ptr %481, align 8
  %483 = fmul double %480, %482
  %484 = fadd double %478, %483
  store double %484, ptr %440, align 8
  %485 = or disjoint i64 %442, 7
  %gep17.7 = getelementptr double, ptr %invariant.gep16, i64 %485
  %486 = load double, ptr %gep17.7, align 8
  %487 = getelementptr double, ptr %8, i64 %485
  %488 = load double, ptr %487, align 8
  %489 = fmul double %486, %488
  %490 = fadd double %484, %489
  store double %490, ptr %440, align 8
  %491 = add nuw nsw i64 %442, 8
  %exitcond.8.not.7 = icmp eq i64 %491, 128
  br i1 %exitcond.8.not.7, label %.preheader.9, label %441

.preheader.9:                                     ; preds = %441
  %492 = getelementptr double, ptr %13, i64 9
  %invariant.gep18 = getelementptr double, ptr %1, i64 1152
  br label %493

493:                                              ; preds = %493, %.preheader.9
  %494 = phi i64 [ 0, %.preheader.9 ], [ %543, %493 ]
  %495 = phi double [ 0.000000e+00, %.preheader.9 ], [ %542, %493 ]
  %gep19 = getelementptr double, ptr %invariant.gep18, i64 %494
  %496 = load double, ptr %gep19, align 8
  %497 = getelementptr double, ptr %8, i64 %494
  %498 = load double, ptr %497, align 8
  %499 = fmul double %496, %498
  %500 = fadd double %495, %499
  store double %500, ptr %492, align 8
  %501 = or disjoint i64 %494, 1
  %gep19.1 = getelementptr double, ptr %invariant.gep18, i64 %501
  %502 = load double, ptr %gep19.1, align 8
  %503 = getelementptr double, ptr %8, i64 %501
  %504 = load double, ptr %503, align 8
  %505 = fmul double %502, %504
  %506 = fadd double %500, %505
  store double %506, ptr %492, align 8
  %507 = or disjoint i64 %494, 2
  %gep19.2 = getelementptr double, ptr %invariant.gep18, i64 %507
  %508 = load double, ptr %gep19.2, align 8
  %509 = getelementptr double, ptr %8, i64 %507
  %510 = load double, ptr %509, align 8
  %511 = fmul double %508, %510
  %512 = fadd double %506, %511
  store double %512, ptr %492, align 8
  %513 = or disjoint i64 %494, 3
  %gep19.3 = getelementptr double, ptr %invariant.gep18, i64 %513
  %514 = load double, ptr %gep19.3, align 8
  %515 = getelementptr double, ptr %8, i64 %513
  %516 = load double, ptr %515, align 8
  %517 = fmul double %514, %516
  %518 = fadd double %512, %517
  store double %518, ptr %492, align 8
  %519 = or disjoint i64 %494, 4
  %gep19.4 = getelementptr double, ptr %invariant.gep18, i64 %519
  %520 = load double, ptr %gep19.4, align 8
  %521 = getelementptr double, ptr %8, i64 %519
  %522 = load double, ptr %521, align 8
  %523 = fmul double %520, %522
  %524 = fadd double %518, %523
  store double %524, ptr %492, align 8
  %525 = or disjoint i64 %494, 5
  %gep19.5 = getelementptr double, ptr %invariant.gep18, i64 %525
  %526 = load double, ptr %gep19.5, align 8
  %527 = getelementptr double, ptr %8, i64 %525
  %528 = load double, ptr %527, align 8
  %529 = fmul double %526, %528
  %530 = fadd double %524, %529
  store double %530, ptr %492, align 8
  %531 = or disjoint i64 %494, 6
  %gep19.6 = getelementptr double, ptr %invariant.gep18, i64 %531
  %532 = load double, ptr %gep19.6, align 8
  %533 = getelementptr double, ptr %8, i64 %531
  %534 = load double, ptr %533, align 8
  %535 = fmul double %532, %534
  %536 = fadd double %530, %535
  store double %536, ptr %492, align 8
  %537 = or disjoint i64 %494, 7
  %gep19.7 = getelementptr double, ptr %invariant.gep18, i64 %537
  %538 = load double, ptr %gep19.7, align 8
  %539 = getelementptr double, ptr %8, i64 %537
  %540 = load double, ptr %539, align 8
  %541 = fmul double %538, %540
  %542 = fadd double %536, %541
  store double %542, ptr %492, align 8
  %543 = add nuw nsw i64 %494, 8
  %exitcond.9.not.7 = icmp eq i64 %543, 128
  br i1 %exitcond.9.not.7, label %.preheader.10, label %493

.preheader.10:                                    ; preds = %493
  %544 = getelementptr double, ptr %13, i64 10
  %invariant.gep20 = getelementptr double, ptr %1, i64 1280
  br label %545

545:                                              ; preds = %545, %.preheader.10
  %546 = phi i64 [ 0, %.preheader.10 ], [ %595, %545 ]
  %547 = phi double [ 0.000000e+00, %.preheader.10 ], [ %594, %545 ]
  %gep21 = getelementptr double, ptr %invariant.gep20, i64 %546
  %548 = load double, ptr %gep21, align 8
  %549 = getelementptr double, ptr %8, i64 %546
  %550 = load double, ptr %549, align 8
  %551 = fmul double %548, %550
  %552 = fadd double %547, %551
  store double %552, ptr %544, align 8
  %553 = or disjoint i64 %546, 1
  %gep21.1 = getelementptr double, ptr %invariant.gep20, i64 %553
  %554 = load double, ptr %gep21.1, align 8
  %555 = getelementptr double, ptr %8, i64 %553
  %556 = load double, ptr %555, align 8
  %557 = fmul double %554, %556
  %558 = fadd double %552, %557
  store double %558, ptr %544, align 8
  %559 = or disjoint i64 %546, 2
  %gep21.2 = getelementptr double, ptr %invariant.gep20, i64 %559
  %560 = load double, ptr %gep21.2, align 8
  %561 = getelementptr double, ptr %8, i64 %559
  %562 = load double, ptr %561, align 8
  %563 = fmul double %560, %562
  %564 = fadd double %558, %563
  store double %564, ptr %544, align 8
  %565 = or disjoint i64 %546, 3
  %gep21.3 = getelementptr double, ptr %invariant.gep20, i64 %565
  %566 = load double, ptr %gep21.3, align 8
  %567 = getelementptr double, ptr %8, i64 %565
  %568 = load double, ptr %567, align 8
  %569 = fmul double %566, %568
  %570 = fadd double %564, %569
  store double %570, ptr %544, align 8
  %571 = or disjoint i64 %546, 4
  %gep21.4 = getelementptr double, ptr %invariant.gep20, i64 %571
  %572 = load double, ptr %gep21.4, align 8
  %573 = getelementptr double, ptr %8, i64 %571
  %574 = load double, ptr %573, align 8
  %575 = fmul double %572, %574
  %576 = fadd double %570, %575
  store double %576, ptr %544, align 8
  %577 = or disjoint i64 %546, 5
  %gep21.5 = getelementptr double, ptr %invariant.gep20, i64 %577
  %578 = load double, ptr %gep21.5, align 8
  %579 = getelementptr double, ptr %8, i64 %577
  %580 = load double, ptr %579, align 8
  %581 = fmul double %578, %580
  %582 = fadd double %576, %581
  store double %582, ptr %544, align 8
  %583 = or disjoint i64 %546, 6
  %gep21.6 = getelementptr double, ptr %invariant.gep20, i64 %583
  %584 = load double, ptr %gep21.6, align 8
  %585 = getelementptr double, ptr %8, i64 %583
  %586 = load double, ptr %585, align 8
  %587 = fmul double %584, %586
  %588 = fadd double %582, %587
  store double %588, ptr %544, align 8
  %589 = or disjoint i64 %546, 7
  %gep21.7 = getelementptr double, ptr %invariant.gep20, i64 %589
  %590 = load double, ptr %gep21.7, align 8
  %591 = getelementptr double, ptr %8, i64 %589
  %592 = load double, ptr %591, align 8
  %593 = fmul double %590, %592
  %594 = fadd double %588, %593
  store double %594, ptr %544, align 8
  %595 = add nuw nsw i64 %546, 8
  %exitcond.10.not.7 = icmp eq i64 %595, 128
  br i1 %exitcond.10.not.7, label %.preheader.11, label %545

.preheader.11:                                    ; preds = %545
  %596 = getelementptr double, ptr %13, i64 11
  %invariant.gep22 = getelementptr double, ptr %1, i64 1408
  br label %597

597:                                              ; preds = %597, %.preheader.11
  %598 = phi i64 [ 0, %.preheader.11 ], [ %647, %597 ]
  %599 = phi double [ 0.000000e+00, %.preheader.11 ], [ %646, %597 ]
  %gep23 = getelementptr double, ptr %invariant.gep22, i64 %598
  %600 = load double, ptr %gep23, align 8
  %601 = getelementptr double, ptr %8, i64 %598
  %602 = load double, ptr %601, align 8
  %603 = fmul double %600, %602
  %604 = fadd double %599, %603
  store double %604, ptr %596, align 8
  %605 = or disjoint i64 %598, 1
  %gep23.1 = getelementptr double, ptr %invariant.gep22, i64 %605
  %606 = load double, ptr %gep23.1, align 8
  %607 = getelementptr double, ptr %8, i64 %605
  %608 = load double, ptr %607, align 8
  %609 = fmul double %606, %608
  %610 = fadd double %604, %609
  store double %610, ptr %596, align 8
  %611 = or disjoint i64 %598, 2
  %gep23.2 = getelementptr double, ptr %invariant.gep22, i64 %611
  %612 = load double, ptr %gep23.2, align 8
  %613 = getelementptr double, ptr %8, i64 %611
  %614 = load double, ptr %613, align 8
  %615 = fmul double %612, %614
  %616 = fadd double %610, %615
  store double %616, ptr %596, align 8
  %617 = or disjoint i64 %598, 3
  %gep23.3 = getelementptr double, ptr %invariant.gep22, i64 %617
  %618 = load double, ptr %gep23.3, align 8
  %619 = getelementptr double, ptr %8, i64 %617
  %620 = load double, ptr %619, align 8
  %621 = fmul double %618, %620
  %622 = fadd double %616, %621
  store double %622, ptr %596, align 8
  %623 = or disjoint i64 %598, 4
  %gep23.4 = getelementptr double, ptr %invariant.gep22, i64 %623
  %624 = load double, ptr %gep23.4, align 8
  %625 = getelementptr double, ptr %8, i64 %623
  %626 = load double, ptr %625, align 8
  %627 = fmul double %624, %626
  %628 = fadd double %622, %627
  store double %628, ptr %596, align 8
  %629 = or disjoint i64 %598, 5
  %gep23.5 = getelementptr double, ptr %invariant.gep22, i64 %629
  %630 = load double, ptr %gep23.5, align 8
  %631 = getelementptr double, ptr %8, i64 %629
  %632 = load double, ptr %631, align 8
  %633 = fmul double %630, %632
  %634 = fadd double %628, %633
  store double %634, ptr %596, align 8
  %635 = or disjoint i64 %598, 6
  %gep23.6 = getelementptr double, ptr %invariant.gep22, i64 %635
  %636 = load double, ptr %gep23.6, align 8
  %637 = getelementptr double, ptr %8, i64 %635
  %638 = load double, ptr %637, align 8
  %639 = fmul double %636, %638
  %640 = fadd double %634, %639
  store double %640, ptr %596, align 8
  %641 = or disjoint i64 %598, 7
  %gep23.7 = getelementptr double, ptr %invariant.gep22, i64 %641
  %642 = load double, ptr %gep23.7, align 8
  %643 = getelementptr double, ptr %8, i64 %641
  %644 = load double, ptr %643, align 8
  %645 = fmul double %642, %644
  %646 = fadd double %640, %645
  store double %646, ptr %596, align 8
  %647 = add nuw nsw i64 %598, 8
  %exitcond.11.not.7 = icmp eq i64 %647, 128
  br i1 %exitcond.11.not.7, label %.preheader.12, label %597

.preheader.12:                                    ; preds = %597
  %648 = getelementptr double, ptr %13, i64 12
  %invariant.gep24 = getelementptr double, ptr %1, i64 1536
  br label %649

649:                                              ; preds = %649, %.preheader.12
  %650 = phi i64 [ 0, %.preheader.12 ], [ %699, %649 ]
  %651 = phi double [ 0.000000e+00, %.preheader.12 ], [ %698, %649 ]
  %gep25 = getelementptr double, ptr %invariant.gep24, i64 %650
  %652 = load double, ptr %gep25, align 8
  %653 = getelementptr double, ptr %8, i64 %650
  %654 = load double, ptr %653, align 8
  %655 = fmul double %652, %654
  %656 = fadd double %651, %655
  store double %656, ptr %648, align 8
  %657 = or disjoint i64 %650, 1
  %gep25.1 = getelementptr double, ptr %invariant.gep24, i64 %657
  %658 = load double, ptr %gep25.1, align 8
  %659 = getelementptr double, ptr %8, i64 %657
  %660 = load double, ptr %659, align 8
  %661 = fmul double %658, %660
  %662 = fadd double %656, %661
  store double %662, ptr %648, align 8
  %663 = or disjoint i64 %650, 2
  %gep25.2 = getelementptr double, ptr %invariant.gep24, i64 %663
  %664 = load double, ptr %gep25.2, align 8
  %665 = getelementptr double, ptr %8, i64 %663
  %666 = load double, ptr %665, align 8
  %667 = fmul double %664, %666
  %668 = fadd double %662, %667
  store double %668, ptr %648, align 8
  %669 = or disjoint i64 %650, 3
  %gep25.3 = getelementptr double, ptr %invariant.gep24, i64 %669
  %670 = load double, ptr %gep25.3, align 8
  %671 = getelementptr double, ptr %8, i64 %669
  %672 = load double, ptr %671, align 8
  %673 = fmul double %670, %672
  %674 = fadd double %668, %673
  store double %674, ptr %648, align 8
  %675 = or disjoint i64 %650, 4
  %gep25.4 = getelementptr double, ptr %invariant.gep24, i64 %675
  %676 = load double, ptr %gep25.4, align 8
  %677 = getelementptr double, ptr %8, i64 %675
  %678 = load double, ptr %677, align 8
  %679 = fmul double %676, %678
  %680 = fadd double %674, %679
  store double %680, ptr %648, align 8
  %681 = or disjoint i64 %650, 5
  %gep25.5 = getelementptr double, ptr %invariant.gep24, i64 %681
  %682 = load double, ptr %gep25.5, align 8
  %683 = getelementptr double, ptr %8, i64 %681
  %684 = load double, ptr %683, align 8
  %685 = fmul double %682, %684
  %686 = fadd double %680, %685
  store double %686, ptr %648, align 8
  %687 = or disjoint i64 %650, 6
  %gep25.6 = getelementptr double, ptr %invariant.gep24, i64 %687
  %688 = load double, ptr %gep25.6, align 8
  %689 = getelementptr double, ptr %8, i64 %687
  %690 = load double, ptr %689, align 8
  %691 = fmul double %688, %690
  %692 = fadd double %686, %691
  store double %692, ptr %648, align 8
  %693 = or disjoint i64 %650, 7
  %gep25.7 = getelementptr double, ptr %invariant.gep24, i64 %693
  %694 = load double, ptr %gep25.7, align 8
  %695 = getelementptr double, ptr %8, i64 %693
  %696 = load double, ptr %695, align 8
  %697 = fmul double %694, %696
  %698 = fadd double %692, %697
  store double %698, ptr %648, align 8
  %699 = add nuw nsw i64 %650, 8
  %exitcond.12.not.7 = icmp eq i64 %699, 128
  br i1 %exitcond.12.not.7, label %.preheader.13, label %649

.preheader.13:                                    ; preds = %649
  %700 = getelementptr double, ptr %13, i64 13
  %invariant.gep26 = getelementptr double, ptr %1, i64 1664
  br label %701

701:                                              ; preds = %701, %.preheader.13
  %702 = phi i64 [ 0, %.preheader.13 ], [ %751, %701 ]
  %703 = phi double [ 0.000000e+00, %.preheader.13 ], [ %750, %701 ]
  %gep27 = getelementptr double, ptr %invariant.gep26, i64 %702
  %704 = load double, ptr %gep27, align 8
  %705 = getelementptr double, ptr %8, i64 %702
  %706 = load double, ptr %705, align 8
  %707 = fmul double %704, %706
  %708 = fadd double %703, %707
  store double %708, ptr %700, align 8
  %709 = or disjoint i64 %702, 1
  %gep27.1 = getelementptr double, ptr %invariant.gep26, i64 %709
  %710 = load double, ptr %gep27.1, align 8
  %711 = getelementptr double, ptr %8, i64 %709
  %712 = load double, ptr %711, align 8
  %713 = fmul double %710, %712
  %714 = fadd double %708, %713
  store double %714, ptr %700, align 8
  %715 = or disjoint i64 %702, 2
  %gep27.2 = getelementptr double, ptr %invariant.gep26, i64 %715
  %716 = load double, ptr %gep27.2, align 8
  %717 = getelementptr double, ptr %8, i64 %715
  %718 = load double, ptr %717, align 8
  %719 = fmul double %716, %718
  %720 = fadd double %714, %719
  store double %720, ptr %700, align 8
  %721 = or disjoint i64 %702, 3
  %gep27.3 = getelementptr double, ptr %invariant.gep26, i64 %721
  %722 = load double, ptr %gep27.3, align 8
  %723 = getelementptr double, ptr %8, i64 %721
  %724 = load double, ptr %723, align 8
  %725 = fmul double %722, %724
  %726 = fadd double %720, %725
  store double %726, ptr %700, align 8
  %727 = or disjoint i64 %702, 4
  %gep27.4 = getelementptr double, ptr %invariant.gep26, i64 %727
  %728 = load double, ptr %gep27.4, align 8
  %729 = getelementptr double, ptr %8, i64 %727
  %730 = load double, ptr %729, align 8
  %731 = fmul double %728, %730
  %732 = fadd double %726, %731
  store double %732, ptr %700, align 8
  %733 = or disjoint i64 %702, 5
  %gep27.5 = getelementptr double, ptr %invariant.gep26, i64 %733
  %734 = load double, ptr %gep27.5, align 8
  %735 = getelementptr double, ptr %8, i64 %733
  %736 = load double, ptr %735, align 8
  %737 = fmul double %734, %736
  %738 = fadd double %732, %737
  store double %738, ptr %700, align 8
  %739 = or disjoint i64 %702, 6
  %gep27.6 = getelementptr double, ptr %invariant.gep26, i64 %739
  %740 = load double, ptr %gep27.6, align 8
  %741 = getelementptr double, ptr %8, i64 %739
  %742 = load double, ptr %741, align 8
  %743 = fmul double %740, %742
  %744 = fadd double %738, %743
  store double %744, ptr %700, align 8
  %745 = or disjoint i64 %702, 7
  %gep27.7 = getelementptr double, ptr %invariant.gep26, i64 %745
  %746 = load double, ptr %gep27.7, align 8
  %747 = getelementptr double, ptr %8, i64 %745
  %748 = load double, ptr %747, align 8
  %749 = fmul double %746, %748
  %750 = fadd double %744, %749
  store double %750, ptr %700, align 8
  %751 = add nuw nsw i64 %702, 8
  %exitcond.13.not.7 = icmp eq i64 %751, 128
  br i1 %exitcond.13.not.7, label %.preheader.14, label %701

.preheader.14:                                    ; preds = %701
  %752 = getelementptr double, ptr %13, i64 14
  %invariant.gep28 = getelementptr double, ptr %1, i64 1792
  br label %753

753:                                              ; preds = %753, %.preheader.14
  %754 = phi i64 [ 0, %.preheader.14 ], [ %803, %753 ]
  %755 = phi double [ 0.000000e+00, %.preheader.14 ], [ %802, %753 ]
  %gep29 = getelementptr double, ptr %invariant.gep28, i64 %754
  %756 = load double, ptr %gep29, align 8
  %757 = getelementptr double, ptr %8, i64 %754
  %758 = load double, ptr %757, align 8
  %759 = fmul double %756, %758
  %760 = fadd double %755, %759
  store double %760, ptr %752, align 8
  %761 = or disjoint i64 %754, 1
  %gep29.1 = getelementptr double, ptr %invariant.gep28, i64 %761
  %762 = load double, ptr %gep29.1, align 8
  %763 = getelementptr double, ptr %8, i64 %761
  %764 = load double, ptr %763, align 8
  %765 = fmul double %762, %764
  %766 = fadd double %760, %765
  store double %766, ptr %752, align 8
  %767 = or disjoint i64 %754, 2
  %gep29.2 = getelementptr double, ptr %invariant.gep28, i64 %767
  %768 = load double, ptr %gep29.2, align 8
  %769 = getelementptr double, ptr %8, i64 %767
  %770 = load double, ptr %769, align 8
  %771 = fmul double %768, %770
  %772 = fadd double %766, %771
  store double %772, ptr %752, align 8
  %773 = or disjoint i64 %754, 3
  %gep29.3 = getelementptr double, ptr %invariant.gep28, i64 %773
  %774 = load double, ptr %gep29.3, align 8
  %775 = getelementptr double, ptr %8, i64 %773
  %776 = load double, ptr %775, align 8
  %777 = fmul double %774, %776
  %778 = fadd double %772, %777
  store double %778, ptr %752, align 8
  %779 = or disjoint i64 %754, 4
  %gep29.4 = getelementptr double, ptr %invariant.gep28, i64 %779
  %780 = load double, ptr %gep29.4, align 8
  %781 = getelementptr double, ptr %8, i64 %779
  %782 = load double, ptr %781, align 8
  %783 = fmul double %780, %782
  %784 = fadd double %778, %783
  store double %784, ptr %752, align 8
  %785 = or disjoint i64 %754, 5
  %gep29.5 = getelementptr double, ptr %invariant.gep28, i64 %785
  %786 = load double, ptr %gep29.5, align 8
  %787 = getelementptr double, ptr %8, i64 %785
  %788 = load double, ptr %787, align 8
  %789 = fmul double %786, %788
  %790 = fadd double %784, %789
  store double %790, ptr %752, align 8
  %791 = or disjoint i64 %754, 6
  %gep29.6 = getelementptr double, ptr %invariant.gep28, i64 %791
  %792 = load double, ptr %gep29.6, align 8
  %793 = getelementptr double, ptr %8, i64 %791
  %794 = load double, ptr %793, align 8
  %795 = fmul double %792, %794
  %796 = fadd double %790, %795
  store double %796, ptr %752, align 8
  %797 = or disjoint i64 %754, 7
  %gep29.7 = getelementptr double, ptr %invariant.gep28, i64 %797
  %798 = load double, ptr %gep29.7, align 8
  %799 = getelementptr double, ptr %8, i64 %797
  %800 = load double, ptr %799, align 8
  %801 = fmul double %798, %800
  %802 = fadd double %796, %801
  store double %802, ptr %752, align 8
  %803 = add nuw nsw i64 %754, 8
  %exitcond.14.not.7 = icmp eq i64 %803, 128
  br i1 %exitcond.14.not.7, label %.preheader.15, label %753

.preheader.15:                                    ; preds = %753
  %804 = getelementptr double, ptr %13, i64 15
  %invariant.gep30 = getelementptr double, ptr %1, i64 1920
  br label %805

805:                                              ; preds = %805, %.preheader.15
  %806 = phi i64 [ 0, %.preheader.15 ], [ %855, %805 ]
  %807 = phi double [ 0.000000e+00, %.preheader.15 ], [ %854, %805 ]
  %gep31 = getelementptr double, ptr %invariant.gep30, i64 %806
  %808 = load double, ptr %gep31, align 8
  %809 = getelementptr double, ptr %8, i64 %806
  %810 = load double, ptr %809, align 8
  %811 = fmul double %808, %810
  %812 = fadd double %807, %811
  store double %812, ptr %804, align 8
  %813 = or disjoint i64 %806, 1
  %gep31.1 = getelementptr double, ptr %invariant.gep30, i64 %813
  %814 = load double, ptr %gep31.1, align 8
  %815 = getelementptr double, ptr %8, i64 %813
  %816 = load double, ptr %815, align 8
  %817 = fmul double %814, %816
  %818 = fadd double %812, %817
  store double %818, ptr %804, align 8
  %819 = or disjoint i64 %806, 2
  %gep31.2 = getelementptr double, ptr %invariant.gep30, i64 %819
  %820 = load double, ptr %gep31.2, align 8
  %821 = getelementptr double, ptr %8, i64 %819
  %822 = load double, ptr %821, align 8
  %823 = fmul double %820, %822
  %824 = fadd double %818, %823
  store double %824, ptr %804, align 8
  %825 = or disjoint i64 %806, 3
  %gep31.3 = getelementptr double, ptr %invariant.gep30, i64 %825
  %826 = load double, ptr %gep31.3, align 8
  %827 = getelementptr double, ptr %8, i64 %825
  %828 = load double, ptr %827, align 8
  %829 = fmul double %826, %828
  %830 = fadd double %824, %829
  store double %830, ptr %804, align 8
  %831 = or disjoint i64 %806, 4
  %gep31.4 = getelementptr double, ptr %invariant.gep30, i64 %831
  %832 = load double, ptr %gep31.4, align 8
  %833 = getelementptr double, ptr %8, i64 %831
  %834 = load double, ptr %833, align 8
  %835 = fmul double %832, %834
  %836 = fadd double %830, %835
  store double %836, ptr %804, align 8
  %837 = or disjoint i64 %806, 5
  %gep31.5 = getelementptr double, ptr %invariant.gep30, i64 %837
  %838 = load double, ptr %gep31.5, align 8
  %839 = getelementptr double, ptr %8, i64 %837
  %840 = load double, ptr %839, align 8
  %841 = fmul double %838, %840
  %842 = fadd double %836, %841
  store double %842, ptr %804, align 8
  %843 = or disjoint i64 %806, 6
  %gep31.6 = getelementptr double, ptr %invariant.gep30, i64 %843
  %844 = load double, ptr %gep31.6, align 8
  %845 = getelementptr double, ptr %8, i64 %843
  %846 = load double, ptr %845, align 8
  %847 = fmul double %844, %846
  %848 = fadd double %842, %847
  store double %848, ptr %804, align 8
  %849 = or disjoint i64 %806, 7
  %gep31.7 = getelementptr double, ptr %invariant.gep30, i64 %849
  %850 = load double, ptr %gep31.7, align 8
  %851 = getelementptr double, ptr %8, i64 %849
  %852 = load double, ptr %851, align 8
  %853 = fmul double %850, %852
  %854 = fadd double %848, %853
  store double %854, ptr %804, align 8
  %855 = add nuw nsw i64 %806, 8
  %exitcond.15.not.7 = icmp eq i64 %855, 128
  br i1 %exitcond.15.not.7, label %856, label %805

856:                                              ; preds = %805
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
