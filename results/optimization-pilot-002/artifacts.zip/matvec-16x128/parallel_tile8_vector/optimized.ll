; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %18

18:                                               ; preds = %17, %18
  %19 = phi i64 [ 0, %17 ], [ %51, %18 ]
  %20 = phi <8 x double> [ zeroinitializer, %17 ], [ %50, %18 ]
  %21 = getelementptr double, ptr %1, i64 %19
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %21, i64 128
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %21, i64 256
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %21, i64 384
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %21, i64 512
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %21, i64 640
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %21, i64 768
  %34 = load double, ptr %33, align 8
  %35 = getelementptr double, ptr %21, i64 896
  %36 = load double, ptr %35, align 8
  %37 = getelementptr double, ptr %8, i64 %19
  %38 = load double, ptr %37, align 8
  %39 = insertelement <8 x double> poison, double %22, i64 0
  %40 = insertelement <8 x double> %39, double %24, i64 1
  %41 = insertelement <8 x double> %40, double %26, i64 2
  %42 = insertelement <8 x double> %41, double %28, i64 3
  %43 = insertelement <8 x double> %42, double %30, i64 4
  %44 = insertelement <8 x double> %43, double %32, i64 5
  %45 = insertelement <8 x double> %44, double %34, i64 6
  %46 = insertelement <8 x double> %45, double %36, i64 7
  %47 = insertelement <8 x double> poison, double %38, i64 0
  %48 = shufflevector <8 x double> %47, <8 x double> poison, <8 x i32> zeroinitializer
  %49 = fmul <8 x double> %46, %48
  %50 = fadd <8 x double> %20, %49
  store <8 x double> %50, ptr %13, align 8
  %51 = add nuw nsw i64 %19, 1
  %exitcond.not = icmp eq i64 %51, 128
  br i1 %exitcond.not, label %52, label %18

52:                                               ; preds = %18
  %53 = getelementptr double, ptr %13, i64 8
  br label %54

54:                                               ; preds = %54, %52
  %55 = phi i64 [ 0, %52 ], [ %88, %54 ]
  %56 = phi <8 x double> [ zeroinitializer, %52 ], [ %87, %54 ]
  %57 = getelementptr double, ptr %1, i64 %55
  %58 = getelementptr double, ptr %57, i64 1024
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %57, i64 1152
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %57, i64 1280
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %57, i64 1408
  %65 = load double, ptr %64, align 8
  %66 = getelementptr double, ptr %57, i64 1536
  %67 = load double, ptr %66, align 8
  %68 = getelementptr double, ptr %57, i64 1664
  %69 = load double, ptr %68, align 8
  %70 = getelementptr double, ptr %57, i64 1792
  %71 = load double, ptr %70, align 8
  %72 = getelementptr double, ptr %57, i64 1920
  %73 = load double, ptr %72, align 8
  %74 = getelementptr double, ptr %8, i64 %55
  %75 = load double, ptr %74, align 8
  %76 = insertelement <8 x double> poison, double %59, i64 0
  %77 = insertelement <8 x double> %76, double %61, i64 1
  %78 = insertelement <8 x double> %77, double %63, i64 2
  %79 = insertelement <8 x double> %78, double %65, i64 3
  %80 = insertelement <8 x double> %79, double %67, i64 4
  %81 = insertelement <8 x double> %80, double %69, i64 5
  %82 = insertelement <8 x double> %81, double %71, i64 6
  %83 = insertelement <8 x double> %82, double %73, i64 7
  %84 = insertelement <8 x double> poison, double %75, i64 0
  %85 = shufflevector <8 x double> %84, <8 x double> poison, <8 x i32> zeroinitializer
  %86 = fmul <8 x double> %83, %85
  %87 = fadd <8 x double> %56, %86
  store <8 x double> %87, ptr %53, align 8
  %88 = add nuw nsw i64 %55, 1
  %exitcond.1.not = icmp eq i64 %88, 128
  br i1 %exitcond.1.not, label %89, label %54

89:                                               ; preds = %54
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28, i8 0, i64 128, i1 false)
  br label %4

4:                                                ; preds = %4, %3
  %5 = phi i64 [ 0, %3 ], [ %37, %4 ]
  %6 = phi <8 x double> [ zeroinitializer, %3 ], [ %36, %4 ]
  %7 = getelementptr double, ptr %.unpack2, i64 %5
  %8 = load double, ptr %7, align 8
  %9 = getelementptr double, ptr %7, i64 128
  %10 = load double, ptr %9, align 8
  %11 = getelementptr double, ptr %7, i64 256
  %12 = load double, ptr %11, align 8
  %13 = getelementptr double, ptr %7, i64 384
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %7, i64 512
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %7, i64 640
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %7, i64 768
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %7, i64 896
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %.unpack17, i64 %5
  %24 = load double, ptr %23, align 8
  %25 = insertelement <8 x double> poison, double %8, i64 0
  %26 = insertelement <8 x double> %25, double %10, i64 1
  %27 = insertelement <8 x double> %26, double %12, i64 2
  %28 = insertelement <8 x double> %27, double %14, i64 3
  %29 = insertelement <8 x double> %28, double %16, i64 4
  %30 = insertelement <8 x double> %29, double %18, i64 5
  %31 = insertelement <8 x double> %30, double %20, i64 6
  %32 = insertelement <8 x double> %31, double %22, i64 7
  %33 = insertelement <8 x double> poison, double %24, i64 0
  %34 = shufflevector <8 x double> %33, <8 x double> poison, <8 x i32> zeroinitializer
  %35 = fmul <8 x double> %32, %34
  %36 = fadd <8 x double> %6, %35
  store <8 x double> %36, ptr %.unpack28, align 8
  %37 = add nuw nsw i64 %5, 1
  %exitcond.not.i = icmp eq i64 %37, 128
  br i1 %exitcond.not.i, label %38, label %4

38:                                               ; preds = %4
  %39 = getelementptr double, ptr %.unpack28, i64 8
  br label %40

40:                                               ; preds = %40, %38
  %41 = phi i64 [ 0, %38 ], [ %74, %40 ]
  %42 = phi <8 x double> [ zeroinitializer, %38 ], [ %73, %40 ]
  %43 = getelementptr double, ptr %.unpack2, i64 %41
  %44 = getelementptr double, ptr %43, i64 1024
  %45 = load double, ptr %44, align 8
  %46 = getelementptr double, ptr %43, i64 1152
  %47 = load double, ptr %46, align 8
  %48 = getelementptr double, ptr %43, i64 1280
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %43, i64 1408
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %43, i64 1536
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %43, i64 1664
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %43, i64 1792
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %43, i64 1920
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %.unpack17, i64 %41
  %61 = load double, ptr %60, align 8
  %62 = insertelement <8 x double> poison, double %45, i64 0
  %63 = insertelement <8 x double> %62, double %47, i64 1
  %64 = insertelement <8 x double> %63, double %49, i64 2
  %65 = insertelement <8 x double> %64, double %51, i64 3
  %66 = insertelement <8 x double> %65, double %53, i64 4
  %67 = insertelement <8 x double> %66, double %55, i64 5
  %68 = insertelement <8 x double> %67, double %57, i64 6
  %69 = insertelement <8 x double> %68, double %59, i64 7
  %70 = insertelement <8 x double> poison, double %61, i64 0
  %71 = shufflevector <8 x double> %70, <8 x double> poison, <8 x i32> zeroinitializer
  %72 = fmul <8 x double> %69, %71
  %73 = fadd <8 x double> %42, %72
  store <8 x double> %73, ptr %39, align 8
  %74 = add nuw nsw i64 %41, 1
  %exitcond.1.not.i = icmp eq i64 %74, 128
  br i1 %exitcond.1.not.i, label %kernel.exit, label %40

kernel.exit:                                      ; preds = %40
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %10, i8 0, i64 128, i1 false)
  br label %11

11:                                               ; preds = %11, %1
  %12 = phi i64 [ 0, %1 ], [ %44, %11 ]
  %13 = phi <8 x double> [ zeroinitializer, %1 ], [ %43, %11 ]
  %14 = getelementptr double, ptr %4, i64 %12
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %14, i64 128
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %14, i64 256
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %14, i64 384
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %14, i64 512
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %14, i64 640
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %14, i64 768
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %14, i64 896
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %7, i64 %12
  %31 = load double, ptr %30, align 8
  %32 = insertelement <8 x double> poison, double %15, i64 0
  %33 = insertelement <8 x double> %32, double %17, i64 1
  %34 = insertelement <8 x double> %33, double %19, i64 2
  %35 = insertelement <8 x double> %34, double %21, i64 3
  %36 = insertelement <8 x double> %35, double %23, i64 4
  %37 = insertelement <8 x double> %36, double %25, i64 5
  %38 = insertelement <8 x double> %37, double %27, i64 6
  %39 = insertelement <8 x double> %38, double %29, i64 7
  %40 = insertelement <8 x double> poison, double %31, i64 0
  %41 = shufflevector <8 x double> %40, <8 x double> poison, <8 x i32> zeroinitializer
  %42 = fmul <8 x double> %39, %41
  %43 = fadd <8 x double> %13, %42
  store <8 x double> %43, ptr %10, align 8
  %44 = add nuw nsw i64 %12, 1
  %exitcond.not.i = icmp eq i64 %44, 128
  br i1 %exitcond.not.i, label %45, label %11

45:                                               ; preds = %11
  %46 = getelementptr double, ptr %10, i64 8
  br label %47

47:                                               ; preds = %47, %45
  %48 = phi i64 [ 0, %45 ], [ %81, %47 ]
  %49 = phi <8 x double> [ zeroinitializer, %45 ], [ %80, %47 ]
  %50 = getelementptr double, ptr %4, i64 %48
  %51 = getelementptr double, ptr %50, i64 1024
  %52 = load double, ptr %51, align 8
  %53 = getelementptr double, ptr %50, i64 1152
  %54 = load double, ptr %53, align 8
  %55 = getelementptr double, ptr %50, i64 1280
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %50, i64 1408
  %58 = load double, ptr %57, align 8
  %59 = getelementptr double, ptr %50, i64 1536
  %60 = load double, ptr %59, align 8
  %61 = getelementptr double, ptr %50, i64 1664
  %62 = load double, ptr %61, align 8
  %63 = getelementptr double, ptr %50, i64 1792
  %64 = load double, ptr %63, align 8
  %65 = getelementptr double, ptr %50, i64 1920
  %66 = load double, ptr %65, align 8
  %67 = getelementptr double, ptr %7, i64 %48
  %68 = load double, ptr %67, align 8
  %69 = insertelement <8 x double> poison, double %52, i64 0
  %70 = insertelement <8 x double> %69, double %54, i64 1
  %71 = insertelement <8 x double> %70, double %56, i64 2
  %72 = insertelement <8 x double> %71, double %58, i64 3
  %73 = insertelement <8 x double> %72, double %60, i64 4
  %74 = insertelement <8 x double> %73, double %62, i64 5
  %75 = insertelement <8 x double> %74, double %64, i64 6
  %76 = insertelement <8 x double> %75, double %66, i64 7
  %77 = insertelement <8 x double> poison, double %68, i64 0
  %78 = shufflevector <8 x double> %77, <8 x double> poison, <8 x i32> zeroinitializer
  %79 = fmul <8 x double> %76, %78
  %80 = fadd <8 x double> %49, %79
  store <8 x double> %80, ptr %46, align 8
  %81 = add nuw nsw i64 %48, 1
  %exitcond.1.not.i = icmp eq i64 %81, 128
  br i1 %exitcond.1.not.i, label %kernel.exit, label %47

kernel.exit:                                      ; preds = %47
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %.unpack28.i, i8 0, i64 128, i1 false)
  br label %10

10:                                               ; preds = %10, %1
  %11 = phi i64 [ 0, %1 ], [ %43, %10 ]
  %12 = phi <8 x double> [ zeroinitializer, %1 ], [ %42, %10 ]
  %13 = getelementptr double, ptr %.unpack2.i, i64 %11
  %14 = load double, ptr %13, align 8
  %15 = getelementptr double, ptr %13, i64 128
  %16 = load double, ptr %15, align 8
  %17 = getelementptr double, ptr %13, i64 256
  %18 = load double, ptr %17, align 8
  %19 = getelementptr double, ptr %13, i64 384
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %13, i64 512
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %13, i64 640
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %13, i64 768
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %13, i64 896
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %.unpack17.i, i64 %11
  %30 = load double, ptr %29, align 8
  %31 = insertelement <8 x double> poison, double %14, i64 0
  %32 = insertelement <8 x double> %31, double %16, i64 1
  %33 = insertelement <8 x double> %32, double %18, i64 2
  %34 = insertelement <8 x double> %33, double %20, i64 3
  %35 = insertelement <8 x double> %34, double %22, i64 4
  %36 = insertelement <8 x double> %35, double %24, i64 5
  %37 = insertelement <8 x double> %36, double %26, i64 6
  %38 = insertelement <8 x double> %37, double %28, i64 7
  %39 = insertelement <8 x double> poison, double %30, i64 0
  %40 = shufflevector <8 x double> %39, <8 x double> poison, <8 x i32> zeroinitializer
  %41 = fmul <8 x double> %38, %40
  %42 = fadd <8 x double> %12, %41
  store <8 x double> %42, ptr %.unpack28.i, align 8
  %43 = add nuw nsw i64 %11, 1
  %exitcond.not.i.i = icmp eq i64 %43, 128
  br i1 %exitcond.not.i.i, label %44, label %10

44:                                               ; preds = %10
  %45 = getelementptr double, ptr %.unpack28.i, i64 8
  br label %46

46:                                               ; preds = %46, %44
  %47 = phi i64 [ 0, %44 ], [ %80, %46 ]
  %48 = phi <8 x double> [ zeroinitializer, %44 ], [ %79, %46 ]
  %49 = getelementptr double, ptr %.unpack2.i, i64 %47
  %50 = getelementptr double, ptr %49, i64 1024
  %51 = load double, ptr %50, align 8
  %52 = getelementptr double, ptr %49, i64 1152
  %53 = load double, ptr %52, align 8
  %54 = getelementptr double, ptr %49, i64 1280
  %55 = load double, ptr %54, align 8
  %56 = getelementptr double, ptr %49, i64 1408
  %57 = load double, ptr %56, align 8
  %58 = getelementptr double, ptr %49, i64 1536
  %59 = load double, ptr %58, align 8
  %60 = getelementptr double, ptr %49, i64 1664
  %61 = load double, ptr %60, align 8
  %62 = getelementptr double, ptr %49, i64 1792
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %49, i64 1920
  %65 = load double, ptr %64, align 8
  %66 = getelementptr double, ptr %.unpack17.i, i64 %47
  %67 = load double, ptr %66, align 8
  %68 = insertelement <8 x double> poison, double %51, i64 0
  %69 = insertelement <8 x double> %68, double %53, i64 1
  %70 = insertelement <8 x double> %69, double %55, i64 2
  %71 = insertelement <8 x double> %70, double %57, i64 3
  %72 = insertelement <8 x double> %71, double %59, i64 4
  %73 = insertelement <8 x double> %72, double %61, i64 5
  %74 = insertelement <8 x double> %73, double %63, i64 6
  %75 = insertelement <8 x double> %74, double %65, i64 7
  %76 = insertelement <8 x double> poison, double %67, i64 0
  %77 = shufflevector <8 x double> %76, <8 x double> poison, <8 x i32> zeroinitializer
  %78 = fmul <8 x double> %75, %77
  %79 = fadd <8 x double> %48, %78
  store <8 x double> %79, ptr %45, align 8
  %80 = add nuw nsw i64 %47, 1
  %exitcond.1.not.i.i = icmp eq i64 %80, 128
  br i1 %exitcond.1.not.i.i, label %_mlir_ciface_kernel.exit, label %46

_mlir_ciface_kernel.exit:                         ; preds = %46
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
