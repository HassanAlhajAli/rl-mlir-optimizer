; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture writeonly %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %13, i8 0, i64 128, i1 false)
  br label %17

17:                                               ; preds = %17, %.preheader3.preheader
  %18 = phi i64 [ 0, %.preheader3.preheader ], [ %75, %17 ]
  %19 = phi double [ 0.000000e+00, %.preheader3.preheader ], [ %74, %17 ]
  %20 = getelementptr double, ptr %1, i64 %18
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %8, i64 %18
  %23 = load double, ptr %22, align 8
  %24 = fmul double %21, %23
  %25 = fadd double %19, %24
  store double %25, ptr %13, align 8
  %26 = or disjoint i64 %18, 1
  %27 = getelementptr double, ptr %1, i64 %26
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %8, i64 %26
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %25, %31
  store double %32, ptr %13, align 8
  %33 = or disjoint i64 %18, 2
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %8, i64 %33
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %32, %38
  store double %39, ptr %13, align 8
  %40 = or disjoint i64 %18, 3
  %41 = getelementptr double, ptr %1, i64 %40
  %42 = load double, ptr %41, align 8
  %43 = getelementptr double, ptr %8, i64 %40
  %44 = load double, ptr %43, align 8
  %45 = fmul double %42, %44
  %46 = fadd double %39, %45
  store double %46, ptr %13, align 8
  %47 = or disjoint i64 %18, 4
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = load double, ptr %48, align 8
  %50 = getelementptr double, ptr %8, i64 %47
  %51 = load double, ptr %50, align 8
  %52 = fmul double %49, %51
  %53 = fadd double %46, %52
  store double %53, ptr %13, align 8
  %54 = or disjoint i64 %18, 5
  %55 = getelementptr double, ptr %1, i64 %54
  %56 = load double, ptr %55, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %53, %59
  store double %60, ptr %13, align 8
  %61 = or disjoint i64 %18, 6
  %62 = getelementptr double, ptr %1, i64 %61
  %63 = load double, ptr %62, align 8
  %64 = getelementptr double, ptr %8, i64 %61
  %65 = load double, ptr %64, align 8
  %66 = fmul double %63, %65
  %67 = fadd double %60, %66
  store double %67, ptr %13, align 8
  %68 = or disjoint i64 %18, 7
  %69 = getelementptr double, ptr %1, i64 %68
  %70 = load double, ptr %69, align 8
  %71 = getelementptr double, ptr %8, i64 %68
  %72 = load double, ptr %71, align 8
  %73 = fmul double %70, %72
  %74 = fadd double %67, %73
  store double %74, ptr %13, align 8
  %75 = add nuw nsw i64 %18, 8
  %exitcond.not.7 = icmp eq i64 %75, 128
  br i1 %exitcond.not.7, label %.preheader.1, label %17

.preheader.1:                                     ; preds = %17
  %76 = getelementptr double, ptr %13, i64 1
  %invariant.gep16 = getelementptr double, ptr %1, i64 128
  br label %77

77:                                               ; preds = %77, %.preheader.1
  %78 = phi i64 [ 0, %.preheader.1 ], [ %127, %77 ]
  %79 = phi double [ 0.000000e+00, %.preheader.1 ], [ %126, %77 ]
  %gep17 = getelementptr double, ptr %invariant.gep16, i64 %78
  %80 = load double, ptr %gep17, align 8
  %81 = getelementptr double, ptr %8, i64 %78
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %79, %83
  store double %84, ptr %76, align 8
  %85 = or disjoint i64 %78, 1
  %gep17.1 = getelementptr double, ptr %invariant.gep16, i64 %85
  %86 = load double, ptr %gep17.1, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %76, align 8
  %91 = or disjoint i64 %78, 2
  %gep17.2 = getelementptr double, ptr %invariant.gep16, i64 %91
  %92 = load double, ptr %gep17.2, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %76, align 8
  %97 = or disjoint i64 %78, 3
  %gep17.3 = getelementptr double, ptr %invariant.gep16, i64 %97
  %98 = load double, ptr %gep17.3, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %76, align 8
  %103 = or disjoint i64 %78, 4
  %gep17.4 = getelementptr double, ptr %invariant.gep16, i64 %103
  %104 = load double, ptr %gep17.4, align 8
  %105 = getelementptr double, ptr %8, i64 %103
  %106 = load double, ptr %105, align 8
  %107 = fmul double %104, %106
  %108 = fadd double %102, %107
  store double %108, ptr %76, align 8
  %109 = or disjoint i64 %78, 5
  %gep17.5 = getelementptr double, ptr %invariant.gep16, i64 %109
  %110 = load double, ptr %gep17.5, align 8
  %111 = getelementptr double, ptr %8, i64 %109
  %112 = load double, ptr %111, align 8
  %113 = fmul double %110, %112
  %114 = fadd double %108, %113
  store double %114, ptr %76, align 8
  %115 = or disjoint i64 %78, 6
  %gep17.6 = getelementptr double, ptr %invariant.gep16, i64 %115
  %116 = load double, ptr %gep17.6, align 8
  %117 = getelementptr double, ptr %8, i64 %115
  %118 = load double, ptr %117, align 8
  %119 = fmul double %116, %118
  %120 = fadd double %114, %119
  store double %120, ptr %76, align 8
  %121 = or disjoint i64 %78, 7
  %gep17.7 = getelementptr double, ptr %invariant.gep16, i64 %121
  %122 = load double, ptr %gep17.7, align 8
  %123 = getelementptr double, ptr %8, i64 %121
  %124 = load double, ptr %123, align 8
  %125 = fmul double %122, %124
  %126 = fadd double %120, %125
  store double %126, ptr %76, align 8
  %127 = add nuw nsw i64 %78, 8
  %exitcond.1.not.7 = icmp eq i64 %127, 128
  br i1 %exitcond.1.not.7, label %.preheader.2, label %77

.preheader.2:                                     ; preds = %77
  %128 = getelementptr double, ptr %13, i64 2
  %invariant.gep14 = getelementptr double, ptr %1, i64 256
  br label %129

129:                                              ; preds = %129, %.preheader.2
  %130 = phi i64 [ 0, %.preheader.2 ], [ %179, %129 ]
  %131 = phi double [ 0.000000e+00, %.preheader.2 ], [ %178, %129 ]
  %gep15 = getelementptr double, ptr %invariant.gep14, i64 %130
  %132 = load double, ptr %gep15, align 8
  %133 = getelementptr double, ptr %8, i64 %130
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %131, %135
  store double %136, ptr %128, align 8
  %137 = or disjoint i64 %130, 1
  %gep15.1 = getelementptr double, ptr %invariant.gep14, i64 %137
  %138 = load double, ptr %gep15.1, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %128, align 8
  %143 = or disjoint i64 %130, 2
  %gep15.2 = getelementptr double, ptr %invariant.gep14, i64 %143
  %144 = load double, ptr %gep15.2, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %128, align 8
  %149 = or disjoint i64 %130, 3
  %gep15.3 = getelementptr double, ptr %invariant.gep14, i64 %149
  %150 = load double, ptr %gep15.3, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %128, align 8
  %155 = or disjoint i64 %130, 4
  %gep15.4 = getelementptr double, ptr %invariant.gep14, i64 %155
  %156 = load double, ptr %gep15.4, align 8
  %157 = getelementptr double, ptr %8, i64 %155
  %158 = load double, ptr %157, align 8
  %159 = fmul double %156, %158
  %160 = fadd double %154, %159
  store double %160, ptr %128, align 8
  %161 = or disjoint i64 %130, 5
  %gep15.5 = getelementptr double, ptr %invariant.gep14, i64 %161
  %162 = load double, ptr %gep15.5, align 8
  %163 = getelementptr double, ptr %8, i64 %161
  %164 = load double, ptr %163, align 8
  %165 = fmul double %162, %164
  %166 = fadd double %160, %165
  store double %166, ptr %128, align 8
  %167 = or disjoint i64 %130, 6
  %gep15.6 = getelementptr double, ptr %invariant.gep14, i64 %167
  %168 = load double, ptr %gep15.6, align 8
  %169 = getelementptr double, ptr %8, i64 %167
  %170 = load double, ptr %169, align 8
  %171 = fmul double %168, %170
  %172 = fadd double %166, %171
  store double %172, ptr %128, align 8
  %173 = or disjoint i64 %130, 7
  %gep15.7 = getelementptr double, ptr %invariant.gep14, i64 %173
  %174 = load double, ptr %gep15.7, align 8
  %175 = getelementptr double, ptr %8, i64 %173
  %176 = load double, ptr %175, align 8
  %177 = fmul double %174, %176
  %178 = fadd double %172, %177
  store double %178, ptr %128, align 8
  %179 = add nuw nsw i64 %130, 8
  %exitcond.2.not.7 = icmp eq i64 %179, 128
  br i1 %exitcond.2.not.7, label %.preheader.3, label %129

.preheader.3:                                     ; preds = %129
  %180 = getelementptr double, ptr %13, i64 3
  %invariant.gep = getelementptr double, ptr %1, i64 384
  br label %181

181:                                              ; preds = %181, %.preheader.3
  %182 = phi i64 [ 0, %.preheader.3 ], [ %231, %181 ]
  %183 = phi double [ 0.000000e+00, %.preheader.3 ], [ %230, %181 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %182
  %184 = load double, ptr %gep, align 8
  %185 = getelementptr double, ptr %8, i64 %182
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %183, %187
  store double %188, ptr %180, align 8
  %189 = or disjoint i64 %182, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %189
  %190 = load double, ptr %gep.1, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %180, align 8
  %195 = or disjoint i64 %182, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %195
  %196 = load double, ptr %gep.2, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %180, align 8
  %201 = or disjoint i64 %182, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %201
  %202 = load double, ptr %gep.3, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %180, align 8
  %207 = or disjoint i64 %182, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %207
  %208 = load double, ptr %gep.4, align 8
  %209 = getelementptr double, ptr %8, i64 %207
  %210 = load double, ptr %209, align 8
  %211 = fmul double %208, %210
  %212 = fadd double %206, %211
  store double %212, ptr %180, align 8
  %213 = or disjoint i64 %182, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %213
  %214 = load double, ptr %gep.5, align 8
  %215 = getelementptr double, ptr %8, i64 %213
  %216 = load double, ptr %215, align 8
  %217 = fmul double %214, %216
  %218 = fadd double %212, %217
  store double %218, ptr %180, align 8
  %219 = or disjoint i64 %182, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %219
  %220 = load double, ptr %gep.6, align 8
  %221 = getelementptr double, ptr %8, i64 %219
  %222 = load double, ptr %221, align 8
  %223 = fmul double %220, %222
  %224 = fadd double %218, %223
  store double %224, ptr %180, align 8
  %225 = or disjoint i64 %182, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %225
  %226 = load double, ptr %gep.7, align 8
  %227 = getelementptr double, ptr %8, i64 %225
  %228 = load double, ptr %227, align 8
  %229 = fmul double %226, %228
  %230 = fadd double %224, %229
  store double %230, ptr %180, align 8
  %231 = add nuw nsw i64 %182, 8
  %exitcond.3.not.7 = icmp eq i64 %231, 128
  br i1 %exitcond.3.not.7, label %.preheader3.1, label %181

.preheader3.1:                                    ; preds = %181
  %232 = getelementptr double, ptr %1, i64 512
  %233 = getelementptr double, ptr %13, i64 4
  br label %234

234:                                              ; preds = %234, %.preheader3.1
  %235 = phi i64 [ 0, %.preheader3.1 ], [ %292, %234 ]
  %236 = phi double [ 0.000000e+00, %.preheader3.1 ], [ %291, %234 ]
  %237 = getelementptr double, ptr %232, i64 %235
  %238 = load double, ptr %237, align 8
  %239 = getelementptr double, ptr %8, i64 %235
  %240 = load double, ptr %239, align 8
  %241 = fmul double %238, %240
  %242 = fadd double %236, %241
  store double %242, ptr %233, align 8
  %243 = or disjoint i64 %235, 1
  %244 = getelementptr double, ptr %232, i64 %243
  %245 = load double, ptr %244, align 8
  %246 = getelementptr double, ptr %8, i64 %243
  %247 = load double, ptr %246, align 8
  %248 = fmul double %245, %247
  %249 = fadd double %242, %248
  store double %249, ptr %233, align 8
  %250 = or disjoint i64 %235, 2
  %251 = getelementptr double, ptr %232, i64 %250
  %252 = load double, ptr %251, align 8
  %253 = getelementptr double, ptr %8, i64 %250
  %254 = load double, ptr %253, align 8
  %255 = fmul double %252, %254
  %256 = fadd double %249, %255
  store double %256, ptr %233, align 8
  %257 = or disjoint i64 %235, 3
  %258 = getelementptr double, ptr %232, i64 %257
  %259 = load double, ptr %258, align 8
  %260 = getelementptr double, ptr %8, i64 %257
  %261 = load double, ptr %260, align 8
  %262 = fmul double %259, %261
  %263 = fadd double %256, %262
  store double %263, ptr %233, align 8
  %264 = or disjoint i64 %235, 4
  %265 = getelementptr double, ptr %232, i64 %264
  %266 = load double, ptr %265, align 8
  %267 = getelementptr double, ptr %8, i64 %264
  %268 = load double, ptr %267, align 8
  %269 = fmul double %266, %268
  %270 = fadd double %263, %269
  store double %270, ptr %233, align 8
  %271 = or disjoint i64 %235, 5
  %272 = getelementptr double, ptr %232, i64 %271
  %273 = load double, ptr %272, align 8
  %274 = getelementptr double, ptr %8, i64 %271
  %275 = load double, ptr %274, align 8
  %276 = fmul double %273, %275
  %277 = fadd double %270, %276
  store double %277, ptr %233, align 8
  %278 = or disjoint i64 %235, 6
  %279 = getelementptr double, ptr %232, i64 %278
  %280 = load double, ptr %279, align 8
  %281 = getelementptr double, ptr %8, i64 %278
  %282 = load double, ptr %281, align 8
  %283 = fmul double %280, %282
  %284 = fadd double %277, %283
  store double %284, ptr %233, align 8
  %285 = or disjoint i64 %235, 7
  %286 = getelementptr double, ptr %232, i64 %285
  %287 = load double, ptr %286, align 8
  %288 = getelementptr double, ptr %8, i64 %285
  %289 = load double, ptr %288, align 8
  %290 = fmul double %287, %289
  %291 = fadd double %284, %290
  store double %291, ptr %233, align 8
  %292 = add nuw nsw i64 %235, 8
  %exitcond.17.not.7 = icmp eq i64 %292, 128
  br i1 %exitcond.17.not.7, label %.preheader.1.1, label %234

.preheader.1.1:                                   ; preds = %234
  %293 = getelementptr double, ptr %13, i64 5
  %invariant.gep18 = getelementptr double, ptr %1, i64 640
  br label %294

294:                                              ; preds = %294, %.preheader.1.1
  %295 = phi i64 [ 0, %.preheader.1.1 ], [ %344, %294 ]
  %296 = phi double [ 0.000000e+00, %.preheader.1.1 ], [ %343, %294 ]
  %gep19 = getelementptr double, ptr %invariant.gep18, i64 %295
  %297 = load double, ptr %gep19, align 8
  %298 = getelementptr double, ptr %8, i64 %295
  %299 = load double, ptr %298, align 8
  %300 = fmul double %297, %299
  %301 = fadd double %296, %300
  store double %301, ptr %293, align 8
  %302 = or disjoint i64 %295, 1
  %gep19.1 = getelementptr double, ptr %invariant.gep18, i64 %302
  %303 = load double, ptr %gep19.1, align 8
  %304 = getelementptr double, ptr %8, i64 %302
  %305 = load double, ptr %304, align 8
  %306 = fmul double %303, %305
  %307 = fadd double %301, %306
  store double %307, ptr %293, align 8
  %308 = or disjoint i64 %295, 2
  %gep19.2 = getelementptr double, ptr %invariant.gep18, i64 %308
  %309 = load double, ptr %gep19.2, align 8
  %310 = getelementptr double, ptr %8, i64 %308
  %311 = load double, ptr %310, align 8
  %312 = fmul double %309, %311
  %313 = fadd double %307, %312
  store double %313, ptr %293, align 8
  %314 = or disjoint i64 %295, 3
  %gep19.3 = getelementptr double, ptr %invariant.gep18, i64 %314
  %315 = load double, ptr %gep19.3, align 8
  %316 = getelementptr double, ptr %8, i64 %314
  %317 = load double, ptr %316, align 8
  %318 = fmul double %315, %317
  %319 = fadd double %313, %318
  store double %319, ptr %293, align 8
  %320 = or disjoint i64 %295, 4
  %gep19.4 = getelementptr double, ptr %invariant.gep18, i64 %320
  %321 = load double, ptr %gep19.4, align 8
  %322 = getelementptr double, ptr %8, i64 %320
  %323 = load double, ptr %322, align 8
  %324 = fmul double %321, %323
  %325 = fadd double %319, %324
  store double %325, ptr %293, align 8
  %326 = or disjoint i64 %295, 5
  %gep19.5 = getelementptr double, ptr %invariant.gep18, i64 %326
  %327 = load double, ptr %gep19.5, align 8
  %328 = getelementptr double, ptr %8, i64 %326
  %329 = load double, ptr %328, align 8
  %330 = fmul double %327, %329
  %331 = fadd double %325, %330
  store double %331, ptr %293, align 8
  %332 = or disjoint i64 %295, 6
  %gep19.6 = getelementptr double, ptr %invariant.gep18, i64 %332
  %333 = load double, ptr %gep19.6, align 8
  %334 = getelementptr double, ptr %8, i64 %332
  %335 = load double, ptr %334, align 8
  %336 = fmul double %333, %335
  %337 = fadd double %331, %336
  store double %337, ptr %293, align 8
  %338 = or disjoint i64 %295, 7
  %gep19.7 = getelementptr double, ptr %invariant.gep18, i64 %338
  %339 = load double, ptr %gep19.7, align 8
  %340 = getelementptr double, ptr %8, i64 %338
  %341 = load double, ptr %340, align 8
  %342 = fmul double %339, %341
  %343 = fadd double %337, %342
  store double %343, ptr %293, align 8
  %344 = add nuw nsw i64 %295, 8
  %exitcond.1.1.not.7 = icmp eq i64 %344, 128
  br i1 %exitcond.1.1.not.7, label %.preheader.2.1, label %294

.preheader.2.1:                                   ; preds = %294
  %345 = getelementptr double, ptr %13, i64 6
  %invariant.gep20 = getelementptr double, ptr %1, i64 768
  br label %346

346:                                              ; preds = %346, %.preheader.2.1
  %347 = phi i64 [ 0, %.preheader.2.1 ], [ %396, %346 ]
  %348 = phi double [ 0.000000e+00, %.preheader.2.1 ], [ %395, %346 ]
  %gep21 = getelementptr double, ptr %invariant.gep20, i64 %347
  %349 = load double, ptr %gep21, align 8
  %350 = getelementptr double, ptr %8, i64 %347
  %351 = load double, ptr %350, align 8
  %352 = fmul double %349, %351
  %353 = fadd double %348, %352
  store double %353, ptr %345, align 8
  %354 = or disjoint i64 %347, 1
  %gep21.1 = getelementptr double, ptr %invariant.gep20, i64 %354
  %355 = load double, ptr %gep21.1, align 8
  %356 = getelementptr double, ptr %8, i64 %354
  %357 = load double, ptr %356, align 8
  %358 = fmul double %355, %357
  %359 = fadd double %353, %358
  store double %359, ptr %345, align 8
  %360 = or disjoint i64 %347, 2
  %gep21.2 = getelementptr double, ptr %invariant.gep20, i64 %360
  %361 = load double, ptr %gep21.2, align 8
  %362 = getelementptr double, ptr %8, i64 %360
  %363 = load double, ptr %362, align 8
  %364 = fmul double %361, %363
  %365 = fadd double %359, %364
  store double %365, ptr %345, align 8
  %366 = or disjoint i64 %347, 3
  %gep21.3 = getelementptr double, ptr %invariant.gep20, i64 %366
  %367 = load double, ptr %gep21.3, align 8
  %368 = getelementptr double, ptr %8, i64 %366
  %369 = load double, ptr %368, align 8
  %370 = fmul double %367, %369
  %371 = fadd double %365, %370
  store double %371, ptr %345, align 8
  %372 = or disjoint i64 %347, 4
  %gep21.4 = getelementptr double, ptr %invariant.gep20, i64 %372
  %373 = load double, ptr %gep21.4, align 8
  %374 = getelementptr double, ptr %8, i64 %372
  %375 = load double, ptr %374, align 8
  %376 = fmul double %373, %375
  %377 = fadd double %371, %376
  store double %377, ptr %345, align 8
  %378 = or disjoint i64 %347, 5
  %gep21.5 = getelementptr double, ptr %invariant.gep20, i64 %378
  %379 = load double, ptr %gep21.5, align 8
  %380 = getelementptr double, ptr %8, i64 %378
  %381 = load double, ptr %380, align 8
  %382 = fmul double %379, %381
  %383 = fadd double %377, %382
  store double %383, ptr %345, align 8
  %384 = or disjoint i64 %347, 6
  %gep21.6 = getelementptr double, ptr %invariant.gep20, i64 %384
  %385 = load double, ptr %gep21.6, align 8
  %386 = getelementptr double, ptr %8, i64 %384
  %387 = load double, ptr %386, align 8
  %388 = fmul double %385, %387
  %389 = fadd double %383, %388
  store double %389, ptr %345, align 8
  %390 = or disjoint i64 %347, 7
  %gep21.7 = getelementptr double, ptr %invariant.gep20, i64 %390
  %391 = load double, ptr %gep21.7, align 8
  %392 = getelementptr double, ptr %8, i64 %390
  %393 = load double, ptr %392, align 8
  %394 = fmul double %391, %393
  %395 = fadd double %389, %394
  store double %395, ptr %345, align 8
  %396 = add nuw nsw i64 %347, 8
  %exitcond.2.1.not.7 = icmp eq i64 %396, 128
  br i1 %exitcond.2.1.not.7, label %.preheader.3.1, label %346

.preheader.3.1:                                   ; preds = %346
  %397 = getelementptr double, ptr %13, i64 7
  %invariant.gep22 = getelementptr double, ptr %1, i64 896
  br label %398

398:                                              ; preds = %398, %.preheader.3.1
  %399 = phi i64 [ 0, %.preheader.3.1 ], [ %448, %398 ]
  %400 = phi double [ 0.000000e+00, %.preheader.3.1 ], [ %447, %398 ]
  %gep23 = getelementptr double, ptr %invariant.gep22, i64 %399
  %401 = load double, ptr %gep23, align 8
  %402 = getelementptr double, ptr %8, i64 %399
  %403 = load double, ptr %402, align 8
  %404 = fmul double %401, %403
  %405 = fadd double %400, %404
  store double %405, ptr %397, align 8
  %406 = or disjoint i64 %399, 1
  %gep23.1 = getelementptr double, ptr %invariant.gep22, i64 %406
  %407 = load double, ptr %gep23.1, align 8
  %408 = getelementptr double, ptr %8, i64 %406
  %409 = load double, ptr %408, align 8
  %410 = fmul double %407, %409
  %411 = fadd double %405, %410
  store double %411, ptr %397, align 8
  %412 = or disjoint i64 %399, 2
  %gep23.2 = getelementptr double, ptr %invariant.gep22, i64 %412
  %413 = load double, ptr %gep23.2, align 8
  %414 = getelementptr double, ptr %8, i64 %412
  %415 = load double, ptr %414, align 8
  %416 = fmul double %413, %415
  %417 = fadd double %411, %416
  store double %417, ptr %397, align 8
  %418 = or disjoint i64 %399, 3
  %gep23.3 = getelementptr double, ptr %invariant.gep22, i64 %418
  %419 = load double, ptr %gep23.3, align 8
  %420 = getelementptr double, ptr %8, i64 %418
  %421 = load double, ptr %420, align 8
  %422 = fmul double %419, %421
  %423 = fadd double %417, %422
  store double %423, ptr %397, align 8
  %424 = or disjoint i64 %399, 4
  %gep23.4 = getelementptr double, ptr %invariant.gep22, i64 %424
  %425 = load double, ptr %gep23.4, align 8
  %426 = getelementptr double, ptr %8, i64 %424
  %427 = load double, ptr %426, align 8
  %428 = fmul double %425, %427
  %429 = fadd double %423, %428
  store double %429, ptr %397, align 8
  %430 = or disjoint i64 %399, 5
  %gep23.5 = getelementptr double, ptr %invariant.gep22, i64 %430
  %431 = load double, ptr %gep23.5, align 8
  %432 = getelementptr double, ptr %8, i64 %430
  %433 = load double, ptr %432, align 8
  %434 = fmul double %431, %433
  %435 = fadd double %429, %434
  store double %435, ptr %397, align 8
  %436 = or disjoint i64 %399, 6
  %gep23.6 = getelementptr double, ptr %invariant.gep22, i64 %436
  %437 = load double, ptr %gep23.6, align 8
  %438 = getelementptr double, ptr %8, i64 %436
  %439 = load double, ptr %438, align 8
  %440 = fmul double %437, %439
  %441 = fadd double %435, %440
  store double %441, ptr %397, align 8
  %442 = or disjoint i64 %399, 7
  %gep23.7 = getelementptr double, ptr %invariant.gep22, i64 %442
  %443 = load double, ptr %gep23.7, align 8
  %444 = getelementptr double, ptr %8, i64 %442
  %445 = load double, ptr %444, align 8
  %446 = fmul double %443, %445
  %447 = fadd double %441, %446
  store double %447, ptr %397, align 8
  %448 = add nuw nsw i64 %399, 8
  %exitcond.3.1.not.7 = icmp eq i64 %448, 128
  br i1 %exitcond.3.1.not.7, label %.preheader3.2, label %398

.preheader3.2:                                    ; preds = %398
  %449 = getelementptr double, ptr %1, i64 1024
  %450 = getelementptr double, ptr %13, i64 8
  br label %451

451:                                              ; preds = %451, %.preheader3.2
  %452 = phi i64 [ 0, %.preheader3.2 ], [ %509, %451 ]
  %453 = phi double [ 0.000000e+00, %.preheader3.2 ], [ %508, %451 ]
  %454 = getelementptr double, ptr %449, i64 %452
  %455 = load double, ptr %454, align 8
  %456 = getelementptr double, ptr %8, i64 %452
  %457 = load double, ptr %456, align 8
  %458 = fmul double %455, %457
  %459 = fadd double %453, %458
  store double %459, ptr %450, align 8
  %460 = or disjoint i64 %452, 1
  %461 = getelementptr double, ptr %449, i64 %460
  %462 = load double, ptr %461, align 8
  %463 = getelementptr double, ptr %8, i64 %460
  %464 = load double, ptr %463, align 8
  %465 = fmul double %462, %464
  %466 = fadd double %459, %465
  store double %466, ptr %450, align 8
  %467 = or disjoint i64 %452, 2
  %468 = getelementptr double, ptr %449, i64 %467
  %469 = load double, ptr %468, align 8
  %470 = getelementptr double, ptr %8, i64 %467
  %471 = load double, ptr %470, align 8
  %472 = fmul double %469, %471
  %473 = fadd double %466, %472
  store double %473, ptr %450, align 8
  %474 = or disjoint i64 %452, 3
  %475 = getelementptr double, ptr %449, i64 %474
  %476 = load double, ptr %475, align 8
  %477 = getelementptr double, ptr %8, i64 %474
  %478 = load double, ptr %477, align 8
  %479 = fmul double %476, %478
  %480 = fadd double %473, %479
  store double %480, ptr %450, align 8
  %481 = or disjoint i64 %452, 4
  %482 = getelementptr double, ptr %449, i64 %481
  %483 = load double, ptr %482, align 8
  %484 = getelementptr double, ptr %8, i64 %481
  %485 = load double, ptr %484, align 8
  %486 = fmul double %483, %485
  %487 = fadd double %480, %486
  store double %487, ptr %450, align 8
  %488 = or disjoint i64 %452, 5
  %489 = getelementptr double, ptr %449, i64 %488
  %490 = load double, ptr %489, align 8
  %491 = getelementptr double, ptr %8, i64 %488
  %492 = load double, ptr %491, align 8
  %493 = fmul double %490, %492
  %494 = fadd double %487, %493
  store double %494, ptr %450, align 8
  %495 = or disjoint i64 %452, 6
  %496 = getelementptr double, ptr %449, i64 %495
  %497 = load double, ptr %496, align 8
  %498 = getelementptr double, ptr %8, i64 %495
  %499 = load double, ptr %498, align 8
  %500 = fmul double %497, %499
  %501 = fadd double %494, %500
  store double %501, ptr %450, align 8
  %502 = or disjoint i64 %452, 7
  %503 = getelementptr double, ptr %449, i64 %502
  %504 = load double, ptr %503, align 8
  %505 = getelementptr double, ptr %8, i64 %502
  %506 = load double, ptr %505, align 8
  %507 = fmul double %504, %506
  %508 = fadd double %501, %507
  store double %508, ptr %450, align 8
  %509 = add nuw nsw i64 %452, 8
  %exitcond.210.not.7 = icmp eq i64 %509, 128
  br i1 %exitcond.210.not.7, label %.preheader.1.2, label %451

.preheader.1.2:                                   ; preds = %451
  %510 = getelementptr double, ptr %13, i64 9
  %invariant.gep24 = getelementptr double, ptr %1, i64 1152
  br label %511

511:                                              ; preds = %511, %.preheader.1.2
  %512 = phi i64 [ 0, %.preheader.1.2 ], [ %561, %511 ]
  %513 = phi double [ 0.000000e+00, %.preheader.1.2 ], [ %560, %511 ]
  %gep25 = getelementptr double, ptr %invariant.gep24, i64 %512
  %514 = load double, ptr %gep25, align 8
  %515 = getelementptr double, ptr %8, i64 %512
  %516 = load double, ptr %515, align 8
  %517 = fmul double %514, %516
  %518 = fadd double %513, %517
  store double %518, ptr %510, align 8
  %519 = or disjoint i64 %512, 1
  %gep25.1 = getelementptr double, ptr %invariant.gep24, i64 %519
  %520 = load double, ptr %gep25.1, align 8
  %521 = getelementptr double, ptr %8, i64 %519
  %522 = load double, ptr %521, align 8
  %523 = fmul double %520, %522
  %524 = fadd double %518, %523
  store double %524, ptr %510, align 8
  %525 = or disjoint i64 %512, 2
  %gep25.2 = getelementptr double, ptr %invariant.gep24, i64 %525
  %526 = load double, ptr %gep25.2, align 8
  %527 = getelementptr double, ptr %8, i64 %525
  %528 = load double, ptr %527, align 8
  %529 = fmul double %526, %528
  %530 = fadd double %524, %529
  store double %530, ptr %510, align 8
  %531 = or disjoint i64 %512, 3
  %gep25.3 = getelementptr double, ptr %invariant.gep24, i64 %531
  %532 = load double, ptr %gep25.3, align 8
  %533 = getelementptr double, ptr %8, i64 %531
  %534 = load double, ptr %533, align 8
  %535 = fmul double %532, %534
  %536 = fadd double %530, %535
  store double %536, ptr %510, align 8
  %537 = or disjoint i64 %512, 4
  %gep25.4 = getelementptr double, ptr %invariant.gep24, i64 %537
  %538 = load double, ptr %gep25.4, align 8
  %539 = getelementptr double, ptr %8, i64 %537
  %540 = load double, ptr %539, align 8
  %541 = fmul double %538, %540
  %542 = fadd double %536, %541
  store double %542, ptr %510, align 8
  %543 = or disjoint i64 %512, 5
  %gep25.5 = getelementptr double, ptr %invariant.gep24, i64 %543
  %544 = load double, ptr %gep25.5, align 8
  %545 = getelementptr double, ptr %8, i64 %543
  %546 = load double, ptr %545, align 8
  %547 = fmul double %544, %546
  %548 = fadd double %542, %547
  store double %548, ptr %510, align 8
  %549 = or disjoint i64 %512, 6
  %gep25.6 = getelementptr double, ptr %invariant.gep24, i64 %549
  %550 = load double, ptr %gep25.6, align 8
  %551 = getelementptr double, ptr %8, i64 %549
  %552 = load double, ptr %551, align 8
  %553 = fmul double %550, %552
  %554 = fadd double %548, %553
  store double %554, ptr %510, align 8
  %555 = or disjoint i64 %512, 7
  %gep25.7 = getelementptr double, ptr %invariant.gep24, i64 %555
  %556 = load double, ptr %gep25.7, align 8
  %557 = getelementptr double, ptr %8, i64 %555
  %558 = load double, ptr %557, align 8
  %559 = fmul double %556, %558
  %560 = fadd double %554, %559
  store double %560, ptr %510, align 8
  %561 = add nuw nsw i64 %512, 8
  %exitcond.1.2.not.7 = icmp eq i64 %561, 128
  br i1 %exitcond.1.2.not.7, label %.preheader.2.2, label %511

.preheader.2.2:                                   ; preds = %511
  %562 = getelementptr double, ptr %13, i64 10
  %invariant.gep26 = getelementptr double, ptr %1, i64 1280
  br label %563

563:                                              ; preds = %563, %.preheader.2.2
  %564 = phi i64 [ 0, %.preheader.2.2 ], [ %613, %563 ]
  %565 = phi double [ 0.000000e+00, %.preheader.2.2 ], [ %612, %563 ]
  %gep27 = getelementptr double, ptr %invariant.gep26, i64 %564
  %566 = load double, ptr %gep27, align 8
  %567 = getelementptr double, ptr %8, i64 %564
  %568 = load double, ptr %567, align 8
  %569 = fmul double %566, %568
  %570 = fadd double %565, %569
  store double %570, ptr %562, align 8
  %571 = or disjoint i64 %564, 1
  %gep27.1 = getelementptr double, ptr %invariant.gep26, i64 %571
  %572 = load double, ptr %gep27.1, align 8
  %573 = getelementptr double, ptr %8, i64 %571
  %574 = load double, ptr %573, align 8
  %575 = fmul double %572, %574
  %576 = fadd double %570, %575
  store double %576, ptr %562, align 8
  %577 = or disjoint i64 %564, 2
  %gep27.2 = getelementptr double, ptr %invariant.gep26, i64 %577
  %578 = load double, ptr %gep27.2, align 8
  %579 = getelementptr double, ptr %8, i64 %577
  %580 = load double, ptr %579, align 8
  %581 = fmul double %578, %580
  %582 = fadd double %576, %581
  store double %582, ptr %562, align 8
  %583 = or disjoint i64 %564, 3
  %gep27.3 = getelementptr double, ptr %invariant.gep26, i64 %583
  %584 = load double, ptr %gep27.3, align 8
  %585 = getelementptr double, ptr %8, i64 %583
  %586 = load double, ptr %585, align 8
  %587 = fmul double %584, %586
  %588 = fadd double %582, %587
  store double %588, ptr %562, align 8
  %589 = or disjoint i64 %564, 4
  %gep27.4 = getelementptr double, ptr %invariant.gep26, i64 %589
  %590 = load double, ptr %gep27.4, align 8
  %591 = getelementptr double, ptr %8, i64 %589
  %592 = load double, ptr %591, align 8
  %593 = fmul double %590, %592
  %594 = fadd double %588, %593
  store double %594, ptr %562, align 8
  %595 = or disjoint i64 %564, 5
  %gep27.5 = getelementptr double, ptr %invariant.gep26, i64 %595
  %596 = load double, ptr %gep27.5, align 8
  %597 = getelementptr double, ptr %8, i64 %595
  %598 = load double, ptr %597, align 8
  %599 = fmul double %596, %598
  %600 = fadd double %594, %599
  store double %600, ptr %562, align 8
  %601 = or disjoint i64 %564, 6
  %gep27.6 = getelementptr double, ptr %invariant.gep26, i64 %601
  %602 = load double, ptr %gep27.6, align 8
  %603 = getelementptr double, ptr %8, i64 %601
  %604 = load double, ptr %603, align 8
  %605 = fmul double %602, %604
  %606 = fadd double %600, %605
  store double %606, ptr %562, align 8
  %607 = or disjoint i64 %564, 7
  %gep27.7 = getelementptr double, ptr %invariant.gep26, i64 %607
  %608 = load double, ptr %gep27.7, align 8
  %609 = getelementptr double, ptr %8, i64 %607
  %610 = load double, ptr %609, align 8
  %611 = fmul double %608, %610
  %612 = fadd double %606, %611
  store double %612, ptr %562, align 8
  %613 = add nuw nsw i64 %564, 8
  %exitcond.2.2.not.7 = icmp eq i64 %613, 128
  br i1 %exitcond.2.2.not.7, label %.preheader.3.2, label %563

.preheader.3.2:                                   ; preds = %563
  %614 = getelementptr double, ptr %13, i64 11
  %invariant.gep28 = getelementptr double, ptr %1, i64 1408
  br label %615

615:                                              ; preds = %615, %.preheader.3.2
  %616 = phi i64 [ 0, %.preheader.3.2 ], [ %665, %615 ]
  %617 = phi double [ 0.000000e+00, %.preheader.3.2 ], [ %664, %615 ]
  %gep29 = getelementptr double, ptr %invariant.gep28, i64 %616
  %618 = load double, ptr %gep29, align 8
  %619 = getelementptr double, ptr %8, i64 %616
  %620 = load double, ptr %619, align 8
  %621 = fmul double %618, %620
  %622 = fadd double %617, %621
  store double %622, ptr %614, align 8
  %623 = or disjoint i64 %616, 1
  %gep29.1 = getelementptr double, ptr %invariant.gep28, i64 %623
  %624 = load double, ptr %gep29.1, align 8
  %625 = getelementptr double, ptr %8, i64 %623
  %626 = load double, ptr %625, align 8
  %627 = fmul double %624, %626
  %628 = fadd double %622, %627
  store double %628, ptr %614, align 8
  %629 = or disjoint i64 %616, 2
  %gep29.2 = getelementptr double, ptr %invariant.gep28, i64 %629
  %630 = load double, ptr %gep29.2, align 8
  %631 = getelementptr double, ptr %8, i64 %629
  %632 = load double, ptr %631, align 8
  %633 = fmul double %630, %632
  %634 = fadd double %628, %633
  store double %634, ptr %614, align 8
  %635 = or disjoint i64 %616, 3
  %gep29.3 = getelementptr double, ptr %invariant.gep28, i64 %635
  %636 = load double, ptr %gep29.3, align 8
  %637 = getelementptr double, ptr %8, i64 %635
  %638 = load double, ptr %637, align 8
  %639 = fmul double %636, %638
  %640 = fadd double %634, %639
  store double %640, ptr %614, align 8
  %641 = or disjoint i64 %616, 4
  %gep29.4 = getelementptr double, ptr %invariant.gep28, i64 %641
  %642 = load double, ptr %gep29.4, align 8
  %643 = getelementptr double, ptr %8, i64 %641
  %644 = load double, ptr %643, align 8
  %645 = fmul double %642, %644
  %646 = fadd double %640, %645
  store double %646, ptr %614, align 8
  %647 = or disjoint i64 %616, 5
  %gep29.5 = getelementptr double, ptr %invariant.gep28, i64 %647
  %648 = load double, ptr %gep29.5, align 8
  %649 = getelementptr double, ptr %8, i64 %647
  %650 = load double, ptr %649, align 8
  %651 = fmul double %648, %650
  %652 = fadd double %646, %651
  store double %652, ptr %614, align 8
  %653 = or disjoint i64 %616, 6
  %gep29.6 = getelementptr double, ptr %invariant.gep28, i64 %653
  %654 = load double, ptr %gep29.6, align 8
  %655 = getelementptr double, ptr %8, i64 %653
  %656 = load double, ptr %655, align 8
  %657 = fmul double %654, %656
  %658 = fadd double %652, %657
  store double %658, ptr %614, align 8
  %659 = or disjoint i64 %616, 7
  %gep29.7 = getelementptr double, ptr %invariant.gep28, i64 %659
  %660 = load double, ptr %gep29.7, align 8
  %661 = getelementptr double, ptr %8, i64 %659
  %662 = load double, ptr %661, align 8
  %663 = fmul double %660, %662
  %664 = fadd double %658, %663
  store double %664, ptr %614, align 8
  %665 = add nuw nsw i64 %616, 8
  %exitcond.3.2.not.7 = icmp eq i64 %665, 128
  br i1 %exitcond.3.2.not.7, label %.preheader3.3, label %615

.preheader3.3:                                    ; preds = %615
  %666 = getelementptr double, ptr %1, i64 1536
  %667 = getelementptr double, ptr %13, i64 12
  br label %668

668:                                              ; preds = %668, %.preheader3.3
  %669 = phi i64 [ 0, %.preheader3.3 ], [ %726, %668 ]
  %670 = phi double [ 0.000000e+00, %.preheader3.3 ], [ %725, %668 ]
  %671 = getelementptr double, ptr %666, i64 %669
  %672 = load double, ptr %671, align 8
  %673 = getelementptr double, ptr %8, i64 %669
  %674 = load double, ptr %673, align 8
  %675 = fmul double %672, %674
  %676 = fadd double %670, %675
  store double %676, ptr %667, align 8
  %677 = or disjoint i64 %669, 1
  %678 = getelementptr double, ptr %666, i64 %677
  %679 = load double, ptr %678, align 8
  %680 = getelementptr double, ptr %8, i64 %677
  %681 = load double, ptr %680, align 8
  %682 = fmul double %679, %681
  %683 = fadd double %676, %682
  store double %683, ptr %667, align 8
  %684 = or disjoint i64 %669, 2
  %685 = getelementptr double, ptr %666, i64 %684
  %686 = load double, ptr %685, align 8
  %687 = getelementptr double, ptr %8, i64 %684
  %688 = load double, ptr %687, align 8
  %689 = fmul double %686, %688
  %690 = fadd double %683, %689
  store double %690, ptr %667, align 8
  %691 = or disjoint i64 %669, 3
  %692 = getelementptr double, ptr %666, i64 %691
  %693 = load double, ptr %692, align 8
  %694 = getelementptr double, ptr %8, i64 %691
  %695 = load double, ptr %694, align 8
  %696 = fmul double %693, %695
  %697 = fadd double %690, %696
  store double %697, ptr %667, align 8
  %698 = or disjoint i64 %669, 4
  %699 = getelementptr double, ptr %666, i64 %698
  %700 = load double, ptr %699, align 8
  %701 = getelementptr double, ptr %8, i64 %698
  %702 = load double, ptr %701, align 8
  %703 = fmul double %700, %702
  %704 = fadd double %697, %703
  store double %704, ptr %667, align 8
  %705 = or disjoint i64 %669, 5
  %706 = getelementptr double, ptr %666, i64 %705
  %707 = load double, ptr %706, align 8
  %708 = getelementptr double, ptr %8, i64 %705
  %709 = load double, ptr %708, align 8
  %710 = fmul double %707, %709
  %711 = fadd double %704, %710
  store double %711, ptr %667, align 8
  %712 = or disjoint i64 %669, 6
  %713 = getelementptr double, ptr %666, i64 %712
  %714 = load double, ptr %713, align 8
  %715 = getelementptr double, ptr %8, i64 %712
  %716 = load double, ptr %715, align 8
  %717 = fmul double %714, %716
  %718 = fadd double %711, %717
  store double %718, ptr %667, align 8
  %719 = or disjoint i64 %669, 7
  %720 = getelementptr double, ptr %666, i64 %719
  %721 = load double, ptr %720, align 8
  %722 = getelementptr double, ptr %8, i64 %719
  %723 = load double, ptr %722, align 8
  %724 = fmul double %721, %723
  %725 = fadd double %718, %724
  store double %725, ptr %667, align 8
  %726 = add nuw nsw i64 %669, 8
  %exitcond.313.not.7 = icmp eq i64 %726, 128
  br i1 %exitcond.313.not.7, label %.preheader.1.3, label %668

.preheader.1.3:                                   ; preds = %668
  %727 = getelementptr double, ptr %13, i64 13
  %invariant.gep30 = getelementptr double, ptr %1, i64 1664
  br label %728

728:                                              ; preds = %728, %.preheader.1.3
  %729 = phi i64 [ 0, %.preheader.1.3 ], [ %778, %728 ]
  %730 = phi double [ 0.000000e+00, %.preheader.1.3 ], [ %777, %728 ]
  %gep31 = getelementptr double, ptr %invariant.gep30, i64 %729
  %731 = load double, ptr %gep31, align 8
  %732 = getelementptr double, ptr %8, i64 %729
  %733 = load double, ptr %732, align 8
  %734 = fmul double %731, %733
  %735 = fadd double %730, %734
  store double %735, ptr %727, align 8
  %736 = or disjoint i64 %729, 1
  %gep31.1 = getelementptr double, ptr %invariant.gep30, i64 %736
  %737 = load double, ptr %gep31.1, align 8
  %738 = getelementptr double, ptr %8, i64 %736
  %739 = load double, ptr %738, align 8
  %740 = fmul double %737, %739
  %741 = fadd double %735, %740
  store double %741, ptr %727, align 8
  %742 = or disjoint i64 %729, 2
  %gep31.2 = getelementptr double, ptr %invariant.gep30, i64 %742
  %743 = load double, ptr %gep31.2, align 8
  %744 = getelementptr double, ptr %8, i64 %742
  %745 = load double, ptr %744, align 8
  %746 = fmul double %743, %745
  %747 = fadd double %741, %746
  store double %747, ptr %727, align 8
  %748 = or disjoint i64 %729, 3
  %gep31.3 = getelementptr double, ptr %invariant.gep30, i64 %748
  %749 = load double, ptr %gep31.3, align 8
  %750 = getelementptr double, ptr %8, i64 %748
  %751 = load double, ptr %750, align 8
  %752 = fmul double %749, %751
  %753 = fadd double %747, %752
  store double %753, ptr %727, align 8
  %754 = or disjoint i64 %729, 4
  %gep31.4 = getelementptr double, ptr %invariant.gep30, i64 %754
  %755 = load double, ptr %gep31.4, align 8
  %756 = getelementptr double, ptr %8, i64 %754
  %757 = load double, ptr %756, align 8
  %758 = fmul double %755, %757
  %759 = fadd double %753, %758
  store double %759, ptr %727, align 8
  %760 = or disjoint i64 %729, 5
  %gep31.5 = getelementptr double, ptr %invariant.gep30, i64 %760
  %761 = load double, ptr %gep31.5, align 8
  %762 = getelementptr double, ptr %8, i64 %760
  %763 = load double, ptr %762, align 8
  %764 = fmul double %761, %763
  %765 = fadd double %759, %764
  store double %765, ptr %727, align 8
  %766 = or disjoint i64 %729, 6
  %gep31.6 = getelementptr double, ptr %invariant.gep30, i64 %766
  %767 = load double, ptr %gep31.6, align 8
  %768 = getelementptr double, ptr %8, i64 %766
  %769 = load double, ptr %768, align 8
  %770 = fmul double %767, %769
  %771 = fadd double %765, %770
  store double %771, ptr %727, align 8
  %772 = or disjoint i64 %729, 7
  %gep31.7 = getelementptr double, ptr %invariant.gep30, i64 %772
  %773 = load double, ptr %gep31.7, align 8
  %774 = getelementptr double, ptr %8, i64 %772
  %775 = load double, ptr %774, align 8
  %776 = fmul double %773, %775
  %777 = fadd double %771, %776
  store double %777, ptr %727, align 8
  %778 = add nuw nsw i64 %729, 8
  %exitcond.1.3.not.7 = icmp eq i64 %778, 128
  br i1 %exitcond.1.3.not.7, label %.preheader.2.3, label %728

.preheader.2.3:                                   ; preds = %728
  %779 = getelementptr double, ptr %13, i64 14
  %invariant.gep32 = getelementptr double, ptr %1, i64 1792
  br label %780

780:                                              ; preds = %780, %.preheader.2.3
  %781 = phi i64 [ 0, %.preheader.2.3 ], [ %830, %780 ]
  %782 = phi double [ 0.000000e+00, %.preheader.2.3 ], [ %829, %780 ]
  %gep33 = getelementptr double, ptr %invariant.gep32, i64 %781
  %783 = load double, ptr %gep33, align 8
  %784 = getelementptr double, ptr %8, i64 %781
  %785 = load double, ptr %784, align 8
  %786 = fmul double %783, %785
  %787 = fadd double %782, %786
  store double %787, ptr %779, align 8
  %788 = or disjoint i64 %781, 1
  %gep33.1 = getelementptr double, ptr %invariant.gep32, i64 %788
  %789 = load double, ptr %gep33.1, align 8
  %790 = getelementptr double, ptr %8, i64 %788
  %791 = load double, ptr %790, align 8
  %792 = fmul double %789, %791
  %793 = fadd double %787, %792
  store double %793, ptr %779, align 8
  %794 = or disjoint i64 %781, 2
  %gep33.2 = getelementptr double, ptr %invariant.gep32, i64 %794
  %795 = load double, ptr %gep33.2, align 8
  %796 = getelementptr double, ptr %8, i64 %794
  %797 = load double, ptr %796, align 8
  %798 = fmul double %795, %797
  %799 = fadd double %793, %798
  store double %799, ptr %779, align 8
  %800 = or disjoint i64 %781, 3
  %gep33.3 = getelementptr double, ptr %invariant.gep32, i64 %800
  %801 = load double, ptr %gep33.3, align 8
  %802 = getelementptr double, ptr %8, i64 %800
  %803 = load double, ptr %802, align 8
  %804 = fmul double %801, %803
  %805 = fadd double %799, %804
  store double %805, ptr %779, align 8
  %806 = or disjoint i64 %781, 4
  %gep33.4 = getelementptr double, ptr %invariant.gep32, i64 %806
  %807 = load double, ptr %gep33.4, align 8
  %808 = getelementptr double, ptr %8, i64 %806
  %809 = load double, ptr %808, align 8
  %810 = fmul double %807, %809
  %811 = fadd double %805, %810
  store double %811, ptr %779, align 8
  %812 = or disjoint i64 %781, 5
  %gep33.5 = getelementptr double, ptr %invariant.gep32, i64 %812
  %813 = load double, ptr %gep33.5, align 8
  %814 = getelementptr double, ptr %8, i64 %812
  %815 = load double, ptr %814, align 8
  %816 = fmul double %813, %815
  %817 = fadd double %811, %816
  store double %817, ptr %779, align 8
  %818 = or disjoint i64 %781, 6
  %gep33.6 = getelementptr double, ptr %invariant.gep32, i64 %818
  %819 = load double, ptr %gep33.6, align 8
  %820 = getelementptr double, ptr %8, i64 %818
  %821 = load double, ptr %820, align 8
  %822 = fmul double %819, %821
  %823 = fadd double %817, %822
  store double %823, ptr %779, align 8
  %824 = or disjoint i64 %781, 7
  %gep33.7 = getelementptr double, ptr %invariant.gep32, i64 %824
  %825 = load double, ptr %gep33.7, align 8
  %826 = getelementptr double, ptr %8, i64 %824
  %827 = load double, ptr %826, align 8
  %828 = fmul double %825, %827
  %829 = fadd double %823, %828
  store double %829, ptr %779, align 8
  %830 = add nuw nsw i64 %781, 8
  %exitcond.2.3.not.7 = icmp eq i64 %830, 128
  br i1 %exitcond.2.3.not.7, label %.preheader.3.3, label %780

.preheader.3.3:                                   ; preds = %780
  %831 = getelementptr double, ptr %13, i64 15
  %invariant.gep34 = getelementptr double, ptr %1, i64 1920
  br label %832

832:                                              ; preds = %832, %.preheader.3.3
  %833 = phi i64 [ 0, %.preheader.3.3 ], [ %882, %832 ]
  %834 = phi double [ 0.000000e+00, %.preheader.3.3 ], [ %881, %832 ]
  %gep35 = getelementptr double, ptr %invariant.gep34, i64 %833
  %835 = load double, ptr %gep35, align 8
  %836 = getelementptr double, ptr %8, i64 %833
  %837 = load double, ptr %836, align 8
  %838 = fmul double %835, %837
  %839 = fadd double %834, %838
  store double %839, ptr %831, align 8
  %840 = or disjoint i64 %833, 1
  %gep35.1 = getelementptr double, ptr %invariant.gep34, i64 %840
  %841 = load double, ptr %gep35.1, align 8
  %842 = getelementptr double, ptr %8, i64 %840
  %843 = load double, ptr %842, align 8
  %844 = fmul double %841, %843
  %845 = fadd double %839, %844
  store double %845, ptr %831, align 8
  %846 = or disjoint i64 %833, 2
  %gep35.2 = getelementptr double, ptr %invariant.gep34, i64 %846
  %847 = load double, ptr %gep35.2, align 8
  %848 = getelementptr double, ptr %8, i64 %846
  %849 = load double, ptr %848, align 8
  %850 = fmul double %847, %849
  %851 = fadd double %845, %850
  store double %851, ptr %831, align 8
  %852 = or disjoint i64 %833, 3
  %gep35.3 = getelementptr double, ptr %invariant.gep34, i64 %852
  %853 = load double, ptr %gep35.3, align 8
  %854 = getelementptr double, ptr %8, i64 %852
  %855 = load double, ptr %854, align 8
  %856 = fmul double %853, %855
  %857 = fadd double %851, %856
  store double %857, ptr %831, align 8
  %858 = or disjoint i64 %833, 4
  %gep35.4 = getelementptr double, ptr %invariant.gep34, i64 %858
  %859 = load double, ptr %gep35.4, align 8
  %860 = getelementptr double, ptr %8, i64 %858
  %861 = load double, ptr %860, align 8
  %862 = fmul double %859, %861
  %863 = fadd double %857, %862
  store double %863, ptr %831, align 8
  %864 = or disjoint i64 %833, 5
  %gep35.5 = getelementptr double, ptr %invariant.gep34, i64 %864
  %865 = load double, ptr %gep35.5, align 8
  %866 = getelementptr double, ptr %8, i64 %864
  %867 = load double, ptr %866, align 8
  %868 = fmul double %865, %867
  %869 = fadd double %863, %868
  store double %869, ptr %831, align 8
  %870 = or disjoint i64 %833, 6
  %gep35.6 = getelementptr double, ptr %invariant.gep34, i64 %870
  %871 = load double, ptr %gep35.6, align 8
  %872 = getelementptr double, ptr %8, i64 %870
  %873 = load double, ptr %872, align 8
  %874 = fmul double %871, %873
  %875 = fadd double %869, %874
  store double %875, ptr %831, align 8
  %876 = or disjoint i64 %833, 7
  %gep35.7 = getelementptr double, ptr %invariant.gep34, i64 %876
  %877 = load double, ptr %gep35.7, align 8
  %878 = getelementptr double, ptr %8, i64 %876
  %879 = load double, ptr %878, align 8
  %880 = fmul double %877, %879
  %881 = fadd double %875, %880
  store double %881, ptr %831, align 8
  %882 = add nuw nsw i64 %833, 8
  %exitcond.3.3.not.7 = icmp eq i64 %882, 128
  br i1 %exitcond.3.3.not.7, label %883, label %832

883:                                              ; preds = %832
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
