; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %13, i8 0, i64 2048, i1 false)
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %832
  %17 = phi i64 [ %833, %832 ], [ 0, %.preheader3.preheader ]
  %18 = shl nuw nsw i64 %17, 8
  %19 = getelementptr double, ptr %1, i64 %18
  %20 = getelementptr double, ptr %13, i64 %17
  %.promoted = load double, ptr %20, align 8
  br label %21

21:                                               ; preds = %21, %.preheader3
  %22 = phi i64 [ 0, %.preheader3 ], [ %51, %21 ]
  %23 = phi double [ %.promoted, %.preheader3 ], [ %50, %21 ]
  %24 = getelementptr double, ptr %19, i64 %22
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %8, i64 %22
  %27 = load double, ptr %26, align 8
  %28 = fmul double %25, %27
  %29 = fadd double %23, %28
  store double %29, ptr %20, align 8
  %30 = or disjoint i64 %22, 1
  %31 = getelementptr double, ptr %19, i64 %30
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %8, i64 %30
  %34 = load double, ptr %33, align 8
  %35 = fmul double %32, %34
  %36 = fadd double %29, %35
  store double %36, ptr %20, align 8
  %37 = or disjoint i64 %22, 2
  %38 = getelementptr double, ptr %19, i64 %37
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %8, i64 %37
  %41 = load double, ptr %40, align 8
  %42 = fmul double %39, %41
  %43 = fadd double %36, %42
  store double %43, ptr %20, align 8
  %44 = or disjoint i64 %22, 3
  %45 = getelementptr double, ptr %19, i64 %44
  %46 = load double, ptr %45, align 8
  %47 = getelementptr double, ptr %8, i64 %44
  %48 = load double, ptr %47, align 8
  %49 = fmul double %46, %48
  %50 = fadd double %43, %49
  store double %50, ptr %20, align 8
  %51 = add nuw nsw i64 %22, 4
  %exitcond.not.3 = icmp eq i64 %51, 256
  br i1 %exitcond.not.3, label %.preheader.1, label %21

.preheader.1:                                     ; preds = %21
  %52 = getelementptr double, ptr %20, i64 1
  %.promoted.1 = load double, ptr %52, align 8
  %invariant.gep31 = getelementptr double, ptr %19, i64 256
  br label %53

53:                                               ; preds = %53, %.preheader.1
  %54 = phi i64 [ 0, %.preheader.1 ], [ %103, %53 ]
  %55 = phi double [ %.promoted.1, %.preheader.1 ], [ %102, %53 ]
  %gep32 = getelementptr double, ptr %invariant.gep31, i64 %54
  %56 = load double, ptr %gep32, align 8
  %57 = getelementptr double, ptr %8, i64 %54
  %58 = load double, ptr %57, align 8
  %59 = fmul double %56, %58
  %60 = fadd double %55, %59
  store double %60, ptr %52, align 8
  %61 = or disjoint i64 %54, 1
  %gep32.1 = getelementptr double, ptr %invariant.gep31, i64 %61
  %62 = load double, ptr %gep32.1, align 8
  %63 = getelementptr double, ptr %8, i64 %61
  %64 = load double, ptr %63, align 8
  %65 = fmul double %62, %64
  %66 = fadd double %60, %65
  store double %66, ptr %52, align 8
  %67 = or disjoint i64 %54, 2
  %gep32.2 = getelementptr double, ptr %invariant.gep31, i64 %67
  %68 = load double, ptr %gep32.2, align 8
  %69 = getelementptr double, ptr %8, i64 %67
  %70 = load double, ptr %69, align 8
  %71 = fmul double %68, %70
  %72 = fadd double %66, %71
  store double %72, ptr %52, align 8
  %73 = or disjoint i64 %54, 3
  %gep32.3 = getelementptr double, ptr %invariant.gep31, i64 %73
  %74 = load double, ptr %gep32.3, align 8
  %75 = getelementptr double, ptr %8, i64 %73
  %76 = load double, ptr %75, align 8
  %77 = fmul double %74, %76
  %78 = fadd double %72, %77
  store double %78, ptr %52, align 8
  %79 = or disjoint i64 %54, 4
  %gep32.4 = getelementptr double, ptr %invariant.gep31, i64 %79
  %80 = load double, ptr %gep32.4, align 8
  %81 = getelementptr double, ptr %8, i64 %79
  %82 = load double, ptr %81, align 8
  %83 = fmul double %80, %82
  %84 = fadd double %78, %83
  store double %84, ptr %52, align 8
  %85 = or disjoint i64 %54, 5
  %gep32.5 = getelementptr double, ptr %invariant.gep31, i64 %85
  %86 = load double, ptr %gep32.5, align 8
  %87 = getelementptr double, ptr %8, i64 %85
  %88 = load double, ptr %87, align 8
  %89 = fmul double %86, %88
  %90 = fadd double %84, %89
  store double %90, ptr %52, align 8
  %91 = or disjoint i64 %54, 6
  %gep32.6 = getelementptr double, ptr %invariant.gep31, i64 %91
  %92 = load double, ptr %gep32.6, align 8
  %93 = getelementptr double, ptr %8, i64 %91
  %94 = load double, ptr %93, align 8
  %95 = fmul double %92, %94
  %96 = fadd double %90, %95
  store double %96, ptr %52, align 8
  %97 = or disjoint i64 %54, 7
  %gep32.7 = getelementptr double, ptr %invariant.gep31, i64 %97
  %98 = load double, ptr %gep32.7, align 8
  %99 = getelementptr double, ptr %8, i64 %97
  %100 = load double, ptr %99, align 8
  %101 = fmul double %98, %100
  %102 = fadd double %96, %101
  store double %102, ptr %52, align 8
  %103 = add nuw nsw i64 %54, 8
  %exitcond.1.not.7 = icmp eq i64 %103, 256
  br i1 %exitcond.1.not.7, label %.preheader.2, label %53

.preheader.2:                                     ; preds = %53
  %104 = getelementptr double, ptr %20, i64 2
  %.promoted.2 = load double, ptr %104, align 8
  %invariant.gep29 = getelementptr double, ptr %19, i64 512
  br label %105

105:                                              ; preds = %105, %.preheader.2
  %106 = phi i64 [ 0, %.preheader.2 ], [ %155, %105 ]
  %107 = phi double [ %.promoted.2, %.preheader.2 ], [ %154, %105 ]
  %gep30 = getelementptr double, ptr %invariant.gep29, i64 %106
  %108 = load double, ptr %gep30, align 8
  %109 = getelementptr double, ptr %8, i64 %106
  %110 = load double, ptr %109, align 8
  %111 = fmul double %108, %110
  %112 = fadd double %107, %111
  store double %112, ptr %104, align 8
  %113 = or disjoint i64 %106, 1
  %gep30.1 = getelementptr double, ptr %invariant.gep29, i64 %113
  %114 = load double, ptr %gep30.1, align 8
  %115 = getelementptr double, ptr %8, i64 %113
  %116 = load double, ptr %115, align 8
  %117 = fmul double %114, %116
  %118 = fadd double %112, %117
  store double %118, ptr %104, align 8
  %119 = or disjoint i64 %106, 2
  %gep30.2 = getelementptr double, ptr %invariant.gep29, i64 %119
  %120 = load double, ptr %gep30.2, align 8
  %121 = getelementptr double, ptr %8, i64 %119
  %122 = load double, ptr %121, align 8
  %123 = fmul double %120, %122
  %124 = fadd double %118, %123
  store double %124, ptr %104, align 8
  %125 = or disjoint i64 %106, 3
  %gep30.3 = getelementptr double, ptr %invariant.gep29, i64 %125
  %126 = load double, ptr %gep30.3, align 8
  %127 = getelementptr double, ptr %8, i64 %125
  %128 = load double, ptr %127, align 8
  %129 = fmul double %126, %128
  %130 = fadd double %124, %129
  store double %130, ptr %104, align 8
  %131 = or disjoint i64 %106, 4
  %gep30.4 = getelementptr double, ptr %invariant.gep29, i64 %131
  %132 = load double, ptr %gep30.4, align 8
  %133 = getelementptr double, ptr %8, i64 %131
  %134 = load double, ptr %133, align 8
  %135 = fmul double %132, %134
  %136 = fadd double %130, %135
  store double %136, ptr %104, align 8
  %137 = or disjoint i64 %106, 5
  %gep30.5 = getelementptr double, ptr %invariant.gep29, i64 %137
  %138 = load double, ptr %gep30.5, align 8
  %139 = getelementptr double, ptr %8, i64 %137
  %140 = load double, ptr %139, align 8
  %141 = fmul double %138, %140
  %142 = fadd double %136, %141
  store double %142, ptr %104, align 8
  %143 = or disjoint i64 %106, 6
  %gep30.6 = getelementptr double, ptr %invariant.gep29, i64 %143
  %144 = load double, ptr %gep30.6, align 8
  %145 = getelementptr double, ptr %8, i64 %143
  %146 = load double, ptr %145, align 8
  %147 = fmul double %144, %146
  %148 = fadd double %142, %147
  store double %148, ptr %104, align 8
  %149 = or disjoint i64 %106, 7
  %gep30.7 = getelementptr double, ptr %invariant.gep29, i64 %149
  %150 = load double, ptr %gep30.7, align 8
  %151 = getelementptr double, ptr %8, i64 %149
  %152 = load double, ptr %151, align 8
  %153 = fmul double %150, %152
  %154 = fadd double %148, %153
  store double %154, ptr %104, align 8
  %155 = add nuw nsw i64 %106, 8
  %exitcond.2.not.7 = icmp eq i64 %155, 256
  br i1 %exitcond.2.not.7, label %.preheader.3, label %105

.preheader.3:                                     ; preds = %105
  %156 = getelementptr double, ptr %20, i64 3
  %.promoted.3 = load double, ptr %156, align 8
  %invariant.gep27 = getelementptr double, ptr %19, i64 768
  br label %157

157:                                              ; preds = %157, %.preheader.3
  %158 = phi i64 [ 0, %.preheader.3 ], [ %207, %157 ]
  %159 = phi double [ %.promoted.3, %.preheader.3 ], [ %206, %157 ]
  %gep28 = getelementptr double, ptr %invariant.gep27, i64 %158
  %160 = load double, ptr %gep28, align 8
  %161 = getelementptr double, ptr %8, i64 %158
  %162 = load double, ptr %161, align 8
  %163 = fmul double %160, %162
  %164 = fadd double %159, %163
  store double %164, ptr %156, align 8
  %165 = or disjoint i64 %158, 1
  %gep28.1 = getelementptr double, ptr %invariant.gep27, i64 %165
  %166 = load double, ptr %gep28.1, align 8
  %167 = getelementptr double, ptr %8, i64 %165
  %168 = load double, ptr %167, align 8
  %169 = fmul double %166, %168
  %170 = fadd double %164, %169
  store double %170, ptr %156, align 8
  %171 = or disjoint i64 %158, 2
  %gep28.2 = getelementptr double, ptr %invariant.gep27, i64 %171
  %172 = load double, ptr %gep28.2, align 8
  %173 = getelementptr double, ptr %8, i64 %171
  %174 = load double, ptr %173, align 8
  %175 = fmul double %172, %174
  %176 = fadd double %170, %175
  store double %176, ptr %156, align 8
  %177 = or disjoint i64 %158, 3
  %gep28.3 = getelementptr double, ptr %invariant.gep27, i64 %177
  %178 = load double, ptr %gep28.3, align 8
  %179 = getelementptr double, ptr %8, i64 %177
  %180 = load double, ptr %179, align 8
  %181 = fmul double %178, %180
  %182 = fadd double %176, %181
  store double %182, ptr %156, align 8
  %183 = or disjoint i64 %158, 4
  %gep28.4 = getelementptr double, ptr %invariant.gep27, i64 %183
  %184 = load double, ptr %gep28.4, align 8
  %185 = getelementptr double, ptr %8, i64 %183
  %186 = load double, ptr %185, align 8
  %187 = fmul double %184, %186
  %188 = fadd double %182, %187
  store double %188, ptr %156, align 8
  %189 = or disjoint i64 %158, 5
  %gep28.5 = getelementptr double, ptr %invariant.gep27, i64 %189
  %190 = load double, ptr %gep28.5, align 8
  %191 = getelementptr double, ptr %8, i64 %189
  %192 = load double, ptr %191, align 8
  %193 = fmul double %190, %192
  %194 = fadd double %188, %193
  store double %194, ptr %156, align 8
  %195 = or disjoint i64 %158, 6
  %gep28.6 = getelementptr double, ptr %invariant.gep27, i64 %195
  %196 = load double, ptr %gep28.6, align 8
  %197 = getelementptr double, ptr %8, i64 %195
  %198 = load double, ptr %197, align 8
  %199 = fmul double %196, %198
  %200 = fadd double %194, %199
  store double %200, ptr %156, align 8
  %201 = or disjoint i64 %158, 7
  %gep28.7 = getelementptr double, ptr %invariant.gep27, i64 %201
  %202 = load double, ptr %gep28.7, align 8
  %203 = getelementptr double, ptr %8, i64 %201
  %204 = load double, ptr %203, align 8
  %205 = fmul double %202, %204
  %206 = fadd double %200, %205
  store double %206, ptr %156, align 8
  %207 = add nuw nsw i64 %158, 8
  %exitcond.3.not.7 = icmp eq i64 %207, 256
  br i1 %exitcond.3.not.7, label %.preheader.4, label %157

.preheader.4:                                     ; preds = %157
  %208 = getelementptr double, ptr %20, i64 4
  %.promoted.4 = load double, ptr %208, align 8
  %invariant.gep25 = getelementptr double, ptr %19, i64 1024
  br label %209

209:                                              ; preds = %209, %.preheader.4
  %210 = phi i64 [ 0, %.preheader.4 ], [ %259, %209 ]
  %211 = phi double [ %.promoted.4, %.preheader.4 ], [ %258, %209 ]
  %gep26 = getelementptr double, ptr %invariant.gep25, i64 %210
  %212 = load double, ptr %gep26, align 8
  %213 = getelementptr double, ptr %8, i64 %210
  %214 = load double, ptr %213, align 8
  %215 = fmul double %212, %214
  %216 = fadd double %211, %215
  store double %216, ptr %208, align 8
  %217 = or disjoint i64 %210, 1
  %gep26.1 = getelementptr double, ptr %invariant.gep25, i64 %217
  %218 = load double, ptr %gep26.1, align 8
  %219 = getelementptr double, ptr %8, i64 %217
  %220 = load double, ptr %219, align 8
  %221 = fmul double %218, %220
  %222 = fadd double %216, %221
  store double %222, ptr %208, align 8
  %223 = or disjoint i64 %210, 2
  %gep26.2 = getelementptr double, ptr %invariant.gep25, i64 %223
  %224 = load double, ptr %gep26.2, align 8
  %225 = getelementptr double, ptr %8, i64 %223
  %226 = load double, ptr %225, align 8
  %227 = fmul double %224, %226
  %228 = fadd double %222, %227
  store double %228, ptr %208, align 8
  %229 = or disjoint i64 %210, 3
  %gep26.3 = getelementptr double, ptr %invariant.gep25, i64 %229
  %230 = load double, ptr %gep26.3, align 8
  %231 = getelementptr double, ptr %8, i64 %229
  %232 = load double, ptr %231, align 8
  %233 = fmul double %230, %232
  %234 = fadd double %228, %233
  store double %234, ptr %208, align 8
  %235 = or disjoint i64 %210, 4
  %gep26.4 = getelementptr double, ptr %invariant.gep25, i64 %235
  %236 = load double, ptr %gep26.4, align 8
  %237 = getelementptr double, ptr %8, i64 %235
  %238 = load double, ptr %237, align 8
  %239 = fmul double %236, %238
  %240 = fadd double %234, %239
  store double %240, ptr %208, align 8
  %241 = or disjoint i64 %210, 5
  %gep26.5 = getelementptr double, ptr %invariant.gep25, i64 %241
  %242 = load double, ptr %gep26.5, align 8
  %243 = getelementptr double, ptr %8, i64 %241
  %244 = load double, ptr %243, align 8
  %245 = fmul double %242, %244
  %246 = fadd double %240, %245
  store double %246, ptr %208, align 8
  %247 = or disjoint i64 %210, 6
  %gep26.6 = getelementptr double, ptr %invariant.gep25, i64 %247
  %248 = load double, ptr %gep26.6, align 8
  %249 = getelementptr double, ptr %8, i64 %247
  %250 = load double, ptr %249, align 8
  %251 = fmul double %248, %250
  %252 = fadd double %246, %251
  store double %252, ptr %208, align 8
  %253 = or disjoint i64 %210, 7
  %gep26.7 = getelementptr double, ptr %invariant.gep25, i64 %253
  %254 = load double, ptr %gep26.7, align 8
  %255 = getelementptr double, ptr %8, i64 %253
  %256 = load double, ptr %255, align 8
  %257 = fmul double %254, %256
  %258 = fadd double %252, %257
  store double %258, ptr %208, align 8
  %259 = add nuw nsw i64 %210, 8
  %exitcond.4.not.7 = icmp eq i64 %259, 256
  br i1 %exitcond.4.not.7, label %.preheader.5, label %209

.preheader.5:                                     ; preds = %209
  %260 = getelementptr double, ptr %20, i64 5
  %.promoted.5 = load double, ptr %260, align 8
  %invariant.gep23 = getelementptr double, ptr %19, i64 1280
  br label %261

261:                                              ; preds = %261, %.preheader.5
  %262 = phi i64 [ 0, %.preheader.5 ], [ %311, %261 ]
  %263 = phi double [ %.promoted.5, %.preheader.5 ], [ %310, %261 ]
  %gep24 = getelementptr double, ptr %invariant.gep23, i64 %262
  %264 = load double, ptr %gep24, align 8
  %265 = getelementptr double, ptr %8, i64 %262
  %266 = load double, ptr %265, align 8
  %267 = fmul double %264, %266
  %268 = fadd double %263, %267
  store double %268, ptr %260, align 8
  %269 = or disjoint i64 %262, 1
  %gep24.1 = getelementptr double, ptr %invariant.gep23, i64 %269
  %270 = load double, ptr %gep24.1, align 8
  %271 = getelementptr double, ptr %8, i64 %269
  %272 = load double, ptr %271, align 8
  %273 = fmul double %270, %272
  %274 = fadd double %268, %273
  store double %274, ptr %260, align 8
  %275 = or disjoint i64 %262, 2
  %gep24.2 = getelementptr double, ptr %invariant.gep23, i64 %275
  %276 = load double, ptr %gep24.2, align 8
  %277 = getelementptr double, ptr %8, i64 %275
  %278 = load double, ptr %277, align 8
  %279 = fmul double %276, %278
  %280 = fadd double %274, %279
  store double %280, ptr %260, align 8
  %281 = or disjoint i64 %262, 3
  %gep24.3 = getelementptr double, ptr %invariant.gep23, i64 %281
  %282 = load double, ptr %gep24.3, align 8
  %283 = getelementptr double, ptr %8, i64 %281
  %284 = load double, ptr %283, align 8
  %285 = fmul double %282, %284
  %286 = fadd double %280, %285
  store double %286, ptr %260, align 8
  %287 = or disjoint i64 %262, 4
  %gep24.4 = getelementptr double, ptr %invariant.gep23, i64 %287
  %288 = load double, ptr %gep24.4, align 8
  %289 = getelementptr double, ptr %8, i64 %287
  %290 = load double, ptr %289, align 8
  %291 = fmul double %288, %290
  %292 = fadd double %286, %291
  store double %292, ptr %260, align 8
  %293 = or disjoint i64 %262, 5
  %gep24.5 = getelementptr double, ptr %invariant.gep23, i64 %293
  %294 = load double, ptr %gep24.5, align 8
  %295 = getelementptr double, ptr %8, i64 %293
  %296 = load double, ptr %295, align 8
  %297 = fmul double %294, %296
  %298 = fadd double %292, %297
  store double %298, ptr %260, align 8
  %299 = or disjoint i64 %262, 6
  %gep24.6 = getelementptr double, ptr %invariant.gep23, i64 %299
  %300 = load double, ptr %gep24.6, align 8
  %301 = getelementptr double, ptr %8, i64 %299
  %302 = load double, ptr %301, align 8
  %303 = fmul double %300, %302
  %304 = fadd double %298, %303
  store double %304, ptr %260, align 8
  %305 = or disjoint i64 %262, 7
  %gep24.7 = getelementptr double, ptr %invariant.gep23, i64 %305
  %306 = load double, ptr %gep24.7, align 8
  %307 = getelementptr double, ptr %8, i64 %305
  %308 = load double, ptr %307, align 8
  %309 = fmul double %306, %308
  %310 = fadd double %304, %309
  store double %310, ptr %260, align 8
  %311 = add nuw nsw i64 %262, 8
  %exitcond.5.not.7 = icmp eq i64 %311, 256
  br i1 %exitcond.5.not.7, label %.preheader.6, label %261

.preheader.6:                                     ; preds = %261
  %312 = getelementptr double, ptr %20, i64 6
  %.promoted.6 = load double, ptr %312, align 8
  %invariant.gep21 = getelementptr double, ptr %19, i64 1536
  br label %313

313:                                              ; preds = %313, %.preheader.6
  %314 = phi i64 [ 0, %.preheader.6 ], [ %363, %313 ]
  %315 = phi double [ %.promoted.6, %.preheader.6 ], [ %362, %313 ]
  %gep22 = getelementptr double, ptr %invariant.gep21, i64 %314
  %316 = load double, ptr %gep22, align 8
  %317 = getelementptr double, ptr %8, i64 %314
  %318 = load double, ptr %317, align 8
  %319 = fmul double %316, %318
  %320 = fadd double %315, %319
  store double %320, ptr %312, align 8
  %321 = or disjoint i64 %314, 1
  %gep22.1 = getelementptr double, ptr %invariant.gep21, i64 %321
  %322 = load double, ptr %gep22.1, align 8
  %323 = getelementptr double, ptr %8, i64 %321
  %324 = load double, ptr %323, align 8
  %325 = fmul double %322, %324
  %326 = fadd double %320, %325
  store double %326, ptr %312, align 8
  %327 = or disjoint i64 %314, 2
  %gep22.2 = getelementptr double, ptr %invariant.gep21, i64 %327
  %328 = load double, ptr %gep22.2, align 8
  %329 = getelementptr double, ptr %8, i64 %327
  %330 = load double, ptr %329, align 8
  %331 = fmul double %328, %330
  %332 = fadd double %326, %331
  store double %332, ptr %312, align 8
  %333 = or disjoint i64 %314, 3
  %gep22.3 = getelementptr double, ptr %invariant.gep21, i64 %333
  %334 = load double, ptr %gep22.3, align 8
  %335 = getelementptr double, ptr %8, i64 %333
  %336 = load double, ptr %335, align 8
  %337 = fmul double %334, %336
  %338 = fadd double %332, %337
  store double %338, ptr %312, align 8
  %339 = or disjoint i64 %314, 4
  %gep22.4 = getelementptr double, ptr %invariant.gep21, i64 %339
  %340 = load double, ptr %gep22.4, align 8
  %341 = getelementptr double, ptr %8, i64 %339
  %342 = load double, ptr %341, align 8
  %343 = fmul double %340, %342
  %344 = fadd double %338, %343
  store double %344, ptr %312, align 8
  %345 = or disjoint i64 %314, 5
  %gep22.5 = getelementptr double, ptr %invariant.gep21, i64 %345
  %346 = load double, ptr %gep22.5, align 8
  %347 = getelementptr double, ptr %8, i64 %345
  %348 = load double, ptr %347, align 8
  %349 = fmul double %346, %348
  %350 = fadd double %344, %349
  store double %350, ptr %312, align 8
  %351 = or disjoint i64 %314, 6
  %gep22.6 = getelementptr double, ptr %invariant.gep21, i64 %351
  %352 = load double, ptr %gep22.6, align 8
  %353 = getelementptr double, ptr %8, i64 %351
  %354 = load double, ptr %353, align 8
  %355 = fmul double %352, %354
  %356 = fadd double %350, %355
  store double %356, ptr %312, align 8
  %357 = or disjoint i64 %314, 7
  %gep22.7 = getelementptr double, ptr %invariant.gep21, i64 %357
  %358 = load double, ptr %gep22.7, align 8
  %359 = getelementptr double, ptr %8, i64 %357
  %360 = load double, ptr %359, align 8
  %361 = fmul double %358, %360
  %362 = fadd double %356, %361
  store double %362, ptr %312, align 8
  %363 = add nuw nsw i64 %314, 8
  %exitcond.6.not.7 = icmp eq i64 %363, 256
  br i1 %exitcond.6.not.7, label %.preheader.7, label %313

.preheader.7:                                     ; preds = %313
  %364 = getelementptr double, ptr %20, i64 7
  %.promoted.7 = load double, ptr %364, align 8
  %invariant.gep19 = getelementptr double, ptr %19, i64 1792
  br label %365

365:                                              ; preds = %365, %.preheader.7
  %366 = phi i64 [ 0, %.preheader.7 ], [ %415, %365 ]
  %367 = phi double [ %.promoted.7, %.preheader.7 ], [ %414, %365 ]
  %gep20 = getelementptr double, ptr %invariant.gep19, i64 %366
  %368 = load double, ptr %gep20, align 8
  %369 = getelementptr double, ptr %8, i64 %366
  %370 = load double, ptr %369, align 8
  %371 = fmul double %368, %370
  %372 = fadd double %367, %371
  store double %372, ptr %364, align 8
  %373 = or disjoint i64 %366, 1
  %gep20.1 = getelementptr double, ptr %invariant.gep19, i64 %373
  %374 = load double, ptr %gep20.1, align 8
  %375 = getelementptr double, ptr %8, i64 %373
  %376 = load double, ptr %375, align 8
  %377 = fmul double %374, %376
  %378 = fadd double %372, %377
  store double %378, ptr %364, align 8
  %379 = or disjoint i64 %366, 2
  %gep20.2 = getelementptr double, ptr %invariant.gep19, i64 %379
  %380 = load double, ptr %gep20.2, align 8
  %381 = getelementptr double, ptr %8, i64 %379
  %382 = load double, ptr %381, align 8
  %383 = fmul double %380, %382
  %384 = fadd double %378, %383
  store double %384, ptr %364, align 8
  %385 = or disjoint i64 %366, 3
  %gep20.3 = getelementptr double, ptr %invariant.gep19, i64 %385
  %386 = load double, ptr %gep20.3, align 8
  %387 = getelementptr double, ptr %8, i64 %385
  %388 = load double, ptr %387, align 8
  %389 = fmul double %386, %388
  %390 = fadd double %384, %389
  store double %390, ptr %364, align 8
  %391 = or disjoint i64 %366, 4
  %gep20.4 = getelementptr double, ptr %invariant.gep19, i64 %391
  %392 = load double, ptr %gep20.4, align 8
  %393 = getelementptr double, ptr %8, i64 %391
  %394 = load double, ptr %393, align 8
  %395 = fmul double %392, %394
  %396 = fadd double %390, %395
  store double %396, ptr %364, align 8
  %397 = or disjoint i64 %366, 5
  %gep20.5 = getelementptr double, ptr %invariant.gep19, i64 %397
  %398 = load double, ptr %gep20.5, align 8
  %399 = getelementptr double, ptr %8, i64 %397
  %400 = load double, ptr %399, align 8
  %401 = fmul double %398, %400
  %402 = fadd double %396, %401
  store double %402, ptr %364, align 8
  %403 = or disjoint i64 %366, 6
  %gep20.6 = getelementptr double, ptr %invariant.gep19, i64 %403
  %404 = load double, ptr %gep20.6, align 8
  %405 = getelementptr double, ptr %8, i64 %403
  %406 = load double, ptr %405, align 8
  %407 = fmul double %404, %406
  %408 = fadd double %402, %407
  store double %408, ptr %364, align 8
  %409 = or disjoint i64 %366, 7
  %gep20.7 = getelementptr double, ptr %invariant.gep19, i64 %409
  %410 = load double, ptr %gep20.7, align 8
  %411 = getelementptr double, ptr %8, i64 %409
  %412 = load double, ptr %411, align 8
  %413 = fmul double %410, %412
  %414 = fadd double %408, %413
  store double %414, ptr %364, align 8
  %415 = add nuw nsw i64 %366, 8
  %exitcond.7.not.7 = icmp eq i64 %415, 256
  br i1 %exitcond.7.not.7, label %.preheader.8, label %365

.preheader.8:                                     ; preds = %365
  %416 = getelementptr double, ptr %20, i64 8
  %.promoted.8 = load double, ptr %416, align 8
  %invariant.gep17 = getelementptr double, ptr %19, i64 2048
  br label %417

417:                                              ; preds = %417, %.preheader.8
  %418 = phi i64 [ 0, %.preheader.8 ], [ %467, %417 ]
  %419 = phi double [ %.promoted.8, %.preheader.8 ], [ %466, %417 ]
  %gep18 = getelementptr double, ptr %invariant.gep17, i64 %418
  %420 = load double, ptr %gep18, align 8
  %421 = getelementptr double, ptr %8, i64 %418
  %422 = load double, ptr %421, align 8
  %423 = fmul double %420, %422
  %424 = fadd double %419, %423
  store double %424, ptr %416, align 8
  %425 = or disjoint i64 %418, 1
  %gep18.1 = getelementptr double, ptr %invariant.gep17, i64 %425
  %426 = load double, ptr %gep18.1, align 8
  %427 = getelementptr double, ptr %8, i64 %425
  %428 = load double, ptr %427, align 8
  %429 = fmul double %426, %428
  %430 = fadd double %424, %429
  store double %430, ptr %416, align 8
  %431 = or disjoint i64 %418, 2
  %gep18.2 = getelementptr double, ptr %invariant.gep17, i64 %431
  %432 = load double, ptr %gep18.2, align 8
  %433 = getelementptr double, ptr %8, i64 %431
  %434 = load double, ptr %433, align 8
  %435 = fmul double %432, %434
  %436 = fadd double %430, %435
  store double %436, ptr %416, align 8
  %437 = or disjoint i64 %418, 3
  %gep18.3 = getelementptr double, ptr %invariant.gep17, i64 %437
  %438 = load double, ptr %gep18.3, align 8
  %439 = getelementptr double, ptr %8, i64 %437
  %440 = load double, ptr %439, align 8
  %441 = fmul double %438, %440
  %442 = fadd double %436, %441
  store double %442, ptr %416, align 8
  %443 = or disjoint i64 %418, 4
  %gep18.4 = getelementptr double, ptr %invariant.gep17, i64 %443
  %444 = load double, ptr %gep18.4, align 8
  %445 = getelementptr double, ptr %8, i64 %443
  %446 = load double, ptr %445, align 8
  %447 = fmul double %444, %446
  %448 = fadd double %442, %447
  store double %448, ptr %416, align 8
  %449 = or disjoint i64 %418, 5
  %gep18.5 = getelementptr double, ptr %invariant.gep17, i64 %449
  %450 = load double, ptr %gep18.5, align 8
  %451 = getelementptr double, ptr %8, i64 %449
  %452 = load double, ptr %451, align 8
  %453 = fmul double %450, %452
  %454 = fadd double %448, %453
  store double %454, ptr %416, align 8
  %455 = or disjoint i64 %418, 6
  %gep18.6 = getelementptr double, ptr %invariant.gep17, i64 %455
  %456 = load double, ptr %gep18.6, align 8
  %457 = getelementptr double, ptr %8, i64 %455
  %458 = load double, ptr %457, align 8
  %459 = fmul double %456, %458
  %460 = fadd double %454, %459
  store double %460, ptr %416, align 8
  %461 = or disjoint i64 %418, 7
  %gep18.7 = getelementptr double, ptr %invariant.gep17, i64 %461
  %462 = load double, ptr %gep18.7, align 8
  %463 = getelementptr double, ptr %8, i64 %461
  %464 = load double, ptr %463, align 8
  %465 = fmul double %462, %464
  %466 = fadd double %460, %465
  store double %466, ptr %416, align 8
  %467 = add nuw nsw i64 %418, 8
  %exitcond.8.not.7 = icmp eq i64 %467, 256
  br i1 %exitcond.8.not.7, label %.preheader.9, label %417

.preheader.9:                                     ; preds = %417
  %468 = getelementptr double, ptr %20, i64 9
  %.promoted.9 = load double, ptr %468, align 8
  %invariant.gep15 = getelementptr double, ptr %19, i64 2304
  br label %469

469:                                              ; preds = %469, %.preheader.9
  %470 = phi i64 [ 0, %.preheader.9 ], [ %519, %469 ]
  %471 = phi double [ %.promoted.9, %.preheader.9 ], [ %518, %469 ]
  %gep16 = getelementptr double, ptr %invariant.gep15, i64 %470
  %472 = load double, ptr %gep16, align 8
  %473 = getelementptr double, ptr %8, i64 %470
  %474 = load double, ptr %473, align 8
  %475 = fmul double %472, %474
  %476 = fadd double %471, %475
  store double %476, ptr %468, align 8
  %477 = or disjoint i64 %470, 1
  %gep16.1 = getelementptr double, ptr %invariant.gep15, i64 %477
  %478 = load double, ptr %gep16.1, align 8
  %479 = getelementptr double, ptr %8, i64 %477
  %480 = load double, ptr %479, align 8
  %481 = fmul double %478, %480
  %482 = fadd double %476, %481
  store double %482, ptr %468, align 8
  %483 = or disjoint i64 %470, 2
  %gep16.2 = getelementptr double, ptr %invariant.gep15, i64 %483
  %484 = load double, ptr %gep16.2, align 8
  %485 = getelementptr double, ptr %8, i64 %483
  %486 = load double, ptr %485, align 8
  %487 = fmul double %484, %486
  %488 = fadd double %482, %487
  store double %488, ptr %468, align 8
  %489 = or disjoint i64 %470, 3
  %gep16.3 = getelementptr double, ptr %invariant.gep15, i64 %489
  %490 = load double, ptr %gep16.3, align 8
  %491 = getelementptr double, ptr %8, i64 %489
  %492 = load double, ptr %491, align 8
  %493 = fmul double %490, %492
  %494 = fadd double %488, %493
  store double %494, ptr %468, align 8
  %495 = or disjoint i64 %470, 4
  %gep16.4 = getelementptr double, ptr %invariant.gep15, i64 %495
  %496 = load double, ptr %gep16.4, align 8
  %497 = getelementptr double, ptr %8, i64 %495
  %498 = load double, ptr %497, align 8
  %499 = fmul double %496, %498
  %500 = fadd double %494, %499
  store double %500, ptr %468, align 8
  %501 = or disjoint i64 %470, 5
  %gep16.5 = getelementptr double, ptr %invariant.gep15, i64 %501
  %502 = load double, ptr %gep16.5, align 8
  %503 = getelementptr double, ptr %8, i64 %501
  %504 = load double, ptr %503, align 8
  %505 = fmul double %502, %504
  %506 = fadd double %500, %505
  store double %506, ptr %468, align 8
  %507 = or disjoint i64 %470, 6
  %gep16.6 = getelementptr double, ptr %invariant.gep15, i64 %507
  %508 = load double, ptr %gep16.6, align 8
  %509 = getelementptr double, ptr %8, i64 %507
  %510 = load double, ptr %509, align 8
  %511 = fmul double %508, %510
  %512 = fadd double %506, %511
  store double %512, ptr %468, align 8
  %513 = or disjoint i64 %470, 7
  %gep16.7 = getelementptr double, ptr %invariant.gep15, i64 %513
  %514 = load double, ptr %gep16.7, align 8
  %515 = getelementptr double, ptr %8, i64 %513
  %516 = load double, ptr %515, align 8
  %517 = fmul double %514, %516
  %518 = fadd double %512, %517
  store double %518, ptr %468, align 8
  %519 = add nuw nsw i64 %470, 8
  %exitcond.9.not.7 = icmp eq i64 %519, 256
  br i1 %exitcond.9.not.7, label %.preheader.10, label %469

.preheader.10:                                    ; preds = %469
  %520 = getelementptr double, ptr %20, i64 10
  %.promoted.10 = load double, ptr %520, align 8
  %invariant.gep13 = getelementptr double, ptr %19, i64 2560
  br label %521

521:                                              ; preds = %521, %.preheader.10
  %522 = phi i64 [ 0, %.preheader.10 ], [ %571, %521 ]
  %523 = phi double [ %.promoted.10, %.preheader.10 ], [ %570, %521 ]
  %gep14 = getelementptr double, ptr %invariant.gep13, i64 %522
  %524 = load double, ptr %gep14, align 8
  %525 = getelementptr double, ptr %8, i64 %522
  %526 = load double, ptr %525, align 8
  %527 = fmul double %524, %526
  %528 = fadd double %523, %527
  store double %528, ptr %520, align 8
  %529 = or disjoint i64 %522, 1
  %gep14.1 = getelementptr double, ptr %invariant.gep13, i64 %529
  %530 = load double, ptr %gep14.1, align 8
  %531 = getelementptr double, ptr %8, i64 %529
  %532 = load double, ptr %531, align 8
  %533 = fmul double %530, %532
  %534 = fadd double %528, %533
  store double %534, ptr %520, align 8
  %535 = or disjoint i64 %522, 2
  %gep14.2 = getelementptr double, ptr %invariant.gep13, i64 %535
  %536 = load double, ptr %gep14.2, align 8
  %537 = getelementptr double, ptr %8, i64 %535
  %538 = load double, ptr %537, align 8
  %539 = fmul double %536, %538
  %540 = fadd double %534, %539
  store double %540, ptr %520, align 8
  %541 = or disjoint i64 %522, 3
  %gep14.3 = getelementptr double, ptr %invariant.gep13, i64 %541
  %542 = load double, ptr %gep14.3, align 8
  %543 = getelementptr double, ptr %8, i64 %541
  %544 = load double, ptr %543, align 8
  %545 = fmul double %542, %544
  %546 = fadd double %540, %545
  store double %546, ptr %520, align 8
  %547 = or disjoint i64 %522, 4
  %gep14.4 = getelementptr double, ptr %invariant.gep13, i64 %547
  %548 = load double, ptr %gep14.4, align 8
  %549 = getelementptr double, ptr %8, i64 %547
  %550 = load double, ptr %549, align 8
  %551 = fmul double %548, %550
  %552 = fadd double %546, %551
  store double %552, ptr %520, align 8
  %553 = or disjoint i64 %522, 5
  %gep14.5 = getelementptr double, ptr %invariant.gep13, i64 %553
  %554 = load double, ptr %gep14.5, align 8
  %555 = getelementptr double, ptr %8, i64 %553
  %556 = load double, ptr %555, align 8
  %557 = fmul double %554, %556
  %558 = fadd double %552, %557
  store double %558, ptr %520, align 8
  %559 = or disjoint i64 %522, 6
  %gep14.6 = getelementptr double, ptr %invariant.gep13, i64 %559
  %560 = load double, ptr %gep14.6, align 8
  %561 = getelementptr double, ptr %8, i64 %559
  %562 = load double, ptr %561, align 8
  %563 = fmul double %560, %562
  %564 = fadd double %558, %563
  store double %564, ptr %520, align 8
  %565 = or disjoint i64 %522, 7
  %gep14.7 = getelementptr double, ptr %invariant.gep13, i64 %565
  %566 = load double, ptr %gep14.7, align 8
  %567 = getelementptr double, ptr %8, i64 %565
  %568 = load double, ptr %567, align 8
  %569 = fmul double %566, %568
  %570 = fadd double %564, %569
  store double %570, ptr %520, align 8
  %571 = add nuw nsw i64 %522, 8
  %exitcond.10.not.7 = icmp eq i64 %571, 256
  br i1 %exitcond.10.not.7, label %.preheader.11, label %521

.preheader.11:                                    ; preds = %521
  %572 = getelementptr double, ptr %20, i64 11
  %.promoted.11 = load double, ptr %572, align 8
  %invariant.gep11 = getelementptr double, ptr %19, i64 2816
  br label %573

573:                                              ; preds = %573, %.preheader.11
  %574 = phi i64 [ 0, %.preheader.11 ], [ %623, %573 ]
  %575 = phi double [ %.promoted.11, %.preheader.11 ], [ %622, %573 ]
  %gep12 = getelementptr double, ptr %invariant.gep11, i64 %574
  %576 = load double, ptr %gep12, align 8
  %577 = getelementptr double, ptr %8, i64 %574
  %578 = load double, ptr %577, align 8
  %579 = fmul double %576, %578
  %580 = fadd double %575, %579
  store double %580, ptr %572, align 8
  %581 = or disjoint i64 %574, 1
  %gep12.1 = getelementptr double, ptr %invariant.gep11, i64 %581
  %582 = load double, ptr %gep12.1, align 8
  %583 = getelementptr double, ptr %8, i64 %581
  %584 = load double, ptr %583, align 8
  %585 = fmul double %582, %584
  %586 = fadd double %580, %585
  store double %586, ptr %572, align 8
  %587 = or disjoint i64 %574, 2
  %gep12.2 = getelementptr double, ptr %invariant.gep11, i64 %587
  %588 = load double, ptr %gep12.2, align 8
  %589 = getelementptr double, ptr %8, i64 %587
  %590 = load double, ptr %589, align 8
  %591 = fmul double %588, %590
  %592 = fadd double %586, %591
  store double %592, ptr %572, align 8
  %593 = or disjoint i64 %574, 3
  %gep12.3 = getelementptr double, ptr %invariant.gep11, i64 %593
  %594 = load double, ptr %gep12.3, align 8
  %595 = getelementptr double, ptr %8, i64 %593
  %596 = load double, ptr %595, align 8
  %597 = fmul double %594, %596
  %598 = fadd double %592, %597
  store double %598, ptr %572, align 8
  %599 = or disjoint i64 %574, 4
  %gep12.4 = getelementptr double, ptr %invariant.gep11, i64 %599
  %600 = load double, ptr %gep12.4, align 8
  %601 = getelementptr double, ptr %8, i64 %599
  %602 = load double, ptr %601, align 8
  %603 = fmul double %600, %602
  %604 = fadd double %598, %603
  store double %604, ptr %572, align 8
  %605 = or disjoint i64 %574, 5
  %gep12.5 = getelementptr double, ptr %invariant.gep11, i64 %605
  %606 = load double, ptr %gep12.5, align 8
  %607 = getelementptr double, ptr %8, i64 %605
  %608 = load double, ptr %607, align 8
  %609 = fmul double %606, %608
  %610 = fadd double %604, %609
  store double %610, ptr %572, align 8
  %611 = or disjoint i64 %574, 6
  %gep12.6 = getelementptr double, ptr %invariant.gep11, i64 %611
  %612 = load double, ptr %gep12.6, align 8
  %613 = getelementptr double, ptr %8, i64 %611
  %614 = load double, ptr %613, align 8
  %615 = fmul double %612, %614
  %616 = fadd double %610, %615
  store double %616, ptr %572, align 8
  %617 = or disjoint i64 %574, 7
  %gep12.7 = getelementptr double, ptr %invariant.gep11, i64 %617
  %618 = load double, ptr %gep12.7, align 8
  %619 = getelementptr double, ptr %8, i64 %617
  %620 = load double, ptr %619, align 8
  %621 = fmul double %618, %620
  %622 = fadd double %616, %621
  store double %622, ptr %572, align 8
  %623 = add nuw nsw i64 %574, 8
  %exitcond.11.not.7 = icmp eq i64 %623, 256
  br i1 %exitcond.11.not.7, label %.preheader.12, label %573

.preheader.12:                                    ; preds = %573
  %624 = getelementptr double, ptr %20, i64 12
  %.promoted.12 = load double, ptr %624, align 8
  %invariant.gep9 = getelementptr double, ptr %19, i64 3072
  br label %625

625:                                              ; preds = %625, %.preheader.12
  %626 = phi i64 [ 0, %.preheader.12 ], [ %675, %625 ]
  %627 = phi double [ %.promoted.12, %.preheader.12 ], [ %674, %625 ]
  %gep10 = getelementptr double, ptr %invariant.gep9, i64 %626
  %628 = load double, ptr %gep10, align 8
  %629 = getelementptr double, ptr %8, i64 %626
  %630 = load double, ptr %629, align 8
  %631 = fmul double %628, %630
  %632 = fadd double %627, %631
  store double %632, ptr %624, align 8
  %633 = or disjoint i64 %626, 1
  %gep10.1 = getelementptr double, ptr %invariant.gep9, i64 %633
  %634 = load double, ptr %gep10.1, align 8
  %635 = getelementptr double, ptr %8, i64 %633
  %636 = load double, ptr %635, align 8
  %637 = fmul double %634, %636
  %638 = fadd double %632, %637
  store double %638, ptr %624, align 8
  %639 = or disjoint i64 %626, 2
  %gep10.2 = getelementptr double, ptr %invariant.gep9, i64 %639
  %640 = load double, ptr %gep10.2, align 8
  %641 = getelementptr double, ptr %8, i64 %639
  %642 = load double, ptr %641, align 8
  %643 = fmul double %640, %642
  %644 = fadd double %638, %643
  store double %644, ptr %624, align 8
  %645 = or disjoint i64 %626, 3
  %gep10.3 = getelementptr double, ptr %invariant.gep9, i64 %645
  %646 = load double, ptr %gep10.3, align 8
  %647 = getelementptr double, ptr %8, i64 %645
  %648 = load double, ptr %647, align 8
  %649 = fmul double %646, %648
  %650 = fadd double %644, %649
  store double %650, ptr %624, align 8
  %651 = or disjoint i64 %626, 4
  %gep10.4 = getelementptr double, ptr %invariant.gep9, i64 %651
  %652 = load double, ptr %gep10.4, align 8
  %653 = getelementptr double, ptr %8, i64 %651
  %654 = load double, ptr %653, align 8
  %655 = fmul double %652, %654
  %656 = fadd double %650, %655
  store double %656, ptr %624, align 8
  %657 = or disjoint i64 %626, 5
  %gep10.5 = getelementptr double, ptr %invariant.gep9, i64 %657
  %658 = load double, ptr %gep10.5, align 8
  %659 = getelementptr double, ptr %8, i64 %657
  %660 = load double, ptr %659, align 8
  %661 = fmul double %658, %660
  %662 = fadd double %656, %661
  store double %662, ptr %624, align 8
  %663 = or disjoint i64 %626, 6
  %gep10.6 = getelementptr double, ptr %invariant.gep9, i64 %663
  %664 = load double, ptr %gep10.6, align 8
  %665 = getelementptr double, ptr %8, i64 %663
  %666 = load double, ptr %665, align 8
  %667 = fmul double %664, %666
  %668 = fadd double %662, %667
  store double %668, ptr %624, align 8
  %669 = or disjoint i64 %626, 7
  %gep10.7 = getelementptr double, ptr %invariant.gep9, i64 %669
  %670 = load double, ptr %gep10.7, align 8
  %671 = getelementptr double, ptr %8, i64 %669
  %672 = load double, ptr %671, align 8
  %673 = fmul double %670, %672
  %674 = fadd double %668, %673
  store double %674, ptr %624, align 8
  %675 = add nuw nsw i64 %626, 8
  %exitcond.12.not.7 = icmp eq i64 %675, 256
  br i1 %exitcond.12.not.7, label %.preheader.13, label %625

.preheader.13:                                    ; preds = %625
  %676 = getelementptr double, ptr %20, i64 13
  %.promoted.13 = load double, ptr %676, align 8
  %invariant.gep7 = getelementptr double, ptr %19, i64 3328
  br label %677

677:                                              ; preds = %677, %.preheader.13
  %678 = phi i64 [ 0, %.preheader.13 ], [ %727, %677 ]
  %679 = phi double [ %.promoted.13, %.preheader.13 ], [ %726, %677 ]
  %gep8 = getelementptr double, ptr %invariant.gep7, i64 %678
  %680 = load double, ptr %gep8, align 8
  %681 = getelementptr double, ptr %8, i64 %678
  %682 = load double, ptr %681, align 8
  %683 = fmul double %680, %682
  %684 = fadd double %679, %683
  store double %684, ptr %676, align 8
  %685 = or disjoint i64 %678, 1
  %gep8.1 = getelementptr double, ptr %invariant.gep7, i64 %685
  %686 = load double, ptr %gep8.1, align 8
  %687 = getelementptr double, ptr %8, i64 %685
  %688 = load double, ptr %687, align 8
  %689 = fmul double %686, %688
  %690 = fadd double %684, %689
  store double %690, ptr %676, align 8
  %691 = or disjoint i64 %678, 2
  %gep8.2 = getelementptr double, ptr %invariant.gep7, i64 %691
  %692 = load double, ptr %gep8.2, align 8
  %693 = getelementptr double, ptr %8, i64 %691
  %694 = load double, ptr %693, align 8
  %695 = fmul double %692, %694
  %696 = fadd double %690, %695
  store double %696, ptr %676, align 8
  %697 = or disjoint i64 %678, 3
  %gep8.3 = getelementptr double, ptr %invariant.gep7, i64 %697
  %698 = load double, ptr %gep8.3, align 8
  %699 = getelementptr double, ptr %8, i64 %697
  %700 = load double, ptr %699, align 8
  %701 = fmul double %698, %700
  %702 = fadd double %696, %701
  store double %702, ptr %676, align 8
  %703 = or disjoint i64 %678, 4
  %gep8.4 = getelementptr double, ptr %invariant.gep7, i64 %703
  %704 = load double, ptr %gep8.4, align 8
  %705 = getelementptr double, ptr %8, i64 %703
  %706 = load double, ptr %705, align 8
  %707 = fmul double %704, %706
  %708 = fadd double %702, %707
  store double %708, ptr %676, align 8
  %709 = or disjoint i64 %678, 5
  %gep8.5 = getelementptr double, ptr %invariant.gep7, i64 %709
  %710 = load double, ptr %gep8.5, align 8
  %711 = getelementptr double, ptr %8, i64 %709
  %712 = load double, ptr %711, align 8
  %713 = fmul double %710, %712
  %714 = fadd double %708, %713
  store double %714, ptr %676, align 8
  %715 = or disjoint i64 %678, 6
  %gep8.6 = getelementptr double, ptr %invariant.gep7, i64 %715
  %716 = load double, ptr %gep8.6, align 8
  %717 = getelementptr double, ptr %8, i64 %715
  %718 = load double, ptr %717, align 8
  %719 = fmul double %716, %718
  %720 = fadd double %714, %719
  store double %720, ptr %676, align 8
  %721 = or disjoint i64 %678, 7
  %gep8.7 = getelementptr double, ptr %invariant.gep7, i64 %721
  %722 = load double, ptr %gep8.7, align 8
  %723 = getelementptr double, ptr %8, i64 %721
  %724 = load double, ptr %723, align 8
  %725 = fmul double %722, %724
  %726 = fadd double %720, %725
  store double %726, ptr %676, align 8
  %727 = add nuw nsw i64 %678, 8
  %exitcond.13.not.7 = icmp eq i64 %727, 256
  br i1 %exitcond.13.not.7, label %.preheader.14, label %677

.preheader.14:                                    ; preds = %677
  %728 = getelementptr double, ptr %20, i64 14
  %.promoted.14 = load double, ptr %728, align 8
  %invariant.gep5 = getelementptr double, ptr %19, i64 3584
  br label %729

729:                                              ; preds = %729, %.preheader.14
  %730 = phi i64 [ 0, %.preheader.14 ], [ %779, %729 ]
  %731 = phi double [ %.promoted.14, %.preheader.14 ], [ %778, %729 ]
  %gep6 = getelementptr double, ptr %invariant.gep5, i64 %730
  %732 = load double, ptr %gep6, align 8
  %733 = getelementptr double, ptr %8, i64 %730
  %734 = load double, ptr %733, align 8
  %735 = fmul double %732, %734
  %736 = fadd double %731, %735
  store double %736, ptr %728, align 8
  %737 = or disjoint i64 %730, 1
  %gep6.1 = getelementptr double, ptr %invariant.gep5, i64 %737
  %738 = load double, ptr %gep6.1, align 8
  %739 = getelementptr double, ptr %8, i64 %737
  %740 = load double, ptr %739, align 8
  %741 = fmul double %738, %740
  %742 = fadd double %736, %741
  store double %742, ptr %728, align 8
  %743 = or disjoint i64 %730, 2
  %gep6.2 = getelementptr double, ptr %invariant.gep5, i64 %743
  %744 = load double, ptr %gep6.2, align 8
  %745 = getelementptr double, ptr %8, i64 %743
  %746 = load double, ptr %745, align 8
  %747 = fmul double %744, %746
  %748 = fadd double %742, %747
  store double %748, ptr %728, align 8
  %749 = or disjoint i64 %730, 3
  %gep6.3 = getelementptr double, ptr %invariant.gep5, i64 %749
  %750 = load double, ptr %gep6.3, align 8
  %751 = getelementptr double, ptr %8, i64 %749
  %752 = load double, ptr %751, align 8
  %753 = fmul double %750, %752
  %754 = fadd double %748, %753
  store double %754, ptr %728, align 8
  %755 = or disjoint i64 %730, 4
  %gep6.4 = getelementptr double, ptr %invariant.gep5, i64 %755
  %756 = load double, ptr %gep6.4, align 8
  %757 = getelementptr double, ptr %8, i64 %755
  %758 = load double, ptr %757, align 8
  %759 = fmul double %756, %758
  %760 = fadd double %754, %759
  store double %760, ptr %728, align 8
  %761 = or disjoint i64 %730, 5
  %gep6.5 = getelementptr double, ptr %invariant.gep5, i64 %761
  %762 = load double, ptr %gep6.5, align 8
  %763 = getelementptr double, ptr %8, i64 %761
  %764 = load double, ptr %763, align 8
  %765 = fmul double %762, %764
  %766 = fadd double %760, %765
  store double %766, ptr %728, align 8
  %767 = or disjoint i64 %730, 6
  %gep6.6 = getelementptr double, ptr %invariant.gep5, i64 %767
  %768 = load double, ptr %gep6.6, align 8
  %769 = getelementptr double, ptr %8, i64 %767
  %770 = load double, ptr %769, align 8
  %771 = fmul double %768, %770
  %772 = fadd double %766, %771
  store double %772, ptr %728, align 8
  %773 = or disjoint i64 %730, 7
  %gep6.7 = getelementptr double, ptr %invariant.gep5, i64 %773
  %774 = load double, ptr %gep6.7, align 8
  %775 = getelementptr double, ptr %8, i64 %773
  %776 = load double, ptr %775, align 8
  %777 = fmul double %774, %776
  %778 = fadd double %772, %777
  store double %778, ptr %728, align 8
  %779 = add nuw nsw i64 %730, 8
  %exitcond.14.not.7 = icmp eq i64 %779, 256
  br i1 %exitcond.14.not.7, label %.preheader.15, label %729

.preheader.15:                                    ; preds = %729
  %780 = getelementptr double, ptr %20, i64 15
  %.promoted.15 = load double, ptr %780, align 8
  %invariant.gep = getelementptr double, ptr %19, i64 3840
  br label %781

781:                                              ; preds = %781, %.preheader.15
  %782 = phi i64 [ 0, %.preheader.15 ], [ %831, %781 ]
  %783 = phi double [ %.promoted.15, %.preheader.15 ], [ %830, %781 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %782
  %784 = load double, ptr %gep, align 8
  %785 = getelementptr double, ptr %8, i64 %782
  %786 = load double, ptr %785, align 8
  %787 = fmul double %784, %786
  %788 = fadd double %783, %787
  store double %788, ptr %780, align 8
  %789 = or disjoint i64 %782, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %789
  %790 = load double, ptr %gep.1, align 8
  %791 = getelementptr double, ptr %8, i64 %789
  %792 = load double, ptr %791, align 8
  %793 = fmul double %790, %792
  %794 = fadd double %788, %793
  store double %794, ptr %780, align 8
  %795 = or disjoint i64 %782, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %795
  %796 = load double, ptr %gep.2, align 8
  %797 = getelementptr double, ptr %8, i64 %795
  %798 = load double, ptr %797, align 8
  %799 = fmul double %796, %798
  %800 = fadd double %794, %799
  store double %800, ptr %780, align 8
  %801 = or disjoint i64 %782, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %801
  %802 = load double, ptr %gep.3, align 8
  %803 = getelementptr double, ptr %8, i64 %801
  %804 = load double, ptr %803, align 8
  %805 = fmul double %802, %804
  %806 = fadd double %800, %805
  store double %806, ptr %780, align 8
  %807 = or disjoint i64 %782, 4
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 %807
  %808 = load double, ptr %gep.4, align 8
  %809 = getelementptr double, ptr %8, i64 %807
  %810 = load double, ptr %809, align 8
  %811 = fmul double %808, %810
  %812 = fadd double %806, %811
  store double %812, ptr %780, align 8
  %813 = or disjoint i64 %782, 5
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 %813
  %814 = load double, ptr %gep.5, align 8
  %815 = getelementptr double, ptr %8, i64 %813
  %816 = load double, ptr %815, align 8
  %817 = fmul double %814, %816
  %818 = fadd double %812, %817
  store double %818, ptr %780, align 8
  %819 = or disjoint i64 %782, 6
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 %819
  %820 = load double, ptr %gep.6, align 8
  %821 = getelementptr double, ptr %8, i64 %819
  %822 = load double, ptr %821, align 8
  %823 = fmul double %820, %822
  %824 = fadd double %818, %823
  store double %824, ptr %780, align 8
  %825 = or disjoint i64 %782, 7
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 %825
  %826 = load double, ptr %gep.7, align 8
  %827 = getelementptr double, ptr %8, i64 %825
  %828 = load double, ptr %827, align 8
  %829 = fmul double %826, %828
  %830 = fadd double %824, %829
  store double %830, ptr %780, align 8
  %831 = add nuw nsw i64 %782, 8
  %exitcond.15.not.7 = icmp eq i64 %831, 256
  br i1 %exitcond.15.not.7, label %832, label %781

832:                                              ; preds = %781
  %833 = add nuw nsw i64 %17, 16
  %834 = icmp ult i64 %17, 240
  br i1 %834, label %.preheader3, label %835

835:                                              ; preds = %832
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
