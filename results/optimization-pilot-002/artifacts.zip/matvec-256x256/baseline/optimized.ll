; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %13, i8 0, i64 2048, i1 false)
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %47
  %17 = phi i64 [ %48, %47 ], [ 0, %.preheader.preheader ]
  %18 = shl i64 %17, 8
  %19 = getelementptr double, ptr %13, i64 %17
  %.promoted = load double, ptr %19, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %18
  br label %20

20:                                               ; preds = %20, %.preheader
  %21 = phi i64 [ 0, %.preheader ], [ %46, %20 ]
  %22 = phi double [ %.promoted, %.preheader ], [ %45, %20 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %21
  %23 = load double, ptr %gep, align 8
  %24 = getelementptr double, ptr %8, i64 %21
  %25 = load double, ptr %24, align 8
  %26 = fmul double %23, %25
  %27 = fadd double %22, %26
  store double %27, ptr %19, align 8
  %28 = or disjoint i64 %21, 1
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 %28
  %29 = load double, ptr %gep.1, align 8
  %30 = getelementptr double, ptr %8, i64 %28
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %27, %32
  store double %33, ptr %19, align 8
  %34 = or disjoint i64 %21, 2
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 %34
  %35 = load double, ptr %gep.2, align 8
  %36 = getelementptr double, ptr %8, i64 %34
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %33, %38
  store double %39, ptr %19, align 8
  %40 = or disjoint i64 %21, 3
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 %40
  %41 = load double, ptr %gep.3, align 8
  %42 = getelementptr double, ptr %8, i64 %40
  %43 = load double, ptr %42, align 8
  %44 = fmul double %41, %43
  %45 = fadd double %39, %44
  store double %45, ptr %19, align 8
  %46 = add nuw nsw i64 %21, 4
  %exitcond.not.3 = icmp eq i64 %46, 256
  br i1 %exitcond.not.3, label %47, label %20

47:                                               ; preds = %20
  %48 = add nuw nsw i64 %17, 1
  %exitcond3.not = icmp eq i64 %48, 256
  br i1 %exitcond3.not, label %49, label %.preheader

49:                                               ; preds = %47
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack28, i8 0, i64 2048, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %34, %3
  %4 = phi i64 [ %35, %34 ], [ 0, %3 ]
  %5 = shl i64 %4, 8
  %6 = getelementptr double, ptr %.unpack28, i64 %4
  %.promoted.i = load double, ptr %6, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %5
  br label %7

7:                                                ; preds = %7, %.preheader.i
  %8 = phi i64 [ 0, %.preheader.i ], [ %33, %7 ]
  %9 = phi double [ %.promoted.i, %.preheader.i ], [ %32, %7 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %8
  %10 = load double, ptr %gep.i, align 8
  %11 = getelementptr double, ptr %.unpack17, i64 %8
  %12 = load double, ptr %11, align 8
  %13 = fmul double %10, %12
  %14 = fadd double %9, %13
  store double %14, ptr %6, align 8
  %15 = or disjoint i64 %8, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %15
  %16 = load double, ptr %gep.i.1, align 8
  %17 = getelementptr double, ptr %.unpack17, i64 %15
  %18 = load double, ptr %17, align 8
  %19 = fmul double %16, %18
  %20 = fadd double %14, %19
  store double %20, ptr %6, align 8
  %21 = or disjoint i64 %8, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %21
  %22 = load double, ptr %gep.i.2, align 8
  %23 = getelementptr double, ptr %.unpack17, i64 %21
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %20, %25
  store double %26, ptr %6, align 8
  %27 = or disjoint i64 %8, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %27
  %28 = load double, ptr %gep.i.3, align 8
  %29 = getelementptr double, ptr %.unpack17, i64 %27
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %26, %31
  store double %32, ptr %6, align 8
  %33 = add nuw nsw i64 %8, 4
  %exitcond.not.i.3 = icmp eq i64 %33, 256
  br i1 %exitcond.not.i.3, label %34, label %7

34:                                               ; preds = %7
  %35 = add nuw nsw i64 %4, 1
  %exitcond3.not.i = icmp eq i64 %35, 256
  br i1 %exitcond3.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %34
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %10, i8 0, i64 2048, i1 false)
  br label %.preheader.i

.preheader.i:                                     ; preds = %41, %1
  %11 = phi i64 [ %42, %41 ], [ 0, %1 ]
  %12 = shl i64 %11, 8
  %13 = getelementptr double, ptr %10, i64 %11
  %.promoted.i = load double, ptr %13, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %12
  br label %14

14:                                               ; preds = %14, %.preheader.i
  %15 = phi i64 [ 0, %.preheader.i ], [ %40, %14 ]
  %16 = phi double [ %.promoted.i, %.preheader.i ], [ %39, %14 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %15
  %17 = load double, ptr %gep.i, align 8
  %18 = getelementptr double, ptr %7, i64 %15
  %19 = load double, ptr %18, align 8
  %20 = fmul double %17, %19
  %21 = fadd double %16, %20
  store double %21, ptr %13, align 8
  %22 = or disjoint i64 %15, 1
  %gep.i.1 = getelementptr double, ptr %invariant.gep.i, i64 %22
  %23 = load double, ptr %gep.i.1, align 8
  %24 = getelementptr double, ptr %7, i64 %22
  %25 = load double, ptr %24, align 8
  %26 = fmul double %23, %25
  %27 = fadd double %21, %26
  store double %27, ptr %13, align 8
  %28 = or disjoint i64 %15, 2
  %gep.i.2 = getelementptr double, ptr %invariant.gep.i, i64 %28
  %29 = load double, ptr %gep.i.2, align 8
  %30 = getelementptr double, ptr %7, i64 %28
  %31 = load double, ptr %30, align 8
  %32 = fmul double %29, %31
  %33 = fadd double %27, %32
  store double %33, ptr %13, align 8
  %34 = or disjoint i64 %15, 3
  %gep.i.3 = getelementptr double, ptr %invariant.gep.i, i64 %34
  %35 = load double, ptr %gep.i.3, align 8
  %36 = getelementptr double, ptr %7, i64 %34
  %37 = load double, ptr %36, align 8
  %38 = fmul double %35, %37
  %39 = fadd double %33, %38
  store double %39, ptr %13, align 8
  %40 = add nuw nsw i64 %15, 4
  %exitcond.not.i.3 = icmp eq i64 %40, 256
  br i1 %exitcond.not.i.3, label %41, label %14

41:                                               ; preds = %14
  %42 = add nuw nsw i64 %11, 1
  %exitcond3.not.i = icmp eq i64 %42, 256
  br i1 %exitcond3.not.i, label %kernel.exit, label %.preheader.i

kernel.exit:                                      ; preds = %41
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %.unpack28.i, i8 0, i64 2048, i1 false)
  br label %.preheader.i.i

.preheader.i.i:                                   ; preds = %40, %1
  %10 = phi i64 [ %41, %40 ], [ 0, %1 ]
  %11 = shl i64 %10, 8
  %12 = getelementptr double, ptr %.unpack28.i, i64 %10
  %.promoted.i.i = load double, ptr %12, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %11
  br label %13

13:                                               ; preds = %13, %.preheader.i.i
  %14 = phi i64 [ 0, %.preheader.i.i ], [ %39, %13 ]
  %15 = phi double [ %.promoted.i.i, %.preheader.i.i ], [ %38, %13 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %14
  %16 = load double, ptr %gep.i.i, align 8
  %17 = getelementptr double, ptr %.unpack17.i, i64 %14
  %18 = load double, ptr %17, align 8
  %19 = fmul double %16, %18
  %20 = fadd double %15, %19
  store double %20, ptr %12, align 8
  %21 = or disjoint i64 %14, 1
  %gep.i.i.1 = getelementptr double, ptr %invariant.gep.i.i, i64 %21
  %22 = load double, ptr %gep.i.i.1, align 8
  %23 = getelementptr double, ptr %.unpack17.i, i64 %21
  %24 = load double, ptr %23, align 8
  %25 = fmul double %22, %24
  %26 = fadd double %20, %25
  store double %26, ptr %12, align 8
  %27 = or disjoint i64 %14, 2
  %gep.i.i.2 = getelementptr double, ptr %invariant.gep.i.i, i64 %27
  %28 = load double, ptr %gep.i.i.2, align 8
  %29 = getelementptr double, ptr %.unpack17.i, i64 %27
  %30 = load double, ptr %29, align 8
  %31 = fmul double %28, %30
  %32 = fadd double %26, %31
  store double %32, ptr %12, align 8
  %33 = or disjoint i64 %14, 3
  %gep.i.i.3 = getelementptr double, ptr %invariant.gep.i.i, i64 %33
  %34 = load double, ptr %gep.i.i.3, align 8
  %35 = getelementptr double, ptr %.unpack17.i, i64 %33
  %36 = load double, ptr %35, align 8
  %37 = fmul double %34, %36
  %38 = fadd double %32, %37
  store double %38, ptr %12, align 8
  %39 = add nuw nsw i64 %14, 4
  %exitcond.not.i.i.3 = icmp eq i64 %39, 256
  br i1 %exitcond.not.i.i.3, label %40, label %13

40:                                               ; preds = %13
  %41 = add nuw nsw i64 %10, 1
  %exitcond3.not.i.i = icmp eq i64 %41, 256
  br i1 %exitcond3.not.i.i, label %_mlir_ciface_kernel.exit, label %.preheader.i.i

_mlir_ciface_kernel.exit:                         ; preds = %40
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
