; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %15, i8 0, i64 36864, i1 false)
  %scevgep10 = getelementptr i8, ptr %8, i64 18432
  %invariant.gep85 = getelementptr i8, ptr %15, i64 3072
  %invariant.gep86 = getelementptr i8, ptr %1, i64 768
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %254
  %indvar = phi i64 [ 0, %.preheader4.preheader ], [ %indvar.next, %254 ]
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %255, %254 ]
  %22 = mul nuw nsw i64 %indvar, 3072
  %scevgep = getelementptr i8, ptr %15, i64 %22
  %gep = getelementptr i8, ptr %invariant.gep85, i64 %22
  %23 = mul nuw nsw i64 %indvar, 768
  %scevgep8 = getelementptr i8, ptr %1, i64 %23
  %gep87 = getelementptr i8, ptr %invariant.gep86, i64 %23
  %24 = mul nuw nsw i64 %21, 24
  %25 = mul nuw nsw i64 %21, 96
  %26 = getelementptr double, ptr %1, i64 %24
  %27 = getelementptr double, ptr %15, i64 %25
  %bound0 = icmp ult ptr %scevgep, %gep87
  %bound1 = icmp ult ptr %scevgep8, %gep
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %gep, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %middle.block
  %28 = phi i64 [ 0, %.preheader4 ], [ %253, %middle.block ]
  %29 = mul nuw nsw i64 %28, 24
  %30 = getelementptr double, ptr %26, i64 %29
  %31 = mul nuw nsw i64 %28, 96
  %32 = getelementptr double, ptr %27, i64 %31
  %33 = getelementptr double, ptr %30, i64 1
  %34 = getelementptr double, ptr %30, i64 2
  %35 = getelementptr double, ptr %30, i64 3
  %36 = getelementptr double, ptr %30, i64 4
  %37 = getelementptr double, ptr %30, i64 5
  %38 = getelementptr double, ptr %30, i64 6
  %39 = getelementptr double, ptr %30, i64 7
  %40 = getelementptr double, ptr %30, i64 8
  %41 = getelementptr double, ptr %30, i64 9
  %42 = getelementptr double, ptr %30, i64 10
  %43 = getelementptr double, ptr %30, i64 11
  %44 = getelementptr double, ptr %30, i64 12
  %45 = getelementptr double, ptr %30, i64 13
  %46 = getelementptr double, ptr %30, i64 14
  %47 = getelementptr double, ptr %30, i64 15
  %48 = getelementptr double, ptr %30, i64 16
  %49 = getelementptr double, ptr %30, i64 17
  %50 = getelementptr double, ptr %30, i64 18
  %51 = getelementptr double, ptr %30, i64 19
  %52 = getelementptr double, ptr %30, i64 20
  %53 = getelementptr double, ptr %30, i64 21
  %54 = getelementptr double, ptr %30, i64 22
  %55 = getelementptr double, ptr %30, i64 23
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %56 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %71 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %71, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %72, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = load double, ptr %49, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %73, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %74 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %74, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %75 = load double, ptr %51, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %75, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %76 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %76, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %77 = load double, ptr %53, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %77, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %78 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %78, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %79 = load double, ptr %55, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %79, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %80 = getelementptr double, ptr %8, i64 %index
  %81 = getelementptr double, ptr %32, i64 %index
  %wide.load = load <4 x double>, ptr %81, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %80, align 8, !alias.scope !8
  %82 = fmul <4 x double> %broadcast.splat, %wide.load14
  %83 = fadd <4 x double> %wide.load, %82
  store <4 x double> %83, ptr %81, align 8, !alias.scope !4, !noalias !6
  %84 = getelementptr double, ptr %80, i64 96
  %wide.load15 = load <4 x double>, ptr %84, align 8, !alias.scope !8
  %85 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %86 = fadd <4 x double> %83, %85
  store <4 x double> %86, ptr %81, align 8, !alias.scope !4, !noalias !6
  %87 = getelementptr double, ptr %80, i64 192
  %wide.load18 = load <4 x double>, ptr %87, align 8, !alias.scope !8
  %88 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %89 = fadd <4 x double> %86, %88
  store <4 x double> %89, ptr %81, align 8, !alias.scope !4, !noalias !6
  %90 = getelementptr double, ptr %80, i64 288
  %wide.load21 = load <4 x double>, ptr %90, align 8, !alias.scope !8
  %91 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %92 = fadd <4 x double> %89, %91
  store <4 x double> %92, ptr %81, align 8, !alias.scope !4, !noalias !6
  %93 = getelementptr double, ptr %80, i64 384
  %wide.load24 = load <4 x double>, ptr %93, align 8, !alias.scope !8
  %94 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %95 = fadd <4 x double> %92, %94
  store <4 x double> %95, ptr %81, align 8, !alias.scope !4, !noalias !6
  %96 = getelementptr double, ptr %80, i64 480
  %wide.load27 = load <4 x double>, ptr %96, align 8, !alias.scope !8
  %97 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %98 = fadd <4 x double> %95, %97
  store <4 x double> %98, ptr %81, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %80, i64 576
  %wide.load30 = load <4 x double>, ptr %99, align 8, !alias.scope !8
  %100 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %101 = fadd <4 x double> %98, %100
  store <4 x double> %101, ptr %81, align 8, !alias.scope !4, !noalias !6
  %102 = getelementptr double, ptr %80, i64 672
  %wide.load33 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %103 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %104 = fadd <4 x double> %101, %103
  store <4 x double> %104, ptr %81, align 8, !alias.scope !4, !noalias !6
  %105 = getelementptr double, ptr %80, i64 768
  %wide.load36 = load <4 x double>, ptr %105, align 8, !alias.scope !8
  %106 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %107 = fadd <4 x double> %104, %106
  store <4 x double> %107, ptr %81, align 8, !alias.scope !4, !noalias !6
  %108 = getelementptr double, ptr %80, i64 864
  %wide.load39 = load <4 x double>, ptr %108, align 8, !alias.scope !8
  %109 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %110 = fadd <4 x double> %107, %109
  store <4 x double> %110, ptr %81, align 8, !alias.scope !4, !noalias !6
  %111 = getelementptr double, ptr %80, i64 960
  %wide.load42 = load <4 x double>, ptr %111, align 8, !alias.scope !8
  %112 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %113 = fadd <4 x double> %110, %112
  store <4 x double> %113, ptr %81, align 8, !alias.scope !4, !noalias !6
  %114 = getelementptr double, ptr %80, i64 1056
  %wide.load45 = load <4 x double>, ptr %114, align 8, !alias.scope !8
  %115 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %116 = fadd <4 x double> %113, %115
  store <4 x double> %116, ptr %81, align 8, !alias.scope !4, !noalias !6
  %117 = getelementptr double, ptr %80, i64 1152
  %wide.load48 = load <4 x double>, ptr %117, align 8, !alias.scope !8
  %118 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %119 = fadd <4 x double> %116, %118
  store <4 x double> %119, ptr %81, align 8, !alias.scope !4, !noalias !6
  %120 = getelementptr double, ptr %80, i64 1248
  %wide.load51 = load <4 x double>, ptr %120, align 8, !alias.scope !8
  %121 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %122 = fadd <4 x double> %119, %121
  store <4 x double> %122, ptr %81, align 8, !alias.scope !4, !noalias !6
  %123 = getelementptr double, ptr %80, i64 1344
  %wide.load54 = load <4 x double>, ptr %123, align 8, !alias.scope !8
  %124 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %125 = fadd <4 x double> %122, %124
  store <4 x double> %125, ptr %81, align 8, !alias.scope !4, !noalias !6
  %126 = getelementptr double, ptr %80, i64 1440
  %wide.load57 = load <4 x double>, ptr %126, align 8, !alias.scope !8
  %127 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %128 = fadd <4 x double> %125, %127
  store <4 x double> %128, ptr %81, align 8, !alias.scope !4, !noalias !6
  %129 = getelementptr double, ptr %80, i64 1536
  %wide.load60 = load <4 x double>, ptr %129, align 8, !alias.scope !8
  %130 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %131 = fadd <4 x double> %128, %130
  store <4 x double> %131, ptr %81, align 8, !alias.scope !4, !noalias !6
  %132 = getelementptr double, ptr %80, i64 1632
  %wide.load63 = load <4 x double>, ptr %132, align 8, !alias.scope !8
  %133 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %134 = fadd <4 x double> %131, %133
  store <4 x double> %134, ptr %81, align 8, !alias.scope !4, !noalias !6
  %135 = getelementptr double, ptr %80, i64 1728
  %wide.load66 = load <4 x double>, ptr %135, align 8, !alias.scope !8
  %136 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %137 = fadd <4 x double> %134, %136
  store <4 x double> %137, ptr %81, align 8, !alias.scope !4, !noalias !6
  %138 = getelementptr double, ptr %80, i64 1824
  %wide.load69 = load <4 x double>, ptr %138, align 8, !alias.scope !8
  %139 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %140 = fadd <4 x double> %137, %139
  store <4 x double> %140, ptr %81, align 8, !alias.scope !4, !noalias !6
  %141 = getelementptr double, ptr %80, i64 1920
  %wide.load72 = load <4 x double>, ptr %141, align 8, !alias.scope !8
  %142 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %143 = fadd <4 x double> %140, %142
  store <4 x double> %143, ptr %81, align 8, !alias.scope !4, !noalias !6
  %144 = getelementptr double, ptr %80, i64 2016
  %wide.load75 = load <4 x double>, ptr %144, align 8, !alias.scope !8
  %145 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %146 = fadd <4 x double> %143, %145
  store <4 x double> %146, ptr %81, align 8, !alias.scope !4, !noalias !6
  %147 = getelementptr double, ptr %80, i64 2112
  %wide.load78 = load <4 x double>, ptr %147, align 8, !alias.scope !8
  %148 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %149 = fadd <4 x double> %146, %148
  store <4 x double> %149, ptr %81, align 8, !alias.scope !4, !noalias !6
  %150 = getelementptr double, ptr %80, i64 2208
  %wide.load81 = load <4 x double>, ptr %150, align 8, !alias.scope !8
  %151 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %152 = fadd <4 x double> %149, %151
  store <4 x double> %152, ptr %81, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %153 = icmp eq i64 %index.next, 96
  br i1 %153, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %154 = phi i64 [ %252, %.preheader ], [ 0, %.preheader3 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %154
  %155 = getelementptr double, ptr %32, i64 %154
  %.promoted = load double, ptr %155, align 8
  %156 = load double, ptr %30, align 8
  %157 = load double, ptr %invariant.gep, align 8
  %158 = fmul double %156, %157
  %159 = fadd double %.promoted, %158
  store double %159, ptr %155, align 8
  %160 = load double, ptr %33, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 96
  %161 = load double, ptr %gep.1, align 8
  %162 = fmul double %160, %161
  %163 = fadd double %159, %162
  store double %163, ptr %155, align 8
  %164 = load double, ptr %34, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 192
  %165 = load double, ptr %gep.2, align 8
  %166 = fmul double %164, %165
  %167 = fadd double %163, %166
  store double %167, ptr %155, align 8
  %168 = load double, ptr %35, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 288
  %169 = load double, ptr %gep.3, align 8
  %170 = fmul double %168, %169
  %171 = fadd double %167, %170
  store double %171, ptr %155, align 8
  %172 = load double, ptr %36, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 384
  %173 = load double, ptr %gep.4, align 8
  %174 = fmul double %172, %173
  %175 = fadd double %171, %174
  store double %175, ptr %155, align 8
  %176 = load double, ptr %37, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 480
  %177 = load double, ptr %gep.5, align 8
  %178 = fmul double %176, %177
  %179 = fadd double %175, %178
  store double %179, ptr %155, align 8
  %180 = load double, ptr %38, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 576
  %181 = load double, ptr %gep.6, align 8
  %182 = fmul double %180, %181
  %183 = fadd double %179, %182
  store double %183, ptr %155, align 8
  %184 = load double, ptr %39, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 672
  %185 = load double, ptr %gep.7, align 8
  %186 = fmul double %184, %185
  %187 = fadd double %183, %186
  store double %187, ptr %155, align 8
  %188 = load double, ptr %40, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 768
  %189 = load double, ptr %gep.8, align 8
  %190 = fmul double %188, %189
  %191 = fadd double %187, %190
  store double %191, ptr %155, align 8
  %192 = load double, ptr %41, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 864
  %193 = load double, ptr %gep.9, align 8
  %194 = fmul double %192, %193
  %195 = fadd double %191, %194
  store double %195, ptr %155, align 8
  %196 = load double, ptr %42, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 960
  %197 = load double, ptr %gep.10, align 8
  %198 = fmul double %196, %197
  %199 = fadd double %195, %198
  store double %199, ptr %155, align 8
  %200 = load double, ptr %43, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 1056
  %201 = load double, ptr %gep.11, align 8
  %202 = fmul double %200, %201
  %203 = fadd double %199, %202
  store double %203, ptr %155, align 8
  %204 = load double, ptr %44, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 1152
  %205 = load double, ptr %gep.12, align 8
  %206 = fmul double %204, %205
  %207 = fadd double %203, %206
  store double %207, ptr %155, align 8
  %208 = load double, ptr %45, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 1248
  %209 = load double, ptr %gep.13, align 8
  %210 = fmul double %208, %209
  %211 = fadd double %207, %210
  store double %211, ptr %155, align 8
  %212 = load double, ptr %46, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 1344
  %213 = load double, ptr %gep.14, align 8
  %214 = fmul double %212, %213
  %215 = fadd double %211, %214
  store double %215, ptr %155, align 8
  %216 = load double, ptr %47, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 1440
  %217 = load double, ptr %gep.15, align 8
  %218 = fmul double %216, %217
  %219 = fadd double %215, %218
  store double %219, ptr %155, align 8
  %220 = load double, ptr %48, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1536
  %221 = load double, ptr %gep.16, align 8
  %222 = fmul double %220, %221
  %223 = fadd double %219, %222
  store double %223, ptr %155, align 8
  %224 = load double, ptr %49, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 1632
  %225 = load double, ptr %gep.17, align 8
  %226 = fmul double %224, %225
  %227 = fadd double %223, %226
  store double %227, ptr %155, align 8
  %228 = load double, ptr %50, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 1728
  %229 = load double, ptr %gep.18, align 8
  %230 = fmul double %228, %229
  %231 = fadd double %227, %230
  store double %231, ptr %155, align 8
  %232 = load double, ptr %51, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 1824
  %233 = load double, ptr %gep.19, align 8
  %234 = fmul double %232, %233
  %235 = fadd double %231, %234
  store double %235, ptr %155, align 8
  %236 = load double, ptr %52, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 1920
  %237 = load double, ptr %gep.20, align 8
  %238 = fmul double %236, %237
  %239 = fadd double %235, %238
  store double %239, ptr %155, align 8
  %240 = load double, ptr %53, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 2016
  %241 = load double, ptr %gep.21, align 8
  %242 = fmul double %240, %241
  %243 = fadd double %239, %242
  store double %243, ptr %155, align 8
  %244 = load double, ptr %54, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 2112
  %245 = load double, ptr %gep.22, align 8
  %246 = fmul double %244, %245
  %247 = fadd double %243, %246
  store double %247, ptr %155, align 8
  %248 = load double, ptr %55, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 2208
  %249 = load double, ptr %gep.23, align 8
  %250 = fmul double %248, %249
  %251 = fadd double %247, %250
  store double %251, ptr %155, align 8
  %252 = add nuw nsw i64 %154, 1
  %exitcond.not = icmp eq i64 %252, 96
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %253 = add nuw nsw i64 %28, 1
  %exitcond6.not = icmp eq i64 %253, 4
  br i1 %exitcond6.not, label %254, label %.preheader3

254:                                              ; preds = %middle.block
  %255 = add nuw nsw i64 %21, 4
  %256 = icmp ult i64 %21, 44
  %indvar.next = add i64 %indvar, 1
  br i1 %256, label %.preheader4, label %257

257:                                              ; preds = %254
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
