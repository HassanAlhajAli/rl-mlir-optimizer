#map = affine_map<(d0, d1, d2) -> (d0, d2)>
#map1 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map2 = affine_map<(d0, d1, d2) -> (d0, d1)>
module {
  func.func @kernel(%arg0: memref<48x24xf64>, %arg1: memref<24x96xf64>, %arg2: memref<48x96xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<48x96xf64>)
    %c0_1 = arith.constant 0 : index
    %c48 = arith.constant 48 : index
    %c4_2 = arith.constant 4 : index
    scf.for %arg3 = %c0_1 to %c48 step %c4_2 {
      %subview = memref.subview %arg0[%arg3, 0] [4, 24] [1, 1] : memref<48x24xf64> to memref<4x24xf64, strided<[24, 1], offset: ?>>
      %subview_3 = memref.subview %arg2[%arg3, 0] [4, 96] [1, 1] : memref<48x96xf64> to memref<4x96xf64, strided<[96, 1], offset: ?>>
      linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "parallel", "reduction"]} ins(%subview, %arg1 : memref<4x24xf64, strided<[24, 1], offset: ?>>, memref<24x96xf64>) outs(%subview_3 : memref<4x96xf64, strided<[96, 1], offset: ?>>) {
      ^bb0(%in: f64, %in_4: f64, %out: f64):
        %0 = arith.mulf %in, %in_4 : f64
        %1 = arith.addf %out, %0 : f64
        linalg.yield %1 : f64
      }
    }
    return
  }
}
