#map = affine_map<(d0, d1) -> (d0, 0, d1)>
#map1 = affine_map<(d0, d1) -> (0, d1, d0)>
module {
  func.func @kernel(%arg0: memref<48x24xf64>, %arg1: memref<24x96xf64>, %arg2: memref<48x96xf64>) attributes {llvm.emit_c_interface} {
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c0_1 = arith.constant 0 : index
    %c8 = arith.constant 8 : index
    %c0_2 = arith.constant 0 : index
    %c8_3 = arith.constant 8 : index
    %c0_4 = arith.constant 0 : index
    %c0_5 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<48x96xf64>)
    %c0_6 = arith.constant 0 : index
    %c48 = arith.constant 48 : index
    %c8_7 = arith.constant 8 : index
    scf.for %arg3 = %c0_6 to %c48 step %c8_7 {
      %subview = memref.subview %arg0[%arg3, 0] [8, 24] [1, 1] : memref<48x24xf64> to memref<8x24xf64, strided<[24, 1], offset: ?>>
      %subview_8 = memref.subview %arg2[%arg3, 0] [8, 96] [1, 1] : memref<48x96xf64> to memref<8x96xf64, strided<[96, 1], offset: ?>>
      %c0_9 = arith.constant 0 : index
      %c96 = arith.constant 96 : index
      %c8_10 = arith.constant 8 : index
      scf.for %arg4 = %c0_9 to %c96 step %c8_10 {
        %subview_11 = memref.subview %arg1[0, %arg4] [24, 8] [1, 1] : memref<24x96xf64> to memref<24x8xf64, strided<[96, 1], offset: ?>>
        %subview_12 = memref.subview %subview_8[0, %arg4] [8, 8] [1, 1] : memref<8x96xf64, strided<[96, 1], offset: ?>> to memref<8x8xf64, strided<[96, 1], offset: ?>>
        %c0_13 = arith.constant 0 : index
        %c24 = arith.constant 24 : index
        %c1_14 = arith.constant 1 : index
        scf.for %arg5 = %c0_13 to %c24 step %c1_14 {
          %subview_15 = memref.subview %subview[0, %arg5] [8, 1] [1, 1] : memref<8x24xf64, strided<[24, 1], offset: ?>> to memref<8x1xf64, strided<[24, 1], offset: ?>>
          %subview_16 = memref.subview %subview_11[%arg5, 0] [1, 8] [1, 1] : memref<24x8xf64, strided<[96, 1], offset: ?>> to memref<1x8xf64, strided<[96, 1], offset: ?>>
          %c8_17 = arith.constant 8 : index
          %c8_18 = arith.constant 8 : index
          %c1_19 = arith.constant 1 : index
          %c0_20 = arith.constant 0 : index
          %cst_21 = arith.constant 0.000000e+00 : f64
          %0 = vector.transfer_read %subview_15[%c0_20, %c0_20], %cst_21 {permutation_map = #map} : memref<8x1xf64, strided<[24, 1], offset: ?>>, vector<8x8x1xf64>
          %cst_22 = arith.constant 0.000000e+00 : f64
          %1 = vector.transfer_read %subview_16[%c0_20, %c0_20], %cst_22 {permutation_map = #map1} : memref<1x8xf64, strided<[96, 1], offset: ?>>, vector<8x8x1xf64>
          %cst_23 = arith.constant 0.000000e+00 : f64
          %2 = vector.transfer_read %subview_12[%c0_20, %c0_20], %cst_23 : memref<8x8xf64, strided<[96, 1], offset: ?>>, vector<8x8xf64>
          %3 = arith.mulf %0, %1 : vector<8x8x1xf64>
          %4 = vector.multi_reduction <add>, %3, %2 [2] : vector<8x8x1xf64> to vector<8x8xf64>
          %c0_24 = arith.constant 0 : index
          vector.transfer_write %4, %subview_12[%c0_24, %c0_24] : vector<8x8xf64>, memref<8x8xf64, strided<[96, 1], offset: ?>>
        }
      }
    }
    return
  }
}
