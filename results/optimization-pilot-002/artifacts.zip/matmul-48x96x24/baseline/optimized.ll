; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(36864) %15, i8 0, i64 36864, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 36864
  %scevgep6 = getelementptr i8, ptr %1, i64 9216
  %scevgep7 = getelementptr i8, ptr %8, i64 18432
  %bound0 = icmp ugt ptr %scevgep6, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound08 = icmp ugt ptr %scevgep7, %15
  %bound19 = icmp ugt ptr %scevgep, %8
  %found.conflict10 = and i1 %bound08, %bound19
  %conflict.rdx = or i1 %found.conflict, %found.conflict10
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %middle.block
  %21 = phi i64 [ %246, %middle.block ], [ 0, %.preheader2.preheader ]
  %22 = mul nuw nsw i64 %21, 24
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = mul nuw nsw i64 %21, 96
  %25 = getelementptr double, ptr %15, i64 %24
  %26 = getelementptr double, ptr %23, i64 1
  %27 = getelementptr double, ptr %23, i64 2
  %28 = getelementptr double, ptr %23, i64 3
  %29 = getelementptr double, ptr %23, i64 4
  %30 = getelementptr double, ptr %23, i64 5
  %31 = getelementptr double, ptr %23, i64 6
  %32 = getelementptr double, ptr %23, i64 7
  %33 = getelementptr double, ptr %23, i64 8
  %34 = getelementptr double, ptr %23, i64 9
  %35 = getelementptr double, ptr %23, i64 10
  %36 = getelementptr double, ptr %23, i64 11
  %37 = getelementptr double, ptr %23, i64 12
  %38 = getelementptr double, ptr %23, i64 13
  %39 = getelementptr double, ptr %23, i64 14
  %40 = getelementptr double, ptr %23, i64 15
  %41 = getelementptr double, ptr %23, i64 16
  %42 = getelementptr double, ptr %23, i64 17
  %43 = getelementptr double, ptr %23, i64 18
  %44 = getelementptr double, ptr %23, i64 19
  %45 = getelementptr double, ptr %23, i64 20
  %46 = getelementptr double, ptr %23, i64 21
  %47 = getelementptr double, ptr %23, i64 22
  %48 = getelementptr double, ptr %23, i64 23
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader2
  %49 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %49, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %50, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %51 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %51, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %52, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %53 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %71 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %71, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %72, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %73 = getelementptr double, ptr %8, i64 %index
  %74 = getelementptr double, ptr %25, i64 %index
  %wide.load = load <4 x double>, ptr %74, align 8, !alias.scope !4, !noalias !6
  %wide.load11 = load <4 x double>, ptr %73, align 8, !alias.scope !8
  %75 = fmul <4 x double> %broadcast.splat, %wide.load11
  %76 = fadd <4 x double> %wide.load, %75
  store <4 x double> %76, ptr %74, align 8, !alias.scope !4, !noalias !6
  %77 = getelementptr double, ptr %73, i64 96
  %wide.load12 = load <4 x double>, ptr %77, align 8, !alias.scope !8
  %78 = fmul <4 x double> %broadcast.splat14, %wide.load12
  %79 = fadd <4 x double> %76, %78
  store <4 x double> %79, ptr %74, align 8, !alias.scope !4, !noalias !6
  %80 = getelementptr double, ptr %73, i64 192
  %wide.load15 = load <4 x double>, ptr %80, align 8, !alias.scope !8
  %81 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %82 = fadd <4 x double> %79, %81
  store <4 x double> %82, ptr %74, align 8, !alias.scope !4, !noalias !6
  %83 = getelementptr double, ptr %73, i64 288
  %wide.load18 = load <4 x double>, ptr %83, align 8, !alias.scope !8
  %84 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %85 = fadd <4 x double> %82, %84
  store <4 x double> %85, ptr %74, align 8, !alias.scope !4, !noalias !6
  %86 = getelementptr double, ptr %73, i64 384
  %wide.load21 = load <4 x double>, ptr %86, align 8, !alias.scope !8
  %87 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %88 = fadd <4 x double> %85, %87
  store <4 x double> %88, ptr %74, align 8, !alias.scope !4, !noalias !6
  %89 = getelementptr double, ptr %73, i64 480
  %wide.load24 = load <4 x double>, ptr %89, align 8, !alias.scope !8
  %90 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %91 = fadd <4 x double> %88, %90
  store <4 x double> %91, ptr %74, align 8, !alias.scope !4, !noalias !6
  %92 = getelementptr double, ptr %73, i64 576
  %wide.load27 = load <4 x double>, ptr %92, align 8, !alias.scope !8
  %93 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %94 = fadd <4 x double> %91, %93
  store <4 x double> %94, ptr %74, align 8, !alias.scope !4, !noalias !6
  %95 = getelementptr double, ptr %73, i64 672
  %wide.load30 = load <4 x double>, ptr %95, align 8, !alias.scope !8
  %96 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %97 = fadd <4 x double> %94, %96
  store <4 x double> %97, ptr %74, align 8, !alias.scope !4, !noalias !6
  %98 = getelementptr double, ptr %73, i64 768
  %wide.load33 = load <4 x double>, ptr %98, align 8, !alias.scope !8
  %99 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %100 = fadd <4 x double> %97, %99
  store <4 x double> %100, ptr %74, align 8, !alias.scope !4, !noalias !6
  %101 = getelementptr double, ptr %73, i64 864
  %wide.load36 = load <4 x double>, ptr %101, align 8, !alias.scope !8
  %102 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %103 = fadd <4 x double> %100, %102
  store <4 x double> %103, ptr %74, align 8, !alias.scope !4, !noalias !6
  %104 = getelementptr double, ptr %73, i64 960
  %wide.load39 = load <4 x double>, ptr %104, align 8, !alias.scope !8
  %105 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %106 = fadd <4 x double> %103, %105
  store <4 x double> %106, ptr %74, align 8, !alias.scope !4, !noalias !6
  %107 = getelementptr double, ptr %73, i64 1056
  %wide.load42 = load <4 x double>, ptr %107, align 8, !alias.scope !8
  %108 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %109 = fadd <4 x double> %106, %108
  store <4 x double> %109, ptr %74, align 8, !alias.scope !4, !noalias !6
  %110 = getelementptr double, ptr %73, i64 1152
  %wide.load45 = load <4 x double>, ptr %110, align 8, !alias.scope !8
  %111 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %112 = fadd <4 x double> %109, %111
  store <4 x double> %112, ptr %74, align 8, !alias.scope !4, !noalias !6
  %113 = getelementptr double, ptr %73, i64 1248
  %wide.load48 = load <4 x double>, ptr %113, align 8, !alias.scope !8
  %114 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %115 = fadd <4 x double> %112, %114
  store <4 x double> %115, ptr %74, align 8, !alias.scope !4, !noalias !6
  %116 = getelementptr double, ptr %73, i64 1344
  %wide.load51 = load <4 x double>, ptr %116, align 8, !alias.scope !8
  %117 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %118 = fadd <4 x double> %115, %117
  store <4 x double> %118, ptr %74, align 8, !alias.scope !4, !noalias !6
  %119 = getelementptr double, ptr %73, i64 1440
  %wide.load54 = load <4 x double>, ptr %119, align 8, !alias.scope !8
  %120 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %121 = fadd <4 x double> %118, %120
  store <4 x double> %121, ptr %74, align 8, !alias.scope !4, !noalias !6
  %122 = getelementptr double, ptr %73, i64 1536
  %wide.load57 = load <4 x double>, ptr %122, align 8, !alias.scope !8
  %123 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %124 = fadd <4 x double> %121, %123
  store <4 x double> %124, ptr %74, align 8, !alias.scope !4, !noalias !6
  %125 = getelementptr double, ptr %73, i64 1632
  %wide.load60 = load <4 x double>, ptr %125, align 8, !alias.scope !8
  %126 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %127 = fadd <4 x double> %124, %126
  store <4 x double> %127, ptr %74, align 8, !alias.scope !4, !noalias !6
  %128 = getelementptr double, ptr %73, i64 1728
  %wide.load63 = load <4 x double>, ptr %128, align 8, !alias.scope !8
  %129 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %130 = fadd <4 x double> %127, %129
  store <4 x double> %130, ptr %74, align 8, !alias.scope !4, !noalias !6
  %131 = getelementptr double, ptr %73, i64 1824
  %wide.load66 = load <4 x double>, ptr %131, align 8, !alias.scope !8
  %132 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %133 = fadd <4 x double> %130, %132
  store <4 x double> %133, ptr %74, align 8, !alias.scope !4, !noalias !6
  %134 = getelementptr double, ptr %73, i64 1920
  %wide.load69 = load <4 x double>, ptr %134, align 8, !alias.scope !8
  %135 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %136 = fadd <4 x double> %133, %135
  store <4 x double> %136, ptr %74, align 8, !alias.scope !4, !noalias !6
  %137 = getelementptr double, ptr %73, i64 2016
  %wide.load72 = load <4 x double>, ptr %137, align 8, !alias.scope !8
  %138 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %139 = fadd <4 x double> %136, %138
  store <4 x double> %139, ptr %74, align 8, !alias.scope !4, !noalias !6
  %140 = getelementptr double, ptr %73, i64 2112
  %wide.load75 = load <4 x double>, ptr %140, align 8, !alias.scope !8
  %141 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %142 = fadd <4 x double> %139, %141
  store <4 x double> %142, ptr %74, align 8, !alias.scope !4, !noalias !6
  %143 = getelementptr double, ptr %73, i64 2208
  %wide.load78 = load <4 x double>, ptr %143, align 8, !alias.scope !8
  %144 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %145 = fadd <4 x double> %142, %144
  store <4 x double> %145, ptr %74, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %146 = icmp eq i64 %index.next, 96
  br i1 %146, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader2, %.preheader
  %147 = phi i64 [ %245, %.preheader ], [ 0, %.preheader2 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %147
  %148 = getelementptr double, ptr %25, i64 %147
  %.promoted = load double, ptr %148, align 8
  %149 = load double, ptr %23, align 8
  %150 = load double, ptr %invariant.gep, align 8
  %151 = fmul double %149, %150
  %152 = fadd double %.promoted, %151
  store double %152, ptr %148, align 8
  %153 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 96
  %154 = load double, ptr %gep.1, align 8
  %155 = fmul double %153, %154
  %156 = fadd double %152, %155
  store double %156, ptr %148, align 8
  %157 = load double, ptr %27, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 192
  %158 = load double, ptr %gep.2, align 8
  %159 = fmul double %157, %158
  %160 = fadd double %156, %159
  store double %160, ptr %148, align 8
  %161 = load double, ptr %28, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 288
  %162 = load double, ptr %gep.3, align 8
  %163 = fmul double %161, %162
  %164 = fadd double %160, %163
  store double %164, ptr %148, align 8
  %165 = load double, ptr %29, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 384
  %166 = load double, ptr %gep.4, align 8
  %167 = fmul double %165, %166
  %168 = fadd double %164, %167
  store double %168, ptr %148, align 8
  %169 = load double, ptr %30, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 480
  %170 = load double, ptr %gep.5, align 8
  %171 = fmul double %169, %170
  %172 = fadd double %168, %171
  store double %172, ptr %148, align 8
  %173 = load double, ptr %31, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 576
  %174 = load double, ptr %gep.6, align 8
  %175 = fmul double %173, %174
  %176 = fadd double %172, %175
  store double %176, ptr %148, align 8
  %177 = load double, ptr %32, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 672
  %178 = load double, ptr %gep.7, align 8
  %179 = fmul double %177, %178
  %180 = fadd double %176, %179
  store double %180, ptr %148, align 8
  %181 = load double, ptr %33, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 768
  %182 = load double, ptr %gep.8, align 8
  %183 = fmul double %181, %182
  %184 = fadd double %180, %183
  store double %184, ptr %148, align 8
  %185 = load double, ptr %34, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 864
  %186 = load double, ptr %gep.9, align 8
  %187 = fmul double %185, %186
  %188 = fadd double %184, %187
  store double %188, ptr %148, align 8
  %189 = load double, ptr %35, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 960
  %190 = load double, ptr %gep.10, align 8
  %191 = fmul double %189, %190
  %192 = fadd double %188, %191
  store double %192, ptr %148, align 8
  %193 = load double, ptr %36, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 1056
  %194 = load double, ptr %gep.11, align 8
  %195 = fmul double %193, %194
  %196 = fadd double %192, %195
  store double %196, ptr %148, align 8
  %197 = load double, ptr %37, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 1152
  %198 = load double, ptr %gep.12, align 8
  %199 = fmul double %197, %198
  %200 = fadd double %196, %199
  store double %200, ptr %148, align 8
  %201 = load double, ptr %38, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 1248
  %202 = load double, ptr %gep.13, align 8
  %203 = fmul double %201, %202
  %204 = fadd double %200, %203
  store double %204, ptr %148, align 8
  %205 = load double, ptr %39, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 1344
  %206 = load double, ptr %gep.14, align 8
  %207 = fmul double %205, %206
  %208 = fadd double %204, %207
  store double %208, ptr %148, align 8
  %209 = load double, ptr %40, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 1440
  %210 = load double, ptr %gep.15, align 8
  %211 = fmul double %209, %210
  %212 = fadd double %208, %211
  store double %212, ptr %148, align 8
  %213 = load double, ptr %41, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1536
  %214 = load double, ptr %gep.16, align 8
  %215 = fmul double %213, %214
  %216 = fadd double %212, %215
  store double %216, ptr %148, align 8
  %217 = load double, ptr %42, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 1632
  %218 = load double, ptr %gep.17, align 8
  %219 = fmul double %217, %218
  %220 = fadd double %216, %219
  store double %220, ptr %148, align 8
  %221 = load double, ptr %43, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 1728
  %222 = load double, ptr %gep.18, align 8
  %223 = fmul double %221, %222
  %224 = fadd double %220, %223
  store double %224, ptr %148, align 8
  %225 = load double, ptr %44, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 1824
  %226 = load double, ptr %gep.19, align 8
  %227 = fmul double %225, %226
  %228 = fadd double %224, %227
  store double %228, ptr %148, align 8
  %229 = load double, ptr %45, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 1920
  %230 = load double, ptr %gep.20, align 8
  %231 = fmul double %229, %230
  %232 = fadd double %228, %231
  store double %232, ptr %148, align 8
  %233 = load double, ptr %46, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 2016
  %234 = load double, ptr %gep.21, align 8
  %235 = fmul double %233, %234
  %236 = fadd double %232, %235
  store double %236, ptr %148, align 8
  %237 = load double, ptr %47, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 2112
  %238 = load double, ptr %gep.22, align 8
  %239 = fmul double %237, %238
  %240 = fadd double %236, %239
  store double %240, ptr %148, align 8
  %241 = load double, ptr %48, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 2208
  %242 = load double, ptr %gep.23, align 8
  %243 = fmul double %241, %242
  %244 = fadd double %240, %243
  store double %244, ptr %148, align 8
  %245 = add nuw nsw i64 %147, 1
  %exitcond.not = icmp eq i64 %245, 96
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %246 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %246, 48
  br i1 %exitcond5.not, label %247, label %.preheader2

247:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
