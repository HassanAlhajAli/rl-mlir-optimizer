; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %15, i8 0, i64 64008, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 64008
  %scevgep6 = getelementptr i8, ptr %1, i64 33528
  %scevgep7 = getelementptr i8, ptr %8, i64 16632
  %bound0 = icmp ugt ptr %scevgep6, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound08 = icmp ugt ptr %scevgep7, %15
  %bound19 = icmp ugt ptr %scevgep, %8
  %found.conflict10 = and i1 %bound08, %bound19
  %conflict.rdx = or i1 %found.conflict, %found.conflict10
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %.loopexit
  %21 = phi i64 [ %327, %.loopexit ], [ 0, %.preheader2.preheader ]
  %22 = mul nuw nsw i64 %21, 33
  %23 = getelementptr double, ptr %1, i64 %22
  %24 = mul nuw nsw i64 %21, 63
  %25 = getelementptr double, ptr %15, i64 %24
  %26 = getelementptr double, ptr %23, i64 1
  %27 = getelementptr double, ptr %23, i64 2
  %28 = getelementptr double, ptr %23, i64 3
  %29 = getelementptr double, ptr %23, i64 4
  %30 = getelementptr double, ptr %23, i64 5
  %31 = getelementptr double, ptr %23, i64 6
  %32 = getelementptr double, ptr %23, i64 7
  %33 = getelementptr double, ptr %23, i64 8
  %34 = getelementptr double, ptr %23, i64 9
  %35 = getelementptr double, ptr %23, i64 10
  %36 = getelementptr double, ptr %23, i64 11
  %37 = getelementptr double, ptr %23, i64 12
  %38 = getelementptr double, ptr %23, i64 13
  %39 = getelementptr double, ptr %23, i64 14
  %40 = getelementptr double, ptr %23, i64 15
  %41 = getelementptr double, ptr %23, i64 16
  %42 = getelementptr double, ptr %23, i64 17
  %43 = getelementptr double, ptr %23, i64 18
  %44 = getelementptr double, ptr %23, i64 19
  %45 = getelementptr double, ptr %23, i64 20
  %46 = getelementptr double, ptr %23, i64 21
  %47 = getelementptr double, ptr %23, i64 22
  %48 = getelementptr double, ptr %23, i64 23
  %49 = getelementptr double, ptr %23, i64 24
  %50 = getelementptr double, ptr %23, i64 25
  %51 = getelementptr double, ptr %23, i64 26
  %52 = getelementptr double, ptr %23, i64 27
  %53 = getelementptr double, ptr %23, i64 28
  %54 = getelementptr double, ptr %23, i64 29
  %55 = getelementptr double, ptr %23, i64 30
  %56 = getelementptr double, ptr %23, i64 31
  %57 = getelementptr double, ptr %23, i64 32
  br i1 %conflict.rdx, label %.preheader.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader2
  %58 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %33, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %35, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %71 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %71, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %72, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %73, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %74 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %74, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %75 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %75, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %76 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %76, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %77 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %77, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %78 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %78, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %79 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %79, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %80 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %80, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %81 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %81, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %82 = load double, ptr %49, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %82, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  %83 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert85 = insertelement <4 x double> poison, double %83, i64 0
  %broadcast.splat86 = shufflevector <4 x double> %broadcast.splatinsert85, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = load double, ptr %51, align 8, !alias.scope !1
  %broadcast.splatinsert88 = insertelement <4 x double> poison, double %84, i64 0
  %broadcast.splat89 = shufflevector <4 x double> %broadcast.splatinsert88, <4 x double> poison, <4 x i32> zeroinitializer
  %85 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert91 = insertelement <4 x double> poison, double %85, i64 0
  %broadcast.splat92 = shufflevector <4 x double> %broadcast.splatinsert91, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = load double, ptr %53, align 8, !alias.scope !1
  %broadcast.splatinsert94 = insertelement <4 x double> poison, double %86, i64 0
  %broadcast.splat95 = shufflevector <4 x double> %broadcast.splatinsert94, <4 x double> poison, <4 x i32> zeroinitializer
  %87 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert97 = insertelement <4 x double> poison, double %87, i64 0
  %broadcast.splat98 = shufflevector <4 x double> %broadcast.splatinsert97, <4 x double> poison, <4 x i32> zeroinitializer
  %88 = load double, ptr %55, align 8, !alias.scope !1
  %broadcast.splatinsert100 = insertelement <4 x double> poison, double %88, i64 0
  %broadcast.splat101 = shufflevector <4 x double> %broadcast.splatinsert100, <4 x double> poison, <4 x i32> zeroinitializer
  %89 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert103 = insertelement <4 x double> poison, double %89, i64 0
  %broadcast.splat104 = shufflevector <4 x double> %broadcast.splatinsert103, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = load double, ptr %57, align 8, !alias.scope !1
  %broadcast.splatinsert106 = insertelement <4 x double> poison, double %90, i64 0
  %broadcast.splat107 = shufflevector <4 x double> %broadcast.splatinsert106, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %91 = getelementptr double, ptr %8, i64 %index
  %92 = getelementptr double, ptr %25, i64 %index
  %wide.load = load <4 x double>, ptr %92, align 8, !alias.scope !4, !noalias !6
  %wide.load11 = load <4 x double>, ptr %91, align 8, !alias.scope !8
  %93 = fmul <4 x double> %broadcast.splat, %wide.load11
  %94 = fadd <4 x double> %wide.load, %93
  store <4 x double> %94, ptr %92, align 8, !alias.scope !4, !noalias !6
  %95 = getelementptr double, ptr %91, i64 63
  %wide.load12 = load <4 x double>, ptr %95, align 8, !alias.scope !8
  %96 = fmul <4 x double> %broadcast.splat14, %wide.load12
  %97 = fadd <4 x double> %94, %96
  store <4 x double> %97, ptr %92, align 8, !alias.scope !4, !noalias !6
  %98 = getelementptr double, ptr %91, i64 126
  %wide.load15 = load <4 x double>, ptr %98, align 8, !alias.scope !8
  %99 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %100 = fadd <4 x double> %97, %99
  store <4 x double> %100, ptr %92, align 8, !alias.scope !4, !noalias !6
  %101 = getelementptr double, ptr %91, i64 189
  %wide.load18 = load <4 x double>, ptr %101, align 8, !alias.scope !8
  %102 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %103 = fadd <4 x double> %100, %102
  store <4 x double> %103, ptr %92, align 8, !alias.scope !4, !noalias !6
  %104 = getelementptr double, ptr %91, i64 252
  %wide.load21 = load <4 x double>, ptr %104, align 8, !alias.scope !8
  %105 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %106 = fadd <4 x double> %103, %105
  store <4 x double> %106, ptr %92, align 8, !alias.scope !4, !noalias !6
  %107 = getelementptr double, ptr %91, i64 315
  %wide.load24 = load <4 x double>, ptr %107, align 8, !alias.scope !8
  %108 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %109 = fadd <4 x double> %106, %108
  store <4 x double> %109, ptr %92, align 8, !alias.scope !4, !noalias !6
  %110 = getelementptr double, ptr %91, i64 378
  %wide.load27 = load <4 x double>, ptr %110, align 8, !alias.scope !8
  %111 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %112 = fadd <4 x double> %109, %111
  store <4 x double> %112, ptr %92, align 8, !alias.scope !4, !noalias !6
  %113 = getelementptr double, ptr %91, i64 441
  %wide.load30 = load <4 x double>, ptr %113, align 8, !alias.scope !8
  %114 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %115 = fadd <4 x double> %112, %114
  store <4 x double> %115, ptr %92, align 8, !alias.scope !4, !noalias !6
  %116 = getelementptr double, ptr %91, i64 504
  %wide.load33 = load <4 x double>, ptr %116, align 8, !alias.scope !8
  %117 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %118 = fadd <4 x double> %115, %117
  store <4 x double> %118, ptr %92, align 8, !alias.scope !4, !noalias !6
  %119 = getelementptr double, ptr %91, i64 567
  %wide.load36 = load <4 x double>, ptr %119, align 8, !alias.scope !8
  %120 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %121 = fadd <4 x double> %118, %120
  store <4 x double> %121, ptr %92, align 8, !alias.scope !4, !noalias !6
  %122 = getelementptr double, ptr %91, i64 630
  %wide.load39 = load <4 x double>, ptr %122, align 8, !alias.scope !8
  %123 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %124 = fadd <4 x double> %121, %123
  store <4 x double> %124, ptr %92, align 8, !alias.scope !4, !noalias !6
  %125 = getelementptr double, ptr %91, i64 693
  %wide.load42 = load <4 x double>, ptr %125, align 8, !alias.scope !8
  %126 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %127 = fadd <4 x double> %124, %126
  store <4 x double> %127, ptr %92, align 8, !alias.scope !4, !noalias !6
  %128 = getelementptr double, ptr %91, i64 756
  %wide.load45 = load <4 x double>, ptr %128, align 8, !alias.scope !8
  %129 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %130 = fadd <4 x double> %127, %129
  store <4 x double> %130, ptr %92, align 8, !alias.scope !4, !noalias !6
  %131 = getelementptr double, ptr %91, i64 819
  %wide.load48 = load <4 x double>, ptr %131, align 8, !alias.scope !8
  %132 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %133 = fadd <4 x double> %130, %132
  store <4 x double> %133, ptr %92, align 8, !alias.scope !4, !noalias !6
  %134 = getelementptr double, ptr %91, i64 882
  %wide.load51 = load <4 x double>, ptr %134, align 8, !alias.scope !8
  %135 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %136 = fadd <4 x double> %133, %135
  store <4 x double> %136, ptr %92, align 8, !alias.scope !4, !noalias !6
  %137 = getelementptr double, ptr %91, i64 945
  %wide.load54 = load <4 x double>, ptr %137, align 8, !alias.scope !8
  %138 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %139 = fadd <4 x double> %136, %138
  store <4 x double> %139, ptr %92, align 8, !alias.scope !4, !noalias !6
  %140 = getelementptr double, ptr %91, i64 1008
  %wide.load57 = load <4 x double>, ptr %140, align 8, !alias.scope !8
  %141 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %142 = fadd <4 x double> %139, %141
  store <4 x double> %142, ptr %92, align 8, !alias.scope !4, !noalias !6
  %143 = getelementptr double, ptr %91, i64 1071
  %wide.load60 = load <4 x double>, ptr %143, align 8, !alias.scope !8
  %144 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %145 = fadd <4 x double> %142, %144
  store <4 x double> %145, ptr %92, align 8, !alias.scope !4, !noalias !6
  %146 = getelementptr double, ptr %91, i64 1134
  %wide.load63 = load <4 x double>, ptr %146, align 8, !alias.scope !8
  %147 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %148 = fadd <4 x double> %145, %147
  store <4 x double> %148, ptr %92, align 8, !alias.scope !4, !noalias !6
  %149 = getelementptr double, ptr %91, i64 1197
  %wide.load66 = load <4 x double>, ptr %149, align 8, !alias.scope !8
  %150 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %151 = fadd <4 x double> %148, %150
  store <4 x double> %151, ptr %92, align 8, !alias.scope !4, !noalias !6
  %152 = getelementptr double, ptr %91, i64 1260
  %wide.load69 = load <4 x double>, ptr %152, align 8, !alias.scope !8
  %153 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %154 = fadd <4 x double> %151, %153
  store <4 x double> %154, ptr %92, align 8, !alias.scope !4, !noalias !6
  %155 = getelementptr double, ptr %91, i64 1323
  %wide.load72 = load <4 x double>, ptr %155, align 8, !alias.scope !8
  %156 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %157 = fadd <4 x double> %154, %156
  store <4 x double> %157, ptr %92, align 8, !alias.scope !4, !noalias !6
  %158 = getelementptr double, ptr %91, i64 1386
  %wide.load75 = load <4 x double>, ptr %158, align 8, !alias.scope !8
  %159 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %160 = fadd <4 x double> %157, %159
  store <4 x double> %160, ptr %92, align 8, !alias.scope !4, !noalias !6
  %161 = getelementptr double, ptr %91, i64 1449
  %wide.load78 = load <4 x double>, ptr %161, align 8, !alias.scope !8
  %162 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %163 = fadd <4 x double> %160, %162
  store <4 x double> %163, ptr %92, align 8, !alias.scope !4, !noalias !6
  %164 = getelementptr double, ptr %91, i64 1512
  %wide.load81 = load <4 x double>, ptr %164, align 8, !alias.scope !8
  %165 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %166 = fadd <4 x double> %163, %165
  store <4 x double> %166, ptr %92, align 8, !alias.scope !4, !noalias !6
  %167 = getelementptr double, ptr %91, i64 1575
  %wide.load84 = load <4 x double>, ptr %167, align 8, !alias.scope !8
  %168 = fmul <4 x double> %broadcast.splat86, %wide.load84
  %169 = fadd <4 x double> %166, %168
  store <4 x double> %169, ptr %92, align 8, !alias.scope !4, !noalias !6
  %170 = getelementptr double, ptr %91, i64 1638
  %wide.load87 = load <4 x double>, ptr %170, align 8, !alias.scope !8
  %171 = fmul <4 x double> %broadcast.splat89, %wide.load87
  %172 = fadd <4 x double> %169, %171
  store <4 x double> %172, ptr %92, align 8, !alias.scope !4, !noalias !6
  %173 = getelementptr double, ptr %91, i64 1701
  %wide.load90 = load <4 x double>, ptr %173, align 8, !alias.scope !8
  %174 = fmul <4 x double> %broadcast.splat92, %wide.load90
  %175 = fadd <4 x double> %172, %174
  store <4 x double> %175, ptr %92, align 8, !alias.scope !4, !noalias !6
  %176 = getelementptr double, ptr %91, i64 1764
  %wide.load93 = load <4 x double>, ptr %176, align 8, !alias.scope !8
  %177 = fmul <4 x double> %broadcast.splat95, %wide.load93
  %178 = fadd <4 x double> %175, %177
  store <4 x double> %178, ptr %92, align 8, !alias.scope !4, !noalias !6
  %179 = getelementptr double, ptr %91, i64 1827
  %wide.load96 = load <4 x double>, ptr %179, align 8, !alias.scope !8
  %180 = fmul <4 x double> %broadcast.splat98, %wide.load96
  %181 = fadd <4 x double> %178, %180
  store <4 x double> %181, ptr %92, align 8, !alias.scope !4, !noalias !6
  %182 = getelementptr double, ptr %91, i64 1890
  %wide.load99 = load <4 x double>, ptr %182, align 8, !alias.scope !8
  %183 = fmul <4 x double> %broadcast.splat101, %wide.load99
  %184 = fadd <4 x double> %181, %183
  store <4 x double> %184, ptr %92, align 8, !alias.scope !4, !noalias !6
  %185 = getelementptr double, ptr %91, i64 1953
  %wide.load102 = load <4 x double>, ptr %185, align 8, !alias.scope !8
  %186 = fmul <4 x double> %broadcast.splat104, %wide.load102
  %187 = fadd <4 x double> %184, %186
  store <4 x double> %187, ptr %92, align 8, !alias.scope !4, !noalias !6
  %188 = getelementptr double, ptr %91, i64 2016
  %wide.load105 = load <4 x double>, ptr %188, align 8, !alias.scope !8
  %189 = fmul <4 x double> %broadcast.splat107, %wide.load105
  %190 = fadd <4 x double> %187, %189
  store <4 x double> %190, ptr %92, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %191 = icmp eq i64 %index.next, 60
  br i1 %191, label %.preheader.preheader, label %vector.body, !llvm.loop !9

.preheader.preheader:                             ; preds = %vector.body, %.preheader2
  %.ph = phi i64 [ 0, %.preheader2 ], [ 60, %vector.body ]
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %192 = phi i64 [ %326, %.preheader ], [ %.ph, %.preheader.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %192
  %193 = getelementptr double, ptr %25, i64 %192
  %.promoted = load double, ptr %193, align 8
  %194 = load double, ptr %23, align 8
  %195 = load double, ptr %invariant.gep, align 8
  %196 = fmul double %194, %195
  %197 = fadd double %.promoted, %196
  store double %197, ptr %193, align 8
  %198 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 63
  %199 = load double, ptr %gep.1, align 8
  %200 = fmul double %198, %199
  %201 = fadd double %197, %200
  store double %201, ptr %193, align 8
  %202 = load double, ptr %27, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 126
  %203 = load double, ptr %gep.2, align 8
  %204 = fmul double %202, %203
  %205 = fadd double %201, %204
  store double %205, ptr %193, align 8
  %206 = load double, ptr %28, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 189
  %207 = load double, ptr %gep.3, align 8
  %208 = fmul double %206, %207
  %209 = fadd double %205, %208
  store double %209, ptr %193, align 8
  %210 = load double, ptr %29, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 252
  %211 = load double, ptr %gep.4, align 8
  %212 = fmul double %210, %211
  %213 = fadd double %209, %212
  store double %213, ptr %193, align 8
  %214 = load double, ptr %30, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 315
  %215 = load double, ptr %gep.5, align 8
  %216 = fmul double %214, %215
  %217 = fadd double %213, %216
  store double %217, ptr %193, align 8
  %218 = load double, ptr %31, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 378
  %219 = load double, ptr %gep.6, align 8
  %220 = fmul double %218, %219
  %221 = fadd double %217, %220
  store double %221, ptr %193, align 8
  %222 = load double, ptr %32, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 441
  %223 = load double, ptr %gep.7, align 8
  %224 = fmul double %222, %223
  %225 = fadd double %221, %224
  store double %225, ptr %193, align 8
  %226 = load double, ptr %33, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 504
  %227 = load double, ptr %gep.8, align 8
  %228 = fmul double %226, %227
  %229 = fadd double %225, %228
  store double %229, ptr %193, align 8
  %230 = load double, ptr %34, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 567
  %231 = load double, ptr %gep.9, align 8
  %232 = fmul double %230, %231
  %233 = fadd double %229, %232
  store double %233, ptr %193, align 8
  %234 = load double, ptr %35, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 630
  %235 = load double, ptr %gep.10, align 8
  %236 = fmul double %234, %235
  %237 = fadd double %233, %236
  store double %237, ptr %193, align 8
  %238 = load double, ptr %36, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 693
  %239 = load double, ptr %gep.11, align 8
  %240 = fmul double %238, %239
  %241 = fadd double %237, %240
  store double %241, ptr %193, align 8
  %242 = load double, ptr %37, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 756
  %243 = load double, ptr %gep.12, align 8
  %244 = fmul double %242, %243
  %245 = fadd double %241, %244
  store double %245, ptr %193, align 8
  %246 = load double, ptr %38, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 819
  %247 = load double, ptr %gep.13, align 8
  %248 = fmul double %246, %247
  %249 = fadd double %245, %248
  store double %249, ptr %193, align 8
  %250 = load double, ptr %39, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 882
  %251 = load double, ptr %gep.14, align 8
  %252 = fmul double %250, %251
  %253 = fadd double %249, %252
  store double %253, ptr %193, align 8
  %254 = load double, ptr %40, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 945
  %255 = load double, ptr %gep.15, align 8
  %256 = fmul double %254, %255
  %257 = fadd double %253, %256
  store double %257, ptr %193, align 8
  %258 = load double, ptr %41, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1008
  %259 = load double, ptr %gep.16, align 8
  %260 = fmul double %258, %259
  %261 = fadd double %257, %260
  store double %261, ptr %193, align 8
  %262 = load double, ptr %42, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 1071
  %263 = load double, ptr %gep.17, align 8
  %264 = fmul double %262, %263
  %265 = fadd double %261, %264
  store double %265, ptr %193, align 8
  %266 = load double, ptr %43, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 1134
  %267 = load double, ptr %gep.18, align 8
  %268 = fmul double %266, %267
  %269 = fadd double %265, %268
  store double %269, ptr %193, align 8
  %270 = load double, ptr %44, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 1197
  %271 = load double, ptr %gep.19, align 8
  %272 = fmul double %270, %271
  %273 = fadd double %269, %272
  store double %273, ptr %193, align 8
  %274 = load double, ptr %45, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 1260
  %275 = load double, ptr %gep.20, align 8
  %276 = fmul double %274, %275
  %277 = fadd double %273, %276
  store double %277, ptr %193, align 8
  %278 = load double, ptr %46, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 1323
  %279 = load double, ptr %gep.21, align 8
  %280 = fmul double %278, %279
  %281 = fadd double %277, %280
  store double %281, ptr %193, align 8
  %282 = load double, ptr %47, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 1386
  %283 = load double, ptr %gep.22, align 8
  %284 = fmul double %282, %283
  %285 = fadd double %281, %284
  store double %285, ptr %193, align 8
  %286 = load double, ptr %48, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 1449
  %287 = load double, ptr %gep.23, align 8
  %288 = fmul double %286, %287
  %289 = fadd double %285, %288
  store double %289, ptr %193, align 8
  %290 = load double, ptr %49, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 1512
  %291 = load double, ptr %gep.24, align 8
  %292 = fmul double %290, %291
  %293 = fadd double %289, %292
  store double %293, ptr %193, align 8
  %294 = load double, ptr %50, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 1575
  %295 = load double, ptr %gep.25, align 8
  %296 = fmul double %294, %295
  %297 = fadd double %293, %296
  store double %297, ptr %193, align 8
  %298 = load double, ptr %51, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 1638
  %299 = load double, ptr %gep.26, align 8
  %300 = fmul double %298, %299
  %301 = fadd double %297, %300
  store double %301, ptr %193, align 8
  %302 = load double, ptr %52, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 1701
  %303 = load double, ptr %gep.27, align 8
  %304 = fmul double %302, %303
  %305 = fadd double %301, %304
  store double %305, ptr %193, align 8
  %306 = load double, ptr %53, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 1764
  %307 = load double, ptr %gep.28, align 8
  %308 = fmul double %306, %307
  %309 = fadd double %305, %308
  store double %309, ptr %193, align 8
  %310 = load double, ptr %54, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 1827
  %311 = load double, ptr %gep.29, align 8
  %312 = fmul double %310, %311
  %313 = fadd double %309, %312
  store double %313, ptr %193, align 8
  %314 = load double, ptr %55, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 1890
  %315 = load double, ptr %gep.30, align 8
  %316 = fmul double %314, %315
  %317 = fadd double %313, %316
  store double %317, ptr %193, align 8
  %318 = load double, ptr %56, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 1953
  %319 = load double, ptr %gep.31, align 8
  %320 = fmul double %318, %319
  %321 = fadd double %317, %320
  store double %321, ptr %193, align 8
  %322 = load double, ptr %57, align 8
  %gep.32 = getelementptr double, ptr %invariant.gep, i64 2016
  %323 = load double, ptr %gep.32, align 8
  %324 = fmul double %322, %323
  %325 = fadd double %321, %324
  store double %325, ptr %193, align 8
  %326 = add nuw nsw i64 %192, 1
  %exitcond.not = icmp eq i64 %326, 63
  br i1 %exitcond.not, label %.loopexit, label %.preheader, !llvm.loop !12

.loopexit:                                        ; preds = %.preheader
  %327 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %327, 127
  br i1 %exitcond5.not, label %328, label %.preheader2

328:                                              ; preds = %.loopexit
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
