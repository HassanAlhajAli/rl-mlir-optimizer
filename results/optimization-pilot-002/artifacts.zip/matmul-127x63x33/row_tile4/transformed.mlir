#map = affine_map<(d0) -> (-d0 + 127, 4)>
#map1 = affine_map<(d0, d1, d2) -> (d0, d2)>
#map2 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map3 = affine_map<(d0, d1, d2) -> (d0, d1)>
module {
  func.func @kernel(%arg0: memref<127x33xf64>, %arg1: memref<33x63xf64>, %arg2: memref<127x63xf64>) attributes {llvm.emit_c_interface} {
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %c0_0 = arith.constant 0 : index
    %cst = arith.constant 0.000000e+00 : f64
    linalg.fill ins(%cst : f64) outs(%arg2 : memref<127x63xf64>)
    %c0_1 = arith.constant 0 : index
    %c127 = arith.constant 127 : index
    %c4_2 = arith.constant 4 : index
    scf.for %arg3 = %c0_1 to %c127 step %c4_2 {
      %0 = affine.min #map(%arg3)
      %1 = affine.min #map(%arg3)
      %subview = memref.subview %arg0[%arg3, 0] [%0, 33] [1, 1] : memref<127x33xf64> to memref<?x33xf64, strided<[33, 1], offset: ?>>
      %subview_3 = memref.subview %arg2[%arg3, 0] [%1, 63] [1, 1] : memref<127x63xf64> to memref<?x63xf64, strided<[63, 1], offset: ?>>
      linalg.generic {indexing_maps = [#map1, #map2, #map3], iterator_types = ["parallel", "parallel", "reduction"]} ins(%subview, %arg1 : memref<?x33xf64, strided<[33, 1], offset: ?>>, memref<33x63xf64>) outs(%subview_3 : memref<?x63xf64, strided<[63, 1], offset: ?>>) {
      ^bb0(%in: f64, %in_4: f64, %out: f64):
        %2 = arith.mulf %in, %in_4 : f64
        %3 = arith.addf %out, %2 : f64
        linalg.yield %3 : f64
      }
    }
    return
  }
}
