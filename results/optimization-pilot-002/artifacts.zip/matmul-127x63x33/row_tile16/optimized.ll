; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(64008) %15, i8 0, i64 64008, i1 false)
  %scevgep10 = getelementptr i8, ptr %8, i64 16632
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %339
  %indvar = phi i64 [ 0, %.preheader4.preheader ], [ %indvar.next, %339 ]
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %340, %339 ]
  %22 = mul nuw nsw i64 %indvar, 8064
  %scevgep = getelementptr i8, ptr %15, i64 %22
  %23 = mul nuw nsw i64 %indvar, 4224
  %scevgep8 = getelementptr i8, ptr %1, i64 %23
  %24 = icmp eq i64 %21, 112
  %25 = select i1 %24, i64 15, i64 16
  %26 = mul nuw nsw i64 %21, 33
  %27 = mul nuw nsw i64 %21, 63
  %28 = getelementptr double, ptr %1, i64 %26
  %29 = getelementptr double, ptr %15, i64 %27
  %30 = mul nuw nsw i64 %25, 504
  %scevgep7 = getelementptr i8, ptr %scevgep, i64 %30
  %31 = mul nuw nsw i64 %25, 264
  %scevgep9 = getelementptr i8, ptr %scevgep8, i64 %31
  %bound0 = icmp ult ptr %scevgep, %scevgep9
  %bound1 = icmp ult ptr %scevgep8, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %.loopexit
  %32 = phi i64 [ 0, %.preheader4 ], [ %338, %.loopexit ]
  %33 = mul nuw nsw i64 %32, 33
  %34 = getelementptr double, ptr %28, i64 %33
  %35 = mul nuw nsw i64 %32, 63
  %36 = getelementptr double, ptr %29, i64 %35
  %37 = getelementptr double, ptr %34, i64 1
  %38 = getelementptr double, ptr %34, i64 2
  %39 = getelementptr double, ptr %34, i64 3
  %40 = getelementptr double, ptr %34, i64 4
  %41 = getelementptr double, ptr %34, i64 5
  %42 = getelementptr double, ptr %34, i64 6
  %43 = getelementptr double, ptr %34, i64 7
  %44 = getelementptr double, ptr %34, i64 8
  %45 = getelementptr double, ptr %34, i64 9
  %46 = getelementptr double, ptr %34, i64 10
  %47 = getelementptr double, ptr %34, i64 11
  %48 = getelementptr double, ptr %34, i64 12
  %49 = getelementptr double, ptr %34, i64 13
  %50 = getelementptr double, ptr %34, i64 14
  %51 = getelementptr double, ptr %34, i64 15
  %52 = getelementptr double, ptr %34, i64 16
  %53 = getelementptr double, ptr %34, i64 17
  %54 = getelementptr double, ptr %34, i64 18
  %55 = getelementptr double, ptr %34, i64 19
  %56 = getelementptr double, ptr %34, i64 20
  %57 = getelementptr double, ptr %34, i64 21
  %58 = getelementptr double, ptr %34, i64 22
  %59 = getelementptr double, ptr %34, i64 23
  %60 = getelementptr double, ptr %34, i64 24
  %61 = getelementptr double, ptr %34, i64 25
  %62 = getelementptr double, ptr %34, i64 26
  %63 = getelementptr double, ptr %34, i64 27
  %64 = getelementptr double, ptr %34, i64 28
  %65 = getelementptr double, ptr %34, i64 29
  %66 = getelementptr double, ptr %34, i64 30
  %67 = getelementptr double, ptr %34, i64 31
  %68 = getelementptr double, ptr %34, i64 32
  br i1 %conflict.rdx, label %.preheader.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %69 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %37, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %71 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %71, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = load double, ptr %39, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %72, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %73, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %74 = load double, ptr %41, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %74, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %75 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %75, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %76 = load double, ptr %43, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %76, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %77 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %77, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %78 = load double, ptr %45, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %78, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %79 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %79, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %80 = load double, ptr %47, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %80, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %81 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %81, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %82 = load double, ptr %49, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %82, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %83 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %83, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %84 = load double, ptr %51, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %84, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  %85 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert61 = insertelement <4 x double> poison, double %85, i64 0
  %broadcast.splat62 = shufflevector <4 x double> %broadcast.splatinsert61, <4 x double> poison, <4 x i32> zeroinitializer
  %86 = load double, ptr %53, align 8, !alias.scope !1
  %broadcast.splatinsert64 = insertelement <4 x double> poison, double %86, i64 0
  %broadcast.splat65 = shufflevector <4 x double> %broadcast.splatinsert64, <4 x double> poison, <4 x i32> zeroinitializer
  %87 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert67 = insertelement <4 x double> poison, double %87, i64 0
  %broadcast.splat68 = shufflevector <4 x double> %broadcast.splatinsert67, <4 x double> poison, <4 x i32> zeroinitializer
  %88 = load double, ptr %55, align 8, !alias.scope !1
  %broadcast.splatinsert70 = insertelement <4 x double> poison, double %88, i64 0
  %broadcast.splat71 = shufflevector <4 x double> %broadcast.splatinsert70, <4 x double> poison, <4 x i32> zeroinitializer
  %89 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert73 = insertelement <4 x double> poison, double %89, i64 0
  %broadcast.splat74 = shufflevector <4 x double> %broadcast.splatinsert73, <4 x double> poison, <4 x i32> zeroinitializer
  %90 = load double, ptr %57, align 8, !alias.scope !1
  %broadcast.splatinsert76 = insertelement <4 x double> poison, double %90, i64 0
  %broadcast.splat77 = shufflevector <4 x double> %broadcast.splatinsert76, <4 x double> poison, <4 x i32> zeroinitializer
  %91 = load double, ptr %58, align 8, !alias.scope !1
  %broadcast.splatinsert79 = insertelement <4 x double> poison, double %91, i64 0
  %broadcast.splat80 = shufflevector <4 x double> %broadcast.splatinsert79, <4 x double> poison, <4 x i32> zeroinitializer
  %92 = load double, ptr %59, align 8, !alias.scope !1
  %broadcast.splatinsert82 = insertelement <4 x double> poison, double %92, i64 0
  %broadcast.splat83 = shufflevector <4 x double> %broadcast.splatinsert82, <4 x double> poison, <4 x i32> zeroinitializer
  %93 = load double, ptr %60, align 8, !alias.scope !1
  %broadcast.splatinsert85 = insertelement <4 x double> poison, double %93, i64 0
  %broadcast.splat86 = shufflevector <4 x double> %broadcast.splatinsert85, <4 x double> poison, <4 x i32> zeroinitializer
  %94 = load double, ptr %61, align 8, !alias.scope !1
  %broadcast.splatinsert88 = insertelement <4 x double> poison, double %94, i64 0
  %broadcast.splat89 = shufflevector <4 x double> %broadcast.splatinsert88, <4 x double> poison, <4 x i32> zeroinitializer
  %95 = load double, ptr %62, align 8, !alias.scope !1
  %broadcast.splatinsert91 = insertelement <4 x double> poison, double %95, i64 0
  %broadcast.splat92 = shufflevector <4 x double> %broadcast.splatinsert91, <4 x double> poison, <4 x i32> zeroinitializer
  %96 = load double, ptr %63, align 8, !alias.scope !1
  %broadcast.splatinsert94 = insertelement <4 x double> poison, double %96, i64 0
  %broadcast.splat95 = shufflevector <4 x double> %broadcast.splatinsert94, <4 x double> poison, <4 x i32> zeroinitializer
  %97 = load double, ptr %64, align 8, !alias.scope !1
  %broadcast.splatinsert97 = insertelement <4 x double> poison, double %97, i64 0
  %broadcast.splat98 = shufflevector <4 x double> %broadcast.splatinsert97, <4 x double> poison, <4 x i32> zeroinitializer
  %98 = load double, ptr %65, align 8, !alias.scope !1
  %broadcast.splatinsert100 = insertelement <4 x double> poison, double %98, i64 0
  %broadcast.splat101 = shufflevector <4 x double> %broadcast.splatinsert100, <4 x double> poison, <4 x i32> zeroinitializer
  %99 = load double, ptr %66, align 8, !alias.scope !1
  %broadcast.splatinsert103 = insertelement <4 x double> poison, double %99, i64 0
  %broadcast.splat104 = shufflevector <4 x double> %broadcast.splatinsert103, <4 x double> poison, <4 x i32> zeroinitializer
  %100 = load double, ptr %67, align 8, !alias.scope !1
  %broadcast.splatinsert106 = insertelement <4 x double> poison, double %100, i64 0
  %broadcast.splat107 = shufflevector <4 x double> %broadcast.splatinsert106, <4 x double> poison, <4 x i32> zeroinitializer
  %101 = load double, ptr %68, align 8, !alias.scope !1
  %broadcast.splatinsert109 = insertelement <4 x double> poison, double %101, i64 0
  %broadcast.splat110 = shufflevector <4 x double> %broadcast.splatinsert109, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %102 = getelementptr double, ptr %8, i64 %index
  %103 = getelementptr double, ptr %36, i64 %index
  %wide.load = load <4 x double>, ptr %103, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %104 = fmul <4 x double> %broadcast.splat, %wide.load14
  %105 = fadd <4 x double> %wide.load, %104
  store <4 x double> %105, ptr %103, align 8, !alias.scope !4, !noalias !6
  %106 = getelementptr double, ptr %102, i64 63
  %wide.load15 = load <4 x double>, ptr %106, align 8, !alias.scope !8
  %107 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %108 = fadd <4 x double> %105, %107
  store <4 x double> %108, ptr %103, align 8, !alias.scope !4, !noalias !6
  %109 = getelementptr double, ptr %102, i64 126
  %wide.load18 = load <4 x double>, ptr %109, align 8, !alias.scope !8
  %110 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %111 = fadd <4 x double> %108, %110
  store <4 x double> %111, ptr %103, align 8, !alias.scope !4, !noalias !6
  %112 = getelementptr double, ptr %102, i64 189
  %wide.load21 = load <4 x double>, ptr %112, align 8, !alias.scope !8
  %113 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %114 = fadd <4 x double> %111, %113
  store <4 x double> %114, ptr %103, align 8, !alias.scope !4, !noalias !6
  %115 = getelementptr double, ptr %102, i64 252
  %wide.load24 = load <4 x double>, ptr %115, align 8, !alias.scope !8
  %116 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %117 = fadd <4 x double> %114, %116
  store <4 x double> %117, ptr %103, align 8, !alias.scope !4, !noalias !6
  %118 = getelementptr double, ptr %102, i64 315
  %wide.load27 = load <4 x double>, ptr %118, align 8, !alias.scope !8
  %119 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %120 = fadd <4 x double> %117, %119
  store <4 x double> %120, ptr %103, align 8, !alias.scope !4, !noalias !6
  %121 = getelementptr double, ptr %102, i64 378
  %wide.load30 = load <4 x double>, ptr %121, align 8, !alias.scope !8
  %122 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %123 = fadd <4 x double> %120, %122
  store <4 x double> %123, ptr %103, align 8, !alias.scope !4, !noalias !6
  %124 = getelementptr double, ptr %102, i64 441
  %wide.load33 = load <4 x double>, ptr %124, align 8, !alias.scope !8
  %125 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %126 = fadd <4 x double> %123, %125
  store <4 x double> %126, ptr %103, align 8, !alias.scope !4, !noalias !6
  %127 = getelementptr double, ptr %102, i64 504
  %wide.load36 = load <4 x double>, ptr %127, align 8, !alias.scope !8
  %128 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %129 = fadd <4 x double> %126, %128
  store <4 x double> %129, ptr %103, align 8, !alias.scope !4, !noalias !6
  %130 = getelementptr double, ptr %102, i64 567
  %wide.load39 = load <4 x double>, ptr %130, align 8, !alias.scope !8
  %131 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %132 = fadd <4 x double> %129, %131
  store <4 x double> %132, ptr %103, align 8, !alias.scope !4, !noalias !6
  %133 = getelementptr double, ptr %102, i64 630
  %wide.load42 = load <4 x double>, ptr %133, align 8, !alias.scope !8
  %134 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %135 = fadd <4 x double> %132, %134
  store <4 x double> %135, ptr %103, align 8, !alias.scope !4, !noalias !6
  %136 = getelementptr double, ptr %102, i64 693
  %wide.load45 = load <4 x double>, ptr %136, align 8, !alias.scope !8
  %137 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %138 = fadd <4 x double> %135, %137
  store <4 x double> %138, ptr %103, align 8, !alias.scope !4, !noalias !6
  %139 = getelementptr double, ptr %102, i64 756
  %wide.load48 = load <4 x double>, ptr %139, align 8, !alias.scope !8
  %140 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %141 = fadd <4 x double> %138, %140
  store <4 x double> %141, ptr %103, align 8, !alias.scope !4, !noalias !6
  %142 = getelementptr double, ptr %102, i64 819
  %wide.load51 = load <4 x double>, ptr %142, align 8, !alias.scope !8
  %143 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %144 = fadd <4 x double> %141, %143
  store <4 x double> %144, ptr %103, align 8, !alias.scope !4, !noalias !6
  %145 = getelementptr double, ptr %102, i64 882
  %wide.load54 = load <4 x double>, ptr %145, align 8, !alias.scope !8
  %146 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %147 = fadd <4 x double> %144, %146
  store <4 x double> %147, ptr %103, align 8, !alias.scope !4, !noalias !6
  %148 = getelementptr double, ptr %102, i64 945
  %wide.load57 = load <4 x double>, ptr %148, align 8, !alias.scope !8
  %149 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %150 = fadd <4 x double> %147, %149
  store <4 x double> %150, ptr %103, align 8, !alias.scope !4, !noalias !6
  %151 = getelementptr double, ptr %102, i64 1008
  %wide.load60 = load <4 x double>, ptr %151, align 8, !alias.scope !8
  %152 = fmul <4 x double> %broadcast.splat62, %wide.load60
  %153 = fadd <4 x double> %150, %152
  store <4 x double> %153, ptr %103, align 8, !alias.scope !4, !noalias !6
  %154 = getelementptr double, ptr %102, i64 1071
  %wide.load63 = load <4 x double>, ptr %154, align 8, !alias.scope !8
  %155 = fmul <4 x double> %broadcast.splat65, %wide.load63
  %156 = fadd <4 x double> %153, %155
  store <4 x double> %156, ptr %103, align 8, !alias.scope !4, !noalias !6
  %157 = getelementptr double, ptr %102, i64 1134
  %wide.load66 = load <4 x double>, ptr %157, align 8, !alias.scope !8
  %158 = fmul <4 x double> %broadcast.splat68, %wide.load66
  %159 = fadd <4 x double> %156, %158
  store <4 x double> %159, ptr %103, align 8, !alias.scope !4, !noalias !6
  %160 = getelementptr double, ptr %102, i64 1197
  %wide.load69 = load <4 x double>, ptr %160, align 8, !alias.scope !8
  %161 = fmul <4 x double> %broadcast.splat71, %wide.load69
  %162 = fadd <4 x double> %159, %161
  store <4 x double> %162, ptr %103, align 8, !alias.scope !4, !noalias !6
  %163 = getelementptr double, ptr %102, i64 1260
  %wide.load72 = load <4 x double>, ptr %163, align 8, !alias.scope !8
  %164 = fmul <4 x double> %broadcast.splat74, %wide.load72
  %165 = fadd <4 x double> %162, %164
  store <4 x double> %165, ptr %103, align 8, !alias.scope !4, !noalias !6
  %166 = getelementptr double, ptr %102, i64 1323
  %wide.load75 = load <4 x double>, ptr %166, align 8, !alias.scope !8
  %167 = fmul <4 x double> %broadcast.splat77, %wide.load75
  %168 = fadd <4 x double> %165, %167
  store <4 x double> %168, ptr %103, align 8, !alias.scope !4, !noalias !6
  %169 = getelementptr double, ptr %102, i64 1386
  %wide.load78 = load <4 x double>, ptr %169, align 8, !alias.scope !8
  %170 = fmul <4 x double> %broadcast.splat80, %wide.load78
  %171 = fadd <4 x double> %168, %170
  store <4 x double> %171, ptr %103, align 8, !alias.scope !4, !noalias !6
  %172 = getelementptr double, ptr %102, i64 1449
  %wide.load81 = load <4 x double>, ptr %172, align 8, !alias.scope !8
  %173 = fmul <4 x double> %broadcast.splat83, %wide.load81
  %174 = fadd <4 x double> %171, %173
  store <4 x double> %174, ptr %103, align 8, !alias.scope !4, !noalias !6
  %175 = getelementptr double, ptr %102, i64 1512
  %wide.load84 = load <4 x double>, ptr %175, align 8, !alias.scope !8
  %176 = fmul <4 x double> %broadcast.splat86, %wide.load84
  %177 = fadd <4 x double> %174, %176
  store <4 x double> %177, ptr %103, align 8, !alias.scope !4, !noalias !6
  %178 = getelementptr double, ptr %102, i64 1575
  %wide.load87 = load <4 x double>, ptr %178, align 8, !alias.scope !8
  %179 = fmul <4 x double> %broadcast.splat89, %wide.load87
  %180 = fadd <4 x double> %177, %179
  store <4 x double> %180, ptr %103, align 8, !alias.scope !4, !noalias !6
  %181 = getelementptr double, ptr %102, i64 1638
  %wide.load90 = load <4 x double>, ptr %181, align 8, !alias.scope !8
  %182 = fmul <4 x double> %broadcast.splat92, %wide.load90
  %183 = fadd <4 x double> %180, %182
  store <4 x double> %183, ptr %103, align 8, !alias.scope !4, !noalias !6
  %184 = getelementptr double, ptr %102, i64 1701
  %wide.load93 = load <4 x double>, ptr %184, align 8, !alias.scope !8
  %185 = fmul <4 x double> %broadcast.splat95, %wide.load93
  %186 = fadd <4 x double> %183, %185
  store <4 x double> %186, ptr %103, align 8, !alias.scope !4, !noalias !6
  %187 = getelementptr double, ptr %102, i64 1764
  %wide.load96 = load <4 x double>, ptr %187, align 8, !alias.scope !8
  %188 = fmul <4 x double> %broadcast.splat98, %wide.load96
  %189 = fadd <4 x double> %186, %188
  store <4 x double> %189, ptr %103, align 8, !alias.scope !4, !noalias !6
  %190 = getelementptr double, ptr %102, i64 1827
  %wide.load99 = load <4 x double>, ptr %190, align 8, !alias.scope !8
  %191 = fmul <4 x double> %broadcast.splat101, %wide.load99
  %192 = fadd <4 x double> %189, %191
  store <4 x double> %192, ptr %103, align 8, !alias.scope !4, !noalias !6
  %193 = getelementptr double, ptr %102, i64 1890
  %wide.load102 = load <4 x double>, ptr %193, align 8, !alias.scope !8
  %194 = fmul <4 x double> %broadcast.splat104, %wide.load102
  %195 = fadd <4 x double> %192, %194
  store <4 x double> %195, ptr %103, align 8, !alias.scope !4, !noalias !6
  %196 = getelementptr double, ptr %102, i64 1953
  %wide.load105 = load <4 x double>, ptr %196, align 8, !alias.scope !8
  %197 = fmul <4 x double> %broadcast.splat107, %wide.load105
  %198 = fadd <4 x double> %195, %197
  store <4 x double> %198, ptr %103, align 8, !alias.scope !4, !noalias !6
  %199 = getelementptr double, ptr %102, i64 2016
  %wide.load108 = load <4 x double>, ptr %199, align 8, !alias.scope !8
  %200 = fmul <4 x double> %broadcast.splat110, %wide.load108
  %201 = fadd <4 x double> %198, %200
  store <4 x double> %201, ptr %103, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %202 = icmp eq i64 %index.next, 60
  br i1 %202, label %.preheader.preheader, label %vector.body, !llvm.loop !9

.preheader.preheader:                             ; preds = %vector.body, %.preheader3
  %.ph = phi i64 [ 0, %.preheader3 ], [ 60, %vector.body ]
  br label %.preheader

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %203 = phi i64 [ %337, %.preheader ], [ %.ph, %.preheader.preheader ]
  %invariant.gep = getelementptr double, ptr %8, i64 %203
  %204 = getelementptr double, ptr %36, i64 %203
  %.promoted = load double, ptr %204, align 8
  %205 = load double, ptr %34, align 8
  %206 = load double, ptr %invariant.gep, align 8
  %207 = fmul double %205, %206
  %208 = fadd double %.promoted, %207
  store double %208, ptr %204, align 8
  %209 = load double, ptr %37, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 63
  %210 = load double, ptr %gep.1, align 8
  %211 = fmul double %209, %210
  %212 = fadd double %208, %211
  store double %212, ptr %204, align 8
  %213 = load double, ptr %38, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 126
  %214 = load double, ptr %gep.2, align 8
  %215 = fmul double %213, %214
  %216 = fadd double %212, %215
  store double %216, ptr %204, align 8
  %217 = load double, ptr %39, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 189
  %218 = load double, ptr %gep.3, align 8
  %219 = fmul double %217, %218
  %220 = fadd double %216, %219
  store double %220, ptr %204, align 8
  %221 = load double, ptr %40, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 252
  %222 = load double, ptr %gep.4, align 8
  %223 = fmul double %221, %222
  %224 = fadd double %220, %223
  store double %224, ptr %204, align 8
  %225 = load double, ptr %41, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 315
  %226 = load double, ptr %gep.5, align 8
  %227 = fmul double %225, %226
  %228 = fadd double %224, %227
  store double %228, ptr %204, align 8
  %229 = load double, ptr %42, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 378
  %230 = load double, ptr %gep.6, align 8
  %231 = fmul double %229, %230
  %232 = fadd double %228, %231
  store double %232, ptr %204, align 8
  %233 = load double, ptr %43, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 441
  %234 = load double, ptr %gep.7, align 8
  %235 = fmul double %233, %234
  %236 = fadd double %232, %235
  store double %236, ptr %204, align 8
  %237 = load double, ptr %44, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 504
  %238 = load double, ptr %gep.8, align 8
  %239 = fmul double %237, %238
  %240 = fadd double %236, %239
  store double %240, ptr %204, align 8
  %241 = load double, ptr %45, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 567
  %242 = load double, ptr %gep.9, align 8
  %243 = fmul double %241, %242
  %244 = fadd double %240, %243
  store double %244, ptr %204, align 8
  %245 = load double, ptr %46, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 630
  %246 = load double, ptr %gep.10, align 8
  %247 = fmul double %245, %246
  %248 = fadd double %244, %247
  store double %248, ptr %204, align 8
  %249 = load double, ptr %47, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 693
  %250 = load double, ptr %gep.11, align 8
  %251 = fmul double %249, %250
  %252 = fadd double %248, %251
  store double %252, ptr %204, align 8
  %253 = load double, ptr %48, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 756
  %254 = load double, ptr %gep.12, align 8
  %255 = fmul double %253, %254
  %256 = fadd double %252, %255
  store double %256, ptr %204, align 8
  %257 = load double, ptr %49, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 819
  %258 = load double, ptr %gep.13, align 8
  %259 = fmul double %257, %258
  %260 = fadd double %256, %259
  store double %260, ptr %204, align 8
  %261 = load double, ptr %50, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 882
  %262 = load double, ptr %gep.14, align 8
  %263 = fmul double %261, %262
  %264 = fadd double %260, %263
  store double %264, ptr %204, align 8
  %265 = load double, ptr %51, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 945
  %266 = load double, ptr %gep.15, align 8
  %267 = fmul double %265, %266
  %268 = fadd double %264, %267
  store double %268, ptr %204, align 8
  %269 = load double, ptr %52, align 8
  %gep.16 = getelementptr double, ptr %invariant.gep, i64 1008
  %270 = load double, ptr %gep.16, align 8
  %271 = fmul double %269, %270
  %272 = fadd double %268, %271
  store double %272, ptr %204, align 8
  %273 = load double, ptr %53, align 8
  %gep.17 = getelementptr double, ptr %invariant.gep, i64 1071
  %274 = load double, ptr %gep.17, align 8
  %275 = fmul double %273, %274
  %276 = fadd double %272, %275
  store double %276, ptr %204, align 8
  %277 = load double, ptr %54, align 8
  %gep.18 = getelementptr double, ptr %invariant.gep, i64 1134
  %278 = load double, ptr %gep.18, align 8
  %279 = fmul double %277, %278
  %280 = fadd double %276, %279
  store double %280, ptr %204, align 8
  %281 = load double, ptr %55, align 8
  %gep.19 = getelementptr double, ptr %invariant.gep, i64 1197
  %282 = load double, ptr %gep.19, align 8
  %283 = fmul double %281, %282
  %284 = fadd double %280, %283
  store double %284, ptr %204, align 8
  %285 = load double, ptr %56, align 8
  %gep.20 = getelementptr double, ptr %invariant.gep, i64 1260
  %286 = load double, ptr %gep.20, align 8
  %287 = fmul double %285, %286
  %288 = fadd double %284, %287
  store double %288, ptr %204, align 8
  %289 = load double, ptr %57, align 8
  %gep.21 = getelementptr double, ptr %invariant.gep, i64 1323
  %290 = load double, ptr %gep.21, align 8
  %291 = fmul double %289, %290
  %292 = fadd double %288, %291
  store double %292, ptr %204, align 8
  %293 = load double, ptr %58, align 8
  %gep.22 = getelementptr double, ptr %invariant.gep, i64 1386
  %294 = load double, ptr %gep.22, align 8
  %295 = fmul double %293, %294
  %296 = fadd double %292, %295
  store double %296, ptr %204, align 8
  %297 = load double, ptr %59, align 8
  %gep.23 = getelementptr double, ptr %invariant.gep, i64 1449
  %298 = load double, ptr %gep.23, align 8
  %299 = fmul double %297, %298
  %300 = fadd double %296, %299
  store double %300, ptr %204, align 8
  %301 = load double, ptr %60, align 8
  %gep.24 = getelementptr double, ptr %invariant.gep, i64 1512
  %302 = load double, ptr %gep.24, align 8
  %303 = fmul double %301, %302
  %304 = fadd double %300, %303
  store double %304, ptr %204, align 8
  %305 = load double, ptr %61, align 8
  %gep.25 = getelementptr double, ptr %invariant.gep, i64 1575
  %306 = load double, ptr %gep.25, align 8
  %307 = fmul double %305, %306
  %308 = fadd double %304, %307
  store double %308, ptr %204, align 8
  %309 = load double, ptr %62, align 8
  %gep.26 = getelementptr double, ptr %invariant.gep, i64 1638
  %310 = load double, ptr %gep.26, align 8
  %311 = fmul double %309, %310
  %312 = fadd double %308, %311
  store double %312, ptr %204, align 8
  %313 = load double, ptr %63, align 8
  %gep.27 = getelementptr double, ptr %invariant.gep, i64 1701
  %314 = load double, ptr %gep.27, align 8
  %315 = fmul double %313, %314
  %316 = fadd double %312, %315
  store double %316, ptr %204, align 8
  %317 = load double, ptr %64, align 8
  %gep.28 = getelementptr double, ptr %invariant.gep, i64 1764
  %318 = load double, ptr %gep.28, align 8
  %319 = fmul double %317, %318
  %320 = fadd double %316, %319
  store double %320, ptr %204, align 8
  %321 = load double, ptr %65, align 8
  %gep.29 = getelementptr double, ptr %invariant.gep, i64 1827
  %322 = load double, ptr %gep.29, align 8
  %323 = fmul double %321, %322
  %324 = fadd double %320, %323
  store double %324, ptr %204, align 8
  %325 = load double, ptr %66, align 8
  %gep.30 = getelementptr double, ptr %invariant.gep, i64 1890
  %326 = load double, ptr %gep.30, align 8
  %327 = fmul double %325, %326
  %328 = fadd double %324, %327
  store double %328, ptr %204, align 8
  %329 = load double, ptr %67, align 8
  %gep.31 = getelementptr double, ptr %invariant.gep, i64 1953
  %330 = load double, ptr %gep.31, align 8
  %331 = fmul double %329, %330
  %332 = fadd double %328, %331
  store double %332, ptr %204, align 8
  %333 = load double, ptr %68, align 8
  %gep.32 = getelementptr double, ptr %invariant.gep, i64 2016
  %334 = load double, ptr %gep.32, align 8
  %335 = fmul double %333, %334
  %336 = fadd double %332, %335
  store double %336, ptr %204, align 8
  %337 = add nuw nsw i64 %203, 1
  %exitcond.not = icmp eq i64 %337, 63
  br i1 %exitcond.not, label %.loopexit, label %.preheader, !llvm.loop !12

.loopexit:                                        ; preds = %.preheader
  %338 = add nuw nsw i64 %32, 1
  %exitcond6.not = icmp eq i64 %338, %25
  br i1 %exitcond6.not, label %339, label %.preheader3

339:                                              ; preds = %.loopexit
  %340 = add nuw nsw i64 %21, 16
  %341 = icmp ult i64 %21, 111
  %indvar.next = add i64 %indvar, 1
  br i1 %341, label %.preheader4, label %342

342:                                              ; preds = %339
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
