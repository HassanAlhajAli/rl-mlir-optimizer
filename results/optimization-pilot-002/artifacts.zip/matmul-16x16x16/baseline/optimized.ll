; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader2.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %15, i8 0, i64 2048, i1 false)
  %scevgep = getelementptr i8, ptr %15, i64 2048
  %scevgep6 = getelementptr i8, ptr %1, i64 2048
  %scevgep7 = getelementptr i8, ptr %8, i64 2048
  %bound0 = icmp ugt ptr %scevgep6, %15
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound08 = icmp ugt ptr %scevgep7, %15
  %bound19 = icmp ugt ptr %scevgep, %8
  %found.conflict10 = and i1 %bound08, %bound19
  %conflict.rdx = or i1 %found.conflict, %found.conflict10
  br label %.preheader2

.preheader2:                                      ; preds = %.preheader2.preheader, %middle.block
  %21 = phi i64 [ %188, %middle.block ], [ 0, %.preheader2.preheader ]
  %22 = shl i64 %21, 4
  %23 = getelementptr double, ptr %15, i64 %22
  %24 = getelementptr double, ptr %1, i64 %22
  %25 = or disjoint i64 %22, 1
  %26 = getelementptr double, ptr %1, i64 %25
  %27 = or disjoint i64 %22, 2
  %28 = getelementptr double, ptr %1, i64 %27
  %29 = or disjoint i64 %22, 3
  %30 = getelementptr double, ptr %1, i64 %29
  %31 = or disjoint i64 %22, 4
  %32 = getelementptr double, ptr %1, i64 %31
  %33 = or disjoint i64 %22, 5
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = or disjoint i64 %22, 6
  %36 = getelementptr double, ptr %1, i64 %35
  %37 = or disjoint i64 %22, 7
  %38 = getelementptr double, ptr %1, i64 %37
  %39 = or disjoint i64 %22, 8
  %40 = getelementptr double, ptr %1, i64 %39
  %41 = or disjoint i64 %22, 9
  %42 = getelementptr double, ptr %1, i64 %41
  %43 = or disjoint i64 %22, 10
  %44 = getelementptr double, ptr %1, i64 %43
  %45 = or disjoint i64 %22, 11
  %46 = getelementptr double, ptr %1, i64 %45
  %47 = or disjoint i64 %22, 12
  %48 = getelementptr double, ptr %1, i64 %47
  %49 = or disjoint i64 %22, 13
  %50 = getelementptr double, ptr %1, i64 %49
  %51 = or disjoint i64 %22, 14
  %52 = getelementptr double, ptr %1, i64 %51
  %53 = or disjoint i64 %22, 15
  %54 = getelementptr double, ptr %1, i64 %53
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader2
  %55 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %71 = getelementptr double, ptr %8, i64 %index
  %72 = getelementptr double, ptr %23, i64 %index
  %wide.load = load <4 x double>, ptr %72, align 8, !alias.scope !4, !noalias !6
  %wide.load11 = load <4 x double>, ptr %71, align 8, !alias.scope !8
  %73 = fmul <4 x double> %broadcast.splat, %wide.load11
  %74 = fadd <4 x double> %wide.load, %73
  store <4 x double> %74, ptr %72, align 8, !alias.scope !4, !noalias !6
  %75 = getelementptr double, ptr %71, i64 16
  %wide.load12 = load <4 x double>, ptr %75, align 8, !alias.scope !8
  %76 = fmul <4 x double> %broadcast.splat14, %wide.load12
  %77 = fadd <4 x double> %74, %76
  store <4 x double> %77, ptr %72, align 8, !alias.scope !4, !noalias !6
  %78 = getelementptr double, ptr %71, i64 32
  %wide.load15 = load <4 x double>, ptr %78, align 8, !alias.scope !8
  %79 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %80 = fadd <4 x double> %77, %79
  store <4 x double> %80, ptr %72, align 8, !alias.scope !4, !noalias !6
  %81 = getelementptr double, ptr %71, i64 48
  %wide.load18 = load <4 x double>, ptr %81, align 8, !alias.scope !8
  %82 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %83 = fadd <4 x double> %80, %82
  store <4 x double> %83, ptr %72, align 8, !alias.scope !4, !noalias !6
  %84 = getelementptr double, ptr %71, i64 64
  %wide.load21 = load <4 x double>, ptr %84, align 8, !alias.scope !8
  %85 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %86 = fadd <4 x double> %83, %85
  store <4 x double> %86, ptr %72, align 8, !alias.scope !4, !noalias !6
  %87 = getelementptr double, ptr %71, i64 80
  %wide.load24 = load <4 x double>, ptr %87, align 8, !alias.scope !8
  %88 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %89 = fadd <4 x double> %86, %88
  store <4 x double> %89, ptr %72, align 8, !alias.scope !4, !noalias !6
  %90 = getelementptr double, ptr %71, i64 96
  %wide.load27 = load <4 x double>, ptr %90, align 8, !alias.scope !8
  %91 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %92 = fadd <4 x double> %89, %91
  store <4 x double> %92, ptr %72, align 8, !alias.scope !4, !noalias !6
  %93 = getelementptr double, ptr %71, i64 112
  %wide.load30 = load <4 x double>, ptr %93, align 8, !alias.scope !8
  %94 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %95 = fadd <4 x double> %92, %94
  store <4 x double> %95, ptr %72, align 8, !alias.scope !4, !noalias !6
  %96 = getelementptr double, ptr %71, i64 128
  %wide.load33 = load <4 x double>, ptr %96, align 8, !alias.scope !8
  %97 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %98 = fadd <4 x double> %95, %97
  store <4 x double> %98, ptr %72, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %71, i64 144
  %wide.load36 = load <4 x double>, ptr %99, align 8, !alias.scope !8
  %100 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %101 = fadd <4 x double> %98, %100
  store <4 x double> %101, ptr %72, align 8, !alias.scope !4, !noalias !6
  %102 = getelementptr double, ptr %71, i64 160
  %wide.load39 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %103 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %104 = fadd <4 x double> %101, %103
  store <4 x double> %104, ptr %72, align 8, !alias.scope !4, !noalias !6
  %105 = getelementptr double, ptr %71, i64 176
  %wide.load42 = load <4 x double>, ptr %105, align 8, !alias.scope !8
  %106 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %107 = fadd <4 x double> %104, %106
  store <4 x double> %107, ptr %72, align 8, !alias.scope !4, !noalias !6
  %108 = getelementptr double, ptr %71, i64 192
  %wide.load45 = load <4 x double>, ptr %108, align 8, !alias.scope !8
  %109 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %110 = fadd <4 x double> %107, %109
  store <4 x double> %110, ptr %72, align 8, !alias.scope !4, !noalias !6
  %111 = getelementptr double, ptr %71, i64 208
  %wide.load48 = load <4 x double>, ptr %111, align 8, !alias.scope !8
  %112 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %113 = fadd <4 x double> %110, %112
  store <4 x double> %113, ptr %72, align 8, !alias.scope !4, !noalias !6
  %114 = getelementptr double, ptr %71, i64 224
  %wide.load51 = load <4 x double>, ptr %114, align 8, !alias.scope !8
  %115 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %116 = fadd <4 x double> %113, %115
  store <4 x double> %116, ptr %72, align 8, !alias.scope !4, !noalias !6
  %117 = getelementptr double, ptr %71, i64 240
  %wide.load54 = load <4 x double>, ptr %117, align 8, !alias.scope !8
  %118 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %119 = fadd <4 x double> %116, %118
  store <4 x double> %119, ptr %72, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %120 = icmp eq i64 %index.next, 16
  br i1 %120, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader2, %.preheader
  %121 = phi i64 [ %187, %.preheader ], [ 0, %.preheader2 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %121
  %122 = getelementptr double, ptr %23, i64 %121
  %.promoted = load double, ptr %122, align 8
  %123 = load double, ptr %24, align 8
  %124 = load double, ptr %invariant.gep, align 8
  %125 = fmul double %123, %124
  %126 = fadd double %.promoted, %125
  store double %126, ptr %122, align 8
  %127 = load double, ptr %26, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 16
  %128 = load double, ptr %gep.1, align 8
  %129 = fmul double %127, %128
  %130 = fadd double %126, %129
  store double %130, ptr %122, align 8
  %131 = load double, ptr %28, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 32
  %132 = load double, ptr %gep.2, align 8
  %133 = fmul double %131, %132
  %134 = fadd double %130, %133
  store double %134, ptr %122, align 8
  %135 = load double, ptr %30, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 48
  %136 = load double, ptr %gep.3, align 8
  %137 = fmul double %135, %136
  %138 = fadd double %134, %137
  store double %138, ptr %122, align 8
  %139 = load double, ptr %32, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 64
  %140 = load double, ptr %gep.4, align 8
  %141 = fmul double %139, %140
  %142 = fadd double %138, %141
  store double %142, ptr %122, align 8
  %143 = load double, ptr %34, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 80
  %144 = load double, ptr %gep.5, align 8
  %145 = fmul double %143, %144
  %146 = fadd double %142, %145
  store double %146, ptr %122, align 8
  %147 = load double, ptr %36, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 96
  %148 = load double, ptr %gep.6, align 8
  %149 = fmul double %147, %148
  %150 = fadd double %146, %149
  store double %150, ptr %122, align 8
  %151 = load double, ptr %38, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 112
  %152 = load double, ptr %gep.7, align 8
  %153 = fmul double %151, %152
  %154 = fadd double %150, %153
  store double %154, ptr %122, align 8
  %155 = load double, ptr %40, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 128
  %156 = load double, ptr %gep.8, align 8
  %157 = fmul double %155, %156
  %158 = fadd double %154, %157
  store double %158, ptr %122, align 8
  %159 = load double, ptr %42, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 144
  %160 = load double, ptr %gep.9, align 8
  %161 = fmul double %159, %160
  %162 = fadd double %158, %161
  store double %162, ptr %122, align 8
  %163 = load double, ptr %44, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 160
  %164 = load double, ptr %gep.10, align 8
  %165 = fmul double %163, %164
  %166 = fadd double %162, %165
  store double %166, ptr %122, align 8
  %167 = load double, ptr %46, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 176
  %168 = load double, ptr %gep.11, align 8
  %169 = fmul double %167, %168
  %170 = fadd double %166, %169
  store double %170, ptr %122, align 8
  %171 = load double, ptr %48, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 192
  %172 = load double, ptr %gep.12, align 8
  %173 = fmul double %171, %172
  %174 = fadd double %170, %173
  store double %174, ptr %122, align 8
  %175 = load double, ptr %50, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 208
  %176 = load double, ptr %gep.13, align 8
  %177 = fmul double %175, %176
  %178 = fadd double %174, %177
  store double %178, ptr %122, align 8
  %179 = load double, ptr %52, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 224
  %180 = load double, ptr %gep.14, align 8
  %181 = fmul double %179, %180
  %182 = fadd double %178, %181
  store double %182, ptr %122, align 8
  %183 = load double, ptr %54, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 240
  %184 = load double, ptr %gep.15, align 8
  %185 = fmul double %183, %184
  %186 = fadd double %182, %185
  store double %186, ptr %122, align 8
  %187 = add nuw nsw i64 %121, 1
  %exitcond.not = icmp eq i64 %187, 16
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %188 = add nuw nsw i64 %21, 1
  %exitcond5.not = icmp eq i64 %188, 16
  br i1 %exitcond5.not, label %189, label %.preheader2

189:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
