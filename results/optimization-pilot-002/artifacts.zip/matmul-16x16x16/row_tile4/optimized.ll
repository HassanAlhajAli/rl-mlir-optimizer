; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, i64 %12, i64 %13, ptr nocapture readnone %14, ptr nocapture %15, i64 %16, i64 %17, i64 %18, i64 %19, i64 %20) local_unnamed_addr #0 {
.preheader4.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(2048) %15, i8 0, i64 2048, i1 false)
  %scevgep10 = getelementptr i8, ptr %8, i64 2048
  br label %.preheader4

.preheader4:                                      ; preds = %.preheader4.preheader, %195
  %indvar = phi i64 [ 0, %.preheader4.preheader ], [ %indvar.next, %195 ]
  %21 = phi i64 [ 0, %.preheader4.preheader ], [ %196, %195 ]
  %22 = shl nuw nsw i64 %indvar, 9
  %scevgep = getelementptr i8, ptr %15, i64 %22
  %23 = add nuw i64 %22, 512
  %scevgep7 = getelementptr i8, ptr %15, i64 %23
  %scevgep8 = getelementptr i8, ptr %1, i64 %22
  %scevgep9 = getelementptr i8, ptr %1, i64 %23
  %24 = shl nuw nsw i64 %21, 4
  %25 = getelementptr double, ptr %1, i64 %24
  %26 = getelementptr double, ptr %15, i64 %24
  %bound0 = icmp ult ptr %scevgep, %scevgep9
  %bound1 = icmp ult ptr %scevgep8, %scevgep7
  %found.conflict = and i1 %bound0, %bound1
  %bound011 = icmp ult ptr %scevgep, %scevgep10
  %bound112 = icmp ugt ptr %scevgep7, %8
  %found.conflict13 = and i1 %bound011, %bound112
  %conflict.rdx = or i1 %found.conflict, %found.conflict13
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader4, %middle.block
  %27 = phi i64 [ 0, %.preheader4 ], [ %194, %middle.block ]
  %28 = shl i64 %27, 4
  %29 = getelementptr double, ptr %26, i64 %28
  %30 = getelementptr double, ptr %25, i64 %28
  %31 = or disjoint i64 %28, 1
  %32 = getelementptr double, ptr %25, i64 %31
  %33 = or disjoint i64 %28, 2
  %34 = getelementptr double, ptr %25, i64 %33
  %35 = or disjoint i64 %28, 3
  %36 = getelementptr double, ptr %25, i64 %35
  %37 = or disjoint i64 %28, 4
  %38 = getelementptr double, ptr %25, i64 %37
  %39 = or disjoint i64 %28, 5
  %40 = getelementptr double, ptr %25, i64 %39
  %41 = or disjoint i64 %28, 6
  %42 = getelementptr double, ptr %25, i64 %41
  %43 = or disjoint i64 %28, 7
  %44 = getelementptr double, ptr %25, i64 %43
  %45 = or disjoint i64 %28, 8
  %46 = getelementptr double, ptr %25, i64 %45
  %47 = or disjoint i64 %28, 9
  %48 = getelementptr double, ptr %25, i64 %47
  %49 = or disjoint i64 %28, 10
  %50 = getelementptr double, ptr %25, i64 %49
  %51 = or disjoint i64 %28, 11
  %52 = getelementptr double, ptr %25, i64 %51
  %53 = or disjoint i64 %28, 12
  %54 = getelementptr double, ptr %25, i64 %53
  %55 = or disjoint i64 %28, 13
  %56 = getelementptr double, ptr %25, i64 %55
  %57 = or disjoint i64 %28, 14
  %58 = getelementptr double, ptr %25, i64 %57
  %59 = or disjoint i64 %28, 15
  %60 = getelementptr double, ptr %25, i64 %59
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %61 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %67 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %67, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %68 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %68, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %69 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %69, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  %70 = load double, ptr %48, align 8, !alias.scope !1
  %broadcast.splatinsert40 = insertelement <4 x double> poison, double %70, i64 0
  %broadcast.splat41 = shufflevector <4 x double> %broadcast.splatinsert40, <4 x double> poison, <4 x i32> zeroinitializer
  %71 = load double, ptr %50, align 8, !alias.scope !1
  %broadcast.splatinsert43 = insertelement <4 x double> poison, double %71, i64 0
  %broadcast.splat44 = shufflevector <4 x double> %broadcast.splatinsert43, <4 x double> poison, <4 x i32> zeroinitializer
  %72 = load double, ptr %52, align 8, !alias.scope !1
  %broadcast.splatinsert46 = insertelement <4 x double> poison, double %72, i64 0
  %broadcast.splat47 = shufflevector <4 x double> %broadcast.splatinsert46, <4 x double> poison, <4 x i32> zeroinitializer
  %73 = load double, ptr %54, align 8, !alias.scope !1
  %broadcast.splatinsert49 = insertelement <4 x double> poison, double %73, i64 0
  %broadcast.splat50 = shufflevector <4 x double> %broadcast.splatinsert49, <4 x double> poison, <4 x i32> zeroinitializer
  %74 = load double, ptr %56, align 8, !alias.scope !1
  %broadcast.splatinsert52 = insertelement <4 x double> poison, double %74, i64 0
  %broadcast.splat53 = shufflevector <4 x double> %broadcast.splatinsert52, <4 x double> poison, <4 x i32> zeroinitializer
  %75 = load double, ptr %58, align 8, !alias.scope !1
  %broadcast.splatinsert55 = insertelement <4 x double> poison, double %75, i64 0
  %broadcast.splat56 = shufflevector <4 x double> %broadcast.splatinsert55, <4 x double> poison, <4 x i32> zeroinitializer
  %76 = load double, ptr %60, align 8, !alias.scope !1
  %broadcast.splatinsert58 = insertelement <4 x double> poison, double %76, i64 0
  %broadcast.splat59 = shufflevector <4 x double> %broadcast.splatinsert58, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %77 = getelementptr double, ptr %8, i64 %index
  %78 = getelementptr double, ptr %29, i64 %index
  %wide.load = load <4 x double>, ptr %78, align 8, !alias.scope !4, !noalias !6
  %wide.load14 = load <4 x double>, ptr %77, align 8, !alias.scope !8
  %79 = fmul <4 x double> %broadcast.splat, %wide.load14
  %80 = fadd <4 x double> %wide.load, %79
  store <4 x double> %80, ptr %78, align 8, !alias.scope !4, !noalias !6
  %81 = getelementptr double, ptr %77, i64 16
  %wide.load15 = load <4 x double>, ptr %81, align 8, !alias.scope !8
  %82 = fmul <4 x double> %broadcast.splat17, %wide.load15
  %83 = fadd <4 x double> %80, %82
  store <4 x double> %83, ptr %78, align 8, !alias.scope !4, !noalias !6
  %84 = getelementptr double, ptr %77, i64 32
  %wide.load18 = load <4 x double>, ptr %84, align 8, !alias.scope !8
  %85 = fmul <4 x double> %broadcast.splat20, %wide.load18
  %86 = fadd <4 x double> %83, %85
  store <4 x double> %86, ptr %78, align 8, !alias.scope !4, !noalias !6
  %87 = getelementptr double, ptr %77, i64 48
  %wide.load21 = load <4 x double>, ptr %87, align 8, !alias.scope !8
  %88 = fmul <4 x double> %broadcast.splat23, %wide.load21
  %89 = fadd <4 x double> %86, %88
  store <4 x double> %89, ptr %78, align 8, !alias.scope !4, !noalias !6
  %90 = getelementptr double, ptr %77, i64 64
  %wide.load24 = load <4 x double>, ptr %90, align 8, !alias.scope !8
  %91 = fmul <4 x double> %broadcast.splat26, %wide.load24
  %92 = fadd <4 x double> %89, %91
  store <4 x double> %92, ptr %78, align 8, !alias.scope !4, !noalias !6
  %93 = getelementptr double, ptr %77, i64 80
  %wide.load27 = load <4 x double>, ptr %93, align 8, !alias.scope !8
  %94 = fmul <4 x double> %broadcast.splat29, %wide.load27
  %95 = fadd <4 x double> %92, %94
  store <4 x double> %95, ptr %78, align 8, !alias.scope !4, !noalias !6
  %96 = getelementptr double, ptr %77, i64 96
  %wide.load30 = load <4 x double>, ptr %96, align 8, !alias.scope !8
  %97 = fmul <4 x double> %broadcast.splat32, %wide.load30
  %98 = fadd <4 x double> %95, %97
  store <4 x double> %98, ptr %78, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %77, i64 112
  %wide.load33 = load <4 x double>, ptr %99, align 8, !alias.scope !8
  %100 = fmul <4 x double> %broadcast.splat35, %wide.load33
  %101 = fadd <4 x double> %98, %100
  store <4 x double> %101, ptr %78, align 8, !alias.scope !4, !noalias !6
  %102 = getelementptr double, ptr %77, i64 128
  %wide.load36 = load <4 x double>, ptr %102, align 8, !alias.scope !8
  %103 = fmul <4 x double> %broadcast.splat38, %wide.load36
  %104 = fadd <4 x double> %101, %103
  store <4 x double> %104, ptr %78, align 8, !alias.scope !4, !noalias !6
  %105 = getelementptr double, ptr %77, i64 144
  %wide.load39 = load <4 x double>, ptr %105, align 8, !alias.scope !8
  %106 = fmul <4 x double> %broadcast.splat41, %wide.load39
  %107 = fadd <4 x double> %104, %106
  store <4 x double> %107, ptr %78, align 8, !alias.scope !4, !noalias !6
  %108 = getelementptr double, ptr %77, i64 160
  %wide.load42 = load <4 x double>, ptr %108, align 8, !alias.scope !8
  %109 = fmul <4 x double> %broadcast.splat44, %wide.load42
  %110 = fadd <4 x double> %107, %109
  store <4 x double> %110, ptr %78, align 8, !alias.scope !4, !noalias !6
  %111 = getelementptr double, ptr %77, i64 176
  %wide.load45 = load <4 x double>, ptr %111, align 8, !alias.scope !8
  %112 = fmul <4 x double> %broadcast.splat47, %wide.load45
  %113 = fadd <4 x double> %110, %112
  store <4 x double> %113, ptr %78, align 8, !alias.scope !4, !noalias !6
  %114 = getelementptr double, ptr %77, i64 192
  %wide.load48 = load <4 x double>, ptr %114, align 8, !alias.scope !8
  %115 = fmul <4 x double> %broadcast.splat50, %wide.load48
  %116 = fadd <4 x double> %113, %115
  store <4 x double> %116, ptr %78, align 8, !alias.scope !4, !noalias !6
  %117 = getelementptr double, ptr %77, i64 208
  %wide.load51 = load <4 x double>, ptr %117, align 8, !alias.scope !8
  %118 = fmul <4 x double> %broadcast.splat53, %wide.load51
  %119 = fadd <4 x double> %116, %118
  store <4 x double> %119, ptr %78, align 8, !alias.scope !4, !noalias !6
  %120 = getelementptr double, ptr %77, i64 224
  %wide.load54 = load <4 x double>, ptr %120, align 8, !alias.scope !8
  %121 = fmul <4 x double> %broadcast.splat56, %wide.load54
  %122 = fadd <4 x double> %119, %121
  store <4 x double> %122, ptr %78, align 8, !alias.scope !4, !noalias !6
  %123 = getelementptr double, ptr %77, i64 240
  %wide.load57 = load <4 x double>, ptr %123, align 8, !alias.scope !8
  %124 = fmul <4 x double> %broadcast.splat59, %wide.load57
  %125 = fadd <4 x double> %122, %124
  store <4 x double> %125, ptr %78, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %126 = icmp eq i64 %index.next, 16
  br i1 %126, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %127 = phi i64 [ %193, %.preheader ], [ 0, %.preheader3 ]
  %invariant.gep = getelementptr double, ptr %8, i64 %127
  %128 = getelementptr double, ptr %29, i64 %127
  %.promoted = load double, ptr %128, align 8
  %129 = load double, ptr %30, align 8
  %130 = load double, ptr %invariant.gep, align 8
  %131 = fmul double %129, %130
  %132 = fadd double %.promoted, %131
  store double %132, ptr %128, align 8
  %133 = load double, ptr %32, align 8
  %gep.1 = getelementptr double, ptr %invariant.gep, i64 16
  %134 = load double, ptr %gep.1, align 8
  %135 = fmul double %133, %134
  %136 = fadd double %132, %135
  store double %136, ptr %128, align 8
  %137 = load double, ptr %34, align 8
  %gep.2 = getelementptr double, ptr %invariant.gep, i64 32
  %138 = load double, ptr %gep.2, align 8
  %139 = fmul double %137, %138
  %140 = fadd double %136, %139
  store double %140, ptr %128, align 8
  %141 = load double, ptr %36, align 8
  %gep.3 = getelementptr double, ptr %invariant.gep, i64 48
  %142 = load double, ptr %gep.3, align 8
  %143 = fmul double %141, %142
  %144 = fadd double %140, %143
  store double %144, ptr %128, align 8
  %145 = load double, ptr %38, align 8
  %gep.4 = getelementptr double, ptr %invariant.gep, i64 64
  %146 = load double, ptr %gep.4, align 8
  %147 = fmul double %145, %146
  %148 = fadd double %144, %147
  store double %148, ptr %128, align 8
  %149 = load double, ptr %40, align 8
  %gep.5 = getelementptr double, ptr %invariant.gep, i64 80
  %150 = load double, ptr %gep.5, align 8
  %151 = fmul double %149, %150
  %152 = fadd double %148, %151
  store double %152, ptr %128, align 8
  %153 = load double, ptr %42, align 8
  %gep.6 = getelementptr double, ptr %invariant.gep, i64 96
  %154 = load double, ptr %gep.6, align 8
  %155 = fmul double %153, %154
  %156 = fadd double %152, %155
  store double %156, ptr %128, align 8
  %157 = load double, ptr %44, align 8
  %gep.7 = getelementptr double, ptr %invariant.gep, i64 112
  %158 = load double, ptr %gep.7, align 8
  %159 = fmul double %157, %158
  %160 = fadd double %156, %159
  store double %160, ptr %128, align 8
  %161 = load double, ptr %46, align 8
  %gep.8 = getelementptr double, ptr %invariant.gep, i64 128
  %162 = load double, ptr %gep.8, align 8
  %163 = fmul double %161, %162
  %164 = fadd double %160, %163
  store double %164, ptr %128, align 8
  %165 = load double, ptr %48, align 8
  %gep.9 = getelementptr double, ptr %invariant.gep, i64 144
  %166 = load double, ptr %gep.9, align 8
  %167 = fmul double %165, %166
  %168 = fadd double %164, %167
  store double %168, ptr %128, align 8
  %169 = load double, ptr %50, align 8
  %gep.10 = getelementptr double, ptr %invariant.gep, i64 160
  %170 = load double, ptr %gep.10, align 8
  %171 = fmul double %169, %170
  %172 = fadd double %168, %171
  store double %172, ptr %128, align 8
  %173 = load double, ptr %52, align 8
  %gep.11 = getelementptr double, ptr %invariant.gep, i64 176
  %174 = load double, ptr %gep.11, align 8
  %175 = fmul double %173, %174
  %176 = fadd double %172, %175
  store double %176, ptr %128, align 8
  %177 = load double, ptr %54, align 8
  %gep.12 = getelementptr double, ptr %invariant.gep, i64 192
  %178 = load double, ptr %gep.12, align 8
  %179 = fmul double %177, %178
  %180 = fadd double %176, %179
  store double %180, ptr %128, align 8
  %181 = load double, ptr %56, align 8
  %gep.13 = getelementptr double, ptr %invariant.gep, i64 208
  %182 = load double, ptr %gep.13, align 8
  %183 = fmul double %181, %182
  %184 = fadd double %180, %183
  store double %184, ptr %128, align 8
  %185 = load double, ptr %58, align 8
  %gep.14 = getelementptr double, ptr %invariant.gep, i64 224
  %186 = load double, ptr %gep.14, align 8
  %187 = fmul double %185, %186
  %188 = fadd double %184, %187
  store double %188, ptr %128, align 8
  %189 = load double, ptr %60, align 8
  %gep.15 = getelementptr double, ptr %invariant.gep, i64 240
  %190 = load double, ptr %gep.15, align 8
  %191 = fmul double %189, %190
  %192 = fadd double %188, %191
  store double %192, ptr %128, align 8
  %193 = add nuw nsw i64 %127, 1
  %exitcond.not = icmp eq i64 %193, 16
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %194 = add nuw nsw i64 %27, 1
  %exitcond6.not = icmp eq i64 %194, 4
  br i1 %exitcond6.not, label %195, label %.preheader3

195:                                              ; preds = %middle.block
  %196 = add nuw nsw i64 %21, 4
  %197 = icmp ult i64 %21, 12
  %indvar.next = add i64 %indvar, 1
  br i1 %197, label %.preheader4, label %198

198:                                              ; preds = %195
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt31 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %2, i64 0, i32 1
  %.unpack32 = load ptr, ptr %.elt31, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 15
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt31.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %9, i64 0, i32 1
  %.unpack32.i = load ptr, ptr %.elt31.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack32.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!2, !7}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
