; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %13, i8 0, i64 4096, i1 false)
  %17 = getelementptr double, ptr %8, i64 1
  %18 = getelementptr double, ptr %8, i64 2
  %19 = getelementptr double, ptr %8, i64 3
  %20 = getelementptr double, ptr %8, i64 4
  %21 = getelementptr double, ptr %8, i64 5
  %22 = getelementptr double, ptr %8, i64 6
  %23 = getelementptr double, ptr %8, i64 7
  %24 = getelementptr double, ptr %8, i64 8
  %25 = getelementptr double, ptr %8, i64 9
  %26 = getelementptr double, ptr %8, i64 10
  %27 = getelementptr double, ptr %8, i64 11
  %28 = getelementptr double, ptr %8, i64 12
  %29 = getelementptr double, ptr %8, i64 13
  %30 = getelementptr double, ptr %8, i64 14
  %31 = getelementptr double, ptr %8, i64 15
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %135
  %32 = phi i64 [ %136, %135 ], [ 0, %.preheader3.preheader ]
  %33 = shl nuw nsw i64 %32, 4
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = getelementptr double, ptr %13, i64 %32
  %36 = getelementptr double, ptr %34, i64 1
  %37 = getelementptr double, ptr %34, i64 2
  %38 = getelementptr double, ptr %34, i64 3
  %39 = getelementptr double, ptr %34, i64 4
  %40 = getelementptr double, ptr %34, i64 5
  %41 = getelementptr double, ptr %34, i64 6
  %42 = getelementptr double, ptr %34, i64 7
  %43 = getelementptr double, ptr %34, i64 8
  %44 = getelementptr double, ptr %34, i64 9
  %45 = getelementptr double, ptr %34, i64 10
  %46 = getelementptr double, ptr %34, i64 11
  %47 = getelementptr double, ptr %34, i64 12
  %48 = getelementptr double, ptr %34, i64 13
  %49 = getelementptr double, ptr %34, i64 14
  %50 = getelementptr double, ptr %34, i64 15
  br label %.preheader

.preheader:                                       ; preds = %.preheader3, %.preheader
  %51 = phi i64 [ 0, %.preheader3 ], [ %134, %.preheader ]
  %52 = shl i64 %51, 4
  %53 = getelementptr double, ptr %35, i64 %51
  %.promoted = load double, ptr %53, align 8
  %54 = getelementptr double, ptr %34, i64 %52
  %55 = load double, ptr %54, align 8
  %56 = load double, ptr %8, align 8
  %57 = fmul double %55, %56
  %58 = fadd double %.promoted, %57
  store double %58, ptr %53, align 8
  %59 = getelementptr double, ptr %36, i64 %52
  %60 = load double, ptr %59, align 8
  %61 = load double, ptr %17, align 8
  %62 = fmul double %60, %61
  %63 = fadd double %58, %62
  store double %63, ptr %53, align 8
  %64 = getelementptr double, ptr %37, i64 %52
  %65 = load double, ptr %64, align 8
  %66 = load double, ptr %18, align 8
  %67 = fmul double %65, %66
  %68 = fadd double %63, %67
  store double %68, ptr %53, align 8
  %69 = getelementptr double, ptr %38, i64 %52
  %70 = load double, ptr %69, align 8
  %71 = load double, ptr %19, align 8
  %72 = fmul double %70, %71
  %73 = fadd double %68, %72
  store double %73, ptr %53, align 8
  %74 = getelementptr double, ptr %39, i64 %52
  %75 = load double, ptr %74, align 8
  %76 = load double, ptr %20, align 8
  %77 = fmul double %75, %76
  %78 = fadd double %73, %77
  store double %78, ptr %53, align 8
  %79 = getelementptr double, ptr %40, i64 %52
  %80 = load double, ptr %79, align 8
  %81 = load double, ptr %21, align 8
  %82 = fmul double %80, %81
  %83 = fadd double %78, %82
  store double %83, ptr %53, align 8
  %84 = getelementptr double, ptr %41, i64 %52
  %85 = load double, ptr %84, align 8
  %86 = load double, ptr %22, align 8
  %87 = fmul double %85, %86
  %88 = fadd double %83, %87
  store double %88, ptr %53, align 8
  %89 = getelementptr double, ptr %42, i64 %52
  %90 = load double, ptr %89, align 8
  %91 = load double, ptr %23, align 8
  %92 = fmul double %90, %91
  %93 = fadd double %88, %92
  store double %93, ptr %53, align 8
  %94 = getelementptr double, ptr %43, i64 %52
  %95 = load double, ptr %94, align 8
  %96 = load double, ptr %24, align 8
  %97 = fmul double %95, %96
  %98 = fadd double %93, %97
  store double %98, ptr %53, align 8
  %99 = getelementptr double, ptr %44, i64 %52
  %100 = load double, ptr %99, align 8
  %101 = load double, ptr %25, align 8
  %102 = fmul double %100, %101
  %103 = fadd double %98, %102
  store double %103, ptr %53, align 8
  %104 = getelementptr double, ptr %45, i64 %52
  %105 = load double, ptr %104, align 8
  %106 = load double, ptr %26, align 8
  %107 = fmul double %105, %106
  %108 = fadd double %103, %107
  store double %108, ptr %53, align 8
  %109 = getelementptr double, ptr %46, i64 %52
  %110 = load double, ptr %109, align 8
  %111 = load double, ptr %27, align 8
  %112 = fmul double %110, %111
  %113 = fadd double %108, %112
  store double %113, ptr %53, align 8
  %114 = getelementptr double, ptr %47, i64 %52
  %115 = load double, ptr %114, align 8
  %116 = load double, ptr %28, align 8
  %117 = fmul double %115, %116
  %118 = fadd double %113, %117
  store double %118, ptr %53, align 8
  %119 = getelementptr double, ptr %48, i64 %52
  %120 = load double, ptr %119, align 8
  %121 = load double, ptr %29, align 8
  %122 = fmul double %120, %121
  %123 = fadd double %118, %122
  store double %123, ptr %53, align 8
  %124 = getelementptr double, ptr %49, i64 %52
  %125 = load double, ptr %124, align 8
  %126 = load double, ptr %30, align 8
  %127 = fmul double %125, %126
  %128 = fadd double %123, %127
  store double %128, ptr %53, align 8
  %129 = getelementptr double, ptr %50, i64 %52
  %130 = load double, ptr %129, align 8
  %131 = load double, ptr %31, align 8
  %132 = fmul double %130, %131
  %133 = fadd double %128, %132
  store double %133, ptr %53, align 8
  %134 = add nuw nsw i64 %51, 1
  %exitcond.not = icmp eq i64 %134, 4
  br i1 %exitcond.not, label %135, label %.preheader

135:                                              ; preds = %.preheader
  %136 = add nuw nsw i64 %32, 4
  %137 = icmp ult i64 %32, 508
  br i1 %137, label %.preheader3, label %138

138:                                              ; preds = %135
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
