; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader3.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %13, i8 0, i64 4096, i1 false)
  %17 = getelementptr double, ptr %8, i64 1
  %18 = getelementptr double, ptr %8, i64 2
  %19 = getelementptr double, ptr %8, i64 3
  %20 = getelementptr double, ptr %8, i64 4
  %21 = getelementptr double, ptr %8, i64 5
  %22 = getelementptr double, ptr %8, i64 6
  %23 = getelementptr double, ptr %8, i64 7
  %24 = getelementptr double, ptr %8, i64 8
  %25 = getelementptr double, ptr %8, i64 9
  %26 = getelementptr double, ptr %8, i64 10
  %27 = getelementptr double, ptr %8, i64 11
  %28 = getelementptr double, ptr %8, i64 12
  %29 = getelementptr double, ptr %8, i64 13
  %30 = getelementptr double, ptr %8, i64 14
  %31 = getelementptr double, ptr %8, i64 15
  %scevgep = getelementptr i8, ptr %13, i64 4096
  %scevgep4 = getelementptr i8, ptr %1, i64 65536
  %scevgep5 = getelementptr i8, ptr %8, i64 128
  %bound0 = icmp ugt ptr %scevgep4, %13
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound06 = icmp ugt ptr %scevgep5, %13
  %bound17 = icmp ugt ptr %scevgep, %8
  %found.conflict8 = and i1 %bound06, %bound17
  %conflict.rdx = or i1 %found.conflict, %found.conflict8
  br label %.preheader3

.preheader3:                                      ; preds = %.preheader3.preheader, %middle.block
  %32 = phi i64 [ %384, %middle.block ], [ 0, %.preheader3.preheader ]
  %33 = shl nuw nsw i64 %32, 4
  %34 = getelementptr double, ptr %1, i64 %33
  %35 = getelementptr double, ptr %13, i64 %32
  %36 = getelementptr double, ptr %34, i64 1
  %37 = getelementptr double, ptr %34, i64 2
  %38 = getelementptr double, ptr %34, i64 3
  %39 = getelementptr double, ptr %34, i64 4
  %40 = getelementptr double, ptr %34, i64 5
  %41 = getelementptr double, ptr %34, i64 6
  %42 = getelementptr double, ptr %34, i64 7
  %43 = getelementptr double, ptr %34, i64 8
  %44 = getelementptr double, ptr %34, i64 9
  %45 = getelementptr double, ptr %34, i64 10
  %46 = getelementptr double, ptr %34, i64 11
  %47 = getelementptr double, ptr %34, i64 12
  %48 = getelementptr double, ptr %34, i64 13
  %49 = getelementptr double, ptr %34, i64 14
  %50 = getelementptr double, ptr %34, i64 15
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader3
  %51 = load double, ptr %8, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %51, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = load double, ptr %17, align 8, !alias.scope !1
  %broadcast.splatinsert9 = insertelement <4 x double> poison, double %52, i64 0
  %broadcast.splat10 = shufflevector <4 x double> %broadcast.splatinsert9, <4 x double> poison, <4 x i32> zeroinitializer
  %53 = load double, ptr %18, align 8, !alias.scope !1
  %broadcast.splatinsert11 = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat12 = shufflevector <4 x double> %broadcast.splatinsert11, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %19, align 8, !alias.scope !1
  %broadcast.splatinsert13 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat14 = shufflevector <4 x double> %broadcast.splatinsert13, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %20, align 8, !alias.scope !1
  %broadcast.splatinsert15 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat16 = shufflevector <4 x double> %broadcast.splatinsert15, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %21, align 8, !alias.scope !1
  %broadcast.splatinsert17 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat18 = shufflevector <4 x double> %broadcast.splatinsert17, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %22, align 8, !alias.scope !1
  %broadcast.splatinsert19 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat20 = shufflevector <4 x double> %broadcast.splatinsert19, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %23, align 8, !alias.scope !1
  %broadcast.splatinsert21 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat22 = shufflevector <4 x double> %broadcast.splatinsert21, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert23 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat24 = shufflevector <4 x double> %broadcast.splatinsert23, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %25, align 8, !alias.scope !1
  %broadcast.splatinsert25 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat26 = shufflevector <4 x double> %broadcast.splatinsert25, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert27 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat28 = shufflevector <4 x double> %broadcast.splatinsert27, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %27, align 8, !alias.scope !1
  %broadcast.splatinsert29 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat30 = shufflevector <4 x double> %broadcast.splatinsert29, <4 x double> poison, <4 x i32> zeroinitializer
  %63 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert31 = insertelement <4 x double> poison, double %63, i64 0
  %broadcast.splat32 = shufflevector <4 x double> %broadcast.splatinsert31, <4 x double> poison, <4 x i32> zeroinitializer
  %64 = load double, ptr %29, align 8, !alias.scope !1
  %broadcast.splatinsert33 = insertelement <4 x double> poison, double %64, i64 0
  %broadcast.splat34 = shufflevector <4 x double> %broadcast.splatinsert33, <4 x double> poison, <4 x i32> zeroinitializer
  %65 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert35 = insertelement <4 x double> poison, double %65, i64 0
  %broadcast.splat36 = shufflevector <4 x double> %broadcast.splatinsert35, <4 x double> poison, <4 x i32> zeroinitializer
  %66 = load double, ptr %31, align 8, !alias.scope !1
  %broadcast.splatinsert37 = insertelement <4 x double> poison, double %66, i64 0
  %broadcast.splat38 = shufflevector <4 x double> %broadcast.splatinsert37, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %67 = shl i64 %index, 4
  %68 = shl i64 %index, 4
  %69 = or disjoint i64 %68, 16
  %70 = shl i64 %index, 4
  %71 = or disjoint i64 %70, 32
  %72 = shl i64 %index, 4
  %73 = or disjoint i64 %72, 48
  %74 = getelementptr double, ptr %35, i64 %index
  %wide.load = load <4 x double>, ptr %74, align 8, !alias.scope !4, !noalias !6
  %75 = getelementptr double, ptr %34, i64 %67
  %76 = getelementptr double, ptr %34, i64 %69
  %77 = getelementptr double, ptr %34, i64 %71
  %78 = getelementptr double, ptr %34, i64 %73
  %79 = load double, ptr %75, align 8, !alias.scope !8
  %80 = load double, ptr %76, align 8, !alias.scope !8
  %81 = load double, ptr %77, align 8, !alias.scope !8
  %82 = load double, ptr %78, align 8, !alias.scope !8
  %83 = insertelement <4 x double> poison, double %79, i64 0
  %84 = insertelement <4 x double> %83, double %80, i64 1
  %85 = insertelement <4 x double> %84, double %81, i64 2
  %86 = insertelement <4 x double> %85, double %82, i64 3
  %87 = fmul <4 x double> %86, %broadcast.splat
  %88 = fadd <4 x double> %wide.load, %87
  store <4 x double> %88, ptr %74, align 8, !alias.scope !4, !noalias !6
  %89 = getelementptr double, ptr %36, i64 %67
  %90 = getelementptr double, ptr %36, i64 %69
  %91 = getelementptr double, ptr %36, i64 %71
  %92 = getelementptr double, ptr %36, i64 %73
  %93 = load double, ptr %89, align 8, !alias.scope !8
  %94 = load double, ptr %90, align 8, !alias.scope !8
  %95 = load double, ptr %91, align 8, !alias.scope !8
  %96 = load double, ptr %92, align 8, !alias.scope !8
  %97 = insertelement <4 x double> poison, double %93, i64 0
  %98 = insertelement <4 x double> %97, double %94, i64 1
  %99 = insertelement <4 x double> %98, double %95, i64 2
  %100 = insertelement <4 x double> %99, double %96, i64 3
  %101 = fmul <4 x double> %100, %broadcast.splat10
  %102 = fadd <4 x double> %88, %101
  store <4 x double> %102, ptr %74, align 8, !alias.scope !4, !noalias !6
  %103 = getelementptr double, ptr %37, i64 %67
  %104 = getelementptr double, ptr %37, i64 %69
  %105 = getelementptr double, ptr %37, i64 %71
  %106 = getelementptr double, ptr %37, i64 %73
  %107 = load double, ptr %103, align 8, !alias.scope !8
  %108 = load double, ptr %104, align 8, !alias.scope !8
  %109 = load double, ptr %105, align 8, !alias.scope !8
  %110 = load double, ptr %106, align 8, !alias.scope !8
  %111 = insertelement <4 x double> poison, double %107, i64 0
  %112 = insertelement <4 x double> %111, double %108, i64 1
  %113 = insertelement <4 x double> %112, double %109, i64 2
  %114 = insertelement <4 x double> %113, double %110, i64 3
  %115 = fmul <4 x double> %114, %broadcast.splat12
  %116 = fadd <4 x double> %102, %115
  store <4 x double> %116, ptr %74, align 8, !alias.scope !4, !noalias !6
  %117 = getelementptr double, ptr %38, i64 %67
  %118 = getelementptr double, ptr %38, i64 %69
  %119 = getelementptr double, ptr %38, i64 %71
  %120 = getelementptr double, ptr %38, i64 %73
  %121 = load double, ptr %117, align 8, !alias.scope !8
  %122 = load double, ptr %118, align 8, !alias.scope !8
  %123 = load double, ptr %119, align 8, !alias.scope !8
  %124 = load double, ptr %120, align 8, !alias.scope !8
  %125 = insertelement <4 x double> poison, double %121, i64 0
  %126 = insertelement <4 x double> %125, double %122, i64 1
  %127 = insertelement <4 x double> %126, double %123, i64 2
  %128 = insertelement <4 x double> %127, double %124, i64 3
  %129 = fmul <4 x double> %128, %broadcast.splat14
  %130 = fadd <4 x double> %116, %129
  store <4 x double> %130, ptr %74, align 8, !alias.scope !4, !noalias !6
  %131 = getelementptr double, ptr %39, i64 %67
  %132 = getelementptr double, ptr %39, i64 %69
  %133 = getelementptr double, ptr %39, i64 %71
  %134 = getelementptr double, ptr %39, i64 %73
  %135 = load double, ptr %131, align 8, !alias.scope !8
  %136 = load double, ptr %132, align 8, !alias.scope !8
  %137 = load double, ptr %133, align 8, !alias.scope !8
  %138 = load double, ptr %134, align 8, !alias.scope !8
  %139 = insertelement <4 x double> poison, double %135, i64 0
  %140 = insertelement <4 x double> %139, double %136, i64 1
  %141 = insertelement <4 x double> %140, double %137, i64 2
  %142 = insertelement <4 x double> %141, double %138, i64 3
  %143 = fmul <4 x double> %142, %broadcast.splat16
  %144 = fadd <4 x double> %130, %143
  store <4 x double> %144, ptr %74, align 8, !alias.scope !4, !noalias !6
  %145 = getelementptr double, ptr %40, i64 %67
  %146 = getelementptr double, ptr %40, i64 %69
  %147 = getelementptr double, ptr %40, i64 %71
  %148 = getelementptr double, ptr %40, i64 %73
  %149 = load double, ptr %145, align 8, !alias.scope !8
  %150 = load double, ptr %146, align 8, !alias.scope !8
  %151 = load double, ptr %147, align 8, !alias.scope !8
  %152 = load double, ptr %148, align 8, !alias.scope !8
  %153 = insertelement <4 x double> poison, double %149, i64 0
  %154 = insertelement <4 x double> %153, double %150, i64 1
  %155 = insertelement <4 x double> %154, double %151, i64 2
  %156 = insertelement <4 x double> %155, double %152, i64 3
  %157 = fmul <4 x double> %156, %broadcast.splat18
  %158 = fadd <4 x double> %144, %157
  store <4 x double> %158, ptr %74, align 8, !alias.scope !4, !noalias !6
  %159 = getelementptr double, ptr %41, i64 %67
  %160 = getelementptr double, ptr %41, i64 %69
  %161 = getelementptr double, ptr %41, i64 %71
  %162 = getelementptr double, ptr %41, i64 %73
  %163 = load double, ptr %159, align 8, !alias.scope !8
  %164 = load double, ptr %160, align 8, !alias.scope !8
  %165 = load double, ptr %161, align 8, !alias.scope !8
  %166 = load double, ptr %162, align 8, !alias.scope !8
  %167 = insertelement <4 x double> poison, double %163, i64 0
  %168 = insertelement <4 x double> %167, double %164, i64 1
  %169 = insertelement <4 x double> %168, double %165, i64 2
  %170 = insertelement <4 x double> %169, double %166, i64 3
  %171 = fmul <4 x double> %170, %broadcast.splat20
  %172 = fadd <4 x double> %158, %171
  store <4 x double> %172, ptr %74, align 8, !alias.scope !4, !noalias !6
  %173 = getelementptr double, ptr %42, i64 %67
  %174 = getelementptr double, ptr %42, i64 %69
  %175 = getelementptr double, ptr %42, i64 %71
  %176 = getelementptr double, ptr %42, i64 %73
  %177 = load double, ptr %173, align 8, !alias.scope !8
  %178 = load double, ptr %174, align 8, !alias.scope !8
  %179 = load double, ptr %175, align 8, !alias.scope !8
  %180 = load double, ptr %176, align 8, !alias.scope !8
  %181 = insertelement <4 x double> poison, double %177, i64 0
  %182 = insertelement <4 x double> %181, double %178, i64 1
  %183 = insertelement <4 x double> %182, double %179, i64 2
  %184 = insertelement <4 x double> %183, double %180, i64 3
  %185 = fmul <4 x double> %184, %broadcast.splat22
  %186 = fadd <4 x double> %172, %185
  store <4 x double> %186, ptr %74, align 8, !alias.scope !4, !noalias !6
  %187 = getelementptr double, ptr %43, i64 %67
  %188 = getelementptr double, ptr %43, i64 %69
  %189 = getelementptr double, ptr %43, i64 %71
  %190 = getelementptr double, ptr %43, i64 %73
  %191 = load double, ptr %187, align 8, !alias.scope !8
  %192 = load double, ptr %188, align 8, !alias.scope !8
  %193 = load double, ptr %189, align 8, !alias.scope !8
  %194 = load double, ptr %190, align 8, !alias.scope !8
  %195 = insertelement <4 x double> poison, double %191, i64 0
  %196 = insertelement <4 x double> %195, double %192, i64 1
  %197 = insertelement <4 x double> %196, double %193, i64 2
  %198 = insertelement <4 x double> %197, double %194, i64 3
  %199 = fmul <4 x double> %198, %broadcast.splat24
  %200 = fadd <4 x double> %186, %199
  store <4 x double> %200, ptr %74, align 8, !alias.scope !4, !noalias !6
  %201 = getelementptr double, ptr %44, i64 %67
  %202 = getelementptr double, ptr %44, i64 %69
  %203 = getelementptr double, ptr %44, i64 %71
  %204 = getelementptr double, ptr %44, i64 %73
  %205 = load double, ptr %201, align 8, !alias.scope !8
  %206 = load double, ptr %202, align 8, !alias.scope !8
  %207 = load double, ptr %203, align 8, !alias.scope !8
  %208 = load double, ptr %204, align 8, !alias.scope !8
  %209 = insertelement <4 x double> poison, double %205, i64 0
  %210 = insertelement <4 x double> %209, double %206, i64 1
  %211 = insertelement <4 x double> %210, double %207, i64 2
  %212 = insertelement <4 x double> %211, double %208, i64 3
  %213 = fmul <4 x double> %212, %broadcast.splat26
  %214 = fadd <4 x double> %200, %213
  store <4 x double> %214, ptr %74, align 8, !alias.scope !4, !noalias !6
  %215 = getelementptr double, ptr %45, i64 %67
  %216 = getelementptr double, ptr %45, i64 %69
  %217 = getelementptr double, ptr %45, i64 %71
  %218 = getelementptr double, ptr %45, i64 %73
  %219 = load double, ptr %215, align 8, !alias.scope !8
  %220 = load double, ptr %216, align 8, !alias.scope !8
  %221 = load double, ptr %217, align 8, !alias.scope !8
  %222 = load double, ptr %218, align 8, !alias.scope !8
  %223 = insertelement <4 x double> poison, double %219, i64 0
  %224 = insertelement <4 x double> %223, double %220, i64 1
  %225 = insertelement <4 x double> %224, double %221, i64 2
  %226 = insertelement <4 x double> %225, double %222, i64 3
  %227 = fmul <4 x double> %226, %broadcast.splat28
  %228 = fadd <4 x double> %214, %227
  store <4 x double> %228, ptr %74, align 8, !alias.scope !4, !noalias !6
  %229 = getelementptr double, ptr %46, i64 %67
  %230 = getelementptr double, ptr %46, i64 %69
  %231 = getelementptr double, ptr %46, i64 %71
  %232 = getelementptr double, ptr %46, i64 %73
  %233 = load double, ptr %229, align 8, !alias.scope !8
  %234 = load double, ptr %230, align 8, !alias.scope !8
  %235 = load double, ptr %231, align 8, !alias.scope !8
  %236 = load double, ptr %232, align 8, !alias.scope !8
  %237 = insertelement <4 x double> poison, double %233, i64 0
  %238 = insertelement <4 x double> %237, double %234, i64 1
  %239 = insertelement <4 x double> %238, double %235, i64 2
  %240 = insertelement <4 x double> %239, double %236, i64 3
  %241 = fmul <4 x double> %240, %broadcast.splat30
  %242 = fadd <4 x double> %228, %241
  store <4 x double> %242, ptr %74, align 8, !alias.scope !4, !noalias !6
  %243 = getelementptr double, ptr %47, i64 %67
  %244 = getelementptr double, ptr %47, i64 %69
  %245 = getelementptr double, ptr %47, i64 %71
  %246 = getelementptr double, ptr %47, i64 %73
  %247 = load double, ptr %243, align 8, !alias.scope !8
  %248 = load double, ptr %244, align 8, !alias.scope !8
  %249 = load double, ptr %245, align 8, !alias.scope !8
  %250 = load double, ptr %246, align 8, !alias.scope !8
  %251 = insertelement <4 x double> poison, double %247, i64 0
  %252 = insertelement <4 x double> %251, double %248, i64 1
  %253 = insertelement <4 x double> %252, double %249, i64 2
  %254 = insertelement <4 x double> %253, double %250, i64 3
  %255 = fmul <4 x double> %254, %broadcast.splat32
  %256 = fadd <4 x double> %242, %255
  store <4 x double> %256, ptr %74, align 8, !alias.scope !4, !noalias !6
  %257 = getelementptr double, ptr %48, i64 %67
  %258 = getelementptr double, ptr %48, i64 %69
  %259 = getelementptr double, ptr %48, i64 %71
  %260 = getelementptr double, ptr %48, i64 %73
  %261 = load double, ptr %257, align 8, !alias.scope !8
  %262 = load double, ptr %258, align 8, !alias.scope !8
  %263 = load double, ptr %259, align 8, !alias.scope !8
  %264 = load double, ptr %260, align 8, !alias.scope !8
  %265 = insertelement <4 x double> poison, double %261, i64 0
  %266 = insertelement <4 x double> %265, double %262, i64 1
  %267 = insertelement <4 x double> %266, double %263, i64 2
  %268 = insertelement <4 x double> %267, double %264, i64 3
  %269 = fmul <4 x double> %268, %broadcast.splat34
  %270 = fadd <4 x double> %256, %269
  store <4 x double> %270, ptr %74, align 8, !alias.scope !4, !noalias !6
  %271 = getelementptr double, ptr %49, i64 %67
  %272 = getelementptr double, ptr %49, i64 %69
  %273 = getelementptr double, ptr %49, i64 %71
  %274 = getelementptr double, ptr %49, i64 %73
  %275 = load double, ptr %271, align 8, !alias.scope !8
  %276 = load double, ptr %272, align 8, !alias.scope !8
  %277 = load double, ptr %273, align 8, !alias.scope !8
  %278 = load double, ptr %274, align 8, !alias.scope !8
  %279 = insertelement <4 x double> poison, double %275, i64 0
  %280 = insertelement <4 x double> %279, double %276, i64 1
  %281 = insertelement <4 x double> %280, double %277, i64 2
  %282 = insertelement <4 x double> %281, double %278, i64 3
  %283 = fmul <4 x double> %282, %broadcast.splat36
  %284 = fadd <4 x double> %270, %283
  store <4 x double> %284, ptr %74, align 8, !alias.scope !4, !noalias !6
  %285 = getelementptr double, ptr %50, i64 %67
  %286 = getelementptr double, ptr %50, i64 %69
  %287 = getelementptr double, ptr %50, i64 %71
  %288 = getelementptr double, ptr %50, i64 %73
  %289 = load double, ptr %285, align 8, !alias.scope !8
  %290 = load double, ptr %286, align 8, !alias.scope !8
  %291 = load double, ptr %287, align 8, !alias.scope !8
  %292 = load double, ptr %288, align 8, !alias.scope !8
  %293 = insertelement <4 x double> poison, double %289, i64 0
  %294 = insertelement <4 x double> %293, double %290, i64 1
  %295 = insertelement <4 x double> %294, double %291, i64 2
  %296 = insertelement <4 x double> %295, double %292, i64 3
  %297 = fmul <4 x double> %296, %broadcast.splat38
  %298 = fadd <4 x double> %284, %297
  store <4 x double> %298, ptr %74, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %299 = icmp eq i64 %index.next, 16
  br i1 %299, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader3, %.preheader
  %300 = phi i64 [ %383, %.preheader ], [ 0, %.preheader3 ]
  %301 = shl i64 %300, 4
  %302 = getelementptr double, ptr %35, i64 %300
  %.promoted = load double, ptr %302, align 8
  %303 = getelementptr double, ptr %34, i64 %301
  %304 = load double, ptr %303, align 8
  %305 = load double, ptr %8, align 8
  %306 = fmul double %304, %305
  %307 = fadd double %.promoted, %306
  store double %307, ptr %302, align 8
  %308 = getelementptr double, ptr %36, i64 %301
  %309 = load double, ptr %308, align 8
  %310 = load double, ptr %17, align 8
  %311 = fmul double %309, %310
  %312 = fadd double %307, %311
  store double %312, ptr %302, align 8
  %313 = getelementptr double, ptr %37, i64 %301
  %314 = load double, ptr %313, align 8
  %315 = load double, ptr %18, align 8
  %316 = fmul double %314, %315
  %317 = fadd double %312, %316
  store double %317, ptr %302, align 8
  %318 = getelementptr double, ptr %38, i64 %301
  %319 = load double, ptr %318, align 8
  %320 = load double, ptr %19, align 8
  %321 = fmul double %319, %320
  %322 = fadd double %317, %321
  store double %322, ptr %302, align 8
  %323 = getelementptr double, ptr %39, i64 %301
  %324 = load double, ptr %323, align 8
  %325 = load double, ptr %20, align 8
  %326 = fmul double %324, %325
  %327 = fadd double %322, %326
  store double %327, ptr %302, align 8
  %328 = getelementptr double, ptr %40, i64 %301
  %329 = load double, ptr %328, align 8
  %330 = load double, ptr %21, align 8
  %331 = fmul double %329, %330
  %332 = fadd double %327, %331
  store double %332, ptr %302, align 8
  %333 = getelementptr double, ptr %41, i64 %301
  %334 = load double, ptr %333, align 8
  %335 = load double, ptr %22, align 8
  %336 = fmul double %334, %335
  %337 = fadd double %332, %336
  store double %337, ptr %302, align 8
  %338 = getelementptr double, ptr %42, i64 %301
  %339 = load double, ptr %338, align 8
  %340 = load double, ptr %23, align 8
  %341 = fmul double %339, %340
  %342 = fadd double %337, %341
  store double %342, ptr %302, align 8
  %343 = getelementptr double, ptr %43, i64 %301
  %344 = load double, ptr %343, align 8
  %345 = load double, ptr %24, align 8
  %346 = fmul double %344, %345
  %347 = fadd double %342, %346
  store double %347, ptr %302, align 8
  %348 = getelementptr double, ptr %44, i64 %301
  %349 = load double, ptr %348, align 8
  %350 = load double, ptr %25, align 8
  %351 = fmul double %349, %350
  %352 = fadd double %347, %351
  store double %352, ptr %302, align 8
  %353 = getelementptr double, ptr %45, i64 %301
  %354 = load double, ptr %353, align 8
  %355 = load double, ptr %26, align 8
  %356 = fmul double %354, %355
  %357 = fadd double %352, %356
  store double %357, ptr %302, align 8
  %358 = getelementptr double, ptr %46, i64 %301
  %359 = load double, ptr %358, align 8
  %360 = load double, ptr %27, align 8
  %361 = fmul double %359, %360
  %362 = fadd double %357, %361
  store double %362, ptr %302, align 8
  %363 = getelementptr double, ptr %47, i64 %301
  %364 = load double, ptr %363, align 8
  %365 = load double, ptr %28, align 8
  %366 = fmul double %364, %365
  %367 = fadd double %362, %366
  store double %367, ptr %302, align 8
  %368 = getelementptr double, ptr %48, i64 %301
  %369 = load double, ptr %368, align 8
  %370 = load double, ptr %29, align 8
  %371 = fmul double %369, %370
  %372 = fadd double %367, %371
  store double %372, ptr %302, align 8
  %373 = getelementptr double, ptr %49, i64 %301
  %374 = load double, ptr %373, align 8
  %375 = load double, ptr %30, align 8
  %376 = fmul double %374, %375
  %377 = fadd double %372, %376
  store double %377, ptr %302, align 8
  %378 = getelementptr double, ptr %50, i64 %301
  %379 = load double, ptr %378, align 8
  %380 = load double, ptr %31, align 8
  %381 = fmul double %379, %380
  %382 = fadd double %377, %381
  store double %382, ptr %302, align 8
  %383 = add nuw nsw i64 %300, 1
  %exitcond.not = icmp eq i64 %383, 16
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  %384 = add nuw nsw i64 %32, 16
  %385 = icmp ult i64 %32, 496
  br i1 %385, label %.preheader3, label %386

386:                                              ; preds = %middle.block
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!7, !2}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
