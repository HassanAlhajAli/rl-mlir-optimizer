; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
.preheader.preheader:
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %13, i8 0, i64 4096, i1 false)
  %17 = getelementptr double, ptr %1, i64 1
  %18 = getelementptr double, ptr %8, i64 1
  %19 = getelementptr double, ptr %1, i64 2
  %20 = getelementptr double, ptr %8, i64 2
  %21 = getelementptr double, ptr %1, i64 3
  %22 = getelementptr double, ptr %8, i64 3
  %23 = getelementptr double, ptr %1, i64 4
  %24 = getelementptr double, ptr %8, i64 4
  %25 = getelementptr double, ptr %1, i64 5
  %26 = getelementptr double, ptr %8, i64 5
  %27 = getelementptr double, ptr %1, i64 6
  %28 = getelementptr double, ptr %8, i64 6
  %29 = getelementptr double, ptr %1, i64 7
  %30 = getelementptr double, ptr %8, i64 7
  %31 = getelementptr double, ptr %1, i64 8
  %32 = getelementptr double, ptr %8, i64 8
  %33 = getelementptr double, ptr %1, i64 9
  %34 = getelementptr double, ptr %8, i64 9
  %35 = getelementptr double, ptr %1, i64 10
  %36 = getelementptr double, ptr %8, i64 10
  %37 = getelementptr double, ptr %1, i64 11
  %38 = getelementptr double, ptr %8, i64 11
  %39 = getelementptr double, ptr %1, i64 12
  %40 = getelementptr double, ptr %8, i64 12
  %41 = getelementptr double, ptr %1, i64 13
  %42 = getelementptr double, ptr %8, i64 13
  %43 = getelementptr double, ptr %1, i64 14
  %44 = getelementptr double, ptr %8, i64 14
  %45 = getelementptr double, ptr %1, i64 15
  %46 = getelementptr double, ptr %8, i64 15
  %scevgep = getelementptr i8, ptr %13, i64 4096
  %scevgep3 = getelementptr i8, ptr %1, i64 65536
  %scevgep4 = getelementptr i8, ptr %8, i64 128
  %bound0 = icmp ugt ptr %scevgep3, %13
  %bound1 = icmp ugt ptr %scevgep, %1
  %found.conflict = and i1 %bound0, %bound1
  %bound05 = icmp ugt ptr %scevgep4, %13
  %bound16 = icmp ugt ptr %scevgep, %8
  %found.conflict7 = and i1 %bound05, %bound16
  %conflict.rdx = or i1 %found.conflict, %found.conflict7
  br i1 %conflict.rdx, label %.preheader, label %vector.body.preheader

vector.body.preheader:                            ; preds = %.preheader.preheader
  %47 = load double, ptr %8, align 8, !alias.scope !1
  %broadcast.splatinsert = insertelement <4 x double> poison, double %47, i64 0
  %broadcast.splat = shufflevector <4 x double> %broadcast.splatinsert, <4 x double> poison, <4 x i32> zeroinitializer
  %48 = load double, ptr %18, align 8, !alias.scope !1
  %broadcast.splatinsert8 = insertelement <4 x double> poison, double %48, i64 0
  %broadcast.splat9 = shufflevector <4 x double> %broadcast.splatinsert8, <4 x double> poison, <4 x i32> zeroinitializer
  %49 = load double, ptr %20, align 8, !alias.scope !1
  %broadcast.splatinsert10 = insertelement <4 x double> poison, double %49, i64 0
  %broadcast.splat11 = shufflevector <4 x double> %broadcast.splatinsert10, <4 x double> poison, <4 x i32> zeroinitializer
  %50 = load double, ptr %22, align 8, !alias.scope !1
  %broadcast.splatinsert12 = insertelement <4 x double> poison, double %50, i64 0
  %broadcast.splat13 = shufflevector <4 x double> %broadcast.splatinsert12, <4 x double> poison, <4 x i32> zeroinitializer
  %51 = load double, ptr %24, align 8, !alias.scope !1
  %broadcast.splatinsert14 = insertelement <4 x double> poison, double %51, i64 0
  %broadcast.splat15 = shufflevector <4 x double> %broadcast.splatinsert14, <4 x double> poison, <4 x i32> zeroinitializer
  %52 = load double, ptr %26, align 8, !alias.scope !1
  %broadcast.splatinsert16 = insertelement <4 x double> poison, double %52, i64 0
  %broadcast.splat17 = shufflevector <4 x double> %broadcast.splatinsert16, <4 x double> poison, <4 x i32> zeroinitializer
  %53 = load double, ptr %28, align 8, !alias.scope !1
  %broadcast.splatinsert18 = insertelement <4 x double> poison, double %53, i64 0
  %broadcast.splat19 = shufflevector <4 x double> %broadcast.splatinsert18, <4 x double> poison, <4 x i32> zeroinitializer
  %54 = load double, ptr %30, align 8, !alias.scope !1
  %broadcast.splatinsert20 = insertelement <4 x double> poison, double %54, i64 0
  %broadcast.splat21 = shufflevector <4 x double> %broadcast.splatinsert20, <4 x double> poison, <4 x i32> zeroinitializer
  %55 = load double, ptr %32, align 8, !alias.scope !1
  %broadcast.splatinsert22 = insertelement <4 x double> poison, double %55, i64 0
  %broadcast.splat23 = shufflevector <4 x double> %broadcast.splatinsert22, <4 x double> poison, <4 x i32> zeroinitializer
  %56 = load double, ptr %34, align 8, !alias.scope !1
  %broadcast.splatinsert24 = insertelement <4 x double> poison, double %56, i64 0
  %broadcast.splat25 = shufflevector <4 x double> %broadcast.splatinsert24, <4 x double> poison, <4 x i32> zeroinitializer
  %57 = load double, ptr %36, align 8, !alias.scope !1
  %broadcast.splatinsert26 = insertelement <4 x double> poison, double %57, i64 0
  %broadcast.splat27 = shufflevector <4 x double> %broadcast.splatinsert26, <4 x double> poison, <4 x i32> zeroinitializer
  %58 = load double, ptr %38, align 8, !alias.scope !1
  %broadcast.splatinsert28 = insertelement <4 x double> poison, double %58, i64 0
  %broadcast.splat29 = shufflevector <4 x double> %broadcast.splatinsert28, <4 x double> poison, <4 x i32> zeroinitializer
  %59 = load double, ptr %40, align 8, !alias.scope !1
  %broadcast.splatinsert30 = insertelement <4 x double> poison, double %59, i64 0
  %broadcast.splat31 = shufflevector <4 x double> %broadcast.splatinsert30, <4 x double> poison, <4 x i32> zeroinitializer
  %60 = load double, ptr %42, align 8, !alias.scope !1
  %broadcast.splatinsert32 = insertelement <4 x double> poison, double %60, i64 0
  %broadcast.splat33 = shufflevector <4 x double> %broadcast.splatinsert32, <4 x double> poison, <4 x i32> zeroinitializer
  %61 = load double, ptr %44, align 8, !alias.scope !1
  %broadcast.splatinsert34 = insertelement <4 x double> poison, double %61, i64 0
  %broadcast.splat35 = shufflevector <4 x double> %broadcast.splatinsert34, <4 x double> poison, <4 x i32> zeroinitializer
  %62 = load double, ptr %46, align 8, !alias.scope !1
  %broadcast.splatinsert36 = insertelement <4 x double> poison, double %62, i64 0
  %broadcast.splat37 = shufflevector <4 x double> %broadcast.splatinsert36, <4 x double> poison, <4 x i32> zeroinitializer
  br label %vector.body

vector.body:                                      ; preds = %vector.body.preheader, %vector.body
  %index = phi i64 [ %index.next, %vector.body ], [ 0, %vector.body.preheader ]
  %63 = shl i64 %index, 4
  %64 = shl i64 %index, 4
  %65 = or disjoint i64 %64, 16
  %66 = shl i64 %index, 4
  %67 = or disjoint i64 %66, 32
  %68 = shl i64 %index, 4
  %69 = or disjoint i64 %68, 48
  %70 = getelementptr double, ptr %13, i64 %index
  %wide.load = load <4 x double>, ptr %70, align 8, !alias.scope !4, !noalias !6
  %71 = getelementptr double, ptr %1, i64 %63
  %72 = getelementptr double, ptr %1, i64 %65
  %73 = getelementptr double, ptr %1, i64 %67
  %74 = getelementptr double, ptr %1, i64 %69
  %75 = load double, ptr %71, align 8, !alias.scope !8
  %76 = load double, ptr %72, align 8, !alias.scope !8
  %77 = load double, ptr %73, align 8, !alias.scope !8
  %78 = load double, ptr %74, align 8, !alias.scope !8
  %79 = insertelement <4 x double> poison, double %75, i64 0
  %80 = insertelement <4 x double> %79, double %76, i64 1
  %81 = insertelement <4 x double> %80, double %77, i64 2
  %82 = insertelement <4 x double> %81, double %78, i64 3
  %83 = fmul <4 x double> %82, %broadcast.splat
  %84 = fadd <4 x double> %wide.load, %83
  store <4 x double> %84, ptr %70, align 8, !alias.scope !4, !noalias !6
  %85 = getelementptr double, ptr %17, i64 %63
  %86 = getelementptr double, ptr %17, i64 %65
  %87 = getelementptr double, ptr %17, i64 %67
  %88 = getelementptr double, ptr %17, i64 %69
  %89 = load double, ptr %85, align 8, !alias.scope !8
  %90 = load double, ptr %86, align 8, !alias.scope !8
  %91 = load double, ptr %87, align 8, !alias.scope !8
  %92 = load double, ptr %88, align 8, !alias.scope !8
  %93 = insertelement <4 x double> poison, double %89, i64 0
  %94 = insertelement <4 x double> %93, double %90, i64 1
  %95 = insertelement <4 x double> %94, double %91, i64 2
  %96 = insertelement <4 x double> %95, double %92, i64 3
  %97 = fmul <4 x double> %96, %broadcast.splat9
  %98 = fadd <4 x double> %84, %97
  store <4 x double> %98, ptr %70, align 8, !alias.scope !4, !noalias !6
  %99 = getelementptr double, ptr %19, i64 %63
  %100 = getelementptr double, ptr %19, i64 %65
  %101 = getelementptr double, ptr %19, i64 %67
  %102 = getelementptr double, ptr %19, i64 %69
  %103 = load double, ptr %99, align 8, !alias.scope !8
  %104 = load double, ptr %100, align 8, !alias.scope !8
  %105 = load double, ptr %101, align 8, !alias.scope !8
  %106 = load double, ptr %102, align 8, !alias.scope !8
  %107 = insertelement <4 x double> poison, double %103, i64 0
  %108 = insertelement <4 x double> %107, double %104, i64 1
  %109 = insertelement <4 x double> %108, double %105, i64 2
  %110 = insertelement <4 x double> %109, double %106, i64 3
  %111 = fmul <4 x double> %110, %broadcast.splat11
  %112 = fadd <4 x double> %98, %111
  store <4 x double> %112, ptr %70, align 8, !alias.scope !4, !noalias !6
  %113 = getelementptr double, ptr %21, i64 %63
  %114 = getelementptr double, ptr %21, i64 %65
  %115 = getelementptr double, ptr %21, i64 %67
  %116 = getelementptr double, ptr %21, i64 %69
  %117 = load double, ptr %113, align 8, !alias.scope !8
  %118 = load double, ptr %114, align 8, !alias.scope !8
  %119 = load double, ptr %115, align 8, !alias.scope !8
  %120 = load double, ptr %116, align 8, !alias.scope !8
  %121 = insertelement <4 x double> poison, double %117, i64 0
  %122 = insertelement <4 x double> %121, double %118, i64 1
  %123 = insertelement <4 x double> %122, double %119, i64 2
  %124 = insertelement <4 x double> %123, double %120, i64 3
  %125 = fmul <4 x double> %124, %broadcast.splat13
  %126 = fadd <4 x double> %112, %125
  store <4 x double> %126, ptr %70, align 8, !alias.scope !4, !noalias !6
  %127 = getelementptr double, ptr %23, i64 %63
  %128 = getelementptr double, ptr %23, i64 %65
  %129 = getelementptr double, ptr %23, i64 %67
  %130 = getelementptr double, ptr %23, i64 %69
  %131 = load double, ptr %127, align 8, !alias.scope !8
  %132 = load double, ptr %128, align 8, !alias.scope !8
  %133 = load double, ptr %129, align 8, !alias.scope !8
  %134 = load double, ptr %130, align 8, !alias.scope !8
  %135 = insertelement <4 x double> poison, double %131, i64 0
  %136 = insertelement <4 x double> %135, double %132, i64 1
  %137 = insertelement <4 x double> %136, double %133, i64 2
  %138 = insertelement <4 x double> %137, double %134, i64 3
  %139 = fmul <4 x double> %138, %broadcast.splat15
  %140 = fadd <4 x double> %126, %139
  store <4 x double> %140, ptr %70, align 8, !alias.scope !4, !noalias !6
  %141 = getelementptr double, ptr %25, i64 %63
  %142 = getelementptr double, ptr %25, i64 %65
  %143 = getelementptr double, ptr %25, i64 %67
  %144 = getelementptr double, ptr %25, i64 %69
  %145 = load double, ptr %141, align 8, !alias.scope !8
  %146 = load double, ptr %142, align 8, !alias.scope !8
  %147 = load double, ptr %143, align 8, !alias.scope !8
  %148 = load double, ptr %144, align 8, !alias.scope !8
  %149 = insertelement <4 x double> poison, double %145, i64 0
  %150 = insertelement <4 x double> %149, double %146, i64 1
  %151 = insertelement <4 x double> %150, double %147, i64 2
  %152 = insertelement <4 x double> %151, double %148, i64 3
  %153 = fmul <4 x double> %152, %broadcast.splat17
  %154 = fadd <4 x double> %140, %153
  store <4 x double> %154, ptr %70, align 8, !alias.scope !4, !noalias !6
  %155 = getelementptr double, ptr %27, i64 %63
  %156 = getelementptr double, ptr %27, i64 %65
  %157 = getelementptr double, ptr %27, i64 %67
  %158 = getelementptr double, ptr %27, i64 %69
  %159 = load double, ptr %155, align 8, !alias.scope !8
  %160 = load double, ptr %156, align 8, !alias.scope !8
  %161 = load double, ptr %157, align 8, !alias.scope !8
  %162 = load double, ptr %158, align 8, !alias.scope !8
  %163 = insertelement <4 x double> poison, double %159, i64 0
  %164 = insertelement <4 x double> %163, double %160, i64 1
  %165 = insertelement <4 x double> %164, double %161, i64 2
  %166 = insertelement <4 x double> %165, double %162, i64 3
  %167 = fmul <4 x double> %166, %broadcast.splat19
  %168 = fadd <4 x double> %154, %167
  store <4 x double> %168, ptr %70, align 8, !alias.scope !4, !noalias !6
  %169 = getelementptr double, ptr %29, i64 %63
  %170 = getelementptr double, ptr %29, i64 %65
  %171 = getelementptr double, ptr %29, i64 %67
  %172 = getelementptr double, ptr %29, i64 %69
  %173 = load double, ptr %169, align 8, !alias.scope !8
  %174 = load double, ptr %170, align 8, !alias.scope !8
  %175 = load double, ptr %171, align 8, !alias.scope !8
  %176 = load double, ptr %172, align 8, !alias.scope !8
  %177 = insertelement <4 x double> poison, double %173, i64 0
  %178 = insertelement <4 x double> %177, double %174, i64 1
  %179 = insertelement <4 x double> %178, double %175, i64 2
  %180 = insertelement <4 x double> %179, double %176, i64 3
  %181 = fmul <4 x double> %180, %broadcast.splat21
  %182 = fadd <4 x double> %168, %181
  store <4 x double> %182, ptr %70, align 8, !alias.scope !4, !noalias !6
  %183 = getelementptr double, ptr %31, i64 %63
  %184 = getelementptr double, ptr %31, i64 %65
  %185 = getelementptr double, ptr %31, i64 %67
  %186 = getelementptr double, ptr %31, i64 %69
  %187 = load double, ptr %183, align 8, !alias.scope !8
  %188 = load double, ptr %184, align 8, !alias.scope !8
  %189 = load double, ptr %185, align 8, !alias.scope !8
  %190 = load double, ptr %186, align 8, !alias.scope !8
  %191 = insertelement <4 x double> poison, double %187, i64 0
  %192 = insertelement <4 x double> %191, double %188, i64 1
  %193 = insertelement <4 x double> %192, double %189, i64 2
  %194 = insertelement <4 x double> %193, double %190, i64 3
  %195 = fmul <4 x double> %194, %broadcast.splat23
  %196 = fadd <4 x double> %182, %195
  store <4 x double> %196, ptr %70, align 8, !alias.scope !4, !noalias !6
  %197 = getelementptr double, ptr %33, i64 %63
  %198 = getelementptr double, ptr %33, i64 %65
  %199 = getelementptr double, ptr %33, i64 %67
  %200 = getelementptr double, ptr %33, i64 %69
  %201 = load double, ptr %197, align 8, !alias.scope !8
  %202 = load double, ptr %198, align 8, !alias.scope !8
  %203 = load double, ptr %199, align 8, !alias.scope !8
  %204 = load double, ptr %200, align 8, !alias.scope !8
  %205 = insertelement <4 x double> poison, double %201, i64 0
  %206 = insertelement <4 x double> %205, double %202, i64 1
  %207 = insertelement <4 x double> %206, double %203, i64 2
  %208 = insertelement <4 x double> %207, double %204, i64 3
  %209 = fmul <4 x double> %208, %broadcast.splat25
  %210 = fadd <4 x double> %196, %209
  store <4 x double> %210, ptr %70, align 8, !alias.scope !4, !noalias !6
  %211 = getelementptr double, ptr %35, i64 %63
  %212 = getelementptr double, ptr %35, i64 %65
  %213 = getelementptr double, ptr %35, i64 %67
  %214 = getelementptr double, ptr %35, i64 %69
  %215 = load double, ptr %211, align 8, !alias.scope !8
  %216 = load double, ptr %212, align 8, !alias.scope !8
  %217 = load double, ptr %213, align 8, !alias.scope !8
  %218 = load double, ptr %214, align 8, !alias.scope !8
  %219 = insertelement <4 x double> poison, double %215, i64 0
  %220 = insertelement <4 x double> %219, double %216, i64 1
  %221 = insertelement <4 x double> %220, double %217, i64 2
  %222 = insertelement <4 x double> %221, double %218, i64 3
  %223 = fmul <4 x double> %222, %broadcast.splat27
  %224 = fadd <4 x double> %210, %223
  store <4 x double> %224, ptr %70, align 8, !alias.scope !4, !noalias !6
  %225 = getelementptr double, ptr %37, i64 %63
  %226 = getelementptr double, ptr %37, i64 %65
  %227 = getelementptr double, ptr %37, i64 %67
  %228 = getelementptr double, ptr %37, i64 %69
  %229 = load double, ptr %225, align 8, !alias.scope !8
  %230 = load double, ptr %226, align 8, !alias.scope !8
  %231 = load double, ptr %227, align 8, !alias.scope !8
  %232 = load double, ptr %228, align 8, !alias.scope !8
  %233 = insertelement <4 x double> poison, double %229, i64 0
  %234 = insertelement <4 x double> %233, double %230, i64 1
  %235 = insertelement <4 x double> %234, double %231, i64 2
  %236 = insertelement <4 x double> %235, double %232, i64 3
  %237 = fmul <4 x double> %236, %broadcast.splat29
  %238 = fadd <4 x double> %224, %237
  store <4 x double> %238, ptr %70, align 8, !alias.scope !4, !noalias !6
  %239 = getelementptr double, ptr %39, i64 %63
  %240 = getelementptr double, ptr %39, i64 %65
  %241 = getelementptr double, ptr %39, i64 %67
  %242 = getelementptr double, ptr %39, i64 %69
  %243 = load double, ptr %239, align 8, !alias.scope !8
  %244 = load double, ptr %240, align 8, !alias.scope !8
  %245 = load double, ptr %241, align 8, !alias.scope !8
  %246 = load double, ptr %242, align 8, !alias.scope !8
  %247 = insertelement <4 x double> poison, double %243, i64 0
  %248 = insertelement <4 x double> %247, double %244, i64 1
  %249 = insertelement <4 x double> %248, double %245, i64 2
  %250 = insertelement <4 x double> %249, double %246, i64 3
  %251 = fmul <4 x double> %250, %broadcast.splat31
  %252 = fadd <4 x double> %238, %251
  store <4 x double> %252, ptr %70, align 8, !alias.scope !4, !noalias !6
  %253 = getelementptr double, ptr %41, i64 %63
  %254 = getelementptr double, ptr %41, i64 %65
  %255 = getelementptr double, ptr %41, i64 %67
  %256 = getelementptr double, ptr %41, i64 %69
  %257 = load double, ptr %253, align 8, !alias.scope !8
  %258 = load double, ptr %254, align 8, !alias.scope !8
  %259 = load double, ptr %255, align 8, !alias.scope !8
  %260 = load double, ptr %256, align 8, !alias.scope !8
  %261 = insertelement <4 x double> poison, double %257, i64 0
  %262 = insertelement <4 x double> %261, double %258, i64 1
  %263 = insertelement <4 x double> %262, double %259, i64 2
  %264 = insertelement <4 x double> %263, double %260, i64 3
  %265 = fmul <4 x double> %264, %broadcast.splat33
  %266 = fadd <4 x double> %252, %265
  store <4 x double> %266, ptr %70, align 8, !alias.scope !4, !noalias !6
  %267 = getelementptr double, ptr %43, i64 %63
  %268 = getelementptr double, ptr %43, i64 %65
  %269 = getelementptr double, ptr %43, i64 %67
  %270 = getelementptr double, ptr %43, i64 %69
  %271 = load double, ptr %267, align 8, !alias.scope !8
  %272 = load double, ptr %268, align 8, !alias.scope !8
  %273 = load double, ptr %269, align 8, !alias.scope !8
  %274 = load double, ptr %270, align 8, !alias.scope !8
  %275 = insertelement <4 x double> poison, double %271, i64 0
  %276 = insertelement <4 x double> %275, double %272, i64 1
  %277 = insertelement <4 x double> %276, double %273, i64 2
  %278 = insertelement <4 x double> %277, double %274, i64 3
  %279 = fmul <4 x double> %278, %broadcast.splat35
  %280 = fadd <4 x double> %266, %279
  store <4 x double> %280, ptr %70, align 8, !alias.scope !4, !noalias !6
  %281 = getelementptr double, ptr %45, i64 %63
  %282 = getelementptr double, ptr %45, i64 %65
  %283 = getelementptr double, ptr %45, i64 %67
  %284 = getelementptr double, ptr %45, i64 %69
  %285 = load double, ptr %281, align 8, !alias.scope !8
  %286 = load double, ptr %282, align 8, !alias.scope !8
  %287 = load double, ptr %283, align 8, !alias.scope !8
  %288 = load double, ptr %284, align 8, !alias.scope !8
  %289 = insertelement <4 x double> poison, double %285, i64 0
  %290 = insertelement <4 x double> %289, double %286, i64 1
  %291 = insertelement <4 x double> %290, double %287, i64 2
  %292 = insertelement <4 x double> %291, double %288, i64 3
  %293 = fmul <4 x double> %292, %broadcast.splat37
  %294 = fadd <4 x double> %280, %293
  store <4 x double> %294, ptr %70, align 8, !alias.scope !4, !noalias !6
  %index.next = add nuw i64 %index, 4
  %295 = icmp eq i64 %index.next, 512
  br i1 %295, label %middle.block, label %vector.body, !llvm.loop !9

.preheader:                                       ; preds = %.preheader.preheader, %.preheader
  %296 = phi i64 [ %379, %.preheader ], [ 0, %.preheader.preheader ]
  %297 = shl i64 %296, 4
  %298 = getelementptr double, ptr %13, i64 %296
  %.promoted = load double, ptr %298, align 8
  %299 = getelementptr double, ptr %1, i64 %297
  %300 = load double, ptr %299, align 8
  %301 = load double, ptr %8, align 8
  %302 = fmul double %300, %301
  %303 = fadd double %.promoted, %302
  store double %303, ptr %298, align 8
  %304 = getelementptr double, ptr %17, i64 %297
  %305 = load double, ptr %304, align 8
  %306 = load double, ptr %18, align 8
  %307 = fmul double %305, %306
  %308 = fadd double %303, %307
  store double %308, ptr %298, align 8
  %309 = getelementptr double, ptr %19, i64 %297
  %310 = load double, ptr %309, align 8
  %311 = load double, ptr %20, align 8
  %312 = fmul double %310, %311
  %313 = fadd double %308, %312
  store double %313, ptr %298, align 8
  %314 = getelementptr double, ptr %21, i64 %297
  %315 = load double, ptr %314, align 8
  %316 = load double, ptr %22, align 8
  %317 = fmul double %315, %316
  %318 = fadd double %313, %317
  store double %318, ptr %298, align 8
  %319 = getelementptr double, ptr %23, i64 %297
  %320 = load double, ptr %319, align 8
  %321 = load double, ptr %24, align 8
  %322 = fmul double %320, %321
  %323 = fadd double %318, %322
  store double %323, ptr %298, align 8
  %324 = getelementptr double, ptr %25, i64 %297
  %325 = load double, ptr %324, align 8
  %326 = load double, ptr %26, align 8
  %327 = fmul double %325, %326
  %328 = fadd double %323, %327
  store double %328, ptr %298, align 8
  %329 = getelementptr double, ptr %27, i64 %297
  %330 = load double, ptr %329, align 8
  %331 = load double, ptr %28, align 8
  %332 = fmul double %330, %331
  %333 = fadd double %328, %332
  store double %333, ptr %298, align 8
  %334 = getelementptr double, ptr %29, i64 %297
  %335 = load double, ptr %334, align 8
  %336 = load double, ptr %30, align 8
  %337 = fmul double %335, %336
  %338 = fadd double %333, %337
  store double %338, ptr %298, align 8
  %339 = getelementptr double, ptr %31, i64 %297
  %340 = load double, ptr %339, align 8
  %341 = load double, ptr %32, align 8
  %342 = fmul double %340, %341
  %343 = fadd double %338, %342
  store double %343, ptr %298, align 8
  %344 = getelementptr double, ptr %33, i64 %297
  %345 = load double, ptr %344, align 8
  %346 = load double, ptr %34, align 8
  %347 = fmul double %345, %346
  %348 = fadd double %343, %347
  store double %348, ptr %298, align 8
  %349 = getelementptr double, ptr %35, i64 %297
  %350 = load double, ptr %349, align 8
  %351 = load double, ptr %36, align 8
  %352 = fmul double %350, %351
  %353 = fadd double %348, %352
  store double %353, ptr %298, align 8
  %354 = getelementptr double, ptr %37, i64 %297
  %355 = load double, ptr %354, align 8
  %356 = load double, ptr %38, align 8
  %357 = fmul double %355, %356
  %358 = fadd double %353, %357
  store double %358, ptr %298, align 8
  %359 = getelementptr double, ptr %39, i64 %297
  %360 = load double, ptr %359, align 8
  %361 = load double, ptr %40, align 8
  %362 = fmul double %360, %361
  %363 = fadd double %358, %362
  store double %363, ptr %298, align 8
  %364 = getelementptr double, ptr %41, i64 %297
  %365 = load double, ptr %364, align 8
  %366 = load double, ptr %42, align 8
  %367 = fmul double %365, %366
  %368 = fadd double %363, %367
  store double %368, ptr %298, align 8
  %369 = getelementptr double, ptr %43, i64 %297
  %370 = load double, ptr %369, align 8
  %371 = load double, ptr %44, align 8
  %372 = fmul double %370, %371
  %373 = fadd double %368, %372
  store double %373, ptr %298, align 8
  %374 = getelementptr double, ptr %45, i64 %297
  %375 = load double, ptr %374, align 8
  %376 = load double, ptr %46, align 8
  %377 = fmul double %375, %376
  %378 = fadd double %373, %377
  store double %378, ptr %298, align 8
  %379 = add nuw nsw i64 %296, 1
  %exitcond.not = icmp eq i64 %379, 512
  br i1 %exitcond.not, label %middle.block, label %.preheader, !llvm.loop !12

middle.block:                                     ; preds = %vector.body, %.preheader
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @kernel(ptr poison, ptr %4, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %7, i64 poison, i64 poison, i64 poison, ptr poison, ptr %10, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @kernel(ptr poison, ptr %.unpack2.i, i64 poison, i64 poison, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack17.i, i64 poison, i64 poison, i64 poison, ptr poison, ptr %.unpack28.i, i64 poison, i64 poison, i64 poison)
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{!2}
!2 = distinct !{!2, !3}
!3 = distinct !{!3, !"LVerDomain"}
!4 = !{!5}
!5 = distinct !{!5, !3}
!6 = !{!7, !2}
!7 = distinct !{!7, !3}
!8 = !{!7}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.runtime.disable"}
!12 = distinct !{!12, !10}
