module {
  func.func @kernel(%a: memref<512x16xf64>, %b: memref<16xf64>, %c: memref<512xf64>) {
    %zero = arith.constant 0.0 : f64
    linalg.fill ins(%zero : f64) outs(%c : memref<512xf64>)
    linalg.generic {indexing_maps = [affine_map<(i,k)->(i,k)>,
      affine_map<(i,k)->(k)>, affine_map<(i,k)->(i)>],
      iterator_types = ["parallel", "reduction"]}
      ins(%a, %b : memref<512x16xf64>, memref<16xf64>)
      outs(%c : memref<512xf64>) {
      ^bb0(%x: f64, %y: f64, %sum: f64):
        %p = arith.mulf %x, %y : f64
        %s = arith.addf %sum, %p : f64
        linalg.yield %s : f64
    }
    return
  }
}