; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define void @kernel(ptr nocapture readnone %0, ptr nocapture readonly %1, i64 %2, i64 %3, i64 %4, i64 %5, i64 %6, ptr nocapture readnone %7, ptr nocapture readonly %8, i64 %9, i64 %10, i64 %11, ptr nocapture readnone %12, ptr nocapture %13, i64 %14, i64 %15, i64 %16) local_unnamed_addr #0 {
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %13, i8 0, i64 4096, i1 false)
  br label %18

18:                                               ; preds = %17, %55
  %19 = phi i64 [ 0, %17 ], [ %56, %55 ]
  %20 = shl nuw nsw i64 %19, 7
  %21 = getelementptr double, ptr %13, i64 %19
  %.promoted = load <8 x double>, ptr %21, align 8
  %invariant.gep = getelementptr double, ptr %1, i64 %20
  br label %22

22:                                               ; preds = %18, %22
  %23 = phi i64 [ 0, %18 ], [ %54, %22 ]
  %24 = phi <8 x double> [ %.promoted, %18 ], [ %53, %22 ]
  %gep = getelementptr double, ptr %invariant.gep, i64 %23
  %25 = load double, ptr %gep, align 8
  %26 = getelementptr double, ptr %gep, i64 128
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep, i64 256
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep, i64 384
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %gep, i64 512
  %33 = load double, ptr %32, align 8
  %34 = getelementptr double, ptr %gep, i64 640
  %35 = load double, ptr %34, align 8
  %36 = getelementptr double, ptr %gep, i64 768
  %37 = load double, ptr %36, align 8
  %38 = getelementptr double, ptr %gep, i64 896
  %39 = load double, ptr %38, align 8
  %40 = getelementptr double, ptr %8, i64 %23
  %41 = load double, ptr %40, align 8
  %42 = insertelement <8 x double> poison, double %25, i64 0
  %43 = insertelement <8 x double> %42, double %27, i64 1
  %44 = insertelement <8 x double> %43, double %29, i64 2
  %45 = insertelement <8 x double> %44, double %31, i64 3
  %46 = insertelement <8 x double> %45, double %33, i64 4
  %47 = insertelement <8 x double> %46, double %35, i64 5
  %48 = insertelement <8 x double> %47, double %37, i64 6
  %49 = insertelement <8 x double> %48, double %39, i64 7
  %50 = insertelement <8 x double> poison, double %41, i64 0
  %51 = shufflevector <8 x double> %50, <8 x double> poison, <8 x i32> zeroinitializer
  %52 = fmul <8 x double> %49, %51
  %53 = fadd <8 x double> %24, %52
  store <8 x double> %53, ptr %21, align 8
  %54 = add nuw nsw i64 %23, 1
  %exitcond.not = icmp eq i64 %54, 128
  br i1 %exitcond.not, label %55, label %22

55:                                               ; preds = %22
  %56 = add nuw nsw i64 %19, 8
  %57 = icmp ult i64 %19, 504
  br i1 %57, label %18, label %58

58:                                               ; preds = %55
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_ciface_kernel(ptr nocapture readonly %0, ptr nocapture readonly %1, ptr nocapture readonly %2) local_unnamed_addr #1 {
  %.elt1 = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %0, i64 0, i32 1
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %.elt16 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %1, i64 0, i32 1
  %.unpack17 = load ptr, ptr %.elt16, align 8
  %.elt27 = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %2, i64 0, i32 1
  %.unpack28 = load ptr, ptr %.elt27, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack28, i8 0, i64 4096, i1 false)
  br label %4

4:                                                ; preds = %41, %3
  %5 = phi i64 [ 0, %3 ], [ %42, %41 ]
  %6 = shl nuw nsw i64 %5, 7
  %7 = getelementptr double, ptr %.unpack28, i64 %5
  %.promoted.i = load <8 x double>, ptr %7, align 8
  %invariant.gep.i = getelementptr double, ptr %.unpack2, i64 %6
  br label %8

8:                                                ; preds = %8, %4
  %9 = phi i64 [ 0, %4 ], [ %40, %8 ]
  %10 = phi <8 x double> [ %.promoted.i, %4 ], [ %39, %8 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %9
  %11 = load double, ptr %gep.i, align 8
  %12 = getelementptr double, ptr %gep.i, i64 128
  %13 = load double, ptr %12, align 8
  %14 = getelementptr double, ptr %gep.i, i64 256
  %15 = load double, ptr %14, align 8
  %16 = getelementptr double, ptr %gep.i, i64 384
  %17 = load double, ptr %16, align 8
  %18 = getelementptr double, ptr %gep.i, i64 512
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i, i64 640
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i, i64 768
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i, i64 896
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %.unpack17, i64 %9
  %27 = load double, ptr %26, align 8
  %28 = insertelement <8 x double> poison, double %11, i64 0
  %29 = insertelement <8 x double> %28, double %13, i64 1
  %30 = insertelement <8 x double> %29, double %15, i64 2
  %31 = insertelement <8 x double> %30, double %17, i64 3
  %32 = insertelement <8 x double> %31, double %19, i64 4
  %33 = insertelement <8 x double> %32, double %21, i64 5
  %34 = insertelement <8 x double> %33, double %23, i64 6
  %35 = insertelement <8 x double> %34, double %25, i64 7
  %36 = insertelement <8 x double> poison, double %27, i64 0
  %37 = shufflevector <8 x double> %36, <8 x double> poison, <8 x i32> zeroinitializer
  %38 = fmul <8 x double> %35, %37
  %39 = fadd <8 x double> %10, %38
  store <8 x double> %39, ptr %7, align 8
  %40 = add nuw nsw i64 %9, 1
  %exitcond.not.i = icmp eq i64 %40, 128
  br i1 %exitcond.not.i, label %41, label %8

41:                                               ; preds = %8
  %42 = add nuw nsw i64 %5, 8
  %43 = icmp ult i64 %5, 504
  br i1 %43, label %4, label %kernel.exit

kernel.exit:                                      ; preds = %41
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = getelementptr ptr, ptr %0, i64 1
  %3 = load ptr, ptr %2, align 8
  %4 = load ptr, ptr %3, align 8
  %5 = getelementptr ptr, ptr %0, i64 8
  %6 = load ptr, ptr %5, align 8
  %7 = load ptr, ptr %6, align 8
  %8 = getelementptr ptr, ptr %0, i64 13
  %9 = load ptr, ptr %8, align 8
  %10 = load ptr, ptr %9, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %10, i8 0, i64 4096, i1 false)
  br label %11

11:                                               ; preds = %48, %1
  %12 = phi i64 [ 0, %1 ], [ %49, %48 ]
  %13 = shl nuw nsw i64 %12, 7
  %14 = getelementptr double, ptr %10, i64 %12
  %.promoted.i = load <8 x double>, ptr %14, align 8
  %invariant.gep.i = getelementptr double, ptr %4, i64 %13
  br label %15

15:                                               ; preds = %15, %11
  %16 = phi i64 [ 0, %11 ], [ %47, %15 ]
  %17 = phi <8 x double> [ %.promoted.i, %11 ], [ %46, %15 ]
  %gep.i = getelementptr double, ptr %invariant.gep.i, i64 %16
  %18 = load double, ptr %gep.i, align 8
  %19 = getelementptr double, ptr %gep.i, i64 128
  %20 = load double, ptr %19, align 8
  %21 = getelementptr double, ptr %gep.i, i64 256
  %22 = load double, ptr %21, align 8
  %23 = getelementptr double, ptr %gep.i, i64 384
  %24 = load double, ptr %23, align 8
  %25 = getelementptr double, ptr %gep.i, i64 512
  %26 = load double, ptr %25, align 8
  %27 = getelementptr double, ptr %gep.i, i64 640
  %28 = load double, ptr %27, align 8
  %29 = getelementptr double, ptr %gep.i, i64 768
  %30 = load double, ptr %29, align 8
  %31 = getelementptr double, ptr %gep.i, i64 896
  %32 = load double, ptr %31, align 8
  %33 = getelementptr double, ptr %7, i64 %16
  %34 = load double, ptr %33, align 8
  %35 = insertelement <8 x double> poison, double %18, i64 0
  %36 = insertelement <8 x double> %35, double %20, i64 1
  %37 = insertelement <8 x double> %36, double %22, i64 2
  %38 = insertelement <8 x double> %37, double %24, i64 3
  %39 = insertelement <8 x double> %38, double %26, i64 4
  %40 = insertelement <8 x double> %39, double %28, i64 5
  %41 = insertelement <8 x double> %40, double %30, i64 6
  %42 = insertelement <8 x double> %41, double %32, i64 7
  %43 = insertelement <8 x double> poison, double %34, i64 0
  %44 = shufflevector <8 x double> %43, <8 x double> poison, <8 x i32> zeroinitializer
  %45 = fmul <8 x double> %42, %44
  %46 = fadd <8 x double> %17, %45
  store <8 x double> %46, ptr %14, align 8
  %47 = add nuw nsw i64 %16, 1
  %exitcond.not.i = icmp eq i64 %47, 128
  br i1 %exitcond.not.i, label %48, label %15

48:                                               ; preds = %15
  %49 = add nuw nsw i64 %12, 8
  %50 = icmp ult i64 %12, 504
  br i1 %50, label %11, label %kernel.exit

kernel.exit:                                      ; preds = %48
  ret void
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define void @_mlir__mlir_ciface_kernel(ptr nocapture readonly %0) local_unnamed_addr #1 {
  %2 = load ptr, ptr %0, align 8
  %3 = load ptr, ptr %2, align 8
  %4 = getelementptr ptr, ptr %0, i64 1
  %5 = load ptr, ptr %4, align 8
  %6 = load ptr, ptr %5, align 8
  %7 = getelementptr ptr, ptr %0, i64 2
  %8 = load ptr, ptr %7, align 8
  %9 = load ptr, ptr %8, align 8
  %.elt1.i = getelementptr inbounds { ptr, ptr, i64, [2 x i64], [2 x i64] }, ptr %3, i64 0, i32 1
  %.unpack2.i = load ptr, ptr %.elt1.i, align 8
  %.elt16.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %6, i64 0, i32 1
  %.unpack17.i = load ptr, ptr %.elt16.i, align 8
  %.elt27.i = getelementptr inbounds { ptr, ptr, i64, [1 x i64], [1 x i64] }, ptr %9, i64 0, i32 1
  %.unpack28.i = load ptr, ptr %.elt27.i, align 8
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(4096) %.unpack28.i, i8 0, i64 4096, i1 false)
  br label %10

10:                                               ; preds = %47, %1
  %11 = phi i64 [ 0, %1 ], [ %48, %47 ]
  %12 = shl nuw nsw i64 %11, 7
  %13 = getelementptr double, ptr %.unpack28.i, i64 %11
  %.promoted.i.i = load <8 x double>, ptr %13, align 8
  %invariant.gep.i.i = getelementptr double, ptr %.unpack2.i, i64 %12
  br label %14

14:                                               ; preds = %14, %10
  %15 = phi i64 [ 0, %10 ], [ %46, %14 ]
  %16 = phi <8 x double> [ %.promoted.i.i, %10 ], [ %45, %14 ]
  %gep.i.i = getelementptr double, ptr %invariant.gep.i.i, i64 %15
  %17 = load double, ptr %gep.i.i, align 8
  %18 = getelementptr double, ptr %gep.i.i, i64 128
  %19 = load double, ptr %18, align 8
  %20 = getelementptr double, ptr %gep.i.i, i64 256
  %21 = load double, ptr %20, align 8
  %22 = getelementptr double, ptr %gep.i.i, i64 384
  %23 = load double, ptr %22, align 8
  %24 = getelementptr double, ptr %gep.i.i, i64 512
  %25 = load double, ptr %24, align 8
  %26 = getelementptr double, ptr %gep.i.i, i64 640
  %27 = load double, ptr %26, align 8
  %28 = getelementptr double, ptr %gep.i.i, i64 768
  %29 = load double, ptr %28, align 8
  %30 = getelementptr double, ptr %gep.i.i, i64 896
  %31 = load double, ptr %30, align 8
  %32 = getelementptr double, ptr %.unpack17.i, i64 %15
  %33 = load double, ptr %32, align 8
  %34 = insertelement <8 x double> poison, double %17, i64 0
  %35 = insertelement <8 x double> %34, double %19, i64 1
  %36 = insertelement <8 x double> %35, double %21, i64 2
  %37 = insertelement <8 x double> %36, double %23, i64 3
  %38 = insertelement <8 x double> %37, double %25, i64 4
  %39 = insertelement <8 x double> %38, double %27, i64 5
  %40 = insertelement <8 x double> %39, double %29, i64 6
  %41 = insertelement <8 x double> %40, double %31, i64 7
  %42 = insertelement <8 x double> poison, double %33, i64 0
  %43 = shufflevector <8 x double> %42, <8 x double> poison, <8 x i32> zeroinitializer
  %44 = fmul <8 x double> %41, %43
  %45 = fadd <8 x double> %16, %44
  store <8 x double> %45, ptr %13, align 8
  %46 = add nuw nsw i64 %15, 1
  %exitcond.not.i.i = icmp eq i64 %46, 128
  br i1 %exitcond.not.i.i, label %47, label %14

47:                                               ; preds = %14
  %48 = add nuw nsw i64 %11, 8
  %49 = icmp ult i64 %11, 504
  br i1 %49, label %10, label %_mlir_ciface_kernel.exit

_mlir_ciface_kernel.exit:                         ; preds = %47
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { nofree norecurse nosync nounwind memory(argmem: readwrite) }
attributes #1 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.module.flags = !{!0}

!0 = !{i32 2, !"Debug Info Version", i32 3}
